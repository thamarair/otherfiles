<?php 
$background_colors = array('#1abb9c', '#73879c', '#1abb9c', '#73879c', '#1abb9c', '#73879c', '#1abb9c', '#73879c', '#1abb9c', '#73879c', '#1abb9c','#73879c');

?>
<div class="right_col" role="main">
<div class="row">
	<div class="col-md-12 col-sm-12 col-xs-12">
		<div class="x_panel tile" style="text-align: center;background: #1abb9c;color: #fff;padding: 0;">
			<h2 class=""><?php echo $classname[0]['classname']." - ".$section; ?></h2> 
		</div>
	</div>
</div>
<!--
<div class="col-md-12 col-sm-12 col-xs-12"> 
	
	<div class="row" id="Monthwise">
		<div class="col-md-12 col-sm-12 col-xs-12">
			  <div class="x_panel tile">
				<div class="x_title">
				  <h2 class="reporttitle monthwiseavgbspi">Average BSPI score by month</h2>
				  <div class="clearfix"></div>
				</div>
				<div style="display:none; text-align:center;" id="iddivLoading5" class="loading"><img src="<?php echo base_url(); ?>assets/images/ajax-page-loader.gif"  style="width:50px;"  /></div>
				<div id="monthwisebspi"></div>
			  </div>
		</div>
		<div class="col-md-12 col-sm-12 col-xs-12">
		  <div class="x_panel tile">
			<div class="x_title">
			  <h2 class="reporttitle">Average Skill score by month</h2>
			  <div class="clearfix"></div>
			</div>
			<div class="x_title">
			  <input type="button" value="ALL" id="ALL" name="viewreport" class="btn btn-success skillwisescore_M" />
				<input type="button" value="M" id="59" name="viewreport" class="btn btn-success skillwisescore_M" />
				<input type="button" value="VP" id="60" name="viewreport" class="btn btn-success skillwisescore_M" />
				<input type="button" value="FA" id="61" name="viewreport" class="btn btn-success skillwisescore_M" />
				<input type="button" value="PS" id="62" name="viewreport" class="btn btn-success skillwisescore_M" />
				<input type="button" value="L" id="63" name="viewreport" class="btn btn-success skillwisescore_M" />
			</div>
			<div style="display:none; text-align:center;" id="iddivLoading6" class="loading"><img src="<?php echo base_url(); ?>assets/images/ajax-page-loader.gif"  style="width:50px;"  /></div>
			<div id="monthwiseskillscore"></div>
		  </div>
		</div>
	</div>
 
	
	
	</div>
	-->
	<!--
	<div class="col-md-4 col-sm-4 col-xs-4">
	<div class="row" id="Monthwise">
	<div class="col-md-12 col-sm-12 col-xs-12 ipadwidth">
	  <div class="x_panel tile">
		<div class="x_title">
		  <h2 class="reporttitle">Intervention Report</h2> 
		  
		  <div class="clearfix"></div>
		</div>
		<div style="display:none; text-align:center;" id="iddivLoading7"  class="loading"><img src="<?php echo base_url(); ?>assets/images/ajax-page-loader.gif" style="width:50px;" /></div>
		<div id="intervetionreport"></div>
	  </div>
	</div>
	<div class="col-md-12 col-sm-12 col-xs-12 ipadwidth">
	  <div class="x_panel tile">
		<div class="x_title">
		  <h2 class="reporttitle">BSPI Toppers</h2><div><a class="btn btn-round viewmore" href="<?php echo base_url(); ?>index.php/home/bspitopper" >View More</a></div>
		  
		  <div class="clearfix"></div>
		</div>
		<div style="display:none; text-align:center;" id="iddivLoading3"  class="loading"><img src="<?php echo base_url(); ?>assets/images/ajax-page-loader.gif" style="width:50px;" /></div>
		<div id="bspitopper_rprt" ></div>
	  </div>
	</div>
	
	<div class="col-md-12 col-sm-12 col-xs-12 ipadwidth">
	  <div class="x_panel tile">
		<div class="x_title">
		  <h2 class="reporttitle">Skill Toppers</h2><div><a class="btn btn-round viewmore" href="<?php echo base_url(); ?>index.php/home/skilltopper" >View More</a></div>
		  
		  <div class="clearfix"></div>
		</div>
		<div style="display:none; text-align:center;" id="iddivLoading2"  class="loading"><img src="<?php echo base_url(); ?>assets/images/ajax-page-loader.gif" style="width:50px;" /></div>
		<div id="skilltoppers_rprt" ></div>
	  </div>
	</div>
	
	<div class="col-md-12 col-sm-12 col-xs-12 ipadwidth">
	  <div class="x_panel tile">
		<div class="x_title">
		  <h2 class="reporttitle">Crownies Toppers</h2><div><a class="btn btn-round viewmore" href="<?php echo base_url(); ?>index.php/home/crownytopper" >View More</a></div>
		  
		  <div class="clearfix"></div>
		</div>
		<div style="display:none; text-align:center;" id="iddivLoading4" class="loading"><img src="<?php echo base_url(); ?>assets/images/ajax-page-loader.gif"  style="width:50px;"  /></div>
	   <div id="crownytopper_rprt"></div>
	  </div>
	</div>
</div>
	</div>
	-->
	<div class="clearfix"></div>
 
  <div class="row hdndiv">
	

<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
<div class="x_panel tile">
<div class="x_title">
<div>
<h2 style="background:aqua; padding:5px; border-radius:45px; color:#000;">User Performance</h2>
<!--<a href="<?php echo base_url(); ?><?php echo $filename; ?>" class="btn btn-success" style="float: right;margin-bottom: 10px;" >Download</a>-->
</div>
<div style="clear:both">Note : Click on specific student name to view their details</div>
<!--<div style="clear:both">Note : Click on specific academy name to view their details</div>-->


<div class="clearfix"></div>
<div class="clearfix"></div>
</div>
<div class="clearfix"></div>
<div id="clptable">

<?php 

		foreach($asap_reports as $key1=>$val1) {
			
			$query1[$asap_reports[$key1]['username']] =  $val1;
	
		}		
		foreach($clp_reports as $key2=>$val2) {
			
			$query2[$clp_reports[$key2]['username']] =  $val2;

		}
		
?>
	<table id="assementTable" class="table table-striped table-bordered table-hover table-condensed">
    <thead>
      <tr>
        <th>S.No.</th> 
        <th>Student Name</th>
		<th>Username</th>
		<th>Grade</th>  		
		<th>Initial Assessment - BSPI</th>
		<th>Detailed Assessment Skill Index</th>
		<th>Program Status</th>
		<th>Registered Date</th>
		<th>Action</th>
       
      </tr>
    </thead>
    <tbody>
	<?php 
	$ini=0; 
	 
	{

	}
	foreach($query2 as $key3=>$val3){
	$ini++;
		$m=$v=$f=$p=$l=0;
	$ME = explode(',',$val3['skillscorem']);
	$VP = explode(',',$val3['skillscorev']);
	$FA = explode(',',$val3['skillscoref']);
	$PS = explode(',',$val3['skillscorep']);
	$LI = explode(',',$val3['skillscorel']);
	 
	?>	
      <tr>
        <td><?php echo $ini; ?></td> 
		<td class="fname"><a href="<?php echo base_url(); ?>index.php/home/userview/<?php echo $val3['username'];  ?>" style="text-decoration: underline;" ><?php echo $val3['fname'].' '.$val3['lname'];  ?></a></td>
		
		<td><?php echo $val3['username'];  ?></td>
		<td><?php echo str_replace("Grade","", $val3['grade']);  ?></td>		
		
		<td><?php if($query1[$key3]['avgbspiset1']=='') {  echo '-'; } else { echo round($query1[$key3]['avgbspiset1'], 2); } ?>
		<a class="asap" style="float:right" href="javascript:;" data-target="#pwdModal" data-toggle="modal" data-info="<table><tr><td>Memory &nbsp;&nbsp;</td><td>&nbsp;&nbsp;<?php if($query1[$key3]['skillscorem']=='') {  echo '-'; } else { echo round($query1[$key3]['skillscorem'], 2); } ?></td></tr><tr><td>Visual Processing &nbsp;&nbsp;</td><td>&nbsp;&nbsp;<?php if($query1[$key3]['skillscorev']=='') {  echo '-'; } else { echo round($query1[$key3]['skillscorev'], 2); } ?></td></tr><tr><td>Focus and Attention &nbsp;&nbsp;</td><td>&nbsp;&nbsp;<?php if($query1[$key3]['skillscoref']=='') {  echo '-'; } else { echo round($query1[$key3]['skillscoref'], 2); }  ?></td></tr><tr><td>Problem Solving &nbsp;&nbsp;</td><td>&nbsp;&nbsp;<?php if($query1[$key3]['skillscorep']=='') {  echo '-'; } else { echo round($query1[$key3]['skillscorep'], 2); } ?></td></tr><tr><td>Linguistics &nbsp;&nbsp;</td><td>&nbsp;&nbsp;<?php if($query1[$key3]['skillscorel']=='') {  echo '-'; } else { echo round($query1[$key3]['skillscorel'], 2); }?></td></tr></table>"><i class="fa fa-info"></i></a>
		</td>
		
		<td><?php if((($ME[1]+$VP[1]+$FA[1]+$PS[1]+$LI[1])/5)=='') {  echo '-'; } else { echo  round(($ME[1]+$VP[1]+$FA[1]+$PS[1]+$LI[1])/5,2);  } ?> 
		<a class="clp" style="float:right" href="javascript:;" data-target="#pwdModal" data-toggle="modal" data-info="<table><tr><td>Memory &nbsp;&nbsp;</td><td>&nbsp;&nbsp;<?php if($ME[0]=='') {  echo '-'; } else { echo round($ME[0], 2);  }  ?></td></tr><tr><td>Visual Processing &nbsp;&nbsp;</td><td>&nbsp;&nbsp;<?php if($VP[0]=='') {  echo '-'; } else { echo round($VP[0], 2);  } ?></td></tr><tr><td>Focus and Attention &nbsp;&nbsp;</td><td>&nbsp;&nbsp;<?php if($FA[0]=='') {  echo '-'; } else { echo round($FA[0], 2);  } ?></td></tr><tr><td>Problem Solving &nbsp;&nbsp;</td><td>&nbsp;&nbsp;<?php if($PS[0]=='') {  echo '-'; } else { echo round($PS[0], 2);  } ?></td></tr><tr><td>Linguistics &nbsp;&nbsp;</td><td>&nbsp;&nbsp;<?php if($LI[0]=='') {  echo '-'; } else { echo round($LI[0], 2);  } ?></td></tr></table>"><i class="fa fa-info"></i></a>
		</td>
		
		<td>		<?php 		if($query1[$key3]['playcount']==0)		{  			echo 'Initial Assessment Yet to Start'; 		}		else if($query1[$key3]['playcount']<5)		{ 			echo 'Initial Assessment In progress'; 		} 		else if($val3['playcount']==0)		{			echo 'Detailed Assessment Skill Index Yet to start';		}		else if($val3['playcount']<=8)		{ 			echo 'Detailed Assessment Skill Index'; 		}		else if($val3['playcount']>8)		{			echo $val3['cyclename']; 		} ?>		</td>
		
		<td><?php echo date('d-m-Y',strtotime($val3['creation_date'])); ?></td>
		
		<td><a href="<?php echo base_url(); ?>index.php/home/userview/<?php echo $val3['username'];  ?>" class="btn btn-success"><i class="fa fa-eye"></i> View</a></td>
      </tr>
	<?php } ?>
      
	  
    </tbody>
  </table> </div>
	
</div>
</div>
</div>
 
</div>
	<script src="<?php echo base_url(); ?>assets/js/jquery.min.js" type="text/javascript"></script>
	<link href="<?php echo base_url(); ?>assets/css/jquery.dataTables.css" rel="stylesheet" type="text/css">
	<link href="<?php echo base_url(); ?>assets/css/dataTables.tableTools.css" rel="stylesheet" type="text/css">
	
	<script src="<?php echo base_url(); ?>assets/js/jquery.dataTables.js" type="text/javascript"></script>
	<script src="<?php echo base_url(); ?>assets/js/dataTables.tableTools.js" type="text/javascript"></script><script src="<?php echo base_url(); ?>assets/js/highcharts.js"></script>
	<script>
	/* $('.dataTable').DataTable({
		"lengthMenu": [[10,  -1], [10,  "All"]]
		//"scrollX": true
	}); */
	$(document).ready(function() {
		$('#dataTable').DataTable( {
			"order": [[ 7, "desc" ]],
			"rowCallback": function (nRow, aData, iDisplayIndex) {
				 var oSettings = this.fnSettings ();
				 $("td:first", nRow).html(oSettings._iDisplayStart+iDisplayIndex +1);
				 return nRow;
			}
			/* initComplete: function () {
				this.api().columns().every( function () {
					var column = this; //console.log(column);
					var select = $('<select><option value=""></option></select>')
						.appendTo( $(column.footer()).empty() )
						.on( 'change', function () {
							var val = $.fn.dataTable.util.escapeRegex(
								$(this).val()
							);
	 
							column
								.search( val ? '^'+val+'$' : '', true, false )
								.draw();
						} );
	 
					column.data().unique().sort().each( function ( d, j ) {
						select.append( '<option value="'+d+'">'+d+'</option>' )
					} );
				});
			} */
		} );
	});
	</script>
				</div>
			</div>
		</div>
	</div>
<div class="clearfix"></div>
</div>
<style>
.dataTables_wrapper{overflow: auto;}
#dataTable tfoot{display: table-header-group;}
.reporttitle { color:#1abb9c; }
thead{ background-color: #1abb9c; color: #fff;}
body{ padding-right: 0px !important; }
body.modal-open { padding-right: 0px !important; }
.modal-content {width: 70%;margin: 0 auto;}
.modaldata table{margin: 0 auto;}
.modaldata td{text-align:justify;}
.modalheading{color: #0d77de;font-weight: bold;}
.panel-default{border-color: #5187bd;background: #3d6a96;color: #fff;}

.loading {
  position: fixed;
  z-index: 999;
  height: 2em;
  width: 2em;
  overflow: show;
  margin: auto;
  top: 0;
  left: 0;
  bottom: 0;
  right: 0;
}

.loading:before {
  content: '';
  display: block;
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background-color: rgba(0,0,0,0.3);
}

/* :not(:required) hides these rules from IE9 and below */
.loading:not(:required) {
  /* hide "loading..." text */
  font: 0/0 a;
  color: transparent;
  text-shadow: none;
  background-color: transparent;
  border: 0;
}
</style>
<!--<script src="<?php echo base_url(); ?>assets/js/jquery.min.js" type="text/javascript"></script>-->

<script type="text/javascript">
$('#assementTable').DataTable( {
	"lengthMenu": [[10,  -1], [10,  "All"]],
	"fnDrawCallback": function (oSettings) {
		$('.asap').click(function(){ 
			$(".modaldata").html("");$(".modalheading").html("");
			$(".modalheading").html($(this).parent().siblings('td.fname').html()+" - ASAP Skill Score");	
			$(".modaldata").html($(this).attr("data-info"));
		});
		$('.clp').click(function(){
			$(".modaldata").html("");$(".modalheading").html("");
			$(".modalheading").html($(this).parent().siblings('td.fname').html()+" - CLP Skill Score");
			$(".modaldata").html($(this).attr("data-info"));
		});
	}
//"scrollX": true
});

monthwisebspi_report()
monthwiseskillscore_report();
function monthwisebspi_report()
{
	$("#iddivLoading5").show();
	$.ajax({
    type: "POST",
	tryCount : 0,
    retryLimit : 3,
	dataType: "json",
	async: true,
    url: "<?php echo base_url(); ?>index.php/home/monthwiseavgbspi",
    data: {type:'monthwisebspi',grade_id:'<?php echo $grade_id; ?>',section:'<?php echo $section; ?>'},
    success: function(result)
	{
		   $("#iddivLoading5").hide();
		/* $('#monthwisebspi').html(result); */
			monthwisebspichart(result);
    }	,
    error : function(xhr, textStatus, errorThrown ) 
	{
        if (textStatus == 'timeout') {
            this.tryCount++;
            if (this.tryCount <= this.retryLimit) {
                //try again
                $.ajax(this);
                return;
            }            
            return;
        }
        if (xhr.status == 500) {
        } else {
        }
    }
	
	});
} 
function monthwisebspichart(result)
{
	var GraphTitle='<?php echo $gradename." - ".$section; ?>'
   $('#monthwisebspi').highcharts({
		chart: {
            type: 'column'
        },
		
        title: {
            text: GraphTitle,
            x: -20 //center
        },
        subtitle: {
            text: '',
            x: -20
        },
        xAxis: {
            categories:result.categories
        },
        yAxis: {
            min: 0,tickInterval: 10,max:100,
            title: {
                text: 'Score'
            },
            plotLines: [{
                value: 0,
                width: 1,
                color: '#ff3300'
            }]
        },
        tooltip: {
            valueSuffix: '',
			 shared: true
        },
		plotOptions: {
        column: {
            dataLabels: {
                enabled: true,
                crop: false,
                overflow: 'none'
            }
        }
    },
        credits: {
      enabled: false
  },
        series: [
		{
			showInLegend: true,   
			name: 'Training BSPI',
			color: '#1abb9c',
			data:result.data
        },
		{
			name: 'Assessment BSPI',
			type: 'spline',
			color: '#ff9900',
			data: result.asap, 
        }
		]
    });

}
function monthwiseskillscore_report()
{
	$("#iddivLoading6").show();
	$.ajax({
    type: "POST",
	tryCount : 0,
    retryLimit : 3,
    url:  "<?php echo base_url(); ?>index.php/home/monthwiseskillscore",
    data: {type:'monthwiseskillscore',skillid:"ALL",grade_id:'<?php echo $grade_id; ?>',section:'<?php echo $section; ?>'},
    success: function(result){
	$("#iddivLoading6").hide();
		$('#monthwiseskillscore').html(result);
    },
    error : function(xhr, textStatus, errorThrown ) 
	{
        if (textStatus == 'timeout') 
		{
            this.tryCount++;
            if (this.tryCount <= this.retryLimit) 
			{
                //try again
                $.ajax(this);
                return;
            }            
            return;
        }
        if (xhr.status == 500) 
		{
        } else 
		{
        }
    }
});
	
}
$('.skillwisescore_M').click(function(){ // skillscorechart();
	var skillid = $(this).attr('id');
	$("#iddivLoading6").show();
	$.ajax({
    type: "POST",
	tryCount : 0,
    retryLimit : 3,
    url:  "<?php echo base_url(); ?>index.php/home/monthwiseskillscore",
    data: {type:'skillscore_monthwise',skillid:skillid,grade_id:'<?php echo $grade_id; ?>',section:'<?php echo $section; ?>'},
    success: function(result){
	$("#iddivLoading6").hide();
		$('#monthwiseskillscore').html(result);
	
    }
	,
    error : function(xhr, textStatus, errorThrown ) {
        if (textStatus == 'timeout') {
            this.tryCount++;
            if (this.tryCount <= this.retryLimit) {
                //try again
                $.ajax(this);
                return;
            }            
            return;
        }
        if (xhr.status == 500) {
        } else {
        }
    }
});

});

//setTimeout(function() { skilltoppersreport();  }, 10);
//setTimeout(function() { bspitooper_rprt('');  }, 0);
//setTimeout(function() { crownytooper_rprt('');  }, 100);
 $(function(){
    /*$('#skilltoppers_rprt').slimScroll({
        height: '400px',
		alwaysVisible: true
    });*/
});

$(function(){
   /* $('#crownytopper_rprt').slimScroll({
        height: '400px',
		alwaysVisible: false	
    });*/
});

$(function(){
  /*  $('#bspitopper_rprt').slimScroll({
        height: '400px',
		alwaysVisible: false
		
		
    });*/
});
function skilltoppersreport()
{
	$("#iddivLoading2").show();
	$.ajax({
    type: "POST",
	tryCount : 0,
    retryLimit : 3,
    url: "<?php echo base_url(); ?>index.php/home/homeskilltopper",
    data: {type:'skilltoppers',grade_id:'<?php echo $grade_id; ?>',section:'<?php echo $section; ?>'},
    success: function(result){
		$("#iddivLoading2").hide();
		$('#skilltoppers_rprt').html(result);
    },
    error : function(xhr, textStatus, errorThrown ) {
		//alert(textStatus);
        if (textStatus == 'timeout') {
            this.tryCount++;
            if (this.tryCount <= this.retryLimit) {
                //try again
                $.ajax(this);
                return;
            }            
            return;
        }
        if (xhr.status == 500) {
        } else {
        }
    }
});
	
}
function bspitooper_rprt()
{
	$("#iddivLoading3").show();
	$.ajax({
    type: "POST",
	tryCount : 0,
    retryLimit : 3,
    url: "<?php echo base_url(); ?>index.php/home/homebspitopper",
    data: {type:'bspitopper',grade_id:'<?php echo $grade_id; ?>',section:'<?php echo $section; ?>'},
    success: function(result){
		$("#iddivLoading3").hide();
	$('#bspitopper_rprt').html(result);
    }
	,
    error : function(xhr, textStatus, errorThrown ) {
        if (textStatus == 'timeout') {
            this.tryCount++;
            if (this.tryCount <= this.retryLimit) {
                //try again
                $.ajax(this);
                return;
            }            
            return;
        }
        if (xhr.status == 500) {
        } else {
        }
    }
});
	
}
function crownytooper_rprt()
{
	$("#iddivLoading4").show();
	$.ajax({
    type: "POST",
	tryCount : 0,
    retryLimit : 3,
    url: "<?php echo base_url(); ?>index.php/home/homecrownytopper",
    data: {type:'crownytopper',grade_id:'<?php echo $grade_id; ?>',section:'<?php echo $section; ?>'},
    success: function(result)
	{
		$("#iddivLoading4").hide();
		$('#crownytopper_rprt').html(result);
    },
    error : function(xhr, textStatus, errorThrown)
	{
        if (textStatus == 'timeout')
		{
            this.tryCount++;
            if (this.tryCount <= this.retryLimit)
			{
                //try again
                $.ajax(this);
                return;
            }            
            return;
        }
        if (xhr.status == 500)
		{
			
        } 
		else
		{
			
        }
    }
});
}
//intervetionreport();
function intervetionreport()
{
	$("#iddivLoading7").show();	
	$.ajax({
    type: "POST", 
    url:  "<?php echo base_url(); ?>index.php/home/intervetionreport",
    data: {grade_id:'<?php echo $grade_id; ?>',section:'<?php echo $section; ?>'},
    success: function(result)
	{
		$("#iddivLoading7").hide();
		$('#intervetionreport').html(result);
    } 
});
	
}


/* $(document).ready(function(){
		
    
	$.ajax
	({
			type:"POST",
			url:"<?php echo base_url()."index.php/home/s1"; ?>",
			data:{gradeid:'<?php echo $grade_id; ?>','section:<?php echo $section; ?>'},
			success:function(result)
			{
				//alert ('success');
				//$('.loading').hide();
				//$('#clpresult').html(result);
			}
	});
}); */







</script>    
<script src="<?php echo base_url(); ?>assets/js/jquery.slimscroll.js" type="text/javascript"></script>