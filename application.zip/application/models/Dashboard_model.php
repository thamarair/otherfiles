<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard_model extends CI_Model {

        
        public function __construct()
        {
                // Call the CI_Model constructor
                parent::__construct();
				 $this->load->database();
				 $this->load->library('Multipledb');
        }

        public function checklogin($username,$password)
        {
					 
			$query = $this->db->query("SELECT *,(select start_date from schools where id=sa.school_id) as school_startdate,(select academic_id from schools where id=sa.school_id) as acade_id, (select startdate from academic_year where id = (select academic_id from schools where id=sa.school_id)) as strdate, (select enddate from academic_year where id = (select academic_id from schools where id=sa.school_id)) as endate,(select value from config_master where code='UTILIZATIONPERCENTAGE' and status='Y') as percentage  FROM school_admin sa WHERE (email='".$username."' AND password='".$password."') and active = 1 and status=1");		
			//echo $this->db->last_query(); exit;
			return $query->result_array();
        }		
		
		public function schooldetails($schoolid)
        {
			$query = $this->db->query("select school_name, city,country,state,start_date,(select concat(DATE_FORMAT(startdate, '%Y'),'-', DATE_FORMAT(enddate, '%y')) from academic_year where id=academic_id) as acade_id from schools where id=".$schoolid."");
			return $query->result_array();
		}
		
		public function puzzledatas($schoolid,$startdate,$enddate)
        {
			$query = $this->db->query("SELECT SUM(gtime) as gtime_school_count , SUM(answer) as answer_school_count, SUM(attempt_question) as attempted_question_count, (select start_date from schools where id=".$schoolid." ) as school_startdate FROM game_reports gr join users u on gr.gu_id=u.id
		WHERE gtime IS NOT NULL AND answer IS NOT NULL and u.sid=".$schoolid." and lastupdate between '".$startdate."' and '".$enddate."'");
			return $query->result_array();
		}
		
		public function totalusers($schoolid)
        {
			$query = $this->db->query(" select sum(registereduser) as total from (select count(id) as registereduser from users where sid='".$schoolid."' and  status=1 and visible=1 ) x1 ");
			return $query->result_array();
		}
		
		public function gradewiseuserscount($schoolid)
        {
			$query = $this->db->query("select sum(registereduser) as total,registereduser,gradename,grade_id from (select count(id) as registereduser, (select classname from class where id=grade_id) as gradename, grade_id from users where sid='".$schoolid."' and  status=1 and visible=1 group by grade_id) x1 group by grade_id");
			return $query->result_array();
		}
		
		public function trainingbspi_gradewise($schoolid)
        {
			$query = $this->db->query("SELECT round(AVG(finalscore), 2) as finalscore, sid, grade_id, (select classname from class where id = grade_id) as gradename  FROM vii_avguserbspiscore where sid='".$schoolid."' group by grade_id");
			return $query->result_array();
		}
		
		public function assessmentbspi_gradewise($schoolid)
        {
			$query = $this->multipledb->db->query("select gu_id,set1,ROUND(avg(bspi),2) as avgbspi,grade_id,sid,(select classname from class where id=u.grade_id) as gradename  from(SELECT gu_id,count(id) as set1,sum(game_score)/5 as bspi FROM game_reports where gu_id!=0 group by gu_id)a1 join users u on u.id=a1.gu_id where set1>=5 and  u.sid='".$schoolid."' group by u.grade_id");
			return $query->result_array();
		}
		
		public function excepted_session($schoolid)
        {
			$query = $this->db->query("select max(totaldays) as total, gradeid,(select classname from class where id =gradeid) as gradename from (select count(selected_date) as totaldays, gradeid,section from (select selected_date, gradename, gradeid,section,(select count(distinct(u.id)) as regusers from users u where u.grade_id=gradeid and u.section=y1.section and u.sid='".$schoolid."' and u.status = 1 and u.visible=1) as totalusers, (SELECT count(distinct(gu_id)) as com from game_reports as gd join users as u on u.id=gd.gu_id where u.sid='".$schoolid."' and u.grade_id=gradeid and u.section=y1.section and date(lastupdate) = selected_date and gd.gu_id!=0) as attenusers from (select concat('Grade', '',monday_grade) as gradename, selected_date, (select id from class where REPLACE(classname,'Grade ','') = monday_grade) as gradeid,section from (select * from ( select monday_grade,monday_section as section,'Monday' as dayname1 from schools_period_schedule where school_id='".$schoolid."' and academic_id=20 and monday_grade!='' union select tuesday_grade,tuesday_section as section,'Tuesday' as dayname1 from schools_period_schedule where school_id='".$schoolid."' and academic_id=20 and tuesday_grade!='' union select wednesday_grade,wednesday_section as section,'Wednesday' as dayname1 from schools_period_schedule where school_id='".$schoolid."' and academic_id=20 and wednesday_grade!='' union select thursday_grade,thursday_section as section,'Thursday' as dayname1 from schools_period_schedule where school_id='".$schoolid."' and academic_id=20 and thursday_grade!='' union select friday_grade,friday_section as section,'Friday' as dayname1 from schools_period_schedule where school_id='".$schoolid."' and academic_id=20 and friday_grade!='' union select saturday_grade,saturday_section as section,'Saturday' as dayname1 from schools_period_schedule where school_id='".$schoolid."' and academic_id=20 and saturday_grade!='' union select sunday_grade,sunday_section as section,'Sunday' as dayname1 from schools_period_schedule where school_id='".$schoolid."' and academic_id=20 and sunday_grade!='')j1 cross join (select *,dayname(selected_date) as nameofday from (select adddate('1970-01-01',t4.i*10000 + t3.i*1000 + t2.i*100 + t1.i*10 + t0.i) selected_date from (select 0 i union select 1 union select 2 union select 3 union select 4 union select 5 union select 6 union select 7 union select 8 union select 9) t0, (select 0 i union select 1 union select 2 union select 3 union select 4 union select 5 union select 6 union select 7 union select 8 union select 9) t1, (select 0 i union select 1 union select 2 union select 3 union select 4 union select 5 union select 6 union select 7 union select 8 union select 9) t2, (select 0 i union select 1 union select 2 union select 3 union select 4 union select 5 union select 6 union select 7 union select 8 union select 9) t3, (select 0 i union select 1 union select 2 union select 3 union select 4 union select 5 union select 6 union select 7 union select 8 union select 9) t4) v where selected_date between (select start_date from schools where id='".$schoolid."' and status=1 and active=1 and visible=1) and '".date('Y-m-d')."' and selected_date >= (select start_date from schools where id='".$schoolid."' and status=1 and active=1 and visible=1) and selected_date NOT IN (select leave_date from schools_leave_list where school_id = '".$schoolid."' and status=1)) j2 on j1.dayname1=j2.nameofday order by selected_date asc) x1)y1) z1 group by gradeid,section) T group by gradeid");
			//echo $this->db->last_query(); exit;
			return $query->result_array();
		}
		
		public function utilized_session($schoolid)
        {
			$query = $this->db->query("select max(totaldays) as total, gradeid, (select classname from class where id =gradeid) as gradename from (select count(selected_date) as totaldays, gradeid,section from (select selected_date, gradename, gradeid,section,(select count(distinct(u.id)) as regusers from users u where u.grade_id=gradeid and u.section=y1.section and u.sid='".$schoolid."' and u.status = 1 and u.visible=1) as totalusers, (SELECT count(distinct(gu_id)) as com from game_reports as gd join users as u on u.id=gd.gu_id where u.sid='".$schoolid."' and u.grade_id=gradeid and u.section=y1.section and date(lastupdate) = selected_date and gd.gu_id!=0) as attenusers from (select concat('Grade', '',monday_grade) as gradename, selected_date, (select id from class where REPLACE(classname,'Grade ','') = monday_grade) as gradeid,section from (select * from ( select monday_grade,monday_section as section,'Monday' as dayname1 from schools_period_schedule where school_id='".$schoolid."' and academic_id=20 and monday_grade!='' union select tuesday_grade,tuesday_section as section,'Tuesday' as dayname1 from schools_period_schedule where school_id='".$schoolid."' and academic_id=20 and tuesday_grade!='' union select wednesday_grade,wednesday_section as section,'Wednesday' as dayname1 from schools_period_schedule where school_id='".$schoolid."' and academic_id=20 and wednesday_grade!='' union select thursday_grade,thursday_section as section,'Thursday' as dayname1 from schools_period_schedule where school_id='".$schoolid."' and academic_id=20 and thursday_grade!='' union select friday_grade,friday_section as section,'Friday' as dayname1 from schools_period_schedule where school_id='".$schoolid."' and academic_id=20 and friday_grade!='' union select saturday_grade,saturday_section as section,'Saturday' as dayname1 from schools_period_schedule where school_id='".$schoolid."' and academic_id=20 and saturday_grade!='' union select sunday_grade,sunday_section as section,'Sunday' as dayname1 from schools_period_schedule where school_id='".$schoolid."' and academic_id=20 and sunday_grade!='')j1 cross join (select *,dayname(selected_date) as nameofday from (select adddate('1970-01-01',t4.i*10000 + t3.i*1000 + t2.i*100 + t1.i*10 + t0.i) selected_date from (select 0 i union select 1 union select 2 union select 3 union select 4 union select 5 union select 6 union select 7 union select 8 union select 9) t0, (select 0 i union select 1 union select 2 union select 3 union select 4 union select 5 union select 6 union select 7 union select 8 union select 9) t1, (select 0 i union select 1 union select 2 union select 3 union select 4 union select 5 union select 6 union select 7 union select 8 union select 9) t2, (select 0 i union select 1 union select 2 union select 3 union select 4 union select 5 union select 6 union select 7 union select 8 union select 9) t3, (select 0 i union select 1 union select 2 union select 3 union select 4 union select 5 union select 6 union select 7 union select 8 union select 9) t4) v where selected_date between (select start_date from schools where id='".$schoolid."' and status=1 and active=1 and visible=1) and '".date('Y-m-d')."' and selected_date >= (select start_date from schools where id='".$schoolid."' and status=1 and active=1 and visible=1) and selected_date NOT IN (select leave_date from schools_leave_list where school_id = '".$schoolid."' and status=1)) j2 on j1.dayname1=j2.nameofday order by selected_date asc) x1)y1) z1 where attenusers!=0 group by gradeid,section) T group by gradeid");
			//echo $this->db->last_query(); exit;
			return $query->result_array();
		}
		
		public function monthbspiscore($schoolid)
        {
			$query = $this->db->query("SELECT avg(finalscore) as bspi, monthNumber FROM vii_avguserbspiscorebymon where sid='".$schoolid."' group by monthNumber");
			return $query->result_array();
		}
		public function requmonths($schoolid,$startdate,$enddate)
        {$currentday = date('Y-m-d');
			$query = $this->db->query("select DATE_FORMAT(m1, '%Y') as YearNumber,DATE_FORMAT(m1, '%m') as monthNumber,DATE_FORMAT(m1, '%b') as monthName from (select ('".$startdate."' - INTERVAL DAYOFMONTH('".$startdate."')-1 DAY) +INTERVAL m MONTH as m1 from (select @rownum:=@rownum+1 as m from(select 1 union select 2 union select 3 union select 4) t1,(select 1 union select 2 union select 3 union select 4) t2,(select 1 union select 2 union select 3 union select 4) t3,(select 1 union select 2 union select 3 union select 4) t4,(select @rownum:=-1) t0) d1) d2 where m1<=LAST_DAY('".$currentday."')");
			return $query->result_array();
		}
		
		public function bspiutilization($schoolid,$startdate)
        {
			$query = $this->db->query("select gradeid,monthNumber,gradename,CASE WHEN attenusers!=0 THEN COUNT(1) ELSE COUNT(0) END as total from
(select DATE_FORMAT(selected_date, '%m') as monthNumber,sum(attenusers) as attenusers,gradename,section,gradeid from
(select selected_date,weekval,a2.gradename,a2.gradeid,a2.section,count(distinct(gu_id)) as attenusers from (select concat('Grade', '',monday_grade) as gradename, selected_date,weekval,(select id from class where REPLACE(classname,'Grade ','') = monday_grade) as gradeid,section from(select * from 
( select monday_grade,monday_section as section,'Monday' as dayname1 from schools_period_schedule where school_id='".$schoolid."' and academic_id=20 and monday_grade!='' union select tuesday_grade,tuesday_section as section,'Tuesday' as dayname1 from schools_period_schedule where school_id='".$schoolid."' and academic_id=20 and tuesday_grade!='' 
union select wednesday_grade,wednesday_section as section,'Wednesday' as dayname1 from schools_period_schedule where school_id='".$schoolid."' and academic_id=20 and wednesday_grade!='' 
union select thursday_grade,thursday_section as section,'Thursday' as dayname1 from schools_period_schedule where school_id='".$schoolid."' and academic_id=20 and thursday_grade!='' 
union select friday_grade,friday_section as section,'Friday' as dayname1 from schools_period_schedule where school_id='".$schoolid."' and academic_id=20 and friday_grade!='' 
union select saturday_grade,saturday_section as section,'Saturday' as dayname1 from schools_period_schedule where school_id='".$schoolid."' and academic_id=20 and saturday_grade!='' 
union select sunday_grade,sunday_section as section,'Sunday' as dayname1 from schools_period_schedule where school_id='".$schoolid."' and academic_id=20 and sunday_grade!='')j1 cross join 
(select selected_date,dayname(selected_date) as nameofday,CASE WHEN MONTH('2017-06-01')=(select MONTH(start_date) from schools where id='".$schoolid."' and status=1 and active=1 and visible=1) THEN (FLOOR((DAYOFMONTH(selected_date) - DAYOFMONTH((select start_date from schools where id='".$schoolid."' and status=1 and active=1 and visible=1))) / 7) + 1) ELSE (FLOOR((DAYOFMONTH(selected_date) - 1) / 7) + 1) END as weekval from (select adddate('1970-01-01',t4.i*10000 + t3.i*1000 + t2.i*100 + t1.i*10 + t0.i) selected_date from (select 0 i union select 1 union select 2 union select 3 union select 4 union select 5 union select 6 union select 7 union select 8 union select 9) t0, (select 0 i union select 1 union select 2 union select 3 union select 4 union select 5 union select 6 union select 7 union select 8 union select 9) t1, (select 0 i union select 1 union select 2 union select 3 union select 4 union select 5 union select 6 union select 7 union select 8 union select 9) t2, (select 0 i union select 1 union select 2 union select 3 union select 4 union select 5 union select 6 union select 7 union select 8 union select 9) t3, (select 0 i union select 1 union select 2 union select 3 union select 4 union select 5 union select 6 union select 7 union select 8 union select 9) t4) v where selected_date between '".$startdate."' and '".date('Y-m-d')."'  and selected_date >= (select start_date from schools where id='".$schoolid."' and status=1 and active=1 and visible=1) and selected_date NOT IN (select leave_date from schools_leave_list where school_id = '".$schoolid."' and status=1)) j2 on j1.dayname1=j2.nameofday order by selected_date asc) x1)a2 
join users as u1 on u1.grade_id=a2.gradeid and u1.section=a2.section and u1.sid='".$schoolid."' and u1.status = 1 and u1.visible=1 join game_reports as gd on gd.gu_id=u1.id and date(gd.lastupdate) = a2.selected_date group by a2.gradeid,a2.section,selected_date)
 a5 group by gradeid,selected_date order by gradeid,selected_date) a10 group by monthNumber");
 //echo $this->db->last_query(); exit;
			return $query->result_array();
		}
		
		public function todaysession($schoolid)
        {
			$query = $this->db->query("select  period,school_id, start_time, end_time, remarks,   grade,gradeid, section,(select count((id)) from users where sid = '".$schoolid."' and grade_id = a2.gradeid and section = a2.section and status=1 and visible=1)as regusers,(select count((id)) from users where sid = '".$schoolid."' and grade_id = a2.gradeid and section = a2.section and status=1 and visible=1 and login_date=CURDATE())as loginuser,(select count(distinct(gu_id)) from game_reports gr join users as u on u.id=gr.gu_id where u.sid='".$schoolid."' and u.status=1 and u.visible=1 and u.grade_id=a2.gradeid and section=a2.section and date(lastupdate) =CURDATE() and gu_id!=0) as attendusers, (select school_name from schools where id ='".$schoolid."' and status=1 and visible=1 and active=1) as schoolname from (SELECT period,school_id, start_time, end_time, remarks,  grade,(select id from class where REPLACE(classname,'Grade ','')  = grade) as gradeid, section 
			
			from (SELECT period, school_id, start_time, end_time, remarks,   (CASE WHEN dayname(CURDATE()) = 'Monday' THEN monday_grade    WHEN dayname(CURDATE()) = 'Tuesday' THEN tuesday_grade  WHEN dayname(CURDATE()) = 'Wednesday' THEN wednesday_grade WHEN dayname(CURDATE()) = 'Thursday' THEN thursday_grade WHEN dayname(CURDATE()) = 'Friday' THEN friday_grade WHEN dayname(CURDATE()) = 'Saturday' THEN saturday_grade WHEN dayname(CURDATE()) = 'Sunday' THEN sunday_grade END ) as grade, 

(CASE WHEN dayname(CURDATE()) = 'Monday' THEN monday_section  WHEN dayname(CURDATE()) = 'Tuesday' THEN tuesday_section WHEN dayname(CURDATE()) = 'Wednesday' THEN wednesday_section  WHEN dayname(CURDATE()) = 'Thursday' THEN thursday_section WHEN dayname(CURDATE()) = 'Friday' THEN friday_section WHEN dayname(CURDATE()) = 'Saturday' THEN saturday_section WHEN dayname(CURDATE()) = 'Sunday' THEN sunday_section END) as section

from schools_period_schedule sp WHERE   status = 'Y' and academic_id = 20 and school_id = (select id from schools where id='".$schoolid."'  and status=1 and visible=1 and active=1) and school_id=(select school_id from school_admin where active=1 and status=1 and flag=1 and school_id='".$schoolid."') order by period) a1 where grade!='' order by  school_id, period) a2 where  school_id NOT IN (select school_id from schools_leave_list where leave_date=date_format(curdate(), '%Y-%m-%d') and status=1 and academic_id = 20 and school_id='".$schoolid."')  order by  start_time");
			return $query->result_array();
		}
		
		public function training_completedusers($schoolid)
        {
			$query = $this->db->query("select count(set1) as cuser,sid, grade_id, section from (select count(gu_id) as set1,gu_id,sid,section,grade_id from (SELECT gu_id,gs_id,u.sid,u.section,u.grade_id  FROM game_reports as gr 
			join users as u on u.id=gr.gu_id where  gr.gu_id!=0 and u.status=1 and u.visible=1 and u.sid='".$schoolid."' and date(lastupdate) =  CURDATE()  group by gu_id,gs_id) a1 where gs_id in(59,60,61,62,63)  group by gu_id, grade_id, section)a3 where set1>=5 group by grade_id, section");
			return $query->result_array();
		}
		
		public function timetable($schoolid)
        {
			$query = $this->db->query("select * from schools_period_schedule where school_id='".$schoolid."' and academic_id='".$this->session->academicid."' order by period ASC");
			return $query->result_array();
		}
		
		public function leavelist($schoolid)
        {
			$query = $this->db->query("select leave_date as ldates   from schools_leave_list where school_id='".$schoolid."' and academic_id='".$this->session->academicid."' and status=1");
			return $query->result_array();
		}
		
		public function regusers($grade,$section,$schoolid)
        {
			$query = $this->db->query("select count(id) as registereduser from users where sid='".$schoolid."' and section='".$section."' and grade_id=(select id from class WHERE classname LIKE concat('Grade ','".$grade."')) and status=1 and visible=1");
			return $query->result_array();
		}
		
		public function trainingtaken($sessiondate,$grade,$section,$schoolid)
        {
			$query = $this->db->query("select count(distinct(gu_id)) as TrainingTaken from (select gu_id from (SELECT gu_id from game_reports as gd join users as u on u.id=gd.gu_id where u.sid=".$schoolid." and u.section='".$section."' and u.grade_id=(select id from class WHERE classname LIKE concat('Grade ','".$grade."')) and date(lastupdate) ='".$sessiondate."'  and u.status=1 and u.visible=1) as a1 where gu_id!=0)as a2");
			return $query->result_array();
		}
		
		public function trainingfullytaken($sessiondate,$grade,$section,$schoolid)
        {
			$query = $this->db->query("select count(set1) as TrainingFullyTaken from (select count(gu_id) as set1 from (SELECT gu_id,gs_id FROM game_reports as gr join users as u on u.id=gr.gu_id where u.sid=".$schoolid." and u.section='".$section."' and u.grade_id=(select id from class WHERE classname LIKE concat('Grade ','".$grade."')) and gr.gu_id!=0 and u.status=1 and u.visible=1 and date(lastupdate) ='".$sessiondate."'  group by gu_id,gs_id) a1 where gs_id in(59,60,61,62,63)  group by gu_id)a3 where set1>=5");
			return $query->result_array();
		}
		
		public function academymonths($startdate)
        {
			date_default_timezone_set('Asia/Kolkata');
			$currentdate = date('Y-m-d', strtotime('last day of previous month'));
			$query = $this->db->query("select m1 as startdate,LAST_DAY(m1) as enddate,DATE_FORMAT(m1, '%m') as monthNumber,DATE_FORMAT(m1, '%Y') as yearNumber,DATE_FORMAT(m1, '%b') as monthName from (select ('".$startdate."' - INTERVAL DAYOFMONTH('".$startdate."')-1 DAY) +INTERVAL m MONTH as m1 from (select @rownum:=@rownum+1 as m from(select 1 union select 2 union select 3 union select 4) t1,(select 1 union select 2 union select 3 union select 4) t2,(select 1 union select 2 union select 3 union select 4) t3,(select 1 union select 2 union select 3 union select 4) t4,(select @rownum:=-1) t0) d1) d2 where m1<=LAST_DAY('".$currentdate."') order by m1");
			//echo $this->db->last_query(); exit;
			return $query->result_array();
		}
		
		
		public function newqryregattenduser($schoolid,$month0,$month1,$grade_id)
        {
			if($grade_id!=''){$gwhere="grade_id=".$grade_id;}else{$gwhere="1=1";}
			
			$query = $this->db->query("select sum(attenusers)*(select session_division from schools where id='".$schoolid."') as totalsession from (Select selected_date,weekval,COUNT(gradeid) as attenusers from ( select grade_id as gradeid,period_day as nameofday,period_date as selected_date, CASE WHEN MONTH('".$month0."')=(select MONTH(start_date) from schools where id='".$schoolid."' and status=1 and active=1 and visible=1) THEN (FLOOR((DAYOFMONTH(period_date) - DAYOFMONTH((select start_date from schools where id='".$schoolid."' and status=1 and active=1 and visible=1))) / 7) + 1) ELSE (FLOOR((DAYOFMONTH(period_date) - 1) / 7) + 1) END as weekval,sid  from schools_period_schedule_daysbeta  where sid='".$schoolid."' and ".$gwhere." and academic_id=20 and period_date between '".$month0."' and '".$month1."' and period_date >= (select start_date from schools where id='".$schoolid."' and status=1 and active=1 and visible=1) and period_date NOT IN (select leave_date from schools_leave_list where school_id ='".$schoolid."' and status=1) ) a2 group by weekval order by weekval,selected_date) X");
			//echo $this->db->last_query(); exit;
			return $query->result_array();
		}
		
		 public function newqrycompleteduser($schoolid,$month0,$month1,$percentage,$grade_id)
        {
			 if($grade_id!=''){$gwhere="grade_id=".$grade_id;}else{$gwhere="1=1";}
			 
			$query = $this->db->query("select sum(completeduser)*(select session_division from schools where id='".$schoolid."') as attendsession,sum(halfattended)*(select session_division from schools where id='".$schoolid."') as halfattendsession from (select sum(Attensession) as completeduser,sum(Halfattended) as halfattended,weekval,selected_date from (select period_no,gradeid,gradename,section,sid,ROUND((attenusers/reguser)*100,2),attenusers,reguser,
			SUM(CASE WHEN attenusers >=1 THEN 1 ELSE 0 END) as Halfattended,SUM(CASE WHEN ROUND((attenusers/reguser)*100,2)>='".$percentage."' THEN 1 ELSE 0 END) as Attensession,weekval,selected_date from (select period_no,weekval,selected_date,sum(reguser) as reguser,sum(attenusers) as attenusers,gradename,section,gradeid,sid from 
			(select period_no,selected_date,weekval,a2.gradename,a2.gradeid,a2.sid,a2.section,expected_user as reguser,count(distinct(gu_id)) as attenusers from 
			(select period_no,grade_id as gradeid,sid,grade_name as gradename,section,period_day as nameofday,period_date as selected_date,expected_user,CASE WHEN MONTH('".$month0."')=(select MONTH(start_date) from schools where id='".$schoolid."' and status=1 and active=1 and visible=1) THEN (FLOOR((DAYOFMONTH(period_date) - DAYOFMONTH((select start_date from schools where id='".$schoolid."' and status=1 and active=1 and visible=1))) / 7) + 1) ELSE (FLOOR((DAYOFMONTH(period_date) - 1) / 7) + 1) END as weekval from schools_period_schedule_daysbeta s1 where sid='".$schoolid."' and ".$gwhere." and academic_id=20 and period_date between '".$month0."' and '".$month1."' and period_date >= (select start_date from schools where id='".$schoolid."' and status=1 and active=1 and visible=1) and period_date NOT IN (select leave_date from schools_leave_list where school_id = '".$schoolid."' and status=1) )a2 
			join users as u1 on u1.grade_id=a2.gradeid and u1.section=a2.section and u1.sid='".$schoolid."' and u1.status = 1 and u1.visible=1 join game_reports as gd on gd.gu_id=u1.id and date(gd.lastupdate) = a2.selected_date group by a2.gradeid,a2.section,selected_date,period_no) a5 group by gradeid,section,weekval,selected_date,period_no order by gradeid,section) a10 group by weekval,gradeid,section,period_no) z group by weekval) X");
			//echo $this->db->last_query(); exit;
			return $query->result_array();
		}
		
		public function qryregattenduser($schoolid,$month0,$month1,$grade_id)
        {
			  if($grade_id!=''){$gwhere="grade_id=".$grade_id;}else{$gwhere="1=1";}
			  
				$query = $this->db->query("select sum(totalusers) as totaluser,sum(attenusers) as attenusers from (select selected_date, gradename, gradeid,section,expected_user as totalusers,(SELECT count(distinct(gu_id)) as com from game_reports as gd join users as u on u.id=gd.gu_id where u.sid='".$schoolid."'  and u.grade_id=gradeid and u.section=y1.section  and date(lastupdate) = selected_date and gd.gu_id!=0) as attenusers from (select expected_user,grade_id as gradeid,grade_name as gradename,section,period_day as nameofday,period_date as selected_date from schools_period_schedule_daysbeta where sid='".$schoolid."' and ".$gwhere." and academic_id=20 and period_date between '".$month0."' and '".$month1."' and period_date >= (select start_date from schools where id='".$schoolid."' and status=1 and active=1 and visible=1) and period_date NOT IN (select leave_date from schools_leave_list where school_id = '".$schoolid."' and status=1))y1)a1");
				return $query->result_array();
		}
		
		public function qrycompleteduser($schoolid,$month0,$month1,$grade_id)
        {
			 if($grade_id!=''){$gwhere="grade_id=".$grade_id;}else{$gwhere="1=1";}
			 
				$query = $this->db->query("select count(*) as completeduser,weekval,gradename,gradeid,section from (select count(*) as cntval,weekval,gradename,gradeid,section,id from (select selected_date,weekval,a2.gradename,a2.gradeid,a2.section,a2.id,gs_id from (select selected_date,weekval,y1.gradename,y1.gradeid,y1.section,u.id from (select grade_id as gradeid,grade_name as gradename,section,period_day as nameofday,period_date as selected_date, CASE WHEN MONTH('".$month[0]."')=(select MONTH(start_date) from schools where id='".$schoolid."' and status=1 and active=1 and visible=1) THEN (FLOOR((DAYOFMONTH(period_date) - DAYOFMONTH((select start_date from schools where id='".$schoolid."' and status=1 and active=1 and visible=1))) / 7) + 1) ELSE (FLOOR((DAYOFMONTH(period_date) - 1) / 7) + 1) END as weekval from schools_period_schedule_days where sid='".$schoolid."' and ".$gwhere." and academic_id=20 and period_date between '".$month0."' and '".$month1."' and period_date >= (select start_date from schools where id='".$schoolid."' and status=1 and active=1 and visible=1) and period_date NOT IN (select leave_date from schools_leave_list where school_id = '".$schoolid."' and status=1)) y1 join users as u on u.grade_id=y1.gradeid and u.section=y1.section and u.sid='".$schoolid."' and u.status = 1 and u.visible=1 group by y1.gradeid,y1.section,selected_date,u.id order by selected_date) a2 join game_reports as gd on gd.gu_id=a2.id and date(gd.lastupdate) = a2.selected_date group by a2.gradeid,a2.section,selected_date,gs_id,gu_id)Z1 group by weekval,gradename,gradeid,section,id)zz1 where cntval>=5 ");
				return $query->result_array();
		} 
		
		public function getasapbspirangecount($schoolid,$month0,$month1,$grade_id)
        {
				if($grade_id!=''){$gwhere="u.grade_id=".$grade_id;}else{$gwhere="1=1";}
				
				$query = $this->multipledb->db->query("select  count(lessthantwenty) as '<=20', count(twentytoforty) as '20-40', count(fortytosixty) as '40-60', count(sixtytoeighty) as '60-80', count(greatereithy) as '>80' from (SELECT AVG(game_score) as finalscore, 

				case when (AVG(game_score)) <=20 then '<20' END as lessthantwenty,
				case when (AVG(game_score)) >20 and (AVG(game_score)) <=40 then '20-40' end as twentytoforty, 
				case when (AVG(game_score)) >40 and (AVG(game_score)) <=60 then '40-60' END as fortytosixty, 
				case  when (AVG(game_score)) >60 and (AVG(game_score)) <=80 then '60-80' end as sixtytoeighty, 
				case when (AVG(game_score)) >80 then '>80' end as greatereithy 

				from game_reports gd JOIN users u ON gd.gu_id=u.id where u.sid='".$schoolid."' and ".$gwhere." and u.status=1 and u.academicyear=19 and gs_id!=0 group BY gu_id) x");
				//echo $this->multipledb->db->last_query(); exit;
				return $query->result_array();
		} 
		public function getclpbspirangecount($schoolid,$month0,$month1,$grade_id)
        {
				if($grade_id!=''){$gwhere="u.grade_id=".$grade_id;}else{$gwhere="1=1";}
				
				$query = $this->db->query("select count(lessthantwenty) as '<=20', count(twentytoforty) as '20-40', count(fortytosixty) as '40-60', count(sixtytoeighty) as '60-80', count(greatereithy) as '>80' from 

				(select round((sum(score) / 5),2) AS finalscore, 
				case when round((sum(score) / 5),2) <=20 then '<=20' END as lessthantwenty,
				case when round((sum(score) / 5),2) >20 and round((sum(score) / 5),2) <=40 then '20-40' end as twentytoforty, 
				case when round((sum(score) / 5),2) >40 and round((sum(score) / 5),2) <=60 then '40-60' END as fortytosixty, 
				case when round((sum(score) / 5),2) >60 and round((sum(score) / 5),2) <=80 then '60-80' end as sixtytoeighty,
				case when round((sum(score) / 5),2) >80 then '>80' end as greatereithy  

				from (select avg(score) as score,gu_id,username from (select ".$this->config->item('skilllogic')."(game_score) as score,gs_id,gu_id,username from gamedata gd JOIN users u ON gd.gu_id=u.id WHERE gs_id in (59,60,61,62,63) and lastupdate BETWEEN '".$month0."' and '".$month1."' and u.status=1 and u.visible=1 and u.sid='".$schoolid."' and ".$gwhere." group by gs_id,gu_id,lastupdate) a1 group by gs_id,gu_id)a2 group by gu_id) x");
				//echo $this->db->last_query(); exit;
				return $query->result_array();
		}
		public function GetReportMessage($schoolid,$monthno,$rcode)
		{
			$query = $this->db->query("Select HdMessage,FooMessage,RCode from  eom_report where School_id='".$schoolid."' and Month_no='".$monthno."' and RCode='".$rcode."' and Status=1");
			//echo $this->db->last_query(); exit;
			return $query->result_array();
		}
		public function getschools()
        {
			$query = $this->db->query('select s.*,sa.email from schools as s 
			join school_admin as sa on sa.school_id=s.id where s.status=1 and s.active=1 and s.visible=1 and s.id NOT IN(2,69) and isemailneed="Y" ');
			
			//echo $this->db->last_query(); exit;
			return $query->result_array();
        }
		
		public function getschools_rps()
        {
			$query = $this->db->query('select s.*,sa.email from schools as s 
			join school_admin as sa on sa.school_id=s.id where s.status=1 and s.active=1 and s.visible=1  and s.id=69 and isemailneed="Y" ');
			
			//echo $this->db->last_query(); exit;
			return $query->result_array();
        }
		
		public function getSpecificSchools()
        {
			$query = $this->db->query('select s.*,sa.email from schools as s 
			join school_admin as sa on sa.school_id=s.id where s.status=1 and s.active=1 and s.visible=1 and s.id NOT IN (2,78) and isemailneed="Y" ');
			
			//echo $this->db->last_query(); exit;
			return $query->result_array();
        }
		
		
		public function userscore_grade($sid,$grade_id,$start_date,$section)
		{	
			$startdate=$start_date;
			$enddate=date("Y-m-d");
			/*
			$query = $this->db->query('select id,fname,username,gp_id,section,grade_id,
			(SELECT count(gs_id) FROM gamedata WHERE gu_id =a1.id and gs_id=59 and lastupdate between "'.$startdate.'" and "'.$enddate.'") as MEnoftimesplayed,
			(SELECT count(gs_id) FROM gamedata WHERE gu_id =a1.id and gs_id=60 and lastupdate between "'.$startdate.'" and "'.$enddate.'") as VPnoftimesplayed,
			(SELECT count(gs_id) FROM gamedata WHERE gu_id =a1.id and gs_id=61 and lastupdate between "'.$startdate.'" and "'.$enddate.'") as FAnoftimesplayed,
			(SELECT count(gs_id) FROM gamedata WHERE gu_id =a1.id and gs_id=62 and lastupdate between "'.$startdate.'" and "'.$enddate.'") as PSnoftimesplayed,
			(SELECT count(gs_id) FROM gamedata WHERE gu_id =a1.id and gs_id=63 and lastupdate between "'.$startdate.'" and "'.$enddate.'") as LInoftimesplayed,
			
			(select CONVERT(CONCAT(avg(game_score),",",avg(game_score1)),CHAR(50))  from (select '.$this->config->item('skilllogic').'(game_score)as game_score,'.$this->config->item('skilllogic1').'(game_score)as game_score1,lastupdate,gu_id from game_reports where gs_id=59  and lastupdate between "'.$startdate.'" and "'.$enddate.'"  group by lastupdate,gu_id ) s1  where gu_id=a1.id) as Memory,
			
			(select CONVERT(CONCAT(avg(game_score),",",avg(game_score1)),CHAR(50)) from (select '.$this->config->item('skilllogic').'(game_score)as game_score,'.$this->config->item('skilllogic1').'(game_score)as game_score1,lastupdate,gu_id from game_reports where gs_id=60  and lastupdate between "'.$startdate.'" and "'.$enddate.'"  group by lastupdate,gu_id )s2  where gu_id=a1.id) as VP,
			
			(select CONVERT(CONCAT(avg(game_score),",",avg(game_score1)),CHAR(50)) from (select '.$this->config->item('skilllogic').'(game_score)as game_score,'.$this->config->item('skilllogic1').'(game_score)as game_score1,lastupdate,gu_id from game_reports where gs_id=61  and lastupdate between "'.$startdate.'" and "'.$enddate.'"  group by lastupdate,gu_id )s3  where gu_id=a1.id) as FA,
			
			(select CONVERT(CONCAT(avg(game_score),",",avg(game_score1)),CHAR(50)) from (select '.$this->config->item('skilllogic').'(game_score)as game_score,'.$this->config->item('skilllogic1').'(game_score)as game_score1,lastupdate,gu_id from game_reports where gs_id=62  and lastupdate between "'.$startdate.'" and "'.$enddate.'"  group by lastupdate,gu_id )s4  where gu_id=a1.id) as PS,
			
			(select CONVERT(CONCAT(avg(game_score),",",avg(game_score1)),CHAR(50)) from (select '.$this->config->item('skilllogic').'(game_score)as game_score,'.$this->config->item('skilllogic1').'(game_score)as game_score1,lastupdate,gu_id from  game_reports where gs_id=63  and lastupdate between "'.$startdate.'" and "'.$enddate.'"  group by lastupdate,gu_id )s5  where gu_id=a1.id) as LI,
			
			(select sum(attempt_question) from (select sum(attempt_question)as attempt_question,lastupdate,gu_id from  game_reports where lastupdate between "'.$startdate.'" and "'.$enddate.'"  group by lastupdate,gu_id ) s1  where gu_id=a1.id) as attempt_question,
			
			(select sum(answer) from (select sum(answer)as answer,lastupdate,gu_id from  game_reports where lastupdate between "'.$startdate.'" and "'.$enddate.'"  group by lastupdate,gu_id ) s1  where gu_id=a1.id) as answer,
			
			(select sum(rtime) from (select sum(rtime)as rtime,lastupdate,gu_id from  game_reports where lastupdate between "'.$startdate.'" and "'.$enddate.'"  group by lastupdate,gu_id ) s1  where gu_id=a1.id) as rtime,
			
			(select count(lastupdate) from (select lastupdate,gu_id from  game_reports where lastupdate between "'.$startdate.'" and "'.$enddate.'" group by lastupdate,gu_id) s1 where gu_id=a1.id) as AttendedSession,  
			
			(select SUM(CASE WHEN game>=5 THEN 1 ELSE 0 END) as completedsession from (select sum(gamesplayed) as game,gu_id,lastupdate from (select lastupdate,count(DISTINCT gs_id) as gamesplayed,gu_id from  game_reports where lastupdate between "'.$startdate.'" and "'.$enddate.'" group by gu_id,gs_id,lastupdate) a1 group by gu_id,lastupdate) s1 where gu_id=a1.id) as CompletedSession,
			
			(select count(id) from  schools_period_schedule_days where grade_id=a1.grade_id and section=a1.section and sid="'.$sid.'" and period_date between "'.$startdate.'" and "'.$enddate.'" and period_date >= (select start_date from schools where id="'.$sid.'" and status=1 and active=1 and visible=1) and period_date NOT IN (select leave_date from schools_leave_list where school_id="'.$sid.'" and status=1)) as scheduled_session
			
			from (select id,fname,username,gp_id,section,grade_id from users where sid="'.$sid.'" and grade_id="'.$grade_id.'" and status=1 and visible=1 and academicyear=20) a1 order by username asc');
			*/
			if($grade_id!=''){$gwhere=" grade_id=".$grade_id;}else{$gwhere="1=1";} 
			if($section!=''){$swhere=" section='".$section."'";}else{$swhere="1=1";}
			
			$query = $this->db->query('select id,fname,username,gp_id,section,grade_id,(select classname from class where id=grade_id) as classname,
			(SELECT count(gs_id) FROM gamedata WHERE gu_id =a1.id and gs_id=59 and lastupdate between "'.$startdate.'" and "'.$enddate.'") as MEnoftimesplayed,
			(SELECT count(gs_id) FROM gamedata WHERE gu_id =a1.id and gs_id=60 and lastupdate between "'.$startdate.'" and "'.$enddate.'") as VPnoftimesplayed,
			(SELECT count(gs_id) FROM gamedata WHERE gu_id =a1.id and gs_id=61 and lastupdate between "'.$startdate.'" and "'.$enddate.'") as FAnoftimesplayed,
			(SELECT count(gs_id) FROM gamedata WHERE gu_id =a1.id and gs_id=62 and lastupdate between "'.$startdate.'" and "'.$enddate.'") as PSnoftimesplayed,
			(SELECT count(gs_id) FROM gamedata WHERE gu_id =a1.id and gs_id=63 and lastupdate between "'.$startdate.'" and "'.$enddate.'") as LInoftimesplayed,
			
			(select CONVERT(CONCAT(avg(game_score),",",avg(game_score1)),CHAR(50))  from (select '.$this->config->item('skilllogic').'(game_score)as game_score,'.$this->config->item('skilllogic1').'(game_score)as game_score1,lastupdate,gu_id from game_reports gr join users u on u.id=gr.gu_id  where sid="'.$sid.'" and '.$gwhere.' and status=1 and visible=1 and academicyear=20 and gs_id=59  and lastupdate between "'.$startdate.'" and "'.$enddate.'"  group by lastupdate,gu_id ) s1  where gu_id=a1.id) as Memory,
			
			(select CONVERT(CONCAT(avg(game_score),",",avg(game_score1)),CHAR(50)) from (select '.$this->config->item('skilllogic').'(game_score)as game_score,'.$this->config->item('skilllogic1').'(game_score)as game_score1,lastupdate,gu_id from game_reports gr join users u on u.id=gr.gu_id where  sid="'.$sid.'" and '.$gwhere.' and status=1 and visible=1 and academicyear=20 and gs_id=60  and lastupdate between "'.$startdate.'" and "'.$enddate.'"  group by lastupdate,gu_id )s2  where gu_id=a1.id) as VP,
			
			(select CONVERT(CONCAT(avg(game_score),",",avg(game_score1)),CHAR(50)) from (select '.$this->config->item('skilllogic').'(game_score)as game_score,'.$this->config->item('skilllogic1').'(game_score)as game_score1,lastupdate,gu_id from game_reports gr join users u on u.id=gr.gu_id where  sid="'.$sid.'" and '.$gwhere.' and status=1 and visible=1 and academicyear=20 and gs_id=61  and lastupdate between "'.$startdate.'" and "'.$enddate.'"  group by lastupdate,gu_id )s3  where gu_id=a1.id) as FA,
			
			(select CONVERT(CONCAT(avg(game_score),",",avg(game_score1)),CHAR(50)) from (select '.$this->config->item('skilllogic').'(game_score)as game_score,'.$this->config->item('skilllogic1').'(game_score)as game_score1,lastupdate,gu_id from game_reports gr join users u on u.id=gr.gu_id where  sid="'.$sid.'" and '.$gwhere.' and status=1 and visible=1 and academicyear=20 and gs_id=62  and lastupdate between "'.$startdate.'" and "'.$enddate.'"  group by lastupdate,gu_id )s4  where gu_id=a1.id) as PS,
			
			(select CONVERT(CONCAT(avg(game_score),",",avg(game_score1)),CHAR(50)) from (select '.$this->config->item('skilllogic').'(game_score)as game_score,'.$this->config->item('skilllogic1').'(game_score)as game_score1,lastupdate,gu_id from  game_reports gr join users u on u.id=gr.gu_id where  sid="'.$sid.'" and '.$gwhere.' and status=1 and visible=1 and academicyear=20 and gs_id=63  and lastupdate between "'.$startdate.'" and "'.$enddate.'"  group by lastupdate,gu_id )s5  where gu_id=a1.id) as LI,
			
			(select score from (select sum(gr.game_score)/5 AS score,gr.gs_id AS gs_id,gr.gu_id AS gu_id,username from schoolsclp_1920_live_1906.game_reports gr join schoolsclp_1920_live_1906.users u on u.id = gr.gu_id where u.status = 1 and u.sid="'.$sid.'"  and '.$gwhere.' and gr.gs_id in (59,60,61,62,63) group by  gr.gu_id)s6  where s6.username=a1.username) as asapbspi,
			
			( select sum(attempt_question)as attempt_question from  game_reports where gu_id=a1.id and lastupdate between "'.$startdate.'" and "'.$enddate.'"   ) as attempt_question,
			
			( select sum(answer)as answer from  game_reports where gu_id=a1.id and lastupdate between "'.$startdate.'" and "'.$enddate.'")  as answer,
			
			(select sum(rtime)as rtime from  game_reports where gu_id=a1.id and lastupdate between "'.$startdate.'" and "'.$enddate.'"  ) as rtime,
			
			(select count(distinct(lastupdate)) from game_reports where gu_id=a1.id and lastupdate between "'.$startdate.'" and "'.$enddate.'") as AttendedSession,  
			
			(select SUM(CASE WHEN game>=5 THEN 1 ELSE 0 END) as completedsession from (select sum(gamesplayed) as game,gu_id,lastupdate from (select lastupdate,count(DISTINCT gs_id) as gamesplayed,gu_id from  game_reports gr join users u on u.id=gr.gu_id where sid="'.$sid.'" and '.$gwhere.' and status=1 and visible=1 and academicyear=20 and lastupdate between "'.$startdate.'" and "'.$enddate.'" group by gu_id,gs_id,lastupdate) a1 group by gu_id,lastupdate) s1 where gu_id=a1.id) as CompletedSession,
			
			(select count(id) from  schools_period_schedule_days where grade_id=a1.grade_id and section=a1.section and sid="'.$sid.'" and period_date between "'.$startdate.'" and "'.$enddate.'" and period_date >= (select start_date from schools where id="'.$sid.'" and status=1 and active=1 and visible=1) and period_date NOT IN (select leave_date from schools_leave_list where school_id="'.$sid.'" and status=1)) as scheduled_session
			
			from (select id,fname,username,gp_id,section,grade_id from users where sid="'.$sid.'" and '.$gwhere.' and 
			'.$swhere.' and status=1 and visible=1 and academicyear=20) a1 order by username asc');
			//echo $this->db->last_query(); exit;
			//exit;
			return $query->result_array();
		}
		
		public function getGradeName($grade_id)
		{
			$query = $this->db->query("select classname from class where id='".$grade_id."' ");
			return $query->result_array();
		}
		public function getTotalGrade($schoolid)
		{
			$query = $this->db->query("select  DISTINCT sc.class_id as id, c.classname from skl_class_section sc join class c ON sc.class_id = c.id Where sc.school_id = '".$schoolid."'");
			return $query->result_array();
		}
		public function getTotalGradeSection($schoolid,$grade_id)
		{
			if($grade_id!=''){$gwhere="sc.class_id=".$grade_id;}else{$gwhere="1=1";}
			
			$query = $this->db->query("select  sc.class_id as id, c.classname,section from skl_class_section sc join class c ON sc.class_id = c.id Where sc.school_id = '".$schoolid."' and ".$gwhere." ");
			return $query->result_array();
		}
		public function getTotalGradeSec($schoolid)
		{
			$query = $this->db->query("select group_concat(DISTINCT sc.class_id )as id, c.classname,group_concat( DISTINCT section) as section from skl_class_section sc join class c ON sc.class_id = c.id Where sc.school_id ='".$schoolid."'");
			return $query->result_array();
		}
		public function bspitopper_gradewise($schoolid,$monthNumber,$grade_id)
		{
			/*$query = $this->db->query("select bspi,monthName,monthNumber,sid,gu_id,grade_id,section,(select GROUP_CONCAT(CONCAT(fname,' ',lname)) from users where id = gu_id) as username,classname,school_name,section from
			(select bspi,monthName,monthNumber,sid,gu_id,grade_id,(select CONCAT(fname,' ',lname) from users where id = gu_id) as username,(select classname from class where id = grade_id)as classname,(select school_name from schools where id = sid)as school_name,section from (select finalscore as bspi,gu_id,monthNumber,monthName,sid,grade_id,section from vii_avguserbspiscorebymon) as a1 where a1.gu_id in (select id from users where status=1 and visible=1) and a1.sid='".$schoolid."' and ROUND(a1.bspi,2)in(select bspi from vii_bspigradetoppersbysec as vv3 where vv3.monthNumber =a1.monthNumber and vv3.monthNumber='".$monthNumber."'  and vv3.sid='".$schoolid."' and vv3.grade_id=a1.grade_id and vv3.section=a1.section)) as a5 group by grade_id,section");*/
			if($grade_id!=''){$gwhere="u.grade_id=".$grade_id;}else{$gwhere="1=1";}
			
			$query = $this->db->query("select bspi,monthName,monthNumber,sid,gu_id,grade_id,section,username,

classname,school_name,section from 

(select bspi,monthName,monthNumber,sid,gu_id,grade_id,

(select CONCAT(fname,' ',lname) from users where id = gu_id) as username,

(select classname from class where id = grade_id)as classname,

(select school_name from schools where id = sid)as school_name,

section from 

(select round((sum(vii2.score) / 5),2) AS bspi,vii2.gu_id AS gu_id,vii2.sid AS sid,vii2.grade_id AS grade_id,vii2.section AS section,vii2.monthNumber AS monthNumber,monthname(str_to_date(vii2.monthNumber,'%m')) AS monthName,vii2.yearName AS yearName from (select round(avg(score),2) AS score,gu_id AS gu_id,gs_id AS gs_id,sid AS sid,grade_id AS grade_id,section AS section,date_format(lastupdate,'%m') AS monthNumber,date_format(lastupdate,'%Y') AS yearName from (select ".$this->config->item('skilllogic')."(gr.game_score) AS score,gr.gs_id AS gs_id,gr.gu_id AS gu_id,u.sid AS sid,u.grade_id AS grade_id,u.section AS section,gr.lastupdate AS lastupdate from game_reports gr join users u on u.id = gr.gu_id where u.status = 1 and u.visible = 1 and u.sid ='".$schoolid."' and ".$gwhere."  and gr.gs_id in (59,60,61,62,63) and date_format(gr.lastupdate,'%m') ='".$monthNumber."'  group by gr.gs_id,gr.gu_id,gr.lastupdate) a1 group by gs_id,gu_id,month(lastupdate)) vii2 group by vii2.gu_id,vii2.monthNumber) as a1 

where ROUND(a1.bspi,2)in

(select bspi from (select max(bspi4.finalscore) AS bspi,bspi4.gu_id AS gu_id,bspi4.monthNumber AS monthNumber,bspi4.sid AS sid,bspi4.grade_id AS grade_id,bspi4.section AS section from (select round((sum(vii2.score) / 5),2) AS finalscore,vii2.gu_id AS gu_id,vii2.sid AS sid,vii2.grade_id AS grade_id,vii2.section AS section,  username,vii2.monthNumber AS monthNumber,monthname(str_to_date(vii2.monthNumber,'%m')) AS monthName,vii2.yearName AS yearName from (select round(avg(score),2) AS score,gu_id AS gu_id,gs_id AS gs_id,sid AS sid,grade_id AS grade_id,username,section AS section,date_format(lastupdate,'%m') AS monthNumber,date_format(lastupdate,'%Y') AS yearName from (select ".$this->config->item('skilllogic')."(gr.game_score) AS score,gr.gs_id AS gs_id,gr.gu_id AS gu_id,u.sid AS sid,u.grade_id AS grade_id,u.section AS section,username,gr.lastupdate AS lastupdate from game_reports gr join users u on u.id = gr.gu_id where u.status = 1 and u.visible = 1 and u.sid ='".$schoolid."' and ".$gwhere." and gr.gs_id in (59,60,61,62,63) and date_format(gr.lastupdate,'%m') ='".$monthNumber."' group by gr.gs_id,gr.gu_id,gr.lastupdate) a1 group by gs_id,gu_id,month(lastupdate))vii2 group by vii2.gu_id,vii2.monthNumber) bspi4  group by bspi4.monthNumber,bspi4.sid,bspi4.grade_id,bspi4.section) as vv3 where vv3.grade_id=a1.grade_id and vv3.section=a1.section)) as a5 


group by grade_id,section");
			//echo "<br/>".$this->db->last_query();
			return $query->result_array();
		}
		public function MaxSkillScore_gradewise($schoolid,$start_date,$enddate,$grade_id,$section)
		{
			 $query = $this->db->query("select * from (select grade_id,section,gs_id,MAX(score) as maxscore from

			(select gu_id,grade_id,section,gs_id,username,round(avg(score),2) as score from 
			 
			 (select gu_id,gs_id,grade_id,username,section,avg(game_score) as score from game_reports as gr join users as u on u.id=gu_id where lastupdate between '".$start_date."' and '".$enddate."' and gs_id IN(59,60,61,62,63) and u.sid='".$schoolid."' group by gs_id , gu_id, lastupdate) as a1
			 
			 group by gu_id,gs_id) as a2 group by grade_id,section,gs_id Order BY maxscore desc) as a3 order by grade_id,section,gs_id");	
			 //echo "<br/>".$this->db->last_query();
			return $query->result_array();
		}
		
		public function MaxSkillScore_gradewiseUser($schoolid,$start_date,$enddate,$grade_id,$section,$score,$gs_id)
		{
			 $query = $this->db->query("select group_concat(name SEPARATOR  ', ') as name,score from (select gu_id,grade_id,section,gs_id,username,concat(fname,'',lname) as name,round(avg(score),2) as score from 
 
			(select gu_id,gs_id,grade_id,username,fname,lname,section,avg(game_score) as score from game_reports as gr join users as u on u.id=gu_id where lastupdate between '".$start_date."' and '".$enddate."' and gs_id IN(59,60,61,62,63) and grade_id='".$grade_id."' and section='".$section."' and u.sid='".$schoolid."' group by gs_id , gu_id, lastupdate) as a1 
			group by gu_id,gs_id) as a2 where grade_id='".$grade_id."' and section='".$section."' and score IN('".$score."')  and gs_id='".$gs_id."' ");	
			//echo "<br/>".$this->db->last_query(); 
			return $query->result_array();
		}
		
		public function bspianalysislist($schoolid,$startdate,$enddate,$type)
		{
			if($type==1)
			{
				$where1 = "OR finalscore<=20"; 	
			}
			if($type==2)
			{
				$where2 = "OR  finalscore>20 and finalscore<=40";
			}
			if($type==3)
			{
				$where3 = "OR  finalscore>40 and finalscore<=60";
			}
			if($type==4)
			{
				$where4 = "OR  finalscore>60 and finalscore<=80";
			}
			if($type==5)
			{
				$where5 = "OR  finalscore>80";
			}
		
			$query = $this->db->query("select username,name,(select school_name from schools where id='".$schoolid."' and status=1 and active=1 and visible=1) as schoolname,section,(select classname from class where id=grade_id) as grade,finalscore from (SELECT SUM(score)/5 as finalscore,count(gu_id) as playedcount, gu_id,(SELECT username from users where id=gu_id and status=1 and visible=1) as username,(SELECT fname from users where id=gu_id and status=1 and visible=1) as name,(SELECT grade_id from users where id=gu_id and status=1 and visible=1) as grade_id,(SELECT section from users where id=gu_id and status=1 and visible=1) as section from (select (AVG(score)) as score, gu_id, gs_id from (SELECT (".$this->config->item('skilllogic')."(game_score)) as score , gs_id , gu_id, lastupdate FROM game_reports WHERE gs_id in (59,60,61,62,63) and lastupdate BETWEEN '".$startdate."' and '".$enddate."' and gu_id in (select id from users  where status=1 and visible=1 and sid='".$schoolid."') group by gs_id , gu_id, lastupdate) a1 group by gs_id, gu_id ) a2 group by gu_id)a1 where (1=2 ".$where1." ".$where2." ".$where3." ".$where4." ".$where5.") order by finalscore");
			//echo $this->db->last_query(); exit;
			return $query->result_array();
		}
		public function Eom_BspiRange($schoolid,$monthNumber,$grade_id)
		{
			/*$query = $this->db->query("select scorerange, count(*) rangecount,schoolid,grade_id,(select classname from class where id=grade_id) as gradename,section from 
			(SELECT SUM(score)/5 as finalscore, 
			case 
			when (SUM(score)/5) <=20 then '<=20' 
			when (SUM(score)/5) >20 and (SUM(score)/5) <=40 then  '20-40' 
			when (SUM(score)/5) >40 and (SUM(score)/5) <=60 then '40-60' 
			when (SUM(score)/5) >60 and (SUM(score)/5) <=80 then '60-80' 
			when (SUM(score)/5) >80 then '>80' end as scorerange,count(gu_id) as playedcount, gu_id,(SELECT username from users where id=gu_id and status=1 and visible=1) as username,(SELECT fname from users where id=gu_id and status=1 and visible=1) as name,(SELECT grade_id from users where id=gu_id and status=1 and visible=1) as grade_id,(SELECT section from users where id=gu_id and status=1 and visible=1) as section,(SELECT sid from users where id=gu_id and status=1 and visible=1) as schoolid from 
			(select (AVG(score)) as score, gu_id, gs_id from (SELECT (".$this->config->item('skilllogic')."(game_score)) as score , gs_id , gu_id, lastupdate FROM game_reports WHERE gs_id in (59,60,61,62,63) and gu_id in (select id from users  where status=1 and visible=1 and sid='".$schoolid."' and month(lastupdate)='".$monthNumber."' ) group by gs_id , gu_id, lastupdate) a1 group by gs_id, gu_id ) a2 group by gu_id)a1 group by scorerange,schoolid,grade_id,section");*/
			
			if($grade_id!=''){$gwhere="u.grade_id=".$grade_id;}else{$gwhere="1=1";}
			
			$query = $this->db->query("select scorerange, count(*) rangecount,schoolid,grade_id,(select classname from class where id=grade_id) as gradename,section from (SELECT SUM(score)/5 as finalscore, case when (SUM(score)/5) <=20 then '<=20' when (SUM(score)/5) >20 and (SUM(score)/5) <=40 then '20-40' when (SUM(score)/5) >40 and (SUM(score)/5) <=60 then '40-60' when (SUM(score)/5) >60 and (SUM(score)/5) <=80 then '60-80' when (SUM(score)/5) >80 then '>80' end as scorerange,count(gu_id) as playedcount, gu_id, username,fname as name, grade_id,section,sid as schoolid from (select (AVG(score)) as score, gu_id,gs_id, sid,fname,lname,username,section,grade_id from (SELECT (".$this->config->item('skilllogic')."(game_score)) as score , gs_id , gu_id,sid,fname,lname,username,section,u.grade_id, lastupdate FROM game_reports gr join users u on u.id=gr.gu_id WHERE gs_id in (59,60,61,62,63) and u.status=1 and u.visible=1 and sid='".$schoolid."' and ".$gwhere." and month(lastupdate)='".$monthNumber."' group by gs_id , gu_id, lastupdate) a1 group by gs_id, gu_id ) a2 group by gu_id)a1 group by scorerange,schoolid,grade_id,section");
			 //echo $this->db->last_query(); exit;
			return $query->result_array();
		}
		public function Eom_BspiRange_grade($schoolid,$monthNumber,$grade_id)
		{
			if($grade_id!=''){$gwhere="u.grade_id=".$grade_id;}else{$gwhere="1=1";}
			
			$query = $this->db->query("select scorerange, count(*) rangecount,schoolid,grade_id,(select classname from class where id=grade_id) as gradename,section from (SELECT SUM(score)/5 as finalscore, case when (SUM(score)/5) <=20 then '<=20' when (SUM(score)/5) >20 and (SUM(score)/5) <=40 then '20-40' when (SUM(score)/5) >40 and (SUM(score)/5) <=60 then '40-60' when (SUM(score)/5) >60 and (SUM(score)/5) <=80 then '60-80' when (SUM(score)/5) >80 then '>80' end as scorerange,count(gu_id) as playedcount, gu_id, username,fname as name, grade_id,section,sid as schoolid from (select (AVG(score)) as score, gu_id,gs_id, sid,fname,lname,username,section,grade_id from (SELECT (".$this->config->item('skilllogic')."(game_score)) as score , gs_id , gu_id,sid,fname,lname,username,section,u.grade_id, lastupdate FROM game_reports gr join users u on u.id=gr.gu_id WHERE gs_id in (59,60,61,62,63) and u.status=1 and u.visible=1 and sid='".$schoolid."' and ".$gwhere." and month(lastupdate)='".$monthNumber."' group by gs_id , gu_id, lastupdate) a1 group by gs_id, gu_id ) a2 group by gu_id)a1 group by scorerange,schoolid,grade_id");
			 //echo $this->db->last_query(); exit;
			return $query->result_array();
		}
		public function Eom_NotAttendedUserCount($schoolid,$monthNumber,$grade_id)
		{
			if($grade_id!=''){$gwhere="grade_id=".$grade_id;}else{$gwhere="1=1";}
			
			$query = $this->db->query("select count(id) as notatteneduser,grade_id,section,username,fname,lname,(select classname from class where id=grade_id) as gradename from users where id Not IN(select gu_id from game_reports where month(lastupdate)='".$monthNumber."' and sid='".$schoolid."' and ".$gwhere.") and sid='".$schoolid."' and ".$gwhere." and status=1 and visible=1 group by grade_id,section");
			 //echo $this->db->last_query(); exit;
			return $query->result_array();
		}
		public function Eom_NotAttendedUserList($schoolid,$monthNumber,$grade_id)
		{
			if($grade_id!=''){$gwhere="grade_id=".$grade_id;}else{$gwhere="1=1";}
			
			$query = $this->db->query("select id,grade_id,(select classname from class where id=grade_id) as gradename,section,username,fname,lname from users where id Not IN(select gu_id from game_reports where month(lastupdate)='".$monthNumber."' and sid='".$schoolid."') and sid='".$schoolid."' and ".$gwhere." and status=1 and visible=1");
			 //echo $this->db->last_query(); exit;
			return $query->result_array();
		}
		public function Eom_Bspi_Twenty($schoolid,$monthNumber,$grade_id)
		{
			
			/*$query = $this->db->query("select username,name,(select school_name from schools where id='18' and status=1 and active=1 and visible=1) as schoolname,section,(select classname from class where id=grade_id) as grade,finalscore from (SELECT SUM(score)/5 as finalscore,count(gu_id) as playedcount, gu_id,(SELECT username from users where id=gu_id and status=1 and visible=1) as username,(SELECT fname from users where id=gu_id and status=1 and visible=1) as name,(SELECT grade_id from users where id=gu_id and status=1 and visible=1) as grade_id,(SELECT section from users where id=gu_id and status=1 and visible=1) as section from (select (AVG(score)) as score, gu_id, gs_id from (SELECT (".$this->config->item('skilllogic')."(game_score)) as score , gs_id , gu_id, lastupdate FROM `game_reports` WHERE gs_id in (59,60,61,62,63) and gu_id in (select id from users  where status=1 and visible=1 and sid='".$schoolid."' and month(lastupdate)='".$monthNumber."' ) group by gs_id , gu_id, lastupdate) a1 group by gs_id, gu_id ) a2 group by gu_id)a1 where finalscore<=20  order by finalscore");*/
			if($grade_id!=''){$gwhere="grade_id=".$grade_id;}else{$gwhere="1=1";}
			
			$query = $this->db->query("select username,name,(select school_name from schools where id='18' and status=1 and active=1 and visible=1) as schoolname,section,(select classname from class where id=grade_id) as grade,finalscore from (SELECT SUM(score)/5 as finalscore,count(gu_id) as playedcount, gu_id, username,fname as name, grade_id,section,sid as schoolid from (select (AVG(score)) as score,gu_id,gs_id, sid,fname,lname,username,section,grade_id from (SELECT (".$this->config->item('skilllogic')."(game_score)) as score , gs_id , gu_id,sid,fname,lname,username,section,u.grade_id, lastupdate FROM game_reports gr join users u on u.id=gr.gu_id WHERE gs_id in (59,60,61,62,63) and u.status=1 and u.visible=1 and sid='".$schoolid."'  and ".$gwhere." and month(lastupdate)='".$monthNumber."' group by gs_id , gu_id, lastupdate) a1 group by gs_id, gu_id ) a2 group by gu_id)a1 where finalscore<=20 order by finalscore");
			//echo $this->db->last_query(); exit;
			return $query->result_array();
		}
		public function Eom_Bspi_TwentytoForty($schoolid,$monthNumber,$grade_id)
		{
			/*$query = $this->db->query("select username,name,(select school_name from schools where id='18' and status=1 and active=1 and visible=1) as schoolname,section,(select classname from class where id=grade_id) as grade,finalscore from (SELECT SUM(score)/5 as finalscore,count(gu_id) as playedcount, gu_id,(SELECT username from users where id=gu_id and status=1 and visible=1) as username,(SELECT fname from users where id=gu_id and status=1 and visible=1) as name,(SELECT grade_id from users where id=gu_id and status=1 and visible=1) as grade_id,(SELECT section from users where id=gu_id and status=1 and visible=1) as section from (select (AVG(score)) as score, gu_id, gs_id from (SELECT (".$this->config->item('skilllogic')."(game_score)) as score , gs_id , gu_id, lastupdate FROM `game_reports` WHERE gs_id in (59,60,61,62,63) and gu_id in (select id from users  where status=1 and visible=1 and sid='".$schoolid."' and month(lastupdate)='".$monthNumber."' ) group by gs_id , gu_id, lastupdate) a1 group by gs_id, gu_id ) a2 group by gu_id)a1 where finalscore >20 and finalscore<=40  order by finalscore");*/
			
			if($grade_id!=''){$gwhere="grade_id=".$grade_id;}else{$gwhere="1=1";}
			
			$query = $this->db->query("select username,name,(select school_name from schools where id='18' and status=1 and active=1 and visible=1) as schoolname,section,(select classname from class where id=grade_id) as grade,finalscore from (SELECT SUM(score)/5 as finalscore,count(gu_id) as playedcount, gu_id, username,fname as name, grade_id,section,sid as schoolid from (select (AVG(score)) as score,gu_id,gs_id, sid,fname,lname,username,section,grade_id from (SELECT (".$this->config->item('skilllogic')."(game_score)) as score , gs_id , gu_id,sid,fname,lname,username,section,u.grade_id, lastupdate FROM game_reports gr join users u on u.id=gr.gu_id WHERE gs_id in (59,60,61,62,63) and u.status=1 and u.visible=1 and sid='".$schoolid."' and ".$gwhere." and month(lastupdate)='".$monthNumber."' group by gs_id , gu_id, lastupdate) a1 group by gs_id, gu_id ) a2 group by gu_id)a1 where  finalscore >20 and finalscore<=40 order by finalscore");
			//echo $this->db->last_query(); exit;
			return $query->result_array();
		}
		public function Eom_Bspi_FortytoSixty($schoolid,$monthNumber,$grade_id)
		{
			/*$query = $this->db->query("select username,name,(select school_name from schools where id='18' and status=1 and active=1 and visible=1) as schoolname,section,(select classname from class where id=grade_id) as grade,finalscore from (SELECT SUM(score)/5 as finalscore,count(gu_id) as playedcount, gu_id,(SELECT username from users where id=gu_id and status=1 and visible=1) as username,(SELECT fname from users where id=gu_id and status=1 and visible=1) as name,(SELECT grade_id from users where id=gu_id and status=1 and visible=1) as grade_id,(SELECT section from users where id=gu_id and status=1 and visible=1) as section from (select (AVG(score)) as score, gu_id, gs_id from (SELECT (".$this->config->item('skilllogic')."(`game_score`)) as score , gs_id , gu_id, lastupdate FROM `game_reports` WHERE gs_id in (59,60,61,62,63) and gu_id in (select id from users  where status=1 and visible=1 and sid='".$schoolid."' and month(lastupdate)='".$monthNumber."' ) group by gs_id , gu_id, lastupdate) a1 group by gs_id, gu_id ) a2 group by gu_id)a1 where finalscore >40 and finalscore<=60 order by finalscore");*/
			
			if($grade_id!=''){$gwhere="grade_id=".$grade_id;}else{$gwhere="1=1";}
			
			$query = $this->db->query("select username,name,(select school_name from schools where id='18' and status=1 and active=1 and visible=1) as schoolname,section,(select classname from class where id=grade_id) as grade,finalscore from (SELECT SUM(score)/5 as finalscore,count(gu_id) as playedcount, gu_id, username,fname as name, grade_id,section,sid as schoolid from (select (AVG(score)) as score,gu_id,gs_id, sid,fname,lname,username,section,grade_id from (SELECT (".$this->config->item('skilllogic')."(game_score)) as score , gs_id , gu_id,sid,fname,lname,username,section,u.grade_id, lastupdate FROM game_reports gr join users u on u.id=gr.gu_id WHERE gs_id in (59,60,61,62,63) and u.status=1 and u.visible=1 and sid='".$schoolid."' and ".$gwhere." and month(lastupdate)='".$monthNumber."' group by gs_id , gu_id, lastupdate) a1 group by gs_id, gu_id ) a2 group by gu_id)a1 where  finalscore >40 and finalscore<=60 order by finalscore");
			//echo $this->db->last_query(); exit;
			return $query->result_array();
		}
		public function Eom_Bspi_SixtytoEighty($schoolid,$monthNumber,$grade_id)
		{
			/*$query = $this->db->query("select username,name,(select school_name from schools where id='18' and status=1 and active=1 and visible=1) as schoolname,section,(select classname from class where id=grade_id) as grade,finalscore from (SELECT SUM(score)/5 as finalscore,count(gu_id) as playedcount, gu_id,(SELECT username from users where id=gu_id and status=1 and visible=1) as username,(SELECT fname from users where id=gu_id and status=1 and visible=1) as name,(SELECT grade_id from users where id=gu_id and status=1 and visible=1) as grade_id,(SELECT section from users where id=gu_id and status=1 and visible=1) as section from (select (AVG(score)) as score, gu_id, gs_id from (SELECT (".$this->config->item('skilllogic')."(`game_score`)) as score , gs_id , gu_id, lastupdate FROM `game_reports` WHERE gs_id in (59,60,61,62,63) and gu_id in (select id from users  where status=1 and visible=1 and sid='".$schoolid."' and month(lastupdate)='".$monthNumber."' ) group by gs_id , gu_id, lastupdate) a1 group by gs_id, gu_id ) a2 group by gu_id)a1 where finalscore >60 and finalscore<=80 order by finalscore");*/
			
			if($grade_id!=''){$gwhere="grade_id=".$grade_id;}else{$gwhere="1=1";}
			
			$query = $this->db->query("select username,name,(select school_name from schools where id='18' and status=1 and active=1 and visible=1) as schoolname,section,(select classname from class where id=grade_id) as grade,finalscore from (SELECT SUM(score)/5 as finalscore,count(gu_id) as playedcount, gu_id, username,fname as name, grade_id,section,sid as schoolid from (select (AVG(score)) as score,gu_id,gs_id, sid,fname,lname,username,section,grade_id from (SELECT (".$this->config->item('skilllogic')."(game_score)) as score , gs_id , gu_id,sid,fname,lname,username,section,u.grade_id, lastupdate FROM game_reports gr join users u on u.id=gr.gu_id WHERE gs_id in (59,60,61,62,63) and u.status=1 and u.visible=1 and sid='".$schoolid."' and ".$gwhere." and month(lastupdate)='".$monthNumber."' group by gs_id , gu_id, lastupdate) a1 group by gs_id, gu_id ) a2 group by gu_id)a1 where  finalscore >60 and finalscore<=80 order by finalscore");
			//echo $this->db->last_query(); exit;
			return $query->result_array();
		}
		
		public function Eom_Bspi_AboveEighty($schoolid,$monthNumber,$grade_id)
		{
			/*$query = $this->db->query("select username,name,(select school_name from schools where id='18' and status=1 and active=1 and visible=1) as schoolname,section,(select classname from class where id=grade_id) as grade,finalscore from (SELECT SUM(score)/5 as finalscore,count(gu_id) as playedcount, gu_id,(SELECT username from users where id=gu_id and status=1 and visible=1) as username,(SELECT fname from users where id=gu_id and status=1 and visible=1) as name,(SELECT grade_id from users where id=gu_id and status=1 and visible=1) as grade_id,(SELECT section from users where id=gu_id and status=1 and visible=1) as section from (select (AVG(score)) as score, gu_id, gs_id from (SELECT (".$this->config->item('skilllogic')."(`game_score`)) as score , gs_id , gu_id, lastupdate FROM `game_reports` WHERE gs_id in (59,60,61,62,63) and gu_id in (select id from users  where status=1 and visible=1 and sid='".$schoolid."' and month(lastupdate)='".$monthNumber."' ) group by gs_id , gu_id, lastupdate) a1 group by gs_id, gu_id ) a2 group by gu_id)a1 where finalscore >80 order by finalscore");*/
			
			if($grade_id!=''){$gwhere="grade_id=".$grade_id;}else{$gwhere="1=1";}
			
			$query = $this->db->query("select username,name,(select school_name from schools where id='18' and status=1 and active=1 and visible=1) as schoolname,section,(select classname from class where id=grade_id) as grade,finalscore from (SELECT SUM(score)/5 as finalscore,count(gu_id) as playedcount, gu_id, username,fname as name, grade_id,section,sid as schoolid from (select (AVG(score)) as score,gu_id,gs_id, sid,fname,lname,username,section,grade_id from (SELECT (".$this->config->item('skilllogic')."(game_score)) as score , gs_id , gu_id,sid,fname,lname,username,section,u.grade_id, lastupdate FROM game_reports gr join users u on u.id=gr.gu_id WHERE gs_id in (59,60,61,62,63) and u.status=1 and u.visible=1 and sid='".$schoolid."' and ".$gwhere." and month(lastupdate)='".$monthNumber."' group by gs_id , gu_id, lastupdate) a1 group by gs_id, gu_id ) a2 group by gu_id)a1 where  finalscore >80 order by finalscore");
			//echo $this->db->last_query(); exit;
			return $query->result_array();
		}
		
		
		
		public function getPuzzleCount()
		{
			$query = $this->multipledb->counterdb->query("SELECT  SUM(gtime) as gtime_total , SUM(correct_answer) as gtime_total_ans,SUM(attempted_question) as gtime_total_att FROM counters WHERE gtime IS NOT NULL AND correct_answer IS NOT NULL ");
			//echo $this->db->last_query(); exit;
			return $query->result_array();
		}
		
		
		public function InsertTime()
		{
			$query = $this->db->query("Insert into test(datetime)values(NOW())");
		}
		
		
		
		
		public function checkMailSentToday($sid)
		{
			$query = $this->db->query("Select count(id) as issenton from eod_mail_log where sid='".$sid."' and date(sent_on)=CURDATE() and status=1");
			//echo $this->db->last_query(); exit;
			return $query->result_array();
		}
		public function InsertTodayMail($sid)
		{
			$query = $this->db->query("INSERT INTO eod_mail_log(sid,sent_on,status)values('".$sid."',NOW(),1)");
		}
		
		
		
		/** PROGRESS REPORT **/
		public function getgrades($sid)
		{
			$query = $this->db->query("select class_id, classname from skl_class_plan sk JOIN class c ON sk.class_id=c.id where school_id='".$sid."' order by class_id asc ");
			//echo $this->db->last_query(); exit;
			return $query->result_array();
		}

		public function getsection($sid,$gradeid)
		{
			$query = $this->db->query("select class_id,section from skl_class_section where school_id='".$sid."' and class_id='".$gradeid."' order by section ASC ");
			//echo $this->db->last_query(); exit;
			return $query->result_array();
		} 
		
		
		public function getasapbspi($schoolid,$gradeid,$section,$student)
	{
		$query = $this->multipledb->db->query("SELECT  sum(game_score)/5 as bspi FROM game_reports join users as u on u.id=gu_id where u.username='".$student."' and u.status=1");
		//echo $this->multipledb->db->last_query(); exit;
		return $query->result_array();
	}
	
		public function getasapbspi_classwise($schoolid,$gradeid,$section)
	{
		 
		$query = $this->multipledb->db->query("select round(avg(bspi),2) as bspi from (SELECT sum(game_score)/5 as bspi FROM game_reports join users as u on u.id=gu_id where u.sid='".$schoolid."' and u.grade_id='".$gradeid."' and u.section='".$section."' and u.status=1 group by u.id) as a1 ");
		//echo $this->multipledb->db->last_query(); exit;
		return $query->result_array();
	}
	
	public function get_max_asapbspi($schoolid,$gradeid,$section)
	{
		$query = $this->multipledb->db->query("select max(bspi) as highscore from ( SELECT sum(game_score)/5 as bspi,gu_id FROM game_reports g join users as u on u.id=g.gu_id where u.grade_id='".$gradeid."' and u.section='".$section."' and u.sid='".$schoolid."' group by gu_id) a1");
		//echo $this->multipledb->db->last_query(); exit;
		return $query->result_array();
	}
	
	
	public function get_max_asapbspi_classwise($schoolid,$gradeid,$section)
	{
		$query = $this->multipledb->db->query("select max(bspi) as highscore from ( SELECT sum(game_score)/5 as bspi,gu_id FROM game_reports g join users as u on u.id=g.gu_id where u.grade_id='".$gradeid."' and u.section='".$section."' and u.sid='".$schoolid."' group by gu_id) a1");
		//echo $this->multipledb->db->last_query(); exit;
		return $query->result_array();
	}
	
		public function getBSPI($userid)
		 {
			 
		$query = $this->db->query("SELECT (MAX(`game_score`)) as score ,gs_id , lastupdate FROM `game_reports` WHERE gs_id in (59,60,61,62,63) and gu_id=(select id from users where username='".$userid."' and academicyear=20 and status=1 ) and (lastupdate between '".$this->session->school_startdate."' and '".date('Y-m-d')."')   group by gs_id , lastupdate");
			return $query->result_array();
		 }
		 
		 public function getmonths($schlstartdate)
		 {
			 
		$query = $this->db->query("select DATE_FORMAT(m1, '%m') as monthNumber,DATE_FORMAT(m1, '%M') as monthName,DATE_FORMAT(m1, '%Y') as yearName from (select ('".$schlstartdate."' - INTERVAL DAYOFMONTH('".$schlstartdate."')-1 DAY) +INTERVAL m MONTH as m1 from (select @rownum:=@rownum+1 as m from(select 1 union select 2 union select 3 union select 4) t1,(select 1 union select 2 union select 3 union select 4) t2,(select 1 union select 2 union select 3 union select 4) t3,(select 1 union select 2 union select 3 union select 4) t4,(select @rownum:=-1) t0) d1) d2 where m1<=LAST_DAY('".$this->session->enddate."')");
			return $query->result_array();
		 }
		 
		 public function getmnthwisebspi($studentname)
		 {
			 
		$query = $this->db->query("SELECT finalscore,monthNumber,monthName,yearName from vii_avguserbspiscorebymon where gu_id=(select id from users where username='".$studentname."' and status=1)");
		//echo $this->db->last_query(); exit;
			return $query->result_array();
			
		 } 


		 public function getmnthwisebspi_classwise($schoolid,$gradeid,$section)
		 {
			 $query = $this->db->query("SELECT round(avg(finalscore),2) as finalscore,monthNumber,monthName,yearName from vii_avguserbspiscorebymon where sid='".$schoolid."' and grade_id='".$gradeid."' and section='".$section."' group by monthNumber");
			 
		//$query = $this->db->query("SELECT finalscore,monthNumber,monthName from vii_avguserbspiscorebymon where gu_id=(select id from users where username='".$studentname."' and academicyear=20)");
		//echo $this->db->last_query(); exit;
			return $query->result_array();
		 } 
		 
		 public function getmnthwisebspi_topscore($schoolid,$gradeid,$section)
		 {
			 
		$query = $this->db->query("SELECT MAX(finalscore) as finalscore,monthNumber,monthName,yearName from vii_avguserbspiscorebymon where sid='".$schoolid."' and grade_id='".$gradeid."' and section='".$section."' group by monthNumber");
		//echo $this->db->last_query(); exit;
			return $query->result_array();
		 }
		 
		 public function getmnthwisebspi_topscore_classwise($schoolid,$gradeid,$section)
		 {
			 
		$query = $this->db->query("SELECT MAX(finalscore) as finalscore,monthNumber,monthName,yearName from vii_avguserbspiscorebymon where sid='".$schoolid."' and grade_id='".$gradeid."' and section='".$section."' group by monthNumber");
		//echo $this->db->last_query(); exit;
			return $query->result_array();
		 }
		 
		 public function getSkillsRandom($catid)
		 {
			 
		$query = $this->db->query("SELECT a.id AS category_id, b.id AS skill_id FROM g_category AS a JOIN category_skills AS b ON a.id = b.category_id WHERE a.id = '".$catid."'");
		//echo $this->db->last_query(); exit;
			return $query->result_array();
		 }
		 
		 public function getmnthwiseskillscore_M($student,$skillid)
		 {
			 
		$query = $this->db->query("select gs_id,(CASE WHEN gs_id=59 THEN 'MEMORY' WHEN gs_id=60 THEN 'VP' WHEN gs_id=61 THEN 'FA' WHEN gs_id=62 THEN 'PS' WHEN gs_id=63 THEN 'LI' else 0 END) as skillname,monthNumber,monthName,yearName,AVG(gamescore) as gamescore from (SELECT (AVG(game_score)) as gamescore ,gs_id , lastupdate,gu_id,DATE_FORMAT(lastupdate,'%m') as monthNumber,DATE_FORMAT(lastupdate, '%M') as monthName,DATE_FORMAT(lastupdate, '%Y') as yearName FROM game_reports WHERE gs_id='".$skillid."' and gu_id=(select id from users where username='".$student."' and status=1 ) and lastupdate between '".$this->session->school_startdate."' and '".date('Y-m-d')."' group by gs_id,lastupdate) a1 group by gs_id,monthNumber order by gs_id, lastupdate");
		//echo $this->db->last_query(); exit;
			return $query->result_array();
		 }
		 
		 public function getmnthwiseskillscore_M_classwise($gradeid,$section,$skillid)
		 {
			
			
		$query = $this->db->query("select gs_id,(CASE WHEN gs_id=59 THEN 'MEMORY' WHEN gs_id=60 THEN 'VP' WHEN gs_id=61 THEN 'FA' WHEN gs_id=62 THEN 'PS' WHEN gs_id=63 THEN 'LI' else 0 END) as skillname,monthNumber,monthName,yearName,AVG(gamescore) as gamescore from (SELECT (AVG(game_score)) as gamescore ,gs_id , lastupdate,gu_id,DATE_FORMAT(lastupdate,'%m') as monthNumber,DATE_FORMAT(lastupdate, '%M') as monthName,DATE_FORMAT(lastupdate, '%Y') as yearName FROM game_reports WHERE gs_id='".$skillid."' and gu_id in (select id from users where  grade_id='".$gradeid."' and section='".$section."' and status=1 and visible=1 and sid='".$this->session->schoolid."' ) and lastupdate between '".$this->session->school_startdate."' and '".date('Y-m-d')."' group by gs_id,lastupdate,gu_id) a1 group by gs_id,monthNumber order by gs_id, lastupdate");
		//echo $this->db->last_query(); exit;
			return $query->result_array();
		 }
		 
		 public function getasapscore_M($student,$skillid)
		 {
			 
		$query = $this->multipledb->db->query("select game_score,gs_id from game_reports where gs_id='".$skillid."' and gu_id=(select id from users where username='".$student."' and status=1 ) order by gs_id limit 1");
		//echo $this->multipledb->db->last_query(); exit;
			return $query->result_array();
		 }
		 
		 public function getasapscore_M_classwise($gradeid,$section,$skillid)
		 {
			 
			 $query = $this->multipledb->db->query("select round(avg(gs.game_score),2) as game_score,gs.gs_id from game_reports gs join users u on u.id=gs.gu_id where gs.gs_id='".$skillid."' and u.grade_id='".$gradeid."' and u.section='".$section."' and u.status=1 ");
			 
		//$query = $this->multipledb->db->query("select game_score,gs_id from game_reports where gs_id='".$skillid."' and gu_id in (select id from users where  grade_id='".$gradeid."' and section='".$section."' and status=1 ) order by gs_id limit 1");
		//echo $this->multipledb->db->last_query(); exit;
			return $query->result_array();
		 }
		 
		 /* public function getstudentname($schoolid,$gradeid,$section,$name)
		 {
			 
		$query = $this->db->query("select id,username,fname from users where grade_id='".$gradeid."' and section='".$section."' and sid='".$schoolid."' and fname LIKE '%".$name."%'");
	//	echo $this->db->last_query(); exit;
			return $query->result_array();
		 } */
		 
		 public function getstudentname($schoolid,$gradeid,$section)
		 {
			 
		$query = $this->db->query("select id,username,fname from users where grade_id='".$gradeid."' and section='".$section."' and sid='".$schoolid."' and status=1 and visible=1 order by fname ASC");
	//	echo $this->db->last_query(); exit;
			return $query->result_array();
		 }
		 
		 public function getBSPI_classwisebspi($gradeid,$section)
		 {
			 
		$query = $this->db->query("SELECT AVG(`finalscore`) as bspi FROM `vii_avguserbspiscore` WHERE `sid` = '".$this->session->schoolid."' AND `grade_id` = '".$gradeid."' AND `section` = '".$section."'");
		//echo $this->db->last_query(); exit;
			return $query->result_array();
		 }
		 
		 public function getasapbspi_classwisebspi($schoolid,$gradeid,$section)
		 {
			 
		$query = $this->db->query("select avg(avgscore) as avgscore, gs_id,lastupdate,gu_id,section,gradeid  from (select avg(avgscore) as avgscore, gs_id,lastupdate,gu_id,section,gradeid  from ( select sum(avgscore)/5 as avgscore, gs_id,lastupdate,gu_id,section,gradeid  from (select avg(avgscore) as avgscore, gs_id,lastupdate,gu_id,section,gradeid from  (SELECT (AVG(`game_score`)) as avgscore,gs_id , lastupdate,gu_id,(select section from users where users.id=gu_id) as section ,(select grade_id from users where users.id=gu_id) as gradeid  FROM `game_reports` WHERE gu_id in (select users.id as user_id from users where sid=".$schoolid." and status=1  and grade_id = '".$gradeid."' and section='".$section."'  ) and gs_id in (59,60,61,62,63) group by gs_id, gu_id , lastupdate) as a1 group by gu_id,gs_id) as a2 group by gu_id) as a3 group by section,gradeid) as a4");
	//	echo $this->db->last_query(); exit;
			return $query->result_array();
		 }
		 
		/** PROGRESS REPORT **/
		
		
		/** NON SCHEDULE  REPORT **/
		
		public function schoolsession_nonschedule($schoolid,$curdate)
		 {
			 
		$query = $this->db->query("select sid as school_id,(select classname from class where id=s1.grade_id) as gradename,grade_id,section,(select count(id) from users where sid=s1.sid and grade_id=s1.grade_id and section=s1.section and status=1 and visible=1) as regusers,count(s1.id) as loggedinuser,login_date,(select count(distinct(gu_id)) from game_reports gr join users as u on u.id=gr.gu_id where u.sid=s1.sid and u.status=s1.status and u.visible=s1.visible and u.grade_id=s1.grade_id and section=s1.section and date(lastupdate) ='".$curdate."' and gs_id in(59,60,61,62,63) and gu_id!=0) as attendusers from users s1 join schools s ON s1.sid=s.id  where 
		concat(sid,'.',grade_id,'.',section) not in (select  concat(school_id,'.',gradeid,'.', section) as sgs from (SELECT school_id,  (select id from class where REPLACE(classname,'Grade ','')  = grade) as gradeid, section from (SELECT  school_id,  (CASE WHEN dayname('".$curdate."') = 'Monday' THEN monday_grade    WHEN dayname('".$curdate."') = 'Tuesday' THEN `tuesday_grade`  WHEN dayname('".$curdate."') = 'Wednesday' THEN `wednesday_grade` WHEN dayname('".$curdate."') = 'Thursday' THEN `thursday_grade` WHEN dayname('".$curdate."') = 'Friday' THEN friday_grade WHEN dayname('".$curdate."') = 'Saturday' THEN saturday_grade END ) as grade, (CASE WHEN dayname('".$curdate."') = 'Monday' THEN monday_section  WHEN dayname('".$curdate."') = 'Tuesday' THEN `tuesday_section` WHEN dayname('".$curdate."') = 'Wednesday' THEN `wednesday_section`  WHEN dayname('".$curdate."') = 'Thursday' THEN `thursday_section` WHEN dayname('".$curdate."') = 'Friday' THEN friday_section WHEN dayname('".$curdate."') = 'Saturday' THEN saturday_section END) as section from schools_period_schedule sp WHERE   status = 'Y' and `academic_id` = 20 and `school_id` = '".$schoolid."') a1 where grade!='' order by  school_id) a2 )and 
		date(login_date)='".$curdate."' and s1.status=1 and s1.visible=1 and s1.sid='".$schoolid."' and s.status=1 and s.visible=1 and s.active=1 and academicyear=20 group by sid,grade_id,section order by sid,grade_id,section");
//		echo $this->db->last_query(); exit;
			return $query->result_array();
		 }
		 
		 
		 public function training_completedusers_nonschedule($schoolid,$curdate)
		 {
			 
		$query = $this->db->query("select count(set1) as cuser,sid, grade_id, section from (select count(gu_id) as set1,gu_id,sid,section,grade_id from (SELECT gu_id,gs_id,u.sid,u.section,u.grade_id  FROM game_reports as gr 
		join users as u on u.id=gr.gu_id 
		where  gr.gu_id!=0 and u.status=1 and u.visible=1 and date(lastupdate) =  '".$curdate."'  group by gu_id,gs_id) a1 where gs_id in(59,60,61,62,63)  group by gu_id, sid, grade_id, section)a3 where set1>=5 and sid='".$schoolid."' group by sid, grade_id, section order by sid,grade_id");
	//	echo $this->db->last_query(); exit;
			return $query->result_array();
		 }
		 
		 public function ns_loguserslist($schoolid,$gradeid,$section,$date,$type)
		 {
			 
			 if($type=='logusers') {
		$query = $this->db->query("select sid as school_id,concat(s1.fname,' ',s1.lname) as name,s1.id,(select classname from class where id=s1.grade_id) as gradename,grade_id,section,login_date

		 from users s1 join schools s ON s1.sid=s.id where concat(sid,'.',grade_id,'.',section) not in (select concat(school_id,'.',gradeid,'.', section) as sgs from 
		 
		 (SELECT school_id, (select id from class where REPLACE(classname,'Grade ','') = grade) as gradeid, section from (SELECT school_id, (CASE WHEN dayname('".$date."') = 'Monday' THEN monday_grade WHEN dayname('".$date."') = 'Tuesday' THEN `tuesday_grade` WHEN dayname('".$date."') = 'Wednesday' THEN `wednesday_grade` WHEN dayname('".$date."') = 'Thursday' THEN `thursday_grade` WHEN dayname('".$date."') = 'Friday' THEN friday_grade WHEN dayname('".$date."') = 'Saturday' THEN saturday_grade END ) as grade, (CASE WHEN dayname('".$date."') = 'Monday' THEN monday_section WHEN dayname('".$date."') = 'Tuesday' THEN `tuesday_section` WHEN dayname('".$date."') = 'Wednesday' THEN `wednesday_section` WHEN dayname('".$date."') = 'Thursday' THEN `thursday_section` WHEN dayname('".$date."') = 'Friday' THEN friday_section WHEN dayname('".$date."') = 'Saturday' THEN saturday_section END) as section from schools_period_schedule sp WHERE status = 'Y' and `academic_id` = 20 and `school_id` = '".$schoolid."') a1 where grade!='' order by school_id) a2
		 )and date(login_date)='".$date."' and s1.grade_id='".$gradeid."' and s1.section='".$section."' and s1.status=1 and s1.visible=1 and s1.sid='".$schoolid."' and s.status=1 and s.visible=1 and s.active=1 and academicyear=20  order by name");
			 }
			 
			else { 
		$query = $this->db->query("select distinct(uid) as userid,name,grade_id,gradename,section, login_date from 
		(select sid as school_id,concat(s1.fname,' ',s1.lname) as name,s1.id as uid,(select classname from class where id=s1.grade_id) as gradename,grade_id,section,login_date 

		from users s1 join schools s ON s1.sid=s.id where concat(sid,'.',grade_id,'.',section) not in (select concat(school_id,'.',gradeid,'.', section) as sgs from 

		(SELECT school_id, (select id from class where REPLACE(classname,'Grade ','') = grade) as gradeid, section from (SELECT school_id, (CASE WHEN dayname('".$date."') = 'Monday' THEN monday_grade WHEN dayname('".$date."') = 'Tuesday' THEN `tuesday_grade` WHEN dayname('".$date."') = 'Wednesday' THEN `wednesday_grade` WHEN dayname('".$date."') = 'Thursday' THEN `thursday_grade` WHEN dayname('".$date."') = 'Friday' THEN friday_grade WHEN dayname('".$date."') = 'Saturday' THEN saturday_grade END ) as grade, (CASE WHEN dayname('".$date."') = 'Monday' THEN monday_section WHEN dayname('".$date."') = 'Tuesday' THEN `tuesday_section` WHEN dayname('".$date."') = 'Wednesday' THEN `wednesday_section` WHEN dayname('".$date."') = 'Thursday' THEN `thursday_section` WHEN dayname('".$date."') = 'Friday' THEN friday_section WHEN dayname('".$date."') = 'Saturday' THEN saturday_section END) as section from schools_period_schedule sp WHERE status = 'Y' and `academic_id` = 20 and `school_id` = '".$schoolid."') a1 where grade!='' order by school_id) a2 )and date(login_date)='".$date."' and s1.grade_id='".$gradeid."' and s1.section='".$section."' and s1.status=1 and s1.visible=1 and s1.sid='".$schoolid."' and s.status=1 and s.visible=1 and s.active=1 and academicyear=20 order by s.id) q JOIN game_reports grt ON q.uid=grt.gu_id where lastupdate='".$date."' order by name");
			 }
		//echo $this->db->last_query(); exit;
			return $query->result_array();
		 }
		 
		 /*  public function cuser_nonschedule($schoolid,$gradeid,$section,$date)
		 {
			 
		$query = $this->db->query("select distinct(uid) as userid,name,grade_id,gradename,section, login_date,school_id from 
		(select sid as school_id,concat(s1.fname,' ',s1.lname) as name,s1.id as uid,(select classname from class where id=s1.grade_id) as gradename,grade_id,section,login_date 

		from users s1 join schools s ON s1.sid=s.id where concat(sid,'.',grade_id,'.',section) not in (select concat(school_id,'.',gradeid,'.', section) as sgs from 

		(SELECT school_id, (select id from class where REPLACE(classname,'Grade ','') = grade) as gradeid, section from (SELECT school_id, (CASE WHEN dayname('".$date."') = 'Monday' THEN monday_grade WHEN dayname('".$date."') = 'Tuesday' THEN `tuesday_grade` WHEN dayname('".$date."') = 'Wednesday' THEN `wednesday_grade` WHEN dayname('".$date."') = 'Thursday' THEN `thursday_grade` WHEN dayname('".$date."') = 'Friday' THEN friday_grade WHEN dayname('".$date."') = 'Saturday' THEN saturday_grade END ) as grade, (CASE WHEN dayname('".$date."') = 'Monday' THEN monday_section WHEN dayname('".$date."') = 'Tuesday' THEN `tuesday_section` WHEN dayname('".$date."') = 'Wednesday' THEN `wednesday_section` WHEN dayname('".$date."') = 'Thursday' THEN `thursday_section` WHEN dayname('".$date."') = 'Friday' THEN friday_section WHEN dayname('".$date."') = 'Saturday' THEN saturday_section END) as section from schools_period_schedule sp WHERE status = 'Y' and `academic_id` = 20 and `school_id` = '".$schoolid."') a1 where grade!='' order by school_id) a2 )and date(login_date)='".$date."' and s1.grade_id='".$gradeid."' and s1.section='".$section."' and s1.status=1 and s1.visible=1 and s1.sid='".$schoolid."' and s.status=1 and s.visible=1 and s.active=1 and academicyear=20 order by s.id) q JOIN game_reports grt ON q.uid=grt.gu_id where lastupdate='".$date."'");
		//echo $this->db->last_query(); exit;
			return $query->result_array();
		 } */
		 
		 
		 
		  public function completeduserslist_nonschedule($schoolid,$date,$gradeid,$section)
		 {
			 
		$query = $this->db->query("select gu_id,concat(fname,' ',lname) as name,sid,(select classname from class where id=grade_id) as gradename, grade_id, section from (select count(gu_id) as set1,fname,lname,gu_id,sid,section,grade_id from (SELECT gu_id,gs_id,u.sid,u.section,u.grade_id,u.fname,u.lname  FROM game_reports as gr join users as u on u.id=gr.gu_id 
		where  gr.gu_id!=0 and u.status=1 and u.visible=1 and date(lastupdate) =  '".$date."'  group by gu_id,gs_id) a1 where gs_id in(59,60,61,62,63)  group by gu_id)a3 where set1>=5 and sid='".$schoolid."' and grade_id='".$gradeid."' and section='".$section."' group by gu_id order by name");
		//echo $this->db->last_query(); exit;
			return $query->result_array();
		 }
		 
		
		/** NON SCHEDULE  REPORT **/
		
		
		
		
		
		
		public function monthwiseavgbspi($schoolid,$startdate,$enddate,$grade_id,$section)
		{
			
			if($grade_id!=''){$gwhere="grade_id=".$grade_id;}else{$gwhere="1=1";}
			if($section!=''){$swhere="section='".$section."'";}else{$swhere="1=1";}
			
			$query = $this->db->query("SELECT avg(`finalscore`) as bspi, monthNumber FROM  
 
(select round((sum(vii2.score) / 5),2) AS finalscore,vii2.gu_id AS gu_id,vii2.sid AS sid,vii2.grade_id AS grade_id,vii2.section AS section,(select users.username from users where (users.id = vii2.gu_id)) AS username,vii2.monthNumber AS monthNumber,monthname(str_to_date(vii2.monthNumber,'%m')) AS monthName,vii2.yearName AS yearName from

(select round(avg(score),2) AS score,gu_id AS gu_id,gs_id AS gs_id,sid AS sid,grade_id AS grade_id,section AS section,date_format(lastupdate,'%m') AS monthNumber,date_format(lastupdate,'%Y') AS yearName from

(select max(gr.game_score) AS score,gr.gs_id AS gs_id,gr.gu_id AS gu_id,u.sid AS sid,u.grade_id AS grade_id,u.section AS section,gr.lastupdate AS lastupdate from game_reports gr 
join users u on u.id = gr.gu_id 

where u.status = 1 and u.visible = 1 and u.sid='".$schoolid."' and ".$gwhere." and ".$swhere."  and gr.gs_id in (59,60,61,62,63) and 
gr.lastupdate between '".$startdate."' and '".$enddate."'
group by gr.gs_id,gr.gu_id,gr.lastupdate) as a1
group by gs_id,gu_id,month(lastupdate))vii2 group by vii2.gu_id,vii2.monthNumber) as a3
group by monthNumber");
			//echo $this->db->last_query(); exit;
			return $query->result_array();
		}
		
		public function monthwiseskillscore($schoolid,$skillid,$startdate,$enddate,$grade_id,$section)
		{
			if($skillid=='ALL'){$where="1=1";}else{$where="gs_id=".$skillid;}			
			if($grade_id!=''){$gwhere="grade_id=".$grade_id;}else{$gwhere="1=1";}
			if($section!=''){$swhere="section='".$section."'";}else{$swhere="1=1";}
			
			
			$query = $this->db->query("select round(AVG(score), 2) as skillscore, s.name, s.colorcode,gs_id,monthNumber from

(select round(avg(score),2) AS score,gu_id AS gu_id,gs_id AS gs_id,sid AS sid,grade_id AS grade_id,section AS section,date_format(lastupdate,'%m') AS monthNumber,date_format(lastupdate,'%Y') AS yearName from

(select max(gr.game_score) AS score,gr.gs_id AS gs_id,gr.gu_id AS gu_id,u.sid AS sid,u.grade_id AS grade_id,u.section AS section,gr.lastupdate AS lastupdate from game_reports gr 
join users u on u.id = gr.gu_id
where u.status = 1 and u.visible = 1 and u.sid='".$schoolid."' and ".$gwhere." and ".$swhere." and gr.gs_id in (59,60,61,62,63) and 
gr.lastupdate between '".$startdate."' and '".$enddate."'
group by gr.gs_id,gr.gu_id,gr.lastupdate) a1

group by gs_id,gu_id,month(lastupdate))v join category_skills s ON s.id=v.gs_id where sid='".$schoolid."' and ".$where." group by gs_id, monthNumber order by  monthNumber, gs_id");
			//echo $this->db->last_query(); exit;
			return $query->result_array();
		}
		public function TotalSkilllist($skillid)
		{
			if($skillid=='ALL'){$where="1=1";}else{$where="id=".$skillid;}
			
			$query = $this->db->query("select id,name,colorcode from category_skills where category_id=1 and ".$where." ");			
			return $query->result_array();
		}
		public function getGradeDetails($schoolid)
		{
			$query = $this->db->query("select  DISTINCT sc.class_id as id, c.classname from skl_class_section sc join class c ON sc.class_id = c.id Where sc.school_id = '".$schoolid."'");
			
			return $query->result_array();
		}
		public function getSectionbyGrade($schoolid,$class)
		{
			$query = $this->db->query("SELECT distinct(section) FROM skl_class_section where school_id='$schoolid' and class_id = '$class'");
			return $query->result_array();
		}
		 
		public function OverallBspiTopperbyGradesec($schoolid,$startdate,$enddate,$grade_ids,$filter)
		{ 
			if($filter=='No')
			{
				$query = $this->db->query("select bspi,sid,gu_id,grade_id,section,name,username,
				classname,school_name,section from 
				(select bspi,sid,gu_id,grade_id,
				(select CONCAT(fname,' ',lname) from users where id = gu_id) as name,
				(select username from users where id = gu_id) as username,
				(select classname from class where id = grade_id)as classname,
				(select school_name from schools where id = sid)as school_name,
				section from 
				(select round((sum(vii2.score) / 5),2) AS bspi,vii2.gu_id AS gu_id,vii2.sid AS sid,vii2.grade_id AS grade_id,vii2.section AS section from (select round(avg(score),2) AS score,gu_id AS gu_id,gs_id AS gs_id,sid AS sid,grade_id AS grade_id,section AS section from (select ".$this->config->item('skilllogic')."(gr.game_score) AS score,gr.gs_id AS gs_id,gr.gu_id AS gu_id,u.sid AS sid,u.grade_id AS grade_id,u.section AS section,gr.lastupdate AS lastupdate from game_reports gr join users u on u.id = gr.gu_id where u.status = 1 and u.visible = 1 and u.sid ='".$schoolid."' and gr.gs_id in (59,60,61,62,63) and gr.lastupdate between '".$startdate."' and '".$enddate."' and  u.grade_id IN(".$grade_ids.") group by gr.gs_id,gr.gu_id,gr.lastupdate) a1 group by gs_id,gu_id) vii2 group by vii2.gu_id) as a1 

				where ROUND(a1.bspi,2)in

				(select bspi from (select max(bspi4.finalscore) AS bspi,bspi4.gu_id AS gu_id,bspi4.sid AS sid,bspi4.grade_id AS grade_id,bspi4.section AS section from (select round((sum(vii2.score) / 5),2) AS finalscore,vii2.gu_id AS gu_id,vii2.sid AS sid,vii2.grade_id AS grade_id,vii2.section AS section,  username from (select round(avg(score),2) AS score,gu_id AS gu_id,gs_id AS gs_id,sid AS sid,grade_id AS grade_id,username,section AS section from (select ".$this->config->item('skilllogic')."(gr.game_score) AS score,gr.gs_id AS gs_id,gr.gu_id AS gu_id,u.sid AS sid,u.grade_id AS grade_id,u.section AS section,username,gr.lastupdate AS lastupdate from game_reports gr join users u on u.id = gr.gu_id where u.status = 1 and u.visible = 1 and u.sid ='".$schoolid."' and gr.gs_id in (59,60,61,62,63) and gr.lastupdate between '".$startdate."' and '".$enddate."' and  u.grade_id IN(".$grade_ids.") group by gr.gs_id,gr.gu_id,gr.lastupdate) a1 group by gs_id,gu_id)vii2 group by vii2.gu_id) bspi4  group by bspi4.sid,bspi4.grade_id,bspi4.section) as vv3 where vv3.grade_id=a1.grade_id and vv3.section=a1.section)) as a5 


				group by grade_id,section");
			}
			else
			{
				$query = $this->db->query("select bspi,sid,gu_id,grade_id,section,name,username,
				classname,school_name,section from 
				(select bspi,sid,gu_id,grade_id,
				(select CONCAT(fname,' ',lname) from users where id = gu_id) as name,
				(select username from users where id = gu_id) as username,
				(select classname from class where id = grade_id)as classname,
				(select school_name from schools where id = sid)as school_name,
				section from 
				(select round((sum(vii2.score) / 5),2) AS bspi,vii2.gu_id AS gu_id,vii2.sid AS sid,vii2.grade_id AS grade_id,vii2.section AS section from (select round(avg(score),2) AS score,gu_id AS gu_id,gs_id AS gs_id,sid AS sid,grade_id AS grade_id,section AS section from (select ".$this->config->item('skilllogic')."(gr.game_score) AS score,gr.gs_id AS gs_id,gr.gu_id AS gu_id,u.sid AS sid,u.grade_id AS grade_id,u.section AS section,gr.lastupdate AS lastupdate from game_reports gr join users u on u.id = gr.gu_id where u.status = 1 and u.visible = 1 and u.sid ='".$schoolid."' and gr.gs_id in (59,60,61,62,63) and gr.lastupdate between '".$startdate."' and '".$enddate."' and  u.grade_id IN(".$grade_ids.") group by gr.gs_id,gr.gu_id,gr.lastupdate) a1 group by gs_id,gu_id) vii2 group by vii2.gu_id) as a1 

				where ROUND(a1.bspi,2)in

				(select bspi from (select max(bspi4.finalscore) AS bspi,bspi4.gu_id AS gu_id,bspi4.sid AS sid,bspi4.grade_id AS grade_id,bspi4.section AS section from (select round((sum(vii2.score) / 5),2) AS finalscore,vii2.gu_id AS gu_id,vii2.sid AS sid,vii2.grade_id AS grade_id,vii2.section AS section,  username from (select round(avg(score),2) AS score,gu_id AS gu_id,gs_id AS gs_id,sid AS sid,grade_id AS grade_id,username,section AS section from (select ".$this->config->item('skilllogic')."(gr.game_score) AS score,gr.gs_id AS gs_id,gr.gu_id AS gu_id,u.sid AS sid,u.grade_id AS grade_id,u.section AS section,username,gr.lastupdate AS lastupdate from game_reports gr join users u on u.id = gr.gu_id where u.status = 1 and u.visible = 1 and u.sid ='".$schoolid."' and gr.gs_id in (59,60,61,62,63) and gr.lastupdate between '".$startdate."' and '".$enddate."' and  u.grade_id IN(".$grade_ids.") group by gr.gs_id,gr.gu_id,gr.lastupdate) a1 group by gs_id,gu_id)vii2 group by vii2.gu_id) bspi4  group by bspi4.sid,bspi4.grade_id) as vv3 where vv3.grade_id=a1.grade_id)) as a5 


				group by grade_id");
			}
			//echo "<br/>".$this->db->last_query();
			return $query->result_array();
		}
		
		public function getGradeSection($schoolid,$grade_ids,$filter)
		{
			if($filter=='No')
			{ // Grade and Section Wise
				$groupby="";
			}
			else
			{
				$groupby="group by sc.class_id";
			}
			$query = $this->db->query("select  sc.class_id as id, c.classname,section from skl_class_section sc join class c ON sc.class_id = c.id Where sc.school_id = '".$schoolid."' and sc.class_id in(".$grade_ids.") ".$groupby." order by sc.class_id,section");
			return $query->result_array();
		}
		public function SkillTopperMaxscore($schoolid,$start_date,$enddate,$grade_ids,$filter)
		{
			if($filter=='No')
			{ // Grade and Section Wise
				 $query = $this->db->query("select * from (select grade_id,section,gs_id,MAX(score) as maxscore from
				(select gu_id,grade_id,section,gs_id,username,round(avg(score),2) as score from 				 
				 (select gu_id,gs_id,grade_id,username,section,".$this->config->item('skilllogic1')."(game_score) as score from game_reports as gr join users as u on u.id=gu_id where lastupdate between '".$start_date."' and '".$enddate."' and gs_id IN(59,60,61,62,63) and u.sid='".$schoolid."' and grade_id IN(".$grade_ids.") group by gs_id , gu_id, lastupdate) as a1 group by gu_id,gs_id) as a2 group by grade_id,section,gs_id Order BY maxscore desc) as a3 order by grade_id,section,gs_id");
			}
			else
			{ // Grade Wise only
				$query = $this->db->query("select * from (select grade_id,section,gs_id,MAX(score) as maxscore from
				(select gu_id,grade_id,section,gs_id,username,round(avg(score),2) as score from 				 
				 (select gu_id,gs_id,grade_id,username,section,".$this->config->item('skilllogic1')."(game_score) as score from game_reports as gr join users as u on u.id=gu_id where lastupdate between '".$start_date."' and '".$enddate."' and gs_id IN(59,60,61,62,63) and u.sid='".$schoolid."'  and grade_id IN(".$grade_ids.") group by gs_id , gu_id, lastupdate) as a1 group by gu_id,gs_id) as a2 group by grade_id,gs_id Order BY maxscore desc) as a3 order by grade_id,gs_id");
				 
			}
			//echo "<br/>".$this->db->last_query();exit;
			return $query->result_array();
		}
		
		public function SkillTopperUser($schoolid,$start_date,$enddate,$grade_id,$section,$score,$gs_id,$filter)
		{
			if($filter=='No')
			{ // Grade and Section Wise
				 $query = $this->db->query("select group_concat(name SEPARATOR  ', ') as name,score,group_concat(username)  as username from (select gu_id,grade_id,section,gs_id,username,concat(fname,'',lname) as name,round(avg(score),2) as score from 
				(select gu_id,gs_id,grade_id,username,fname,lname,section,".$this->config->item('skilllogic1')."(game_score) as score from game_reports as gr join users as u on u.id=gu_id where lastupdate between '".$start_date."' and '".$enddate."' and gs_id IN(59,60,61,62,63) and grade_id='".$grade_id."' and section='".$section."' and u.sid='".$schoolid."' group by gs_id , gu_id, lastupdate) as a1 group by gu_id,gs_id) as a2 where grade_id='".$grade_id."' and section='".$section."' and score IN('".$score."')  and gs_id='".$gs_id."' ");	
			}
			else
			{
				$query = $this->db->query("select group_concat(name SEPARATOR  ', ') as name,score,group_concat(username)  as username from (select gu_id,grade_id,section,gs_id,username,concat(fname,'',lname) as name,round(avg(score),2) as score from 
				(select gu_id,gs_id,grade_id,username,fname,lname,section,".$this->config->item('skilllogic1')."(game_score) as score from game_reports as gr join users as u on u.id=gu_id where lastupdate between '".$start_date."' and '".$enddate."' and gs_id IN(59,60,61,62,63) and grade_id='".$grade_id."'  and u.sid='".$schoolid."' group by gs_id , gu_id, lastupdate) as a1 group by gu_id,gs_id) as a2 where grade_id='".$grade_id."' and score IN('".$score."')  and gs_id='".$gs_id."' ");
			}
			// echo "<br/>".$this->db->last_query();exit;
			return $query->result_array();
		}
		
		public function CrownyTopperMaxscore($schoolid,$start_date,$enddate,$grade_ids,$filter)
		{
			if($filter=='No')
			{ // Grade and Section Wise
				 $query = $this->db->query("select MAX(points) as points,userid,grade_id,section from (select u.id as userid,grade_id,sum(a2.Points) AS points,u.section from user_sparkies_history a2 
				 join users u on u.id = a2.U_ID where u.status = 1 and u.visible = 1 and S_ID=".$schoolid." and G_ID IN (".$grade_ids.") and date_format(a2.Datetime,'%Y-%m-%d') between '".$start_date."' and '".$enddate."' group by a2.U_ID) as a1 group by grade_id,section ");
			}
			else
			{ // Grade Wise only
				 $query = $this->db->query("select MAX(points) as points,userid,grade_id,section from (select u.id as userid,grade_id,sum(a2.Points) AS points,u.section from user_sparkies_history a2 
				 join users u on u.id = a2.U_ID where u.status = 1 and u.visible = 1 and S_ID=".$schoolid." and G_ID IN (".$grade_ids.") and date_format(a2.Datetime,'%Y-%m-%d') between '".$start_date."' and '".$enddate."' group by a2.U_ID) as a1 group by grade_id ");
			}
			//echo "<br/>".$this->db->last_query();exit;
			return $query->result_array();
		}
		
		public function CrownyTopperUser($schoolid,$start_date,$enddate,$grade_id,$filter)
		{
			if($filter=='No')
			{ // Grade and Section Wise
				 $query = $this->db->query("select group_concat(name SEPARATOR  ', ') as name,group_concat(username SEPARATOR  ', ') as username,MAX(points) as points,userid,grade_id,section,grade_name from (select u.id as userid,concat(fname,'',lname) as name,username as username,grade_id,(select classname from class where id=grade_id) as grade_name, sum(a2.Points) AS points,u.section from user_sparkies_history a2 
				 join users u on u.id = a2.U_ID where u.status = 1 and u.visible = 1 and S_ID=".$schoolid." and G_ID IN (".$grade_id.") and date_format(a2.Datetime,'%Y-%m-%d') between '".$start_date."' and '".$enddate."' group by a2.U_ID) as a1 where points IN(
				 
				 select MAX(points) as points from (select u.id as userid,grade_id,sum(a2.Points) AS points,u.section from user_sparkies_history a2 
				 join users u on u.id = a2.U_ID where u.status = 1 and u.visible = 1 and S_ID=".$schoolid." and G_ID IN (".$grade_id.") and date_format(a2.Datetime,'%Y-%m-%d') between '".$start_date."' and '".$enddate."' group by a2.U_ID) as a1 group by grade_id,section
				 
				 )  group by grade_id,section ");	
			}
			else
			{
				$query = $this->db->query("select group_concat(name SEPARATOR  ', ') as name,group_concat(username SEPARATOR  ', ') as username,MAX(points) as points,userid,grade_id,section,grade_name from (select u.id as userid,concat(fname,'',lname) as name,username as username,grade_id,(select classname from class where id=grade_id) as grade_name, sum(a2.Points) AS points,u.section from user_sparkies_history a2 join users u on u.id = a2.U_ID where u.status = 1 and u.visible = 1 and S_ID=".$schoolid." and G_ID IN (".$grade_id.") and date_format(a2.Datetime,'%Y-%m-%d') between '".$start_date."' and '".$enddate."' group by a2.U_ID) as a1 where points IN(
				
				select MAX(points) as points from (select u.id as userid,grade_id,sum(a2.Points) AS points,u.section from user_sparkies_history a2 
				 join users u on u.id = a2.U_ID where u.status = 1 and u.visible = 1 and S_ID=".$schoolid." and G_ID IN (".$grade_id.") and date_format(a2.Datetime,'%Y-%m-%d') between '".$start_date."' and '".$enddate."' group by a2.U_ID) as a1 group by grade_id
				
				)  group by grade_id");
			}
			//echo "<br/>".$this->db->last_query();exit;
			return $query->result_array();
		} 
		public function SchoolAvgBspi($school_id,$startdate,$enddate)
		{
			$query = $this->db->query("SELECT round(AVG(`finalscore`), 2) as bspi  FROM
			(select round((sum(score) / 5),2) AS finalscore,gu_id AS gu_id,sid AS sid,grade_id AS grade_id,section AS section,(select users.username from users where (users.id = gu_id)) AS username,month(lastupdate) AS monthNumber,date_format(lastupdate,'%b') AS monthName from 
			(select avg(score) AS score,gu_id AS gu_id,gs_id AS gs_id,sid AS sid,grade_id AS grade_id,section AS section,lastupdate AS lastupdate from 
			(select ".$this->config->item('skilllogic')."(gr.game_score) AS score,gr.gs_id AS gs_id,gr.gu_id AS gu_id,u.sid AS sid,u.grade_id AS grade_id,u.section AS section,gr.lastupdate AS lastupdate from game_reports gr
			join users u on u.id = gr.gu_id where u.status = 1 and u.visible = 1 and u.sid=".$school_id." and gr.gs_id in (59,60,61,62,63) and gr.lastupdate between '".$startdate."' and '".$enddate."'
			group by gr.gs_id,gr.gu_id,gr.lastupdate) as a1
			group by gs_id,gu_id) as a2
			group by gu_id) as a3 ");
			//echo "<br/>".$this->db->last_query();exit;
			return $query->result_array();
		}
		
		public function MaxSkillScore_Overall($schoolid,$startdate,$enddate,$grade_id,$section)
		{
			if($grade_id!=''){$gwhere="grade_id=".$grade_id;}else{$gwhere="1=1";}
			if($section!=''){$swhere="section='".$section."'";}else{$swhere="1=1";}
			
			$query = $this->db->query(" select max(finalscore) as skillscore,  gs_id from (select round((AVG(score)), 2) as finalscore, gu_id, gs_id from (SELECT (".$this->config->item('skilllogic1')."(`game_score`)) as  score , gs_id , gu_id, lastupdate FROM `game_reports` join users u ON u.id=gu_id  WHERE gs_id IN (59,60,61,62,63) and lastupdate between '".$startdate."' and '".$enddate."' and u.status=1 and u.visible=1 and u.sid='".$schoolid."' and ".$gwhere." and ".$swhere." group by gs_id , gu_id, lastupdate) a1 group by gs_id, gu_id order by gs_id, finalscore DESC) x1 group by gs_id");
			//echo "<br/>".$this->db->last_query();exit;
			return $query->result_array();
		 
		}
		public function MaxSkillScoreUser_Overall($schoolid,$startdate,$enddate,$skillscore,$gs_id,$grade_id,$section)
		{
			if($grade_id!=''){$gwhere="grade_id=".$grade_id;}else{$gwhere="1=1";}
			if($section!=''){$swhere="section='".$section."'";}else{$swhere="1=1";}
			
			$query = $this->db->query("select * from (select round((AVG(score)), 2) as finalscore, gu_id, gs_id,(select name from category_skills where id=gs_id) as skillname,name,username,gradeid,(select classname from class where id=gradeid) as gradename,section from (SELECT (".$this->config->item('skilllogic1')."(`game_score`)) as  score , gs_id , gu_id, CONCAT(u.fname,'',u.lname) as name, u.username, u.grade_id as gradeid, u.section,  lastupdate FROM `game_reports` gr join users u ON u.id=gu_id WHERE gs_id IN (59,60,61,62,63) and lastupdate between '".$startdate."' and '".$enddate."' and u.status=1 and u.visible=1 and u.sid='".$schoolid."'  and ".$gwhere." and ".$swhere." group by gs_id , gu_id, lastupdate) a1 group by gs_id, gu_id order by gs_id, finalscore DESC)z1 where finalscore IN('".$skillscore."') and gs_id='".$gs_id."'");
			
			return $query->result_array();
		 
		}
		
		public function MaxBspiScore_Overall($schoolid,$startdate,$enddate,$grade_id,$section)
		{
			if($grade_id!=''){$gwhere="grade_id=".$grade_id;}else{$gwhere="1=1";}
			if($section!=''){$swhere="section='".$section."'";}else{$swhere="1=1";}
			
			$query = $this->db->query("select name, section, max(finalscore) as bspiscore, grade_id, (select classname from class where id=grade_id) as gradename,username from (SELECT round(SUM(score)/5, 2) as finalscore,count(gu_id) as playedcount, gu_id, username,fname as name, grade_id,section from (select (AVG(score)) as score, gu_id, gs_id,username,fname, grade_id,section from (SELECT (".$this->config->item('skilllogic')."(`game_score`)) as score , gs_id , gu_id,u.username,u.fname, u.grade_id,u.section, lastupdate FROM `game_reports` gr join users u on u.id=gr.gu_id WHERE gs_id in (59,60,61,62,63) and lastupdate between '".$startdate."' and '".$enddate."' and u.status=1 and u.visible=1 and u.sid='".$schoolid."'  and ".$gwhere." and ".$swhere."    group by gs_id , gu_id, lastupdate) a1 group by gs_id, gu_id ) a2 group by gu_id order by finalscore desc)z1 group by grade_id");
			
			//echo "<br/>".$this->db->last_query();exit;
			
			return $query->result_array();
		 
		}
		public function MaxBspiScoreUser_Overall($schoolid,$startdate,$enddate,$grade_id,$section)
		{
			if($grade_id!=''){$gwhere="grade_id=".$grade_id;}else{$gwhere="1=1";}
			if($section!=''){$swhere="section='".$section."'";}else{$swhere="1=1";}
			
			$query = $this->db->query("Select finalscore,playedcount,username,name,(select classname from class where id=grade_id) as gradename,section from(SELECT round(SUM(score)/5, 2) as finalscore,count(gu_id) as playedcount, gu_id, username,fname as name, grade_id,section from (select (AVG(score)) as score, gu_id, gs_id,username,fname, grade_id,section from (SELECT (".$this->config->item('skilllogic')."(`game_score`)) as score , gs_id , gu_id,u.username,u.fname, u.grade_id,u.section, lastupdate FROM `game_reports` gr join users u on u.id=gr.gu_id WHERE gs_id in (59,60,61,62,63) and lastupdate between '".$startdate."' and '".$enddate."' and u.status=1 and u.visible=1 and u.sid='".$schoolid."'  and ".$gwhere." and ".$swhere."   group by gs_id , gu_id, lastupdate) a1 group by gs_id, gu_id ) a2 group by gu_id order by finalscore desc)a1 where finalscore IN (
			
			select max(finalscore) as bspiscore from (SELECT round(SUM(score)/5, 2) as finalscore,count(gu_id) as playedcount, gu_id, username,fname as name, grade_id,section from (select (AVG(score)) as score, gu_id, gs_id,username,fname, grade_id,section from (SELECT (".$this->config->item('skilllogic')."(`game_score`)) as score , gs_id , gu_id,u.username,u.fname, u.grade_id,u.section, lastupdate FROM `game_reports` gr join users u on u.id=gr.gu_id WHERE gs_id in (59,60,61,62,63) and lastupdate between '".$startdate."' and '".$enddate."' and u.status=1 and u.visible=1 and u.sid='".$schoolid."'  and ".$gwhere." and ".$swhere."    group by gs_id , gu_id, lastupdate) a1 group by gs_id, gu_id ) a2 group by gu_id order by finalscore desc)z1 group by grade_id)
			group by grade_id");
			//echo "<br/>".$this->db->last_query();exit;
			return $query->result_array();
		 
		}
		
		public function MaxCrownyUser_Overall($schoolid,$startdate,$enddate,$grade_id,$section)
		{
			if($grade_id!=''){$gwhere="grade_id=".$grade_id;}else{$gwhere="1=1";}
			if($section!=''){$swhere="section='".$section."'";}else{$swhere="1=1";}
			
			$query = $this->db->query("select group_concat(name SEPARATOR  ', ') as name,MAX(points) as points,userid,grade_id,section,classname,username from (select u.id as userid,concat(fname,'',lname) as name,username as username,grade_id,(select classname from class where id=grade_id) as classname, sum(a2.Points) AS points,u.section from user_sparkies_history a2 
				 join users u on u.id = a2.U_ID where u.status = 1 and u.visible = 1 and S_ID=".$schoolid."  and ".$gwhere." and ".$swhere."  and date_format(a2.Datetime,'%Y-%m-%d') between '".$start_date."' and '".$enddate."' group by a2.U_ID) as a1 where points IN(
				 
				 select MAX(points) as points from (select u.id as userid,grade_id,sum(a2.Points) AS points,u.section from user_sparkies_history a2 
				 join users u on u.id = a2.U_ID where u.status = 1 and u.visible = 1 and S_ID=".$schoolid."  and ".$gwhere." and ".$swhere."  and date_format(a2.Datetime,'%Y-%m-%d') between '".$start_date."' and '".$enddate."' group by a2.U_ID) as a1 
				 ) ");
				 
			//echo "<br/>".$this->db->last_query();
			return $query->result_array();
		}
		
		public function GradeSecwiseUsersCount($schoolid,$grade_id,$section)
        {
			if($section!=''){$swhere="section='".$section."'";}else{$swhere="1=1";}
			
			$query = $this->db->query("select sum(registereduser) as total,registereduser,gradename,grade_id,section from (select count(id) as registereduser, (select classname from class where id=grade_id) as gradename, grade_id,section from users where sid='".$schoolid."' and grade_id='".$grade_id."' and ".$swhere." and  status=1 and visible=1 group by grade_id,section) x1 group by grade_id,section");
			return $query->result_array();
		}
		
/*
Student Report Start
*/	
		public function studentDetails($schoolid,$username)
		{
			$query = $this->db->query("select id,concat(fname,'',lname) as name,username,grade_id,gp_id,section,section,(select classname from class where id=grade_id) as classname from users where username='".$username."' and status=1 and visible=1 and sid='".$schoolid."' "); 
			return $query->result_array();
		}
		public function studentRank($schoolid,$startdate,$enddate,$userid,$grade_id,$section)
		{
			$query=$this->db->query("select rowNumber as rank  from(select rowNumber,id, name,lname,avatarimage,bspi from (select  (@cnt := @cnt + 1) AS rowNumber,id, fname as name,lname,avatarimage, IF(avgbspiset1 IS NULL,0,avgbspiset1) as bspi from (select id as id, fname,lname,avatarimage, grade_id,(select classname from class where id=grade_id) as gradename,a3.finalscore as avgbspiset1 from users mu  left join 
			(SELECT SUM(score)/5 as finalscore, gu_id, (SELECT sid from users where id=gu_id) as schoolid from (select (AVG(score)) as score, gu_id, gs_id from (SELECT (".$this->config->item('skilllogic')."(`game_score`)) as score , gs_id , gu_id, lastupdate FROM game_reports WHERE gs_id in (59,60,61,62,63) and lastupdate between '".$startdate."' and '".$enddate."' and gu_id in (select id from users where sid=".$schoolid." and status=1) group by gs_id , gu_id, lastupdate) a1 group by gs_id, gu_id ) a2 group by gu_id) a3   on a3.gu_id=mu.id where sid=".$schoolid." and  grade_id=".$grade_id." and section='".$section."' and status=1 and visible=1  ORDER BY avgbspiset1 DESC ) as a5 CROSS JOIN (SELECT @cnt := 0) AS dummy) as b1 order by bspi DESC) as c1 where id = ".$userid." ");
			//echo "<br/>".$this->db->last_query();
			return $query->result_array();
		}
		public function studentPlayCount($schoolid,$startdate,$enddate,$userid)
		{
			
			$query=$this->db->query("SELECT SUM(gtime) as gtime_school_count , SUM(answer) as answer_school_count, SUM(attempt_question) as attempted_question_count,(select sum(points) from user_sparkies_history where U_ID=".$userid." and S_ID=".$schoolid." and date(Datetime) between '".$startdate."' and '".$enddate."' ) as TotalCrownyPoints FROM game_reports gr join users u on gr.gu_id=u.id
		WHERE gtime IS NOT NULL AND answer IS NOT NULL and u.id=(select id from users where id='".$userid."')  and lastupdate between '".$startdate."' and '".$enddate."'" );
		//echo "<br/>".$this->db->last_query();
		return $query->result_array();
		
		}
		public function studentAvgBspi($schoolid,$startdate,$enddate,$userid)
		{
			
			$query=$this->db->query("SELECT SUM(score)/5 as avgbspi, gu_id from 
			(select (AVG(score)) as score,gu_id,gs_id from (SELECT (".$this->config->item('skilllogic')."(game_score)) as score , gs_id , gu_id,lastupdate FROM game_reports gr join users u on u.id=gr.gu_id WHERE gs_id in (59,60,61,62,63) and u.status=1 and u.visible=1 and u.sid=".$schoolid." and u.id=".$userid." and lastupdate between '".$startdate."' and '".$enddate."' group by gs_id , gu_id, lastupdate) a1 group by gs_id, gu_id ) a2 group by gu_id" );
		//echo "<br/>".$this->db->last_query();
		return $query->result_array();
		
		}
		
		public function studentAttendedCount($schoolid,$startdate,$enddate,$userid,$grade_id,$section)
		{
			$query=$this->db->query("select sum(totalusers) as totaluser,sum(attenusers) as attenusers,gradename,section from (select selected_date, gradename, gradeid,section,(select count(distinct(u.id)) as regusers from users u  where u.id='".$userid."' and u.status = 1 and u.visible=1 and u.grade_id='".$grade_id."' and section='".$section."') as totalusers,

			(SELECT count(distinct(gu_id)) as com from game_reports as gd 
			join users as u on u.id=gd.gu_id where  u.id='".$userid."' and date(lastupdate) = selected_date and gd.gu_id!=0) as attenusers

			from (select grade_id as gradeid,grade_name as gradename,section,period_day as nameofday,period_date as selected_date from schools_period_schedule_days where sid='".$schoolid."' and academic_id=20 and period_date between '".$startdate."' and '".$enddate."' and period_date >= (select start_date from schools where id='".$schoolid."' and status=1 and active=1 and visible=1) and period_date NOT IN (select leave_date from schools_leave_list where school_id = '".$schoolid."' and status=1))y1)a1 where gradeid='".$grade_id."' and section='".$section."' group by gradeid,section");
		//echo "<br/>".$this->db->last_query();exit;
		return $query->result_array();
		
		}
		public function studentCompletedCount($schoolid,$startdate,$enddate,$userid,$grade_id,$section)
		{
			$query=$this->db->query("select count(*) as completeduser from (select count(*) as cntval,weekval,gradename,gradeid,section,id from ( select selected_date,weekval,a2.gradename,a2.gradeid,a2.section,a2.id,gs_id from (select selected_date,weekval,y1.gradename,y1.gradeid,y1.section,u.id from (select grade_id as gradeid,grade_name as gradename,section,period_day as nameofday,period_date as selected_date,
			CASE WHEN MONTH('".$startdate."')=(select MONTH(start_date) from schools where id='".$schoolid."' and status=1 and active=1 and visible=1) THEN (FLOOR((DAYOFMONTH(period_date) - DAYOFMONTH((select start_date from schools where id='".$schoolid."' and status=1 and active=1 and visible=1))) / 7) + 1) ELSE (FLOOR((DAYOFMONTH(period_date) - 1) / 7) + 1) END as weekval
					from schools_period_schedule_days where sid='".$schoolid."' and academic_id=20 and period_date between '".$startdate."' and '".$enddate."' and period_date >= (select start_date from schools where id='".$schoolid."' and status=1 and active=1 and visible=1) and period_date NOT IN (select leave_date from schools_leave_list where school_id = '".$schoolid."' and status=1)
			) y1 join users as u on u.grade_id=y1.gradeid and u.section=y1.section and u.sid='".$schoolid."' and u.status = 1 and u.visible=1 and u.id='".$userid."' group by y1.gradeid,y1.section,selected_date,u.id order by selected_date) a2 join game_reports as gd on gd.gu_id=a2.id and date(gd.lastupdate) = a2.selected_date group by a2.gradeid,a2.section,selected_date,gs_id,gu_id)Z1 group by selected_date,id)zz1 where cntval>=5 and gradeid='".$grade_id."' and section='".$section."' ");
		//echo "<br/>".$this->db->last_query();exit;
		return $query->result_array();
		
		}
		
		/* public function studentSBB($schoolid,$startdate,$enddate,$userid,$grade_id,$section)
		{
			$query=$this->db->query("select bspi,monthName,monthNumber,sid,count(gu_id) as total,grade_id from(select avg(bspi2.score) AS bspi,bspi2.gu_id AS gu_id,date_format(bspi2.lastupdate,'%m') AS monthNumber,date_format(bspi2.lastupdate,'%b') AS monthName,u.sid AS sid,u.grade_id AS grade_id from (vi_1dayuserscore bspi2 join users u on((u.id = bspi2.gu_id))) where (date_format(bspi2.lastupdate,'%Y-%m-%d') between '".$startdate."' and '".$enddate."')   group by bspi2.gu_id,month(bspi2.lastupdate)) as a1 where a1.grade_id='".$grade_id."' and a1.sid=".$schoolid."  and a1.gu_id in(".$userid.") and ROUND(a1.bspi,2)=(select bspi from vi_maxbspibymsg  as vv3 where vv3.monthNumber =a1.monthNumber and  vv3.monthNumber!=".date('m')." and vv3.grade_id='".$grade_id."' and vv3.sid=".$schoolid.")");
			echo "<br/>".$this->db->last_query();exit;
		return $query->result_array();
		}
		public function studentSGB($schoolid,$startdate,$enddate,$userid,$grade_id,$section)
		{
			$query=$this->db->query("select count(gu_id) as total from (select count(gu_id) AS countofplayed,gu_id AS gu_id,date_format(lastupdate,'%b') AS monthName,date_format(lastupdate,'%m') AS monthNumber,(select sid from users where (id = gu_id)) AS gs_ID,(select grade_id from users where (id = gu_id)) AS grad_ID from game_reports where (convert(date_format(lastupdate,'%Y-%m-%d') using latin1) between '".$startdate."' and '".$enddate."' ) group by date_format(lastupdate,'%m'),gu_id) a1 where a1.grad_ID=(select grade_id from users where id=".$userid.") and a1.gs_ID=".$schoolid." and a1.gu_id in(".$userid.") and a1.countofplayed in (select countofval from vi_gameplayed v where v.monthNumber=a1.monthNumber and v.monthNumber!=".date('m')." and  v.school_id=".$schoolid." and v.grad_id=(select grade_id from users where id = ".$userid."))");
		//echo "<br/>".$this->db->last_query();exit;
		return $query->result_array();
		}
		
		public function studentSAB($schoolid,$startdate,$enddate,$userid,$grade_id,$section)
		{
			$query=$this->db->query("select ans,count(gu_id) as total,monthName,monthNumber,grad_ID,gs_ID from (select sum(answer) as ans,game_reports.gu_id AS gu_id,date_format(game_reports.lastupdate,'%b') AS monthName,date_format(game_reports.lastupdate,'%m') AS monthNumber,(select users.sid from users where (users.id = game_reports.gu_id)) AS gs_ID,(select users.grade_id from users where (users.id = game_reports.gu_id)) AS grad_ID from game_reports where (convert(date_format(game_reports.lastupdate,'%Y-%m-%d') using latin1) between '".$startdate."' and '".$enddate."' ) group by date_format(game_reports.lastupdate,'%m'),game_reports.gu_id) a1 where a1.grad_ID=(select grade_id from users where id = ".$userid.") and a1.gs_ID=".$schoolid." and a1.gu_id in(".$userid.") and a1.ans in (select ans from superangel v where v.monthNumber=a1.monthNumber and  v.monthNumber!=".date('m')." and v.gs_ID=".$schoolid." and v.grad_ID=(select grade_id from users where id = ".$userid."))");
		//echo "<br/>".$this->db->last_query();exit;
		return $query->result_array();
		} */
		public function getStudentBadgeCount($sid,$userid,$gradeid)
		{
			$query = $this->db->query("SELECT SUM(CASE WHEN type='SAB' THEN 1 else 0 END ) as sabbadge, SUM(CASE WHEN type='SBB' THEN 1 else 0 END ) as sbbbadge, SUM(CASE WHEN type='SGB' THEN 1 else 0 END ) as sgbbadge from leaderboard where gradeid=".$gradeid." and sid=".$sid." and userid=".$userid." ");
			return $query->result_array();
		}
		public function studentSkillScore($schoolid,$startdate,$enddate,$userid)
		{
			$query=$this->db->query(" SELECT (".$this->config->item('skilllogic')."(game_score)) as score ,gs_id , lastupdate,DATE_FORMAT(lastupdate,'%m') as playedMonth  FROM game_reports WHERE gs_id in (59,60,61,62,63) and gu_id='".$userid."'   and  lastupdate between '".$startdate."' and '".$enddate."'  group by gs_id , lastupdate ");
			//echo "<br/>".$this->db->last_query();exit;
			return $query->result_array();
			
		}
		public function studentPuzzlePlayedDays($schoolid,$startdate,$enddate,$userid)
		{
			$query=$this->db->query(" select DATE_FORMAT(lastupdate,'%m') as monthlist  from game_reports where gu_id='".$userid."' and lastupdate between '".$startdate."' and '".$enddate."' group by DATE_FORMAT(`lastupdate`,'%m'),lastupdate");
			//echo "<br/>".$this->db->last_query();exit;
			return $query->result_array();
		}
		public function studentavgSkillScore($schoolid,$startdate,$enddate,$userid,$skillid)
		{
			if($skillid=='ALL'){$where="1=1";}else{$where="gs_id=".$skillid;}
			
			$query=$this->db->query("select round(AVG(score), 2) as skillscore, s.name, s.colorcode,gs_id from
			(select avg(score) AS score,gu_id AS gu_id,gs_id AS gs_id,sid AS sid,grade_id AS grade_id,section AS section,lastupdate AS lastupdate from
			(select ".$this->config->item('skilllogic1')."(gr.game_score) AS score,gr.gs_id AS gs_id,gr.gu_id AS gu_id,u.sid AS sid,u.grade_id AS grade_id,u.section AS section,gr.lastupdate AS lastupdate from game_reports gr 
			join users u on u.id = gr.gu_id

			where u.status = 1 and u.visible = 1 and u.sid=".$schoolid." and gu_id='".$userid."' and gr.gs_id in (59,60,61,62,63) and 
			gr.lastupdate between '".$startdate."' and '".$enddate."' group by gr.gs_id,gr.gu_id,gr.lastupdate)a1
			 group by gs_id,gu_id) a2 join category_skills s ON s.id=a2.gs_id where gu_id='".$userid."' and ".$where."   group by gs_id" );
			//echo "<br/>".$this->db->last_query();exit;
			return $query->result_array();
		}
		public function studentSkillPlayedDays($schoolid,$startdate,$enddate,$userid,$skillid)
		{
			if($skillid=='ALL'){$where="1=1";}else{$where="gs_id=".$skillid;}
			
			$query=$this->db->query("select sum(inCount) as pcount,`gs_id`, monthlist,name,colorcode from (select count(DISTINCT lastupdate) as inCount, gs_id,monthlist,name,colorcode from (select gs_id,DATE_FORMAT(`lastupdate`,'%m') as monthlist,lastupdate from game_reports where gu_id='".$userid."' and lastupdate between '".$startdate."' and '".$enddate."' and ".$where."  group by lastupdate,gs_id) as a1 join category_skills on category_skills.id=a1.gs_id group by gs_id,monthlist) x1 group by gs_id");
			//echo "<br/>".$this->db->last_query();exit;
			return $query->result_array();
		}
		
		public function studentAttemptedGameCount($schoolid,$startdate,$enddate,$userid)
		{			
			$query=$this->db->query("select count(Completed) as attempt,monthlist,monthname from (select username,gu_id,gs_id,count(gs_id) Completed,DATE_FORMAT(`lastupdate`,'%m') as monthlist,DATE_FORMAT(`lastupdate`,'%b') as monthname from (SELECT count(gr.id) as PalyCount,DATE_FORMAT(`lastupdate`,'%m') as monthlist ,lastupdate,gs_id,gu_id,username from game_reports gr join users u on u.id = gr.gu_id join user_academic_mapping um on u.id=um.id where gu_id='".$userid."' and date(lastupdate) between '".$startdate."' and '".$enddate."' group by date(lastupdate),DATE_FORMAT(`lastupdate`,'%m'),gu_id,gs_id order by date(lastupdate))a2 group by gu_id,lastupdate)a2 group by monthlist");
			//echo "<br/>".$this->db->last_query();exit;
			return $query->result_array();
		}
		public function studentCompletedGameCount($schoolid,$startdate,$enddate,$userid)
		{			
			$query=$this->db->query("select count(Completed) as comp,monthlist,monthname from (select username,gu_id,gs_id,count(gs_id) Completed,DATE_FORMAT(`lastupdate`,'%m') as monthlist,DATE_FORMAT(`lastupdate`,'%b') as monthname from (SELECT count(gr.id) as PalyCount,DATE_FORMAT(`lastupdate`,'%m') as monthlist ,lastupdate,gs_id,gu_id,username from game_reports gr join users u on u.id = gr.gu_id join user_academic_mapping um on u.id=um.id where gu_id='".$userid."' and date(lastupdate) between '".$startdate."' and '".$enddate."' group by date(lastupdate),DATE_FORMAT(`lastupdate`,'%m'),gu_id,gs_id order by date(lastupdate))a2 group by gu_id,lastupdate)a2 where Completed>=5 group by monthlist");
			//echo "<br/>".$this->db->last_query();exit;
			return $query->result_array();
		}
		
		
		public function AsapAvgBspi($schoolid,$startdate,$enddate,$grade_id,$section)
		{
			
			if($grade_id!=''){$gwhere="grade_id=".$grade_id;}else{$gwhere="1=1";}
			if($section!=''){$swhere="section='".$section."'";}else{$swhere="1=1";}
			
			$query = $this->multipledb->db->query("select round(avg(score),2) as ASAPbspi from (select sum(gr.game_score)/5 AS score,gr.gs_id AS gs_id,gr.gu_id AS gu_id,u.sid AS sid,u.grade_id AS grade_id,u.section AS section,gr.lastupdate AS lastupdate from game_reports gr join users u on u.id = gr.gu_id where u.status = 1 and u.sid='".$schoolid."' and ".$gwhere." and ".$swhere."  and gr.gs_id in (59,60,61,62,63) group by  gr.gu_id) as a1 group by sid");
			//echo $this->multipledb->db->last_query();exit;
			return $query->result_array(); 
		}
		public function AsapAvgSkillScore($schoolid,$skillid,$startdate,$enddate,$grade_id,$section)
		{
			if($skillid=='ALL'){$where="gs_id IN(59,60,61,62,63)";}else{$where="gs_id=".$skillid;}			
			if($grade_id!=''){$gwhere="grade_id=".$grade_id;}else{$gwhere="1=1";}
			if($section!=''){$swhere="section='".$section."'";}else{$swhere="1=1";}
			
			$query = $this->multipledb->db->query("select round(AVG(game_score), 2) as skillscore,gs_id,sid from (select round(avg(gs.game_score),2) as game_score,gs.gs_id,sid from game_reports gs join users u on u.id=gs.gu_id where sid='".$schoolid."' and ".$gwhere." and ".$swhere." and u.status=1 and ".$where." group by gu_id) as a1 group by sid"); 
			
			return $query->result_array();
		}
		public function intervetionreport_clp($schoolid,$startdate,$enddate,$grade_id,$section)
		{
			if($grade_id!=''){$gwhere="grade_id=".$grade_id;}else{$gwhere="1=1";}
			if($section!=''){$swhere="section='".$section."'";}else{$swhere="1=1";}
			
			//$query = $this->db->query("select scorerange, count(*) rangecount,schoolid,grade_id,(select classname from class where id=grade_id) as gradename,section from (SELECT SUM(score)/5 as finalscore, case when (SUM(score)/5) <=20 then '<=20' when (SUM(score)/5) >20 and (SUM(score)/5) <=40 then '20-40' when (SUM(score)/5) >40 and (SUM(score)/5) <=60 then '40-60' when (SUM(score)/5) >60 and (SUM(score)/5) <=80 then '60-80' when (SUM(score)/5) >80 then '>80' end as scorerange,count(gu_id) as playedcount, gu_id, username,fname as name, grade_id,section,sid as schoolid from (select (AVG(score)) as score, gu_id,gs_id, sid,fname,lname,username,section,grade_id from (SELECT (".$this->config->item('skilllogic')."(game_score)) as score , gs_id , gu_id,sid,fname,lname,username,section,u.grade_id, lastupdate FROM game_reports gr join users u on u.id=gr.gu_id WHERE gs_id in (59,60,61,62,63) and u.status=1 and u.visible=1 and sid='".$schoolid."' and ".$gwhere." and ".$swhere." and lastupdate between '".$startdate."' and '".$enddate."' group by gs_id,gu_id, lastupdate) a1 group by gs_id, gu_id ) a2 group by gu_id)a1 group by scorerange");
			$query = $this->db->query("select count(lessthantwenty) as '<=20', count(twentytoforty) as '20-40', count(fortytosixty) as '40-60', count(sixtytoeighty) as '60-80', count(greatereithy) as '>80' from
			(SELECT SUM(score)/5 as finalscore,
			case when (SUM(score)/5) <=20 then '<20' END as lessthantwenty,
			case when (SUM(score)/5) >20 and (SUM(score)/5) <=40 then '20-40' end as twentytoforty, 
			case when (SUM(score)/5) >40 and (SUM(score)/5) <=60 then '40-60' END as fortytosixty, 
			case  when (SUM(score)/5) >60 and (SUM(score)/5) <=80 then '60-80' end as sixtytoeighty, 
			case when (SUM(score)/5) >80 then '>80' end as greatereithy ,gu_id,username,fname as name,grade_id,section,sid as schoolid from (select (AVG(score)) as score, gu_id,gs_id, sid,fname,lname,username,section,grade_id from 
			(SELECT (max(game_score)) as score , gs_id , gu_id,sid,fname,lname,username,section,u.grade_id, lastupdate FROM game_reports gr join users u on u.id=gr.gu_id WHERE gs_id in (59,60,61,62,63) and u.status=1 and u.visible=1 and sid='".$schoolid."' and ".$gwhere." and ".$swhere." and lastupdate between '".$startdate."' and '".$enddate."' group by gs_id,gu_id, lastupdate) a1 group by gs_id, gu_id ) a2 group by gu_id)a1");
			 //echo $this->db->last_query(); exit;
			return $query->result_array();
		}
		public function intervetionreport_asap($schoolid,$startdate,$enddate,$grade_id,$section)
		{
			if($grade_id!=''){$gwhere="grade_id=".$grade_id;}else{$gwhere="1=1";}
			if($section!=''){$swhere="section='".$section."'";}else{$swhere="1=1";}
			
			$query = $this->multipledb->db->query("select  count(lessthantwenty) as '<=20', count(twentytoforty) as '20-40', count(fortytosixty) as '40-60', count(sixtytoeighty) as '60-80', count(greatereithy) as '>80' from (SELECT AVG(game_score) as finalscore, case when (AVG(game_score)) <=20 then '<20' END as lessthantwenty,
				case when (AVG(game_score)) >20 and (AVG(game_score)) <=40 then '20-40' end as twentytoforty, 
				case when (AVG(game_score)) >40 and (AVG(game_score)) <=60 then '40-60' END as fortytosixty, 
				case  when (AVG(game_score)) >60 and (AVG(game_score)) <=80 then '60-80' end as sixtytoeighty, 
				case when (AVG(game_score)) >80 then '>80' end as greatereithy from game_reports gd JOIN users u ON gd.gu_id=u.id where gd.lastupdate between (select startdate from academic_year where id=19) and (select enddate from academic_year where id=19) and u.sid='".$schoolid."' and ".$gwhere." and ".$swhere." and u.status=1 and u.academicyear=19 group BY gu_id) x");
			 //echo $this->db->last_query(); exit;
			return $query->result_array();
		}
		public function student_AsapavgSkillScore($schoolid,$userid,$skillid,$username)
		{
			if($skillid=='ALL'){$where="gs_id IN(59,60,61,62,63)";}else{$where="gs_id=".$skillid;}	 
			
			$query = $this->multipledb->db->query("select round(avg(gs.game_score),2) as game_score,gs.gs_id,sid from game_reports gs join users u on u.id=gs.gu_id where sid='".$schoolid."' and u.status=1 and ".$where." and u.username='".$username."' group by gs_id,gu_id");  
			return $query->result_array();
		}
		
		
		public function UserScoreData($sid,$start_date,$userid)
		{	
			$startdate=$start_date;
			$enddate=date("Y-m-d");
			 
			
			$query = $this->db->query('select id,fname,username,gp_id,section,grade_id,(select classname from class where id=grade_id) as classname,
			(SELECT sum(Points) FROM user_sparkies_history WHERE U_ID ="'.$userid.'" and date(Datetime) between "'.$startdate.'" and "'.$enddate.'") as CrownyPoints,
			(SELECT count(gs_id) FROM gamedata WHERE gu_id ="'.$userid.'" and gs_id=59 and lastupdate between "'.$startdate.'" and "'.$enddate.'") as MEnoftimesplayed,
			(SELECT count(gs_id) FROM gamedata WHERE gu_id ="'.$userid.'" and gs_id=60 and lastupdate between "'.$startdate.'" and "'.$enddate.'") as VPnoftimesplayed,
			(SELECT count(gs_id) FROM gamedata WHERE gu_id ="'.$userid.'" and gs_id=61 and lastupdate between "'.$startdate.'" and "'.$enddate.'") as FAnoftimesplayed,
			(SELECT count(gs_id) FROM gamedata WHERE gu_id ="'.$userid.'" and gs_id=62 and lastupdate between "'.$startdate.'" and "'.$enddate.'") as PSnoftimesplayed,
			(SELECT count(gs_id) FROM gamedata WHERE gu_id ="'.$userid.'" and gs_id=63 and lastupdate between "'.$startdate.'" and "'.$enddate.'") as LInoftimesplayed,
			
			(select CONVERT(CONCAT(avg(game_score),",",avg(game_score1)),CHAR(50))  from (select '.$this->config->item('skilllogic').'(game_score)as game_score,'.$this->config->item('skilllogic1').'(game_score)as game_score1,lastupdate,gu_id from game_reports gr join users u on u.id=gr.gu_id  where sid="'.$sid.'" and u.id="'.$userid.'"  and status=1 and visible=1 and academicyear=20 and gs_id=59  and lastupdate between "'.$startdate.'" and "'.$enddate.'"  group by lastupdate,gu_id ) s1  where gu_id=a1.id) as Memory,
			
			(select CONVERT(CONCAT(avg(game_score),",",avg(game_score1)),CHAR(50)) from (select '.$this->config->item('skilllogic').'(game_score)as game_score,'.$this->config->item('skilllogic1').'(game_score)as game_score1,lastupdate,gu_id from game_reports gr join users u on u.id=gr.gu_id where  sid="'.$sid.'"  and u.id="'.$userid.'" and status=1 and visible=1 and academicyear=20 and gs_id=60  and lastupdate between "'.$startdate.'" and "'.$enddate.'"  group by lastupdate,gu_id )s2  where gu_id=a1.id) as VP,
			
			(select CONVERT(CONCAT(avg(game_score),",",avg(game_score1)),CHAR(50)) from (select '.$this->config->item('skilllogic').'(game_score)as game_score,'.$this->config->item('skilllogic1').'(game_score)as game_score1,lastupdate,gu_id from game_reports gr join users u on u.id=gr.gu_id where  sid="'.$sid.'"  and u.id="'.$userid.'"  and status=1 and visible=1 and academicyear=20 and gs_id=61  and lastupdate between "'.$startdate.'" and "'.$enddate.'"  group by lastupdate,gu_id )s3  where gu_id=a1.id) as FA,
			
			(select CONVERT(CONCAT(avg(game_score),",",avg(game_score1)),CHAR(50)) from (select '.$this->config->item('skilllogic').'(game_score)as game_score,'.$this->config->item('skilllogic1').'(game_score)as game_score1,lastupdate,gu_id from game_reports gr join users u on u.id=gr.gu_id where  sid="'.$sid.'"   and u.id="'.$userid.'" and status=1 and visible=1 and academicyear=20 and gs_id=62  and lastupdate between "'.$startdate.'" and "'.$enddate.'"  group by lastupdate,gu_id )s4  where gu_id=a1.id) as PS,
			
			(select CONVERT(CONCAT(avg(game_score),",",avg(game_score1)),CHAR(50)) from (select '.$this->config->item('skilllogic').'(game_score)as game_score,'.$this->config->item('skilllogic1').'(game_score)as game_score1,lastupdate,gu_id from  game_reports gr join users u on u.id=gr.gu_id where  sid="'.$sid.'"  and u.id="'.$userid.'"  and status=1 and visible=1 and academicyear=20 and gs_id=63  and lastupdate between "'.$startdate.'" and "'.$enddate.'"  group by lastupdate,gu_id )s5  where gu_id=a1.id) as LI,
			
			(select score from (select sum(gr.game_score)/5 AS score,gr.gs_id AS gs_id,gr.gu_id AS gu_id,username from schoolsclp_1920_live_1906.game_reports gr join schoolsclp_1920_live_1906.users u on u.id = gr.gu_id where u.status = 1 and u.sid="'.$sid.'"    and gr.gs_id in (59,60,61,62,63) group by  gr.gu_id)s6  where s6.username=a1.username) as asapbspi,
			
			( select sum(attempt_question)as attempt_question from  game_reports where gu_id="'.$userid.'" and lastupdate between "'.$startdate.'" and "'.$enddate.'"   ) as attempt_question,
			
			( select sum(answer)as answer from  game_reports where gu_id="'.$userid.'" and lastupdate between "'.$startdate.'" and "'.$enddate.'")  as answer,
			
			(select sum(rtime)as rtime from  game_reports where gu_id="'.$userid.'" and lastupdate between "'.$startdate.'" and "'.$enddate.'"  ) as rtime,
			
			(select sum(gtime)as gtime from  game_reports where gu_id="'.$userid.'" and lastupdate between "'.$startdate.'" and "'.$enddate.'"  ) as gtime,
			
			(select count(distinct(lastupdate)) from game_reports where gu_id="'.$userid.'" and lastupdate between "'.$startdate.'" and "'.$enddate.'") as AttendedSession,  
			
			(select SUM(CASE WHEN game>=5 THEN 1 ELSE 0 END) as completedsession from (select sum(gamesplayed) as game,gu_id,lastupdate from (select lastupdate,count(DISTINCT gs_id) as gamesplayed,gu_id from  game_reports gr join users u on u.id=gr.gu_id where sid="'.$sid.'" and u.id="'.$userid.'"  and status=1 and visible=1 and academicyear=20 and lastupdate between "'.$startdate.'" and "'.$enddate.'" group by gu_id,gs_id,lastupdate) a1 group by gu_id,lastupdate) s1 where gu_id=a1.id) as CompletedSession,
			
			(select count(id) from  schools_period_schedule_days where grade_id=a1.grade_id and section=a1.section and sid="'.$sid.'" and period_date between "'.$startdate.'" and "'.$enddate.'" and period_date >= (select start_date from schools where id="'.$sid.'" and status=1 and active=1 and visible=1) and period_date NOT IN (select leave_date from schools_leave_list where school_id="'.$sid.'" and status=1)) as scheduled_session
			
			from (select id,fname,username,gp_id,section,grade_id from users where sid="'.$sid.'" and id="'.$userid.'" and status=1 and visible=1 and academicyear=20) a1 order by username asc');
			//echo $this->db->last_query(); exit;
			//exit;
			return $query->result_array();
		}
		public function getgamenames($userid,$pid,$startdate,$enddate)
	{
	 
	$query=$this->db->query("SELECT a.gid,a.gname FROM  games a, game_reports b where a.gid=b.g_id and b.gu_id='".$userid."' and b.gp_id = '".$pid."'  and a.gc_id = 1 and (lastupdate between '".$startdate."' and '".$enddate."') group by a.gid");
	//echo $this->db->last_query(); exit;
	return $query->result();
	}
	public function getacademicmonths($startdate,$enddate)
		 { //echo ;exit;
			 
		$query = $this->db->query("select DATE_FORMAT(m1, '%m') as monthNumber,DATE_FORMAT(m1, '%Y') as yearNumber,DATE_FORMAT(m1, '%b') as monthName from (select ('".$startdate."' - INTERVAL DAYOFMONTH('".$startdate."')-1 DAY) +INTERVAL m MONTH as m1 from (select @rownum:=@rownum+1 as m from(select 1 union select 2 union select 3 union select 4) t1,(select 1 union select 2 union select 3 union select 4) t2,(select 1 union select 2 union select 3 union select 4) t3,(select 1 union select 2 union select 3 union select 4) t4,(select @rownum:=-1) t0) d1) d2 where m1<='".$enddate."' order by m1");
		//echo $this->db->last_query(); exit;
			return $query->result_array();
		 }
			 public function IsAsapEnable($username)
	{
		$query = $query = $this->multipledb->db->query('select count(id) as playedstatus from game_reports where gu_id=(select id from users where username="'.$username.'") and gs_id in(59,60,61,62,63)');
		//echo $this->multipledb->db->last_query(); exit;
		return $query->result_array();
	}
	public function IsCLPEnable($uid)
	{
		$query = $query = $this->db->query('select count(id) as playedstatus from game_reports where gu_id="'.$uid.'" and gs_id in(59,60,61,62,63)');
		return $query->result_array();
	} 
	public function getUserEfficiencyGraph($userid,$startdate,$enddate)
	{
		$query = $this->db->query("
		select round((sum(score)/5),2) as score,playeddate as rtime,monthNumber,yearNumber from (select avg(score) as score,sum(playeddate) as playeddate,DATE_FORMAT(lastupdate, '%m') as monthNumber,DATE_FORMAT(lastupdate, '%Y') as yearNumber from ( SELECT (".$this->config->item('skilllogic')."(`game_score`)) as score,count(distinct lastupdate) as playeddate,gs_id,lastupdate,gu_id FROM `game_reports` WHERE gs_id in (59,60,61,62,63) and gu_id='".$userid."' and (lastupdate between '".$startdate."' and '".$enddate."') group by gs_id,lastupdate) a1 group by gs_id,month(lastupdate))a2 group by monthNumber");
		//echo $this->db->last_query(); exit;
		return $query->result_array();
	}
		public function getasapinfo($userid)
		{
			$query = $this->db->query("SELECT id,fname,lname,gender,email,mobile,dob,address,avatarimage,father,creation_date,(select classname from class where id=u.grade_id) as grade FROM users u where id='".$userid."' and u.status=1");		
			//echo $this->db->last_query(); exit;
			return $query->result_array();
		}
		
		public function getuserid($uname)
        {
					 
			$query = $this->multipledb->db->query("SELECT id  FROM users where username='".$uname."' and status=1");		
			//echo $this->db->last_query(); exit;
			return $query->result_array();
        }
		
		
		public function getCurrentSessionLevel($userid)
	{
		$query = $this->db->query("select session_id from gamedata where gu_id=".$userid." and session_id!=0 order by id DESC limit 1");
		//echo $this->db->last_query(); exit;
		return $query->result_array();
	}
	
	public function getDefaultCycleData($Session_StartRange,$Session_EndRange,$session_curid)
	{
		$query = $this->db->query("select * from cycle_master where status=1 and range_start <=".$session_curid." and range_start!=1 ");
		//echo $this->db->last_query(); exit;
		return $query->result_array();
	}
	
	public function getCurrentBSPIName($Session_StartRange,$Session_EndRange,$session_curid)
	{
		$query = $this->db->query("select * from cycle_master where status=1 and range_start =".$Session_StartRange." and range_end =".$Session_EndRange." ");
		//echo $this->db->last_query(); exit;
		return $query->result_array();
	}
	
	public function getacademicyearbyschoolid($userid)
		 {
			 
			$query = $this->db->query("select startdate,enddate,id from academic_year where id=(select academic_id from schools where id=(select sid from users where id='".$userid."'))order by id desc limit 1");
			return $query->result_array();
		 }
	 
	public function getAdvancedSkillChart($userid,$Session_StartRange,$Session_EndRange,$session_curid,$startdate,$enddate)
	{
		$query = $this->db->query("select AVG(gamescore) as gamescore,gs_id,session_id from (SELECT (AVG(game_score)) as gamescore,gs_id,session_id  FROM game_reports WHERE gs_id in (59,60,61,62,63) and gu_id='".$userid."' and  (lastupdate between '".$startdate."' and '".$enddate."') and (session_id between '".$Session_StartRange."' and '".$Session_EndRange."') and session_id!=0  group by gs_id,session_id) a1 group by gs_id");
		//echo $this->db->last_query(); exit;
		return $query->result_array();
	}
	public function getBSPI_range($userid,$startrange,$endrange)		 
		{
			$query = $this->db->query('select id, fname, a3.finalscore as avgbspiset1 from users mu left join (SELECT SUM(score)/5 as finalscore, gu_id, (SELECT sid from users where id=gu_id) as schoolid from (select (AVG(score)) as score, gu_id, gs_id from (SELECT ('.$this->config->item('skilllogic').'(`game_score`)) as score , gs_id , gu_id, lastupdate FROM `game_reports` WHERE gs_id in (59,60,61,62,63) and gu_id =  "'.$userid.'" and (session_id between "'.$startrange.'" and "'.$endrange.'") and session_id!=0 group by gs_id , gu_id, lastupdate) a1 group by gs_id, gu_id ) a2 group by gu_id) a3   on a3.gu_id=mu.id where id = "'.$userid.'" ORDER BY avgbspiset1 DESC');
 
			//echo $this->multipledb->db->last_query(); exit;
			return $query->result_array();
		}
	public function getBasicSkillChart($userid,$Session_StartRange,$Session_EndRange,$session_curid,$startdate,$enddate)
	{
		$query = $this->db->query("select AVG(gamescore) as gamescore,gs_id,playedMonth from (SELECT (AVG(game_score)) as gamescore ,gs_id , lastupdate,DATE_FORMAT(lastupdate,'%m') as playedMonth  FROM sk_gamedata WHERE gs_id in (59,60,61,62,63) and gu_id='".$userid."' and  (lastupdate between '".$startdate."' and '".$enddate."') and (session_id between '".$Session_StartRange."' and '".$Session_EndRange."') and session_id!=0  group by gs_id,session_id) a1 group by gs_id");
	//	echo $this->db->last_query(); exit;
		
		return $query->result_array();
	}
	
	public function getSkillKitBSPI($userid,$Session_StartRange,$Session_EndRange)
	{
		$query = $this->db->query('SELECT AVG(score) as tsi, gu_id from (select (AVG(score)) as score, gu_id, gs_id from (SELECT ('.$this->config->item('skilllogic').'(Convert(game_score,SIGNED))) as score , gs_id , gu_id, lastupdate FROM sk_gamedata WHERE gs_id in (59,60,61,62,63) and gu_id ="'.$userid.'" and (session_id between "'.$Session_StartRange.'" and "'.$Session_EndRange.'") and session_id!=0 group by gs_id , gu_id, lastupdate) a1 group by gs_id, gu_id ) a2 group by gu_id');
	
		//echo $this->db->last_query(); exit;
		return $query->result_array();
	}
	public function getAssignSkills($userid)
	{
		$query = $this->db->query('select * from category_skills where FIND_IN_SET(id,(select weakSkills from sk_user_game_list where  userID='.$userid.' and status=0))');
		//echo $this->db->last_query(); exit;
		return $query->result_array();
	}
	 public function getskills()
		 {
		$query = $this->db->query("select name,id from category_skills where category_id = 1 order by id");
		//echo $this->db->last_query(); 
			return $query->result_array();
		 }
		 
		  public function getbspicomparison($userid)		 
		{
			$query = $this->multipledb->db->query('select id, fname, a3.finalscore as avgbspiset1 from users mu

left join 
 (SELECT SUM(score)/5 as finalscore, gu_id, (SELECT sid from users where id=gu_id) as schoolid from (select (AVG(score)) as score, gu_id, gs_id from (SELECT (AVG(`game_score`)) as score , gs_id , gu_id, lastupdate FROM `game_reports` WHERE gs_id in (59,60,61,62,63) and gu_id =  "'.$userid.'" group by gs_id , gu_id, lastupdate) a1 group by gs_id, gu_id ) a2 group by gu_id) a3   on a3.gu_id=mu.id 
 where id = "'.$userid.'" ORDER BY avgbspiset1 DESC');
 
			//echo $this->multipledb->db->last_query(); exit;
			return $query->result_array();
		}
		
		public function clpbspi($userid)		 
		{
			$query = $this->db->query('select id, fname, a3.finalscore as avgbspiset1,(select MAX(session_id) as play from game_reports where gu_id=mu.id) as playcount,(select name from cycle_master where (playcount between range_start and range_end) and status=1) as cyclename from users mu

left join 
 (SELECT SUM(score)/5 as finalscore, gu_id, (SELECT sid from users where id=gu_id) as schoolid from (select (AVG(score)) as score, gu_id, gs_id from (SELECT ('.$this->config->item('skilllogic').'(`game_score`)) as score , gs_id , gu_id, lastupdate FROM `game_reports` WHERE gs_id in (59,60,61,62,63) and gu_id =  "'.$userid.'" and session_id BETWEEN 1 and 8 group by gs_id , gu_id, lastupdate) a1 group by gs_id, gu_id ) a2 group by gu_id) a3   on a3.gu_id=mu.id 
 where id = "'.$userid.'" ORDER BY avgbspiset1 DESC');
 
			//echo $this->multipledb->db->last_query(); exit;
			return $query->result_array();
		}
		public function getskillwise_avg($uname) 
		{
			
			$query = $this->multipledb->db->query('select id, fname,s1.skillscore_M as skillscorem, skillscore_V as skillscorev,skillscore_F as skillscoref,skillscore_P as skillscorep,skillscore_L as skillscorel, a3.finalscore as avgbspiset1 from users mu

left join 
 (SELECT SUM(score)/5 as finalscore, gu_id, (SELECT sid from users where id=gu_id) as schoolid from (select (AVG(score)) as score, gu_id, gs_id from (SELECT (AVG(`game_score`)) as score , gs_id , gu_id, lastupdate FROM `game_reports` WHERE gs_id in (59,60,61,62,63) and gu_id in (select id from users) group by gs_id , gu_id, lastupdate) a1 group by gs_id, gu_id ) a2 group by gu_id) a3   on a3.gu_id=mu.id 
 
 left join
(select (AVG(score)) as skillscore_M, gu_id from (SELECT (AVG(`game_score`)) as score , gs_id , gu_id, lastupdate FROM `game_reports` WHERE gs_id =59 and gu_id in (select id from users) group by gs_id , gu_id, lastupdate) a1 group by gs_id, gu_id) s1 on s1.gu_id=mu.id 

left join
(select (AVG(score)) as skillscore_V, gu_id from (SELECT (AVG(`game_score`)) as score , gs_id , gu_id, lastupdate FROM `game_reports` WHERE gs_id =60 and gu_id in (select id from users) group by gs_id , gu_id, lastupdate) a1 group by gs_id, gu_id) s2 on s2.gu_id=mu.id 

left join
(select (AVG(score)) as skillscore_F, gu_id from (SELECT (AVG(`game_score`)) as score , gs_id , gu_id, lastupdate FROM `game_reports` WHERE gs_id =61 and gu_id in (select id from users) group by gs_id , gu_id, lastupdate) a1 group by gs_id, gu_id) s3 on s3.gu_id=mu.id 

left join
(select (AVG(score)) as skillscore_P, gu_id from (SELECT (AVG(`game_score`)) as score , gs_id , gu_id, lastupdate FROM `game_reports` WHERE gs_id =62 and gu_id in (select id from users) group by gs_id , gu_id, lastupdate) a1 group by gs_id, gu_id) s4 on s4.gu_id=mu.id 

left join
(select (AVG(score)) as skillscore_L, gu_id from (SELECT (AVG(`game_score`)) as score , gs_id , gu_id, lastupdate FROM `game_reports` WHERE gs_id =63 and gu_id in (select id from users) group by gs_id , gu_id, lastupdate) a1 group by gs_id, gu_id) s5 on s5.gu_id=mu.id 
 
 

 where username="'.$uname.'" ORDER BY avgbspiset1 DESC');
			//echo $this->multipledb->db->last_query(); exit;
			return $query->result_array();
			
		}
		public function getcounters($userid)		 
		{
			//$query = $this->db->query("SELECT ROUND((SUM(gtime)/60),0) as gtime_school_count , SUM(answer) as answer_school_count, SUM(attempt_question) as attempted_question_count FROM game_reports gr join users u on gr.gu_id=u.id WHERE gtime IS NOT NULL AND answer IS NOT NULL and u.id='".$userid."' and u.status=1  and lastupdate between (select startdate from users where id='".$userid."') and (select enddate from users where id='".$userid."')");
		
 $query = $this->db->query("SELECT ROUND((SUM(gtime)/60),0) as gtime_school_count , SUM(answer) as answer_school_count, SUM(attempt_question) as attempted_question_count FROM game_reports gr join users u on gr.gu_id=u.id WHERE gtime IS NOT NULL AND answer IS NOT NULL and u.id='".$userid."' and u.status=1  ");
 
			//echo $this->db->last_query(); exit;
			return $query->result_array();
		}
		
		public function getcrowny($userid)		 
		{
			$query = $this->db->query("select points from vi_sumofcrownypoints where U_ID='".$userid."' ");
 
			//echo $this->db->last_query(); exit;
			return $query->result_array();
		}
		public function getattemptsession($userid)		 
		{
			//$query = $this->db->query("select gu_id,count(Completed) as attempt from (select gu_id,gs_id,count(gs_id) Completed from (SELECT count(gr.id) as PalyCount,DATE_FORMAT(`lastupdate`,'%m') as monthlist ,lastupdate,gs_id,gu_id from game_reports gr join users u on u.id = gr.gu_id join user_academic_mapping um on u.id=um.id where gu_id='".$userid."' and date(lastupdate) between (select startdate from users where id='".$userid."') and (select enddate from users where id='".$userid."') group by date(lastupdate),DATE_FORMAT(`lastupdate`,'%m'),gu_id,gs_id order by date(lastupdate))a2 group by gu_id,lastupdate)a2 ");
			$query = $this->db->query("select gu_id,count(Completed) as attempt from (select gu_id,gs_id,count(gs_id) Completed from (SELECT count(gr.id) as PalyCount,DATE_FORMAT(`lastupdate`,'%m') as monthlist ,lastupdate,gs_id,gu_id from game_reports gr join users u on u.id = gr.gu_id join user_academic_mapping um on u.id=um.id where gu_id='".$userid."'   group by date(lastupdate),DATE_FORMAT(`lastupdate`,'%m'),gu_id,gs_id order by date(lastupdate))a2 group by gu_id,lastupdate)a2 ");
 
		//	echo $this->db->last_query(); exit;
			return $query->result_array();
		}
		
		public function getcompsession($userid)		 
		{
			//$query = $this->db->query("select gu_id,count(Completed) as comp from (select gu_id,gs_id,count(gs_id) Completed from (SELECT count(gr.id) as PalyCount,DATE_FORMAT(`lastupdate`,'%m') as monthlist ,lastupdate,gs_id,gu_id from game_reports gr join users u on u.id = gr.gu_id join user_academic_mapping um on u.id=um.id where gu_id='".$userid."' and date(lastupdate) between (select startdate from users where id='".$userid."') and (select enddate from users where id='".$userid."') group by date(lastupdate),DATE_FORMAT(`lastupdate`,'%m'),gu_id,gs_id order by date(lastupdate))a2 group by gu_id,lastupdate)a2 where Completed>=5");
			$query = $this->db->query("select gu_id,count(Completed) as comp from (select gu_id,gs_id,count(gs_id) Completed from (SELECT count(gr.id) as PalyCount,DATE_FORMAT(`lastupdate`,'%m') as monthlist ,lastupdate,gs_id,gu_id from game_reports gr join users u on u.id = gr.gu_id join user_academic_mapping um on u.id=um.id where gu_id='".$userid."'  group by date(lastupdate),DATE_FORMAT(`lastupdate`,'%m'),gu_id,gs_id order by date(lastupdate))a2 group by gu_id,lastupdate)a2 where Completed>=5");
 
			//echo $this->db->last_query(); exit;
			return $query->result_array();
		}
		
		public function get_clp_skillwise_avg($userid)		 
		{
			$query = $this->db->query("select id, fname, s1.skillscore_M as skillscorem, skillscore_V as skillscorev,skillscore_F as skillscoref,skillscore_P as skillscorep,skillscore_L as skillscorel, a3.finalscore as avgbspiset1 from users mu 
left join (SELECT SUM(score)/5 as finalscore, gu_id, (SELECT sid from users where id=gu_id) as schoolid from (select (AVG(score)) as score, gu_id, gs_id from (SELECT (AVG(`game_score`)) as score , gs_id , gu_id, lastupdate FROM `game_reports` WHERE gs_id in (59,60,61,62,63) and gu_id='".$userid."' and session_id BETWEEN 1 and 8 group by gs_id , gu_id, lastupdate) a1 group by gs_id, gu_id ) a2 group by gu_id) a3 on a3.gu_id=mu.id 
left join (select (AVG(score)) as skillscore_M, gu_id from (SELECT (AVG(`game_score`)) as score , gs_id , gu_id, lastupdate FROM `game_reports` WHERE gs_id =59 and gu_id='".$userid."' and session_id BETWEEN 1 and 8 group by gs_id , gu_id, lastupdate) a1 group by gs_id, gu_id) s1 on s1.gu_id=mu.id 
left join (select (AVG(score)) as skillscore_V, gu_id from (SELECT (AVG(`game_score`)) as score , gs_id , gu_id, lastupdate FROM `game_reports` WHERE gs_id =60 and gu_id='".$userid."' and session_id BETWEEN 1 and 8 group by gs_id , gu_id, lastupdate) a1 group by gs_id, gu_id) s2 on s2.gu_id=mu.id 
left join (select (AVG(score)) as skillscore_F, gu_id from (SELECT (AVG(`game_score`)) as score , gs_id , gu_id, lastupdate FROM `game_reports` WHERE gs_id =61 and gu_id='".$userid."' and session_id BETWEEN 1 and 8 group by gs_id , gu_id, lastupdate) a1 group by gs_id, gu_id) s3 on s3.gu_id=mu.id 
left join (select (AVG(score)) as skillscore_P, gu_id from (SELECT (AVG(`game_score`)) as score , gs_id , gu_id, lastupdate FROM `game_reports` WHERE gs_id =62 and gu_id='".$userid."' and session_id BETWEEN 1 and 8 group by gs_id , gu_id, lastupdate) a1 group by gs_id, gu_id) s4 on s4.gu_id=mu.id 
left join (select (AVG(score)) as skillscore_L, gu_id from (SELECT (AVG(`game_score`)) as score , gs_id , gu_id, lastupdate FROM `game_reports` WHERE gs_id =63 and gu_id='".$userid."' and session_id BETWEEN 1 and 8 group by gs_id , gu_id, lastupdate) a1 group by gs_id, gu_id) s5 on s5.gu_id=mu.id 

 where id='".$userid."' ORDER BY avgbspiset1 DESC");
 
			//echo $this->db->last_query(); exit;
			return $query->result_array();
		}
	public function getMonthWiseSkillScore($uid,$startdate,$enddate)
	{
		$query = $query = $this->db->query("select gs_id,(CASE WHEN gs_id=59 THEN 'MEMORY'
WHEN gs_id=60 THEN 'VP'
WHEN gs_id=61 THEN 'FA'
WHEN gs_id=62 THEN 'PS'
WHEN gs_id=63 THEN 'LI' else 0
END) as skillname,playedMonth,monthName,AVG(gamescore) as gamescore from (SELECT (AVG(game_score)) as gamescore ,gs_id , lastupdate,gu_id,DATE_FORMAT(lastupdate,'%m') as playedMonth,DATE_FORMAT(lastupdate, '%b') as monthName FROM game_reports WHERE gs_id in (59,60,61,62,63)and gu_id=".$uid." and lastupdate between '".$startdate."' and '".$enddate."' group by gs_id,lastupdate) a1 group by gs_id,playedMonth");
//echo $this->db->last_query(); exit;
		return $query->result_array();
	}
		
	public function getbspireport1($userid,$mnths)
		 {
	
		//$query = $this->db->query("SELECT (".$this->config->item('skilllogic')."(`game_score`)) as gamescore,gs_id , lastupdate FROM `game_reports` WHERE gs_id in (59,60,61,62,63) and gu_id='".$userid."' and DATE_FORMAT(lastupdate,'%b-%Y') in ('".$mnths."') and  lastupdate between (select startdate from users where id='".$userid."') and (select enddate from users where id='".$userid."') group by gs_id , lastupdate");
		$query = $this->db->query("SELECT (".$this->config->item('skilllogic')."(`game_score`)) as gamescore,gs_id , lastupdate FROM `game_reports` WHERE gs_id in (59,60,61,62,63) and gu_id='".$userid."' and DATE_FORMAT(lastupdate,'%b-%Y') in ('".$mnths."')   group by gs_id , lastupdate");
		//echo $this->db->last_query(); exit;
			return $query->result_array();
		 }	
		 
		 
	public function asap_reports($sid,$grade_id,$section) 
	{
			if($grade_id!=''){$gwhere="grade_id=".$grade_id;}else{$gwhere="1=1";}
			if($section!=''){$swhere="section='".$section."'";}else{$swhere="1=1";}
			
			$query = $this->multipledb->db->query('select id, fname,lname,username,mobile,father,mother,  s1.skillscore_M as skillscorem, skillscore_V as skillscorev,skillscore_F as skillscoref,skillscore_P as skillscorep,skillscore_L as skillscorel, a3.finalscore as avgbspiset1,COALESCE(a3.playedcount,0) as playcount from users mu

left join 
 (SELECT SUM(score)/5 as finalscore, count(gu_id) as playedcount, gu_id, '.$sid.' as schoolid from (select (AVG(score)) as score, gu_id, gs_id from (SELECT (AVG(`game_score`)) as score , gs_id , gu_id, lastupdate FROM `game_reports` WHERE gs_id in (59,60,61,62,63) and gu_id in (select id from users where sid='.$sid.' and '.$gwhere.' and '.$swhere.') group by gs_id , gu_id, lastupdate) a1 group by gs_id, gu_id ) a2 group by gu_id) a3   on a3.gu_id=mu.id 
 
 left join
(select (AVG(score)) as skillscore_M, gu_id from (SELECT (AVG(`game_score`)) as score , gs_id , gu_id, lastupdate FROM `game_reports` WHERE gs_id =59 and gu_id in (select id from users where sid='.$sid.' and '.$gwhere.'  and '.$swhere.') group by gs_id , gu_id, lastupdate) a1 group by gs_id, gu_id) s1 on s1.gu_id=mu.id 

left join
(select (AVG(score)) as skillscore_V, gu_id from (SELECT (AVG(`game_score`)) as score , gs_id , gu_id, lastupdate FROM `game_reports` WHERE gs_id =60 and gu_id in (select id from users where sid='.$sid.' and '.$gwhere.'  and '.$swhere.') group by gs_id , gu_id, lastupdate) a1 group by gs_id, gu_id) s2 on s2.gu_id=mu.id 

left join
(select (AVG(score)) as skillscore_F, gu_id from (SELECT (AVG(`game_score`)) as score , gs_id , gu_id, lastupdate FROM `game_reports` WHERE gs_id =61 and gu_id in (select id from users where sid='.$sid.' and '.$gwhere.'  and '.$swhere.') group by gs_id , gu_id, lastupdate) a1 group by gs_id, gu_id) s3 on s3.gu_id=mu.id 

left join
(select (AVG(score)) as skillscore_P, gu_id from (SELECT (AVG(`game_score`)) as score , gs_id , gu_id, lastupdate FROM `game_reports` WHERE gs_id =62 and gu_id in (select id from users where sid='.$sid.' and '.$gwhere.'  and '.$swhere.') group by gs_id , gu_id, lastupdate) a1 group by gs_id, gu_id) s4 on s4.gu_id=mu.id 

left join
(select (AVG(score)) as skillscore_L, gu_id from (SELECT (AVG(`game_score`)) as score , gs_id , gu_id, lastupdate FROM `game_reports` WHERE gs_id =63 and gu_id in (select id from users where sid='.$sid.' and '.$gwhere.'  and '.$swhere.') group by gs_id , gu_id, lastupdate) a1 group by gs_id, gu_id) s5 on s5.gu_id=mu.id where mu.sid='.$sid.'
 ');
			//echo $this->multipledb->db->last_query(); exit;
			return $query->result_array();
			
		}
		
		public function clp_reports($sid,$grade_id,$section)		 
		{ 
		
			if($grade_id!=''){$gwhere="grade_id=".$grade_id;}else{$gwhere="1=1";}
			if($section!=''){$swhere="section='".$section."'";}else{$swhere="1=1";}

			$query = $this->db->query("select id,fname,lname,username,gp_id,section,grade_id,creation_date,(select classname from class where id=grade_id order by id asc) as grade,(select MAX(session_id) as play from game_reports where gu_id=a1.id) as playcount,(select name from cycle_master where (playcount between range_start and range_end) and status=1) as cyclename,

			(select CONVERT(CONCAT(avg(game_score),',',avg(game_score1)),CHAR(100)) from (select AVG(game_score)as game_score,MAX(game_score)as game_score1,lastupdate,gu_id from game_reports where gs_id=59 and session_id BETWEEN 1 and 8  group by lastupdate,gu_id ) s1  where gu_id=a1.id) as skillscorem,

			(select CONVERT(CONCAT(avg(game_score),',',avg(game_score1)),CHAR(100)) from (select AVG(game_score)as game_score,MAX(game_score)as game_score1,lastupdate,gu_id from game_reports where gs_id=60 and session_id BETWEEN 1 and 8 group by lastupdate,gu_id )s2  where gu_id=a1.id) as skillscorev,

			(select CONVERT(CONCAT(avg(game_score),',',avg(game_score1)),CHAR(100)) from (select AVG(game_score)as game_score,MAX(game_score)as game_score1,lastupdate,gu_id from game_reports where gs_id=61 and session_id BETWEEN 1 and 8  group by lastupdate,gu_id )s3  where gu_id=a1.id) as skillscoref,

			(select CONVERT(CONCAT(avg(game_score),',',avg(game_score1)),CHAR(100)) from (select AVG(game_score)as game_score,MAX(game_score)as game_score1,lastupdate,gu_id from game_reports where gs_id=62 and session_id BETWEEN 1 and 8  group by lastupdate,gu_id )s4  where gu_id=a1.id) as skillscorep,

			(select CONVERT(CONCAT(avg(game_score),',',avg(game_score1)),CHAR(100)) from (select AVG(game_score)as game_score,MAX(game_score)as game_score1,lastupdate,gu_id from  game_reports where gs_id=63 and session_id BETWEEN 1 and 8 group by lastupdate,gu_id )s5  where gu_id=a1.id) as skillscorel,

			(select count(lastupdate) from (select lastupdate,gu_id from  game_reports group by lastupdate,gu_id) s1 where lastupdate between a1.startdate and a1.enddate and gu_id=a1.id) as AttendedSession,

			(select SUM(CASE WHEN game>=5 THEN 1 ELSE 0 END) as completedsession from (select sum(gamesplayed) as game,gu_id,lastupdate from (select lastupdate,count(DISTINCT gs_id) as gamesplayed,gu_id from  game_reports  group by gu_id,gs_id,lastupdate) a3 group by gu_id,lastupdate) s1 where lastupdate between a1.startdate and a1.enddate and  gu_id=a1.id) as CompletedSession	

			from (select id,fname,lname,username,gp_id,section,grade_id,creation_date,1 as startdate,1 as  enddate  from users where sid=".$sid." and ".$gwhere." and ".$swhere."  and status=1 and visible=1 ) a1");

			//	echo $this->db->last_query(); 
			return $query->result_array();
		}
		/* SELECT count(email) as emailcount  FROM school_admin sd join schools sls on sd.email=sls.email WHERE sd.status=1 and sls.active=1  and email='".$emailid."'   */ 
		
		//-----------------------forget password-------------------------------//
		
		public function getmailid($usermailid)
		{ 
			$query = $this->db->query("select count(usermailid) as mailcount,fname,mobile,school_id from school_admin where active=1 and status=1 and usermailid='".$usermailid."'"); 
		 // echo $this->db->last_query(); exit;
		    return $query->result_array();  
		}
		
		public function fpwdinsertlog($usermailid,$randid)
		{
			 
			$query = $this->db->query("insert into forgetpasswordlog(usrmailid,randid,modified_on,status)values('".$usermailid."','".$randid."',NOW(),1)"); 
			//echo $this->db->last_query(); exit;
		}
		
		public function chkisvalidusr($usremailid,$randid)
		{
			$query = $this->db->query("select usrmailid as usremailid,randid,modified_on from forgetpasswordlog where status=1 and md5(usrmailid)='".$usremailid."' and md5(randid)='".$randid."'");
			//echo $this->db->last_query(); exit;
			return $query->result_array();
		}
		
		public function getResetpwdUserDetails($usermailid)
		{	
			$query = $this->db->query("select id,usermailid,fname,lname,email,mobile from school_admin where usermailid='".$usermailid."' and status=1 and active=1 and flag=1");
			//echo $this->db->last_query(); exit;
			return $query->result_array();
		} 
		
		public function ResetUserPwd($newpassword,$usermailid)
		{
			//echo "update school_admin set password='".md5($newpassword)."' where usermailid='".$usermailid."' and active=1 and status=1 and flag=1";exit;
			$query = $this->db->query("update school_admin set password='".md5($newpassword)."' where usermailid='".$usermailid."' and active=1 and status=1 and flag=1");
			 
		}
		 
		public function ResetUserPwd_log($usremailid,$randid,$newpassword)
		{
			$query = $this->db->query("update forgetpasswordlog set 	modified_on=now(),status=1,newpassword='".md5($newpassword)."' where md5(usrmailid)='".$usremailid."' and md5(randid)='".$randid."'"); 
		} 
}
