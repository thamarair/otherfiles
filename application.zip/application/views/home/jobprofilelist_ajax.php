 <div class="container1">  
	<div class="row">
		<div class="col-md-12 col-sm-12 col-xs-12">
			<div class="col-md-12 col-sm-12 col-xs-12" style="text-align:center;color:#FF5722;font-weight: bold;letter-spacing: 2px;border-bottom: 2px dotted #ccc;padding: 0 0 10px 0;">
				<h4 style="margin:0px;">Job Profile</h4> 
				<h2 style="margin:0px;font-weight: bold;"><?php echo $EbilityProfileData[0]['occupation']; ?></h2> 
			</div>
			<div class="col-md-12 col-sm-12 col-xs-12" style="text-align:center;font-weight: bold;letter-spacing: 2px;color: #009688;border-bottom: 2px dotted #ccc;padding: 10px 0;"> 
					<h4 style="margin:0px;">Sector</h4> 
				<h3 style="margin:0px;font-weight: bold;"><?php echo $EbilityProfileData[0]['subsector']; ?></h3>
			</div>
		</div>
		<div class="col-md-12 col-sm-12 col-xs-12" style="margin-bottom:200px;">
			<div class="col-md-6 col-sm-6 col-xs-6">
				<div class="col-md-12 col-sm-12 col-xs-12" style="text-align:center;color:#FF5722;font-weight: bold;letter-spacing: 2px;">
					<h2>Abilities</h2> 
				</div>
				<table id="AB" class="table table-striped table-bordered"	>
					<thead>
						<tr>
							<th>S.No.</th>
							<th>Name</th>
							<th>Percentage(%)</th>
							<th>Description</th>
						   
						</tr>
					</thead>
					<tbody>
						<?php $i=1;
						foreach($EbilityProfileData as $row)
						{
							?>
							<tr>
								<td><?php echo $i; ?></td>
								<td><?php echo $row['subability']; ?></td>
								<td><?php echo $row['abilityvalue']; ?></td>
								<td><?php echo $row['description']; ?></td>
								</td>	
							</tr>
						<?php
						$i++; }
						?>	 
					</tbody>
				</table>
			</div>
			<div class="col-md-6 col-sm-6 col-xs-6">
				<div class="col-md-12 col-sm-12 col-xs-12" style="text-align:center;color:#FF5722;font-weight: bold;letter-spacing: 2px;">
					<h2>Skills</h2> 
				</div>
				<table id="SK" class="table table-striped table-bordered"	>
					<thead>
						<tr>
							<th>S.No.</th>
							<th>Name</th>
							<th>Percentage(%)</th>
							<th>Description</th>
						</tr>
					</thead>
					
					<tbody>
					<?php $j=1;
					foreach ($SkillProfileData as $row)
					{
						?>
						<tr>
							<td><?php echo $j; ?></td>
							<td><?php echo $row['subskill']; ?></td>
							<td><?php echo $row['skillvalue']; ?></td>
							<td><?php echo $row['description']; ?></td>
							</td>	
						</tr>
					<?php
					$j++; }
					?>	 
				<?php
					$row++;
				?>
					</tbody>
				</table>
			 </div>
		</div>
	</div>
</div>
 <script>
$(document).ready(function() {
    $('#AB').DataTable( {
  "pageLength": 5,searching: false, "bLengthChange" : false
} );
    $('#SK').DataTable( {
  "pageLength": 5,searching: false, "bLengthChange" : false
} );
});
</script>