<!DOCTYPE html>
<html lang="en"> 
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=yes">
<title>Skillangels</title> 

<!-- Bootstrap --> 
<link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/bootstrap.min.css">	 
<link href="<?php echo base_url(); ?>assets/css/font-awesome.min.css" rel="stylesheet">
<link href="<?php echo base_url(); ?>assets/css/nprogress.css" rel="stylesheet">
 <link href="<?php echo base_url(); ?>assets/css/animate.min.css" rel="stylesheet">
<link href="<?php echo base_url(); ?>assets/css/custom.min.css" rel="stylesheet"> 
  
  <script src="<?php echo base_url(); ?>assets/js/jquery.min.js"type="text/javascript"></script>
  <script src="<?php echo base_url(); ?>assets/js/bootstrap.min.js"type="text/javascript"></script>
  <script src="<?php echo base_url(); ?>assets/js/jquery.validate.js"></script>
  <style>
.ed6 {
    color: rgb(0, 170, 255);
    font-family: "Shadows Into Light",cursive;
    font-size: 2em;
}
.LoginContainer
{
	    BORDER: 2px solid;
    width: 50%;
    margin-left: 25%;
}
.submitlabel{padding-top:20px;padding-bottom:20px;}
.LoginContainer .fields{text-align:right;}
footer {
    margin-left: 0px !important;
	 color: #73879C;
}
input
{	 color: #73879C;
}
.landingContainer{padding-bottom:20px;}
body {
    color: #ffffff;
}

#lnkforgetpwd{
    width:200px;
    height:32px;
	font-weight:500;
	font-size:20px;
	color:#ff9800;
    
}
b, h4 {
    font-weight: 700;
    color: #2A3F54;
}
#successmsg{
	 color: #e91e63;
	 font-weight:600;
	 font-size:20px;
}
#frmFP{
	color: #ff5722;
	 font-weight:600;
	 font-size:20px;
	
}
</style>
</head>
 
<div class="login_wrapper">
        <div class="animate form login_form">
		 <div align="center"><img style="width: 200px;display: block;" src="<?php echo base_url(); ?>assets/images/web_logo.png" /><strong><span class="ed6">EdSix Brain Lab<sup>TM</sup> Pvt Ltd</span><br>Incubated by IIT Madras' RTBI<br>
					Supported by IIM Ahmedabad's CIIE and Village Capital, U.S.A</strong>

					</div>
               <section class="login_content">
            <form action="<?php echo base_url();?>index.php/home/logincheck" class="cmxform" method="POST" id="commentForm" accept-charset="utf-8">
              <h1>School Admin Login</h1>
			   <div class="green"></div>
					<div class="" style="padding-bottom: 20px; color:red; text-shadow:none;"><?php echo $msg_error;?></div>
              <div>
                <input type="text" name="username" value="" class="form-control required email" placeholder="Username" id="email">
              </div>
              <div>
                <input type="password" name="password" value="" class="form-control required" placeholder="Password" id="pwd">
				 <a id="lnkforgetpwd"  href="#"   data-toggle="modal" data-target="#fpwdModal">Forgot / Change Password?</a> 
 
              <div>
                <input type="submit" class="btn btn-success" style="float:right;" id="submit" name="submit" value="Login">
				<span style="color: crimson;text-shadow: none;font-size: 20px;"><?php echo $this->session->flashdata('message'); ?></span>
              </div> 
            </form>
          </section>
		  </div></div></div> 
		  
		 <div class="modal" id="fpwdModal">
			<div class="modal-dialog">
				<div class="modal-content"> 
			  <!-- Modal Header   -->
				  <div class="modal-header">
					<h4 class="modal-title">Welcome, Enter your E-mail Address </h4>
					<button type="button" class="close" data-dismiss="modal">&times;</button>
				  </div> 
					  <!-- Modal body  -->
				  <div class="modal-body">
					<div class="">
                      <form class="form-horizontal" role="form" name="frmFP" id="frmFP">
                          <div class="panel-body"><div id="msgFP" style="font-size: 18px;"></div>
							<div class="form-group"> 
					  
								<label for="usermailid" class="usrname"><h4>E-mail Address: </h4></label>
								<input type="text" class="form-control input-lg" placeholder="Enter E-mail Address" name="usermailid" id="usermailid"> 
									<div id="successmsg"> </div>	
							</div> 
						 </div>
					  </form>
					</div>
					  <!-- Modal footer-->  
					  <div class="modal-footer">
						<input type="button" class="btn btn-primary" name="btnsubmit" id="btnsubmit"   value="Submit">  
					  </div>  
					</div> 
				 </div> 
			</div>	 
<script>
$(document).ready(function() {
	 
			//alert("caa");	
		$("#frmFP").validate({
			rules: {
			"usermailid": {required: true,email:true}
			},
			messages: {
			"usermailid": {required: "Please enter a email address"}
			},
			errorPlacement: function(error, element) {
			error.insertAfter(element);
			},
			highlight: function(input) {
			$(input).addClass('error');
			}
		}); 
			$("#btnsubmit").click(function(){
				if($("#frmFP").valid())
				{
					$.ajax({
				url: "<?php echo base_url(); ?>index.php/home/forgetpwd_popup", 
				type:'POST',
				data:{usermailid:$("#usermailid").val()},
				success: function(result)
				{
					if(result==1)
					{
						$("#usermailid").attr('readonly', 'readonly');
						$("#msgFP").css("margin-bottom","10px").html("<div style='color:green;font-size: 19px;'>Reset password link has beed send to your mail id.</div>");
						$('#btnsubmit').hide();
					}
					else
					{	
						$("#msgFP").css("margin-bottom","10px").html("<div style='color:red'>Enter the valid registered email id</div>");
						$('#btnsubmit').show();
					}
					 
				}
			});
					 
				}
		});   
	   
});   
			 
		 
</script>

 <!--<a id="lnkforgetpwd"  href="#"   data-toggle="modal" data-target="#fpwdModal">.base_url().index.php/home/confirmpassword</a>pvsscl@gmail.com-->



 

