<?php //echo $this->session->issparkies."==".$this->session->sparkiespoints;exit; ?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=yes">
<title>Skillangels</title>
<link rel="icon" href="<?php echo base_url(); ?>favicon.ico">
<!-- Bootstrap -->
	<link href="<?php echo base_url(); ?>assets/css/bootstrap-glyphicons.css" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/css/bootstrap.min.css">
 <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/css/styleinner.css">
 <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/css/<?php if($userthemefile[0]['usertheme']==''){ echo 'default.css'; } else { echo $userthemefile[0]['usertheme']; } ?>">
 
 <link href="<?php echo base_url(); ?>assets/css/responsive.css" rel="stylesheet">
  <link href="<?php echo base_url(); ?>assets/css/font.css" rel="stylesheet">
    <link href="<?php echo base_url(); ?>assets/css/font-awesome.css" rel="stylesheet">
    <link href="<?php echo base_url(); ?>assets/css/font-awesome-animation.min.css" rel="stylesheet">

	 <!-- font CSS -->
    <link href="<?php echo base_url(); ?>assets/css/font-awesome.min.css" rel="stylesheet">
    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <link href="<?php echo base_url(); ?>assets/css/ie10-viewport-bug-workaround.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="<?php echo base_url(); ?>assets/css/navbar-static-top.css" rel="stylesheet">
	<link href="<?php echo base_url(); ?>assets/fonts/Roboto.css" rel="stylesheet">
<script src="<?php echo base_url(); ?>assets/js/ie-emulation-modes-warning.js"></script>
<!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/css/stylenew.css">
<script src="<?php echo base_url(); ?>assets/js/jquery-2.2.0.min.js" type="text/javascript"></script>
<script src="<?php echo base_url(); ?>assets/js/jquery-ui.js"></script>
<script src="<?php echo base_url(); ?>assets/js/jquery.validate.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/bootstrap.min.js"></script>

<style>
.pd2px{padding:0px 2px;}
.section_three .nav>li>a
{    padding: 22px 8px;
}
/* Dashboard*/

.news-item {
    margin: 0px;
    border-bottom: 1px dotted #fff;
    padding: 3px 0;
    color: #000;
}

.news-item img{margin-right:8px;}
#resultsmine,#resultsall{height: 415px;overflow-y: scroll;background-color:rgb(224, 228, 201);}

#results{background:#fafafa}
#newsfeedpart{border: 1px solid #c1bebe;}
.panel-heading{padding: 0;background:#ddd;color:#fff;padding:0;margin:0;}
.minefeeds{border-right: 1px solid;text-align: center;display: block;float: left;    cursor: pointer;}
.allfeeds{    cursor: pointer;}
.panel-heading .active{background:#ffc000}

/*   STYLE 10 */


#bspisval {
    /* width: 100%; */
    padding: 0px 15px;
    text-align: center;
    color: #fdec09;
    font-size: 24px;
    font-weight: bold;
}
#bspisval h5{color:#fdec09}
#pointsval h5{color:#fdec09}
/*-----Dashboard----*/

.pointscart {
	float: left;
    width: 55%;
}

.loader {
    position: fixed;
    left: 0px;
    top: 0px;
    bottom: 0;
    right: 0;
    width: 100%;
    height: 100%;
    z-index: 99999;
    background: #5a5757 50% 100% no-repeat;
    opacity: 0.6;
}

.pad_v1 p{line-height:28px;}




#visiblepoints
{
	margin: auto;
    color: #fae50d;
    padding: 4px 20px;
    background: #92278f;
    position: relative;
    font-size: 20px;
    font-weight: 800;
}


.tooltip {background-color:transparent !important;opacity:1 }
.tooltip-inner {max-width:320px;text-align: inherit;}
.section_two{height:90px;}
.tooltip-inner {
    background-color:#ffffbc;
    color: #000;
    border: 3px solid #dede71;
    border-radius: 10px;
}
.tooltip.in{opacity:1 !important}

.reportChartContainer1 {
    padding: 20px;
    overflow: hidden;
}
.cb {
    clear: both;
}
.PskillName {
    float: left;
    width: 34.5%;
    display: inline-block;
    padding: 10px 0 11px 0;
    border-right: 1px solid #000;
    margin-bottom: 0;    color: #000;
	font-size:18px !important;
	line-height:25px; !important;
}
div.meter {
    float: left;
    width: 65%;
    height: 25px;
    border: 1px solid #b0b0b0;
    -webkit-box-shadow: inset 0 3px 5px 0 #d3d0d0;
    -moz-box-shadow: inset 0 3px 5px 0 #d3d0d0;
    box-shadow: inset 0 3px 5px 0 #d3d0d0;
    -webkit-border-radius: 3px;
    -moz-border-radius: 3px;
    -ms-border-radius: 3px;
    -o-border-radius: 3px;
    border-radius: 3px;
}
.mt10 {
    margin-top: 9px;
}
div.meter span {
    color: #fff;
    top: 0;
    line-height: 0px;
    padding-left: 7px;
    font-weight: bold;
    text-align: right;
    padding-right: 5px;
    display: block;
    height: 100%;
    animation: grower 1s linear;
    -moz-animation: grower 1s linear;
    -webkit-animation: grower 1s linear;
    -o-animation: grower 1s linear;
    position: relative;
    left: -1px;
    -webkit-border-radius: 3px;
    -moz-border-radius: 3px;
    -ms-border-radius: 3px;
    -o-border-radius: 3px;
    border-radius: 3px;
    -webkit-box-shadow: inset 0px 3px 5px 0px rgba(0, 0, 0, 0.2);
    -moz-box-shadow: inset 0px 3px 5px 0px rgba(0, 0, 0, 0.2);
    box-shadow: inset 0px 3px 5px 0px rgba(0, 0, 0, 0.2);
    background-image: -webkit-gradient(linear, 0 0, 100% 100%, color-stop(0.25, rgba(255, 255, 255, 0.2)), color-stop(0.25, transparent), color-stop(0.5, transparent), color-stop(0.5, rgba(255, 255, 255, 0.2)), color-stop(0.75, rgba(255, 255, 255, 0.2)), color-stop(0.75, transparent), to(transparent));
    background-image: -webkit-linear-gradient(45deg, rgba(255, 255, 255, 0.2) 25%, transparent 25%, transparent 50%, rgba(255, 255, 255, 0.2) 50%, rgba(255, 255, 255, 0.2) 75%, transparent 75%, transparent);
    background-image: -moz-linear-gradient(45deg, rgba(255, 255, 255, 0.2) 25%, transparent 25%, transparent 50%, rgba(255, 255, 255, 0.2) 50%, rgba(255, 255, 255, 0.2) 75%, transparent 75%, transparent);
    background-image: -ms-linear-gradient(45deg, rgba(255, 255, 255, 0.2) 25%, transparent 25%, transparent 50%, rgba(255, 255, 255, 0.2) 50%, rgba(255, 255, 255, 0.2) 75%, transparent 75%, transparent);
    background-image: -o-linear-gradient(45deg, rgba(255, 255, 255, 0.2) 25%, transparent 25%, transparent 50%, rgba(255, 255, 255, 0.2) 50%, rgba(255, 255, 255, 0.2) 75%, transparent 75%, transparent);
    -webkit-background-size: 45px 45px;
    -moz-background-size: 45px 45px;
    -o-background-size: 45px 45px;
    background-size: 45px 45px;
}
.redColor {
    background: #e81919;
}
.yellowColor {
    background: #ffa300;
    margin-bottom: 10px;
}
.greenColor {
    background: #8bcc46;
    margin-bottom: 10px;
}
.orangeColor {
    background: #f16202;
    margin-bottom: 10px;
}
.blueColor {
    background: #0ab7f6;
    margin-bottom: 10px;
}
div.meter span:before {
    content: '';
    display: block;
    width: 100%;
    height: 50%;
    position: relative;
    top: 50%;
    background: rgba(0, 0, 0, 0.03);
}

.counters { text-align:center; font-size:21px; background: crimson;
    margin-right: 4px; color:#fff; }
	
.Mh2 { font-size: 38px; font-weight: 400; position: relative; color: #ff6600; margin-bottom:0; }


#todayModal .modal-title {color: #000;}
#todayModal .modal-body {background: #FFF;overflow: hidden;}
#todayModal h3{color:#fff;margin-top: 5px;text-align: left;}
#todayModal h4{color:#fff;margin-top: 5px;}

#jobprofile .modal-title {color: #000;}
#jobprofile .modal-body {background: #FFF;overflow: hidden;}
#jobprofile h3{color:#fff;margin-top: 5px;text-align: left;}
#jobprofile h4{color:#fff;margin-top: 5px;}

.sessionpopup {
    background-image: url('<?php echo base_url(); ?>/assets/images/popup/PU-Logout.png');
    background-repeat: no-repeat;
    background-size: cover;
    height: 500px;
	background-position: center;
}
.welcomemsgpopup {
    background-image: url('<?php echo base_url(); ?>/assets/images/popup/PU-welcome.png');
    background-repeat: no-repeat;
    background-size: cover;
    height: 500px;
	background-position: center;
}
.incompleteday {
    background-image: url('<?php echo base_url(); ?>/assets/images/popup/PUholder-leftatgame.png');
    background-repeat: no-repeat;
    background-size: cover;
    height: 500px;
	background-position: center;
}

#tfdbksubmit {
    background-image: url('<?php echo base_url(); ?>/assets/images/popup/Teachers-03web.png');
	/* background-position: center center; 
    background-size: 100%;*/
    background-color: transparent;
	width:196px;
	height:75px;
  
} 

.skillkitmodal {
    background-image: url('<?php echo base_url(); ?>/assets/images/popup/PU-welcome.png');
    background-repeat: no-repeat;
    background-size: cover;
    height: 500px;
	background-position: center;
}
.firstlogincls {
	font-size: 23px;
    position: relative;
    margin-bottom: 15px;
    color: #ff6600;
	text-align : justify;
}
.welcontent ul li { list-style:inherit; }
</style>
</head>
<?php 
if ($this->session->user_id && isset($this->session->issparkies)){
	if($this->session->sparkiespoints!=0)
	{
		$sparkiesloginpointval=$this->session->sparkiespoints;
	}
	else
	{
		$sparkiesloginpointval=0;
	}
}
?>
<body>
<button onclick="topFunction()" id="myBtn" title="Go to top"><span class=""></span></button>
<div id="ContentPartStart">
	<div class="modal fade"  id="login-modal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: none;">

    	  <div class="modal-dialog">
		 
				<div class="loginmodal-container">
				 <button type="button" class="close" data-dismiss="modal"><img src="<?php echo base_url();?>/assets/images/close.png" /></button>
					<h1>Login to Your Account</h1><br>
					
					<form  class="cmxform form-inline" method="POST" id="form-login" accept-charset="utf-8" > <ul><li><div id="errormsg"></div></li><li><label for="email">Email or Username</label><input required="required" type="text" name="email" value="" class="input-small logTxt" id="email"></li><li><label for="pwd">Password</label><input required="required" type="password" name="pwd" value="" class="input-small logTxt" id="pwd"></li>
					<li style="display:none">
					<select style="height:28px" name="ddlLanguage" class="input-small logTxt ddlHLanguage" id="ddlHLanguage">
								<option value="1">English</option>
								</select>
					</li><li><input type="button" class="btn btn-primary logSubmit" id="submit" name="submit" value="Login"></li> </ul></form>
					
				 
				  <div class="login-help">
					<label><input type="checkbox" id="remember" name="remember"><span class="spanRememberme">Remember me</span></label>
				  </div>
				</div>
			</div>
		  </div>
		  <div class="clear_both"></div>
<div id="header">
<div class="section_two" id="View">
<div class="container">
<div class="row">
<?php
if(($sabadge[0]['isSA']>0) || ($sbbadge[0]['isSB']>0) || ($sgbadge[0]['isSG']>0))
{ 
	$colcls="col-md-3 col-sm-3 col-xs-12";
	$cls3=" sec_in1";
	$cls4=" ";
}
else
{
	$colcls="col-md-4 col-sm-4 col-xs-12";
	$cls3=" ";
	$cls4=" sec_in1";
}
//if($this->session->game_grade!=12 && $this->session->game_grade!=13 && $this->session->game_grade!=14 && $this->session->game_grade!=15)
if($this->session->game_grade==100)
{
	$mathvisiblecls="col-md-6 col-sm-6 col-xs-6";
	$mathvisible="";
}
else
{
	$mathvisiblecls="";
	$mathvisible="display:none;";
}
?><div class="<?php echo $colcls; ?>">
  <div class="sec_in_sec goodday">
	<p>Good day <br><?php echo $this->session->fname; ?></p>
  </div>
  </div>
  <!--<div class="<?php echo $colcls; ?>">
	<div class="sec_in_sec">
	<div id="bspisval" class="bspival bouncedown <?php echo $mathvisiblecls; ?>">
		 <h5 style="">BSPI Score <a style="top:-5px;position:relative;" href="javascript:;" data-toggle="tooltip" data-placement="left" data-html="true" title='<div class=""><span style="font-size:12px;">Your BSPI score reflects <br/>the average score<br/> of the 5 skills you use.<br/> Practice each skill <br/>to raise this score</span></div>'><i  style="color:white; font-size:16px;" class="fa fa-info-circle"></i></a></h5>
		 <span id="currentBSPI"><?php echo round($bspi,2); ?></span>
	</div>
	<div id="mspisval" class="bspival bouncedown <?php echo $mathvisiblecls; ?>" style="<?php echo $mathvisible; ?>">
		 <h5 style="">MSPI Score <a style="top:-5px;position:relative;" href="javascript:;" data-toggle="tooltip" data-placement="left" data-html="true" title='<div class=""><span style="font-size:12px;">Your MSPI score reflects <br/>the average score<br/> of the 5 skills you use.<br/> Practice each skill <br/>to raise this score</span></div>'><i  style="color:white; font-size:16px;" class="fa fa-info-circle"></i></a></h5>
		 <span id="currentMSPI"><?php echo round($mspi,2); ?></span>
	</div>
	</div>		
  </div>-->
  <div class="col-md-5 col-sm-5 col-xs-12 pd2px">
		<div class="col-md-6 col-sm-6 col-xs-12 pd2px">
			<div class="sec_in_sec">
				<div id="bspisval" class="bspival bouncedown col-md-12 col-sm-12 col-xs-12">
					 <h5 style="">Initial Assessment BSPI <a style="top:-5px;position:relative;" href="javascript:;" data-toggle="tooltip" data-placement="left" data-html="true" title='<div class=""><span style="font-size:12px;">Your BSPI score reflects <br/>the average score<br/> of the 5 skills you use.<br/> Practice each skill <br/>to raise this score</span></div>'><i  style="color:white; font-size:16px;" class="fa fa-info-circle"></i></a></h5>
					 <span id="currentAsapBSPI"><?php echo $asap_bspi['bspi']; ?></span>
				</div>
			</div>		
		</div>
		<div class="col-md-6 col-sm-6 col-xs-12 pd2px">
			<div class="sec_in_sec">
				<div id="bspisval" class="bspival bouncedown col-md-12 col-sm-12 col-xs-12">
					 <h5 style="">Status</h5>
					 <?php 
					 if($this->session->Next_Session_id<=8)
					 {
							$cursessid=$this->session->Next_Session_id;
					?>
						<span id="currentPgmStatus"><?php echo $asap_bspi['current_status']." [S-".$cursessid."]"; ?></span>
					 <?php 
					 } 
					 else
					 {
					 ?>
						<span id="currentPgmStatus"><?php echo $asap_bspi['current_status']; ?></span>
					 <?php
					 }
					 ?>
				</div>
			</div>		
		</div>	
	</div>
 <!--<div class="<?php echo $colcls; ?>">-->
  <div class="col-md-3 col-sm-3 col-xs-12 pd2px">
    <div class="sec_in_sec <?php echo $cls4 ; ?> sec_in_sec_crown">
	<div id="pointsval" class="bouncedown col-md-3 col-sm-4 col-xs-12">
		<div class="spaval"><h5 style="">Crownies <a style="top:-5px;position:relative;" href="javascript:;" data-toggle="tooltip" data-placement="left" data-html="true" title='<div class=""><span style="font-size:12px;">Earn Crownies by solving <br/>more games and <br/>coming back regularly</span></div>'><i  style="color:white; font-size:16px;" class="fa fa-info-circle"></i></a></h5>
			<span id="skyangelspoints"><?php echo $sparkies; ?></span>
		</div>
		<div class="pointscart points-cart-img">
			<img class="" src="<?php echo base_url(); ?>assets/images/sparkies/6.gif" width="80px;" >
		</div>
	</div>
  </div>
  </div>
<?php
if(($sabadge[0]['isSA']>0) || ($sbbadge[0]['isSB']>0) || ($sgbadge[0]['isSG']>0))
{ ?>
  <div class="<?php echo $colcls; ?>">
	<div class="sec_in_sec <?php echo $cls3; ?>">
			<div class="col-md-4 col-sm-4 col-xs-4 sab badgepart">
			<?php if($sabadge[0]['isSA']>0) { ?>
				 <p style="font-size: 20px; margin:0;"><a id="" class="certification_sa" style="text-decoration: none;" data-type="sa" data-val="<?php echo 20; ?>" href="javascript:;" title="Super Angel Badge">
					<img src="<?php echo base_url(); ?>assets/images/popup/superangel-web.png" style="width: 30px;"/> <a style="top:-5px;position:relative;" href="javascript:;" data-toggle="tooltip" data-placement="left" data-html="true" title='<div class=""><div class="toolbadgehe">Super Angel Badge</div><span style="font-size:12px;">Accurate Played User</span></div>'><i  style="color:white; font-size:16px;" class="fa fa-info-circle"></i></a></a>
				 </p> <?php } ?>
			</div>
					
			<div class="col-md-4 col-sm-4 col-xs-4 sbb badgepart">
			<?php if($sbbadge[0]['isSB']>0) { ?>
				 <p style="font-size: 20px;  margin:0;"><a id="" class="certification_sa" style="text-decoration: none;" data-type="sb" data-val="<?php echo 55.2; ?>" href="javascript:;" title="Super Brain Badge">
					<img src="<?php echo base_url(); ?>assets/images/popup/superbrain-web.png" style="width: 30px;"/><a style="top:-5px;position:relative;" href="javascript:;" data-toggle="tooltip" data-placement="left" data-html="true" title='<div class=""><div class="toolbadgehe">Super Brain Badge </div><span style="font-size:12px;">Highest BSPI Scorer</span></div>'><i  style="color:white; font-size:16px;" class="fa fa-info-circle"></i></a></a>
				  </p> <?php } ?>
			</div>
			<div class="col-md-4 col-sm-4 col-xs-4 sgb badgepart">
			<?php if($sgbadge[0]['isSG']>0) { ?>
				 <p style="font-size: 20px;  margin:0;"><a id="" class="certification_sa" style="text-decoration: none;" data-type="sg" data-val="<?php echo 100; ?>" href="javascript:;" title="Super Goer Badge">
					<img src="<?php echo base_url(); ?>assets/images/popup/supergoerweb.png" style="width: 30px;"/><a style="top:-5px;position:relative;" href="javascript:;" data-toggle="tooltip" data-placement="left" data-html="true" title='<div class=""><div class="toolbadgehe">Super Goer Badge </div><span style="font-size:12px;">Maximum Games Played User</span></div>'><i  style="color:white; font-size:16px;" class="fa fa-info-circle"></i></a></a>
				</p>
			<?php } ?>
			</div>
			<p class="col-md-12 col-sm-12 col-xs-12" style="font-size:13px;padding:0px;margin:0px;">*Click your earned badges to download your E-certificate</p>
	</div>		
  </div>
<?php } ?> 
  
  </div><!--/row -->
  </div><!--/container -->
</div><!--/section_two -->
  
	<div class="container" style="background-color: indianred;text-align: center;">
	<div class="section2">
	

	
	
	</div></div>
	<div class="clear_both"></div>
	<div class="section_three" id="mainmenu">
	
	<div class="container">
	 <nav class="navbar navbar-default navbar-fixed-top">
	       <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar1" aria-expanded="false" aria-controls="navbar1">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
		  
        </div>
	      <div id="navbar1" class="navbar-collapse collapse">
         
          <ul class="nav navbar-nav">
			<li <?php if($this->uri->segment(2)=="myprofile" || $this->uri->segment(2)=="profile" ){echo 'class="activereport"';}?> ><a href="<?php echo base_url("index.php/home/profile#View") ?>">Profile  </a></li> 

			<?php 
			$currdate=date('Y-m-d');
			if($this->session->bstartdate <= $currdate/*  && $this->session->isbraintest==1 */){ ?>
<?php if($this->session->game_grade==8 || $this->session->game_grade==9 || $this->session->game_grade==10 || $this->session->game_grade==12 || $this->session->game_grade==13 || $this->session->game_grade==14 || $this->session->game_grade==15)
			{
				?>

			<!--<li <?php if($this->uri->segment(2)=="iaschallenge"){echo 'class="activereport"';}?> ><a href="<?php echo base_url("index.php/home/iaschallenge") ?>">HOTS Olympiad</a></li>-->
			<?php } } 
			if($isIAS==0){ ?>
			<li <?php if($this->uri->segment(2)=="dashboard"){echo 'class="activereport"';}?> ><a href="<?php echo base_url("index.php/home/dashboard#View") ?>">Puzzles</a></li>
			<?php } ?>

			<!--- <li <?php if($this->uri->segment(1)=="reports"){echo 'class="activereport"';}?> > <a href="<?php echo base_url("index.php/reports/reportslist#View") ?>">My Reports</a></li>-->

			<!--<li <?php if($this->uri->segment(1)=="reports"){echo 'class="activereport"';}?> > <a href="<?php echo base_url("index.php/reports/reportslist1#View") ?>">Reports</a></li>-->
			
			<li <?php if($this->uri->segment(2)=="reports"){echo 'class="activereport"';}?> > <a href="<?php echo base_url("index.php/home/reports#View") ?>">Reports</a></li>
			<!--<li <?php if($this->uri->segment(2)=="mybrainprofile"){echo 'class="activereport"';}?> ><a href="<?php echo base_url("index.php/home/mybrainprofile#View") ?>">Brain Profile </a></li>-->
			<li <?php if($this->uri->segment(2)=="mytrophies"){echo 'class="activereport"';}?> ><a href="<?php echo base_url("index.php/home/mytrophies#View") ?>">Trophies </a></li>
			<!--<li <?php if($this->uri->segment(2)=="mybadges"){echo 'class="activereport"';}?> ><a href="<?php echo base_url("index.php/home/mybadges#View") ?>">Badges </a></li>-->
			<!--<li <?php if($this->uri->segment(2)=="leaderboard"){echo 'class="activereport"';}?> ><a href="<?php echo base_url("index.php/home/leaderboard#View") ?>"> Leader Board </a></li>-->
			<!--<li <?php if($this->uri->segment(2)=="mythemes"){echo 'class="activereport"';}?> ><a href="<?php echo base_url("index.php/home/mythemes#View") ?>">Themes</a></li>-->
			<?php if($skillkitenable[0]['isenable']>0){ $class="class='menuhighlight'"; } else{$class="";}?>
			<?php if($isIAS==0){ ?>
			<li <?php if($this->uri->segment(2)=="skillkit"){echo 'class="activereport"';}?> ><a <?php echo $class; ?> href="<?php echo base_url("index.php/home/skillkit") ?>">Skill Kit </a></li>
			<?php } ?>



			<?php if(!isset($this->session->user_id))
			{ ?>
			<?php 
			} else { ?>

			<li><a href="javascript:;" class="loginLink">Logout</a></li>
			<?php } ?>
        
          </ul>
		  
        </div><!--/.nav-collapse -->
		</nav>
	</div><!--/container -->
	</div><!--/section_three -->

	</div>
	
<script src="<?php echo base_url(); ?>assets/js/hover/sparkleHover.js"></script>

<div style="display:none;margin: auto;position: absolute;" >
<div  id="sparkiesimg" style="margin: auto;position: absolute;"><span id="visiblepoints" style="margin: auto;position: absolute;">Wow!  You have gained  <?php echo $sparkiesloginpointval; ?> Crownies today!</span><img  src="<?php echo base_url(); ?>assets/images/sparkies/6.gif" alt="sparkies"/></div>
 </div> 
<input type="hidden" value="<?php echo $sparkiesloginpointval; ?>" name="hdnsparkiespoints" id="hdnsparkiespoints" />

<script>

$(function () {
	//alert("hjojo");
   $('[data-toggle="tooltip"]').tooltip();
	
});

$(document).ready(function() { //alert("hjojo");
<?php if ($this->session->user_id && isset($this->session->issparkies)){ 
if($this->session->sparkiespoints!=0){
?>
/* $(window).load(function(){        
	$('#welcomemsg').modal({backdrop: 'static', keyboard: false}) ;
}); */
$("#welcomemsg .clspopup").click(function()
{	//alert("JJJ");
	sparkies();
	<?php //if($this->session->isteachers_popup==1) { ?>
	//setTimeout(function(){  $('#teachersmodal').modal({backdrop: 'static', keyboard: false}) ;  }, 5000);
	<?php //} ?>
	

});
$('#welcomemsg').modal({backdrop: 'static', keyboard: false}) ;

<?php  } } 
?>
<?php 
if($this->session->skillkitactive > 0){ ?>
var skillkit = <?php echo $this->session->skillkitactive; ?>;
<?php if($isIAS==0){ ?>
skillkitpopup();
$('#skillkitpopup').modal({backdrop: 'static', keyboard: false}) ; 
<?php } ?>
<?php }  ?>

});

//$('#skillkitclose').click(function(){
$(document).on('click', '#skillkitclose', function(){ 
<?php $this->session->unset_userdata('skillkitactive','');	?>
	$('#skillkitpopup').modal('hide');
});

$('#skyangelspoints').sparkleHover(); 

$('.certification_sa').click(function(){
	
	var score = $(this).data('val');
	var type = $(this).data('type');
	//alert(type);
	$.ajax({
			type: "POST",
			url: "<?php echo base_url()."index.php/home/ecertificate"; ?>",
			data: {score:score,type:type},
			dataType: "json",
			success: function(result){
				//alert(result);
			$("#cert1").attr("src",result.file_url);
			$("#cert1download").attr("download",result.file_name);
			$("#cert1download").attr("href",result.file_url);
			$('#imagemodal').modal('show').find('.modal-body').load($(this).attr('href'));	
			//window.open(result, '_blank');	
			}
	});	
});   
</script>
<script>
$(window).load(function(){//alert("logout");
      $("#mainmenu").sticky({ topSpacing: 0 });
});
</script>

 <div class="modal fade" data-easein="bounceIn" id="skillkitpopup" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
     <div class="">
        <div class="modal-body skillkitmodal"  style="" >
	<div style="padding-top:80px">
			<h2 class="modal-title" style="text-align:center;padding-bottom:0"></h2>
			<div style="text-align:center;position: relative;padding: 5%;">
			<h3 style="color:#ff6600"> Hi <?php echo $this->session->fname; ?>,</h3>
          <div class="fdbkcontent" style="font-size: 20px; width:70%; margin:0 auto;">Do you need any help in playing <span id="skillkits"></span>… </br>Please ask to your teacher!<br/>
		  You can improve this skill by using the skill kit in your page…<br/>
		  Lets play again !</div>
		</div>
	</div><br/>
	<br/>
	
				 <div style="text-align:center;">
				 <a href="<?php echo base_url(); ?>index.php/home/skillkit" class="btn btn-success" id="" >Ok</a> 
				<!-- <button type="button" class="btn btn-danger" id="skillkitclose">ok</button>-->
				 
				 </div>
        </div>
         
      </div>
	  
	 
      
    </div>
  </div>
  
  <div class="modal fade" data-easein="bounceIn" id="incompletemodal" role="dialog">
    <div class="modal-dialog">
      <!-- Modal content-->
      <div class="">
        <div class="modal-body incompleteday"  style="" >
	<div style="padding-top:80px">
			<h2 class="modal-title" style="text-align:center;padding-bottom:0"> Hey <?php echo $this->session->fname; ?>, Wait!!   </h2>
			<div style="text-align:center">
          <h2 class="fdbkcontent">You have not finished the entire session. </h2>
		<div style="font-size: 25px;">Do you want to leave?</div>
		</div>
	</div><br/>
				 <div style="text-align:center;">
				 <button type="button" class="btn btn-success" id="" data-dismiss="modal">Continue</button> 
				 <button type="button" class="btn btn-danger" id="logoutbtn">Logout</button>
				 </div>
        </div>
      </div>

    </div>
  </div>
  
  <div class="modal fade" data-easein="bounceIn" id="feedbackmodal" role="dialog">
    <div class="modal-dialog">
      <!-- Modal content-->
      <div class="" style="">
        <div class="modal-body sessionpopup"  style=" " >
			<h2 class="modal-title" style="text-align:center;padding-bottom:0">  </h2>
			<div style="text-align:center;position: relative;padding: 15%;">
			<h3 style="color:#ff6600">Hey <?php echo $this->session->fname; ?>!</h3>
          <div class="fdbkcontent" style="font-size: 23px;">Will be eager to see you for your next session</div>
		<div style="font-size: 23px;" id="dateday"></div>
		<!--<br/><div style="font-size: 25px;" id="time"></div>-->
	</div>
				 <div style="text-align:center;"><button type="button" class="btn btn-success" id="fbksubmit" data-dismiss="modal">Logout</button></div>
        </div>

      </div>
	  
	 
      
    </div>
  </div>
  
  
  <div class="modal fade" data-easein="bounceIn" id="welcomemsg" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="">
        
        <div class="modal-body welcomemsgpopup"  style="" >
	<div style="padding-top:80px">
			<!--<h2 class="modal-title" style="text-align:center;padding-bottom:0"> Hey <?php echo $this->session->fname; ?>, Wait!!   </h2>-->
			<div style="text-align:center">
          <div class="fdbkcontent welcontent <?php echo $this->session->firstlogincls; ?> <?php echo $this->session->commonmsg; ?>" style="padding-left: 150px;padding-right: 150px;"><?php echo $this->session->greetings_content; ?></div>
		</div>
	</div><br/>
				 <div style="text-align:center;">
				 <button type="button" class="btn btn-success clspopup" id="" data-dismiss="modal">OK</button> 
				<!-- <button type="button" class="btn btn-danger" id="logoutbtn">Logout</button>--->
				 
				 </div>
        </div>
         
      </div>
	  
	 
      
    </div>
  </div>
  
  <div class="modal fade" data-easein="bounceIn" id="imagemodal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
		<h4 class="modal-title">E-Certificate</h4>
      </div>
        <div class="modal-body"  style="border: 10px solid rgba(0, 0, 0, 0.41);" >
	
			<h2 class="modal-title" style="text-align:center;padding-bottom:0"> Hey <?php echo $this->session->fname; ?>, Here's Your E-Certificate !!   </h2>
			<div style="text-align:center">
			<img id="cert1" src="" style="width:550px" >
		
	</div><br/>
				 <div style="text-align:center;">
				 <a href="" class="btn btn-success" download="" target="_blank" id="cert1download" ><i class="fa fa-download"></i>Download</a>
				 <!--<button type="button" class="btn btn-warning printMe" id="">Print</button>-->
				 
				 </div>
        </div>
         
      </div>
	  
	 
      
    </div>
  </div>
  
  <div id="todayModal" class="modal fade" role="dialog">
  <div class="modal-dialog modal-lg" id="welcomecontainer">
    <!-- Modal content-->
    <div class="modal-content" style="box-shadow: none;border: none;">
      <div class="modal-header" style="text-align:center;">
<button type="button" class="close" data-dismiss="modal" style="color: #000;opacity: 1;font-size: 30px;
">&times;</button>
			<h3 class="modal-title" id="curday" style="text-align: center;"></h3>
      </div>
      <div class="modal-body"  style="padding:0px;">
	  <div class="gameplayeddata">
	   <div class="col-md-12 col-sm-12 col-xs-12" style="margin-top: 10px;">
	   
	   <div class="col-md-3 col-sm-3 col-xs-12 "><div class="col-md-12 col-sm-12 col-xs-12 counters" >Questions Attempted</div><div class="col-md-12 col-sm-12 col-xs-12 counters"  id="CURPuzzlesAttempted"></div></div>
	   
	    <div class="col-md-3 col-sm-3 col-xs-12 "><div class="col-md-12 col-sm-12 col-xs-12 counters" >Questions Solved</div><div class="col-md-12 col-sm-12 col-xs-12 counters"  id="CURPuzzlesSolved"></div></div>
		
		 <div class="col-md-3 col-sm-3 col-xs-12 "><div class="col-md-12 col-sm-12 col-xs-12 counters">Minutes Trained</div><div class="col-md-12 col-sm-12 col-xs-12 counters"  id="CURMinutesTrained"></div></div>
		 
		  <div class="col-md-3 col-sm-3 col-xs-12 "><div class="col-md-12 col-sm-12 col-xs-12 counters" >Crownies</div><div class="col-md-12 col-sm-12 col-xs-12 counters"  id="CURCrownies"></div></div>
	   </div></div>
	   
	   
	  <div class="col-md-12 col-sm-12 col-xs-12 text-center">
			<div class="col-md-6 col-sm-6 col-xs-12 text-center">
				<h2 class="Mh2">Skill Score</h2>
					<div class="panel panel-default" style="background: #fff;">
                        <div class="panel-body">
					<div class="reportChartContainer1">
                            <div class="cb">
                            	<p class="PskillName pt0">Memory</p>
                                	
                            	<div class="meter mt10">
                                	<span class="redColor" id="mem"></span>
								</div>
                            </div>
                            <div class="cb">
                            	<p class="PskillName">Visual Processing</p>
                            	<div class="meter mt10">
  									<span class="yellowColor" id="vp"></span>
								</div>
                            </div>
                            <div class="cb">
                            	<p class="PskillName">Focus & Attention</p>
                            	<div class="meter mt10">
  									<span class="greenColor" id="focus"></span>
								</div>
                            </div>
                            <div class="cb">
                            	<p class="PskillName">Problem Solving</p>
                            	<div class="meter mt10">
  									<span class="orangeColor" id="problem"></span>
								</div>
                            </div>
                            <div class="cb">
                            	<p class="PskillName">Linguistics</p>
                            		<div class="meter mt10">
  										<span class="blueColor" id="ling"></span>
									</div>
                            </div>
                     </div>
				
				</div>
				</div>
			</div>
			
			<div class="col-md-6 col-sm-6 col-xs-12">
			<h2 class="Mh2">BSPI</h2>
			<div id="score" class="block"  style="text-align:center; font-size: 25px;font-weight: bold;"></div>
			<div id="chart-container"  style=""></div>

			</div>
			
			</div>
			
      </div>
    </div>
  </div>
</div>
<!-- ................ Welcome PopuP End...................--->

 <div id="jobprofile" class="modal fade" role="dialog">
  <div class="modal-dialog modal-lg" id="welcomecontainer">
    <!-- Modal content id="<//?php echo $row['occupationid']; ?>"-->
    <div class="modal-content" style="box-shadow: none;border: none;">
      <div class="modal-header" style="text-align:center;">
		<button type="button" class="close" data-dismiss="modal" style="color: #000;opacity: 1;font-size: 30px;
		">&times;</button>
		
			<h3 class="modal-title" id="curday" style="text-align: center;line-height: 50px;font-weight: 600;" ><?php echo $getjobprofile[0]['occupation']; ?></h3>
      </div>
      <div class="modal-body"  style="padding:0px;">
	  <div style="padding-top:20px"> 
			<div style="text-align:center">
			<div class="fdbkcontent welcontent" style="padding-left: 150px;padding-right: 150px;line-height: 45px;font-weight: 550;font-size: 30px;color:#da0404 ">Abilities</div>
			
			<?php $i=1;
						foreach($getjobprofile as $row)
						{ 
						?>
			
			
			
				<div class="fdbkcontent welcontent" style="padding-left: 150px;padding-right: 150px;line-height: 45px;font-weight: 500;font-size: 25px; color:#92d050"><?php echo $row['subability']; ?>(<?php echo $row['abilityvalue']; ?>%)</div>
				<div class="fdbkcontent welcontent" style="padding-left: 150px;padding-right: 150px;font-weight: 450;line-height: 40px;font-size: 25px;"><?php echo $row['description']; ?></div>
				<?php
						$i++;
						} 
						?>
				<div class="fdbkcontent welcontent" style="padding-left: 150px;padding-right: 150px;font-weight: 550;line-height: 50px;font-size: 30px;color:#ffc000">Skill</div>
				<?php $j=1;
						foreach($getskilldata as $row1)
						{ 
						?>
				<div class="fdbkcontent welcontent" style="padding-left: 150px;padding-right: 150px;font-weight: 500;line-height: 45px;font-size: 25px;color:#ff6600"><?php echo $row1['subskill']; ?>(<?php echo $row1['skillvalue']; ?>%)</div>
				<div class="fdbkcontent welcontent" style="padding-left: 150px;padding-right: 150px;font-weight: 450;line-height: 40px;font-size: 25px;"><?php echo $row1['description']; ?></div>
				<?php
						$j++;
						} 
						?>
			</div>
		</div>
	    <div style="text-align:center;">
			<button type="button" class="btn btn-success clspopup" id="" data-dismiss="modal">OK</button> 	
		</div>
      </div>	
    </div>
  </div>
</div>


<!--.. Welcome Popup Modal Open ..-->
<?php if ($this->session->user_id && isset($this->session->issparkies)){ 
if($this->session->sparkiespoints!=0){ ?>
<script src="<?php echo base_url(); ?>assets/js/createjs-2015.11.26.min.js"></script>
<script src="<?php echo base_url(); ?>assets/js/Greetings.js?1519122690690"></script>
<script>
$(document).ready(function() { 
		//init();
		
		$('#welcomemsg').modal('show');
});


//var canvas, stage, exportRoot, anim_container, dom_overlay_container, fnStartAnimation;
//var msg='<?php echo $this->session->greetings_content; ?>';
// function init() {
	// canvas = document.getElementById("canvas");
	// anim_container = document.getElementById("animation_container");
	// dom_overlay_container = document.getElementById("dom_overlay_container");
	// var comp=AdobeAn.getComposition("3E5EE9899C98464BB5D75A2EE3451710");
	// var lib=comp.getLibrary();
	// handleComplete({},comp);
// }
/* function handleComplete(evt,comp) {
	//This function is always called, irrespective of the content. You can use the variable "stage" after it is created in token create_stage.
	var lib=comp.getLibrary();
	var ss=comp.getSpriteSheet();
	exportRoot = new lib.Greetings();
	stage = new lib.Stage(canvas);	
	//Registers the "tick" event listener.
	fnStartAnimation = function() {
		stage.addChild(exportRoot);
		createjs.Ticker.setFPS(lib.properties.fps);
		createjs.Ticker.addEventListener("tick", stage);
	}	    
	//Code to support hidpi screens and responsive scaling.
	function makeResponsive(isResp, respDim, isScale, scaleType) {		
		var lastW, lastH, lastS=1;		
		window.addEventListener('resize', resizeCanvas);		
		resizeCanvas();		
		function resizeCanvas() {			
			var w = lib.properties.width, h = lib.properties.height;			
			//var iw = window.innerWidth, ih=window.innerHeight;			
			var iw = $("#welcomecontainer").width(), ih=window.innerHeight; //alert(iw);
			var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
			if(isResp) {                
				if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
					sRatio = lastS;                
				}				
				else if(!isScale) {					
					if(iw<w || ih<h)						
						sRatio = Math.min(xRatio, yRatio);				
				}				
				else if(scaleType==1) {					
					sRatio = Math.min(xRatio, yRatio);				
				}				
				else if(scaleType==2) {					
					sRatio = Math.max(xRatio, yRatio);				
				}			
			}			
			canvas.width = w*pRatio*sRatio;			
			canvas.height = h*pRatio*sRatio;
			//canvas.style.width = dom_overlay_container.style.width = anim_container.style.width =  w*sRatio+'px';				
			canvas.style.width = dom_overlay_container.style.width = anim_container.style.width =  '100%';				
			//canvas.style.height = anim_container.style.height = dom_overlay_container.style.height = h*sRatio+'px';
			stage.scaleX = pRatio*sRatio;			
			stage.scaleY = pRatio*sRatio;			
			lastW = iw; lastH = ih; lastS = sRatio;            
			stage.tickOnUpdate = false;            
			stage.update();            
			stage.tickOnUpdate = true;		
		}
	}
	makeResponsive(true,'both',false,1);	
	AdobeAn.compositionLoaded(lib.properties.id);
	fnStartAnimation();
} */
</script>

<?php 	}} ?>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/menu/jquery.sticky.js"></script> 
<script src="<?php echo base_url(); ?>assets/js/jquery_easing.js"></script>
<!-- Sweet Alert -->
<!-- This is what you need -->
<script src="<?php echo base_url(); ?>assets/js/sweetalert/sweetalert2.js"></script>
<link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/sweetalert/sweetalert2.min.css">
<!--.......................-->
<script>
function sparkies()
{ //alert("hjhjjh");
		$(".loader").show();
        var cart = $('.points-cart-img');
        var imgtodrag = $("#sparkiesimg").eq(0); //console.log(imgtodrag);
		var points=$("#sparkiespoints").text();
		//var imgtodrag = $(this).parent('.bounceIn').find("img").eq(0);
        if (imgtodrag) {
            var imgclone = imgtodrag.clone()
                .offset({
                top: "350",
                left: "550"
            })
                .css({
                'opacity': '0.9',
                    'position': 'absolute',
                    'height': '150px',
                    'width': '150px',
                    'z-index': '99999',
		

            })
                .appendTo($('body'))
                .animate({
					'top': cart.offset().top + 10,
                    'left': cart.offset().left + 10,
                    'width': 200,
                    'height': 200
            }, 2000, 'easeInOutExpo');
            
            setTimeout(function () {
                cart.effect("shake", {
                    times: 2
                }, 200);
				
            }, 1500);

            imgclone.animate({
                'width': 0,
                    'height': 0
            }, function () {
                $(this).detach();
				$(".loader").hide();
				if($("#hdnsparkiespoints").val()!='' && $("#hdnsparkiespoints").val()!='0')
				{   var total_skyangels=$('#skyangelspoints').text();
					var current_skyangels=$("#hdnsparkiespoints").val();
					//alert(parseInt(total_skyangels)+parseInt(current_skyangels));
					$('#skyangelspoints').text(parseInt(total_skyangels)+parseInt(current_skyangels));
					$("#hdnsparkiespoints").val('');$("#visiblepoints").val('');
						$('#jobprofile').modal({backdrop: 'static', keyboard: false}) ;
						<?php 
						$this->session->unset_userdata('issparkies',0);	
						$this->session->unset_userdata('sparkiespoints',0);
						?>
					Celebration();
					
				}
				
            });
			
			
        }
}

<!--$('#jobprofile').modal({backdrop: 'static', keyboard: false}) ;	-->
</script>
							<!-- popup side nav-->
<div id="jobProfilenav" class="sidenav">

	<div class="">
		<a href="javascript:void(0)" class="closebtn" onclick="closeNav()"><i class="fa fa-window-close" aria-hidden="true"></i></a>
</div>
	
	<div class="">
		<div class="col-md-12 col-sm-12 col-xs-12 starclsnew" style="background: #fafafa;">		
			
			<div class="clear_both"></div>	
			<div class="sectiona" id="report">
				<div class="container">
					<div class="row">	
					
					<div class="modal-body"  style="padding:0px;">
	  <div style="padding-top:20px"> 
								
			<h3 style="background: #faa400;padding: 10px;color: #fff;font-size: 30px;">Jobbb Profile</h3>
			<h3> <?php echo $getjobprofile[0]['occupation']; ?></h3>
			<center><h2><?php echo $getjobprofile[0]['subsector']; ?></h2>
			<p><?php echo $getjobprofile[0]['description']; ?></p></center>	
	
					
					<!--	<div id="profile"></div>	-->
						
					</div>
				</div>
			</div>	
		</div>	
	</div>	
</div>

<script>
function openNav() {//alert("eddd");
		$(".btmbar").css("z-index","99");
		$("#myBtn").css("z-index","99");
		
		document.getElementById("jobProfilenav").style.width = "100%";
	}

	function closeNav() {
		document.getElementById("jobProfilenav").style.width = "0";
		$(".btmbar").css("z-index","9999");
		$("#myBtn").css("z-index","99999");
	}

 /* $(function () {
   $('[data-toggle="tooltip"]').tooltip();
	
});  */


</script>

<script>
/*  */

</script>




<style>
p {
	font-weight: 550;
    font-size: 30px;
    line-height: 45px;
    color: #000;

}
</style>
<div class="jb">
<a href="javascript:;" class="vprofile" id="vprofile" onclick="openNav()">View Jobprofileee</a>
</div>