<!DOCTYPE html>
<html lang="en"> 
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=yes">
<title>Skillangels</title> 

<!-- Bootstrap --> 
<link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/bootstrap.min.css">	 
<link href="<?php echo base_url(); ?>assets/css/font-awesome.min.css" rel="stylesheet">
<link href="<?php echo base_url(); ?>assets/css/nprogress.css" rel="stylesheet">
 <link href="<?php echo base_url(); ?>assets/css/animate.min.css" rel="stylesheet">
<link href="<?php echo base_url(); ?>assets/css/custom.min.css" rel="stylesheet"> 
  
  <script src="<?php echo base_url(); ?>assets/js/jquery.min.js"type="text/javascript"></script>
  <script src="<?php echo base_url(); ?>assets/js/bootstrap.min.js"type="text/javascript"></script>
  <script src="<?php echo base_url(); ?>assets/js/jquery.validate.js"></script>
  <style>
.ed6 {
    color: rgb(0, 170, 255);
    font-family: "Shadows Into Light",cursive;
    font-size: 2em;
}
.LoginContainer
{
	    BORDER: 2px solid;
    width: 50%;
    margin-left: 25%;
}
.submitlabel{padding-top:20px;padding-bottom:20px;}
.LoginContainer .fields{text-align:right;}
footer {
    margin-left: 0px !important;
	 color: #73879C;
}
input
{	 color: #73879C;
}
.landingContainer{padding-bottom:20px;}
body {
    color: #ffffff;
}

#lnkforgetpwd{
    width:200px;
    height:32px;
	font-weight:500;
	font-size:20px;
	color:#ff9800;
    
}
b, h4 {
    font-weight: 700;
    color: #2A3F54;
}
#successmsg{
	 color: #2A3F54;
}
label {
    display: inline-block;
    max-width: 100%;
    margin-bottom: 5px;
    font-weight: 700;
    color: #fff;
}
</style>
</head>
 
<div class="login_wrapper">
    <div class="animate form login_form">
	  <div align="center"><img style="width: 200px;display: block;" src="<?php echo base_url(); ?>assets/images/web_logo.png" /><strong><span class="ed6">EdSix Brain Lab<sup>TM</sup> Pvt Ltd</span><br>Incubated by IIT Madras' RTBI<br>
					Supported by IIM Ahmedabad's CIIE and Village Capital, U.S.A</strong> 
		</div>
               <section class="login_content">
             
              <h1>Reset Password</h1>
			   <div class="green"></div>
					<div class="" style="padding-bottom: 20px; color:red; text-shadow:none;"><?php echo $msg_error;?></div>
					
		<form class="form-horizontal" role="form" name="frmRP" id="frmRP" method="POST">
			<div class="panel-body"><div id="msgRP" style="font-size: 18px;"></div>	
			<div class="form-group"> 
				<input type="password" name="newpassword" value="" class="form-control required" placeholder="New password" id="newpassword">
			</div>
			<div>
				<input type="password" name="confirmpwd" value="" class="form-control required" placeholder="Confirm Password" id="confirmpwd">
			</div>
				<div id="successmsg"> </div>
			</div>
			<div>
                <input type="submit" class="btn btn-success" style="float:right;" id="submit" name="submit" value="Submit"> 
             </div>
	  </form>
			 
             
          </section>
		  </div></div></div>  
		</div>
			
						
<script>
$(document).ready(function () {	
	
	$("#frmRP").validate({
			rules: {
			"newpassword": {required: true,minlength:8},
			"confirmpwd": {required: true,equalTo: "#newpassword"}
			},
			messages: {
			"newpassword": {required: "Please enter password"},
			"confirmpwd": {required: "Please enter confirm password",equalTo: "Password does not match"},
			},
			errorPlacement: function(error, element) {
			error.insertAfter(element);
			},
			highlight: function(input) {
			$(input).addClass('error');
			}
		}); 
	
	/* $("#submit").click(function(){
		//alert("hlo");
	//	var newpassword=$("#newpassword").val();//alert(email);
	//	var confirmpwd=$("#confirmpwd").val();//alert(email);
		if($("#frmRP").valid())
		{
		
			$.ajax({
					url: "<?php echo base_url(); ?>index.php/home/changepassword",
					type:"POST",
					//dataType:"json",
					data:{newpassword:$("#newpassword").val(),confirmpwd:$("#confirmpwd").val()},
					success: function (result) 
					{
						//alert("hii");
						 if(result==1)
						{
							$("#newpassword").attr('readonly', 'readonly');
							$("#msgRP").css("margin-bottom","10px").html("<div style='color:green;font-size: 19px;'>Password has been successfully changed!!!</div>");
							$('#submit').hide();
						}
						else
						{	
							$("#msgRP").css("margin-bottom","10px").html("<div style='color:red'>Mismatch Password</div>");
							$('#submit').show();
						}  
					}
				});
		}
	});  */
});


</script>			

  
		 
 