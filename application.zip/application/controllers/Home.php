<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	  public function __construct()
        {
                // Call the CI_Model constructor
                parent::__construct();
				$this->load->model('Dashboard_model');
				$this->load->library('session');			
				$this->load->library('My_PHPMailer');	
				$this->load->library('user_agent');
        }
		
	public function index()
	{			
		//$this->load->view('header');
		$this->load->view('index');
		//$this->load->view('footer');
		
	}
	
	public function logincheck()
	{	

	
			$data['query'] = $this->Dashboard_model->checklogin($this->input->post('username'),md5($this->input->post('password')));
		//	echo $data['query'][0]['school_id']; exit;
			if(isset($data['query'][0]['id'])){ 
			
			$date1 = $data['query'][0]['school_startdate'];
			$date2 = $data['query'][0]['endate'];

			$ts1 = strtotime($date1);
			$ts2 = strtotime($date2);

			$year1 = date('Y', $ts1);
			$year2 = date('Y', $ts2);

			$month1 = date('m', $ts1);
			$month2 = date('m', $ts2);

			$month_diff = (($year2 - $year1) * 12) + ($month2 - $month1)+2;

			//echo $month_diff; exit;
			
			$this->session->set_userdata(array(
			
			'aid'       => $data['query'][0]['id'],
			'afname'       => $data['query'][0]['fname'],
			'schoolid'       => $data['query'][0]['school_id'],
			'startdate'       => $data['query'][0]['strdate'],
			'enddate'       => $data['query'][0]['endate'],
			'academicid'       => $data['query'][0]['acade_id'],
			'school_startdate'       => $data['query'][0]['school_startdate'],
			'percentage'       => $data['query'][0]['percentage'],
			'month_interval'       => $month_diff,
			
			));
			redirect('index.php/home/dashboard');
			}
			else {
				
			$this->session->set_flashdata('message', 'Invalid Login credentials');
				redirect(base_url());
			}
	
	
	}
	
	public function dashboard()
	{
		if($this->session->schoolid=="" || !isset($this->session->schoolid)){redirect('index.php');}
		$data['returnURL']=$this->agent->referrer();
		
		$schoolid = $this->session->schoolid;
		$data['schooldetails'] = $this->Dashboard_model->schooldetails($schoolid);
		$data['puzzledatas'] = $this->Dashboard_model->puzzledatas($schoolid,$this->session->startdate,$this->session->enddate);
		$data['totalusers'] = $this->Dashboard_model->totalusers($schoolid);
		$data['gradewiseuserscount'] = $this->Dashboard_model->gradewiseuserscount($schoolid);
		//$data['assessmentbspi_gradewise'] = $this->Dashboard_model->assessmentbspi_gradewise($schoolid);
		//$data['trainingbspi_gradewise'] = $this->Dashboard_model->trainingbspi_gradewise($schoolid);
		
		//$data['excepted_session'] = $this->Dashboard_model->excepted_session($schoolid);
	
		//$data['utilized_session'] = $this->Dashboard_model->utilized_session($schoolid);
		
		//$data['monthbspiscore'] = $this->Dashboard_model->monthbspiscore($schoolid);
		$data['mon'] = $this->Dashboard_model->requmonths($schoolid,$this->session->startdate,$this->session->enddate);
		$data['SchoolAvgBspi'] = $this->Dashboard_model->SchoolAvgBspi($schoolid,$this->session->startdate,$this->session->enddate);
		
		//$data['bspiutilization'] = $this->Dashboard_model->bspiutilization($schoolid,$this->session->startdate);
		//echo "<pre>";print_r($data['mon']);exit;
		
		$this->load->view('header', $data);
		$this->load->view('home', $data);
		$this->load->view('footer');
	}
	
	public function todaysession()
	{
		
		$schoolid = $this->session->schoolid;
		
		$data['schools'] = $this->Dashboard_model->todaysession($schoolid);
		$data['completeusers'] = $this->Dashboard_model->training_completedusers($schoolid);
		$this->load->view('today_session', $data);
	}
	
	public function getsessioninfo()
	{
		
		$grade = $this->input->post('grade');
		$section = $this->input->post('section');
		$sessiondate = $this->input->post('sessiondate');
		$schoolid = $this->session->schoolid;
		
		$data['regusers'] = $this->Dashboard_model->regusers($grade,$section,$schoolid);
		$data['trainingtaken'] = $this->Dashboard_model->trainingtaken($sessiondate,$grade,$section,$schoolid);
		$data['trainingfullytaken'] = $this->Dashboard_model->trainingfullytaken($sessiondate,$grade,$section,$schoolid);
		
		$data['grade'] = $this->input->post('grade');
		$data['section'] = $this->input->post('section');
		$data['sessiondate'] = $this->input->post('sessiondate');
		
		
		$this->load->view('popup_timetable', $data);
		
	}
	
	public function timetable()
	{
		//echo "<pre/>";print_r($_REQUEST);exit;
		$schoolid = $this->session->schoolid;
		
		$data['timetable'] = $this->Dashboard_model->timetable($schoolid);
		
		$data['SLeaveList'] = $this->Dashboard_model->leavelist($schoolid);
		
		$arr=array();
		foreach($data['SLeaveList'] as $row)
		{
			$arr[$row['ldates']]=$row['ldates'];
		}
		$data['LeaveList']=$arr;
		
		$data['startdate']=$_POST['startdate'];
		$data['e1']=$_POST['enddate'];
		
		$this->load->view('timetable', $data);
	}
	
	public function eom()
	{
		if($this->session->schoolid=="" || !isset($this->session->schoolid)){redirect('index.php');}
		$data['returnURL']=$this->agent->referrer();
		
		$schoolid = $this->session->schoolid;
		$data['schooldetails'] = $this->Dashboard_model->schooldetails($schoolid);
		$data['puzzledatas'] = $this->Dashboard_model->puzzledatas($schoolid,$this->session->startdate,$this->session->enddate);
		$data['academicMonths'] = $this->Dashboard_model->academymonths($this->session->school_startdate);
		$data['gradewiseuserscount'] = $this->Dashboard_model->gradewiseuserscount($schoolid);
		$this->load->view('header', $data);
		$this->load->view('eom');
		$this->load->view('footer');
		
	}
	
	public function ajax_eom_summaryofutilization()
	{
		//echo 'test'; exit;
		$schoolid = $this->session->schoolid;
		$percentage=$this->session->percentage;
		//echo $this->input->post('month'); exit;
		$month = explode("/",$this->input->post('month'));
		$exestartdate=explode("-",$month[0]);
		$exeenddate=explode("-",$month[1]);
		$startdate=$exestartdate[2]; 
		$enddate=$exeenddate[2];
		
		$grade_id=$this->input->post('grade');
		
		$data['arrtotsession'] = $this->Dashboard_model->newqryregattenduser($schoolid,$month[0],$month[1],$grade_id);
		$data['arrattendsession'] = $this->Dashboard_model->newqrycompleteduser($schoolid,$month[0],$month[1],$percentage,$grade_id);
		$data['regattenduser'] = $this->Dashboard_model->qryregattenduser($schoolid,$month[0],$month[1],$grade_id);
		$data['completeduser'] = $this->Dashboard_model->qrycompleteduser($schoolid,$month[0],$month[1],$grade_id);
		
		$this->load->view('ajax_eom_summaryofutilization', $data);
		
	}
	
	public function bspirange()
	{
		//echo 'test'; exit;
		$schoolid = $this->session->schoolid;
		//echo $this->input->post('month'); exit;
		
		$month = explode("/",$this->input->post('month'));
		$exestartdate=explode("-",$month[0]);
		$exeenddate=explode("-",$month[1]);
		$startdate=$exestartdate[2]; 
		$enddate=$exeenddate[2];
		
		$grade=$this->input->post('grade');
		
		$data['asapcount'] = $this->Dashboard_model->getasapbspirangecount($schoolid,$month[0],$month[1],$grade);
		$data['clpcount'] = $this->Dashboard_model->getclpbspirangecount($schoolid,$month[0],$month[1],$grade);
		
		
		$a1=explode("-",$month[0]);		
		$monthNumber=$a1[1];
		
		$data['Summary'] = $this->Dashboard_model->GetReportMessage($schoolid,$monthNumber,'SUMMARY');
		
		$data['monthNumber'] =$month;
		
		$this->load->view('ajax_bspirange', $data);
		
	}
	public function bspianalysislist()
	{
		$schoolid = $this->session->schoolid;
		$data['schooldetails'] = $this->Dashboard_model->schooldetails($schoolid);
		$type=$this->uri->segment('3');
		$startdate=$this->uri->segment('4');
		$enddate=$this->uri->segment('5');

		$data['userlist']=$this->Dashboard_model->bspianalysislist($schoolid,$startdate,$enddate,$type);
		
		
		$this->load->view('header', $data);
		$this->load->view('bspianalysislist', $data);
		$this->load->view('footer');	
			
	}
	public function gradeuser()
	{
		if($this->session->schoolid=="" || !isset($this->session->schoolid)){redirect('index.php');}
		$data['returnURL']=$this->agent->referrer();
		
		$schoolid = $this->session->schoolid;
		$data['schooldetails'] = $this->Dashboard_model->schooldetails($schoolid);
		$grade_id=$this->uri->segment('3');
		$section='';
		$data['classname'] = $this->Dashboard_model->getGradeName($grade_id);
		$data['sectioncount'] = $this->Dashboard_model->GradeSecwiseUsersCount($schoolid,$grade_id,$section);
		//echo "<pre>";print_r($data['schooldetails']);exit;
		
		//$data['userskillscore']=$this->Dashboard_model->userscore_grade($schoolid,$grade_id,$data['schooldetails'][0]['start_date'],$section); 
		$data['asap_reports'] = $this->Dashboard_model->asap_reports($schoolid,$grade_id,$section);
		$data['clp_reports'] = $this->Dashboard_model->clp_reports($schoolid,$grade_id,$section); 
		
		$data['grade_id']=$grade_id;
		//echo "<pre>";print_r($data);exit;
		$this->load->view('header', $data);
		$this->load->view('gradeuser', $data);
		$this->load->view('footer');
	}
	public function sectionuser()
	{
		if($this->session->schoolid=="" || !isset($this->session->schoolid)){redirect('index.php');}
		$data['returnURL']=$this->agent->referrer();
		
		$schoolid = $this->session->schoolid;
		$data['schooldetails'] = $this->Dashboard_model->schooldetails($schoolid);
		$grade_id=$this->uri->segment('3');
		$section=$this->uri->segment('4');
		
		$data['classname'] = $this->Dashboard_model->getGradeName($grade_id);
		 
		//$data['sectioncount'] = $this->Dashboard_model->GradeSecwiseUsersCount($schoolid,$grade_id,$section);
		//echo "<pre>";print_r($data['schooldetails']);exit;
		
		/* $data['userskillscore']=$this->Dashboard_model->userscore_grade($schoolid,$grade_id,$data['schooldetails'][0]['start_date'],$section); */
		 
		 $data['asap_reports'] = $this->Dashboard_model->asap_reports($schoolid,$grade_id,$section);
		$data['clp_reports'] = $this->Dashboard_model->clp_reports($schoolid,$grade_id,$section); 
		 
		 
		$data['grade_id']=$grade_id;
		$data['gradename']=$data['classname'][0]['classname'];
		$data['section']=$section;
		$this->load->view('header', $data);
		$this->load->view('sectionuser', $data);
		$this->load->view('footer');
	}
	public function bspitopper_gradewise()
	{
		$schoolid = $this->session->schoolid;
		$month = explode("/",$_POST['month']);
		$exestartdate=explode("-",$month[0]);
		$exeenddate=explode("-",$month[1]);		
		$monthNumber=$exestartdate[1];
		
		$grade=$this->input->post('grade');
		
		$data['TotalGrade'] = $this->Dashboard_model->getTotalGrade($schoolid);
		
		$data['bspitopper_gradewise']=$this->Dashboard_model->bspitopper_gradewise($schoolid,$monthNumber,$grade);
		
		//$data['skilltopper_gradewise']=$this->Dashboard_model->skilltopper_gradewise($schoolid,$month[0],$month[1]);
		//echo "<pre>";print_r($data['userskillscore']);exit;
		
		$this->load->view('bspitopper_gradewise', $data);
		
	}
	public function sort_max($a,$subkey)
	{
						foreach($a as $k=>$v) {
							$b[$k] = strtolower($v[$subkey]);
						}
						arsort($b);
						foreach($b as $key=>$val) {
							$c[] = $a[$key];
						}
						return $c;
	}
	public function skilltopper_gradewise()
	{
		$schoolid = $this->session->schoolid;
		$month = explode("/",$_POST['month']);
		$exestartdate=explode("-",$month[0]);
		$exeenddate=explode("-",$month[1]);		
		$monthNumber=$exestartdate[1];
		
		$grade=$this->input->post('grade');
		
		$TotalGrade=$this->Dashboard_model->getTotalGradeSection($schoolid,$grade);
		$gradeid=$TotalGrade[0]['id'];
		$section=$TotalGrade[0]['section'];
		$a =explode ( ",", $section );
		$sec = "'" . implode ( "','", $a ) . "'";
		
		$skilltopper_gradewise=$this->Dashboard_model->MaxSkillScore_gradewise($schoolid,$month[0],$month[1],$gradeid,$sec);
		$aTop = array();
		foreach($skilltopper_gradewise as $skillTop)
		{
			$arrtopuser=$this->Dashboard_model->MaxSkillScore_gradewiseUser($schoolid,$month[0],$month[1],$skillTop['grade_id'],$skillTop['section'],$skillTop['maxscore'],$skillTop['gs_id']);
			foreach($arrtopuser as $topuser)
			{
				
				$aTop[$skillTop['grade_id']."-".$skillTop['section']."-".$skillTop['gs_id']][] = array(
										'name' => $topuser['name'],
										'score' => round($topuser['score'], 2)
										);
			}
			
		}
		
		$data['sections']=$TotalGrade;
		$data['aTop']=$aTop;
		//echo "<pre>";print_r($data);exit;
		
		$this->load->view('skilltopper_gradewise', $data);
		
	}
	public function eom_intervention()
	{
		$schoolid = $this->session->schoolid;
		$month = explode("/",$_POST['month']);
		$exestartdate=explode("-",$month[0]);
		$exeenddate=explode("-",$month[1]);		
		$monthNumber=$exestartdate[1];
		
		$grade=$this->input->post('grade');
		 
		$data['filter']=$this->input->post('filter');
		
		$data['TotalGradeSec'] = $this->Dashboard_model->getTotalGradeSection($schoolid,$grade);
		
		$bspiranges=$this->Dashboard_model->Eom_BspiRange($schoolid,$monthNumber,$grade);
		$notattendeduser=$this->Dashboard_model->Eom_NotAttendedUserCount($schoolid,$monthNumber,$grade);
		
		foreach($bspiranges as $key1=>$val1) {
			$query[$bspiranges[$key1]['grade_id'].'-'.$bspiranges[$key1]['section']]=$val1;
		}
		foreach($notattendeduser as $key7=>$val7) {
			$queryna[$notattendeduser[$key7]['grade_id'].'-'.$notattendeduser[$key7]['section']]=$val7['notatteneduser'];
		}
		
		foreach($bspiranges as $key1=>$val1) {
			if($bspiranges[$key1]['scorerange']=='<=20'){
			$query1[$bspiranges[$key1]['grade_id'].'-'.$bspiranges[$key1]['section']]=$bspiranges[$key1]['rangecount'];
			}
		}
		foreach($bspiranges as $key1=>$val1) {
			if($bspiranges[$key1]['scorerange']=='20-40'){
			$query2[$bspiranges[$key1]['grade_id'].'-'.$bspiranges[$key1]['section']]=$bspiranges[$key1]['rangecount'];
			}
		}
		foreach($bspiranges as $key1=>$val1) {
			if($bspiranges[$key1]['scorerange']=='40-60'){
			$query3[$bspiranges[$key1]['grade_id'].'-'.$bspiranges[$key1]['section']]=$bspiranges[$key1]['rangecount'];
			}
		}
		foreach($bspiranges as $key1=>$val1) { 
			if($bspiranges[$key1]['scorerange']=='60-80'){
			$query4[$bspiranges[$key1]['grade_id'].'-'.$bspiranges[$key1]['section']]=$bspiranges[$key1]['rangecount'];
			}
		}
		foreach($bspiranges as $key1=>$val1) {
			if($bspiranges[$key1]['scorerange']=='>80'){
			$query5[$bspiranges[$key1]['grade_id'].'-'.$bspiranges[$key1]['section']]=$bspiranges[$key1]['rangecount'];
			}
		}
		
		$data['query']=$query;
		$data['queryna']=$queryna;
		$data['query1']=$query1;
		$data['query2']=$query2;
		$data['query3']=$query3;
		$data['query4']=$query4;
		$data['query5']=$query5;
		
		
		
		$data['NotAttendedUser']=$this->Dashboard_model->Eom_NotAttendedUserList($schoolid,$monthNumber,$grade);
		$data['Twenty']=$this->Dashboard_model->Eom_Bspi_Twenty($schoolid,$monthNumber,$grade);
		$data['TwentytoForty']=$this->Dashboard_model->Eom_Bspi_TwentytoForty($schoolid,$monthNumber,$grade);
		$data['FortytoSixty']=$this->Dashboard_model->Eom_Bspi_FortytoSixty($schoolid,$monthNumber,$grade);
		$data['SixtytoEighty']=$this->Dashboard_model->Eom_Bspi_SixtytoEighty($schoolid,$monthNumber,$grade);
		$data['AboveEighty']=$this->Dashboard_model->Eom_Bspi_AboveEighty($schoolid,$monthNumber,$grade);
		
		
		
		$this->load->view('eom_intervention', $data);
	}
	
	public function logout(){
        // Unset User Data
        $this->session->sess_destroy();
        redirect(base_url());
    }
	
	public function GetNextPrevMonthDate()
	{
		$start_date=$this->input->post('fromdate');
		$end_date=$this->input->post('todate');
		$type=$this->input->post('type');
		if($type=='PREVMONTHS')
		{
			$currentmondate=$this->input->post('currentmondate');
			$start_date=date('Y-m-d',strtotime('first day of last month',strtotime($currentmondate)));
			$end_date=date('Y-m-d',strtotime('last day of last month',strtotime($currentmondate)));
			$monthofyear=date('M Y',(strtotime($start_date)));
			$date=array(
				'start_date'=>$start_date,
				'end_date' =>$end_date,
				'monthofyear'=>$monthofyear
			);
			echo json_encode($date);exit;
		}
		if($type=='NEXTMONTHS')
		{
			$currentmondate=$this->input->post('currentmondate');
			$start_date=date('Y-m-d',strtotime('first day of next month',strtotime($currentmondate)));
			$end_date=date('Y-m-d',strtotime('last day of next month',strtotime($currentmondate)));
			$monthofyear=date('M Y',(strtotime($start_date)));
			$date=array(
				'start_date'=>$start_date,
				'end_date' =>$end_date,
				'monthofyear'=>$monthofyear
			);
			echo json_encode($date);exit;
		}
	}	
	public function GetWeeks()
	{
		$start_date=$this->input->post('fromdate');
		$end_date=$this->input->post('todate');
		$type=$this->input->post('type');
		
		if($type=='WEEKS')
		{	
			echo '<ul class="liststyle">';
			$i=1;
			$monthofyear=date('M',(strtotime($start_date)));
			$dayofmonthstart=date('l',strtotime($start_date));
			//echo $start_date;
			if($monthofyear=='Feb' || $dayofmonthstart=='Sunday')
			{	$conddate = date('Y-m-d', strtotime($end_date.' + 6 days'));
			}	
			else
			{	$conddate=$end_date;
			}
			
			for($date = $start_date; $date <= $conddate; $date = date('Y-m-d', strtotime($date. ' + 7 days')))
			{
				$a=date('W');	
				$week =  date('W', strtotime($date));
				$year =  date('Y', strtotime($date));
				$from = date("Y-m-d", strtotime("{$year}-W{$week}+0"));//Returns the date of monday in week
				if($from < $start_date)$from = $start_date; 
				$to = date("Y-m-d", strtotime("{$year}-W{$week}-7"));//Returns the date of sunday in week
				if($to > $end_date) $to = $end_date;
				//if(date('l',strtotime($start_date))=='Sunday' && $i==1){$from=$date;$to=$date;}
				if($a==$week && $_REQUEST['loadtype']!='')
				{
					echo '<li class="col-md-20 col-lg-20 col-sm-20 col-xs-20">
						<div class="week common currentweek active" id="W'.$i.'" data-startdate="'.$from.'" data-enddate="'.$to.'">WEEK '.$i.'</div>
						</li>';
						$i++;
				}
				else
				{	if($_REQUEST['loadtype']!='ONLOAD' && $i==1 ){$class='active';}else{$class='';}
					if(date('l',strtotime($from))!='Sunday')
					{
						echo '<li class="col-md-20 col-lg-20 col-sm-20 col-xs-20">
							<div class="week common '.$class.'" id="W'.$i.'" data-startdate="'.$from.'" data-enddate="'.$to.'">WEEK '.$i.'</div>
							</li>';
						$i++;
					}
					
				}
				
					
			}
			echo "<li id='selecteddate' style='float: right; width: 125px; font-weight: bold;border-right: medium none;font-size: 15px;'></li></ul>";
			exit;
		}
	}
	
	public function Dailysession($curdate=null)
	{	
		/* if($curdate!='')
		{
			$date= date('Y-m-d',(strtotime ('-1 day' , strtotime ($curdate))));
		}
		else
		{
			$date= date('Y-m-d',(strtotime ('-1 day' , strtotime (date('Y-m-d')))));
		} */
		$date= date('Y-m-d',strtotime (date('Y-m-d')));
		$dayname=date('l', strtotime($date));
		$day_of_week = date('N', strtotime($dayname));
		/* if($dayname!='Sunday')
		{ */
			$schools=$this->Dashboard_model->getschools();
			
			//echo "<pre>";print_r($schools);exit;
			foreach($schools as $sid)
			{	
			$maildays = explode(",",$sid['maildays']);
			
			if (in_array($day_of_week, $maildays)) 
			{
				$issend=$this->Dashboard_model->checkMailSentToday($sid['id']);
				if($issend[0]['issenton']==0)
				{					
					$todayses='';
					//$sid['id']=4;
					$data['SLeaveList']=$this->Dashboard_model->leavelist($sid['id']);
					$arr=array();
					$scklschedule=array();
					$compusers=array();
					foreach($data['SLeaveList'] as $row)
					{
						$arr[$row['ldates']]=$row['ldates'];
					}
						$LeaveList=$arr;
					//echo $date."<pre>";print_r($LeaveList);exit;
					if(!in_array($date,$LeaveList))
					{	
						$todaysession= $this->Dashboard_model->todaysession($sid['id']);
						$completeusers= $this->Dashboard_model->training_completedusers($sid['id']);
						
						$compusers[$completeusers['sid']][$completeusers['grade_id']][$completeusers['section']]= $completeusers['cuser'];
						foreach($todaysession as $key1=>$val1) {
							
							$scklschedule[$todaysession[$key1]['school_id'].'-'.$todaysession[$key1]['gradeid'].'-'.$todaysession[$key1]['section'] ] =  $val1;
						}
						foreach($completeusers as $key2=>$val2) {
							
							$compusers[$completeusers[$key2]['sid'].'-'.$completeusers[$key2]['grade_id'].'-'.$completeusers[$key2]['section'] ] =  $val2;
						}
						$totalsession=count($scklschedule);
						if(count($scklschedule)>0)
						{
							$curdate=date('d/m/Y',strtotime($date));
							$todayses='<div style="background-color:#fafafa;margin:1% 5%;border: 1px solid;font-family: Calibri;">
							<table style="width:100%;font-size: 16px;">
							<tbody>						
							<tr style="display:block;overflow:hidden;background: #20489c;">
							<td style="float:left;border:0px;text-align: center;padding: 10px 0px;width:33%;color: #fff;">
								<img alt="https://schools.skillangels.com" src="https://schools.skillangels.com/assets/images/sklogo-web.png" style="float: left;width:220px;">
							</td>
							<td style="float:left;border:0px;text-align: center;padding: 30px 0px;width: 33%;color: #fff;">
								<a href="https://schools.skillangels.com" target="_blank" style="color: #fff;text-decoration: none;cursor: pointer;font-size: 23px;">SkillAngels - Daily Session Status</a>
							</td>
							
							</tr>
							<tr style="text-align: center;font-size: 25px;color: #000;margin-bottom:10px;">
								<td style="font-size: 20px;">'.$sid['school_name'].'</td>
							</tr>
							<tr>
								<td style="font-size: 12px;"><br/> Dear Madam / Sir,<br/><br/><br/></td>
							</tr>
							<tr style="display: block;">
								<td style="font-size: 12px;">The CLP session update for : '.$curdate.'<br/><br/></td>
							</tr>
							<tr style="display: block;">
								<td style="font-weight:bold;font-size: 12px;">Time table session - '.$totalsession.'<br/><br/></td>
							</tr>
							<tr style="display: block;">
								<td style="font-weight:bold;font-size: 12px;">Session Status:</td>
							</tr>
							</tbody></table><br/><br/>';
							$todayses.='<table align="center" border="1" cellspacing="0" cellpadding="0" style="border: gray;;font-size:16px;margin:0px;width: 100%;padding:1% 0.5%;font-size: 16px;">
							<thead style="background-color:#1c366b; color:#FFF;">
								<tr>
									<th style="padding:5px;font-weight: normal;font-size: 12px;">Grade</th>
									<th style="padding:5px;font-weight: normal;font-size: 12px;">Section</th>
									<th style="padding:5px;font-weight: normal;font-size: 12px;">No. of students enrolled for the session</th>
									<th style="padding:5px;font-weight: normal;font-size: 12px;">Attendance for the session</th>
									<th style="padding:5px;font-weight: normal;font-size: 12px;">Actual completion for the session</th>
								 </tr>
							 </thead>
								<tbody style="">';
								 $i=1;
								foreach($scklschedule as $key3=>$val3) 
								{
									if($i%2==0){$cls="style='background-color:#f3f3f3;'";}else{$cls="style='background-color:#fff;'";}
									
									$scklschedule[$key3]['cccount'] =  $compusers[$key3]['cuser'];
									
									if($compusers[$key3]['cuser']=='') { $completedUser=0; } else { $completedUser=$compusers[$key3]['cuser']; }
									
									 $todayses.='<tr '.$cls.'>
													<td style="padding:5px;font-weight: normal;font-size: 12px;">'.  $val3['grade'].'</td>
													<td style="padding:5px;font-weight: normal;font-size: 12px;">'.  $val3['section'].'</td>
													<td style="padding:5px;font-weight: normal;font-size: 12px;">'.  $val3['regusers'].'</td>
													<td style="padding:5px;font-weight: normal;font-size: 12px;">'.  $val3['attendusers'].'</td>
													<td style="padding:5px;font-weight: normal;font-size: 12px;">'.  $completedUser.'</td>
										</tr>';		
									
									
							$i++;	} 
							
							$todayses.='</tbody></table><br/>';
							$todayses.='<table style="display: block;font-size: 16px;"><tbody>
							<tr ><td style="font-size: 12px;">  We recommend students attend every session, if missed, we recommend compensating the session either in school or at home. <br/><br/></td></tr>	
							<tr>
								<td style="font-size: 12px;">Thanks & Regards,</td>
							</tr>
							<tr>
								<td style="font-size: 12px;"> Priya</td>
							</tr>
							<tr>
								<td style="color:blue;font-size: 12px;"><i> SkillAngels</i> - <i>"We aim to Delight"</i></td>
							</tr>
							<tr>
								<td style="font-size: 12px;"> Customer Delight Executive  <br/> <br/></td>
							</tr>';
							$todayses.="<tr>
								<td style='font-size: 12px;'> Edsix Brain Lab Private Limited, <br/>
								Supported by IIT Madras RTBI <br/>
								And by IIM Ahmedabad's CIIE <br/>";
								
								
								$todayses.='<br/>
								<a href="www.facebook.com/skillangels" title="Skillangels" >www.facebook.com/skillangels</a>
								<br/>
								(P) : +91 97880 91988
								<br/>
								URL : <a href="www.skillangels.com" title="Skillangels">www.skillangels.com</a>
								</td>
							</tr>
							
							</tbody>                
							</table></div>';
							//$emailarr=array($sid['email']);
							$emailarr=array();
							$a=explode(",",$sid['emailcc']);						
							foreach($a as $e)
							{
								array_push($emailarr,$e);
							}
							
							$emailarr_cc=array();
							$a1=explode(",",$sid['emailcc1']);						
							foreach($a1 as $e1)
							{
								array_push($emailarr_cc,$e1);
							}
							
							/* echo "<pre>";print_r($a);
							echo "<pre>";print_r($emailarr);
							echo $sid['emailcc']."<br/>";
							echo $todayses; exit; */
							$subject="SkillAngels - Daily Session Status";
							
							$this->SendEmail($emailarr,$emailarr_cc,$todayses,$subject);
							$this->Dashboard_model->InsertTodayMail($sid['id']);
						
						}
						else
						{
							echo $sid['school_name']." no schedule for this date <br/><br/>";//exit;
						}
					}
					else
					{
						echo $sid['school_name']." Today Leave <br/><br/>";//exit;
					}
				}
				else
				{
					echo $sid['school_name']." Mail already sent<br/><br/>";//exit;
				}
			}
		
		else
		{
			echo $sid['school_name']." Today Sunday <br/><br/>";//exit;
		}
		}
	}
	
	public function Riverside_cron($curdate=null)
	{	
		date_default_timezone_set('Asia/Kolkata');
		$curdatetime=date('His');
		$clock10='220000';
		$clock105='220500';
		if($curdatetime>=$clock10 && $curdatetime<=$clock105)
		//if(1==1)
		{
			$date= date('Y-m-d',strtotime (date('Y-m-d')));
			$dayname=date('l', strtotime($date));
			if($dayname!='Sunday')
			{
				$schools=$this->Dashboard_model->getschools_rps();
				//echo "<pre>";print_r($schools);exit;
				foreach($schools as $sid)
				{	
					$issend=$this->Dashboard_model->checkMailSentToday($sid['id']);
					if($issend[0]['issenton']==0)
					{					
						$todayses='';
						//$sid['id']=4;
						$data['SLeaveList']=$this->Dashboard_model->leavelist($sid['id']);
						$arr=array();
						$scklschedule=array();
						$compusers=array();
						foreach($data['SLeaveList'] as $row)
						{
							$arr[$row['ldates']]=$row['ldates'];
						}
							$LeaveList=$arr;
						//echo $date."<pre>";print_r($LeaveList);exit;
						if(!in_array($date,$LeaveList))
						{	
							$todaysession= $this->Dashboard_model->todaysession($sid['id']);
							$completeusers= $this->Dashboard_model->training_completedusers($sid['id']);
							
							$compusers[$completeusers['sid']][$completeusers['grade_id']][$completeusers['section']]= $completeusers['cuser'];
							foreach($todaysession as $key1=>$val1) {
								
								$scklschedule[$todaysession[$key1]['school_id'].'-'.$todaysession[$key1]['gradeid'].'-'.$todaysession[$key1]['section'] ] =  $val1;
							}
							foreach($completeusers as $key2=>$val2) {
								
								$compusers[$completeusers[$key2]['sid'].'-'.$completeusers[$key2]['grade_id'].'-'.$completeusers[$key2]['section'] ] =  $val2;
							}
							$totalsession=count($scklschedule);
							if(count($scklschedule)>0)
							{
								$curdate=date('d/m/Y',strtotime($date));
								$todayses='<div style="background-color:#fafafa;margin:1% 5%;border: 1px solid;font-family: Calibri;">
								<table style="width:100%;font-size: 16px;">
								<tbody>						
								<tr style="display:block;overflow:hidden;background: #20489c;">
								<td style="float:left;border:0px;text-align: center;padding: 10px 0px;width:33%;color: #fff;">
									<img alt="https://schools.skillangels.com" src="https://schools.skillangels.com/assets/images/sklogo-web.png" style="float: left;width:220px;">
								</td>
								<td style="float:left;border:0px;text-align: center;padding: 30px 0px;width: 33%;color: #fff;">
									<a href="https://schools.skillangels.com" target="_blank" style="color: #fff;text-decoration: none;cursor: pointer;font-size: 23px;">SkillAngels - Daily Session Status</a>
								</td>
								
								</tr>
								<tr style="text-align: center;font-size: 25px;color: #000;margin-bottom:10px;">
									<td style="font-size: 20px;">'.$sid['school_name'].'</td>
								</tr>
								<tr>
									<td style="font-size: 12px;"><br/> Dear Madam / Sir,<br/><br/><br/></td>
								</tr>
								<tr style="display: block;">
									<td style="font-size: 12px;">The CLP session update for : '.$curdate.'<br/><br/></td>
								</tr>
								<tr style="display: block;">
									<td style="font-weight:bold;font-size: 12px;">Time table session - '.$totalsession.'<br/><br/></td>
								</tr>
								<tr style="display: block;">
									<td style="font-weight:bold;font-size: 12px;">Session Status:</td>
								</tr>
								</tbody></table><br/><br/>';
								$todayses.='<table align="center" border="1" cellspacing="0" cellpadding="0" style="border: gray;;font-size:16px;margin:0px;width: 100%;padding:1% 0.5%;font-size: 16px;">
								<thead style="background-color:#1c366b; color:#FFF;">
									<tr>
										<th style="padding:5px;font-weight: normal;font-size: 12px;">Grade</th>
										<th style="padding:5px;font-weight: normal;font-size: 12px;">Section</th>
										<th style="padding:5px;font-weight: normal;font-size: 12px;">No. of students enrolled for the session</th>
										<th style="padding:5px;font-weight: normal;font-size: 12px;">Attendance for the session</th>
										<th style="padding:5px;font-weight: normal;font-size: 12px;">Actual completion for the session</th>
									 </tr>
								 </thead>
									<tbody style="">';
									 $i=1;
									foreach($scklschedule as $key3=>$val3) 
									{
										if($i%2==0){$cls="style='background-color:#f3f3f3;'";}else{$cls="style='background-color:#fff;'";}
										
										$scklschedule[$key3]['cccount'] =  $compusers[$key3]['cuser'];
										
										if($compusers[$key3]['cuser']=='') { $completedUser=0; } else { $completedUser=$compusers[$key3]['cuser']; }
										
										 $todayses.='<tr '.$cls.'>
														<td style="padding:5px;font-weight: normal;font-size: 12px;">'.  $val3['grade'].'</td>
														<td style="padding:5px;font-weight: normal;font-size: 12px;">'.  $val3['section'].'</td>
														<td style="padding:5px;font-weight: normal;font-size: 12px;">'.  $val3['regusers'].'</td>
														<td style="padding:5px;font-weight: normal;font-size: 12px;">'.  $val3['attendusers'].'</td>
														<td style="padding:5px;font-weight: normal;font-size: 12px;">'.  $completedUser.'</td>
											</tr>';		
										
										
								$i++;	} 
								
								$todayses.='</tbody></table><br/>';
								$todayses.='<table style="display: block;font-size: 16px;"><tbody>
								<tr ><td style="font-size: 12px;">  We recommend students attend every session, if missed, we recommend compensating the session either in school or at home. <br/><br/></td></tr>	
								<tr>
									<td style="font-size: 12px;">Thanks & Regards,</td>
								</tr>
								<tr>
									<td style="font-size: 12px;"> Priya</td>
								</tr>
								<tr>
									<td style="color:blue;font-size: 12px;"><i> SkillAngels</i> - <i>"We aim to Delight"</i></td>
								</tr>
								<tr>
									<td style="font-size: 12px;"> Customer Delight Executive  <br/> <br/></td>
								</tr>';
								$todayses.="<tr>
									<td style='font-size: 12px;'> Edsix Brain Lab Private Limited, <br/>
									Supported by IIT Madras RTBI <br/>
									And by IIM Ahmedabad's CIIE <br/>";
									
									
									$todayses.='<br/>
									<a href="www.facebook.com/skillangels" title="Skillangels" >www.facebook.com/skillangels</a>
									<br/>
									(P) : +91 97880 91988
									<br/>
									URL : <a href="www.skillangels.com" title="Skillangels">www.skillangels.com</a>
									</td>
								</tr>
								
								</tbody>                
								</table></div>';
								//$emailarr=array($sid['email']);
								$emailarr=array();
								$a=explode(",",$sid['emailcc']);						
								foreach($a as $e)
								{
									array_push($emailarr,$e);
								}
								
								/* echo "<pre>";print_r($a);
								echo "<pre>";print_r($emailarr);
								echo $sid['emailcc']."<br/>";
								echo $todayses; exit;  */
								$subject="SkillAngels - Daily Session Status";
								
								$this->SendEmail($emailarr,$todayses,$subject);
								$this->Dashboard_model->InsertTodayMail($sid['id']);
							
							}
							else
							{
								echo $sid['school_name']." no schedule for this date <br/><br/>";//exit;
							}
						}
						else
						{
							echo $sid['school_name']." Today Leave <br/><br/>";//exit;
						}
					}
					else
					{
						echo $sid['school_name']." Mail already sent<br/><br/>";//exit;
					}
				}
			}
			else
			{
				echo "Today Sunday <br/><br/>";//exit;
			}
		}
		else
		{
			echo "not Between 10 to 10:05 clock";exit;
		}
	}
	
	public function MonthlySessionReport($curdate=null)
	{	
		date_default_timezone_set('Asia/Kolkata');

		/* if($curdate!='')
		{
			$date= date('Y-m-d',(strtotime ('-1 day' , strtotime ($curdate))));
		}
		else
		{
			$date= date('Y-m-d',(strtotime ('-1 day' , strtotime (date('Y-m-d')))));
		} */
		$currentMonth = date('F');
		$lastmonth=Date('F', strtotime($currentMonth . " last month"));
			
			$schools=$this->Dashboard_model->getSpecificSchools();
			$arrcounter=$this->Dashboard_model->getPuzzleCount();
			
			$Puzzles_Attempted=str_split($arrcounter[0]['gtime_total_att']);
			$Puzzles_Solved=str_split($arrcounter[0]['gtime_total_ans']);
			$Minutes_Trained=str_split($arrcounter[0]['gtime_total']);
			
					
			foreach($schools as $sid)
			{
				$curdate=date('d/m/Y H:i:A');
				$currentMonth = date('F');
				$lastmonth=Date('F', strtotime($currentMonth . " last month"));
				$todayses='<div style="background-color:#fafafa;margin:0 auto;border: 1px solid;width: 800px;">
				<table style="width:100%;font-size: 18px;">
				<tbody>						
				<tr style="display:block;overflow:hidden;background: #20489c;">
					<td style="float:left;border:0px;text-align: center;padding: 10px 0px;width:33%;color: #fff;">
							<img alt="https://schools.skillangels.com" src="https://schools.skillangels.com/assets/images/sklogo-web.png" style="float: left;width:220px;">
					</td>
					<td style="float:left;border:0px;padding: 30px 0px;width: 67%;color: #fff;">
						<p style="color: #fff;font-size: 23px;margin: 0;">End of Month Report - '.$lastmonth.'</p>
					</td>
				</tr>
				<tr style="text-align: center;font-size: 32px;color: #000;font-weight:bold;">
					<td>'.$sid['school_name'].'</td>
				</tr>
				<tr style="display:block;overflow:hidden;margin: 1% 1% 1% 1%;">
					<td style="float:left;border:0px;text-align: center;padding: 2% 0px;width: 31%;color: #fff;margin: 0px 1%;">
						<div style="color:#fff;">
						<div style="color:#fff;overflow: hidden;clear: both;padding: 5%;background: #5f1c52;">
							Puzzles Attempted
						</div>
						
							<div style="padding: 5% 0%;overflow: hidden;background: #ab268f;">';
							foreach($Puzzles_Attempted as $PA)
							{
								$todayses.='<div style="border:1px solid;width: 25px;padding: 3% 0%;    display: inline-block;background:#333333;">'.$PA.'</div>';
							}

						$todayses.='</div>
						</div>
					</td>
					<td style="float:left;border:0px;text-align: center;padding: 2% 0px;width: 31%;color: #fff;margin: 0px 1%;">
						<div style="color:#fff;">
						<div style="color:#fff;overflow: hidden;clear: both;padding: 5%;background: #ad4f2b;">
							Puzzles Solved
						</div>
						<div style="padding: 5% 2%;overflow: hidden;background: #f58821;">';
							foreach($Puzzles_Solved as $PS)
							{
								$todayses.='<div style="border:1px solid;width: 25px;padding: 3% 0%;    display: inline-block;background:#333333;">'.$PS.'</div>';
							}
						$todayses.='</div>
						<div>
						
					</td>
					<td style="float:left;border:0px;text-align: center;padding: 2% 0px;width: 31%;color: #fff;margin: 0px 1%;">
						<div style="color:#fff;">
						<div style="color:#fff;overflow: hidden;clear: both;padding: 5%;background: #9d1e39;">
							Minutes Trained
						</div>
						<div style="padding: 5% 2%;overflow: hidden;background: #ee1c67;">';
							foreach($Minutes_Trained as $MT)
							{
								$todayses.='<div style="border:1px solid;width: 25px;padding: 3% 0%;    display: inline-block;background:#333333;">'.$MT.'</div>';
							}
						$todayses.='</div>
						<div>
					</td>
				</tr>
				<tr><td style="padding: 0% 1%;">As of '.$curdate.'</td></tr>
				<tr style="padding-left:5px;display:block;">
					<td> <br/> <br/> Dear Sir / Madam,</td>
				</tr>
				<tr style="padding-left:5px;display:block;"><td> <br/>Greetings from SkillAngels!<br/></td></tr>
				<tr style="padding-left:5px;display: block;">
					<td>We are happy to share you the EOM report for the '.$lastmonth.' month with the intent to ensure that we partner with you in making SkillAngels training a success. The report captures important parameters that will help you understand the training -Student and Class performance.</td>
				</tr>
				<tr style="padding-left:5px;display: block;">
					<td style=""><br/>Please find the EOM reports of your school in the link below.</td>
				</tr>
				<tr style="padding-left:5px;display: block;">
					<td style="font-weight:bold;"><br/>
						<a href="https://schools.skillangels.com/school_admin" target="_blank" style="cursor: pointer;">https://schools.skillangels.com/school_admin</a>
					</td>
				</tr>
				
				<tr style="padding-left:5px;display: block;">
					<td style="font-weight:bold;"><br/><br/>
						<p style="margin: 0;"> Username : '.$sid['email'].' </p>
						<p style="margin: 0;"> Password :  skillangels </p>
					</td>
				</tr>
				<tr style="padding-left:5px;display: block;">
					<td style=""><br/>
						<p> Do let us know if you would like us to capture any other detail.</p>
					</td>
				</tr>
								
				</tbody></table>';
				$todayses.='<table align="center" border="1" cellspacing="0" cellpadding="0" style="border: gray;;font-size:18px;margin:0px;width: 100%;padding:1% 2%;">
				<tbody style="">';
				
				$todayses.='</tbody>                
				</table>';
				$todayses.='<table style="display: block;font-size: 18px;padding-left:5px;"><tbody>
						<tr>
							<td>Thanks & Regards,</td>
						</tr>
						<tr>
							<td> Priya</td>
						</tr>
						<tr>
							<td style="color:blue;"><i> SkillAngels</i> - <i>"We aim to Delight"</i></td>
						</tr>
						<tr>
							<td> Customer Delight Executive  <br/> <br/></td>
						</tr>';
						$todayses.="<tr>
							<td> Edsix Brain Lab Private Limited, <br/>
							Supported by IIT Madras RTBI <br/>
							And by IIM Ahmedabad's CIIE <br/>";
							
							
							$todayses.='<br/>
							<a href="www.facebook.com/skillangels" title="Skillangels" >www.facebook.com/skillangels</a>
							<br/>
							(P) : +91 97880 91988
							<br/>
							URL : <a href="www.skillangels.com" title="Skillangels">www.skillangels.com</a>
							</td>
						</tr>
						
						</tbody>                
						</table></div>';
						
						$emailarr=array();
						$a=explode(",",$sid['emailcc']);						
						foreach($a as $e)
						{
							array_push($emailarr,$e);
						}
						
						$subject='SkillAngels - End of Month Report';
						//echo $todayses;exit;
						//$this->SendEmail($emailarr,$todayses,$subject);
					
				
			}
		
	}
	
	
	public function SendEmail($toemailid,$ccemailid,$message,$subject)
	{
		$mail = new PHPMailer;
		$mail->isSMTP();
		$mail->SMTPDebug = 0;
		$mail->Debugoutput = 'html';
		$mail->Host = "smtp.falconide.com";
		$mail->Port = 587;
		$mail->SMTPAuth = true;
		$mail->SMTPSecure = "";
		$mail->Username = "skillsangelsfal";
		$mail->Password = "SkillAngels@123";
		$mail->setFrom('support@skillangels.com', 'SkillAngels');
		$mail->addReplyTo('support@skillangels.com', 'SkillAngels');
		foreach($toemailid as $email)
		{
		   $mail->addAddress($email,'');
		}	
		foreach($ccemailid as $emailcc)
		{
		   $mail->AddCC($emailcc,'');
		}
		
		$mail->addBCC("priyat@skillangels.com", "Priya");		
		$mail->addBCC("damu@skillangels.com", "Damu");
		
		/* echo "<pre>";print_r($message);
		echo "<pre>";print_r($subject);
		echo "<pre>";print_r($mail);exit;  */
		
		$mail->Subject = $subject;
		$mail->msgHTML($message);
		
		if (!$mail->send()) {
		   echo "Mailer Error: " . $mail->ErrorInfo;
		}else{
		   echo "Message sent!"."<br/>";
		}
	}
	
	

	public function Sendcron()
	{		
		$todaysession= $this->Dashboard_model->InsertTime();
	}
	
	public function progress()
	{
		if($this->session->schoolid=="" || !isset($this->session->schoolid)){redirect('index.php');}
		$schoolid = $this->session->schoolid;
		$data['schooldetails'] = $this->Dashboard_model->schooldetails($schoolid);
		$data['getgrade'] = $this->Dashboard_model->getgrades($schoolid); 
		
		
		$this->load->view('header', $data);
		$this->load->view('progress', $data);
		$this->load->view('footer');
		
	}
	
	public function progress_classwise()
	{
		if($this->session->schoolid=="" || !isset($this->session->schoolid)){redirect('index.php');}
		$schoolid = $this->session->schoolid;
		$data['schooldetails'] = $this->Dashboard_model->schooldetails($schoolid);
		$data['getgrade'] = $this->Dashboard_model->getgrades($schoolid); 
		
		
		$this->load->view('header', $data);
		$this->load->view('progress_classwise', $data);
		$this->load->view('footer');
		
	}
	
	public function bspi_progress_classwise()
	{
		 if($this->session->schoolid=="" || !isset($this->session->schoolid)){ redirect('index.php'); }
		$schoolid = $this->session->schoolid;
		$gradeid = $this->input->post('gradeid');
		$section = $this->input->post('section');
		
		//$data['asapbspi_classwise']=$this->Dashboard_model->getasapbspi_classwisebspi($schoolid,$gradeid,$section);
		$data['asapbspi']=$this->Dashboard_model->getasapbspi_classwise($schoolid,$gradeid,$section);
		$data['get_bspi_rows'] =$this->Dashboard_model->getBSPI_classwisebspi($gradeid,$section);	

		$response=array('clpbspi'=>round($data['get_bspi_rows'][0]['bspi'],2),'asapbspi'=>round($data['asapbspi'][0]['bspi'], 2));
		
		 echo json_encode($response);exit;
		
	}
	
	public function getstudentname()
	{
		
		if($this->session->schoolid=="" || !isset($this->session->schoolid)){redirect('index.php');}
		
		 $schoolid = $this->session->schoolid;
		 $gradeid = $this->input->post('gradeid'); 
		 $section = $this->input->post('section'); 
		 
		 $data['studentname'] = $this->Dashboard_model->getstudentname($schoolid,$gradeid,$section);
		 
		 $this->load->view('student_name', $data);
		
	}
	
	/* public function getstudentname()
	{
		
		if($this->session->schoolid=="" || !isset($this->session->schoolid)){redirect('index.php');}
		
		 $schoolid = $this->session->schoolid;
		 $gradeid = $this->input->post('gradeid'); 
		 $section = $this->input->post('section'); 
		 $name = $this->input->post('name'); 
		$data['getname'] = $this->Dashboard_model->getstudentname($schoolid,$gradeid,$section,$name);
		
		//echo '<pre>'; print_r($data['getname']); exit;
		foreach($data['getname'] as $res){
			
			 $name[] = $res["fname"];
		 }
		echo json_encode($name); exit;
		} */
	
	
	public function getsection()
	{
		if($this->session->schoolid=="" || !isset($this->session->schoolid)){ redirect('index.php'); }
		$schoolid = $this->session->schoolid;
		$gradeid = $this->input->post('gradeid');
		
		$data['getsection'] = $this->Dashboard_model->getsection($schoolid,$gradeid);
		
		$this->load->view('section', $data);
		
	}
	
	public function skillscores_m()
	{
		 if($this->session->schoolid=="" || !isset($this->session->schoolid)){ redirect('index.php'); }
		$schoolid = $this->session->schoolid;
		$gradeid = $this->input->post('gradeid');
		$section = $this->input->post('section');
		$student = $this->input->post('student');
		$skillid = $this->input->post('skillid');
		$catid=1;
		$data['skill'] = $this->input->post('skillid');
		
		$data['getmonths'] = $this->Dashboard_model->getmonths($this->session->school_startdate);
		//$data['getskills']=$this->Dashboard_model->getSkillsRandom($catid);
		/* foreach($data['getskills'] as $res) {
		$data['getmnthwiseskillscores'] = $this->Dashboard_model->getmnthwiseskillscore($student,$res['skill_id']);
		} */
		$data['getmnthwiseskillscores'] = $this->Dashboard_model->getmnthwiseskillscore_M($student,$skillid);
		$data['getasapscore_M'] = $this->Dashboard_model->getasapscore_M($student,$skillid);
		//print_r($data['getasapscore_M']); exit;
		$this->load->view('skillscore_progress', $data);
	}
	public function skillscores_m_classwise()
	{
		 if($this->session->schoolid=="" || !isset($this->session->schoolid)){ redirect('index.php'); }
		$schoolid = $this->session->schoolid;
		$gradeid = $this->input->post('gradeid');
		$section = $this->input->post('section');
 		$skillid = $this->input->post('skillid');
		$catid=1;
		$data['skill'] = $this->input->post('skillid');
		
		$data['getmonths'] = $this->Dashboard_model->getmonths($this->session->school_startdate);
		//$data['getskills']=$this->Dashboard_model->getSkillsRandom($catid);
		/* foreach($data['getskills'] as $res) {
		$data['getmnthwiseskillscores'] = $this->Dashboard_model->getmnthwiseskillscore($student,$res['skill_id']);
		} */
		$data['getmnthwiseskillscores'] = $this->Dashboard_model->getmnthwiseskillscore_M_classwise($gradeid,$section,$skillid);
		$data['getasapscore_M'] = $this->Dashboard_model->getasapscore_M_classwise($gradeid,$section,$skillid);
		//print_r($data['getasapscore_M']); exit;
		$this->load->view('skillscore_progress_classwise', $data);
	}
	
	
	public function bspi_progress_report2()
	{
		 if($this->session->schoolid=="" || !isset($this->session->schoolid)){ redirect('index.php'); }
		$schoolid = $this->session->schoolid;
		$gradeid = $this->input->post('gradeid');
		$section = $this->input->post('section');
		$student = $this->input->post('student');
		
		$data['getmonths'] = $this->Dashboard_model->getmonths($this->session->school_startdate);
		$data['getmnthwisebspi'] = $this->Dashboard_model->getmnthwisebspi($student);
		
		$data['getmnthwisebspi_topscore'] = $this->Dashboard_model->getmnthwisebspi_topscore($schoolid,$gradeid,$section);
		$data['asapbspi']=$this->Dashboard_model->getasapbspi($schoolid,$gradeid,$section,$student);
		$data['max_asapbspi']=$this->Dashboard_model->get_max_asapbspi($schoolid,$gradeid,$section);
		
		$this->load->view('bspi_progress', $data);
		
	}
	
	public function bspi_progress_report2_classwise()
	{
		 if($this->session->schoolid=="" || !isset($this->session->schoolid)){ redirect('index.php'); }
		$schoolid = $this->session->schoolid;
		$gradeid = $this->input->post('gradeid');
		$section = $this->input->post('section');
 		
		$data['getmonths'] = $this->Dashboard_model->getmonths($this->session->school_startdate);
		$data['getmnthwisebspi'] = $this->Dashboard_model->getmnthwisebspi_classwise($schoolid,$gradeid,$section);
		
		$data['getmnthwisebspi_topscore'] = $this->Dashboard_model->getmnthwisebspi_topscore_classwise($schoolid,$gradeid,$section);
		$data['asapbspi']=$this->Dashboard_model->getasapbspi_classwise($schoolid,$gradeid,$section);
		$data['max_asapbspi']=$this->Dashboard_model->get_max_asapbspi_classwise($schoolid,$gradeid,$section);
		
		$this->load->view('bspi_progress_classwise', $data);
		
	}
	
	public function bspi_progress()
	{
		 if($this->session->schoolid=="" || !isset($this->session->schoolid)){ redirect('index.php'); }
		$schoolid = $this->session->schoolid;
		$gradeid = $this->input->post('gradeid');
		$section = $this->input->post('section');
		$student = $this->input->post('student');
		
		$data['asapbspi']=$this->Dashboard_model->getasapbspi($schoolid,$gradeid,$section,$student);
		
		$get_bspi_rows =$this->Dashboard_model->getBSPI($student);	
		
		$res_tot_memory=$res_tot_vp=$res_tot_fa= $res_tot_ps=$res_tot_lang=0;
		$res_tot_memory_i=$res_tot_vp_i=$res_tot_fa_i= $res_tot_ps_i=$res_tot_lang_i=0; 
		foreach($get_bspi_rows as $get_res){		
			if(($get_res['gs_id']=='59')){$res_tot_memory_i++; $res_tot_memory += $get_res['score'];}
			else{$res_tot_memory += 0.00;}
			if(($get_res['gs_id']=='60')){$res_tot_vp_i++;$res_tot_vp += $get_res['score'];}
			else{$res_tot_vp += 0.00;}
			if(($get_res['gs_id']=='61')){$res_tot_fa_i++;$res_tot_fa += $get_res['score'];}
			else{$res_tot_fa += 0.00;}
			if(($get_res['gs_id']=='62')){$res_tot_ps_i++;$res_tot_ps += $get_res['score'];}
			else{$res_tot_ps += 0.00;}
			if(($get_res['gs_id']=='63')){$res_tot_lang_i++;$res_tot_lang += $get_res['score'];}
			else{$res_tot_lang += 0.00;}		 
		}
		if($res_tot_memory_i==0){$res_tot_memory_i=1;}
		if($res_tot_vp_i==0){$res_tot_vp_i=1;}
		if($res_tot_fa_i==0){$res_tot_fa_i=1;}
		if($res_tot_ps_i==0){$res_tot_ps_i=1;}
		if($res_tot_lang_i==0){$res_tot_lang_i=1;}
		$tot = (($res_tot_memory/$res_tot_memory_i)+($res_tot_vp/$res_tot_vp_i)+($res_tot_fa/$res_tot_fa_i)+($res_tot_ps/$res_tot_ps_i)+($res_tot_lang/$res_tot_lang_i))/5;
		
		
		$response=array('clpbspi'=>round($tot,2),'asapbspi'=>round($data['asapbspi'][0]['bspi'], 2));
		
		 echo json_encode($response);exit;
		
	}
	
	public function non_schedule($curdate = '')
	{
		 if($this->session->schoolid=="" || !isset($this->session->schoolid)){ redirect('index.php'); }
		 
		 $schoolid = $this->session->schoolid;
		 $data['schooldetails'] = $this->Dashboard_model->schooldetails($schoolid);
		 
		 if($curdate=='') {
			 
			 $curdate = date('Y-m-d');
			// $curdate = '2018-04-16';
			 $data['date']=$curdate;
		 }
		//echo $curdate; exit;
		 
		 $data['schools'] = $this->Dashboard_model->schoolsession_nonschedule($schoolid,$curdate);
		 $data['completeusers'] = $this->Dashboard_model->training_completedusers_nonschedule($schoolid,$curdate);
		 
		 
		 $this->load->view('header', $data);
		 $this->load->view('non_schedule', $data);
		 $this->load->view('footer');
	}
	
	public function nonschedule_userslist()
	{
		if($this->session->schoolid=="" || !isset($this->session->schoolid)){ redirect('index.php'); }
		 
		$gradeid = $this->input->post('gradeid');
		$section = $this->input->post('section');
		$type = $this->input->post('type');
		$date = $this->input->post('date');
		$schoolid = $this->session->schoolid;
		
		if($type=='logusers'){ $data['title']='Logged in users list';  } 
		else if($type=='attnusers') { $data['title']='Attended users list'; } 
			
		if($type=='cmptusers')
		{
			// $data['schools'] = $this->Dashboard_model->cuser_nonschedule($schoolid,$gradeid,$section,$date);
			 //$data['schools'] = $this->Dashboard_model->schoolsession_nonschedule($schoolid,$date);
			 $data['completeusers'] = $this->Dashboard_model->completeduserslist_nonschedule($schoolid,$date,$gradeid,$section);
			 $this->load->view('ajax_ns_comp_userslist', $data);
		}
		else {
			
			$data['loguserslist'] = $this->Dashboard_model->ns_loguserslist($schoolid,$gradeid,$section,$date,$type);
			$this->load->view('ajax_ns_userslist', $data);
			
			}
		
		
	}
	
	
	public function monthwiseavgbspi()
	{
		$grade_id=$this->input->post('grade_id');
		$section=$this->input->post('section');
		
		$schoolid = $this->session->schoolid;
		$enddate=date('Y-m-d');
		$startdate=$this->session->school_startdate;
		
		$get_bspi_rows = $this->Dashboard_model->monthwiseavgbspi($schoolid,$startdate,$enddate,$grade_id,$section);
		
		$arrofasapbspi = $this->Dashboard_model->AsapAvgBspi($schoolid,$startdate,$enddate,$grade_id,$section);
		
		$academicMonths= $this->Dashboard_model->academymonths($this->session->school_startdate); 
 
		foreach($get_bspi_rows as $get_res)
		{
			$monthbspiscore[$get_res['monthNumber']]=$get_res['bspi'];
		}
		$categories=array();$data=array();$asap=array();
		foreach($academicMonths as $am)
		{
			$categories[]=$am['monthName'];
			$asap[]=round($arrofasapbspi[0]['ASAPbspi'],2);
			if(isset($monthbspiscore[$am['monthNumber']]))
			{
				$data[]=round($monthbspiscore[$am['monthNumber']],2);
				
			}
			else
			{
				$data[]=0;
				
			}
		}
		$res=array(
			'categories'=>$categories,
			'data'=>$data,
			'asap'=>$asap
		);
		
		echo json_encode($res); exit;
	}
	public function monthwiseskillscore()
	{
		//if($this->session->schoolid=="" || !isset($this->session->schoolid)){ redirect('index.php'); }
		$schoolid = $this->session->schoolid;
		$skillid = $this->input->post('skillid');
		//Grade Page
		$grade_id=$this->input->post('grade_id');
		$section=$this->input->post('section');
		
		
		$startdate=$this->session->school_startdate;
		$enddate=date('Y-m-d');
		$get_skillscore_rows = $this->Dashboard_model->monthwiseskillscore($schoolid,$skillid,$startdate,$enddate,$grade_id,$section); // clp skill score
		
		$arrof_asapavgskillscore=$this->Dashboard_model->AsapAvgSkillScore($schoolid,$skillid,$startdate,$enddate,$grade_id,$section); // asap skill score
		
		$data['academicMonths']= $this->Dashboard_model->academymonths($startdate);
		$data['SkillList']= $this->Dashboard_model->TotalSkilllist($skillid);
		
		if($grade_id!='')
		{
			$GradeName= $this->Dashboard_model->getGradeName($grade_id);
			$data['GradeName']=$GradeName[0]['classname'];
		}
		else
		{
			$data['GradeName']='';
		}
		if($section!='')
		{
			$SectionName=" - ".$section;
		}
		else
		{
			$SectionName='';
		}
		 
		$monthwiseskillscore=array();
		foreach($get_skillscore_rows as $get_mon_skillscore)
		{
			$monthwiseskillscore[$get_mon_skillscore['monthNumber']][$get_mon_skillscore['name']]=$get_mon_skillscore['skillscore'];
		}
		$data['monthwiseskillscore']=$monthwiseskillscore;
		$data['asapavgskillscore']=$arrof_asapavgskillscore;
		
		$data['GraphTitle']=$data['GradeName']."".$SectionName;
		
		$this->load->view('ajax_monthwiseskillscore', $data);			 
	}
	public function bspitopper()
	{
		if($this->session->schoolid=="" || !isset($this->session->schoolid)){ redirect('index.php'); }
		$data['returnURL']=$this->agent->referrer();
		
		$schoolid = $this->session->schoolid;
		$data['GradeList']=$this->Dashboard_model->getGradeDetails($schoolid);
		$data['schooldetails'] = $this->Dashboard_model->schooldetails($schoolid);
		$data['academicMonths'] = $this->Dashboard_model->academymonths($this->session->school_startdate);
		
		$this->load->view('header', $data);
		$this->load->view('toppers/bspitopper', $data);
		$this->load->view('footer');
	} 
	public function ajax_bspitooper()
	{
		date_default_timezone_set('Asia/Kolkata');
		$schoolid = $this->session->schoolid;
		$enddate=date('Y-m-d');
		
		$grade_ids=$this->input->post('gradeids');
		$filter=$this->input->post('filter');
	 
		if($grade_ids!='')
		{
			$TotalGrade=$this->Dashboard_model->getGradeSection($schoolid,$grade_ids,$filter);
			$bspitopper_gradewise=$this->Dashboard_model->OverallBspiTopperbyGradesec($schoolid,$this->session->school_startdate,$enddate,$grade_ids,$filter);
			$aTop = array();
			
			foreach($bspitopper_gradewise as $topuser)
			{
				if($filter=='No')
				{ // Grade and Section Wise
					$gradesec=$topuser['grade_id']."-".$topuser['section'];
				}
				else
				{// Grade  Wise only
					$gradesec=$topuser['grade_id'];
				}
				$aTop[$gradesec][] = array(
										'name' => $topuser['name'],
										'username' => $topuser['username'],
										'bspi' =>$topuser['bspi']
										);
			}
			$data['sections']=$TotalGrade;
			$data['aTop']=$aTop;
			$data['filter']=$filter;
		}
		else
		{
			$data['aTop']=0;
		}
		$this->load->view('toppers/ajax_bspitopper', $data);			 
	}
	public function skilltopper()
	{
		if($this->session->schoolid=="" || !isset($this->session->schoolid)){ redirect('index.php'); }
		$data['returnURL']=$this->agent->referrer();
		
		$schoolid = $this->session->schoolid;
		$data['GradeList']=$this->Dashboard_model->getGradeDetails($schoolid);
		$data['schooldetails'] = $this->Dashboard_model->schooldetails($schoolid);
		
		$this->load->view('header', $data);
		$this->load->view('toppers/skilltopper', $data);
		$this->load->view('footer');
	} 
	public function ajax_skilltopper()
	{
		date_default_timezone_set('Asia/Kolkata');
		$schoolid = $this->session->schoolid;
		$enddate=date('Y-m-d');
		
		$grade_ids=$this->input->post('gradeids');
		$filter=$this->input->post('filter');
	 
		if($grade_ids!='')
		{	
			
			$schoolid = $this->session->schoolid;
			$TotalGrade=$this->Dashboard_model->getGradeSection($schoolid,$grade_ids,$filter);
			$skilltopper_gradewise=$this->Dashboard_model->SkillTopperMaxscore($schoolid,$this->session->school_startdate,$enddate,$grade_ids,$filter);
			$aTop = array();
			
			foreach($skilltopper_gradewise as $skillTop)
			{
				$arrtopuser=$this->Dashboard_model->SkillTopperUser($schoolid,$this->session->school_startdate,$enddate,$skillTop['grade_id'],$skillTop['section'],$skillTop['maxscore'],$skillTop['gs_id'],$filter);
				foreach($arrtopuser as $topuser)
				{
					if($filter=='No')
					{ // Grade and Section Wise
						$gradesec=$skillTop['grade_id']."-".$skillTop['section']."-".$skillTop['gs_id'];
					}
					else
					{// Grade  Wise only
						$gradesec=$skillTop['grade_id']."-".$skillTop['gs_id'];
					}
					$aTop[$gradesec][] = array(
											'name' => $topuser['name'],
											'username' => $topuser['username'],
											'score' => round($topuser['score'], 2)
											);
				}
				
			}
			
			$data['sections']=$TotalGrade;
			$data['aTop']=$aTop;$data['filter']=$filter;
		}
		else
		{
			$data['aTop']=0;
		}
		/* echo "<pre>";print_r($data['sections']);
		echo "<pre>";print_r($data['aTop']);exit; */
		$this->load->view('toppers/ajax_skilltopper', $data);			 
	}
	public function crownytopper()
	{
		if($this->session->schoolid=="" || !isset($this->session->schoolid)){ redirect('index.php'); }
		$data['returnURL']=$this->agent->referrer();

		$schoolid = $this->session->schoolid;
		$data['GradeList']=$this->Dashboard_model->getGradeDetails($schoolid);
		$data['schooldetails'] = $this->Dashboard_model->schooldetails($schoolid);
		
		$this->load->view('header', $data);
		$this->load->view('toppers/crownytopper', $data);
		$this->load->view('footer');
	} 
	public function ajax_crownytopper()
	{
		date_default_timezone_set('Asia/Kolkata');
		$schoolid = $this->session->schoolid;
		$enddate=date('Y-m-d');
		
		$grade_ids=$this->input->post('gradeids');
		$filter=$this->input->post('filter');
	 
		if($grade_ids!='')
		{	
			$TotalGrade=$this->Dashboard_model->getGradeSection($schoolid,$grade_ids,$filter);
			 
			$aTop = array();
			$arrtopuser=$this->Dashboard_model->CrownyTopperUser($schoolid,$this->session->school_startdate,$enddate,$grade_ids,$filter);
		 
			foreach($arrtopuser as $topuser)
			{
				if($filter=='No')
				{ // Grade and Section Wise
					$gradesec=$topuser['grade_id']."-".$topuser['section'];
				}
				else
				{// Grade  Wise only
					$gradesec=$topuser['grade_id'];
				}
				$aTop[$gradesec][] = array(
										'name' => $topuser['name'],
										'username' => $topuser['username'],
										'points' => round($topuser['points'], 2)
										);
			}
			$data['sections']=$TotalGrade;
			$data['aTop']=$aTop;
			$data['filter']=$filter;
		}
		else
		{
			$data['aTop']=0;$data['filter']=$filter;$data['sections']=$TotalGrade;
		}
		/* echo "<pre>";print_r($data['sections']);
		echo "<pre>";print_r($data['aTop']);exit; */ 
		$this->load->view('toppers/ajax_crownytopper', $data);			 
	}
	
	public function homeskilltopper()
	{
		$schoolid= $this->session->schoolid;
		$startdate=$this->session->school_startdate;
		$enddate=date('Y-m-d');
		//Grade Page
		$grade_id=$this->input->post('grade_id');
		$section=$this->input->post('section');
		
		$arrofmaxskillscore=$this->Dashboard_model->MaxSkillScore_Overall($schoolid,$startdate,$enddate,$grade_id,$section);
			
		foreach($arrofmaxskillscore as $topscoresbyskill_res)
		{
			$skillscorebytopusers=$this->Dashboard_model->MaxSkillScoreUser_Overall($schoolid,$startdate,$enddate,$topscoresbyskill_res['skillscore'],$topscoresbyskill_res['gs_id'],$grade_id,$section);
			
			foreach($skillscorebytopusers as $topscoredusers)
			{
				$topskillscoredusers_res[]= $topscoredusers;
			}
		}
		
		$data['SkilTopper']=$topskillscoredusers_res;
		//echo "<pre>";print_r($data);exit;
		$this->load->view('toppers/home_skilltopper', $data);	
	}
	public function homebspitopper()
	{
		$schoolid= $this->session->schoolid;
		$startdate=$this->session->school_startdate;
		$enddate=date('Y-m-d');
		
		//Grade Page
		$grade_id=$this->input->post('grade_id');
		$section=$this->input->post('section');
		
		/* $topbspi=$this->Dashboard_model->MaxBspiScore_Overall($schoolid,$startdate,$enddate,$grade_id,$section);
			
		foreach($topbspi as $bspitopper)
		{
			$finalbspi=$this->Dashboard_model->MaxBspiScoreUser_Overall($schoolid,$startdate,$enddate,$bspitopper['bspiscore'],$grade_id,$section);
			
			foreach($finalbspi as $finalbspiuser)
			{
				$bspischooltopper[]= $finalbspiuser;
			}
		} */
		$bspischooltopper=$this->Dashboard_model->MaxBspiScoreUser_Overall($schoolid,$startdate,$enddate,$grade_id,$section);
		
		$data['BspiTopper']=$bspischooltopper;
		//echo "<pre>";print_r($data);exit;
		$this->load->view('toppers/home_bspitopper', $data);	
		
	}
	public function homecrownytopper()
	{
		$schoolid= $this->session->schoolid;
		$startdate=$this->session->school_startdate;
		$enddate=date('Y-m-d');
		//Grade Page
		$grade_id=$this->input->post('grade_id');
		$section=$this->input->post('section');
		
		$topcrownybyuser=$this->Dashboard_model->MaxCrownyUser_Overall($schoolid,$startdate,$enddate,$grade_id,$section);
			
		
		$data['CrownyTopper']=$topcrownybyuser;
		//echo "<pre>";print_r($data);exit;
		$this->load->view('toppers/home_crownytopper', $data);
	}
	 
	 
	public function studentprofile() 
	{
		if($this->session->schoolid=="" || !isset($this->session->schoolid)){ redirect('index.php'); }
		$data['returnURL']=$this->agent->referrer();
		 
		
		$schoolid= $this->session->schoolid;
		$startdate=$this->session->school_startdate;
		$enddate=date('Y-m-d');
		$username=$this->uri->segment('3');
		$data['schooldetails'] = $this->Dashboard_model->schooldetails($schoolid);
		$data['studentdetails']=$this->Dashboard_model->studentDetails($schoolid,$username); // Rank
		$userid=$data['studentdetails'][0]['id'];
		$grade_id=$data['studentdetails'][0]['grade_id'];
		$section=$data['studentdetails'][0]['section'];
		// Rank
		$data['studentRank']=$this->Dashboard_model->studentRank($schoolid,$startdate,$enddate,$userid,$grade_id,$section); 
		//$data['studentPlay']=$this->Dashboard_model->studentPlayCount($schoolid,$startdate,$enddate,$userid);//Play Count
		//$data['studentavgBspi']=$this->Dashboard_model->studentAvgBspi($schoolid,$startdate,$enddate,$userid);//Play Count
		$data['userskillscore']=$this->Dashboard_model->UserScoreData($schoolid,$this->session->school_startdate,$userid);
		//$studentAttendedCount=$this->Dashboard_model->studentAttendedCount($schoolid,$startdate,$enddate,$userid,$grade_id,$section);//Attempted Count
		//$studentCompletedCount=$this->Dashboard_model->studentCompletedCount($schoolid,$startdate,$enddate,$userid,$grade_id,$section);//Completed Count
		
		 
		/* $percent = $studentAttendedCount[0]['attenusers']/$studentAttendedCount[0]['totaluser'];
		$Attendedper = round( $percent * 100, 2 );
		$percent1 = $studentCompletedCount[0]['completeduser'] /$studentAttendedCount[0]['totaluser'];
		$Completedper = round( $percent1 * 100, 2 ); 
		 
		$data['Attendedper']=$Attendedper;
		$data['Completedper']=$Completedper; */
		
/* $data['studentSBB']=$this->Dashboard_model->studentSBB($schoolid,$startdate,$enddate,$userid,$grade_id,$section);//SBB 
$data['studentSGB']=$this->Dashboard_model->studentSGB($schoolid,$startdate,$enddate,$userid,$grade_id,$section);//SGB 
$data['studentSAB']=$this->Dashboard_model->studentSAB($schoolid,$startdate,$enddate,$userid,$grade_id,$section);//SAB  
*/		
		$data['StudentBadgeCount']=$this->Dashboard_model->getStudentBadgeCount($schoolid,$userid,$grade_id);//Student Badge
		
		$arrofskillscore = $this->Dashboard_model->studentSkillScore($schoolid,$startdate,$enddate,$userid);

		$res_tot_memory=$res_tot_vp=$res_tot_fa= $res_tot_ps=$res_tot_lang=0;
		$res_tot_memory_i=$res_tot_vp_i=$res_tot_fa_i= $res_tot_ps_i=$res_tot_lang_i=0;
		$month_array=$month_array_chart=array();
		foreach($arrofskillscore as $get_res)
		{
			$month_array[$get_res['playedMonth']][$get_res['gs_id']]['score']+=$get_res['score']; 
			if(!isset($month_array[$get_res['playedMonth']][$get_res['gs_id']]['count'])){$month_array[$get_res['playedMonth']][$get_res['gs_id']]['count']=0;}
			$month_array[$get_res['playedMonth']][$get_res['gs_id']]['count']+=1;
			$month_array_chart[$get_res['playedMonth']][$get_res['gs_id']]=$month_array[$get_res['playedMonth']][$get_res['gs_id']]['score']/$month_array[$get_res['playedMonth']][$get_res['gs_id']]['count'];
			
			if(($get_res['gs_id']=='59')){
			$res_tot_memory_i++;
			$res_tot_memory += $get_res['score'];	
			}else{
			$res_tot_memory += 0.00;
			}
			if(($get_res['gs_id']=='60')){
			$res_tot_vp_i++;

			$res_tot_vp += $get_res['score'];	
			}else{
			$res_tot_vp += 0.00;
			}
			if(($get_res['gs_id']=='61')){
			$res_tot_fa_i++;

			$res_tot_fa += $get_res['score'];	
			}else{
			$res_tot_fa += 0.00;
			}
			if(($get_res['gs_id']=='62')){
			$res_tot_ps_i++;

			$res_tot_ps += $get_res['score'];	
			}else{
			$res_tot_ps += 0.00;
			}
			if(($get_res['gs_id']=='63')){
			$res_tot_lang_i++;

			$res_tot_lang += $get_res['score'];	
			}else{
			$res_tot_lang += 0.00;
			}

		}

		$tot = (($res_tot_memory/$res_tot_memory_i)+($res_tot_vp/$res_tot_vp_i)+($res_tot_fa/$res_tot_fa_i)+($res_tot_ps/$res_tot_ps_i)+($res_tot_lang/$res_tot_lang_i))/5;
		$skillQuotient_value = round($tot,2);

		

		$innwer_arr1=$innwer_arr2=array();
		foreach($month_array_chart as $key=>$month_arr_chart)
		{
		$innwer_arr1[$key]=0;
		if(!isset($innwer_arr1[$key])){$innwer_arr1[$key]=0;}
		foreach($month_arr_chart as $chart)
		{
		$innwer_arr1[$key]+=$chart;
		}
		}
		foreach($innwer_arr1 as $key=>$value)
		{
		$innwer_arr2[$key]=round(($value/5),2);
		}
		$OverallPerformance_value=$innwer_arr2;
		$month_score=$month_array_chart;


		$qryPlayedCount_dayschart=$this->Dashboard_model->studentPuzzlePlayedDays($schoolid,$startdate,$enddate,$userid);
 
		foreach($qryPlayedCount_dayschart as $key=>$arrPlayedDays_arr)
		{
			$arrPlayedDaysinner[]=$arrPlayedDays_arr['monthlist'];
		}
		$arrPlayedDays=array_count_values($arrPlayedDaysinner);
		
		$data['academicMonths'] = $this->Dashboard_model->academymonths($startdate);
		$data['OverallPerformance_value']=$OverallPerformance_value;
		$data['arrPlayedDays']=$arrPlayedDays;
		
		//Game Play Status
		$qryuserattemptcountbymon=$this->Dashboard_model->studentAttemptedGameCount($schoolid,$startdate,$enddate,$userid);
		$qryusercompletecountbymon=$this->Dashboard_model->studentCompletedGameCount($schoolid,$startdate,$enddate,$userid);
		
		foreach($qryuserattemptcountbymon as $objuserattemptbymon)
		{
			$userattemptbymon[$objuserattemptbymon['monthlist']]=$objuserattemptbymon;
		}
		foreach($qryusercompletecountbymon as $objusercompletebymon)
		{
			$usercompletebymon[$objusercompletebymon['monthlist']]=$objusercompletebymon;
		}
		$data['userattemptbymon']=$userattemptbymon;
		$data['usercompletebymon']=$usercompletebymon;
		
		//echo "<pre>";print_r($data);exit;
		$this->load->view('header', $data);
		$this->load->view('student/strudent_profile', $data);
		$this->load->view('footer');
		
	}
	
	public function ajax_studentskillscore()
	{
		//if($this->session->schoolid=="" || !isset($this->session->schoolid)){ redirect('index.php'); }
		$schoolid= $this->session->schoolid;
		$startdate=$this->session->school_startdate;
		$enddate=date('Y-m-d');
		$skillid = $this->input->post('skillid'); 
		$userid = $this->input->post('userid'); 
		$username = $this->input->post('username'); 
		
		$data['SkillList']= $this->Dashboard_model->TotalSkilllist($skillid);
		
		$qryavgskillscore = $this->Dashboard_model->studentavgSkillScore($schoolid,$startdate,$enddate,$userid,$skillid);
		if($skillid=='ALL')
		{
			$qryavgskillscore_attendays = $this->Dashboard_model->studentSkillPlayedDays($schoolid,$startdate,$enddate,$userid,$skillid);
			foreach($qryavgskillscore_attendays as $objavgskillscore_attendays)
			{
				$avgskillscore_days[$objavgskillscore_attendays['gs_id']]=$objavgskillscore_attendays;
			}
			$asapavgskillscore=0;
		}
		else
		{
			$qryasapavgskillscore=$this->Dashboard_model->student_AsapavgSkillScore($schoolid,$userid,$skillid,$username);
			foreach($qryasapavgskillscore as $asapscore)
			{
				$asapavgskillscore[$asapscore['gs_id']]=$asapscore;
			}
			$avgskillscore_days=0;
		}		
		
		
		foreach($qryavgskillscore as $objavgskillscore)
		{
			$avgskillscore[$objavgskillscore['gs_id']]=$objavgskillscore;
		}
		
		
		
		
		$data['avgskillscore']=$avgskillscore;
		$data['asapavgskillscore']=$asapavgskillscore;
		$data['avgskillscore_days']=$avgskillscore_days;
		
		$this->load->view('student/ajax_studentskillscore', $data);
	}
	public function intervetionreport()
	{
		$schoolid = $this->session->schoolid; 
		//Grade Page
		$grade_id=$this->input->post('grade_id');
		$section=$this->input->post('section');
		$startdate=$this->session->school_startdate;
		$enddate=date('Y-m-d');
		
		
		$arrofintervetionscorerange_clp= $this->Dashboard_model->intervetionreport_clp($schoolid,$startdate,$enddate,$grade_id,$section); // clp intervetion report
		$arrofintervetionscorerange_asap= $this->Dashboard_model->intervetionreport_asap($schoolid,$startdate,$enddate,$grade_id,$section); // clp intervetion report
		
		/* foreach($arrofintervetionscorerange_clp as $key1=>$val1)
		{
			if($bspiranges['scorerange']=='<=20')
			{
				$query1[]=$bspiranges[$key1]['rangecount'];
			}
		}
		 */
		$data['scorerange_clp']=$arrofintervetionscorerange_clp;
		$data['scorerange_asap']=$arrofintervetionscorerange_asap;
		$this->load->view('ajax_intervetionreport', $data);			 
	}
	
	public function userscore()
	{  
		if($this->session->schoolid=="" || !isset($this->session->schoolid)){redirect('index.php');}
		$data['returnURL']=$this->agent->referrer();
		
		$schoolid = $this->session->schoolid;
		$data['schooldetails'] = $this->Dashboard_model->schooldetails($schoolid);
		$data['userskillscore']=$this->Dashboard_model->userscore_grade($schoolid,'',$this->session->school_startdate,'');
		

		$this->load->view('header', $data);
		$this->load->view('userscore/userscore');
		$this->load->view('footer');
	}
	 public function userview()
	{
		if($this->session->schoolid=="" || !isset($this->session->schoolid)){redirect('index.php');}
		$schoolid= $this->session->schoolid;
		$startdate=$this->session->school_startdate;
		$enddate=date('Y-m-d');
		$username = $this->uri->segment(3);
		$data['schooldetails'] = $this->Dashboard_model->schooldetails($schoolid);
		$data['studentdetails']=$this->Dashboard_model->studentDetails($schoolid,$username); // Rank
		$userid=$data['studentdetails'][0]['id'];
		$grade_id=$data['studentdetails'][0]['grade_id'];
		$plan_id=$data['studentdetails'][0]['gp_id'];
		$section=$data['studentdetails'][0]['section'];
		$data['userid']=$userid;
		$data['returnURL']=$this->agent->referrer();
		$uname = $username;
		
		/* New Report  */
		$pid =$data['query'][0]['gp_id'];
		$data['Playedgames'] = $this->Dashboard_model->getgamenames($userid,$plan_id,$startdate,$enddate);
		$data['academicmonths'] = $this->Dashboard_model->getacademicmonths($startdate,$enddate);
		
		$data['IsAsapEnable'] = $this->Dashboard_model->IsAsapEnable($uname);
		$data['IsCLPEnable'] = $this->Dashboard_model->IsCLPEnable($userid);
		
		$data['getasapinfo'] = $this->Dashboard_model->getasapinfo($userid);
		$data['getuserid'] = $this->Dashboard_model->getuserid($uname);
		
		/*Current cycle*/
		$SessionLevel=$this->Dashboard_model->getCurrentSessionLevel($userid);
		if($SessionLevel[0]['session_id']!='')
		{ 
	
			foreach($this->config->item('CYCLE') as $cycle)
			{
				$range=explode('-',$cycle);
				//echo "<pre>";print_r($range);
				if($range[0]<=$SessionLevel[0]['session_id'] && $range[1]>=$SessionLevel[0]['session_id'])
				{
					$Session_StartRange=$range[0];
					$Session_EndRange=$range[1];
				}
				
			}
			$Session_Start_Range=$Session_StartRange;
			$Session_End_Range=$Session_EndRange;
			$Session_Curid=$SessionLevel[0]['session_id'];
			/* $this->session->set_userdata('Session_StartRange', $Session_StartRange);
			$this->session->set_userdata('Session_EndRange', $Session_EndRange);
			$this->session->set_userdata('Session_Curid', $SessionLevel[0]['session_id']); */
		}
		else
		{
			//echo 'hai'; exit;
			$SessionVar=$this->config->item('CYCLE');
			$range=explode("-",$SessionVar[0]);
			//echo $range[1]; exit;
			$Session_StartRange=$range[0];
			$Session_EndRange=$range[1];
			
			$Session_Start_Range=$Session_StartRange;
			$Session_End_Range=$Session_EndRange;
			$Session_Curid=0;
			
			/* $this->session->set_userdata('Session_StartRange', $Session_StartRange);
			$this->session->set_userdata('Session_EndRange', $Session_EndRange);
			$this->session->set_userdata('Session_Curid', 0); */
		}
		$data['Session_Start_Range']=$Session_Start_Range;
		$data['Session_End_Range']=$Session_End_Range; 
		
		$data['default_cycle']=$this->Dashboard_model->getDefaultCycleData($Session_Start_Range,$Session_End_Range,$Session_Curid);

		$startdate = $data['getasapinfo'][0]['startdate'];
		$enddate = $data['getasapinfo'][0]['enddate'];
		$data['academicmonths'] = $this->Dashboard_model->getacademicmonths($startdate,$enddate);
		
		 $asapuserid = $data['getuserid'][0]['id']; 
		
		 $data['asapbspi'] = $this->Dashboard_model->getbspicomparison($asapuserid);
		 $data['clpbspi'] = $this->Dashboard_model->clpbspi($userid);		 
			/*SKILL PERFORMANCE*/
	
$data['skillwiseaverage'] = $this->Dashboard_model->getskillwise_avg($uname);

$data['set1avg_M'] = ($data['skillwiseaverage'][0]['skillscorem']);

$data['set1avg_V'] = ($data['skillwiseaverage'][0]['skillscorev']);

$data['set1avg_F'] = ($data['skillwiseaverage'][0]['skillscoref']);

$data['set1avg_P'] = ($data['skillwiseaverage'][0]['skillscorep']);

$data['set1avg_L'] = ($data['skillwiseaverage'][0]['skillscorel']);
		/*SKILL PERFORMANCE*/
		
		$data['getcounters'] = $this->Dashboard_model->getcounters($userid);
		$data['getcrowny'] = $this->Dashboard_model->getcrowny($userid);
		$data['getattemptsession'] = $this->Dashboard_model->getattemptsession($userid);
		$data['getcompsession'] = $this->Dashboard_model->getcompsession($userid);
		
		/*SKILL PERFORMANCE CLP*/
$data['clp_skillwiseaverage'] = $this->Dashboard_model->get_clp_skillwise_avg($userid);
$data['MonthWiseSkillScore'] = $this->Dashboard_model->getMonthWiseSkillScore($userid,$startdate,$enddate);
$data['CLP_M'] = ($data['clp_skillwiseaverage'][0]['skillscorem']);

$data['CLP_V'] = ($data['clp_skillwiseaverage'][0]['skillscorev']);

$data['CLP_F'] = ($data['clp_skillwiseaverage'][0]['skillscoref']);

$data['CLP_P'] = ($data['clp_skillwiseaverage'][0]['skillscorep']);

$data['CLP_L'] = ($data['clp_skillwiseaverage'][0]['skillscorel']);
		/*SKILL PERFORMANCE CLP*/
		
		/* Efficiency Graph */

$arrofEfficiency=$this->Dashboard_model->getUserEfficiencyGraph($userid,$startdate,$enddate);
foreach($arrofEfficiency as $month)
{
	$userscore[$month['monthNumber'].$month['yearNumber'].'-S']=$month['score'];
	$userresponsetime[$month['monthNumber'].$month['yearNumber'].'-T']=$month['rtime'];
}
$data['Uscore']=$userscore;
$data['Utime']=$userresponsetime;
//echo "<pre>";print_r($data);exit;
/* Efficiency Graph */
		$this->load->view('header', $data);
		$this->load->view('user_view', $data);
		$this->load->view('footer');
	}
	
	
	public function mybspi_report_ajax()
{
	/*$yeramonths = $this->comma_separated_to_array($_POST['hdnMonthID']);
	//print_r($yeramonths); exit;
	$test = "'" . implode("','", $yeramonths) . "'"; */
	$userid = $_POST['userid'];
	$mnthval = $_POST['bspireport'];
	$data['bspireport'] = $this->Dashboard_model->getbspireport1($userid,$mnthval); 
	$res_tot_memory=$res_tot_vp=$res_tot_fa= $res_tot_ps=$res_tot_lang=0;
$res_tot_memory_i=$res_tot_vp_i=$res_tot_fa_i= $res_tot_ps_i=$res_tot_lang_i=0;

foreach($data['bspireport'] as $get_res)
{
	//echo $get_res['gs_id'];
	//echo $get_res['gamescore'];
	if(($get_res['gs_id']=='59')){
			$res_tot_memory_i++;
			  $res_tot_memory += $get_res['gamescore'];	
		}else{
		 	$res_tot_memory += 0.00;
			}
if(($get_res['gs_id']=='60')){
				$res_tot_vp_i++;

			 	$res_tot_vp += $get_res['gamescore'];
		}else{
			 $res_tot_vp += 0.00;
			}
if(($get_res['gs_id']=='61')){
				$res_tot_fa_i++;

				 $res_tot_fa += $get_res['gamescore'];	
		}else{
			 $res_tot_fa += 0.00;
			}
if(($get_res['gs_id']=='62')){
				$res_tot_ps_i++;

			 $res_tot_ps += $get_res['gamescore'];	
		}else{
			 $res_tot_ps += 0.00;
			}
if(($get_res['gs_id']=='63')){
				$res_tot_lang_i++;

			 $res_tot_lang += $get_res['gamescore'];
		}else{
		 	$res_tot_lang += 0.00;
			}
		//$month_cnt =  count($_POST['option']);
}
if($res_tot_memory_i==0){$res_tot_memory_i=1;}
	if($res_tot_vp_i==0){$res_tot_vp_i=1;}
	if($res_tot_fa_i==0){$res_tot_fa_i=1;}
	if($res_tot_ps_i==0){$res_tot_ps_i=1;}
	if($res_tot_lang_i==0){$res_tot_lang_i=1;}
$tot = (($res_tot_memory/$res_tot_memory_i)+($res_tot_vp/$res_tot_vp_i)+($res_tot_fa/$res_tot_fa_i)+($res_tot_ps/$res_tot_ps_i)+($res_tot_lang/$res_tot_lang_i))/5;

echo $bspi = $tot;

}

public function getSkillChart()
{
	$cycleid = $this->input->post('cycle');
	$range_value = $this->input->post('range');
	$type = $this->input->post('type');
	$userid = $this->input->post('userid');
	
	$range=explode("-",$range_value);
//	$data['bspi']=$this->getBSPI($userid);

	$data['bspirange']=$this->Dashboard_model->getBSPI_range($userid,$range[0],$range[1]);
	$data['bspi']=$data['bspirange'][0]['avgbspiset1'];
	
	$academicyear=$this->Dashboard_model->getacademicyearbyschoolid($userid);
	
	if($type=='ADVANCE')
	{
		
		$arrSkillChart=$this->Dashboard_model->getAdvancedSkillChart($userid,$range[0],$range[1],$this->session->Session_Curid,$academicyear[0]['startdate'],$academicyear[0]['enddate']);
		$mybspiCalendarSkillScore=array("SID59"=>0,"SID60"=>0,"SID61"=>0,"SID62"=>0,"SID63"=>0);
		foreach($arrSkillChart as $score)
		{
			$mybspiCalendarSkillScore["SID".$score['gs_id']]=round($score['gamescore'],2);
		}
		 $data['SkillChart']=$mybspiCalendarSkillScore;
		 $data['skills'] = $this->Dashboard_model->getskills();
	}
	else
	{
		$arrSkillChart=$this->Dashboard_model->getBasicSkillChart($userid,$range[0],$range[1],$this->session->Session_Curid,$academicyear[0]['startdate'],$academicyear[0]['enddate']);
		$mybspiCalendarSkillScore=array("SID59"=>0,"SID60"=>0,"SID61"=>0,"SID62"=>0,"SID63"=>0);
		foreach($arrSkillChart as $score)
		{
			$mybspiCalendarSkillScore[$score['gs_id']]=round($score['gamescore'],2);
		}
		$data['SkillChart']=$mybspiCalendarSkillScore;
		$tsivalue=$this->Dashboard_model->getSkillKitBSPI($userid,$range[0],$range[1]);
		$data['bspi']=$tsivalue[0]['tsi'];
		$data['skills'] = $this->Dashboard_model->getAssignSkills($userid);
	}
	
	$data['CurrentBSPIName']=$this->Dashboard_model->getCurrentBSPIName($range[0],$range[1],$this->session->Session_Curid);
	
	$data['type']=$type;
		
	//echo "<pre>";print_r($data);exit;
	$this->load->view('reports/ajax_skillchart', $data);
}

	 public function userperformance()
	{
		if($this->session->schoolid=="" || !isset($this->session->schoolid)){redirect('index.php');}
		$data['returnURL']=$this->agent->referrer();
		$data['schooldetails'] = $this->Dashboard_model->schooldetails($this->session->schoolid);
		
		$this->load->view('header', $data);
		$this->load->view('patient_performance', $data);
		$this->load->view('footer');
	}  
	 public function clp_userperformance()
	{
		if($this->session->schoolid=="" || !isset($this->session->schoolid)){redirect('index.php');}		
		
		$academicid = '';
		$studentname = '';
		$gradeid = '';		
		$section = '';		
		
		$sid=$this->session->schoolid;
		$startdate=$this->session->school_startdate;
		$enddate=date("Y-m-d");
		$data['asap_reports'] = $this->Dashboard_model->asap_reports($sid,$gradeid,$section);
		$data['clp_reports'] = $this->Dashboard_model->clp_reports($sid,$gradeid,$section); 
	
 
		
		$this->load->view('clp_user_performance_ajax', $data);
	} 
	
	/*-------------------Forget password-----------*/
	
	public function confirmation_email($toemailid,$subject,$message)
	{
				//Create a new PHPMailer instance
		/*$mail = new PHPMailer;
		$mail->isSMTP();
		$mail->SMTPDebug = 0;
		$mail->Debugoutput = 'html';
		$mail->Host = "smtp.falconide.com";
		$mail->Port = 587;
		$mail->SMTPAuth = true;
		$mail->SMTPSecure = "";
		$mail->Username = "skillsangelsfal";
		$mail->Password = "SkillAngels@123";
		$mail->setFrom('angel@skillangels.com', 'Intelekts');
		$mail->addReplyTo('angel@skillangels.com', 'Intelekts');
		$mail->addAddress($toemailid, ''); //to mail id
		$mail->Subject = $subject;
		$mail->msgHTML($message);
		 if (!$mail->send()) {
		   //echo "Mailer Error: " . $mail->ErrorInfo;
		} else {
		   //echo "Message sent!";
		}  */ 
	}
	
	
	
	public function forgetpwd_popup()
	{	 
		$usermailid = $_POST['usermailid'];  
		//echo $usermailid;exit;
		$data['usermailid'] = $this->Dashboard_model->getmailid($usermailid);
		$fname = $data['usermailid'][0]['fname'];
		//echo $fname;exit;
		/* echo "<pre>";
		print_r($data['usermailid']);exit; */
		if(($data['usermailid'][0]['mailcount']) == 1)
		{ 
			$randid=rand(1000000, 9999999);
			$forgetpwdinsertlog = $this->Dashboard_model->fpwdinsertlog($usermailid,$randid);
			$sub="Reset Password";
			$message='<table align="center" width="800px" border="1" cellspacing="0" cellpadding="0" style="font-size:medium;margin-right:auto;margin-left:auto;border:1px solid rgb(197,197,197);font-family:Arial,Helvetica,sans-serif;background-image:initial;background-repeat:initial;box-shadow: 10px 10px 5px #35395e;"><tbody><tr style="display:block;overflow:hidden;background: #1e88e5;"><td style="float:left;border:0px;text-align: center;padding: 10px 0px;width:33%;color: #fff;"></td><td style="float:left;border:0px;text-align: center;padding: 5px 0px;width: 33%;color: #fff;"> <div class="animate form login_form"><img   src="'.base_url().'assets/images/web_logo.png" style="width:100%;"></div></td></tr><tr style="padding:0px;margin:10px 42px 20px;display:block;font-size:13px;font-family:Verdana,Geneva,sans-serif;line-height:18px;text-align:justify"><td colspan="2" style="border:0px">Dear '.$fname.',<br/><br/> Have a good day <br/><br/>Click below link to create new password	<br/><br/><br/><a href="'.base_url().'index.php/home/changepassword?randid='.md5($randid).'&usrmailid='.md5($usermailid).'" style="color: #fff;background: #ea0b72;padding: 13px;border-radius: 5px;text-decoration: none;font-weight: bold;margin-top: 10px;" target="_blank" >Create Password</a><br/><br/><br/><br/>Regards,<br/><strong><span class="ed6">EdSix Brain Lab<sup>TM</sup> Pvt Ltd</span><br> </strong><br/></td></tr><tr style=""><td style="text-align:center;color:#ee1b5b;border:0px;background-size:100%;background-image: url('.base_url().'assets/images/emailer/footer.jpg);padding-top:20px;padding-bottom:20px;font-family: cursive;font-size: 20px;"></td></tr><tr style="display:block;overflow:hidden"><td style="float:left;border:0px;"></td></tr></tbody></table>';
		 
			//$this->confirmation_email($data['usermailid'][0]['usermailid'],$sub,$message);
		 	echo $message;exit;
			 
			echo 1;exit; // valid users			
		}
		else
		{
			echo 0;exit;// invalid user
		}  
	} 
	 public function changepassword()
	 {
		 
		 $usremailid = $_REQUEST['usrmailid']; 
		 $randid=$_REQUEST['randid'];
		 if($usremailid!='' && $randid!='')
		 {
			 $isvaliduser = $this->Dashboard_model->chkisvalidusr($usremailid,$randid);
			//echo "<pre>";print_r($isvaliduser);exit;
			 
			 if($isvaliduser[0]['usremailid']!='')
			 {}else{redirect("index.php");exit;}
			$this->load->view('changepassword',$data);
		 }
			if(isset($_POST))
			{
				if(isset($_POST['newpassword']))
				{ 
					if($_POST['newpassword']==$_POST['confirmpwd'])
					{	 
						$arruserdetails = $this->Dashboard_model->getResetpwdUserDetails($isvaliduser[0]['usremailid']);  
						//echo "<pre>";print_r($arruserdetails);exit;
						
						$pwdupdate=$this->Dashboard_model->ResetUserPwd($_REQUEST['newpassword'],$isvaliduser[0]['usremailid']);
						//echo "<pre>";print_r($arruserdetails);exit;
						$logupdate=$this->Dashboard_model->ResetUserPwd_log($usremailid,$randid,$_REQUEST['newpassword']); 
						//echo "<pre>";print_r($arruserdetails);exit;
						$baseurl="http://".$_SERVER['HTTP_HOST'].dirname($_SERVER['PHP_SELF']);
						$subject = 'Reset Password Successfully';
						$message = '<table align="center" width="800px" border="1" cellspacing="0" cellpadding="0" style="font-size:medium;margin-right:auto;margin-left:auto;border:1px solid rgb(197,197,197);font-family:Arial,Helvetica,sans-serif;background-image:initial;background-repeat:initial;box-shadow: 10px 10px 5px #35395e;"><tbody><tr style="display:block;overflow:hidden;background: #1e88e5;"><td style="float:left;border:0px;text-align: center;padding: 10px 0px;width:33%;color: #fff;"></td><td style="float:left;border:0px;text-align: center;padding: 5px 0px;width: 33%;color: #fff;"> <div class="animate form login_form"><img   src="'.base_url().'assets/images/web_logo.png" style="width:100%;"></div></td></tr><tr style="padding:0px;margin:10px 42px 20px;display:block;font-size:13px;font-family:Verdana,Geneva,sans-serif;line-height:18px;text-align:justify"><td colspan="2" style="border:0px">Dear '.$arruserdetails[0]['fname'].',<br/><br/>
						Your can reset your password.<br/><br/> Now, You can login <a href="'.base_url().'" target="_blank" >'.base_url().'</a>  with the following credentials <br/><br/>Username <strong> : '.$arruserdetails[0]['email'].'</strong><br/>Password<strong> : '.$_REQUEST['newpassword'].'</strong><br/><br/><br/>All The Very Best!!!<br/><br/>Regards,<br/><strong><span class="ed6">EdSix Brain Lab<sup>TM</sup> Pvt Ltd</span><br> </strong><br/></td></tr><tr style=""><td style="text-align:center;color:#ee1b5b;border:0px;background-size:100%;background-image: url('.base_url().'assets/images/emailer/footer.jpg);padding-top:20px;padding-bottom:20px;font-family: cursive;font-size: 20px;"></td></tr><tr style="display:block;overflow:hidden"><td style="float:left;border:0px;">
						</div></td></tr><tr style="display:block;overflow:hidden"><td style="float:left;border:0px;"></td></tr></tbody></table>';
						echo $message;exit; 
						
						//echo "<pre>";print_r($arruserdetails);exit;
						//Create a new PHPMailer instance
						//$this->confirmation_email($arruserdetails[0]['email'],$subject,$message); 
						 echo 1;exit;
				 
				}
				else
				{
					echo 0;exit;
				//	$data['response']='Password does not match';
				}
				}
			} 
	} 
	 
}
