<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Bka_reports extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	  public function __construct()
        {
                // Call the CI_Model constructor
                parent::__construct();
				$this->load->model('kinderangels_ba_model');//echo "hi";exit;
				$this->load->library('session');
				$this->load->library('My_PHPMailer');
				$this->load->library('Ajax_pagination');
				$this->perPage = 12;
        }
		
	public function index()
	{			
		//$this->load->view('header');
		$this->load->view('index');
		//$this->load->view('footer');		
	}
	 
	
	
	public function userview()
	{
		//error_reporting(E_ALL); 
		//echo "ka";exit;		
		$userid = $this->uri->segment(3);
	//	$data['getusername'] = $this->kinderangels_ba_model->getusername($userid);
		$data['gettotalscore'] = $this->kinderangels_ba_model->gettotalscore($userid); 
		$data['gettotalcrownies'] = $this->kinderangels_ba_model->gettotalcrownies($userid); 
		$data['getmonthlyscore'] = $this->kinderangels_ba_model->getchartdetails($userid); 
	//	$data['getmonthname'] = $this->kinderangels_ba_model->getmonthname($userid); 
	//	echo "<pre>";print_r($data['getmonthlyscore']);exit;
		
		$uname = $data['getusername'][0]['username'];
		//echo $uname ;exit;
		/* New Report  */
		$pid =$data['query'][0]['gp_id'];
		 
		
	//	$data['IsAsapEnable'] = $this->kinderangels_ba_model->IsAsapEnable($uname);
	//	$data['IsCLPEnable'] = $this->kinderangels_ba_model->IsCLPEnable($userid);
		
		$data['getasapinfo'] = $this->kinderangels_ba_model->getasapinfo($userid);
		//$data['getmonthlyscore'] = $this->kinderangels_ba_model->getchartdetails($userid);
		//echo "<pre>";print_r ($data['getmonthlyscore']);exit;
	//	$data['getuserid'] = $this->kinderangels_ba_model->getuserid($uname);
		
		/*Current cycle*/
	//	$SessionLevel=$this->kinderangels_ba_model->getCurrentSessionLevel($userid);
	//	$DefaultCycle=$this->kinderangels_ba_model->getAllDefaultCycle();
		
		if($SessionLevel[0]['session_id']!='')
		{ 
	
			foreach($DefaultCycle as $cycle)
			{
				$range=explode('-',$cycle['value']);
				//echo "<pre>";print_r($range);
				if($range[0]<=$SessionLevel[0]['session_id'] && $range[1]>=$SessionLevel[0]['session_id'])
				{
					$Session_StartRange=$range[0];
					$Session_EndRange=$range[1];
				}
				
			}
			$Session_Start_Range=$Session_StartRange;
			$Session_End_Range=$Session_EndRange;
			$Session_Curid=$SessionLevel[0]['session_id'];
			/* $this->session->set_userdata('Session_StartRange', $Session_StartRange);
			$this->session->set_userdata('Session_EndRange', $Session_EndRange);
			$this->session->set_userdata('Session_Curid', $SessionLevel[0]['session_id']); */
		}
		else
		{
			//echo 'hai'; exit;
			$SessionVar=$DefaultCycle[0]['value'];
			$range=explode("-",$SessionVar[0]);
			//echo $range[1]; exit;
			$Session_StartRange=$range[0];
			$Session_EndRange=$range[1];
			
			$Session_Start_Range=$Session_StartRange;
			$Session_End_Range=$Session_EndRange;
			$Session_Curid=0;
			
			/* $this->session->set_userdata('Session_StartRange', $Session_StartRange);
			$this->session->set_userdata('Session_EndRange', $Session_EndRange);
			$this->session->set_userdata('Session_Curid', 0); */
		}
		$data['Session_Start_Range']=$Session_Start_Range;
		$data['Session_End_Range']=$Session_End_Range; 
		
	//	$data['default_cycle']=$this->kinderangels_ba_model->getDefaultCycleData($Session_Start_Range,$Session_End_Range,$Session_Curid);

		$startdate = $data['getasapinfo'][0]['startdate'];
		$enddate = $data['getasapinfo'][0]['enddate'];
		//$data['academicmonths'] = $this->kinderangels_ba_model->getacademicmonths($startdate,$enddate);
		
		 $asapuserid = $data['getuserid'][0]['id']; 
		
	//	 $data['asapbspi'] = $this->kinderangels_ba_model->getbspicomparison($asapuserid);
		// $data['clpbspi'] = $this->kinderangels_ba_model->clpbspi($userid);		 
			/*SKILL PERFORMANCE*/
	
	//	$data['skillwiseaverage'] = $this->kinderangels_ba_model->getskillwise_avg($uname);

		$data['set1avg_M'] = ($data['skillwiseaverage'][0]['skillscorem']);

		$data['set1avg_V'] = ($data['skillwiseaverage'][0]['skillscorev']);

		$data['set1avg_F'] = ($data['skillwiseaverage'][0]['skillscoref']);

		$data['set1avg_P'] = ($data['skillwiseaverage'][0]['skillscorep']);

		$data['set1avg_L'] = ($data['skillwiseaverage'][0]['skillscorel']);
		/*SKILL PERFORMANCE*/
		
		 
		
		/*SKILL PERFORMANCE CLP*/
	//	$data['clp_skillwiseaverage'] = $this->kinderangels_ba_model->get_clp_skillwise_avg($userid);
		//$data['MonthWiseSkillScore'] = $this->kinderangels_ba_model->getMonthWiseSkillScore($userid,$startdate,$enddate);
		$data['CLP_M'] = ($data['clp_skillwiseaverage'][0]['skillscorem']);

		$data['CLP_V'] = ($data['clp_skillwiseaverage'][0]['skillscorev']);

		$data['CLP_F'] = ($data['clp_skillwiseaverage'][0]['skillscoref']);

		$data['CLP_P'] = ($data['clp_skillwiseaverage'][0]['skillscorep']);

		$data['CLP_L'] = ($data['clp_skillwiseaverage'][0]['skillscorel']);
		 
		// Intermediate & post Assessment
		// $data['InterAsapData'] = $this->kinderangels_ba_model->getInterAsapData($userid);
		// $data['PostAsapData'] = $this->kinderangels_ba_model->getPostAsapData($userid);

		//echo "<pre>";print_r($data);exit;
		$this->load->view('header');
		$this->load->view('kinderangels/user_viewdetails',$data);
		$this->load->view('footer');
	}
	
	 public function mybspi_report_ajax()
	{
		/*$yeramonths = $this->comma_separated_to_array($_POST['hdnMonthID']);
		//print_r($yeramonths); exit;
		$test = "'" . implode("','", $yeramonths) . "'"; */
		$userid = $_POST['userid'];
		$mnthval = $_POST['bspireport'];
	//	$data['bspireport'] = $this->kinderangels_ba_model->getbspireport1($userid,$mnthval); 
		$res_tot_memory=$res_tot_vp=$res_tot_fa= $res_tot_ps=$res_tot_lang=0;
		$res_tot_memory_i=$res_tot_vp_i=$res_tot_fa_i= $res_tot_ps_i=$res_tot_lang_i=0;

		foreach($data['bspireport'] as $get_res)
		{
			//echo $get_res['gs_id'];
			//echo $get_res['gamescore'];
			if(($get_res['gs_id']=='59')){
				$res_tot_memory_i++;
				  $res_tot_memory += $get_res['gamescore'];	
			}else{
				$res_tot_memory += 0.00;
				}
			if(($get_res['gs_id']=='60')){
					$res_tot_vp_i++;

					$res_tot_vp += $get_res['gamescore'];
			}else{
				 $res_tot_vp += 0.00;
				}
			if(($get_res['gs_id']=='61')){
					$res_tot_fa_i++;

					 $res_tot_fa += $get_res['gamescore'];	
			}else{
				 $res_tot_fa += 0.00;
				}
			if(($get_res['gs_id']=='62')){
					$res_tot_ps_i++;

				 $res_tot_ps += $get_res['gamescore'];	
			}else{
				 $res_tot_ps += 0.00;
				}
			if(($get_res['gs_id']=='63')){
					$res_tot_lang_i++;

				 $res_tot_lang += $get_res['gamescore'];
			}else{
				$res_tot_lang += 0.00;
				}
			//$month_cnt =  count($_POST['option']);
		}
		if($res_tot_memory_i==0){$res_tot_memory_i=1;}
		if($res_tot_vp_i==0){$res_tot_vp_i=1;}
		if($res_tot_fa_i==0){$res_tot_fa_i=1;}
		if($res_tot_ps_i==0){$res_tot_ps_i=1;}
		if($res_tot_lang_i==0){$res_tot_lang_i=1;}
		$tot = (($res_tot_memory/$res_tot_memory_i)+($res_tot_vp/$res_tot_vp_i)+($res_tot_fa/$res_tot_fa_i)+($res_tot_ps/$res_tot_ps_i)+($res_tot_lang/$res_tot_lang_i))/5;

		echo $bspi = $tot; 
	}  
	 
	
	
	public function getSkillChart()
	{
		$cycleid = $this->input->post('cycle');
		$range_value = $this->input->post('range');
		$type = $this->input->post('type');
		$userid = $this->input->post('userid');
		
		$range=explode("-",$range_value);
	//	$data['bspi']=$this->getBSPI($userid);

	//	$data['bspirange']=$this->kinderangels_ba_model->getBSPI_range($userid,$range[0],$range[1]);
		$data['bspi']=$data['bspirange'][0]['avgbspiset1'];
		
	//	$academicyear=$this->kinderangels_ba_model->getacademicyearbyschoolid($userid);
	
		if($type=='ADVANCE')
		{
		
		//	$arrSkillChart=$this->kinderangels_ba_model->getAdvancedSkillChart($userid,$range[0],$range[1],$this->session->Session_Curid,$academicyear[0]['startdate'],$academicyear[0]['enddate']);
			$mybspiCalendarSkillScore=array("SID59"=>0,"SID60"=>0,"SID61"=>0,"SID62"=>0,"SID63"=>0);
			foreach($arrSkillChart as $score)
			{
				$mybspiCalendarSkillScore["SID".$score['gs_id']]=round($score['gamescore'],2);
			}
			$data['SkillChart']=$mybspiCalendarSkillScore;
		//	$data['skills'] = $this->kinderangels_ba_model->getskills();
		}
		else
		{
		//	$arrSkillChart=$this->kinderangels_ba_model->getBasicSkillChart($userid,$range[0],$range[1],$this->session->Session_Curid,$academicyear[0]['startdate'],$academicyear[0]['enddate']);
			$gs_id='';
			$mybspiCalendarSkillScore=array("SID59"=>0,"SID60"=>0,"SID61"=>0,"SID62"=>0,"SID63"=>0);
			foreach($arrSkillChart as $score)
			{
				$mybspiCalendarSkillScore[$score['gs_id']]=round($score['gamescore'],2);
				$gs_id.=$score['gs_id'].",";
			}
			$WeakSkills=trim($gs_id,',');
			$data['SkillChart']=$mybspiCalendarSkillScore;
		//	$tsivalue=$this->kinderangels_ba_model->getSkillKitBSPI($userid,$range[0],$range[1]);
			$data['bspi']=$tsivalue[0]['tsi'];
		//	$data['skills'] = $this->kinderangels_ba_model->getWeakSkills($WeakSkills);	
		//	echo "<pre>";print_r($data['skills']);exit;
		}
	
	//	$data['CurrentBSPIName']=$this->kinderangels_ba_model->getCurrentBSPIName($range[0],$range[1],$this->session->Session_Curid);
	
		$data['type']=$type;
		
		$this->load->view('kinderangels/ajax_skillchart', $data);
	}
	
	public function update_patienttype()
	{
		$data['updatepatienttype'] = $this->kinderangels_ba_model->updatepatienttype($_POST['userid'],$_POST['typeid']);
		echo 1; exit;
	}
	
	public function clp_users_search()
	{
		$academicid = $this->input->post('ddacademyname');
		$studentname = $this->input->post('txtstudentname');
		$gradeid = $this->input->post('ddgradename');
		
	//	$data['asap_reports'] = $this->kinderangels_ba_model->asap_reports();
	//	$data['clp_reports'] = $this->kinderangels_ba_model->clp_reports($academicid,$studentname,$gradeid);
		
		$this->load->view('clp_user_search_res', $data);
	}
	
	
	 
	
	 
}