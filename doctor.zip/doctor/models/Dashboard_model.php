<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard_model extends CI_Model {

        
        public function __construct()
        {
                // Call the CI_Model constructor
                parent::__construct();
				 $this->load->database();
				 $this->load->library('Multipledb');
        }

		public function checklogin($username,$password)
        {
			//echo "SELECT *  FROM doctormaster WHERE (username='".$username."' AND password='".$password."') and status=1";exit;		 
			$query = $this->db->query("SELECT *  FROM doctormaster WHERE (username='".$username."' AND password='".$password."') and status=1");		
			//echo $this->db->last_query(); exit;
			return $query->result_array();
        }	
		
		public function doctorinfo($doctorid)
        {
					 
			$query = $this->db->query("SELECT *,(select state_name from state where id=doctormaster.state) as statename, (select hospitalname from hospitalmaster where id=doctormaster.hospitalid) as hospitalname1  FROM doctormaster WHERE id='".$doctorid."' and status=1");
			//echo $this->db->last_query(); exit;
			return $query->result_array();
        }
		
		public function totalrec_userlist()
        {
			$query = $this->db->query("SELECT count(*) as totalrecord FROM users u where doctorid='".$this->session->doctorid."'");		
			//echo $this->db->last_query(); exit;
			return $query->result_array();
		}

		public function userslist($start,$limit)
        {
			$qry=' ';
			if($limit=='')
			{
				$qry=" ";
			}
			else if($start=='' && $limit!=''){
				$qry=" limit ".$limit;
			}
			else if($start!='' && $limit!=''){
				$qry=" limit ".$start.','.$limit;
			}
					 
			$query = $this->db->query("SELECT id,userid,fname,username,grade_id,(select program_name from program_master where id=u.programid) as programname,(select gradename from program_grade_master where gradeid=u.grade_id and programid=u.programid) as gradename,email,mobile,address,dob,avatarimage,(select state_name from state where id=u.stateid) as statename,(select type from patient_type_master where id=u.patient_type) as patienttype,city,parentname,creation_date,status,isnew,programid  FROM users u where doctorid='".$this->session->doctorid."' order by creation_date desc ".$qry."");		
			//echo $this->db->last_query(); exit;
			return $query->result_array();
        }
		
		public function getusername($userid)
        {
					 
			$query = $this->db->query("SELECT username,isnew FROM users where id='".$userid."'");		
			//echo $this->db->last_query(); exit;
			return $query->result_array();
        }
		
		public function getasapinfo($userid)
        {
					 
			$query = $this->db->query("SELECT id,fname,lname,gender,email,mobile,dob,city,(select state_name from state where id=users.stateid) as statename,couponcode,startdate,enddate,parentname,address,avatarimage,patient_type,portal_type  FROM users where id='".$userid."'");		
			//echo $this->db->last_query(); exit;
			return $query->result_array();
        }
		
		public function getuserid($uname)
        {
					 
			$query = $this->multipledb->db->query("SELECT id  FROM users where username='".$uname."'");		
			//echo $this->db->last_query(); exit;
			return $query->result_array();
        }

		
		
		public function userscount($doctorid,$hospid)
        {
			$query = $this->db->query("SELECT count(*) as total FROM users  WHERE hospitalid='".$hospid."' and doctorid='".$doctorid."'");		
			//echo $this->db->last_query(); exit;
			return $query->result_array();
        }
		
		public function scanstatus($doctorid)
        {
					 
			$query = $this->db->query("SELECT COUNT(qrcode) as scancount from couponmaster where doctorid='".$doctorid."' and status=1");		
			//echo $this->db->last_query(); exit;
			return $query->result_array();
        }
		
	
		public function couponcodecount($doctorid)
        {
			$query = $this->db->query("SELECT count(*) as totalcoupon FROM couponmaster  WHERE doctorid='".$doctorid."' and usedstatus='N'");		
			//echo $this->db->last_query(); exit;
			return $query->result_array();
        }
		
		public function couponlist($doctorid)
        {
			$query = $this->db->query("SELECT *  FROM couponmaster  WHERE doctorid='".$doctorid."' ");		
			//echo $this->db->last_query(); exit;
			return $query->result_array();
        }
		

		public function getstate()
        {
			$query = $this->db->query("SELECT id, state_name FROM state  WHERE countryid=113");		
			//echo $this->db->last_query(); exit;
			return $query->result_array();
        }	
		
		public function gethospital()
        {
			$query = $this->db->query("SELECT id, hospitalname FROM hospitalmaster  WHERE status=1");		
			//echo $this->db->last_query(); exit;
			return $query->result_array();
        }	
		
		public function editdoctor($doctorid)
        {
			$query = $this->db->query("SELECT *,(select state_name from state where id=d.state) as statename,(select hospitalname from hospitalmaster where id=d.hospitalid) as hospitalname1 FROM doctormaster d WHERE d.id='".$doctorid."'");		
			//echo $this->db->last_query(); exit;
			return $query->result_array();
        }	
		
		public function updatedoctor($doctorname,$lname,$gender,$dob,$emailid,$secondaryemailid,$mobile,$secondarymobile,$state,$city,$address,$doctorid,$imgpath,$hospitalname,$Pan,$AccHolderName,$AccNo,$IFSCCode,$BranchName,$BankName)
        {
			if($imgpath!='')
			{
				$query = $this->db->query("UPDATE `doctormaster` SET `doctorname`='".$doctorname."',`lastname`='".$lname."',`gender`='".$gender."',`dateofbirth`='".$dob."',`email`='".$emailid."',`secondaryemail`='".$secondaryemailid."',`state`='".$state."',`city`='".$city."',`mobilenumber`='".$mobile."',`secondarymobilenumber`='".$secondarymobile."',`address`='".$address."',`profileimage`='".$imgpath."',`modifed_on`=NOW(),hospitalname='".$hospitalname."',pan='".$Pan."',accholdername='".$AccHolderName."'
				,accno='".$AccNo."',ifsccode='".$IFSCCode."',branchname='".$BranchName."',bankname='".$BankName."' WHERE id='".$doctorid."'");
			}
			else
			{
				$query = $this->db->query("UPDATE `doctormaster` SET `doctorname`='".$doctorname."',`lastname`='".$lname."',`gender`='".$gender."',`dateofbirth`='".$dob."',`email`='".$emailid."',`secondaryemail`='".$secondaryemailid."',`state`='".$state."',`city`='".$city."',`mobilenumber`='".$mobile."',`secondarymobilenumber`='".$secondarymobile."',`address`='".$address."',`modifed_on`=NOW(),hospitalname='".$hospitalname."',pan='".$Pan."',accholdername='".$AccHolderName."'
				,accno='".$AccNo."',ifsccode='".$IFSCCode."',branchname='".$BranchName."',bankname='".$BankName."' WHERE id='".$doctorid."'");
			}
		//	echo $this->db->last_query(); exit;
			
        }

		 public function getskillwise_avg($uname) 
		{
			
			$query = $this->multipledb->db->query('select id, fname,s1.skillscore_M as skillscorem, skillscore_V as skillscorev,skillscore_F as skillscoref,skillscore_P as skillscorep,skillscore_L as skillscorel, a3.finalscore as avgbspiset1 from users mu

left join 
 (SELECT SUM(score)/5 as finalscore, gu_id, (SELECT sid from users where id=gu_id) as schoolid from (select (AVG(score)) as score, gu_id, gs_id from (SELECT (AVG(`game_score`)) as score , gs_id , gu_id, lastupdate FROM `game_reports` WHERE gs_id in (59,60,61,62,63) and gu_id in (select id from users) group by gs_id , gu_id, lastupdate) a1 group by gs_id, gu_id ) a2 group by gu_id) a3   on a3.gu_id=mu.id 
 
 left join
(select (AVG(score)) as skillscore_M, gu_id from (SELECT (AVG(`game_score`)) as score , gs_id , gu_id, lastupdate FROM `game_reports` WHERE gs_id =59 and gu_id in (select id from users) group by gs_id , gu_id, lastupdate) a1 group by gs_id, gu_id) s1 on s1.gu_id=mu.id 

left join
(select (AVG(score)) as skillscore_V, gu_id from (SELECT (AVG(`game_score`)) as score , gs_id , gu_id, lastupdate FROM `game_reports` WHERE gs_id =60 and gu_id in (select id from users) group by gs_id , gu_id, lastupdate) a1 group by gs_id, gu_id) s2 on s2.gu_id=mu.id 

left join
(select (AVG(score)) as skillscore_F, gu_id from (SELECT (AVG(`game_score`)) as score , gs_id , gu_id, lastupdate FROM `game_reports` WHERE gs_id =61 and gu_id in (select id from users) group by gs_id , gu_id, lastupdate) a1 group by gs_id, gu_id) s3 on s3.gu_id=mu.id 

left join
(select (AVG(score)) as skillscore_P, gu_id from (SELECT (AVG(`game_score`)) as score , gs_id , gu_id, lastupdate FROM `game_reports` WHERE gs_id =62 and gu_id in (select id from users) group by gs_id , gu_id, lastupdate) a1 group by gs_id, gu_id) s4 on s4.gu_id=mu.id 

left join
(select (AVG(score)) as skillscore_L, gu_id from (SELECT (AVG(`game_score`)) as score , gs_id , gu_id, lastupdate FROM `game_reports` WHERE gs_id =63 and gu_id in (select id from users) group by gs_id , gu_id, lastupdate) a1 group by gs_id, gu_id) s5 on s5.gu_id=mu.id 
 
 

 where username="'.$uname.'" ORDER BY avgbspiset1 DESC');
			//echo $this->multipledb->db->last_query(); exit;
			return $query->result_array();
			
		}
		
		public function asap_reports($doctorid) 
		{
			
			$query = $this->multipledb->db->query('select id, fname,lname,username,mobile,parentname,  s1.skillscore_M as skillscorem, skillscore_V as skillscorev,skillscore_F as skillscoref,skillscore_P as skillscorep,skillscore_L as skillscorel, a3.finalscore as avgbspiset1,COALESCE(a3.playedcount,0) as playcount from users mu

left join 
 (SELECT SUM(score)/5 as finalscore, count(gu_id) as playedcount, gu_id, (SELECT sid from users where id=gu_id) as schoolid from (select (AVG(score)) as score, gu_id, gs_id from (SELECT (AVG(`game_score`)) as score , gs_id , gu_id, lastupdate FROM `game_reports` WHERE gs_id in (59,60,61,62,63) and gu_id in (select id from users) group by gs_id , gu_id, lastupdate) a1 group by gs_id, gu_id ) a2 group by gu_id) a3   on a3.gu_id=mu.id 
 
 left join
(select (AVG(score)) as skillscore_M, gu_id from (SELECT (AVG(`game_score`)) as score , gs_id , gu_id, lastupdate FROM `game_reports` WHERE gs_id =59 and gu_id in (select id from users) group by gs_id , gu_id, lastupdate) a1 group by gs_id, gu_id) s1 on s1.gu_id=mu.id 

left join
(select (AVG(score)) as skillscore_V, gu_id from (SELECT (AVG(`game_score`)) as score , gs_id , gu_id, lastupdate FROM `game_reports` WHERE gs_id =60 and gu_id in (select id from users) group by gs_id , gu_id, lastupdate) a1 group by gs_id, gu_id) s2 on s2.gu_id=mu.id 

left join
(select (AVG(score)) as skillscore_F, gu_id from (SELECT (AVG(`game_score`)) as score , gs_id , gu_id, lastupdate FROM `game_reports` WHERE gs_id =61 and gu_id in (select id from users) group by gs_id , gu_id, lastupdate) a1 group by gs_id, gu_id) s3 on s3.gu_id=mu.id 

left join
(select (AVG(score)) as skillscore_P, gu_id from (SELECT (AVG(`game_score`)) as score , gs_id , gu_id, lastupdate FROM `game_reports` WHERE gs_id =62 and gu_id in (select id from users) group by gs_id , gu_id, lastupdate) a1 group by gs_id, gu_id) s4 on s4.gu_id=mu.id 

left join
(select (AVG(score)) as skillscore_L, gu_id from (SELECT (AVG(`game_score`)) as score , gs_id , gu_id, lastupdate FROM `game_reports` WHERE gs_id =63 and gu_id in (select id from users) group by gs_id , gu_id, lastupdate) a1 group by gs_id, gu_id) s5 on s5.gu_id=mu.id 
 
 

 where doctorid="'.$doctorid.'" ');
			//echo $this->multipledb->db->last_query(); exit;
			return $query->result_array();
			
		}
		
		public function clp_reports($doctorid)		 
		{
			$query = $this->db->query('select id, fname,lname,username,mobile,parentname, (select type from patient_type_master where id=mu.patient_type) as patienttype from users mu 
			where doctorid="'.$doctorid.'" '); 
			//echo $this->db->last_query(); exit;
			return $query->result_array();
		}
		
		 public function getbspicomparison($userid)		 
		{
			$query = $this->multipledb->db->query('select id, fname, a3.finalscore as avgbspiset1 from users mu

left join 
 (SELECT SUM(score)/5 as finalscore, gu_id, (SELECT sid from users where id=gu_id) as schoolid from (select (AVG(score)) as score, gu_id, gs_id from (SELECT (AVG(`game_score`)) as score , gs_id , gu_id, lastupdate FROM `game_reports` WHERE gs_id in (59,60,61,62,63) and gu_id =  "'.$userid.'" group by gs_id , gu_id, lastupdate) a1 group by gs_id, gu_id ) a2 group by gu_id) a3   on a3.gu_id=mu.id 
 where id = "'.$userid.'" ORDER BY avgbspiset1 DESC');
 
			//echo $this->multipledb->db->last_query(); exit;
			return $query->result_array();
		}
		
		public function clpbspi($userid)		 
		{
			$query = $this->db->query('select id, fname, a3.finalscore as avgbspiset1 from users mu

left join 
 (SELECT SUM(score)/5 as finalscore, gu_id, (SELECT sid from users where id=gu_id) as schoolid from (select (AVG(score)) as score, gu_id, gs_id from (SELECT (AVG(`game_score`)) as score , gs_id , gu_id, lastupdate FROM `game_reports` WHERE gs_id in (59,60,61,62,63) and gu_id =  "'.$userid.'" group by gs_id , gu_id, lastupdate) a1 group by gs_id, gu_id ) a2 group by gu_id) a3   on a3.gu_id=mu.id 
 where id = "'.$userid.'" ORDER BY avgbspiset1 DESC');
 
			//echo $this->multipledb->db->last_query(); exit;
			return $query->result_array();
		}
		
		
		public function getcounters($userid)		 
		{
			$query = $this->db->query("SELECT ROUND((SUM(gtime)/60),0) as gtime_school_count , SUM(answer) as answer_school_count, SUM(attempt_question) as attempted_question_count FROM game_reports gr 
			join users u on gr.gu_id=u.id
			WHERE gtime IS NOT NULL AND answer IS NOT NULL and u.id='".$userid."'  and 
			lastupdate between (select startdate from users where id='".$userid."') and (select enddate from users where id='".$userid."')");
 
			//echo $this->db->last_query(); exit;
			return $query->result_array();
		}
		
		public function getcrowny($userid)		 
		{
			$query = $this->db->query("select points from vi_sumofcrownypoints where U_ID='".$userid."' ");
 
			//echo $this->db->last_query(); exit;
			return $query->result_array();
		}
		
		public function getattemptsession($userid)		 
		{
			$query = $this->db->query("select gu_id,count(Completed) as attempt from (select gu_id,gs_id,count(gs_id) Completed from (SELECT count(gr.id) as PalyCount,DATE_FORMAT(`lastupdate`,'%m') as monthlist ,lastupdate,gs_id,gu_id from game_reports gr join users u on u.id = gr.gu_id join user_academic_mapping um on u.id=um.id where gu_id='".$userid."' and date(lastupdate) between (select startdate from users where id='".$userid."') and (select enddate from users where id='".$userid."') group by date(lastupdate),DATE_FORMAT(`lastupdate`,'%m'),gu_id,gs_id order by date(lastupdate))a2 group by gu_id,lastupdate)a2 ");
 
		//	echo $this->db->last_query(); exit;
			return $query->result_array();
		}
		
		public function getcompsession($userid)		 
		{
			$query = $this->db->query("select gu_id,count(Completed) as comp from (select gu_id,gs_id,count(gs_id) Completed from (SELECT count(gr.id) as PalyCount,DATE_FORMAT(`lastupdate`,'%m') as monthlist ,lastupdate,gs_id,gu_id from game_reports gr join users u on u.id = gr.gu_id join user_academic_mapping um on u.id=um.id where gu_id='".$userid."' and date(lastupdate) between (select startdate from users where id='".$userid."') and (select enddate from users where id='".$userid."') group by date(lastupdate),DATE_FORMAT(`lastupdate`,'%m'),gu_id,gs_id order by date(lastupdate))a2 group by gu_id,lastupdate)a2 where Completed>=5");
 
			//echo $this->db->last_query(); exit;
			return $query->result_array();
		}
		
		public function get_clp_skillwise_avg($userid)		 
		{
			$query = $this->db->query("select id, fname, s1.skillscore_M as skillscorem, skillscore_V as skillscorev,skillscore_F as skillscoref,skillscore_P as skillscorep,skillscore_L as skillscorel, a3.finalscore as avgbspiset1 from users mu 
left join (SELECT SUM(score)/5 as finalscore, gu_id, (SELECT sid from users where id=gu_id) as schoolid from (select (AVG(score)) as score, gu_id, gs_id from (SELECT (AVG(`game_score`)) as score , gs_id , gu_id, lastupdate FROM `game_reports` WHERE gs_id in (59,60,61,62,63) and gu_id in (select id from users) group by gs_id , gu_id, lastupdate) a1 group by gs_id, gu_id ) a2 group by gu_id) a3 on a3.gu_id=mu.id 
left join (select (AVG(score)) as skillscore_M, gu_id from (SELECT (AVG(`game_score`)) as score , gs_id , gu_id, lastupdate FROM `game_reports` WHERE gs_id =59 and gu_id in (select id from users) group by gs_id , gu_id, lastupdate) a1 group by gs_id, gu_id) s1 on s1.gu_id=mu.id 
left join (select (AVG(score)) as skillscore_V, gu_id from (SELECT (AVG(`game_score`)) as score , gs_id , gu_id, lastupdate FROM `game_reports` WHERE gs_id =60 and gu_id in (select id from users) group by gs_id , gu_id, lastupdate) a1 group by gs_id, gu_id) s2 on s2.gu_id=mu.id 
left join (select (AVG(score)) as skillscore_F, gu_id from (SELECT (AVG(`game_score`)) as score , gs_id , gu_id, lastupdate FROM `game_reports` WHERE gs_id =61 and gu_id in (select id from users) group by gs_id , gu_id, lastupdate) a1 group by gs_id, gu_id) s3 on s3.gu_id=mu.id 
left join (select (AVG(score)) as skillscore_P, gu_id from (SELECT (AVG(`game_score`)) as score , gs_id , gu_id, lastupdate FROM `game_reports` WHERE gs_id =62 and gu_id in (select id from users) group by gs_id , gu_id, lastupdate) a1 group by gs_id, gu_id) s4 on s4.gu_id=mu.id 
left join (select (AVG(score)) as skillscore_L, gu_id from (SELECT (AVG(`game_score`)) as score , gs_id , gu_id, lastupdate FROM `game_reports` WHERE gs_id =63 and gu_id in (select id from users) group by gs_id , gu_id, lastupdate) a1 group by gs_id, gu_id) s5 on s5.gu_id=mu.id 

 where id='".$userid."' ORDER BY avgbspiset1 DESC");
 
			//echo $this->db->last_query(); exit;
			return $query->result_array();
		}
		
		
	
		public function getpatienttype()		 
		{
			$query = $this->db->query("SELECT id,type from  patient_type_master where status=1");
			//echo $this->db->last_query(); exit;
			return $query->result_array();
		}
		
		public function updatepatienttype($userid,$typeid)		 
		{
			$query = $this->db->query("UPDATE users SET patient_type='".$typeid."' where id='".$userid."' ");
			//echo $this->db->last_query(); exit;
			//return $query->result_array();
		}
		
		public function getacademicmonths($startdate,$enddate)
		 { //echo ;exit;
			 
		$query = $this->db->query("select DATE_FORMAT(m1, '%m') as monthNumber,DATE_FORMAT(m1, '%Y') as yearNumber,DATE_FORMAT(m1, '%b') as monthName from (select ('".$startdate."' - INTERVAL DAYOFMONTH('".$startdate."')-1 DAY) +INTERVAL m MONTH as m1 from (select @rownum:=@rownum+1 as m from(select 1 union select 2 union select 3 union select 4) t1,(select 1 union select 2 union select 3 union select 4) t2,(select 1 union select 2 union select 3 union select 4) t3,(select 1 union select 2 union select 3 union select 4) t4,(select @rownum:=-1) t0) d1) d2 where m1<='".$enddate."' order by m1");
		//echo $this->db->last_query(); exit;
			return $query->result_array();
		 }
		 
public function getUserEfficiencyGraph($userid,$startdate,$enddate)
{
	$query = $this->db->query("
	select round((sum(score)/5),2) as score,playeddate as rtime,monthNumber,yearNumber from (select avg(score) as score,sum(playeddate) as playeddate,DATE_FORMAT(lastupdate, '%m') as monthNumber,DATE_FORMAT(lastupdate, '%Y') as yearNumber from ( SELECT (AVG(`game_score`)) as score,count(distinct lastupdate) as playeddate,gs_id,lastupdate,gu_id FROM `game_reports` WHERE gs_id in (59,60,61,62,63) and gu_id='".$userid."' and (lastupdate between '".$startdate."' and '".$enddate."') group by gs_id,lastupdate) a1 group by gs_id,month(lastupdate))a2 group by monthNumber");
	//echo $this->db->last_query(); exit;
	return $query->result_array();
}
	
		   
		public function getScannedCoupon($doctorid)
	{  
		$query = $this->db->query("SELECT qrcode,date(qr_scanned_date_time) as scandate,status as ldata,usedstatus,programid,(select program_name from program_master where id=c.programid ) as programname,gradeid, (select gradename from program_grade_master where 	gradeid=c.gradeid and programid=c.programid ) as gradename,paymentmode FROM couponmaster c WHERE doctorid=".$doctorid." ORDER BY qr_scanned_date_time DESC");
			return $query->result_array();
	}
	public function checkdoctormailidexist($emailid)
	{
				 
		$query = $this->db->query('select id,count(email) as emailcount,doctorname,lastname,email,username,mobilenumber from doctormaster where email ="'.$emailid.'" and status=1');		
		//echo $this->db->last_query(); exit;
		return $query->result_array();
	}
	public function resetpwdlog($userid,$randid)
	{	
		$qry=$this->db->query("insert into doctor_password_history(doctorid,randid,requestdatetime,status)values('".$userid."','".$randid."',NOW(),0)");
	}
	function CheckValidActivationlink($userid,$randid)
	{
		$query=$this->db->query("select doctorid as userid,randid,requestdatetime from doctor_password_history where status=0 and md5(doctorid)='".$userid."' and md5(randid)='".$randid."'");
		//echo $this->db->last_query(); exit;
		return $query->result_array();
	}
	public function getResetpwdDoctorDetails($userid)
	{	
		$query = $this->db->query('select id,doctorname,lastname,email,username,mobilenumber from doctormaster where id="'.$userid.'" and status=1');
		//echo $this->db->last_query(); exit;
		return $query->result_array();
	}
	function UpdateNewPwd($pwd,$userid,$salt1,$salt2,$orgpwd)
	{
		$qry=$this->db->query("update doctormaster set password='".$pwd."',orgpwd='".$orgpwd."' where md5(id)='".$userid."'");
	}
	function UpdateNewPwd_log($userid,$randid,$orgpwd,$ip)
	{
		$qry=$this->db->query("update doctor_password_history set processdatetime=now(),status=1,update_password='".$orgpwd."',ip='".$ip."' where md5(doctorid)='".$userid."' and md5(randid)='".$randid."'");
	}
	
	public function insert_login_log($doctorid,$sessionid,$ip,$country,$region,$city,$isp,$browser,$status)
		{
			$query = $this->db->query('INSERT INTO doctor_login_log(	doctorid,sessionid,created_date,lastupdate,logout_date,ip,country,region,city,browser,isp,status)VALUES("'.$doctorid.'","'.$sessionid.'",now(),now(),now(), "'.$ip.'","'.$country.'","'.$region.'","'.$city.'","'.$browser.'","'.$isp.'","'.$status.'")');
			//echo $this->db->last_query(); exit;
			return $query;
			
		}
		
		public function update_login_log($doctorid,$sessionid)
		{
			$query = $this->db->query('update doctor_login_log set lastupdate=now() where doctorid="'.$doctorid.'" and sessionid="'.$sessionid.'"');
			return $query;
			
		}
		
		public function update_logout_log($doctorid,$sessionid)
		{
			$query = $this->db->query('update doctor_login_log set lastupdate=now(),logout_date=now() where doctorid="'.$doctorid.'" and sessionid="'.$sessionid.'"');
			return $query;
			
		}
		
		
		public function getWeeklyAttemptSession($userid)		 
		{
			$query = $this->db->query("select count(weekval) as AttemptedSession from (select weekval from gamedata where gu_id='".$userid."' group by weekval) as a1  ");
			return $query->result_array();
		}
		public function getWeeklyCompSession($userid)		 
		{
			$query = $this->db->query("select count(weekval) as CompletedSession from (select count(gs_id) as AttemptedSkill,weekval from (select gs_id,weekval from gamedata where gu_id='".$userid."' group by weekval,gs_id) as a1 group by weekval) as a2 where AttemptedSkill>=5 ");
			return $query->result_array();
		}
		public function getWeeklyCrowny($userid)		 
		{
			$query = $this->db->query("SELECT sum(Points) as points FROM `user_sparkies_history` WHERE U_ID='".$userid."' ");
			return $query->result_array();
		}
		
		public function getWeeklyAsapAttemptSession($userid)		 
		{
			$query = $this->db->query("select count(week_val) as asapAttemptedSession  from asap_gamescore where gu_id='".$userid."' group by week_val");
			return $query->result_array();
		}
		public function getWeeklyAsapCompSession($userid)		 
		{
			$query = $this->db->query("select count(week_val) as asapCompletedSession from asap_gamescore where gu_id='".$userid."' and (ME!='' and VP!='' and FA!='' and PS!='' and LI!='') group by week_val ");
			return $query->result_array();
		}
		public function getNewUserCounters($userid)		 
		{
			$query = $this->db->query("SELECT (coalesce(ROUND((SUM(gtime)/60),0),0)+(select coalesce(ROUND((SUM(gtime)/60),0),0) from asap_gamedata where gu_id=gr.gu_id)) as gtime_school_count , (coalesce(SUM(answer),0)+(select coalesce(SUM(answer),0) from asap_gamedata where gu_id=gr.gu_id)) as answer_school_count, (coalesce(SUM(attempt_question),0)+(select coalesce(SUM(attempt_question),0) from asap_gamedata where gu_id=gr.gu_id)) as attempted_question_count FROM game_reports gr 
			join users u on gr.gu_id=u.id
			WHERE gtime IS NOT NULL AND answer IS NOT NULL and u.id='".$userid."'  and 
			lastupdate between (select startdate from users where id='".$userid."') and (select enddate from users where id='".$userid."')");
 
			//echo $this->db->last_query(); exit;
			return $query->result_array();
		}
		
		
		
			/*------------get the program name -----------------*/
		 public function programname()
		{
			$query = $this->db->query("SELECT id,program_name from program_master  WHERE  status=1");
			//echo $this->db->last_query(); exit;
			return $query->result_array();
		}
		
		/*------------get the gradename based on the program selection -----------------*/
		public function gradeinfo($programname)
		{
			$query = $this->db->query("SELECT gradeid,gradename,planid from program_grade_master  WHERE  programid='".$programname."' ");
		//	echo $this->db->last_query(); exit;
			return $query->result_array();
		} 
		
		/*  public function getPlaninfo($gradename)
		{		
			$query = $this->db->query("SELECT planid from program_grade_master where gradeid='".$gradename."' and programid='".$programname."'");
			//echo $this->multipledb->db->last_query(); exit;
			return $query->result_array();
		}  */
	
}
