<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Blessedangelreport_model extends CI_Model {

        
     public function __construct()
     {
         // Call the CI_Model constructor
          parent::__construct();
		  $this->load->database();
	      $this->load->library('Multipledb');
     }

	public function checklogin($username,$password)
    {
					 
		// $query = $this->multipledb->ba->query("SELECT *  FROM academic_center_master WHERE (username=".$this->multipledb->ba->escape($username)." AND password=".$this->multipledb->ba->escape($password).") and status=1");	
			
		$query = $this->multipledb->ba->query("SELECT `id`, `email`, `password`, `fname`, `lname`, `emailid`, `level`,  `status`, `createdby`, `creation_date` FROM `admin` WHERE (email=".$this->multipledb->ba->escape($username)." AND password=".$this->multipledb->ba->escape($password).") and status=1");		
		//echo $this->multipledb->ba->last_query(); exit;
		return $query->result_array();
    }	
		
	public function usercount()
    {
		$query = $this->multipledb->ba->query("SELECT count(*) as total FROM users u join academic_center_master a on a.id=u.academic_center_id WHERE u.status=1 and u.academic_center_id!=0 and u.isdemo=0 and a.isdemo=0");
		//echo $this->multipledb->ba->last_query(); exit;
		return $query->result_array();
    } 
		
	public function sc_usercount()
    {
		$query = $this->multipledb->saasap->query("SELECT count(*) as total FROM users  WHERE status=1 and academic_center_id!=0 and isnewuser='Y'");
		//echo $this->multipledb->ba->last_query(); exit;
		return $query->result_array();
    } 
		
	public function issuedlicense()
    {
		$query = $this->multipledb->ba->query("select sum(noofcoupon) as issuedlicense from edsix_issued_coupon where status='Y' and product_id=1");		
		//echo $this->multipledb->ba->last_query(); exit;
		return $query->result_array();
    }
		
	public function distributelicense($proid)
    {
		$query = $this->multipledb->ba->query("select sum(noofcoupon) as issuedlicense from edsix_issued_coupon where status='Y' and product_id=".$this->multipledb->ba->escape($proid)." ");		
		//echo $this->multipledb->ba->last_query(); exit;
		return $query->result_array();
    }

	public function sc_issuedlicense()
    {
		$query = $this->multipledb->ba->query("select sum(noofcoupon) as issuedlicense from edsix_issued_coupon where status='Y' and product_id=2");		
		//echo $this->multipledb->ba->last_query(); exit;
		return $query->result_array();
    }
		
	public function getacademy()
    {
		$query = $this->multipledb->ba->query("SELECT id,username,email from academic_center_master where status=1 and isdemo=0");		
		//echo $this->multipledb->ba->last_query(); exit;
		return $query->result_array();
    } 
		
	public function insertlicensecount($centerid,$adminid,$nooflicense,$issuedate,$proid)		 
	{
		$query = $this->multipledb->ba->query("INSERT INTO license_count (centerid,adminid, licensecount, givendatetime,status,created_on,product_id)VALUES(".$this->multipledb->ba->escape($centerid).",".$this->multipledb->ba->escape($adminid).",".$this->multipledb->ba->escape($nooflicense).",".$this->multipledb->ba->escape($issuedate).",1,NOW(),".$this->multipledb->ba->escape($proid).")");
 
		//echo $this->multipledb->ba->last_query(); exit;
		//return $query->result_array();
	}
		
	public function gettotallicensecount($proid)
	{
		$query = $this->multipledb->ba->query('SELECT sum(noofcoupon) as value from client_approved_license where status="Y" and product_id='.$this->multipledb->ba->escape($proid).' ');
		return $query->result_array();
	}
		
	public function totallicenseissued()
    {
		
		$query = $this->multipledb->ba->query("SELECT SUM(licensecount) as totalcount FROM license_count  WHERE status=1 and centerid  IN (select id from academic_center_master where status=1 and isdemo=0) and product_id=1");		
		//echo $this->multipledb->ba->last_query(); exit;
		return $query->result_array();
    }
		
	public function totallicensedistributed($proid)
    { 
		$query = $this->multipledb->ba->query("SELECT SUM(licensecount) as totalcount FROM license_count  WHERE status=1 and centerid  IN (select id from academic_center_master where status=1 and isdemo=0 and product_id=".$this->multipledb->ba->escape($proid).")");		
		//echo $this->multipledb->ba->last_query(); exit;
		return $query->result_array();
    }

	public function sc_totallicenseissued()
    { 
		$query = $this->multipledb->ba->query("SELECT SUM(licensecount) as totalcount FROM license_count  WHERE status=1 and centerid  IN (select id from academic_center_master where status=1 and isdemo=0) and product_id=2");		
		//echo $this->multipledb->ba->last_query(); exit;
		return $query->result_array();
    }
		
	public function getlicensehistory($proid)		 
	{
		//$query = $this->multipledb->ba->query("SELECT *,(select regionname from regionmaster where id=regionid and status=1) as rname FROM region_coupon_count");
			
		$query = $this->multipledb->ba->query("SELECT licensecount,givendatetime FROM license_count rc JOIN academic_center_master r ON rc.centerid=r.id WHERE  r.isdemo=0 and rc.product_id=".$this->multipledb->ba->escape($proid)." ORDER BY givendatetime DESC");
		//echo $this->multipledb->ba->last_query(); exit;
		return $query->result_array();
	}
		
		public function totalrec_userlist()
        {
			$query = $this->db->query("SELECT count(*) as totalrecord FROM users u where doctorid='".$this->session->doctorid."'");		
			//echo $this->db->last_query(); exit;
			return $query->result_array();
		}
		
	//--------------brobliss_clpgd----------------------------//
	 

	public function userslist($start,$limit)
    {
		$qry=' ';
		if($limit=='')
		{
			$qry=" ";
		}
		else if($start=='' && $limit!=''){
			$qry=" limit ".$limit;
		}
		else if($start!='' && $limit!=''){
			$qry=" limit ".$start.','.$limit;
		}
					 
		$query = $this->db->query("SELECT id,fname,username,(select program_name from program_master where id=u.programid) as programname,(select gradename from program_grade_master where gradeid=u.grade_id and programid=u.programid) as gradename,email,mobile,address,dob,avatarimage,(select state_name from state where id=u.stateid) as statename,(select type from patient_type_master where id=u.patient_type) as patienttype,city,parentname,creation_date,status,isnew  FROM users u where doctorid='".$this->session->doctorid."' order by creation_date desc ".$qry."");		
		//echo $this->db->last_query(); exit;
		return $query->result_array();
     } 
	
		//--------------brobliss_clpgd----------------------------//
		 
		
	public function getusername($userid)
    { 			 
		$query = $this->multipledb->ba->query("SELECT id,username,gp_id,grade_id,startdate,enddate  FROM users where id=".$this->multipledb->ba->escape($userid)."");		
		//echo $this->multipledb->ba->last_query(); exit;
		return $query->result_array();
    }
		
		//-----------------brobliss_clpgd---------------//
		
	public function getasapinfo($userid)
    {
					 
		$query = $this->multipledb->ba->query("SELECT id,fname,lname,gender,email,mobile,dob,address,avatarimage,startdate,enddate,father,creation_date,(select classname from class where id=u.grade_id) as grade FROM users u where id=".$this->multipledb->ba->escape($userid)." and u.status=1");		
	    //echo $this->multipledb->ba->last_query(); exit;
		return $query->result_array();
    }
		//-----------------brobliss_clpgd---------------//
		
	public function getuserid($uname)
    { 		 
		$query = $this->multipledb->ba->query("SELECT id  FROM users where username=".$this->multipledb->ba->escape($uname)." and status=1");		
		//echo $this->multipledb->ba->last_query(); exit;
		return $query->result_array();
    } 
	public function userscount($centerid)
    {
		$query = $this->multipledb->ba->query("SELECT count(*) as total FROM users  WHERE  academic_center_id=".$this->multipledb->ba->escape($centerid)."");		
		//	echo $this->multipledb->ba->last_query(); exit;
		return $query->result_array();
     }
		
	public function datewiseusers($centerid)
    { 	
		$query = $this->multipledb->ba->query("SELECT count(*) as users, DATE_FORMAT(creation_date, '%d-%m-%Y') as creation_date FROM users WHERE academic_center_id=".$this->multipledb->ba->escape($centerid)." and u.status=1 and isdemo=0 group by creation_date");		
		//	echo $this->multipledb->ba->last_query(); exit;
		return $query->result_array();
	}
		
	public function gradewiseusers($centerid)
    { 	
		$query = $this->multipledb->ba->query("SELECT count(*) as usercount, REPLACE (classname, 'Grade', '') as grade,sorting_order  FROM users u JOIN class c ON u.grade_id=c.id  WHERE  academic_center_id=".$this->multipledb->ba->escape($centerid)." and u.status=1 group by `grade_id` order by sorting_order");
		//	echo $this->multipledb->ba->last_query(); exit;
		return $query->result_array();
	}
		
	public function userdetails_sc($academicid,$studentname,$gradeid)
    {
		$where = ' '; 		 
			
		if($academicid!='')
		{
			$where.= " and academic_center_id = ".$this->multipledb->ba->escape($academicid).""; 
		}
		if($studentname!='')
		{
			$where.= " and fname LIKE '%".$studentname."%'"; 
		}
		if($gradeid!='')
		{
			$where.= " and grade_id = ".$this->multipledb->ba->escape($gradeid).""; 
		} 
			
		$query = $this->multipledb->saasap->query("SELECT u.id,u.fname,username,u.creation_date,startdate, REPLACE (classname, 'Grade', '') as grade,sorting_order,(select finalscore as bspi from vii_avguserbspiscore where gu_id=u.id) as bspi, (select count(DISTINCT lastupdate) from game_reports where gu_id=u.id and lastupdate between u.startdate and u.enddate) as totaldays,  ROUND(s1.skillscore_M, 2) as skillscorem, ROUND(skillscore_V, 2) as skillscorev,ROUND(skillscore_F, 2) as skillscoref,ROUND(skillscore_P, 2) as skillscorep,ROUND(skillscore_L, 2) as skillscorel, ROUND(a3.finalscore, 2) as avgbspiset1  FROM users u JOIN class c ON u.grade_id=c.id  

		left join (SELECT SUM(score)/5 as finalscore,count(gu_id) as playedcount, gu_id, (SELECT sid from users where id=gu_id) as schoolid from (select (AVG(score)) as score, gu_id, gs_id from (SELECT (AVG(`game_score`)) as score , gs_id , gu_id, lastupdate FROM `game_reports` WHERE gs_id in (59,60,61,62,63) and gu_id in (select id from users) group by gs_id , gu_id, lastupdate) a1 group by gs_id, gu_id ) a2 group by gu_id) a3 on a3.gu_id=u.id 
		left join (select (AVG(score)) as skillscore_M, gu_id from (SELECT (AVG(`game_score`)) as score , gs_id , gu_id, lastupdate FROM `game_reports` WHERE gs_id =59 and gu_id in (select id from users) group by gs_id , gu_id, lastupdate) a1 group by gs_id, gu_id) s1 on s1.gu_id=u.id 
		left join (select (AVG(score)) as skillscore_V, gu_id from (SELECT (AVG(`game_score`)) as score , gs_id , gu_id, lastupdate FROM `game_reports` WHERE gs_id =60 and gu_id in (select id from users) group by gs_id , gu_id, lastupdate) a1 group by gs_id, gu_id) s2 on s2.gu_id=u.id 
		left join (select (AVG(score)) as skillscore_F, gu_id from (SELECT (AVG(`game_score`)) as score , gs_id , gu_id, lastupdate FROM `game_reports` WHERE gs_id =61 and gu_id in (select id from users) group by gs_id , gu_id, lastupdate) a1 group by gs_id, gu_id) s3 on s3.gu_id=u.id 
		left join (select (AVG(score)) as skillscore_P, gu_id from (SELECT (AVG(`game_score`)) as score , gs_id , gu_id, lastupdate FROM `game_reports` WHERE gs_id =62 and gu_id in (select id from users) group by gs_id , gu_id, lastupdate) a1 group by gs_id, gu_id) s4 on s4.gu_id=u.id 
		left join (select (AVG(score)) as skillscore_L, gu_id from (SELECT (AVG(`game_score`)) as score , gs_id , gu_id, lastupdate FROM `game_reports` WHERE gs_id =63 and gu_id in (select id from users) group by gs_id , gu_id, lastupdate) a1 group by gs_id, gu_id) s5 on s5.gu_id=u.id 


		WHERE  u.status=1 and visible=1 and isdemo=0 and academic_center_id!=0 and academic_center_id!=19 and 1=1 ".$this->multipledb->ba->escape($where)." order by creation_date DESC");  
			
		//	echo $this->multipledb->ba->last_query(); exit;
			return $query->result_array();
	} 
		
	public function getcrowny_sc($userid)		 
	{
		$query = $this->multipledb->ba->query("select points from vi_sumofcrownypoints where U_ID=".$this->multipledb->ba->escape($userid)." "); 
		//echo $this->multipledb->ba->last_query(); exit;
		return $query->result_array();
	}
		
	public function getbspi_sc($userid)		 
	{
		$query = $this->multipledb->ba->query("select finalscore as bspi from vii_avguserbspiscore where gu_id=".$this->multipledb->ba->escape($userid)." "); 
		//echo $this->multipledb->ba->last_query(); exit;
		return $query->result_array();
	}
		
	public function getuserinfo_sc($userid)
    {					 
		$query = $this->multipledb->saasap->query("SELECT id,fname,username,gender,email,mobile, creation_date,(select classname from class where id=u.grade_id) as grade FROM users u where id=".$this->multipledb->ba->escape($userid)." and status=1");		
		//echo $this->multipledb->ba->last_query(); exit;
		return $query->result_array();
    }
		
	public function getcounters_sc($userid)		 
	{
		$query = $this->multipledb->saasap->query("SELECT ROUND((SUM(gtime)/60),0) as MinutesTrained , SUM(answer) as PuzzlesSolved, SUM(attempt_question) as PuzzlesAttempted,count(g_id) as UniqueGames  FROM game_reports gr join users u on gr.gu_id=u.id	WHERE gtime IS NOT NULL AND answer IS NOT NULL and u.id=".$this->multipledb->ba->escape($userid)." and u.status=1 "); 
		//echo $this->multipledb->ba->last_query(); exit;
		return $query->result_array();
	}
		
	public function IsCLPEnable_sc($userid)
	{
		$query  = $this->multipledb->saasap->query('select count(id) as playedstatus from game_reports where gu_id='.$this->multipledb->ba->escape($userid).' and gs_id in(59,60,61,62,63)');
		return $query->result_array();
	}
	
	public function getplayeddates($userid)
	{
		$query = $this->multipledb->saasap->query("Select lastupdate as `date`,1 as badge from gamedata where gu_id=".$this->multipledb->ba->escape($userid)." group by lastupdate");
		//	echo $this->multipledb->ba->last_query(); exit;
		return $query->result_array();
	}
	
	public function getTrainingCalendarData($userid,$curdate)
	{
		$query = $this->multipledb->saasap->query("SELECT ROUND((SUM(gtime)/60),0) as 	MinutesTrained  , SUM(answer) as PuzzlesSolved, SUM(attempt_question) as PuzzlesAttempted,(select SUM(Points) from user_sparkies_history where U_ID=".$this->multipledb->ba->escape($userid)." and date(Datetime)=".$this->multipledb->ba->escape($curdate).") as Crownies FROM game_reports gr join users u on gr.gu_id=u.id	WHERE gtime IS NOT NULL AND answer IS NOT NULL and u.id=".$this->multipledb->ba->escape($userid)." and u.status=1 and lastupdate between (select startdate from users where id=".$this->multipledb->ba->escape($userid).") and (select enddate from users where id=".$this->multipledb->ba->escape($userid).") and lastupdate=".$this->multipledb->ba->escape($curdate)." ");
		//echo $this->multipledb->ba->last_query(); exit;
		return $query->result_array();
	}
	
	public function getonedaybspi($userid,$curdate)
	{
		$query = $this->multipledb->saasap->query("SELECT SUM(avgskillscore)/5 as BSPI from (select AVG(game_score) as avgskillscore, gs_id FROM game_reports  where gu_id=".$this->multipledb->ba->escape($userid)." and lastupdate=".$this->multipledb->ba->escape($curdate)." group by gs_id) a1");
		//echo $this->multipledb->ba->last_query(); exit;
		return $query->result_array();
	}
	
	public function datewisebspi_sc($userid,$startdate,$enddate)
	{
		$query = $this->multipledb->saasap->query("SELECT ROUND(SUM(avgskillscore)/5, 2) as BSPI, DATE_FORMAT(lastupdate, '%d-%m-%Y') as Playeddate from (select AVG(game_score) as avgskillscore, lastupdate, gs_id FROM game_reports  where gu_id=".$this->multipledb->ba->escape($userid)." and lastupdate BETWEEN ".$this->multipledb->ba->escape($startdate)." and ".$this->multipledb->ba->escape($enddate)." group by gs_id, lastupdate) a1 group by lastupdate");
		//echo $this->multipledb->ba->last_query(); exit;
		return $query->result_array();
	}
	
	public function overallskillscore_sc($userid,$startdate,$enddate)
	{
		$query = $this->multipledb->saasap->query("select AVG(gamescore) as skillscore,gs_id from (SELECT (AVG(game_score)) as gamescore ,gs_id , lastupdate  FROM game_reports WHERE gs_id in (59,60,61,62,63) and gu_id=".$this->multipledb->ba->escape($userid)." and  lastupdate between ".$this->multipledb->ba->escape($startdate)." and ".$this->multipledb->ba->escape($enddate)." group by gs_id,lastupdate) a1 group by gs_id");
		//echo $this->multipledb->saasap->last_query(); exit;
		return $query->result_array();
	}
		 
	public function getonedayskillscore($userid,$curdate)
	{
		$query = $this->multipledb->saasap->query("SELECT id, s1.mem as memory,s2.vp as visual, s3.fa as focus, s4.ps as problem,s5.lin as ling from users mu left join 

		(select AVG(game_score) as mem, gu_id FROM game_reports  where gu_id=".$this->multipledb->ba->escape($userid)." and lastupdate=".$this->multipledb->ba->escape($curdate)." and gs_id=59)s1 ON s1.gu_id=mu.id

		left join (select AVG(game_score) as vp, gu_id FROM game_reports  where gu_id=".$this->multipledb->ba->escape($userid)." and lastupdate=".$this->multipledb->ba->escape($curdate)." and gs_id=60)s2 ON s2.gu_id=mu.id

		left join (select AVG(game_score) as fa, gu_id FROM game_reports  where gu_id=".$this->multipledb->ba->escape($userid)." and lastupdate=".$this->multipledb->ba->escape($curdate)." and gs_id=61)s3 ON s3.gu_id=mu.id

		left join (select AVG(game_score) as ps, gu_id FROM game_reports  where gu_id=".$this->multipledb->ba->escape($userid)." and lastupdate=".$this->multipledb->ba->escape($curdate)." and gs_id=62)s4 ON s4.gu_id=mu.id

		left join (select AVG(game_score) as lin, gu_id FROM game_reports  where gu_id=".$this->multipledb->ba->escape($userid)." and lastupdate=".$this->multipledb->ba->escape($curdate)." and gs_id=63)s5 ON s5.gu_id=mu.id where mu.id=".$this->multipledb->ba->escape($userid)." ");
		//echo $this->multipledb->ba->last_query(); exit;
		return $query->result_array();
	}
		
	public function scanstatus($doctorid)
    { 	 
		$query = $this->multipledb->ba->query("SELECT COUNT(qrcode) as scancount from couponmaster where doctorid=".$this->multipledb->ba->escape($doctorid)." and status=1");		
		//echo $this->multipledb->ba->last_query(); exit;
		return $query->result_array();
     }
		
	
	public function couponcodecount($doctorid)
    {
		$query = $this->multipledb->ba->query("SELECT count(*) as totalcoupon FROM couponmaster  WHERE doctorid=".$this->multipledb->ba->escape($doctorid)." and usedstatus='N'");		
		//echo $this->multipledb->ba->last_query(); exit;
		return $query->result_array();
    }
		
	public function couponlist($doctorid)
    {
		$query = $this->multipledb->ba->query("SELECT *  FROM couponmaster  WHERE doctorid=".$this->multipledb->ba->escape($doctorid)." ");		
		//echo $this->multipledb->ba->last_query(); exit;
		return $query->result_array();
    }
		

	public function getstate()
    {
		$query = $this->multipledb->ba->query("SELECT id, state_name FROM state  WHERE countryid=113");		
		//echo $this->multipledb->ba->last_query(); exit;
		return $query->result_array();
    }	
		
	public function gethospital()
    {
		$query = $this->multipledb->ba->query("SELECT id, hospitalname FROM hospitalmaster  WHERE status=1");		
		//echo $this->multipledb->ba->last_query(); exit;
		return $query->result_array();
    }	
		
	public function editdoctor($doctorid)
    {
		$query = $this->multipledb->ba->query("SELECT *,(select state_name from state where id=d.state) as statename,(select hospitalname from hospitalmaster where id=d.hospitalid) as hospitalname1 FROM doctormaster d WHERE d.id=".$this->multipledb->ba->escape($doctorid)."");		
		//echo $this->multipledb->ba->last_query(); exit;
		return $query->result_array();
    }	
		
	public function updatedoctor($doctorname,$lname,$gender,$dob,$emailid,$secondaryemailid,$mobile,$secondarymobile,$state,$city,$address,$doctorid,$imgpath,$hospitalname)
    {
		if($imgpath!='')
		{
			$query = $this->multipledb->ba->query("UPDATE `doctormaster` SET `doctorname`=".$this->multipledb->ba->escape($doctorname).",`lastname`=".$this->multipledb->ba->escape($lname).",`gender`=".$this->multipledb->ba->escape($gender).",`dateofbirth`=".$this->multipledb->ba->escape($dob).",`email`=".$this->multipledb->ba->escape($emailid).",`secondaryemail`=".$this->multipledb->ba->escape($secondaryemailid).",`state`=".$this->multipledb->ba->escape($state).",`city`=".$this->multipledb->ba->escape($city).",`mobilenumber`=".$this->multipledb->ba->escape($mobile).",`secondarymobilenumber`=".$this->multipledb->ba->escape($secondarymobile).",`address`=".$this->multipledb->ba->escape($address).",`profileimage`=".$this->multipledb->ba->escape($imgpath).",`modifed_on`=NOW(),hospitalname=".$this->multipledb->ba->escape($hospitalname)." WHERE id=".$this->multipledb->ba->escape($doctorid)."");
		}
		else
		{
			$query = $this->multipledb->ba->query("UPDATE `doctormaster` SET `doctorname`=".$this->multipledb->ba->escape($doctorname).",`lastname`=".$this->multipledb->ba->escape($lname).",`gender`=".$this->multipledb->ba->escape($gender).",`dateofbirth`=".$this->multipledb->ba->escape($dob).",`email`=".$this->multipledb->ba->escape($emailid).",`secondaryemail`=".$this->multipledb->ba->escape($secondaryemailid).",`state`=".$this->multipledb->ba->escape($state).",`city`=".$this->multipledb->ba->escape($city).",`mobilenumber`=".$this->multipledb->ba->escape($mobile).",`secondarymobilenumber`=".$this->multipledb->ba->escape($secondarymobile).",`address`=".$this->multipledb->ba->escape($address).",`modifed_on`=NOW(),hospitalname=".$this->multipledb->ba->escape($hospitalname)." WHERE id=".$this->multipledb->ba->escape($doctorid)."");
			}
		//	echo $this->multipledb->ba->last_query(); exit;
			
      }

	public function getskillwise_avg($uname) 
	{
			
		$query = $this->multipledb->ba->query('select id, fname,s1.skillscore_M as skillscorem, skillscore_V as skillscorev,skillscore_F as skillscoref,skillscore_P as skillscorep,skillscore_L as skillscorel, a3.finalscore as avgbspiset1 from users mu

		left join 
		 (SELECT SUM(score)/5 as finalscore, gu_id, (SELECT sid from users where id=gu_id) as schoolid from (select (AVG(score)) as score, gu_id, gs_id from (SELECT (AVG(`game_score`)) as score , gs_id , gu_id, lastupdate FROM `asap_game_reports` WHERE gs_id in (59,60,61,62,63) and gu_id in (select id from users) group by gs_id , gu_id, lastupdate) a1 group by gs_id, gu_id ) a2 group by gu_id) a3   on a3.gu_id=mu.id 
			 
		 left join
		(select (AVG(score)) as skillscore_M, gu_id from (SELECT (AVG(`game_score`)) as score , gs_id , gu_id, lastupdate FROM `asap_game_reports` WHERE gs_id =59 and portal_type="ASAP1" and gu_id in (select id from users) group by gs_id , gu_id, lastupdate) a1 group by gs_id, gu_id) s1 on s1.gu_id=mu.id 

		 left join
		(select (AVG(score)) as skillscore_V, gu_id from (SELECT (AVG(`game_score`)) as score , gs_id , gu_id, lastupdate FROM `asap_game_reports` WHERE gs_id =60 and portal_type="ASAP1" and gu_id in (select id from users) group by gs_id , gu_id, lastupdate) a1 group by gs_id, gu_id) s2 on s2.gu_id=mu.id 

		left join
		(select (AVG(score)) as skillscore_F, gu_id from (SELECT (AVG(`game_score`)) as score , gs_id , gu_id, lastupdate FROM `asap_game_reports` WHERE gs_id =61 and portal_type="ASAP1" and gu_id in (select id from users) group by gs_id , gu_id, lastupdate) a1 group by gs_id, gu_id) s3 on s3.gu_id=mu.id 

		left join
		(select (AVG(score)) as skillscore_P, gu_id from (SELECT (AVG(`game_score`)) as score , gs_id , gu_id, lastupdate FROM `asap_game_reports` WHERE gs_id =62 and portal_type="ASAP1" and gu_id in (select id from users) group by gs_id , gu_id, lastupdate) a1 group by gs_id, gu_id) s4 on s4.gu_id=mu.id 

		left join
		(select (AVG(score)) as skillscore_L, gu_id from (SELECT (AVG(`game_score`)) as score , gs_id , gu_id, lastupdate FROM `asap_game_reports` WHERE gs_id =63  and portal_type="ASAP1" and gu_id in (select id from users) group by gs_id , gu_id, lastupdate) a1 group by gs_id, gu_id) s5 on s5.gu_id=mu.id  

		 where username='.$this->multipledb->ba->escape($uname).' ORDER BY avgbspiset1 DESC');
		//echo $this->multipledb->ba->last_query(); exit;
		return $query->result_array();
			
	}
	
	public function getskillwise_avg2($uname) 
	{
			
		$query = $this->multipledb->ba->query('select id, fname,s1.skillscore_M as skillscorem, skillscore_V as skillscorev,skillscore_F as skillscoref,skillscore_P as skillscorep,skillscore_L as skillscorel, a3.finalscore as avgbspiset1 from users mu

		left join 
		 (SELECT SUM(score)/5 as finalscore, gu_id, (SELECT sid from users where id=gu_id) as schoolid from (select (AVG(score)) as score, gu_id, gs_id from (SELECT (AVG(`game_score`)) as score , gs_id , gu_id, lastupdate FROM `asap_game_reports` WHERE gs_id in (59,60,61,62,63) and gu_id in (select id from users) group by gs_id , gu_id, lastupdate) a1 group by gs_id, gu_id ) a2 group by gu_id) a3   on a3.gu_id=mu.id 
			 
		 left join
		(select (AVG(score)) as skillscore_M, gu_id from (SELECT (AVG(`game_score`)) as score , gs_id , gu_id, lastupdate FROM `asap_game_reports` WHERE gs_id =59 and portal_type="ASAP2" and gu_id in (select id from users) group by gs_id , gu_id, lastupdate) a1 group by gs_id, gu_id) s1 on s1.gu_id=mu.id 

		 left join
		(select (AVG(score)) as skillscore_V, gu_id from (SELECT (AVG(`game_score`)) as score , gs_id , gu_id, lastupdate FROM `asap_game_reports` WHERE gs_id =60 and portal_type="ASAP2" and gu_id in (select id from users) group by gs_id , gu_id, lastupdate) a1 group by gs_id, gu_id) s2 on s2.gu_id=mu.id 

		left join
		(select (AVG(score)) as skillscore_F, gu_id from (SELECT (AVG(`game_score`)) as score , gs_id , gu_id, lastupdate FROM `asap_game_reports` WHERE gs_id =61 and portal_type="ASAP2" and gu_id in (select id from users) group by gs_id , gu_id, lastupdate) a1 group by gs_id, gu_id) s3 on s3.gu_id=mu.id 

		left join
		(select (AVG(score)) as skillscore_P, gu_id from (SELECT (AVG(`game_score`)) as score , gs_id , gu_id, lastupdate FROM `asap_game_reports` WHERE gs_id =62 and portal_type="ASAP2" and gu_id in (select id from users) group by gs_id , gu_id, lastupdate) a1 group by gs_id, gu_id) s4 on s4.gu_id=mu.id 

		left join
		(select (AVG(score)) as skillscore_L, gu_id from (SELECT (AVG(`game_score`)) as score , gs_id , gu_id, lastupdate FROM `asap_game_reports` WHERE gs_id =63 and portal_type="ASAP2" and gu_id in (select id from users) group by gs_id , gu_id, lastupdate) a1 group by gs_id, gu_id) s5 on s5.gu_id=mu.id  

		 where username='.$this->multipledb->ba->escape($uname).' ORDER BY avgbspiset1 DESC');
		//echo $this->multipledb->ba->last_query(); exit;
		return $query->result_array();
			
	}
		
	public function asap_reports() 
	{ 	
		$query = $this->multipledb->saasap->query('select id, fname,lname,username,mobile,father,mother,  s1.skillscore_M as skillscorem, skillscore_V as skillscorev,skillscore_F as skillscoref,skillscore_P as skillscorep,skillscore_L as skillscorel, a3.finalscore as avgbspiset1,COALESCE(a3.playedcount,0) as playcount from users mu

		left join 
		 (SELECT SUM(score)/5 as finalscore, count(gu_id) as playedcount, gu_id, (SELECT sid from users where id=gu_id) as schoolid from (select (AVG(score)) as score, gu_id, gs_id from (SELECT (AVG(`game_score`)) as score , gs_id , gu_id, lastupdate FROM `game_reports` WHERE gs_id in (59,60,61,62,63) and gu_id in (select id from users) group by gs_id , gu_id, lastupdate) a1 group by gs_id, gu_id ) a2 group by gu_id) a3   on a3.gu_id=mu.id 
			 
		 left join
		(select (AVG(score)) as skillscore_M, gu_id from (SELECT (AVG(`game_score`)) as score , gs_id , gu_id, lastupdate FROM `game_reports` WHERE gs_id =59 and gu_id in (select id from users) group by gs_id , gu_id, lastupdate) a1 group by gs_id, gu_id) s1 on s1.gu_id=mu.id 

		left join
		(select (AVG(score)) as skillscore_V, gu_id from (SELECT (AVG(`game_score`)) as score , gs_id , gu_id, lastupdate FROM `game_reports` WHERE gs_id =60 and gu_id in (select id from users) group by gs_id , gu_id, lastupdate) a1 group by gs_id, gu_id) s2 on s2.gu_id=mu.id 

		left join
		(select (AVG(score)) as skillscore_F, gu_id from (SELECT (AVG(`game_score`)) as score , gs_id , gu_id, lastupdate FROM `game_reports` WHERE gs_id =61 and gu_id in (select id from users) group by gs_id , gu_id, lastupdate) a1 group by gs_id, gu_id) s3 on s3.gu_id=mu.id 

		left join
		(select (AVG(score)) as skillscore_P, gu_id from (SELECT (AVG(`game_score`)) as score , gs_id , gu_id, lastupdate FROM `game_reports` WHERE gs_id =62 and gu_id in (select id from users) group by gs_id , gu_id, lastupdate) a1 group by gs_id, gu_id) s4 on s4.gu_id=mu.id 

		left join
		(select (AVG(score)) as skillscore_L, gu_id from (SELECT (AVG(`game_score`)) as score , gs_id , gu_id, lastupdate FROM `game_reports` WHERE gs_id =63 and gu_id in (select id from users) group by gs_id , gu_id, lastupdate) a1 group by gs_id, gu_id) s5 on s5.gu_id=mu.id 
			 
		 where academic_center_id!=0 order BY academic_center_id ');
		//echo $this->multipledb->db->last_query(); exit;
		return $query->result_array();
			
	}
		
	public function getbspireport1($userid,$mnths)
	{
	
		$query = $this->multipledb->ba->query("SELECT (".$this->config->item('skilllogic')."(`game_score`)) as gamescore,gs_id , lastupdate FROM `game_reports` WHERE gs_id in (59,60,61,62,63) and gu_id=".$this->multipledb->ba->escape($userid)." and DATE_FORMAT(lastupdate,'%b-%Y') in (".$this->multipledb->ba->escape($mnths).") and  lastupdate between (select startdate from users where id=".$this->multipledb->ba->escape($userid).") and (select enddate from users where id=".$this->multipledb->ba->escape($userid).") group by gs_id , lastupdate");
		//echo $this->multipledb->ba->last_query(); exit;
		return $query->result_array();
	 }
		
	public function clp_reports($academicid='',$studentname='',$gradeid='')		 
	{
			
			$where = ' ';
			
			if($academicid!='')
			{
				$where.= " and academic_center_id = ".$this->multipledb->ba->escape($academicid).""; 
			}
			if($studentname!='')
			{
				$where.= " and CONCAT(fname,'',lname) LIKE '%".$studentname."%'"; 
			}
			if($gradeid!='')
			{
				$where.= " and grade_id = ".$this->multipledb->ba->escape($gradeid).""; 
			}


			$query = $this->multipledb->ba->query("select id,fname,lname,username,gp_id,section,grade_id,creation_date,(select classname from class where id=grade_id order by id asc) as grade,academic_center_id,(select MAX(session_id) as play from game_reports where gu_id=a1.id) as playcount,(select name from cycle_master where (playcount between range_start and range_end) and status=1) as cyclename,
			
			(select game_score from asap_game_reports where gs_id=59 and asap_id=24 and gu_id=a1.id) as me24,
			(select game_score from asap_game_reports where gs_id=60 and asap_id=24 and gu_id=a1.id) as vp24,
			(select game_score from asap_game_reports where gs_id=61 and asap_id=24 and gu_id=a1.id) as fa24,
			(select game_score from asap_game_reports where gs_id=62 and asap_id=24 and gu_id=a1.id) as ps24,
			(select game_score from asap_game_reports where gs_id=63 and asap_id=24 and gu_id=a1.id) as li24,
			
			(select game_score from asap_game_reports where gs_id=59 and asap_id=48 and gu_id=a1.id) as me48,
			(select game_score from asap_game_reports where gs_id=60 and asap_id=48 and gu_id=a1.id) as vp48,
			(select game_score from asap_game_reports where gs_id=61 and asap_id=48 and gu_id=a1.id) as fa48,
			(select game_score from asap_game_reports where gs_id=62 and asap_id=48 and gu_id=a1.id) as ps48,
			(select game_score from asap_game_reports where gs_id=63 and asap_id=48 and gu_id=a1.id) as li48,
			(select asap_id from asap_game_reports where gu_id=a1.id group by gu_id) as asapstatus,

			(select CONVERT(CONCAT(avg(game_score),',',avg(game_score1)),CHAR(100)) from (select AVG(game_score)as game_score,MAX(game_score)as game_score1,lastupdate,gu_id from game_reports where gs_id=59 and session_id BETWEEN 1 and 8  group by lastupdate,gu_id ) s1  where gu_id=a1.id) as skillscorem,

			(select CONVERT(CONCAT(avg(game_score),',',avg(game_score1)),CHAR(100)) from (select AVG(game_score)as game_score,MAX(game_score)as game_score1,lastupdate,gu_id from game_reports where gs_id=60 and session_id BETWEEN 1 and 8 group by lastupdate,gu_id )s2  where gu_id=a1.id) as skillscorev,

			(select CONVERT(CONCAT(avg(game_score),',',avg(game_score1)),CHAR(100)) from (select AVG(game_score)as game_score,MAX(game_score)as game_score1,lastupdate,gu_id from game_reports where gs_id=61 and session_id BETWEEN 1 and 8  group by lastupdate,gu_id )s3  where gu_id=a1.id) as skillscoref,

			(select CONVERT(CONCAT(avg(game_score),',',avg(game_score1)),CHAR(100)) from (select AVG(game_score)as game_score,MAX(game_score)as game_score1,lastupdate,gu_id from game_reports where gs_id=62 and session_id BETWEEN 1 and 8  group by lastupdate,gu_id )s4  where gu_id=a1.id) as skillscorep,

			(select CONVERT(CONCAT(avg(game_score),',',avg(game_score1)),CHAR(100)) from (select AVG(game_score)as game_score,MAX(game_score)as game_score1,lastupdate,gu_id from  game_reports where gs_id=63 and session_id BETWEEN 1 and 8 group by lastupdate,gu_id )s5  where gu_id=a1.id) as skillscorel,

			(select count(lastupdate) from (select lastupdate,gu_id from  game_reports group by lastupdate,gu_id) s1 where lastupdate between a1.startdate and a1.enddate and gu_id=a1.id) as AttendedSession,

			(select SUM(CASE WHEN game>=5 THEN 1 ELSE 0 END) as completedsession from (select sum(gamesplayed) as game,gu_id,lastupdate from (select lastupdate,count(DISTINCT gs_id) as gamesplayed,gu_id from  game_reports  group by gu_id,gs_id,lastupdate) a3 group by gu_id,lastupdate) s1 where lastupdate between a1.startdate and a1.enddate and  gu_id=a1.id) as CompletedSession	

			from (select id,fname,lname,username,gp_id,section,grade_id,creation_date,academic_center_id,startdate,enddate  from users where sid=2 and status=1 and visible=1 and isdemo=0 and isapp='Y' ".$this->multipledb->ba->escape($where)." ) a1 ORDER BY academic_center_id");

			//	echo $this->multipledb->ba->last_query(); 
			return $query->result_array();
		}
		
		public function getbspicomparison($userid)		 
		{
			$query =  $this->multipledb->ba->query('select id, fname, a3.finalscore as avgbspiset1 from users mu

			left join 
			 (SELECT SUM(score)/5 as finalscore, gu_id, (SELECT sid from users where id=gu_id) as schoolid from (select (AVG(score)) as score, gu_id, gs_id from (SELECT (AVG(`game_score`)) as score , gs_id , gu_id, lastupdate FROM `asap_game_reports` WHERE gs_id in (59,60,61,62,63) and portal_type="ASAP1" and gu_id =  '.$this->multipledb->ba->escape($userid).' group by gs_id , gu_id, lastupdate) a1 group by gs_id, gu_id ) a2 group by gu_id) a3   on a3.gu_id=mu.id 
			 where id = '.$this->multipledb->ba->escape($userid).' ORDER BY avgbspiset1 DESC');
 
			//echo $this->multipledb->ba->last_query(); exit;
			return $query->result_array();
		}
		
		public function getbspicomparison2($userid)		 
		{
			$query =  $this->multipledb->ba->query('select id, fname, a3.finalscore as avgbspiset1 from users mu

			left join 
			 (SELECT SUM(score)/5 as finalscore, gu_id, (SELECT sid from users where id=gu_id) as schoolid from (select (AVG(score)) as score, gu_id, gs_id from (SELECT (AVG(`game_score`)) as score , gs_id , gu_id, lastupdate FROM `asap_game_reports` WHERE gs_id in (59,60,61,62,63) and portal_type="ASAP2" and gu_id =  '.$this->multipledb->ba->escape($userid).' group by gs_id , gu_id, lastupdate) a1 group by gs_id, gu_id ) a2 group by gu_id) a3   on a3.gu_id=mu.id 
			 where id = '.$this->multipledb->ba->escape($userid).' ORDER BY avgbspiset1 DESC');
 
			//echo $this->multipledb->ba->last_query(); exit;
			return $query->result_array();
		}
		
	public function getMonthWiseSkillScore($uid,$startdate,$enddate)
	{
		$query = $this->multipledb->ba->query("select gs_id,(CASE WHEN gs_id=59 THEN 'MEMORY'
		WHEN gs_id=60 THEN 'VP'
		WHEN gs_id=61 THEN 'FA'
		WHEN gs_id=62 THEN 'PS'
		WHEN gs_id=63 THEN 'LI' else 0
		END) as skillname,playedMonth,monthName,AVG(gamescore) as gamescore from (SELECT (AVG(game_score)) as gamescore ,gs_id , lastupdate,gu_id,DATE_FORMAT(lastupdate,'%m') as playedMonth,DATE_FORMAT(lastupdate, '%b') as monthName FROM game_reports WHERE gs_id in (59,60,61,62,63)and gu_id=".$this->multipledb->ba->escape($uid)." and lastupdate between ".$this->multipledb->ba->escape($startdate)." and ".$this->multipledb->ba->escape($enddate)." group by gs_id,lastupdate) a1 group by gs_id,playedMonth");
		//echo $this->multipledb->ba->last_query(); exit;
		return $query->result_array();
	}
		
	public function clpbspi($userid)		 
	{
		$query = $this->multipledb->ba->query('select id, fname, a3.finalscore as avgbspiset1,(select MAX(session_id) as play from game_reports where gu_id=mu.id) as playcount,(select name from cycle_master where (playcount between range_start and range_end) and status=1) as cyclename from users mu

		left join 
		 (SELECT SUM(score)/5 as finalscore, gu_id, (SELECT sid from users where id=gu_id) as schoolid from (select (AVG(score)) as score, gu_id, gs_id from (SELECT ('.$this->config->item('skilllogic').'(`game_score`)) as score , gs_id , gu_id, lastupdate FROM `game_reports` WHERE gs_id in (59,60,61,62,63) and gu_id =  '.$this->multipledb->ba->escape($userid).' and session_id BETWEEN 1 and 8 group by gs_id , gu_id, lastupdate) a1 group by gs_id, gu_id ) a2 group by gu_id) a3   on a3.gu_id=mu.id 
		 where id = '.$this->multipledb->ba->escape($userid).' ORDER BY avgbspiset1 DESC');
 
		//echo $this->multipledb->db->last_query(); exit;
		return $query->result_array();
	}
		
		public function getcounters($userid)		 
		{
			$query = $this->multipledb->ba->query("SELECT ROUND((SUM(gtime)/60),0) as gtime_school_count , SUM(answer) as answer_school_count, SUM(attempt_question) as attempted_question_count FROM game_reports gr join users u on gr.gu_id=u.id
			WHERE gtime IS NOT NULL AND answer IS NOT NULL and u.id=".$this->multipledb->ba->escape($userid)." and u.status=1  and lastupdate between (select startdate from users where id=".$this->multipledb->ba->escape($userid).") and (select enddate from users where id=".$this->multipledb->ba->escape($userid).")");
 
			//echo $this->multipledb->ba->last_query(); exit;
			return $query->result_array();
		}
		
		
		public function getcrowny($userid)		 
		{
			$query = $this->multipledb->ba->query("select points from vi_sumofcrownypoints where U_ID=".$this->multipledb->ba->escape($userid)." "); 
			//echo $this->multipledb->ba->last_query(); exit;
			return $query->result_array();
		}
		
		public function getattemptsession($userid)		 
		{
			$query = $this->multipledb->ba->query("select gu_id,count(Completed) as attempt from (select gu_id,gs_id,count(gs_id) Completed from (SELECT count(gr.id) as PalyCount,DATE_FORMAT(`lastupdate`,'%m') as monthlist ,lastupdate,gs_id,gu_id from game_reports gr join users u on u.id = gr.gu_id join user_academic_mapping um on u.id=um.id where gu_id=".$this->multipledb->ba->escape($userid)." and date(lastupdate) between (select startdate from users where id=".$this->multipledb->ba->escape($userid).") and (select enddate from users where id=".$this->multipledb->ba->escape($userid).") group by date(lastupdate),DATE_FORMAT(`lastupdate`,'%m'),gu_id,gs_id order by date(lastupdate))a2 group by gu_id,lastupdate)a2 ");
 
		//	echo $this->multipledb->ba->last_query(); exit;
			return $query->result_array();
		}
		
		public function getcompsession($userid)		 
		{
			$query = $this->multipledb->ba->query("select gu_id,count(Completed) as comp from (select gu_id,gs_id,count(gs_id) Completed from (SELECT count(gr.id) as PalyCount,DATE_FORMAT(`lastupdate`,'%m') as monthlist ,lastupdate,gs_id,gu_id from game_reports gr join users u on u.id = gr.gu_id join user_academic_mapping um on u.id=um.id where gu_id=".$this->multipledb->ba->escape($userid)." and date(lastupdate) between (select startdate from users where id=".$this->multipledb->ba->escape($userid).") and (select enddate from users where id=".$this->multipledb->ba->escape($userid).") group by date(lastupdate),DATE_FORMAT(`lastupdate`,'%m'),gu_id,gs_id order by date(lastupdate))a2 group by gu_id,lastupdate)a2 where Completed>=5");
 
			//echo $this->multipledb->ba->last_query(); exit;
			return $query->result_array();
		}
		
		public function get_clp_skillwise_avg($userid)		 
		{
			$query = $this->multipledb->ba->query("select id, fname, s1.skillscore_M as skillscorem, skillscore_V as skillscorev,skillscore_F as skillscoref,skillscore_P as skillscorep,skillscore_L as skillscorel, a3.finalscore as avgbspiset1 from users mu 
			left join (SELECT SUM(score)/5 as finalscore, gu_id, (SELECT sid from users where id=gu_id) as schoolid from (select (AVG(score)) as score, gu_id, gs_id from (SELECT (AVG(`game_score`)) as score , gs_id , gu_id, lastupdate FROM `game_reports` WHERE gs_id in (59,60,61,62,63) and gu_id=".$this->multipledb->ba->escape($userid)." and session_id BETWEEN 1 and 8 group by gs_id , gu_id, lastupdate) a1 group by gs_id, gu_id ) a2 group by gu_id) a3 on a3.gu_id=mu.id 
			left join (select (AVG(score)) as skillscore_M, gu_id from (SELECT (AVG(`game_score`)) as score , gs_id , gu_id, lastupdate FROM `game_reports` WHERE gs_id =59 and gu_id=".$this->multipledb->ba->escape($userid)." and session_id BETWEEN 1 and 8 group by gs_id , gu_id, lastupdate) a1 group by gs_id, gu_id) s1 on s1.gu_id=mu.id 
			left join (select (AVG(score)) as skillscore_V, gu_id from (SELECT (AVG(`game_score`)) as score , gs_id , gu_id, lastupdate FROM `game_reports` WHERE gs_id =60 and gu_id=".$this->multipledb->ba->escape($userid)." and session_id BETWEEN 1 and 8 group by gs_id , gu_id, lastupdate) a1 group by gs_id, gu_id) s2 on s2.gu_id=mu.id 
			left join (select (AVG(score)) as skillscore_F, gu_id from (SELECT (AVG(`game_score`)) as score , gs_id , gu_id, lastupdate FROM `game_reports` WHERE gs_id =61 and gu_id=".$this->multipledb->ba->escape($userid)." and session_id BETWEEN 1 and 8 group by gs_id , gu_id, lastupdate) a1 group by gs_id, gu_id) s3 on s3.gu_id=mu.id 
			left join (select (AVG(score)) as skillscore_P, gu_id from (SELECT (AVG(`game_score`)) as score , gs_id , gu_id, lastupdate FROM `game_reports` WHERE gs_id =62 and gu_id=".$this->multipledb->ba->escape($userid)." and session_id BETWEEN 1 and 8 group by gs_id , gu_id, lastupdate) a1 group by gs_id, gu_id) s4 on s4.gu_id=mu.id 
			left join (select (AVG(score)) as skillscore_L, gu_id from (SELECT (AVG(`game_score`)) as score , gs_id , gu_id, lastupdate FROM `game_reports` WHERE gs_id =63 and gu_id=".$this->multipledb->ba->escape($userid)." and session_id BETWEEN 1 and 8 group by gs_id , gu_id, lastupdate) a1 group by gs_id, gu_id) s5 on s5.gu_id=mu.id 

			 where id=".$this->multipledb->ba->escape($userid)." ORDER BY avgbspiset1 DESC");
 
			//echo $this->multipledb->ba->last_query(); exit;
			return $query->result_array();
	}
		
		
	
	public function getpatienttype()		 
	{
		$query = $this->multipledb->ba->query("SELECT id,type from  patient_type_master where status=1");
		//echo $this->multipledb->ba->last_query(); exit;
		return $query->result_array();
	}
		
	public function updatepatienttype($userid,$typeid)		 
	{
		$query = $this->multipledb->ba->query("UPDATE users SET patient_type=".$this->multipledb->ba->escape($typeid)." where id=".$this->multipledb->ba->escape($userid)." ");
		//echo $this->multipledb->ba->last_query(); exit;
		//return $query->result_array();
	}
		
	public function getacademicmonths($startdate,$enddate)
	{ //echo ;exit;
			 
		$query = $this->multipledb->ba->query("select DATE_FORMAT(m1, '%m') as monthNumber,DATE_FORMAT(m1, '%Y') as yearNumber,DATE_FORMAT(m1, '%b') as monthName from (select (".$this->multipledb->ba->escape($startdate)." - INTERVAL DAYOFMONTH(".$this->multipledb->ba->escape($startdate).")-1 DAY) +INTERVAL m MONTH as m1 from (select @rownum:=@rownum+1 as m from(select 1 union select 2 union select 3 union select 4) t1,(select 1 union select 2 union select 3 union select 4) t2,(select 1 union select 2 union select 3 union select 4) t3,(select 1 union select 2 union select 3 union select 4) t4,(select @rownum:=-1) t0) d1) d2 where m1<=".$this->multipledb->ba->escape($enddate)." order by m1");
		//echo $this->multipledb->ba->last_query(); exit;
			return $query->result_array();
	}
		 
	public function IsAsapEnable($username)
	{
		//$query = $this->multipledb->saasap->query('select count(id) as playedstatus from game_reports where gu_id=(select id from users where username='.$this->multipledb->ba->escape($username).') and gs_id in(59,60,61,62,63)');
		
		$query = $this->multipledb->ba->query('select count(id) as playedstatus,count(distinct(portal_type)) as asapcount from asap_game_reports where gu_id=(select id from users where username='.$this->multipledb->ba->escape($username).') and gs_id in(59,60,61,62,63)');
		//echo $this->multipledb->db->last_query(); exit;
		return $query->result_array();
	}
	
	public function IsCLPEnable($uid)
	{
		$query = $this->multipledb->ba->query('select count(id) as playedstatus from game_reports where gu_id='.$this->multipledb->ba->escape($uid).' and gs_id in(59,60,61,62,63)');
		return $query->result_array();
	}
	
		 
	public function getUserEfficiencyGraph($userid,$startdate,$enddate)
	{
		$query = $this->multipledb->ba->query("
		select round((sum(score)/5),2) as score,playeddate as rtime,monthNumber,yearNumber from (select avg(score) as score,sum(playeddate) as playeddate,DATE_FORMAT(lastupdate, '%m') as monthNumber,DATE_FORMAT(lastupdate, '%Y') as yearNumber from ( SELECT (".$this->config->item('skilllogic')."(`game_score`)) as score,count(distinct lastupdate) as playeddate,gs_id,lastupdate,gu_id FROM `game_reports` WHERE gs_id in (59,60,61,62,63) and gu_id=".$this->multipledb->ba->escape($userid)." and (lastupdate between ".$this->multipledb->ba->escape($startdate)." and ".$this->multipledb->ba->escape($enddate).") group by gs_id,lastupdate) a1 group by gs_id,month(lastupdate))a2 group by monthNumber");
		//echo $this->multipledb->ba->last_query(); exit;
		return $query->result_array();
	}


	public function mybspicalendar($school_id,$uid,$dateQry,$startdate,$enddate)
	{
		$query = $this->multipledb->ba->query('select (sum(a.game_score)/5) as game_score, lastupdate,playedDate from(SELECT '.$this->config->item('skilllogic').'(gr.game_score) as game_score,count(*) as cnt, lastupdate,DATE_FORMAT(`lastupdate`,"%d") as playedDate FROM game_reports gr join category_skills sk join users u WHERE gr.gu_id = u.id and u.sid =2 and gr.gu_id='.$this->multipledb->ba->escape($uid).' and sk.id = gr.gs_id and gr.gs_id in (SELECT id FROM category_skills where category_id=2) and  lastupdate between '.$this->multipledb->ba->escape($startdate).' and '.$this->multipledb->ba->escape($enddate).' AND DATE_FORMAT(lastupdate, "%Y-%m")=\''.$dateQry.'\' group by lastupdate, gr.gs_id, gr.gu_id order by gr.gs_id) a group by lastupdate');
		//echo $this->multipledb->ba->last_query(); exit;
		return $query->result_array();
						
	}
	
	public function mySkillCalendar($school_id,$uid,$dateQry,$startdate,$enddate)
	{
		$query = $this->multipledb->ba->query('SELECT gs_id,avg(gr.game_score) as game_score,count(*) as cnt, lastupdate,DATE_FORMAT(`lastupdate`,"%d") as playedDate FROM game_reports gr join category_skills sk join users u WHERE gr.gu_id = u.id and u.sid =2 and gr.gu_id='.$this->multipledb->ba->escape($uid).' and sk.id = gr.gs_id and gr.gs_id in (SELECT id FROM category_skills where category_id=2) and  lastupdate between '.$this->multipledb->ba->escape($startdate).' and '.$this->multipledb->ba->escape($enddate).' AND DATE_FORMAT(lastupdate, "%Y-%m")=\''.$dateQry.'\' group by lastupdate, gr.gs_id, gr.gu_id order by lastupdate asc');
		//echo $this->multipledb->ba->last_query(); exit;
		return $query->result_array();
	}
	
	public function getgamedetails($userid,$gameid,$pid,$startdate,$enddate)
	{
		$query = $this->multipledb->ba->query("select g_id, avg(game_score) as game_score,DATE_FORMAT(lastupdate, '%d-%m-%Y') as lastupdate from game_reports where gp_id = ".$this->multipledb->ba->escape($pid)." and gu_id=".$this->multipledb->ba->escape($userid)." and g_id=".$this->multipledb->ba->escape($gameid)." AND (lastupdate between ".$this->multipledb->ba->escape($startdate)." and ".$this->multipledb->ba->escape($enddate).") group by lastupdate  ORDER BY lastupdate DESC LIMIT 10");
		//echo $this->multipledb->ba->last_query(); 
		return $query->result_array();
	}
		   
	public function getScannedCoupon($doctorid)
	{  
		$query = $this->multipledb->ba->query("SELECT qrcode,date(qr_scanned_date_time) as scandate,status as ldata,usedstatus FROM couponmaster WHERE doctorid=".$this->multipledb->ba->escape($doctorid)." ORDER BY qr_scanned_date_time DESC");
		return $query->result_array();
	}
	
	public function getgamenames($userid,$pid,$startdate,$enddate)
	{
	 
		$query=$this->multipledb->ba->query("SELECT a.gid,a.gname FROM  games a, game_reports b where a.gid=b.g_id and b.gu_id=".$this->multipledb->ba->escape($userid)." and b.gp_id = ".$this->multipledb->ba->escape($pid)."  and a.gc_id = 1 and (lastupdate between ".$this->multipledb->ba->escape($startdate)." and ".$this->multipledb->ba->escape($enddate).") group by a.gid");
		//echo $this->multipledb->ba->last_query(); exit;
		return $query->result();
	}
	
	
	public function checkdoctormailidexist($emailid)
	{
				 
		$query = $this->multipledb->ba->query('select id,count(email) as emailcount,doctorname,lastname,email,username,mobilenumber from doctormaster where email ='.$this->multipledb->ba->escape($emailid).' and status=1');		
		//echo $this->multipledb->ba->last_query(); exit;
		return $query->result_array();
	}
	
	public function resetpwdlog($userid,$randid)
	{	
		$qry=$this->multipledb->ba->query("insert into doctor_password_history(doctorid,randid,requestdatetime,status)values(".$this->multipledb->ba->escape($userid).",".$this->multipledb->ba->escape($randid).",NOW(),0)");
	}
	function CheckValidActivationlink($userid,$randid)
	{
		$query=$this->multipledb->ba->query("select doctorid as userid,randid,requestdatetime from doctor_password_history where status=0 and md5(doctorid)=".$this->multipledb->ba->escape($userid)." and md5(randid)=".$this->multipledb->ba->escape($randid)."");
		//echo $this->multipledb->ba->last_query(); exit;
		return $query->result_array();
	}
	
	public function getResetpwdDoctorDetails($userid)
	{	
		$query = $this->multipledb->ba->query('select id,doctorname,lastname,email,username,mobilenumber from doctormaster where id='.$this->multipledb->ba->escape($userid).' and status=1');
		//echo $this->multipledb->ba->last_query(); exit;
		return $query->result_array();
	}
	
	function UpdateNewPwd($pwd,$userid,$salt1,$salt2,$orgpwd)
	{
		$qry=$this->multipledb->ba->query("update doctormaster set password=".$this->multipledb->ba->escape('.$this->multipledb->ba->escape($pwd).').",orgpwd=".$this->multipledb->ba->escape($orgpwd)." where md5(id)=".$this->multipledb->ba->escape($userid)."");
	}
	
	function UpdateNewPwd_log($userid,$randid,$orgpwd,$ip)
	{
		$qry=$this->multipledb->ba->query("update doctor_password_history set processdatetime=now(),status=1,update_password=".$this->multipledb->ba->escape($orgpwd).",ip=".$this->multipledb->ba->escape($ip)." where md5(doctorid)=".$this->multipledb->ba->escape($userid)." and md5(randid)=".$this->multipledb->ba->escape($randid)."");
	}
	
	public function insert_login_log($centerid,$sessionid,$ip,$country,$region,$city,$isp,$browser,$status)
	{
			$query = $this->multipledb->ba->query('INSERT INTO 	admin_login_log(	adminid,sessionid,created_date,lastupdate,logout_date,ip,country,region,city,browser,isp,status)VALUES('.$this->multipledb->ba->escape($centerid).','.$this->multipledb->ba->escape($sessionid).',now(),now(),now(), '.$this->multipledb->ba->escape($ip).',"","","",'.$this->multipledb->ba->escape($browser).',"",'.$this->multipledb->ba->escape($status).')');
			//echo $this->multipledb->ba->last_query(); exit;
			return $query;
			
	}
		
	public function update_login_log($adminid,$sessionid)
	{
			$query = $this->multipledb->ba->query('update admin_login_log set lastupdate=now() where adminid='.$this->multipledb->ba->escape($adminid).' and sessionid='.$this->multipledb->ba->escape($sessionid).'');
			return $query;
			
	}
		
	public function update_logout_log($adminid,$sessionid)
	{
			$query = $this->multipledb->ba->query('update admin_login_log set lastupdate=now(),logout_date=now() where adminid='.$this->multipledb->ba->escape($adminid).' and sessionid='.$this->multipledb->ba->escape($sessionid).'');
			return $query;
			
	}
		
	public function getacadmiclist($proid)
	{
			$query = $this->multipledb->ba->query('SELECT id,(select sum(licensecount) from license_count where centerid=a.id and product_id='.$this->multipledb->ba->escape($proid).') as givenlicence,(select product_name from product_master where id='.$this->multipledb->ba->escape($proid).') as productname, (select count(*) from users where academic_center_id=a.id and status=1) as usedlicense from academic_center_master a where status=1 and isdemo=0 ORDER BY givenlicence DESC');
			return $query->result_array();
			
	}
		
	public function sc_getacadmiclist($proid)
	{
			$query = $this->multipledb->ba->query('SELECT id,(select sum(licensecount) from  license_count where centerid=a.id and product_id='.$this->multipledb->ba->escape($proid).') as givenlicence,(select product_name from product_master where id='.$this->multipledb->ba->escape($proid).') as productname, (select count(*) from '.$this->config->item("asapdb").'.users where academic_center_id=a.id and status=1 and isnewuser="Y") as usedlicense from academic_center_master a where status=1 and isdemo=0 ORDER BY givenlicence DESC');
			//echo $this->multipledb->ba->last_query(); exit; 
			return $query->result_array();			
	}
		
	public function getproductlist()
	{
			$query = $this->multipledb->ba->query('SELECT `id`, `product_name`, `product_code`, `status` FROM `product_master` WHERE status=1 and isdemo=0');
			return $query->result_array();
			
	}
		
	public function academiccount()
	{
			$query = $this->multipledb->ba->query('SELECT count(id) as totalcount from academic_center_master a where status=1 and isdemo=0');
			return $query->result_array();
			
	}
		
	public function licenseissuelist($proid)
	{
			$query = $this->multipledb->ba->query('SELECT  noofcoupon,status,issued_on,(select product_name from product_master where id='.$this->multipledb->ba->escape($proid).') as productname from edsix_issued_coupon a where status="Y" and product_id='.$this->multipledb->ba->escape($proid).' order by issued_on DESC');
			return $query->result_array();
			
	}
		
	public function licensetoacademy()
	{
			$query = $this->multipledb->ba->query('SELECT SUM(licensecount) as distributedcount  from license_count a where status=1 group by centerid');
			return $query->result_array();
			
	}
		  
		
	public function updatepwd($adminid,$pwd)
	{
			$query = $this->multipledb->ba->query('update admin set password="'.md5('.$this->multipledb->ba->escape($pwd).').'",orgpwd='.$this->multipledb->ba->escape($pwd).',modified_date=now() where id='.$this->multipledb->ba->escape($adminid).'');
			//echo $this->multipledb->ba->last_query(); exit;
			//return $query->result_array();
	}
		
	public function adminresetpwdlog($randid,$pwd,$adminid)
	{	
			$qry=$this->multipledb->ba->query("insert into  admin_password_history(adminid,randid,requestdatetime,update_password,ip,status)values(".$this->multipledb->ba->escape($adminid).",".$this->multipledb->ba->escape($randid).",NOW(),".$this->multipledb->ba->escape('.$this->multipledb->ba->escape($pwd).').",'".$this->input->ip_address()."',0)");
			//echo $this->multipledb->ba->last_query(); exit;
	}
	
	public function getgrades()
	{
			$query = $this->multipledb->ba->query('SELECT id,classname from class where status=0 ORDER BY sorting_order');
			//echo $this->multipledb->ba->last_query(); exit;
			return $query->result_array();
	}
		
		/****ACADEMIC DASHBOARD START*******/
		
	public function academy_userscount($centerid)
    {
			$query = $this->multipledb->ba->query("SELECT count(*) as total FROM users  WHERE  academic_center_id=".$this->multipledb->ba->escape($centerid)." and isdemo=0 and status=1");		
		//	echo $this->multipledb->ba->last_query(); exit;
			return $query->result_array();
    }
		
	public function academy_gradewiseusers($centerid)
    { 
			$query = $this->multipledb->ba->query("SELECT count(*) as usercount, REPLACE (classname, 'Grade', '') as grade,sorting_order  FROM users u JOIN class c ON u.grade_id=c.id  WHERE  academic_center_id=".$this->multipledb->ba->escape($centerid)." and isdemo=0 and u.status=1 group by `grade_id` order by sorting_order");
		//	echo $this->multipledb->ba->last_query(); exit;
			return $query->result_array();
	}
		
	public function academy_asap_reports($centerid) 
	{
			
			$query = $this->multipledb->ba->query('select id, fname,lname,username,mobile,father,mother,  s1.skillscore_M as skillscorem, skillscore_V as skillscorev,skillscore_F as skillscoref,skillscore_P as skillscorep,skillscore_L as skillscorel, a3.finalscore as avgbspiset1,COALESCE(a3.playedcount,0) as playcount from users mu

			left join 
			 (SELECT SUM(score)/5 as finalscore, count(gu_id) as playedcount, gu_id, (SELECT sid from users where id=gu_id) as schoolid from (select (AVG(score)) as score, gu_id, gs_id from (SELECT (AVG(`game_score`)) as score , gs_id , gu_id, lastupdate FROM `game_reports` WHERE gs_id in (59,60,61,62,63) and gu_id in (select id from users) group by gs_id , gu_id, lastupdate) a1 group by gs_id, gu_id ) a2 group by gu_id) a3   on a3.gu_id=mu.id 
			 
			 left join
			(select (AVG(score)) as skillscore_M, gu_id from (SELECT (AVG(`game_score`)) as score , gs_id , gu_id, lastupdate FROM `game_reports` WHERE gs_id =59 and gu_id in (select id from users) group by gs_id , gu_id, lastupdate) a1 group by gs_id, gu_id) s1 on s1.gu_id=mu.id 

			left join
			(select (AVG(score)) as skillscore_V, gu_id from (SELECT (AVG(`game_score`)) as score , gs_id , gu_id, lastupdate FROM `game_reports` WHERE gs_id =60 and gu_id in (select id from users) group by gs_id , gu_id, lastupdate) a1 group by gs_id, gu_id) s2 on s2.gu_id=mu.id 

			left join
			(select (AVG(score)) as skillscore_F, gu_id from (SELECT (AVG(`game_score`)) as score , gs_id , gu_id, lastupdate FROM `game_reports` WHERE gs_id =61 and gu_id in (select id from users) group by gs_id , gu_id, lastupdate) a1 group by gs_id, gu_id) s3 on s3.gu_id=mu.id 

			left join
			(select (AVG(score)) as skillscore_P, gu_id from (SELECT (AVG(`game_score`)) as score , gs_id , gu_id, lastupdate FROM `game_reports` WHERE gs_id =62 and gu_id in (select id from users) group by gs_id , gu_id, lastupdate) a1 group by gs_id, gu_id) s4 on s4.gu_id=mu.id 

			left join
			(select (AVG(score)) as skillscore_L, gu_id from (SELECT (AVG(`game_score`)) as score , gs_id , gu_id, lastupdate FROM `game_reports` WHERE gs_id =63 and gu_id in (select id from users) group by gs_id , gu_id, lastupdate) a1 group by gs_id, gu_id) s5 on s5.gu_id=mu.id  

			 where academic_center_id='.$this->multipledb->ba->escape($centerid).' ');
			//echo $this->multipledb->db->last_query(); exit;
			return $query->result_array();
			
	}
		
	public function academy_clp_reports($centerid)		 
	{
			$query = $this->multipledb->ba->query("select id,fname,lname,username,gp_id,section,grade_id,creation_date,(select classname from class where id=grade_id order by id asc) as grade,academic_center_id, (select MAX(session_id) as play from game_reports where gu_id=a1.id) as playcount,(select name from cycle_master where (playcount between range_start and range_end) and status=1) as cyclename,
	
			(select game_score from asap_game_reports where gs_id=59 and asap_id=24 and gu_id=a1.id) as me24,
			(select game_score from asap_game_reports where gs_id=60 and asap_id=24 and gu_id=a1.id) as vp24,
			(select game_score from asap_game_reports where gs_id=61 and asap_id=24 and gu_id=a1.id) as fa24,
			(select game_score from asap_game_reports where gs_id=62 and asap_id=24 and gu_id=a1.id) as ps24,
			(select game_score from asap_game_reports where gs_id=63 and asap_id=24 and gu_id=a1.id) as li24,
			
			(select game_score from asap_game_reports where gs_id=59 and asap_id=48 and gu_id=a1.id) as me48,
			(select game_score from asap_game_reports where gs_id=60 and asap_id=48 and gu_id=a1.id) as vp48,
			(select game_score from asap_game_reports where gs_id=61 and asap_id=48 and gu_id=a1.id) as fa48,
			(select game_score from asap_game_reports where gs_id=62 and asap_id=48 and gu_id=a1.id) as ps48,
			(select game_score from asap_game_reports where gs_id=63 and asap_id=48 and gu_id=a1.id) as li48,
			
			(select CONVERT(CONCAT(avg(game_score),',',avg(game_score1)),CHAR(100)) from (select AVG(game_score)as game_score,MAX(game_score)as game_score1,lastupdate,gu_id from game_reports where gs_id=59 and session_id BETWEEN 1 and 8   group by lastupdate,gu_id ) s1  where gu_id=a1.id) as skillscorem,
			
			(select CONVERT(CONCAT(avg(game_score),',',avg(game_score1)),CHAR(100)) from (select AVG(game_score)as game_score,MAX(game_score)as game_score1,lastupdate,gu_id from game_reports where gs_id=60 and session_id BETWEEN 1 and 8 group by lastupdate,gu_id )s2  where gu_id=a1.id) as skillscorev,
			
			(select CONVERT(CONCAT(avg(game_score),',',avg(game_score1)),CHAR(100)) from (select AVG(game_score)as game_score,MAX(game_score)as game_score1,lastupdate,gu_id from game_reports where gs_id=61 and session_id BETWEEN 1 and 8  group by lastupdate,gu_id )s3  where gu_id=a1.id) as skillscoref,
			
			(select CONVERT(CONCAT(avg(game_score),',',avg(game_score1)),CHAR(100)) from (select AVG(game_score)as game_score,MAX(game_score)as game_score1,lastupdate,gu_id from game_reports where gs_id=62 and session_id BETWEEN 1 and 8  group by lastupdate,gu_id )s4  where gu_id=a1.id) as skillscorep,
			
			(select CONVERT(CONCAT(avg(game_score),',',avg(game_score1)),CHAR(100)) from (select AVG(game_score)as game_score,MAX(game_score)as game_score1,lastupdate,gu_id from  game_reports where gs_id=63 and session_id BETWEEN 1 and 8 group by lastupdate,gu_id )s5  where gu_id=a1.id) as skillscorel,
			
			(select count(lastupdate) from (select lastupdate,gu_id from  game_reports group by lastupdate,gu_id) s1 where lastupdate between a1.startdate and a1.enddate and gu_id=a1.id) as AttendedSession,
			
			(select SUM(CASE WHEN game>=5 THEN 1 ELSE 0 END) as completedsession from (select sum(gamesplayed) as game,gu_id,lastupdate from (select lastupdate,count(DISTINCT gs_id) as gamesplayed,gu_id from  game_reports  group by gu_id,gs_id,lastupdate) a3 group by gu_id,lastupdate) s1 where lastupdate between a1.startdate and a1.enddate and  gu_id=a1.id) as CompletedSession	
			
			
			from (select id,fname,lname,username,gp_id,section,grade_id,creation_date,academic_center_id,startdate,enddate from users where academic_center_id=".$this->multipledb->ba->escape($centerid)." and status=1  and isdemo=0  ) a1");
 
			//echo $this->multipledb->ba->last_query(); exit;
			return $query->result_array();
	} 
		 
		/**** END *****/
		
		/**** SC SATRT ****/
		
	public function academy_userscount_sc($centerid)
    {
			$query = $this->multipledb->saasap->query("SELECT count(*) as total FROM users  WHERE  academic_center_id=".$this->multipledb->ba->escape($centerid)." and isnewuser='Y' and status=1");		
		//	echo $this->multipledb->ba->last_query(); exit;
			return $query->result_array();
   }
		
	public function academy_gradewiseusers_sc($centerid)
    { 
			$query = $this->multipledb->saasap->query("SELECT count(*) as usercount, REPLACE (classname, 'Grade', '') as grade  FROM users u JOIN class c ON u.grade_id=c.id  WHERE  academic_center_id=".$this->multipledb->ba->escape($centerid)." and isnewuser='Y' and u.status=1 group by `grade_id`");
		//	echo $this->multipledb->ba->last_query(); exit;
			return $query->result_array();
	}
		
		
	public function distributedlicensetoacademy_sc($centerid)		 
	{
			$query = $this->multipledb->ba->query("SELECT id,(select sum(licensecount) from license_count where centerid=a.id and product_id=2) as givenlicense from academic_center_master a where status=1 and isdemo=0 and id=".$this->multipledb->ba->escape($centerid)."");
			return $query->result_array();
	}
		
		 
		
	public function userlist_sc($centerid)
    {
			$query = $this->multipledb->saasap->query("SELECT u.id,u.fname,username,u.creation_date , REPLACE (classname, 'Grade', '') as grade  FROM users u JOIN class c ON u.grade_id=c.id  WHERE  u.status=1 and u.isnewuser='Y' and academic_center_id=".$this->multipledb->ba->escape($centerid)."  order by u.id");
		//	echo $this->multipledb->ba->last_query(); exit;
			return $query->result_array();
	}
		
		
		/*** SC END ***/
		
	public function getproductname($proid) 
	{
			$query = $this->multipledb->ba->query("SELECT  `product_name` FROM `product_master` WHERE status=1 and isdemo=0 and id=".$this->multipledb->ba->escape($proid)."");
			return $query->result_array();
	}
		 
		
	public function usernamecheck($username) 
	{
			$query = $this->multipledb->ba->query('SELECT count(id) as usercount from academic_center_master where username='.$this->multipledb->ba->escape($username).' and status=1');
			//echo $this->multipledb->ba->last_query(); exit;
			return $query->result_array();
	}
		
	public function academycode($code) 
	{
			$query = $this->multipledb->ba->query('SELECT count(id) as codecount from academic_center_master where code='.$this->multipledb->ba->escape($code).' and status=1');
			//echo $this->multipledb->ba->last_query(); exit;
			return $query->result_array();
	}
		 
		
		 
		
		
		/*New code*/
		
	public function getCurrentSessionLevel($userid)
	{
		$query = $this->multipledb->ba->query("select session_id from gamedata where gu_id=".$this->multipledb->ba->escape($userid)." and session_id!=0 order by id DESC limit 1");
		//echo $this->multipledb->ba->last_query(); exit;
		return $query->result_array();
	}
	
	public function getDefaultCycleData($Session_StartRange,$Session_EndRange,$session_curid)
	{
		$query = $this->multipledb->ba->query("select * from cycle_master where status=1 and range_start <=".$this->multipledb->ba->escape($session_curid)." and range_start!=1 ");
		//echo $this->multipledb->ba->last_query(); exit;
		return $query->result_array();
	}
	
	public function getCurrentBSPIName($Session_StartRange,$Session_EndRange,$session_curid)
	{
		$query = $this->multipledb->ba->query("select * from cycle_master where status=1 and range_start =".$this->multipledb->ba->escape($Session_StartRange)." and range_end =".$this->multipledb->ba->escape($Session_EndRange)." ");
		//echo $this->multipledb->ba->last_query(); exit;
		return $query->result_array();
	}
	
	public function getacademicyearbyschoolid($userid)
	{
			 
			$query = $this->multipledb->ba->query("select startdate,enddate,id from academic_year where id=(select academic_id from schools where id=(select sid from users where id=".$this->multipledb->ba->escape($userid)."))order by id desc limit 1");
			return $query->result_array();
	 }
	 
	public function getAdvancedSkillChart($userid,$Session_StartRange,$Session_EndRange,$session_curid,$startdate,$enddate)
	{
		$query = $this->multipledb->ba->query("select AVG(gamescore) as gamescore,gs_id,session_id from (SELECT (AVG(game_score)) as gamescore,gs_id,session_id  FROM game_reports WHERE gs_id in (59,60,61,62,63) and gu_id=".$this->multipledb->ba->escape($userid)." and  (lastupdate between ".$this->multipledb->ba->escape($startdate)." and ".$this->multipledb->ba->escape($enddate).") and (session_id between ".$this->multipledb->ba->escape($Session_StartRange)." and ".$this->multipledb->ba->escape($Session_EndRange).") and session_id!=0  group by gs_id,session_id) a1 group by gs_id");
		//echo $this->multipledb->ba->last_query(); exit;
		return $query->result_array();
	}
	public function getBSPI_range($userid,$startrange,$endrange)		 
	{
			$query = $this->multipledb->ba->query('select id, fname, a3.finalscore as avgbspiset1 from users mu left join (SELECT SUM(score)/5 as finalscore, gu_id, (SELECT sid from users where id=gu_id) as schoolid from (select (AVG(score)) as score, gu_id, gs_id from (SELECT ('.$this->config->item('skilllogic').'(`game_score`)) as score , gs_id , gu_id, lastupdate FROM `game_reports` WHERE gs_id in (59,60,61,62,63) and gu_id =  '.$this->multipledb->ba->escape($userid).' and (session_id between '.$this->multipledb->ba->escape($startrange).' and '.$this->multipledb->ba->escape($endrange).') and session_id!=0 group by gs_id , gu_id, lastupdate) a1 group by gs_id, gu_id ) a2 group by gu_id) a3   on a3.gu_id=mu.id where id = '.$this->multipledb->ba->escape($userid).' ORDER BY avgbspiset1 DESC');
 
			//echo $this->multipledb->db->last_query(); exit;
			return $query->result_array();
	}
	
	public function getBasicSkillChart($userid,$Session_StartRange,$Session_EndRange,$session_curid,$startdate,$enddate)
	{
			$query = $this->multipledb->ba->query("select AVG(gamescore) as gamescore,gs_id,playedMonth from (SELECT (AVG(game_score)) as gamescore ,gs_id , lastupdate,DATE_FORMAT(lastupdate,'%m') as playedMonth  FROM sk_gamedata WHERE gs_id in (59,60,61,62,63) and gu_id=".$this->multipledb->ba->escape($userid)." and  (lastupdate between ".$this->multipledb->ba->escape($startdate)." and ".$this->multipledb->ba->escape($enddate).") and (session_id between ".$this->multipledb->ba->escape($Session_StartRange)." and ".$this->multipledb->ba->escape($Session_EndRange).") and session_id!=0  group by gs_id,session_id) a1 group by gs_id");
		//	echo $this->multipledb->ba->last_query(); exit;
		
			return $query->result_array();
	}
	
	public function getSkillKitBSPI($userid,$Session_StartRange,$Session_EndRange)
	{
			$query = $this->multipledb->ba->query('SELECT AVG(score) as tsi, gu_id from (select (AVG(score)) as score, gu_id, gs_id from (SELECT ('.$this->config->item('skilllogic').'(Convert(game_score,SIGNED))) as score , gs_id , gu_id, lastupdate FROM sk_gamedata WHERE gs_id in (59,60,61,62,63) and gu_id ='.$this->multipledb->ba->escape($userid).' and (session_id between '.$this->multipledb->ba->escape($Session_StartRange).' and '.$this->multipledb->ba->escape($Session_EndRange).') and session_id!=0 group by gs_id , gu_id, lastupdate) a1 group by gs_id, gu_id ) a2 group by gu_id');
	
			//echo $this->multipledb->ba->last_query(); exit;
			return $query->result_array();
	}
	public function getAssignSkills($userid)
	{
			$query = $this->multipledb->ba->query('select * from category_skills where FIND_IN_SET(id,(select weakSkills from sk_user_game_list where  userID='.$this->multipledb->ba->escape($userid).' and status=0))');
			//echo $this->multipledb->ba->last_query(); exit;
			return $query->result_array();
	}
	 public function getskills()
	{
			$query = $this->multipledb->ba->query("select name,id from category_skills where category_id = 2 order by id");
			//echo $this->multipledb->ba->last_query(); 
			return $query->result_array();
	}
	public function getInterAsapData($userid)		 
	{ 
			$query = $this->multipledb->ba->query("select gs_id,game_score from asap_game_reports where asap_id=24	 and gu_id=".$this->multipledb->ba->escape($userid)." group by gs_id ");
			//	echo $this->multipledb->ba->last_query(); 
			return $query->result_array();
	}
	public function getPostAsapData($userid)		 
	{ 
			$query = $this->multipledb->ba->query("select gs_id,game_score from asap_game_reports where asap_id=48	 and gu_id=".$this->multipledb->ba->escape($userid)." group by gs_id");
			//	echo $this->multipledb->ba->last_query(); 
			return $query->result_array();
	}
	public function getAllDefaultCycle()
	{
			$query = $this->multipledb->ba->query("select name,range_start,range_end,value from cycle_master where status=1 ");
			//echo $this->multipledb->ba->last_query(); exit;
			return $query->result_array();
	}
	public function getWeakSkills($skillid)
	{	
			if($skillid!=''){$gs_id="id in(".$skillid.")";}else{$gs_id="1=1";} 
	
			$query = $this->multipledb->ba->query("select * from category_skills where category_id = 2 and  ".$gs_id." order by id");
		//	echo $this->multipledb->ba->last_query(); exit;
			return $query->result_array();
	}
	
	//----------------add user---------------------------------
	public function get_classname()
	{		
			$query = $this->multipledb->saasap->query("SELECT id,classname from class  where id	not in(1,2,11)");
			//echo $this->multipledb->db->last_query(); exit;
			return $query->result_array();
	}
	public function getPlaninfo($grade_id)
	{		
			$query = $this->multipledb->saasap->query("SELECT plan_id from skl_class_plan 	where school_id=2 and class_id=".$this->multipledb->ba->escape($grade_id)."");
			//echo $this->multipledb->db->last_query(); exit;
			return $query->result_array();
	}

	public function insert_userdata($salt1, $pwdhash,$salt2,$fname,$lname,$gradename,$academyname,$plan_id,$checkboxchk,$brainydirectusrname)
	{ 
			$query = $this->multipledb->saasap->query("call concat_username_id(".$this->multipledb->ba->escape($salt1).",".$this->multipledb->ba->escape($pwdhash).",".$this->multipledb->ba->escape($salt2).",".$this->multipledb->ba->escape($fname).",".$this->multipledb->ba->escape($lname).",1,".$this->multipledb->ba->escape($gradename).",2,'A',19,now(),1,".$this->multipledb->ba->escape($academyname).",'N','Y',".$this->multipledb->ba->escape($plan_id).",".$this->multipledb->ba->escape($checkboxchk).",".$this->multipledb->ba->escape($brainydirectusrname).")"); 
		//	echo $this->multipledb->saasap->last_query(); exit;
			return $query->result_array();
	} 
	
		
	//----------------------------------added user list--------------------------
	 public function assess_reports($centerid) 
	 { 
		if($centerid!=''){$where="academic_center_id=".$centerid;}else{$where="'1=1'";}
			$query = $this->multipledb->saasap->query('select u.fname,u.lname,u.username,c.classname,u.creation_date,acm.id as centerid,u.is_direct_brainyuser,u.program_status,s1.skillscore_M as skillscorem, skillscore_V as skillscorev,skillscore_F as skillscoref,skillscore_P as skillscorep,skillscore_L as skillscorel, a3.finalscore as avgbspiset1,COALESCE(a3.playedcount,0) as playcount from users u join academic_center_master acm on u.academic_center_id=acm.id join class c on c.id=u.grade_id   

			left join 
			 (SELECT SUM(score)/5 as finalscore, count(gu_id) as playedcount, gu_id, (SELECT sid from users where id=gu_id) as schoolid from (select (AVG(score)) as score, gu_id, gs_id from (SELECT (AVG(`game_score`)) as score , gs_id , gu_id, lastupdate FROM `game_reports` WHERE gs_id in (59,60,61,62,63) and gu_id in (select id from users) group by gs_id , gu_id, lastupdate) a1 group by gs_id, gu_id ) a2 group by gu_id) a3   on a3.gu_id=u.id 
			 
			 left join
			(select (AVG(score)) as skillscore_M, gu_id from (SELECT (AVG(`game_score`)) as score , gs_id , gu_id, lastupdate FROM `game_reports` WHERE gs_id =59 and gu_id in (select id from users) group by gs_id , gu_id, lastupdate) a1 group by gs_id, gu_id) s1 on s1.gu_id=u.id 

			left join
			(select (AVG(score)) as skillscore_V, gu_id from (SELECT (AVG(`game_score`)) as score , gs_id , gu_id, lastupdate FROM `game_reports` WHERE gs_id =60 and gu_id in (select id from users) group by gs_id , gu_id, lastupdate) a1 group by gs_id, gu_id) s2 on s2.gu_id=u.id 

			left join
			(select (AVG(score)) as skillscore_F, gu_id from (SELECT (AVG(`game_score`)) as score , gs_id , gu_id, lastupdate FROM `game_reports` WHERE gs_id =61 and gu_id in (select id from users) group by gs_id , gu_id, lastupdate) a1 group by gs_id, gu_id) s3 on s3.gu_id=u.id 

			left join
			(select (AVG(score)) as skillscore_P, gu_id from (SELECT (AVG(`game_score`)) as score , gs_id , gu_id, lastupdate FROM `game_reports` WHERE gs_id =62 and gu_id in (select id from users) group by gs_id , gu_id, lastupdate) a1 group by gs_id, gu_id) s4 on s4.gu_id=u.id 

			left join
			(select (AVG(score)) as skillscore_L, gu_id from (SELECT (AVG(`game_score`)) as score , gs_id , gu_id, lastupdate FROM `game_reports` WHERE gs_id =63 and gu_id in (select id from users) group by gs_id , gu_id, lastupdate) a1 group by gs_id, gu_id) s5 on s5.gu_id=u.id 

			where u.isnewuser="Y"  and acm.status=1 and c.status=1 and academic_center_id!=0  and '.$where.' order BY creation_date desc '); 
			//echo $this->multipledb->saasap->last_query(); exit;
			return $query->result_array(); 
	} 

	public function username_check($usrname) 
	{
			$query = $this->multipledb->saasap->query('SELECT count(username) as usercount 	from users where username='.$this->multipledb->ba->escape($usrname).''); 
			return $query->result_array();
	}
	
	 public function brainy_directunamecheck_username_check($brainydirectusrname) 
	 {
		
			$query = $this->multipledb->saasap->query('SELECT count(username) as usercount from users where username='.$this->multipledb->ba->escape($brainydirectusrname).' and isapp="N"'); 
			return $query->result_array();
	 } 
		
	 public function update_username($usrname,$usrid)
	 {
			$query = $this->multipledb->saasap->query("update users set username=".$this->multipledb->ba->escape($usrname).",program_status='CLP',isapp='N' where username=".$this->multipledb->ba->escape($usrid)."");	
		
		//echo 'INSERT INTO users (salt1,password,salt2,fname,lname,status,gp_id,grade_id,username,sid,section,academicyear,creation_date,agreetermsandservice,portal_type,academic_center_id,isapp,isnewuser) select  sba.salt1,sba.password,sba.salt2,sba.fname,sba.lname,sba.status,sba.gp_id,sba.grade_id,sba.username,sba.sid,sba.section,sba.academicyear,sba.creation_date,sba.agreetermsandservice,sba.academic_center_id,sba.isapp,sba.isnewuser from '.$this->config->item("asapdb").'.users sba where sba.username='.$this->multipledb->ba->escape($usrname).''; exit;
		
			$query = $this->multipledb->ba->query('INSERT INTO users (salt1,password,salt2,fname,lname,status,gp_id,grade_id,username,sid,section,academicyear,creation_date,agreetermsandservice,portal_type,academic_center_id,isapp,isnewuser,startdate,enddate,visible) select  sba.salt1,sba.password,sba.salt2,sba.fname,sba.lname,sba.status,sba.gp_id,sba.grade_id,sba.username,sba.sid,sba.section,20 as academicyear,sba.creation_date,sba.agreetermsandservice,sba.program_status,sba.academic_center_id,"Y" as isapp,sba.isnewuser,'.$this->multipledb->ba->escape(date('Y-m-d')).',DATE_ADD('.$this->multipledb->ba->escape(date('Y-m-d')).',INTERVAL 6 MONTH),1 from '.$this->config->item("asapdb").'.users sba where sba.username='.$this->multipledb->ba->escape($usrname).'');	 
	}

	public function move_brainyuser_toclp($brainyusrid)
	{
			$query = $this->multipledb->saasap->query("update users set program_status='CLP' where username=".$this->multipledb->ba->escape($brainyusrid)."");	
		
			$query = $this->multipledb->ba->query('INSERT INTO users (salt1,password,salt2,fname,lname,status,gp_id,grade_id,username,sid,section,academicyear,creation_date,agreetermsandservice,portal_type,academic_center_id,isapp,isnewuser,startdate,enddate,visible) select  sba.salt1,sba.password,sba.salt2,sba.fname,sba.lname,sba.status,sba.gp_id,sba.grade_id,sba.username,sba.sid,sba.section,20 as academicyear,sba.creation_date,sba.agreetermsandservice,sba.program_status,sba.academic_center_id,"Y" as isapp,sba.isnewuser,'.$this->multipledb->ba->escape(date('Y-m-d')).',DATE_ADD('.$this->multipledb->ba->escape(date('Y-m-d')).',INTERVAL 6 MONTH),1 from '.$this->config->item("asapdb").'.users sba where sba.username='.$this->multipledb->ba->escape($brainyusrid).'');
	}	
	
	public function checkLicenseAvailability_asap($proid,$centerid)
	{
			$query = $this->multipledb->ba->query('SELECT id,(select 	COALESCE(sum(licensecount),0) from  license_count where centerid=a.id and product_id='.$this->multipledb->ba->escape($proid).') as givenlicence,(select count(*) from '.$this->config->item("asapdb").'.users where academic_center_id=a.id and status=1 and isnewuser="Y") as usedlicense from academic_center_master a where status=1 and isdemo=0 and id='.$this->multipledb->ba->escape($centerid).' ORDER BY givenlicence DESC');
		//echo $this->multipledb->ba->last_query(); exit; 
		return $query->result_array();			
	}
	public function checkLicenseAvailability_clp($proid,$centerid)
	{
			$query = $this->multipledb->ba->query('SELECT id,(select COALESCE(sum(licensecount),0) from  license_count where centerid=a.id and product_id='.$this->multipledb->ba->escape($proid).') as givenlicence,(select count(*) from users where academic_center_id=a.id and status=1 and isnewuser="Y") as usedlicense from academic_center_master a where status=1 and isdemo=0 and id='.$this->multipledb->ba->escape($centerid).' ORDER BY givenlicence DESC');
			//echo $this->multipledb->ba->last_query(); exit; 
			return $query->result_array();			
	}
	public function getUserReportCard($username)
	{ 
			$query = $this->multipledb->saasap->query("SELECT id,fname,username, grade_id,sid,school_name,section,gradename,schoolname,
			(SELECT COALESCE((AVG(game_score)),0) as score FROM game_reports WHERE gs_id =59 and gu_id=mu.id) as skillscorem,
			(SELECT COALESCE((AVG(game_score)),0) as score FROM game_reports WHERE gs_id =60 and gu_id=mu.id) as skillscorev,
			(SELECT COALESCE((AVG(game_score)),0) as score FROM game_reports WHERE gs_id =61 and gu_id=mu.id) as skillscoref,
			(SELECT COALESCE((AVG(game_score)),0) as score FROM game_reports WHERE gs_id =62 and gu_id=mu.id) as skillscorep,
			(SELECT COALESCE((AVG(game_score)),0) as score FROM game_reports WHERE gs_id =63 and gu_id=mu.id) as skillscorel,
			(SELECT COALESCE((SUM(game_score)/5),0) as score FROM game_reports WHERE gs_id in(59,60,61,62,63) and gu_id=mu.id) as avgbspiset1
			from
			(SELECT id, fname,username, grade_id,sid,school_name,section,(select classname from class where id=grade_id) as gradename,(select school_name from schools where id=sid) as schoolname from users as u where u.username=".$this->multipledb->ba->escape($username).") as mu ");
			return $query->result_array();
	}
		
}

 

