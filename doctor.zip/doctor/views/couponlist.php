 <div class="right_col" role="main">
<div class="col-md-12 col-sm-12 col-xs-12">
<div class="x_panel tile" style="min-height: 280px;">
<div class="x_title">
<h2 class="reporttitle">Coupon List</h2>
<div class="clearfix"></div>
</div>
<div class="clearfix"></div>
<?php foreach($couponlist as $res) { ?>
<div class="animated flipInY col-lg-3 col-md-3 col-sm-3 col-xs-12">
		<div class="tile-stats">
			<div class="toppart" style="background-color: #337ab7;color:#fff">
			<div class="icon"><i class="fa fa-credit-card"></i></div>
				<div class="count"><?php echo $res['couponcode']; ?></div>
				<div class="footerpart">
				<p class="pull-left">Status :</p><span class="pull-right"><?php if($res['usedstatus']=='N') { ?>Available <?php }
				else if($res['usedstatus']=='Y') { ?>Used <?php } ?></span>
			</div>
				
			</div>
		</div>
</div>
<?php } ?>
</div>
</div>
        </div>	
		

<link href="<?php echo base_url(); ?>assets/css/jquery.dataTables.css" rel="stylesheet" type="text/css">
<link href="<?php echo base_url(); ?>assets/css/dataTables.tableTools.css" rel="stylesheet" type="text/css">
<script src="<?php echo base_url(); ?>assets/js/jquery.min.js" type="text/javascript"></script>
<script src="<?php echo base_url(); ?>assets/js/jquery.dataTables.js" type="text/javascript"></script>
<script src="<?php echo base_url(); ?>assets/js/dataTables.tableTools.js" type="text/javascript"></script>
<script>
$('#assementTable').DataTable( {
	
	"lengthMenu": [[10,  -1], [10,  "All"]],
"scrollX": true
})
</script>
<style>
.reporttitle { color:#1abb9c; }
thead{ background-color: #1abb9c; color: #fff;}
</style>
