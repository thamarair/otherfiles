  
<option value="">Select your Grade</option>
  <?php foreach($gradeinfo as $res) { ?> 
					<option value="<?php echo $res['gradeid']; ?>" data-planid="<?php echo $res['planid']; ?>" ><?php echo $res['gradename']; ?></option>
				<?php } ?>