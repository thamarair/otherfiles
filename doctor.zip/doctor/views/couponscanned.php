 <div class="right_col" role="main">
<div class="row">
<div class="col-md-12 col-sm-12 col-xs-12">
<div class="x_panel tile">
<div class="x_title">
<h2 class="reporttitle">Coupons Scanned</h2>
<div class="clearfix"></div>
<div class="clearfix"></div>
</div>
<div class="clearfix"></div>
  
	<table id="assementTable" class="table table-striped table-bordered table-hover table-condensed">
    <thead>
      <tr>
        <th>S.No.</th>
        <th>Scanned Coupon - QR Value</th>
        <th>Date on scanned</th>
        <th>Program</th>
        <th>Grade</th>
        <th>Payment mode</th>
        <th>Status</th>

		 
      </tr>
    </thead>
    <tbody>
	<?php 
	$ini=0; 
 
	foreach($query as $couponscanned){
	$ini++;
	?>	
      <tr>
        <td><?php echo $ini; ?></td>
		<td><?php echo $couponscanned['qrcode'];  ?></td>
		<td><?php echo $couponscanned['scandate'];  ?></td>
		<td><?php echo $couponscanned['programname']; ?> </td>
		<td><?php echo str_replace("Grade","", $couponscanned['gradename']);  ?></td>
		<td><?php if($couponscanned['paymentmode']=='C'){echo "Cash";} else {echo "Online Payment";}  ?></td>
		<td><?php if($couponscanned['usedstatus']=='Y'){echo "Registered";} else {echo "Yet to register";}  ?></td>


 
		
      </tr>
	<?php } ?>
      
	  
    </tbody>
 
  </table>
	
</div>
</div>
</div>
</div>		
		

<link href="<?php echo base_url(); ?>assets/css/jquery.dataTables.css" rel="stylesheet" type="text/css">
<link href="<?php echo base_url(); ?>assets/css/dataTables.tableTools.css" rel="stylesheet" type="text/css">
<script src="<?php echo base_url(); ?>assets/js/jquery.min.js" type="text/javascript"></script>
<script src="<?php echo base_url(); ?>assets/js/jquery.dataTables.js" type="text/javascript"></script>
<script src="<?php echo base_url(); ?>assets/js/dataTables.tableTools.js" type="text/javascript"></script>
<script>
$('#assementTable').DataTable( {
	
	"lengthMenu": [[10,  -1], [10,  "All"]],
	//"scrollX": true
})
</script>
<style>
.reporttitle { color:#1abb9c; }
thead{ background-color: #1abb9c; color: #fff;}
</style>
