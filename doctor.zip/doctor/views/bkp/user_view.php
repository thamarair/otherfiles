<style>
.counter {width: 16%; background: yellowgreen; padding: 9px; margin: 2px; color:black;  }
.counterinnertxt { font-size: 15px; font-weight: bold; color: cornsilk;}
</style>
<div class="right_col" role="main">
          <div class="">
           
            
            <div class="clearfix"></div>

            <div class="row">
              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>User Report</h2>
                  
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                    <div class="col-md-3 col-sm-3 col-xs-12 profile_left" style="background: aliceblue;">
                      <div class="profile_img">
                        <div id="crop-avatar">
                          <!-- Current avatar -->
						 <?php  if($getasapinfo[0]['avatarimage']==""){$getasapinfo[0]['avatarimage']="assets/images/avatar.png";} 
  if(file_exists(APPPATH."../assets/".$getasapinfo[0]['avatarimage'])=='false')
   {$getasapinfo[0]['avatarimage']="assets/images/avatar.png";}else{$getasapinfo[0]['avatarimage']=$getasapinfo[0]['avatarimage'];} ?>
                          <img class="img-responsive avatar-view" src="<?php echo base_url(); ?><?php echo $getasapinfo[0]['avatarimage']; ?>" alt="Avatar" title="Change the avatar">
                        </div>
                      </div>
                      <h3><?php echo $getasapinfo[0]['fname']; ?></h3>

                      <ul class="list-unstyled user_data">
					  <li>
					  <?php if($getasapinfo[0]['gender']=='M') {  ?>
					  <i class="fa fa-male"></i> Male
					<?php   } ?>
					<?php if($getasapinfo[0]['gender']=='F') {  ?>
					  <i class="fa fa-female"></i> Female
					<?php   } ?>
					  
					  <?php 
					  $dateOfBirth = $getasapinfo[0]['dob'];
					  $today = date("Y-m-d");
					  $diff = date_diff(date_create($dateOfBirth), date_create($today));
					  ?>
					   <li><i class="fa fa-birthday-cake"></i> <?php echo $getasapinfo[0]['dob']; ?>, Age - <?php echo $diff->format('%y'); ?>
                        </li>
						
                        <li><i class="fa fa-map-marker user-profile-icon"></i> <?php echo $getasapinfo[0]['address']; ?>, <?php echo $getasapinfo[0]['city']; ?>, <?php echo $getasapinfo[0]['statename']; ?>
                        </li>

                        <li>
                          <i class="fa fa-mobile-phone"></i> <?php echo $getasapinfo[0]['mobile']; ?>
                        </li>

                        <li class="m-top-xs">
                          <i class="fa fa-envelope-o"></i>
                          <a href="javascript:;" target="_blank"><?php echo $getasapinfo[0]['email']; ?></a>
                        </li>
						
						 <li class="m-top-xs">
                          <i class="fa fa-user"></i>
                          Parent / Guardian - <?php echo $getasapinfo[0]['parentname']; ?>
                        </li>
						
						
						 <li class="m-top-xs">
                          <i class="fa fa-calendar-o"></i>
                         <?php echo date('d-m-Y', strtotime($getasapinfo[0]['startdate'])); ?>  -  <?php echo date('d-m-Y', strtotime($getasapinfo[0]['enddate'])); ?>
                        </li>
						
						 <li class="m-top-xs">
                          <i class="fa fa-file-code-o"></i>
                         Coupon code - <?php echo $getasapinfo[0]['couponcode']; ?>
                        </li>
                      </ul>

                      <br />


                    </div>
                    <div class="col-md-9 col-sm-9 col-xs-12">
                        <div class="" role="tabpanel" data-example-id="togglable-tabs">
                        <ul id="myTab" class="nav nav-tabs bar_tabs" role="tablist">
                          <li role="presentation" class="active col-md-4 col-sm-4 col-xs-12"><a href="#tab_content1" id="home-tab" role="tab" data-toggle="tab" aria-expanded="true">Assessment</a>
                          </li>
                          <li role="presentation" class="col-md-4 col-sm-4 col-xs-12"><a href="#tab_content2" role="tab" id="profile-tab" data-toggle="tab" aria-expanded="false">Training</a>
                          </li>
                          <li role="presentation" class="col-md-4 col-sm-4 col-xs-12"><a href="#tab_content3" role="tab" id="profile-tab2" data-toggle="tab" aria-expanded="false">Assessment vs Training</a>
                          </li>
                        </ul>
                        <div id="myTabContent" class="tab-content">
                          <div role="tabpanel" class="tab-pane fade active in" id="tab_content1" aria-labelledby="home-tab">
                            <div class="">
								<div class="col-md-10">
								</div>
								<div class="col-md-2">
								  <h2 style="font-weight:700 !important; color:tomato;">BSPI : <?php echo round($asapbspi[0]['avgbspiset1'], 2); ?> </h2>
								</div>
							  </div>
							  <!-- start of user-activity-graph -->
							  <div id="container3" style="width:100%;"></div>
							  <!-- end of user-activity-graph -->
                          </div>
                          <div role="tabpanel" class="tab-pane fade" id="tab_content2" aria-labelledby="profile-tab">
						
							  <!-- start of user-activity-graph -->
							  <div class="col-md-12" style="text-align: center;">
							  <div class="col-md-2 counter">Minutes Trained<br/><span class="counterinnertxt"><?php echo $getcounters[0]['gtime_school_count']; ?></span></div>
							  <div class="col-md-2 counter">Puzzles Attempted<br/><span class="counterinnertxt"><?php echo $getcounters[0]['attempted_question_count']; ?></span></div>
							   <div class="col-md-2 counter">Puzzles Solved<br/><span class="counterinnertxt"><?php echo $getcounters[0]['answer_school_count']; ?></span></div>
							   <div class="col-md-2 counter">Crownies<br/><span class="counterinnertxt"><?php if($getcrowny[0]['points']!='') { echo $getcrowny[0]['points']; } else { echo '-'; } ?></span></div>
							   <div class="col-md-2 counter">Session Attempted<br/><span class="counterinnertxt"><?php echo $getattemptsession[0]['attempt']; ?></span></div>
							   <div class="col-md-2 counter">Session Completed<br/><span class="counterinnertxt"><?php echo $getcompsession[0]['comp']; ?></span></div>
							  </div><br/>
							<div class="">
								<div class="col-md-10">
								</div>
								<div class="col-md-2">
								  <h2 style="font-weight:700 !important; color:tomato;">BSPI : <?php echo round($clpbspi[0]['avgbspiset1'], 2); ?> </h2>
								</div>
							  </div>

							  <div id="clpchart" style="width:100%"></div>
                            <!-- end user projects -->
						
                          </div>
						  
						  
                          
						  <div role="tabpanel" class="tab-pane fade" id="tab_content3" aria-labelledby="profile-tab">
                            <!--<div class="profile_title">
								<div class="col-md-6">
								  <h2>User Activity Report</h2>
								</div>
								<div class="col-md-6">
								  <div id="reportrange" class="pull-right" style="margin-top: 5px; background: #fff; cursor: pointer; padding: 5px 10px; border: 1px solid #E6E9ED">
									<i class="glyphicon glyphicon-calendar fa fa-calendar"></i>
									<span>December 30, 2014 - January 28, 2015</span> <b class="caret"></b>
								  </div>
								</div>
							  </div>-->
							  <!-- start of user-activity-graph -->
							  <div id="graph_bar" style="width:100%"></div>
							  <!-- end of user-activity-graph -->
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
		<?php 
$memory = round($set1avg_M, 2);
$visual = round($set1avg_V, 2);
$focus = round($set1avg_F, 2);
$problem = round($set1avg_P, 2);
$linguistics = round($set1avg_L, 2);

$memory_clp = round($CLP_M, 2);
$visual_clp = round($CLP_V, 2);
$focus_clp = round($CLP_F, 2);
$problem_clp = round($CLP_P, 2);
$linguistics_clp = round($CLP_L, 2);


$test = array("Memory"=>$memory, "Visual Processing"=>$visual, "Focus and Attention"=>$focus, "Problem Solving"=>$problem, "Linguistics"=>$linguistics);
arsort($test);

$clp_skills = array("Memory"=>$memory_clp, "Visual Processing"=>$visual_clp, "Focus and Attention"=>$focus_clp, "Problem Solving"=>$problem_clp, "Linguistics"=>$linguistics_clp);
arsort($clp_skills);
		?>
<script src="<?php echo base_url(); ?>assets/js/jquery.min.js" type="text/javascript"></script>
<script src="<?php echo base_url(); ?>assets/js/highcharts.js" type="text/javascript"></script>
		
		<script>
		$(document).ready(function(){
			skillwisechart();
			skillwisechart_clp();
		});
		
		Highcharts.chart('graph_bar', {
    chart: {
        type: 'column',
		backgroundColor:'transparent'
    },
	
	 title: {
            text: ''
        },
    
    xAxis: {
        categories: [
            'BSPI',
            'Memory',
            'Visual Processing',
            'Focus and Attention',
            'Problem Solving',
            'Linguistics'
           
        ],
        crosshair: true
    },
    yAxis: {
        min: 0,
        title: {
            text: 'Score'
        }
    },
    tooltip: {enabled: false},exporting:false,credits: {
      enabled: false
  },
    plotOptions: {
     
            column: {
                depth: 50,
    dataLabels: {
            enabled: true
        }
            }
        },
    series: [{
        name: 'Assessment',
		color:'#0b62bd',
        data: [<?php echo round($asapbspi[0]['avgbspiset1'], 2); ?>, <?php echo $memory; ?>, <?php echo $visual; ?>, <?php echo $focus; ?>, <?php echo $problem; ?>, <?php echo $linguistics; ?>]

    }, {
        name: 'Training',
		color:'#00bcd4',
        data: [<?php echo round($clpbspi[0]['avgbspiset1'], 2); ?>, <?php echo $memory_clp; ?>, <?php echo $visual_clp; ?>, <?php echo $focus_clp; ?>, <?php echo $problem_clp; ?>, <?php echo $linguistics_clp; ?>]

    }]
});
		
		/*  var chart = new Highcharts.Chart({
        chart: {
            renderTo: 'graph_bar',
            type: 'column',
   backgroundColor:'transparent'
             
        },
        title: {
            text: ''
        },
  tooltip: {enabled: false},exporting:false,credits: {
      enabled: false
  },
        subtitle: {
            text: ''
        },
   
  yAxis:{
    title: {
                text: 'Score'
            },
   max: 100 ,
  gridLineWidth: 0,
  minorGridLineWidth: 0
},
       xAxis:{ 
     categories: ['BSPI','Memory','Visual Processing','Focus and Attention','Problem Solving','Linguistics'],
    
  gridLineWidth: 0,
  minorGridLineWidth: 0
},
        plotOptions: {
     
            column: {
                depth: 50,
    dataLabels: {
            enabled: true
        }
            }
        },
        series: [{
 showInLegend: false, 
            data: [{y:<?php echo round($clpbspi[0]['avgbspiset1'], 2); ?>,color:'#da0404'},{y:<?php echo $memory_clp; ?>,color:'#da0404'}, {y:<?php echo $visual_clp; ?>,color:'#ffc000' },{y:<?php echo $focus_clp; ?>,color:'#92d050'},{y:<?php echo $problem_clp; ?>,color:'#ff6600'},{y:<?php echo $linguistics_clp; ?>,color:'#00b0f0'}]
        }]
    }); */
	
		 function skillwisechart()
 {

	 var chart3 = Highcharts.chart('container3', {

    chart: {
        type: 'bar',
		backgroundColor:'transparent'
	
	 
    },

    title: {
        text: ''
    },

    subtitle: {
        text: ''
    },
	tooltip: {enabled: true},exporting:false,credits: {
      enabled: false
  },

    xAxis: {
        categories: [<?php foreach($test as $key=>$value){ 
	 echo "'".$key."',";
		}
	?> ],
		gridLineWidth: 0,
  minorGridLineWidth: 0,
 /* labels: {
            style: {
                fontSize: '25px',
				color: '#FF6600',
				fontFamily: 'Phenomena-Regular'
            }
        } */
       
    },
  
    yAxis: {
        allowDecimals: false,
        title: {
            text: 'Score'
			/* style: {fontSize: '25px',color: '#000',fontFamily: 'Phenomena-Regular'} */
        },
		 max: 100 ,
  gridLineWidth: 0,
  minorGridLineWidth: 0,
 /* labels: {
            style: {
                fontSize: '20px',
				color: '#000',
				fontFamily: 'Phenomena-Regular'
            }
        } */
		
    },
	
 plotOptions: {
	  
    series: {
        dataLabels: {
            enabled: true,
			formatter: function() {
 
    var Greeting0='Needs Attention !!!';
    var Greeting1='Needs Improvement !!!';
    var Greeting2='Can Do Better !!!';
    var Greeting3='Average !!!';
    var Greeting4='Fair !!!';
    var Greeting5='Good !!!';
    var Greeting6='Very Good !!!';
    var Greeting7='Excellent !!!';
    var Greeting8='Extraordinary !!!';
    var Greeting9='Genius !!!';
    var Greeting10='Prodigy !!!';

    if(this.y<1){ return this.y +' - '+ Greeting0;}
    else if(this.y<11){ return this.y +' - '+ Greeting1;}
    else if(this.y<21){ return this.y +' - '+ Greeting2;}
    else if(this.y<31){ return this.y +' - '+ Greeting3;}
    else if(this.y<41){ return this.y +' - '+ Greeting4;}
    else if(this.y<51){ return this.y +' - '+ Greeting5;}
    else if(this.y<61){ return this.y +' - '+ Greeting6;}
    else if(this.y<71){ return this.y +' - '+ Greeting7;}
    else if(this.y<81){ return this.y +' - '+ Greeting8;}
    else if(this.y<91){ return this.y +' - '+ Greeting9;}
    else if(this.y<101){ return this.y +' - '+ Greeting10;}
	
	//return this.y;
   },
                        inside: true,
			style: {color: '#000', textShadow: false}
             
        }
    }
},	

   
    series: [
	
	{
		showInLegend: false,
        name:"Skill Wise Average",
        data: [<?php foreach($test as $key=>$value){  if($key=='Memory'){$color='#da0404';}
	else if($key=='Visual Processing'){$color='#ffc000';}
	else if($key=='Focus and Attention'){$color='#92d050';}
	else if($key=='Problem Solving'){$color='#ff6600';}
	else if($key=='Linguistics'){$color='#00b0f0';} echo'{y:'.$value.',color:"'.$color.'"},'; }?>]
	}
	 ] 

});
$('#loadingimage1').css("display", "none");
 }
 
  function skillwisechart_clp()
 {
	 
	 
	
	 var chart3 = Highcharts.chart('clpchart', {

    chart: {
        type: 'bar',
		backgroundColor:'transparent'
	
	 
    },

    title: {
        text: ''
    },

    subtitle: {
        text: ''
    },
	tooltip: {enabled: true},exporting:false,credits: {
      enabled: false
  },
	
			
	

    

    xAxis: {
        categories: [<?php foreach($clp_skills as $key=>$value){ 
	 echo "'".$key."',";
		}
	?> ],
		gridLineWidth: 0,
  minorGridLineWidth: 0,
  labels: {
         /*   style: {
                fontSize: '25px',
				color: '#FF6600',
				fontFamily: 'Phenomena-Regular'
            } */
        }
       
    },
  
    yAxis: {
        allowDecimals: false,
        title: {
            text: 'Score',
			/* style: {fontSize: '25px',color: '#000',fontFamily: 'Phenomena-Regular'} */
        },
		 max: 100 ,
  gridLineWidth: 0,
  minorGridLineWidth: 0,
  labels: {
          /*  style: {
                fontSize: '20px',
				color: '#000',
				fontFamily: 'Phenomena-Regular'
            } */
        }
		
    },
	
 plotOptions: {
	  
    bar: {
        dataLabels: {
            enabled: true,
			formatter: function() {
 
    var Greeting0='Needs Attention !!!';
    var Greeting1='Needs Improvement !!!';
    var Greeting2='Can Do Better !!!';
    var Greeting3='Average !!!';
    var Greeting4='Fair !!!';
    var Greeting5='Good !!!';
    var Greeting6='Very Good !!!';
    var Greeting7='Excellent !!!';
    var Greeting8='Extraordinary !!!';
    var Greeting9='Genius !!!';
    var Greeting10='Prodigy !!!';

    if(this.y<1){ return this.y +' - '+ Greeting0;}
    else if(this.y<11){ return this.y +' - '+ Greeting1;}
    else if(this.y<21){ return this.y +' - '+ Greeting2;}
    else if(this.y<31){ return this.y +' - '+ Greeting3;}
    else if(this.y<41){ return this.y +' - '+ Greeting4;}
    else if(this.y<51){ return this.y +' - '+ Greeting5;}
    else if(this.y<61){ return this.y +' - '+ Greeting6;}
    else if(this.y<71){ return this.y +' - '+ Greeting7;}
    else if(this.y<81){ return this.y +' - '+ Greeting8;}
    else if(this.y<91){ return this.y +' - '+ Greeting9;}
    else if(this.y<101){ return this.y +' - '+ Greeting10;}
   },
                        inside: true,
			style: {color: '#000', textShadow: false}
             
        }
    }
},	

   
    series: [
	
	{
		showInLegend: false,
        name:"Skill Wise Average",
        data: [<?php foreach($clp_skills as $key=>$value){  if($key=='Memory'){$color='#da0404';}
	else if($key=='Visual Processing'){$color='#ffc000';}
	else if($key=='Focus and Attention'){$color='#92d050';}
	else if($key=='Problem Solving'){$color='#ff6600';}
	else if($key=='Linguistics'){$color='#00b0f0';} echo'{y:'.$value.',color:"'.$color.'"},'; }?>]
	}
	 ] 

});
$('#loadingimage1').css("display", "none");
 }

		</script>