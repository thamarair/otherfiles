<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=yes">
<title>Edsix BrainLab</title>
<!-- Bootstrap -->

	<link href="<?php echo base_url(); ?>assets/css/bootstrap.min.css" rel="stylesheet">
    <link href="<?php echo base_url(); ?>assets/css/font-awesome.min.css" rel="stylesheet">
    <link href="<?php echo base_url(); ?>assets/css/nprogress.css" rel="stylesheet">
    <link href="<?php echo base_url(); ?>assets/css/animate.min.css" rel="stylesheet">
    <link href="<?php echo base_url(); ?>assets/css/custom.min.css" rel="stylesheet">
<style>
.login_content form input[type=text], .login_content form input[type=email], .login_content form input[type=password]
{
	margin-bottom: 10px;
}
.ed6 {
    color: rgb(0, 170, 255);
    font-family: "Shadows Into Light",cursive;
    font-size: 2em;
}
.LoginContainer
{
	    BORDER: 2px solid;
    width: 50%;
    margin-left: 25%;
}
.submitlabel{padding-top:20px;padding-bottom:20px;}
.LoginContainer .fields{text-align:right;}
footer {
    margin-left: 0px !important;
	 color: #73879C;
}
input
{	 color: #73879C;
}
.landingContainer{padding-bottom:20px;}
body {
        //background:#73879C;
        background:#26b99a;
}
label.error {
    color: red;
    font-size: 15px;
    float: left;
}
label{float: left;}
</style>
</head>

<div class="login_wrapper">
	<div class="animate form login_form">
		 <div><img src="<?php echo base_url(); ?>assets/images/Edsix.png" style="width: 55%; margin-right: 1%; margin-bottom: 0.5em;margin-left: 60px;" alt="..." class="" />
		<!--  <img src="<?php echo base_url(); ?>assets/images/Bris01.png" style="width: 45%; margin-right: 1%; margin-bottom: 0.5em;" alt="..." class="" />--></div>
		<section class="login_content">
            <form action="" class="cmxform" method="POST" id="frmchangepwd" name="frmchangepwd" accept-charset="utf-8">
              <h1>Reset Password</h1>
			  <?php if($response!=''){ ?>
				<h3 style="color:green;text-align: center;padding: 0px 0px 100px;"><?php echo $response;?></h3>
				<?php }else{ ?> 
              <div><label for="txtOPassword">Password <span style="color:red">*</span></label>
                <input type="password" placeholder="Minimum 8 characters" class="form-control" maxlength="20" name="txtOPassword" value="" id="txtOPassword">
              </div>
              <div><label for="txtCPassword">Confirm Password <span style="color:red">*</span></label>
				<input type="password" placeholder="Minimum 8 characters" class="form-control" maxlength="20" name="txtCPassword" value="" id="txtCPassword">
              </div>
              <div style="clear:both;">
                <input type="submit" class="btn btn-success" style="float:right;" id="submit" name="submit" value="Submit">
              </div>            
				<?php } ?>
		   </form>
          </section>
	</div>
</div>
		 
<!--modal-->
			<script src="<?php echo base_url(); ?>assets/js/jquery.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/bootstrap.min.js"></script>
	<script src="<?php echo base_url(); ?>assets/js/jquery.validate.js"></script>
<script type="text/javascript">
$(document).ready(function() {
	$("#frmchangepwd").validate({
		rules: {
			"txtOPassword": {required: true,minlength: 8},
			"txtCPassword": {required: true,equalTo: "#txtOPassword"}
		},
		messages: {
			"txtOPassword": {required: "Please enter password"},
			"txtCPassword": {required: "Please confirm password",equalTo: "Please enter valid confirm password"}
		},
		errorPlacement: function(error, element) {
		if (element.attr("type") === "radio") {
			error.insertAfter(element.parent().parent());
		} 
		else {
			error.insertAfter(element);
		}
	}
	});
	$("#btnpwd").click(function(){
		if($("#frmFP").valid())
		{ alert($("#txtemail").val());
			$(".loadingimg").show();
			$.ajax({
				url: "<?php echo base_url(); ?>index.php/home/resetpwdlink", 
				type:'POST',
				data:{email:$("#txtemail").val()},
				success: function(result)
				{
					if(result==1)
					{
						$("#txtemail").attr('readonly', 'readonly');
						$("#msgFP").css("margin-bottom","10px").html("<div style='color:green'>Check your mailbox for the reset password activation link</div>");
					}
					else
					{	
						$("#msgFP").css("margin-bottom","10px").html("<div style='color:red'>Please enter the registered email id</div>");
					}
					$(".loadingimg").hide();
				}
			});
		}
	});
}); 
</script>