
        <div class="right_col" role="main">
          <!-- top tiles -->
   <div class="loading" style="display:none;" ><img src="<?php echo base_url(); ?>assets/images/ajax-page-loader.gif" style="width:80px;" /></div>       
<!-- /top tiles -->
<div class="row">

<div class="col-md-6 col-sm-6 col-xs-6">
<div class="x_panel tile" style="min-height: 500px;">
<div class="x_title">
<h2 class="reporttitle">Dashboard</h2>
<div class="clearfix"></div>
</div>
<div class="clearfix"></div>
<div class="row">
	<div class="animated flipInY col-lg-6 col-md-6 col-sm-6 col-xs-12">
		<div class="tile-stats">
		<a href="<?php echo base_url(); ?>index.php/home/couponscanned">
			<div class="toppart" style="background-color: #ffa500;color:#fff">
			<div class="icon"><i class="fa fa-users"></i></div>
				<div class="count" id="couponscanned"></div>
				<h4>Coupons Scanned</h4>
			</div>
			<div class="footerpart">
				<p class="pull-left">View Details</p><span class="pull-right"><i style="color:#26b99a" class="fa fa-arrow-circle-right"></i></span>
			</div></a>
		</div>
		 
	</div>
<div class="animated flipInY col-lg-6 col-md-6 col-sm-6 col-xs-12">
		<div class="tile-stats">
			<a href="<?php echo base_url(); ?>index.php/home/userslist">
			<div class="toppart" style="background-color: #ffa500;color:#fff">
			<div class="icon"><i class="fa fa-users"></i></div>
				<div class="count"><?php echo $userscount[0]['total']; ?></div>
				<h4>Children</h4>
			</div>
			
			<div class="footerpart">
				<p class="pull-left">View Details</p><span class="pull-right"><i style="color:#26b99a" class="fa fa-arrow-circle-right"></i></span>
			</div></a>    
	</div>
</div>
</div>

<div class="row">
<div class="animated flipInY col-lg-12 col-md-12 col-sm-12 col-xs-12">
<form name="frmqrcode" id="qrcode" class="" method="POST"  >

<div class="row">
	<div class="col-lg-6">
	  <div class="form-group">	  
		<label for="txtqrcode">Scan QR Value<span style="color:red">*</span></label>
		<input type="text" maxlength="8"  class="form-control alphaOnly" name="txtqrcode" value="" id="txtqrcode" />		
	  </div> 
  </div> 
  
  <div class="col-lg-6">
	  <div class="form-group">
			<label for="ddlprogram" id="ddlpgm" name="ddlpgm">Program<span style="color:red">*</span></label>
			<select class="form-control"  name="ddlprogram" id="ddlprogram">
				<option value="">Select</option>
				 <?php foreach($programname as $res) { ?> 
					<option value="<?php echo $res['id']; ?>"  ><?php echo $res['program_name']; ?></option>
				<?php } ?> 				 
			</select>
	</div>
</div>
<div class="col-lg-6">
	  <div class="form-group">
			<label for="ddlgrade" name="ddlclassname" id="ddlclassname">Grade<span style="color:red">*</span></label> 
		<select class="form-control"  name="ddlgrade" id="ddlgrade" >
				<option value="">Select</option>
				 
			</select>
	</div>
</div>

<div class="col-lg-6">
	  <div class="form-group">			 
		<label for="rdPaymentmode">Payment Mode<span style="color:red"> *</span></label>
			<div class=""> 
				<div class="col-sm-4"><label class="radio-inline "><input type="radio" class="rdPaymentmode"   name="rdPaymentmode" value="C" id="rdC">Cash</label></div>
				<div class="col-sm-8"><label class="radio-inline ">
				<input type="radio" class="rdPaymentmode"    name="rdPaymentmode" value="OP" id="rdOp">Online Payment</label></div>
			</div>
	</div> 
</div>
</div>

 <div class="row">
  <div class="col-lg-6" style="margin-top: 21px;">
	  <div class="form-group">
		<input type="button" id="btnactivate" style="float:none;" class="btn btn-success btnactivate" value="Activate">
	  </div> 	  
	  </div> 
  </div>
  
 </form>
</div>
<div id="successmsg" style="color: green; text-align: center;"></div>
</div>

   
</div>
</div>

<div class="col-md-6 col-sm-6 col-xs-12">
<div class="x_panel tile" style="min-height: 280px;">
<div class="x_title">
<h2 class="reporttitle">Profile</h2>
<div class="clearfix"></div>
</div>
<div class="clearfix"></div>

<div class="col-md-6 col-sm-6 col-xs-12 profile_left">
                     
                      <h3><?php echo $doctorinfo[0]['doctorname'];  ?></h3>
                      <ul class="list-unstyled user_data">
					<li><i class="fa fa-birthday-cake"></i> <?php echo $doctorinfo[0]['dateofbirth'];  ?></li>
                        <li><i class="fa fa-map-marker user-profile-icon"></i> <?php echo $doctorinfo[0]['address'];  ?>, <?php echo $doctorinfo[0]['city'];  ?>, <?php echo $doctorinfo[0]['statename'];  ?></li>
                        <li><i class="fa fa-mobile-phone"></i> <?php echo $doctorinfo[0]['mobilenumber'];  ?> <?php if($doctorinfo[0]['secondarymobilenumber']!='') {  echo " / ". $doctorinfo[0]['secondarymobilenumber'];   } ?></li>
                        <li>
                          <i class="fa fa-envelope-o"></i> <?php echo $doctorinfo[0]['email'];  ?> <?php if($doctorinfo[0]['secondaryemail']!='') {  echo " / ". $doctorinfo[0]['secondaryemail'];   } ?>
                        </li>
						<?php if($doctorinfo[0]['hospitalname']!=''){ ?>
							<li><i class="fa fa-hospital-o"></i> <?php echo $doctorinfo[0]['hospitalname'];  ?></li>
						<?php } ?>
                      </ul>
                    </div>
					
					<div class="col-md-6 col-sm-6 col-xs-12 profile_left">
						<?php if($doctorinfo[0]['profileimage']!=''){ ?>
                       <img src="<?php echo base_url(); ?><?php echo $doctorinfo[0]['profileimage'];  ?>" class="img-responsive avatar-view" style="width:100px; height:100px;" alt="profile image"  />
						<?php } ?>
                    </div>
					<br/>
					<div class="col-xs-12 col-sm-6 emphasis" style="padding: 10px;">
                              <a href="<?php echo base_url(); ?>index.php/home/doctoredit/" target="_blank" class="btn btn-success btn-xs">
                                <i class="fa fa-edit"> </i> Edit Details
                              </a>
                            </div>
					

</div>
</div>
</div>
	</div> 
<link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/jquery-ui.css">	
<script src="<?php echo base_url(); ?>assets/js/jquery-2.2.0.min.js" type="text/javascript"></script>
<script src="<?php echo base_url(); ?>assets/js/jquery.min.js" type="text/javascript"></script>
<script src="<?php echo base_url(); ?>assets/js/jquery.validate.js"></script> 
<script>	 
	$(document).ready(function(){
	couponcounts();
	});
	
	
	/* $('#regsubmit').click(function(){
		//alert('true');$("#hdnusrid").val($(this).attr('data-username'));
		//alert('true');$("#hdnusrid").val($(this).attr('data-planid'));
		var usrid = $("#hdnusrid").val();
		var planid = $("#hdnusrid").val();$('#the_id').data('original-title');
		
		if($("#frmRegister").valid()==true)
		{ */
	
	//added new fields
	$('#btnactivate').click(function()
	{  
		if($("#qrcode").valid())
		{        
			var qrcode = $('#txtqrcode').val();
			var doctorid = '<?php echo $this->session->doctorid; ?>';
			var program_name = $('#ddlprogram').val();
			var gradename = $('#ddlgrade').val();
			var planid = $('#ddlgrade option:selected').data('planid');//alert(planid);
			var paymentmode = $("input[name='rdPaymentmode']:checked").val();
			$('.loading').show();
			$.ajax({
				type:"POST",
				url:"<?php echo base_url('index.php/api/checkqrcode') ?>",
				data:{qrcode:qrcode,doctorid:doctorid,program_name:program_name,gradename:gradename,paymentmode:paymentmode,planid:planid},
				success:function(result)
					{
						//alert(result);
						$('.loading').hide();						
						$("#successmsg").html(result);
						setTimeout(function () {location.reload();	}, 2000);
						//couponcounts();
					}
				});
		}      
});
	 
	
		function couponcounts()
		{
			$.ajax({
				type:"POST",
				dataType: "json",
				url:"<?php echo base_url('index.php/home/couponcounts') ?>",
				data:{},
				success:function(result)
				{
				//alert(result);
				$("#couponscanned").html(result);
				}
			});
		}
	
	/*------list grade based on program click--------*/
			$('#ddlprogram').change(function()
			{
			//alert("hiiii");
				var ddlpgm = $(this).val();
				$.ajax({
					type:"POST",
					url:"<?php echo base_url('index.php/home/gradeinfo') ?>",  
					data:{programname:$('#ddlprogram').val()},
					success:function(result)
					{
					//alert(result);
						$("#ddlgrade").html(result);
					}
				});	 
			});
	/*------list grade based on program click--------*/
	 
	
	
	</script>
	<style>
	
	.loading {
  position: fixed;
  z-index: 999;
  height: 2em;
  width: 2em;
  overflow: show;
  margin: auto;
  top: 0;
  left: 0;
  bottom: 0;
  right: 0;
}
.loading:before {
  content: '';
  display: block;
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background-color: rgba(0,0,0,0.3);
}
	</style>
   