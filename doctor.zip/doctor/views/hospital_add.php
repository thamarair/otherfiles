 <div class="right_col" role="main">
<div class="row">
<div class="col-md-12 col-sm-12 col-xs-12">
<div class="x_panel tile">
<div class="x_title">
<h2 class="reporttitle">Add Hospital</h2>

<div class="clearfix"></div>
</div>
<div class="clearfix"></div>

	<div id="mainContDisp" class="container playGames homePlayGames" style="margin-top:20px;margin-bottom:70px;"> 

<form name="frmRegister" id="frmRegister" class="" method="post"  action="<?php echo base_url(); ?>index.php/home/inserthospital"  accept-charset="utf-8"  >
 <div class="row">
    <div class="col-lg-12 txtclr">
	<div style="padding-top:5px;">
      <div class="">
      <h3>Please fill the details below : </h3>
	  <?php if(isset($msg)){?> <div class="msg"><?php echo $msg; ?> </div><?php } ?>
	  <span style="float:right;"><label><span style="color:red">*</span> Required fields
	  </label></span>
	 
  </div>
  </div>
  </div>
</div>
<div class="row">
		<div class="col-lg-6">
      <div class="form-group">
    <label for="txtHName">Hospital Name <span style="color:red">*</span></label>
    <input type="text" maxlength="100" class="form-control" name="txtHName" value=""  id="txtHName">
  </div> 
  </div>
  <div class="col-lg-6">
  <div class="form-group">
    <label for="txtcode">Code <span style="color:red">*</span></label>
    <input type="text" maxlength="10"  class="form-control" name="txtcode" value="" id="txtcode">
  </div> 
  </div>
    </div>
	
	<div class="row">
		<div class="col-lg-6">
  <div class="form-group">
    <label for="txtMobile">Phone Number 1<span style="color:red">*</span></label>
	 <div class="input-group">
          <span class="input-group-addon" id="idmobileCode">+91</span>
    <input placeholder="" type="text" class="form-control numbersOnly" maxlength="15" name="txtMobile" value="" id="txtMobile">
        </div>
  </div>
    </div>
	<div class="col-lg-6">
 <div class="form-group">
    <label for="txtSMobile">Phone Number 2</label>
	 <div class="input-group">
          <span class="input-group-addon" id="idmobileCode">+91</span>
    <input placeholder="" type="text" class="form-control numbersOnly" maxlength="15" name="txtSMobile" value="" id="txtSMobile">
        </div>
  </div>
    </div></div>

	<div class="row">
	<div class="col-lg-6">
  <div class="form-group">
    <label for="txtEmail">Email ID 1<span style="color:red">*</span></label>
    <input type="text" maxlength="200" class="form-control" name="txtEmail" value="" id="txtEmail">
	<label id='errEmail' class="error"></label>
  </div>
    </div>
	<div class="col-lg-6">
  <div class="form-group">
    <label for="txtSEmail">Email ID 2</label>
    <input type="text" maxlength="200" class="form-control" name="txtSEmail" value="" id="txtSEmail">
  </div>
    </div> </div>
	
	 
	
	<div class="row">
	<div class="col-lg-6">
  <div class="form-group">
    <label for="ddlState">State<span style="color:red">*</span></label>
<select class="form-control"  name="ddlState" id="ddlState">
<option value="">Select</option>
<?php foreach($getstate as $res) { ?> 
<option value="<?php echo $res['id']; ?>"><?php echo $res['state_name']; ?></option>
<?php } ?>


</select>  

</div>
    </div>
	<div class="col-lg-6">
  <div class="form-group">
    <label for="txtCity">City <span style="color:red">*</span></label>
    	<input class="form-control alphaOnly" type="text" maxlength="255" name="txtCity" id="txtCity"/>
    	
  </div>
    </div></div>	
	<div class="row">
	<div class="col-lg-6">
  <div class="form-group">
    <label for="txtAddress">Address <span style="color:red">*</span></label>
	<textarea class="form-control"  name="txtAddress" id="txtAddress"></textarea>
  </div>
    </div>
	
	<div class="col-lg-6">
  <div class="form-group">
    <label for="txtCity">Contact Person <span style="color:red">*</span></label>
    	<input class="form-control alphaonly" type="text" maxlength="255" name="txtcontactperson" id="txtcontactperson"/>
    	
  </div>
    </div></div>
	<div class="row">
	<div class="col-lg-6">
  <div class="form-group">
    <label for="txtMobile">Status <span style="color:red">*</span></label>
    <div class=""> 
       <div class="col-sm-3"><label class="radio-inline"><input type="radio" class=""  name="txtstatus" value="1" id="rdGM">Active</label></div>
    <div class="col-sm-3"><label class="radio-inline"><input type="radio" class=""  name="txtstatus" value="0" id="rdGF">In Active</label></div>
	</div>
  </div>
	</div></div>
	<div class="row>"
	
	<div style="text-align:center;clear:both;">
   <input type="submit" id="btnRegisterSubmit" name="btnRegisterSubmit" style="float:none;" class="btn btn-success" value="Submit">
   <input type="reset"  id="frmreset" class="btn btn-waring">
</div>
</div>
	
</div>
</div>
</div>
</div>		
		 </form>


<link href="<?php echo base_url(); ?>assets/css/jquery.dataTables.css" rel="stylesheet" type="text/css">
<link href="<?php echo base_url(); ?>assets/css/dataTables.tableTools.css" rel="stylesheet" type="text/css">
<script src="<?php echo base_url(); ?>assets/js/jquery.min.js" type="text/javascript"></script>
<script src="<?php echo base_url(); ?>assets/js/jquery.dataTables.js" type="text/javascript"></script>
<script src="<?php echo base_url(); ?>assets/js/dataTables.tableTools.js" type="text/javascript"></script>

<script src="<?php echo base_url(); ?>assets/js/jquery.validate.js"></script> 
<script type="text/javascript">

$('.numbersOnly').keyup(function () { 
    this.value = this.value.replace(/[^0-9]/g,'');
});

$('.alphaOnly').keyup(function () { 
    this.value = this.value.replace(/[^a-zA-Z ]/g,'');
});

$.validator.addMethod('filesize', function(value, element, param) {
    return this.optional(element) || (element.files[0].size <= param) 
}); 

 $('#txtPassword').bind("cut copy paste",function(e) {
     e.preventDefault();
 });
  $('#txtCPassword').bind("cut copy paste",function(e) {
     e.preventDefault();
 }); $('#txtEmail').bind("cut copy paste",function(e) {
     e.preventDefault();
 });
  $('#txtSEmail').bind("cut copy paste",function(e) {
     e.preventDefault();
 });
 
 $("#frmRegister").validate({
        rules: {
            "txtHName": {required: true,minlength: 3},
			 "txtcode": {required: true},
			"txtEmail": {required: true,email: true},
			"txtSEmail": {email: true},
			
            "txtMobile": {required: true,minlength: 10},
			"txtSMobile": {minlength: 10},
            "txtstatus": {required: true},
            "ddlState": {required: true},
            "txtCity": {required: true},
             "txtAddress": {required: true},
			/* "txtUID":{accept: "png|jpe?g|pdf", filesize: 1048576*4}, */
            "txtcontactperson": {required: true,minlength: 3},
            "ddlpreferred_channel": {required: true}
        },
        messages: {
            "txtHName": {required: "Please enter hospital name"},
			"txtcode": {required: "Please enter hospital code"},
			"txtEmail": {required: "Please enter email",email: "Please enter valid email"},
			"txtSEmail": {email: "Please enter valid email"},
            "txtstatus": {required: "Please select status"},
			"txtMobile": {required:"Please enter phone number",minlength:"Please enter valid phone number" },
			"txtSMobile": {minlength:"Please enter valid phone number" },
          
            "ddlState": {required: "Please select state"},
            "txtCity": {required: "Please enter city"},
            "txtAddress": {required: "Please enter hospital address"},
			/* "txtUID":{accept: "Please upload files only in the format of PNG, JPEG or PDF", filesize: "Please upload file size only upto 4MB"}, */
            "txtcontactperson": {required: "Please enter contact person"},
            "ddlpreferred_channel": {required: "Please select most watched channel"}
        },
		errorPlacement: function(error, element) {
    if (element.attr("type") === "radio") {
        error.insertAfter(element.parent().parent());
    } 
	else if (element.attr("id") === "txtMobile") {
        error.insertAfter(element.parent());
    } 
	
	else if (element.attr("id") === "txtSMobile") {
        error.insertAfter(element.parent());
    } 
	else {
        error.insertAfter(element);
    }
	
},
		highlight: function(input) {
            $(input).addClass('error');
        } 
    });
	
	
	
 
 
</script>
<style>
.reporttitle { color:#1abb9c; }
thead{ background-color: #1abb9c; color: #fff;}
.error {color:red;}
</style>

