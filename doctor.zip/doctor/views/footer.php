<footer>
          <div class="pull-right">
            Copyright © <?php echo date("Y"); ?> Edsix BrainLab Pvt Ltd. All rights reserved.
          </div>
          <div class="clearfix"></div>
        </footer>
        <!-- /footer content -->
     

	<script src="<?php echo base_url(); ?>assets/js/jquery.min.js"></script>
	<script src="<?php echo base_url(); ?>assets/js/jquery.validate.js"></script> 
    <script src="<?php echo base_url(); ?>assets/js/bootstrap.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/fastclick.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/nprogress.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/Chart.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/gauge.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/bootstrap-progressbar.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/icheck.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/skycons.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/jquery.flot.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/jquery.flot.pie.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/jquery.flot.time.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/jquery.flot.stack.js"></script>
	<script src="<?php echo base_url(); ?>assets/js/jquery.flot.resize.js"></script>
	

    <script src="<?php echo base_url(); ?>assets/js/jquery.flot.orderBars.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/jquery.flot.spline.min.js"></script>
	<script src="<?php echo base_url(); ?>assets/js/curvedLines.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/date.js"></script>
	
	<script src="<?php echo base_url(); ?>assets/js/jquery.vmap.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/jquery.vmap.world.js"></script>
	<script src="<?php echo base_url(); ?>assets/js/jquery.vmap.sampledata.js"></script>
	
    <script src="<?php echo base_url(); ?>assets/js/moment.min.js"></script>
	<script src="<?php echo base_url(); ?>assets/js/daterangepicker.js"></script>
		 
	<script src="<?php echo base_url(); ?>assets/js/custom.js"></script>
	
	<script src="<?php echo base_url(); ?>assets/js/moment.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/fullcalendar.min.js"></script>
	<!-- FullCalendar -->
    <link href="<?php echo base_url(); ?>assets/css/fullcalendar.min.css" rel="stylesheet">
    <link href="<?php echo base_url(); ?>assets/css/fullcalendar.print.css" rel="stylesheet" media="print">
	
	<script src="<?php echo base_url(); ?>assets/js/jquery.dataTables.js" type="text/javascript"></script>
	<script src="<?php echo base_url(); ?>assets/js/dataTables.tableTools.js" type="text/javascript"></script>
	
	
	
	<script type="text/javascript">
		$( document ).ready(function() {
			
			setInterval(LoginAjaxCall, 1000*60*1); //300000 MS == 5 minutes
			LoginAjaxCall();

			$("#calview").click(function() {
				$("#tableview").hide();
				$("#chartview").hide();
				$("#calendarview").show();
				$("#todayfilter").show();
			});
			$("#tblview").click(function() {
				$("#tableview").show();
				$("#chartview").hide();
				$("#calendarview").hide();
				$("#todayfilter").show();
			});
			$("#chview").click(function() {
				$("#tableview").hide();
				$("#chartview").show();
				$("#calendarview").hide();
				$("#todayfilter").show();
			});
		});
		
		
		//-----------home.php => validation for newfields
		$("#qrcode").validate({
        rules: {
            "txtqrcode": {required: true},
			"ddlprogram": {required: true},
			"ddlgrade": {required: true},
			"rdPaymentmode": {required: true}            
			},
        messages: {
            "txtqrcode": {required: "Please enter QR Code"},
			"ddlprogram": {required: "Please select program name"},
			"ddlgrade": {required: "Please select grade"},
            "rdPaymentmode": {required: "Please choose paymentmode"}			 
        },
		errorPlacement: function(error, element) {
    if (element.attr("type") === "radio") {
        error.insertAfter(element.parent().parent().parent());
    } 
	else if (element.attr("id") === "rdPaymentmode") {
        error.insertAfter(element.parent());
    } 
	
	else if (element.attr("id") === "ddlgrade") {
        error.insertAfter(element.parent());
    } 
	else {
        error.insertAfter(element);
    }
	
},
		highlight: function(input) {
           // $(input).addClass('error');
        } 
    }); 
		//-----------home.php => validation for newfields
		
		function LoginAjaxCall(){ 		
		$.ajax({
			type:"POST",
			url:"<?php echo base_url('index.php/home/checkuserisactive') ?>",
			success:function(result)
			{	//alert(result);
			///	if(result==1)
			//	{ 
					
			//		window.location.href= "<?php echo base_url();?>index.php";
			//	}		
			}
		});
		}
		
	</script>
	 </div>
    </div>
  </body>
</html>

<style>
.dateinfo .count{font-size:20px;color:#337ab7;font-weight: bold;display:block;padding-left:20px;}
.dateinfo .count_top{font-size:15px;font-weight: bold;}
.toppart h4{padding:0px; margin:0 0 0 10px;}
.footerpart .fa-arrow-circle-right{color: #f60;}
.footerpart{background: #f3f1f1;overflow: hidden;}
.tile-stats .icon i{font-size:40px;}
.tile-stats .icon{right: 30px;top: 10px;}
.error {color:red;}
</style>

		