<style>
@media (min-width:1025px) {.counter {width: 16%;}}
@media (min-width:1281px) {.counter {width: 16%;}}
.counter {background:#32b8cd; padding: 9px; margin: 2px; color:black;  }
.counterinnertxt { font-size: 15px; font-weight: bold; color: cornsilk;}
</style>
<div class="right_col" role="main">
          <div class="">
           
            
            <div class="clearfix"></div>

            <div class="row">
              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>User Report</h2>
                  
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                    <div class="col-md-3 col-sm-3 col-xs-12 profile_left" style="background: #32b8cd;color: #fff;">
                      <div class="profile_img" style="margin: 0 auto;width: 100px;padding-top: 10px;">
                        <div id="crop-avatar">
                          <!-- Current avatar -->
						 <?php  if($getasapinfo[0]['avatarimage']==""){$getasapinfo[0]['avatarimage']="assets/images/avatar.png";} 
  if(file_exists(APPPATH."../assets/".$getasapinfo[0]['avatarimage'])=='false')
   {$getasapinfo[0]['avatarimage']="assets/images/avatar.png";}else{$getasapinfo[0]['avatarimage']=$getasapinfo[0]['avatarimage'];} ?>
                          <img class="img-responsive avatar-view" src="<?php echo base_url(); ?><?php echo $getasapinfo[0]['avatarimage']; ?>" alt="Avatar" title="Change the avatar">
                        </div>
                      </div>
                      <h3><?php echo $getasapinfo[0]['fname']; ?></h3>

                      <ul class="list-unstyled user_data">
					  <li>
					  <?php if($getasapinfo[0]['gender']=='M') {  ?>
					  <i class="fa fa-male"></i> Male
					<?php   } ?>
					<?php if($getasapinfo[0]['gender']=='F') {  ?>
					  <i class="fa fa-female"></i> Female
					<?php   } ?>
					  </li>
					  <?php 
					  $dateOfBirth = $getasapinfo[0]['dob'];
					  $today = date("Y-m-d");
					  $diff = date_diff(date_create($dateOfBirth), date_create($today));
					  ?>
					   <li><i class="fa fa-birthday-cake"></i> <?php echo $getasapinfo[0]['dob']; ?>, Age - <?php echo $diff->format('%y'); ?>
                        </li>
						
                        <li><i class="fa fa-map-marker user-profile-icon"></i> <?php echo $getasapinfo[0]['address']; ?>, <?php echo $getasapinfo[0]['city']; ?>, <?php echo $getasapinfo[0]['statename']; ?>
                        </li>

                        <li>
                          <i class="fa fa-mobile-phone"></i> <?php echo $getasapinfo[0]['mobile']; ?>
                        </li>

                        <li class="m-top-xs">
                          <i class="fa fa-envelope-o"></i>
                          <a href="javascript:;" style="color:#fff;"><?php echo $getasapinfo[0]['email']; ?></a>
                        </li>
						
						 <li class="m-top-xs">
                          <i class="fa fa-user"></i>
                          Parent / Guardian - <?php echo $getasapinfo[0]['parentname']; ?>
                        </li>
						
						
						 <li class="m-top-xs">
                          <i class="fa fa-calendar-o"></i>
                         <?php echo date('d-m-Y', strtotime($getasapinfo[0]['startdate'])); ?>  -  <?php echo date('d-m-Y', strtotime($getasapinfo[0]['enddate'])); ?>
                        </li>
						
						<li class="m-top-xs">
                          Child Type  -   <select style="color:#000;" name="patienttype" class="" id="patienttype">
						  <option value="">Select</option>  
	 <?php foreach($patienttype as $res)
	 { ?> 
	<option value="<?php echo $res['id']; ?>" <?php if($getasapinfo[0]['patient_type']==$res['id']) { ?> selected="selected" <?php } ?> > <?php echo $res['type']; ?></option>  		  		 
	<?php } ?>
      </select>
                        </li>
						<li id="successmsg" style="color: green; font-weight: 700;"></li>
						
                      </ul>

                      <br />


                    </div>
                    <div class="col-md-9 col-sm-9 col-xs-12">
                        <div class="" role="tabpanel" data-example-id="togglable-tabs">
                        <ul id="myTab" class="nav nav-tabs bar_tabs" role="tablist" style="margin:0">
                          <li role="presentation" class="active col-md-4 col-sm-4 col-xs-12"><a href="#tab_content1" id="asap-tab" role="tab" data-toggle="tab" aria-expanded="true">Assessment</a>
                          </li>
                          <li role="presentation" class="col-md-4 col-sm-4 col-xs-12"><a href="#tab_content2" role="tab" id="training-tab" data-toggle="tab" aria-expanded="false">Training</a>
                          </li>
                          <li role="presentation" class="col-md-4 col-sm-4 col-xs-12"><a href="#tab_content3" role="tab" id="clp_asap_tab" data-toggle="tab" aria-expanded="false">Assessment vs Training</a>
                          </li>
                        </ul>
                        <div id="myTabContent" class="tab-content">
                          <div role="tabpanel" class="tab-pane fade active in" id="tab_content1" aria-labelledby="home-tab">
                            <div class="">
								<div class="col-md-10">
								</div>
								<div class="col-md-2">
								  <h2 style="font-weight:700 !important; color:#4765ff;">BSPI : <?php echo round($asapbspi[0]['avgbspiset1'], 2); ?> </h2>
								</div>
							  </div>
							  
							  
							  
							<div class="col-12 col-md-12 col-sm-12 col-xs-12">
							  <div id="container3"></div></div>
							  <!-- end of user-activity-graph -->
                          </div>
                          <div role="tabpanel" class="tab-pane fade" id="tab_content2" aria-labelledby="profile-tab">
						  
						  <?php if($getasapinfo[0]['portal_type']=='ASAP') { ?> 
						  <h2> Training Not Yet Started </h2>
						  <?php } else { ?>
 						
							  <!-- start of user-activity-graph -->
							  <div class="col-md-12" style="text-align: center;">
							  <div class="col-md-2 col-xs-12 counter">Minutes Trained<br/><span class="counterinnertxt"><?php echo $getcounters[0]['gtime_school_count']; ?></span></div>
							  <div class="col-md-2 col-xs-12 counter">Puzzles Attempted<br/><span class="counterinnertxt"><?php echo $getcounters[0]['attempted_question_count']; ?></span></div>
							   <div class="col-md-2 col-xs-12 counter">Puzzles Solved<br/><span class="counterinnertxt"><?php echo $getcounters[0]['answer_school_count']; ?></span></div>
							   <div class="col-md-2 col-xs-12 counter">Crownies<br/><span class="counterinnertxt"><?php if($getcrowny[0]['points']!='') { echo $getcrowny[0]['points']; } else { echo '-'; } ?></span></div>
							   <div class="col-md-2 col-xs-12 counter">Session Attempted<br/><span class="counterinnertxt"><?php echo $getattemptsession[0]['attempt']; ?></span></div>
							   <div class="col-md-2 col-xs-12 counter">Session Completed<br/><span class="counterinnertxt"><?php echo $getcompsession[0]['comp']; ?></span></div>
							  </div><br/>
							<div class="">
								<div class="col-md-10">
								</div>
								<div class="col-md-2">
								  <h2 style="font-weight:700 !important; color:#4765ff;">BSPI : <?php echo round($clpbspi[0]['avgbspiset1'], 2); ?> </h2>
								</div>
								
								
							  </div>
							  <!---inner-->
							
							   <div class="" role="tabpanel" data-example-id="togglable-tabs">
                        <ul id="myTab1" class="nav nav-tabs bar_tabs" role="tablist">
                          <li role="presentation" class="active col-md-2 col-sm-2 col-xs-12"><a style="font-size: 12px;" href="#tab_content11" id="asap-tab1" role="tab" data-toggle="tab" aria-expanded="true">Skill Performance</a>
                          </li>
                          <li role="presentation" class="col-md-2 col-sm-2 col-xs-12"><a style="font-size: 12px;" href="#tab_content21" role="tab" id="training-tab1" data-toggle="tab" aria-expanded="false">Efficiency Graph</a>
                          </li>
                           
                        </ul>
						
						</div>
						
						<div id="myTabContent1" class="tab-content">
                          <div role="tabpanel" class="tab-pane fade active in" id="tab_content11" aria-labelledby="home-tab">
                            <div class="col-12 col-md-12 col-sm-12 col-xs-12">
 							  <div id="clpchart"></div>
							  </div>
							  
							  

                          </div>
						  
						   <div role="tabpanel" class="tab-pane fade" id="tab_content21" aria-labelledby="home-tab">
                             
							  
							  <div class="col-12 col-md-12 col-sm-12 col-xs-12">
 							  <div id="EfficiencyGraphChart"></div>
							  </div>

                          </div>
						  
						  </div>
							  <!--inner-->
                            <!-- end user projects -->
						  </div>
						  
						  
                          
						  <div role="tabpanel" class="tab-pane fade" id="tab_content3" aria-labelledby="profile-tab">
							  <div class="col-12 col-md-12 col-sm-12 col-xs-12">
							  <div id="graph_bar"></div>
							  </div>
                          </div><?php } ?>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
		<?php 
		
		$categories=''; 
foreach($academicmonths as $months){ 
	   $categories.="'".$months['monthName']."-".$months['yearNumber']."',";
 }
 
$memory = round($set1avg_M, 2);
$visual = round($set1avg_V, 2);
$focus = round($set1avg_F, 2);
$problem = round($set1avg_P, 2);
$linguistics = round($set1avg_L, 2);

$memory_clp = round($CLP_M, 2);
$visual_clp = round($CLP_V, 2);
$focus_clp = round($CLP_F, 2);
$problem_clp = round($CLP_P, 2);
$linguistics_clp = round($CLP_L, 2);


$test = array("Memory"=>$memory, "Visual Processing"=>$visual, "Focus and Attention"=>$focus, "Problem Solving"=>$problem, "Linguistics"=>$linguistics);
arsort($test);

$clp_skills = array("Memory"=>$memory_clp, "Visual Processing"=>$visual_clp, "Focus and Attention"=>$focus_clp, "Problem Solving"=>$problem_clp, "Linguistics"=>$linguistics_clp);
arsort($clp_skills);
		?>
<script src="<?php echo base_url(); ?>assets/js/jquery.min.js" type="text/javascript"></script>
<script src="<?php echo base_url(); ?>assets/js/highcharts.js" type="text/javascript"></script>
		
		<script>
		$(document).ready(function(){
			skillwisechart();
			//skillwisechart_clp();
			//skillwisechart_asap_clp();
		});
		
		
		
		$('#patienttype').change(function(){
			var typeid = $(this).val();
			var userid = '<?php echo $this->uri->segment(3); ?>';
		$.ajax({
type:"POST",
url:"<?php echo base_url('index.php/home/update_patienttype') ?>",
data:{typeid:typeid,userid:userid},
success:function(result)
{
//alert(result);
if(result==1)
{
	$("#successmsg").html("Updated Successfully");
}
}
});
		});
		
		$('#asap-tab').click(function(){
		skillwisechart();
		});
		
		$('#training-tab').click(function(){
		skillwisechart_clp();
		EfficiencyGraphChart();
		});
		
		$('#clp_asap_tab').click(function(){
		skillwisechart_asap_clp();
		});
		
		 function skillwisechart_asap_clp()
 {
		Highcharts.chart('graph_bar', {
    chart: {
        type: 'column',
		backgroundColor:'transparent'
    },
	
	 title: {
            text: ''
        },
    
    xAxis: {
        categories: [
            'BSPI',
            'Memory',
            'Visual Processing',
            'Focus and Attention',
            'Problem Solving',
            'Linguistics'
           
        ],
        crosshair: true
    },
    yAxis: {
        min: 0,
        title: {
            text: 'Score'
        }
    },
    tooltip: {enabled: false},exporting:false,credits: {
      enabled: false
  },
    plotOptions: {
     
            column: {
                depth: 50,
    dataLabels: {
            enabled: true
        }
            }
        },
    series: [{
        name: 'Assessment',
		color:'#0b62bd',
        data: [<?php echo round($asapbspi[0]['avgbspiset1'], 2); ?>, <?php echo $memory; ?>, <?php echo $visual; ?>, <?php echo $focus; ?>, <?php echo $problem; ?>, <?php echo $linguistics; ?>]

    }, {
        name: 'Training',
		color:'#00bcd4',
        data: [<?php echo round($clpbspi[0]['avgbspiset1'], 2); ?>, <?php echo $memory_clp; ?>, <?php echo $visual_clp; ?>, <?php echo $focus_clp; ?>, <?php echo $problem_clp; ?>, <?php echo $linguistics_clp; ?>]

    }]
});

 }
 
 function EfficiencyGraphChart()
{
    var chart = new Highcharts.Chart({
        chart: {
            renderTo: 'EfficiencyGraphChart',
            type: 'column',
    },
    title: {
        text: ''
    },
    subtitle: {
        text: ''
    },
    xAxis: {
        categories: [<?php echo rtrim($categories,',');?>],
        crosshair: true
    },
    yAxis: {
		gridLineWidth: 0,
		minorGridLineWidth: 0,
        min: 0,
        title: {
            text: ''
        }
    },
    tooltip: {
        headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
        pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
            '<td style="padding:0"><b>{point.y:.1f}</b></td></tr>',
        footerFormat: '</table>',
        shared: true,
        useHTML: true
    },
    plotOptions: {
        column: {
            dataLabels: {
                enabled: true,
                crop: false,
                overflow: 'none'
            }
        }
    },exporting:false,
	credits: {
      enabled: false
  },
    series: [
		{ 	showInLegend: true,
			name: 'BSPI',
			color: '#ff6600',
            data: [<?php $ini=0; foreach($academicmonths as $months){
				$ini++;
				if($ini>1){echo ",";}
				if(isset($Uscore[$months['monthNumber'].$months['yearNumber'].'-S'])){
				echo "".$Uscore[$months['monthNumber'].$months['yearNumber'].'-S']."";
				}
				else{echo "0";}
			} ?>]
        },
		{	showInLegend: true, 
			name: 'Played Days',
			color: '#77bdff',
            data: [<?php $ini=0; foreach($academicmonths as $months){
				$ini++;
				if($ini>1){echo ",";}
				if(isset($Utime[$months['monthNumber'].$months['yearNumber'].'-T'])){
				echo "".round($Utime[$months['monthNumber'].$months['yearNumber'].'-T'])."";
				}
				else{echo "0";}
			} ?>]
        }]
});
}
		

		 function skillwisechart()
 {

	 var chart3 = Highcharts.chart('container3', {

    chart: {
        type: 'bar',
		backgroundColor:'transparent'
	
	 
    },

    title: {
        text: ''
    },

    subtitle: {
        text: ''
    },
	tooltip: {enabled: true},exporting:false,credits: {
      enabled: false
  },

    xAxis: {
        categories: [<?php foreach($test as $key=>$value){ 
	 echo "'".$key."',";
		}
	?> ],
		gridLineWidth: 0,
  minorGridLineWidth: 0,
 /* labels: {
            style: {
                fontSize: '25px',
				color: '#FF6600',
				fontFamily: 'Phenomena-Regular'
            }
        } */
       
    },
  
    yAxis: {
        allowDecimals: false,
        title: {
            text: 'Score'
			/* style: {fontSize: '25px',color: '#000',fontFamily: 'Phenomena-Regular'} */
        },
		 max: 100 ,
  gridLineWidth: 0,
  minorGridLineWidth: 0,
 /* labels: {
            style: {
                fontSize: '20px',
				color: '#000',
				fontFamily: 'Phenomena-Regular'
            }
        } */
		
    },
	
 plotOptions: {
	  
    series: {
        dataLabels: {
            enabled: true,
			formatter: function() {
 
    var Greeting0='Needs Attention !!!';
    var Greeting1='Needs Improvement !!!';
    var Greeting2='Can Do Better !!!';
    var Greeting3='Average !!!';
    var Greeting4='Fair !!!';
    var Greeting5='Good !!!';
    var Greeting6='Very Good !!!';
    var Greeting7='Excellent !!!';
    var Greeting8='Extraordinary !!!';
    var Greeting9='Genius !!!';
    var Greeting10='Prodigy !!!';

    if(this.y<1){ return this.y +' - '+ Greeting0;}
    else if(this.y<11){ return this.y +' - '+ Greeting1;}
    else if(this.y<21){ return this.y +' - '+ Greeting2;}
    else if(this.y<31){ return this.y +' - '+ Greeting3;}
    else if(this.y<41){ return this.y +' - '+ Greeting4;}
    else if(this.y<51){ return this.y +' - '+ Greeting5;}
    else if(this.y<61){ return this.y +' - '+ Greeting6;}
    else if(this.y<71){ return this.y +' - '+ Greeting7;}
    else if(this.y<81){ return this.y +' - '+ Greeting8;}
    else if(this.y<91){ return this.y +' - '+ Greeting9;}
    else if(this.y<101){ return this.y +' - '+ Greeting10;}
	
	//return this.y;
   },
                        inside: true,
			style: {color: '#000', textShadow: false}
             
        }
    }
},	

   
    series: [
	
	{
		showInLegend: false,
        name:"Skill Wise Average",
        data: [<?php foreach($test as $key=>$value){  if($key=='Memory'){$color='#da0404';}
	else if($key=='Visual Processing'){$color='#ffc000';}
	else if($key=='Focus and Attention'){$color='#92d050';}
	else if($key=='Problem Solving'){$color='#ff6600';}
	else if($key=='Linguistics'){$color='#00b0f0';} echo'{y:'.$value.',color:"'.$color.'"},'; }?>]
	}
	 ] 

});
$('#loadingimage1').css("display", "none");
 }
 
  function skillwisechart_clp()
 {
	 
	 
	
	 var chart3 = Highcharts.chart('clpchart', {

    chart: {
        type: 'bar',
		backgroundColor:'transparent'
	
	 
    },

    title: {
        text: ''
    },

    subtitle: {
        text: ''
    },
	tooltip: {enabled: true},exporting:false,credits: {
      enabled: false
  },
	
			
	

    

    xAxis: {
        categories: [<?php foreach($clp_skills as $key=>$value){ 
	 echo "'".$key."',";
		}
	?> ],
		gridLineWidth: 0,
  minorGridLineWidth: 0,
  labels: {
         /*   style: {
                fontSize: '25px',
				color: '#FF6600',
				fontFamily: 'Phenomena-Regular'
            } */
        }
       
    },
  
    yAxis: {
        allowDecimals: false,
        title: {
            text: 'Score',
			/* style: {fontSize: '25px',color: '#000',fontFamily: 'Phenomena-Regular'} */
        },
		 max: 100 ,
  gridLineWidth: 0,
  minorGridLineWidth: 0,
  labels: {
          /*  style: {
                fontSize: '20px',
				color: '#000',
				fontFamily: 'Phenomena-Regular'
            } */
        }
		
    },
	
 plotOptions: {
	  
    bar: {
        dataLabels: {
            enabled: true,
			formatter: function() {
 
    var Greeting0='Needs Attention !!!';
    var Greeting1='Needs Improvement !!!';
    var Greeting2='Can Do Better !!!';
    var Greeting3='Average !!!';
    var Greeting4='Fair !!!';
    var Greeting5='Good !!!';
    var Greeting6='Very Good !!!';
    var Greeting7='Excellent !!!';
    var Greeting8='Extraordinary !!!';
    var Greeting9='Genius !!!';
    var Greeting10='Prodigy !!!';

    if(this.y<1){ return this.y +' - '+ Greeting0;}
    else if(this.y<11){ return this.y +' - '+ Greeting1;}
    else if(this.y<21){ return this.y +' - '+ Greeting2;}
    else if(this.y<31){ return this.y +' - '+ Greeting3;}
    else if(this.y<41){ return this.y +' - '+ Greeting4;}
    else if(this.y<51){ return this.y +' - '+ Greeting5;}
    else if(this.y<61){ return this.y +' - '+ Greeting6;}
    else if(this.y<71){ return this.y +' - '+ Greeting7;}
    else if(this.y<81){ return this.y +' - '+ Greeting8;}
    else if(this.y<91){ return this.y +' - '+ Greeting9;}
    else if(this.y<101){ return this.y +' - '+ Greeting10;}
   },
                        inside: true,
			style: {color: '#000', textShadow: false}
             
        }
    }
},	

   
    series: [
	
	{
		showInLegend: false,
        name:"Skill Wise Average",
        data: [<?php foreach($clp_skills as $key=>$value){  if($key=='Memory'){$color='#da0404';}
	else if($key=='Visual Processing'){$color='#ffc000';}
	else if($key=='Focus and Attention'){$color='#92d050';}
	else if($key=='Problem Solving'){$color='#ff6600';}
	else if($key=='Linguistics'){$color='#00b0f0';} echo'{y:'.$value.',color:"'.$color.'"},'; }?>]
	}
	 ] 

});
$('#loadingimage1').css("display", "none");
 }

		</script>