 <div class="right_col" role="main">
<div class="row">
<div class="col-md-12 col-sm-12 col-xs-12">
<div class="x_panel tile">
<div class="x_title">
<h2 class="reporttitle">Child Performance</h2>
<!--<a href="<?php echo base_url(); ?><?php echo $filename; ?>" class="btn btn-success" style="float: right;margin-bottom: 10px;" >Download</a>-->
<a href="javascript:;" class="btn btn-success" id="downloadcsv" style="float: right;margin-bottom: 10px;" >Download</a>
<div class="clearfix"></div>
<div class="clearfix"></div>
</div>
<div class="clearfix"></div>
<?php 

		/* foreach($asap_reports as $key1=>$val1) {
			
			$query1[$asap_reports[$key1]['username']] =  $val1;
	
		}		
		foreach($clp_reports as $key2=>$val2) {
			
			$query2[$clp_reports[$key2]['username']] =  $val2;

		} */
		
?>
	<table id="assementTable" class="table table-striped table-bordered table-hover table-condensed">
    <thead>
      <tr>
        <th>S.No.</th>
        <th>First Name</th>
        <th>Last Name</th>
		<th>Email ID</th>
        <th>Mobile Number</th>
		<th>Parent Name</th>
		<th>Child Type</th>
        
	<!--	<th>Baseline - BSPI</th>
		<th>CEP - BSPI</th>
		<th>Program Status</th>	-->
       
      </tr>
    </thead>
    <tbody>
	<?php 
	$ini=0; 
	foreach($clp_reports as $row){
	$ini++;
	?>	
      <tr>
        <td><?php echo $ini; ?></td>
		<td class="fname"><?php echo $row['fname'];  ?></td>
		<td><?php echo $row['lname'];  ?></td>
		<td><?php echo $row['username'];  ?></td>
		<td><?php echo $row['mobile'];  ?></td>
		<td><?php echo $row['parentname'];  ?></td>
		<td><?php echo $row['patienttype'];  ?></td>
		
		
	<!--	<td><?php if($val3['avgbspiset1']=='') {  echo '-'; } else { echo round($val3['avgbspiset1'], 2);  } ?> 
		<a class="asap" style="float:right" href="javascript:;" data-target="#pwdModal" data-toggle="modal" data-info="<table><tr><td>Memory &nbsp;&nbsp;</td><td>&nbsp;&nbsp;<?php if($val3['skillscorem']=='') {  echo '-'; } else { echo round($val3['skillscorem'], 2);  }  ?></td></tr><tr><td>Visual Processing &nbsp;&nbsp;</td><td>&nbsp;&nbsp;<?php if($val3['skillscorev']=='') {  echo '-'; } else { echo round($val3['skillscorev'], 2);  } ?></td></tr><tr><td>Focus and Attention &nbsp;&nbsp;</td><td>&nbsp;&nbsp;<?php if($val3['skillscoref']=='') {  echo '-'; } else { echo round($val3['skillscoref'], 2);  } ?></td></tr><tr><td>Problem Solving &nbsp;&nbsp;</td><td>&nbsp;&nbsp;<?php if($val3['skillscorep']=='') {  echo '-'; } else { echo round($val3['skillscorep'], 2);  } ?></td></tr><tr><td>Linguistics &nbsp;&nbsp;</td><td>&nbsp;&nbsp;<?php if($val3['skillscorel']=='') {  echo '-'; } else { echo round($val3['skillscorel'], 2);  } ?></td></tr></table>"><i class="fa fa-info"></i></a>
		</td>
		
		
		<td><?php if($query2[$key3]['avgbspiset1']=='') {  echo '-'; } else { echo round($query2[$key3]['avgbspiset1'], 2); } ?>
		<a class="clp" style="float:right" href="javascript:;" data-target="#pwdModal" data-toggle="modal" data-info="<table><tr><td>Memory &nbsp;&nbsp;</td><td>&nbsp;&nbsp;<?php if($query2[$key3]['skillscorem']=='') {  echo '-'; } else { echo round($query2[$key3]['skillscorem'], 2); } ?></td></tr><tr><td>Visual Processing &nbsp;&nbsp;</td><td>&nbsp;&nbsp;<?php if($query2[$key3]['skillscorev']=='') {  echo '-'; } else { echo round($query2[$key3]['skillscorev'], 2); } ?></td></tr><tr><td>Focus and Attention &nbsp;&nbsp;</td><td>&nbsp;&nbsp;<?php if($query2[$key3]['skillscoref']=='') {  echo '-'; } else { echo round($query2[$key3]['skillscoref'], 2); }  ?></td></tr><tr><td>Problem Solving &nbsp;&nbsp;</td><td>&nbsp;&nbsp;<?php if($query2[$key3]['skillscorep']=='') {  echo '-'; } else { echo round($query2[$key3]['skillscorep'], 2); } ?></td></tr><tr><td>Linguistics &nbsp;&nbsp;</td><td>&nbsp;&nbsp;<?php if($query2[$key3]['skillscorel']=='') {  echo '-'; } else { echo round($query2[$key3]['skillscorel'], 2); }?></td></tr></table>"><i class="fa fa-info"></i></a>
		</td>
		<td><?php if($val3['playcount']==0) {  echo 'Assessment Yet to Start'; } else if($val3['playcount']<5) { echo 'Assessment In progress'; } else if($query2[$key3]['playcount']==0) { echo 'CEP Yet to Start'; } else if($query2[$key3]['playcount']<5) { echo 'CEP In progress'; } else if($query2[$key3]['playcount']==5) { echo 'CEP In progress'; } ?></td>-->
		
      </tr>
	<?php } ?>
      
	  
    </tbody>
  </table>
	
</div>
</div>
</div>
</div>		
		

<link href="<?php echo base_url(); ?>assets/css/jquery.dataTables.css" rel="stylesheet" type="text/css">
<link href="<?php echo base_url(); ?>assets/css/dataTables.tableTools.css" rel="stylesheet" type="text/css">
<script src="<?php echo base_url(); ?>assets/js/jquery.min.js" type="text/javascript"></script>
<script src="<?php echo base_url(); ?>assets/js/jquery.dataTables.js" type="text/javascript"></script>
<script src="<?php echo base_url(); ?>assets/js/dataTables.tableTools.js" type="text/javascript"></script>
<script>
$('#assementTable').DataTable( {
	"lengthMenu": [[10,  -1], [10,  "All"]],
	"fnDrawCallback": function (oSettings) {
		$('.asap').click(function(){
			$(".modaldata").html("");$(".modalheading").html("");
			$(".modalheading").html($(this).parent().siblings('td.fname').html()+" - Baseline Skill Score");	
			$(".modaldata").html($(this).attr("data-info"));
		});
		$('.clp').click(function(){
			$(".modaldata").html("");$(".modalheading").html("");
			$(".modalheading").html($(this).parent().siblings('td.fname').html()+" - CEP Skill Score");
			$(".modaldata").html($(this).attr("data-info"));
		});
	}
//"scrollX": true
});

$('#downloadcsv').click(function(){
		$.ajax({
type:"POST",
url:"<?php echo base_url('index.php/home/patientperformance_downloadcsv') ?>",
data:{},
success:function(result)
{
var s = result.replace(/\uploads/g, '');var res = s.replace(/\//g, '');
$("#downloadcsv").attr("download", res);
//alert(result);
window.location.href= "<?php echo base_url(); ?>"+ result +"";
}
});
		
	$('.asap').click(function(){
		//alert($(this).parent().siblings('td.fname').html());
		$(".modaldata").html("");$(".modalheading").html("");
		$(".modalheading").html($(this).parent().siblings('td.fname').html()+" - Baseline Skill Score");	
		$(".modaldata").html($(this).attr("data-info"));
	});
	$('.clp').click(function(){
		$(".modaldata").html("");$(".modalheading").html("");
		$(".modalheading").html($(this).parent().siblings('td.fname').html()+" - CEP Skill Score");
		$(".modaldata").html($(this).attr("data-info"));
	});
});
</script>
<style>
.reporttitle { color:#1abb9c; }
thead{ background-color: #1abb9c; color: #fff;}
body{ padding-right: 0px !important; }
body.modal-open { padding-right: 0px !important; }
.modal-content {width: 70%;margin: 0 auto;}
.modaldata table{margin: 0 auto;}
.modaldata td{text-align:justify;}
.modalheading{color: #0d77de;font-weight: bold;}
.panel-default{border-color: #5187bd;background: #3d6a96;color: #fff;}
</style>
