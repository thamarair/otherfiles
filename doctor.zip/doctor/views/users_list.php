 <div class="right_col" role="main">
          <div class="">
            <div class="page-title">
              <div class="title_left">
                <h3>Child List</h3>
              </div>
            </div>

            <div class="clearfix"></div>

            <div class="row">
              <div class="col-md-12">
			  <div class="loading" style="display:none;" ><img src="<?php echo base_url(); ?>assets/images/ajax-page-loader.gif" style="width:80px;" /></div>
                <div class="x_panel" id="postList">
				<?php echo $this->ajax_pagination->create_links(); ?>
                  <div class="x_content">
                    <div class="row">
                      <div class="col-md-12 col-sm-12 col-xs-12 text-center"> 
                      </div>

                      <div class="clearfix"></div>
<?php 

$ini=0;
	$childcount=count($userslist);// echo $childcount;exit;	 
	if($childcount==0){?> 
	   <div class="col-md-12 col-sm-12 col-xs-12">           
            <div class="col-sm-12">						  
				<center><h3>No data found</h3> </center>
			</div>			 
	  </div>
	<?php }
	 
	//echo "<pre>";print_r($userslist);exit;
	foreach($userslist as $res){
	$ini++;
	?>	
		
                      <div class="col-md-4 col-sm-4 col-xs-12 profile_details">
                        <div class="well profile_view" style="background:#f4f7ff">
                          <div class="col-sm-12" style="min-height: 260px;">
						  <div class="col-sm-6">
                            <h4 class="brief"><i><b><?php echo $res['fname']; ?></b></i></h4></div>
							<?php if($res['patienttype']!='') { ?>
							<div class="col-sm-6">
                            <h5 style="float:right" class="brief"><i><b> Type : <?php  echo $res['patienttype']; ?></b></i></h5></div><?php } ?>
                            <div class="left col-xs-7 <?php if($res['status']==0) { ?> inactiveelement <?php } ?>">
                              <ul class="list-unstyled">
							  
							   
							   <li><i class="fa fa-circle"></i> <?php echo $res['programname']; ?></li>
							    <li><i class="fa fa-book"></i> <?php echo $res['gradename']; ?></li>					  
							  
							  <li><i class="fa fa-user"></i> <?php echo $res['parentname']; ?></li>
							  <li><i class="fa fa-mobile-phone"></i> <?php echo $res['mobile']; ?></li>
                                <li><i class="fa fa-envelope-o"></i> <?php echo $res['email']; ?></li>
                                <li><i class="fa fa-birthday-cake"></i> <?php echo $res['dob']; ?></li>
								<li><i class="fa fa-map-marker"></i> <?php echo $res['address']; ?> <?php echo $res['city']; ?>, <?php echo $res['statename']; ?></li>
								<?php if($res['creation_date']!='0000-00-00') { ?>
								<li>Registered Date : <?php echo date('d-m-Y',strtotime($res['creation_date'])); ?></li><?php } ?>
                              </ul>
                            </div>
						<!--	<//?php if($res['avatarimage']==""){$res['avatarimage']="assets/images/avatar.png";} 
  if(file_exists(APPPATH."../assets/".$res['avatarimage'])=='false')
   {$res['avatarimage']="assets/images/avatar.png";}else{$res['avatarimage']=$res['avatarimage'];} ?>
                            <div class="right col-xs-5 text-center">
                              <img src="<//?php echo base_url(); ?><//?php echo $res['avatarimage']; ?>" style="width:100px;height:100px;" alt="profileimage" class="img-circle img-responsive">
                            </div>-->
                          </div>
                          <div class="col-xs-12 bottom text-center" style="background:#93c5c7">
                            <div class="col-xs-12 col-sm-6 emphasis">
                            </div>
                             <div class="col-xs-12 col-sm-6 emphasis">
                              <?php if($res['programid']==1)
							  { ?>
								  <a style="float:right" href="<?php echo base_url(); ?>index.php/sa_reports/userview/<?php echo $res['userid']; ?>" class="btn btn-success btn-xs">
									<i class="fa fa-user"> </i> View Details
								  </a> 
							  <?php } else if(($res['programid']==2) && ($res['grade_id']==1 || $res['grade_id']==2 || $res['grade_id']==11)) { ?>
									<a style="float:right" href="<?php echo base_url(); ?>index.php/bka_reports/userview/<?php echo $res['userid']; ?>" class="btn btn-success btn-xs">
									<i class="fa fa-user"> </i> View Details
								  </a>
							  <?php } 	else if($res['programid']==2) { ?>
								   <a style="float:right" href="<?php echo base_url(); ?>index.php/ba_reports/userview/<?php echo $res['userid']; ?>" class="btn btn-success btn-xs">
									<i class="fa fa-user"> </i> View Details
								  </a>
							  <?php } else if($res['programid']==3) { ?>
									<a style="float:right" href="<?php echo base_url(); ?>index.php/ka_reports/userview/<?php echo $res['userid']; ?>" class="btn btn-success btn-xs">
									<i class="fa fa-user"> </i> View Details111
								  </a>
							  <?php }  ?>
                            </div>	 
                          </div>
                        </div>
	</div><?php } ?>
                    </div>
					<?php echo $this->ajax_pagination->create_links(); ?>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>	
		


<script src="<?php echo base_url(); ?>assets/js/jquery.min.js" type="text/javascript"></script>

<script>
function searchFilter(page_num) {
    page_num = page_num?page_num:0;
    var keywords = $('#keywords').val();
    var sortBy = $('#sortBy').val();
    $.ajax({
        type: 'POST',
        url: '<?php echo base_url(); ?>index.php/home/userlist_PaginationData/'+page_num,
        data:'page='+page_num,
        beforeSend: function () {
            $('.loading').show();
        },
        success: function (html) {
            $('#postList').html(html);
            $('.loading').fadeOut("slow");
        }
    });
}



$('#btnsrch').click(function(){
	
	var ddacademyname = $('#ddacademyname').val();
	var txtstudentname = $('#txtstudentname').val();
	var ddgradename = $('#ddgradename').val();
			$('.loading').show();
		$.ajax({
					type:"POST",
					url:"<?php echo base_url('index.php/home/clp_users_search') ?>",
					data:{ddacademyname:ddacademyname,txtstudentname:txtstudentname,ddgradename:ddgradename},
					success:function(result)
					{
						$('.loading').hide();
					$('#clptable').html(result);
					}
			});
	});


</script>
<style>
.reporttitle { color:#1abb9c; }
thead{ background-color: #1abb9c; color: #fff;}

.pagination a{background: #ca0f0f;padding: 7px;color:#fff}
.pagination b{background: #15cc46;padding: 7px;color:#fff}
.pagination{float:right;}


.loading {
  position: fixed;
  z-index: 999;
  height: 2em;
  width: 2em;
  overflow: show;
  margin: auto;
  top: 0;
  left: 0;
  bottom: 0;
  right: 0;
}

.loading:before {
  content: '';
  display: block;
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background-color: rgba(0,0,0,0.3);
}

/* :not(:required) hides these rules from IE9 and below */
.loading:not(:required) {
  /* hide "loading..." text */
  font: 0/0 a;
  color: transparent;
  text-shadow: none;
  background-color: transparent;
  border: 0;
}
</style>
