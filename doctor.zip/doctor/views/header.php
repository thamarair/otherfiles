<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Edsix BrainLab </title>
	<link href="<?php echo base_url(); ?>assets/css/bootstrap-multiselect.css" type="text/css" />
	<link href="<?php echo base_url(); ?>assets/css/bootstrap.min.css" rel="stylesheet">
    <link href="<?php echo base_url(); ?>assets/css/font-awesome.min.css" rel="stylesheet">
    <link href="<?php echo base_url(); ?>assets/css/nprogress.css" rel="stylesheet">
	<link href="<?php echo base_url(); ?>assets/css/green.css" rel="stylesheet">
	<link href="<?php echo base_url(); ?>assets/css/bootstrap-progressbar-3.3.4.min.css" rel="stylesheet">
	<link href="<?php echo base_url(); ?>assets/css/jqvmap.min.css" rel="stylesheet"/>
	<link href="<?php echo base_url(); ?>assets/css/daterangepicker.css" rel="stylesheet">
	<link href="<?php echo base_url(); ?>assets/css/custom.css" rel="stylesheet"> 
    <link href="<?php echo base_url(); ?>assets/css/animate.min.css" rel="stylesheet">
 
    <link href="<?php echo base_url(); ?>assets/css/jquery.dataTables.css" rel="stylesheet" type="text/css">
    <link href="<?php echo base_url(); ?>assets/css/dataTables.tableTools.css" rel="stylesheet" type="text/css">
	
	   <style>
	   .inactiveelement { opacity: 0.5; }
	   </style>
<body class="nav-sm">
    <div class="container body">
      <div class="main_container">
        <div class="col-md-3 left_col">
          <div class="left_col scroll-view">
           

         

            <!-- menu profile quick info -->
            <div class="profile clearfix">
              <div class="profile_pic">
               <a href="javascript:;"><img src="<?php echo base_url(); ?>assets/images/web_logo.png" style="width: 200px;" alt="..." class="">
              </div>
             
            </div>
            <!-- /menu profile quick info -->

            <br>
<div id="sidebar-menu" class="main_menu_side hidden-print main_menu">
              <div class="menu_section">
                <ul class="nav side-menu">
                  <li><a id="Dashboard" class="Dashboard menu" href="<?php echo base_url(); ?>index.php/home/dashboard"><i class="fa fa-home"></i>Dashboard</a>
                        </li>
						
						<li><a id="userslist" class="Dashboard menu" href="<?php echo base_url(); ?>index.php/home/userslist"><i class="fa fa-users"></i>Child List</a>
                        </li>
						
						<!--<li><a id="userslist" class="Dashboard menu" href="<?php echo base_url(); ?>index.php/home/patientperformance"><i class="fa fa-bar-chart-o"></i>Child Performance</a>
                        </li>-->
						
						<!--<li><a id="couponcode" class="Dashboard menu" href="<?php echo base_url(); ?>index.php/home/couponlist"><i class="fa fa-credit-card"></i>Coupon Code</a>
                        </li>
						
						
						 <li><a id="BspiToppers" class="BspiToppers menu" href="javascript:;"><i class="fa fa-table"></i>BSPI Toppers</a>
                        </li>
						
						<li><a id="CrowniesToppers" class="CrowniesToppers menu" href="javascript:;"><i class="fa fa-table"></i>Crownies' Toppers</a>
                        </li>
						
						<li><a id="EomReports" class="EomReports menu" href="javascript:;"><i class="fa fa-table"></i>EOM Report</a>
                        </li>
						<li>
                            <a id="MyProfile" class="MyProfile  menu" href="javascript:;"><i class="fa fa-table fa-fw"></i> Student Game Play Status</a>
                        </li>
						<li><a id="SupportCenter" class="SupportCenter menu" href="javascript:;"><i class="fa fa-table"></i>Support Center</a>
                        </li>
						<li><a id="SupportCenter" class="SupportCenter menu" href="javascript:;"><i class="fa fa-table"></i>Bandwidth Log</a>
                        </li>-->
                    </ul>
              </div>

            </div>
			</div>

        </div>

        <!-- top navigation -->
        <div class="top_nav">
          <div class="nav_menu">
            <nav>
              <div class="nav toggle">
                <a id="menu_toggle"><i class="fa fa-bars"></i></a>
              </div>
				
              <ul class="nav navbar-nav navbar-right">
			  <li class="col-sm-6">
				<div class="schooltitle" style="display:inline;"><span style="font-size:20px;" class="topHead"> Welcome  <?php echo $this->session->doctorname; ?></span></div>
			  </li>
                 
<li class="col-sm-1 dateinfo fa fa-sign-out pull-right" style="float: right;"><span class="count_top"><a href="<?php echo base_url(); ?>index.php/home/logout" class="" style="font-weight:bold;">Logout</a></span></li>
               </ul>
			   
            </nav>
          </div>
        </div>
        <!-- /top navigation -->

        <!-- page content -->
        
<div id="pwdModal" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true">
  <div class="modal-dialog">
  <div class="modal-content"> 
   <div style="display:none;" id="loadingimg" class="loading"></div>
      <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
		  <h3 class="text-center modalheading"></h3>
		  <div class="col-md-12 col-sm-12 col-xs-12" >
                <div class="panel panel-default">
                    <div class="panel-body">
                        <div class="text-center">
                          <div class="modaldata"></div>
                        </div>
                    </div>
                </div>
            </div>
      </div>
	</div>
  </div>
</div>