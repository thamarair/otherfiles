            $(document).ready(function() {
 if ( $('.box select').length) {  $('.box select').niceSelect();}
});   
			$(document).ready(function () {
				 if ( $('header').length) { 
				 
                var stickyNavTop = $('header').offset().top;
                var stickyNav = function () {
                    var scrollTop = $(window).scrollTop();
                    if (scrollTop > stickyNavTop) {
                        $('header').addClass('sticky');
                    }
                    else {
                        $('header').removeClass('sticky');
                    }
                };
                stickyNav();
                $(window).scroll(function () {
                    stickyNav();
                });
				 }
                $('a[href^="#"].goLink').click(function () {
                    $('html,body').animate({
                        scrollTop: $(this.hash).offset().top - 80
                    }, 800);
                    return false;
                    e.preventDefault();
                });
            });