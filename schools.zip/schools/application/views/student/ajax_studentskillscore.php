<script type="text/javascript">
		$('#container_2').highcharts({
		chart: {
            type: 'column', spacingTop: 20
			
        },
		
        title: {
            text: '',
            x: -20 //center
        },
        subtitle: {
            text: '',
            x: -20
        },
        xAxis: {
            categories: [<?php $ini=0; foreach($SkillList as $am){
				$ini++;
				if($ini>1){echo ",";}
				echo "'".$am['name']."'";
			} ?>]
        },
        yAxis: {
            min: 0,tickInterval: 10,max:100,
            title: {
                text: 'Score'
            },
           
        },
        tooltip: {
            valueSuffix: ''
        },
		plotOptions: {
            column: {
            dataLabels: {
                enabled: true,
                crop: false,
                overflow: 'none'
            }
            }
        },
        credits: {
      enabled: false
  },
        series: [
			<?php if(count($SkillList)!=5 )
			{?>
			{	showInLegend: true,
				color: '#7cb5ec',
				name: 'Assessment Skill Score',
				data: [<?php $j=0; foreach($SkillList as $am){ ?>
						{name:'<?php echo $am['name'] ?>',y: <?php if(isset($asapavgskillscore[$am['id']]['game_score'])){echo $asapavgskillscore[$am['id']]['game_score'];}else{echo 0;} ?>, color: '#7cb5ec'},
						<?php $j++;} ?>
				]
			},
	<?php } ?>
			{
				showInLegend: true,   
				color: '#ff3300',
				name: 'Training Skill Score',
				data: [<?php $i=0; foreach($SkillList as $am)
				{ ?>			
						{name:'<?php echo $am['name'] ?>',y: <?php if(isset($avgskillscore[$am['id']]['skillscore'])){echo $avgskillscore[$am['id']]['skillscore'];}else{echo 0; } ?>, color: '<?php echo $am['colorcode'] ?>'},
		<?php 		$i++;
				} ?>
				]
			},
		<?php if(count($SkillList)==5 )
		{?>
			{	showInLegend: true,
				color: '#7cb5ec',
				name: 'Training Days',
				data: [<?php $j=0; foreach($SkillList as $am){ ?>
						{name:'<?php echo $am['name'] ?>',y: <?php if(isset($avgskillscore_days[$am['id']]['pcount'])){echo $avgskillscore_days[$am['id']]['pcount'];}else{echo 0;} ?>, color: '#7cb5ec'},
						<?php $j++;} ?>
				]
			}
<?php   }?>

		],
		
		
    });
</script>
<div id="container_2"></div>