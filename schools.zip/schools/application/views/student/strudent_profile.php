<div class="right_col" role="main">
<?php
$clp_bspi=round(((round($userskillscore[0]['Memory'],2)+round($userskillscore[0]['VP'],2)+round($userskillscore[0]['FA'],2)+round($userskillscore[0]['PS'],2)+round($userskillscore[0]['LI'],2))/5),2)
?>
	<div class="row tile_count">
		<div class="col-md-2 col-sm-4 col-xs-6 tile_stats_count">
			<span class="count_top"><i class="fa fa-user"></i> Section rank</span>
			<div class="count"><?php echo $studentRank[0]['rank']; ?></div>
		</div>
		<div class="col-md-2 col-sm-4 col-xs-6 tile_stats_count">
			<span class="count_top"><i class="fa fa-clock-o"></i> Minutes Trained</span>
			<div class="count green"><?php echo floor($userskillscore[0]['gtime']/60)  ;?></div>
		</div>
		<div class="col-md-2 col-sm-4 col-xs-6 tile_stats_count">
			<span class="count_top"><i class="fa fa-puzzle-piece"></i> Puzzles Attempted</span>
			<div class="count"><?php echo $userskillscore[0]['attempt_question'] ;?></div>
		</div>
		<div class="col-md-2 col-sm-4 col-xs-6 tile_stats_count">
			<span class="count_top"><i class="fa fa-puzzle-piece"></i> Puzzles Solved</span>
			<div class="count green"><?php echo $userskillscore[0]['answer'] ;?></div>
		</div>
		<div class="col-md-2 col-sm-4 col-xs-6 tile_stats_count">
			<span class="count_top"><i class="fa fa-gamepad"></i> Average BSPI</span>
			<div class="count"><?php echo $clp_bspi; ?></div>
		</div>

		<div class="col-md-2 col-sm-4 col-xs-6 tile_stats_count">
			<span class="count_top"> <i class="fa fa-gamepad"></i> Crownies </span>		  
			<div class="count green"><?php echo $userskillscore[0]['CrownyPoints']; ?></div>		 
		</div>
	</div> 
	<div class="row">
		<div class="col-md-12 col-sm-12 col-xs-12">
			<!--<div class="col-md-4 col-sm-4 col-xs-12 countdata"><label class="text-center">Expected  Utilization </label><span class="countval"><?php echo $regattenduser['totaluser']; ?></span></div>-->
			<div class="col-md-4 col-sm-4 col-xs-12 countdata newcolor1"><label class="text-center">Scheduled Sessions</label><span class="countval"><?php echo $userskillscore[0]['scheduled_session']; ?></span></div>
			<div class="col-md-4 col-sm-4 col-xs-12 countdata newcolor2"><label class="text-center">Attended Sessions</label><span class="countval"><?php echo $userskillscore[0]['AttendedSession']; ?></span></div>
			<div class="col-md-4 col-sm-4 col-xs-12 countdata newcolor1"><label class="text-center">Completed Sessions</label><span class="countval"><?php echo $userskillscore[0]['CompletedSession']; ?></span></div>
		</div>
	</div>
	 <div class="pageHomePager Dashboardhide mygameshide myreporthide myprofilehide userdetails">
		<div class="row">
		  <div class="col-lg-12">
				<h1 class="page-header reporttitle"><?php echo $studentdetails[0]['name']." : ".$studentdetails[0]['classname']." - ".$studentdetails[0]['section']; ?></h1>
		  </div>
		</div>	
	 
		<div class="row">
		  <div class="col-md-12 col-sm-12 col-xs-12">
			<div class="x_panel">
			  <div class="x_title">
			  <?php
				
				$asap_bspi=$userskillscore[0]['asapbspi'];
				
				if($clp_bspi>$asap_bspi)
				{
					$growth_score=round($clp_bspi-$asap_bspi,2);
					$growth_percentage=round(((($clp_bspi-$asap_bspi)/$asap_bspi)*100),2);
					$growth_icon="fa fa-arrow-up";
					$growth_color="green";
				}
				else
				{
					$growth_score=round($asap_bspi-$clp_bspi,2);
					$growth_percentage=round(((($asap_bspi-$clp_bspi)/$clp_bspi)*100),2);
					$growth_icon="fa fa-arrow-down";
					$growth_color="red";
				}
			  ?>
				<h2 class="reporttitle">BSPI Comparison : <i class="<?php echo $growth_icon; ?>" style="font-size:24px;color:<?php echo $growth_color; ?>"></i> <span class="improvement">
				<?php echo $growth_score ." (".$growth_percentage."%) "; ?></span></h2>				
				<div class="clearfix"></div>
			  </div> 
			  <div class="x_content">
				<div class="row">
				  <div class="col-md-12">
				  <div class="col-md-2 col-xs-12 widget widget_tally_box"></div>
					<div class="col-md-3 col-xs-12 widget widget_tally_box">
                        <div class="x_panel ui-ribbon-container fixed_height_390" style="background: #2a3f54;color: #fff;">
                          <div class="x_title" >
                            <h2 style="color:#fff;">Assessment BSPI </h2>
                            <div class="clearfix"></div>
                          </div>
                          <div class="x_content">

                            <div style="text-align: center; margin-bottom: 17px">
                              <span class="chart" data-percent="<?php echo $asap_bspi;?>">
								<span class="percent"><?php echo $asap_bspi;?></span>
                              <canvas height="110" width="110"></canvas></span>
                            </div>
							<div style="text-align: center; margin-bottom: 17px">
									<h2>BSPI : <?php echo $asap_bspi;?></h2>
							</div>
                          </div>
                        </div>
                      </div>
					  <div class="col-md-3 col-xs-12 widget widget_tally_box" >
                        <div class="x_panel ui-ribbon-container fixed_height_390" style="background: #2a3f54;color: #fff;">
                          <div class="x_title">
                            <h2 style="color:#fff;">Training BSPI</h2>
                            <div class="clearfix"></div>
                          </div>
                          <div class="x_content">
                            <div style="text-align: center; margin-bottom: 17px">
                              <span class="chart" data-percent="<?php echo $clp_bspi;?>">
								<span class="percent"><?php echo $clp_bspi;?></span>
                              <canvas height="110" width="110"></canvas></span>
                            </div>
								<div style="text-align: center; margin-bottom: 17px">
									<h2>BSPI : <?php echo $clp_bspi;?></h2>
								</div>
                          </div>
                        </div>
                      </div>
					<div class="col-md-2 col-xs-12 widget widget_tally_box"></div>
					 <!--<div class="col-md-6">
                      <div class="progress right"> 
                        <div class="progress-bar progress-bar-danger" data-transitiongoal="25" aria-valuenow="25" style="width: <?php echo $asap_bspi;?>%;">ASAP BSPI : <?php echo $asap_bspi;?></div>
                      </div>
                    </div>
                    <div class="col-md-6">
                      <div class="progress">
                        <div class="progress-bar progress-bar-danger" data-transitiongoal="25" aria-valuenow="25" style="width: <?php echo $clp_bspi;?>%;">CLP BSPI : <?php echo $clp_bspi;?></div>
                      </div> 
                    </div>-->
				  </div>
				</div>
			  </div>
			</div>
		  </div>
		</div>
		<div class="row">
		  <div class="col-md-12 col-sm-12 col-xs-12">
			<div class="x_panel">
			  <div class="x_title">
				<h2 class="reporttitle">Rewards</h2>				
				<div class="clearfix"></div>
			  </div>
			  <?php
				if($StudentBadgeCount[0]['sbbbadge']!=''){$sbbbadge=$StudentBadgeCount[0]['sbbbadge'];}else{$sbbbadge=0;}
				if($StudentBadgeCount[0]['sgbbadge']!=''){$sgbbadge=$StudentBadgeCount[0]['sgbbadge'];}else{$sgbbadge=0;}
				if($StudentBadgeCount[0]['sabbadge']!=''){$sabbadge=$StudentBadgeCount[0]['sabbadge'];}else{$sabbadge=0;}
			  ?>
			  <div class="x_content">
				<div class="row">
				  <div class="col-md-12">
					<!-- price element -->
					<div class="col-md-4 col-sm-6 col-xs-12" data-toggle="tooltip" data-placement="top" title="Has scored the highest BSPI in the class for one month">
					  <div class="pricing">
						<div class="title">
						<div class="col-md-12 col-sm-12 col-xs-12">
							<div class="col-md-4 col-sm-4 col-xs-12">
								<img src="<?php echo base_url(); ?>assets/images/SuperBrain-Badge.png" style="width:80px;" /> 
							</div>
							<div class="col-md-8 col-sm-8 col-xs-12">
								<h2>SuperBrain Badge</h2>
								 <h1><?php echo $sbbbadge;  ?></h1>
							</div>
						</div>
						</div>						
					  </div>
					</div>
					<div class="col-md-4 col-sm-6 col-xs-12" data-toggle="tooltip" data-placement="top" title="Has played the most games of any student in the class for one month">
					  <div class="pricing">
						<div class="title">
							<div class="col-md-12 col-sm-12 col-xs-12">
								<div class="col-md-4 col-sm-4 col-xs-12">
									<img src="<?php echo base_url(); ?>assets/images/SuperGoer-Badge.png" style="width:80px;" /> 
								</div>
								<div class="col-md-8 col-sm-8 col-xs-12">
									<h2>SuperGoer Badge</h2>
									 <h1><?php  echo $sgbbadge; ?></h1>
								</div>
							</div> 
						</div>
					  </div>
					</div> 
					<div class="col-md-4 col-sm-6 col-xs-12" data-toggle="tooltip" data-placement="top" title="Has given the most correct answers of any student in the class for one month">
					  <div class="pricing">
						<div class="title">
							<div class="col-md-12 col-sm-12 col-xs-12">
								<div class="col-md-4 col-sm-4 col-xs-12">
									<img src="<?php echo base_url(); ?>assets/images/SuperAngel-Badge.png" style="width:80px;" /> 
								</div>
								<div class="col-md-8 col-sm-8 col-xs-12">
									<h2>SuperAngel Badge</h2>
									 <h1><?php  echo $sabbadge; ?></h1>
								</div>
							</div>
						</div>
					  </div>
					</div>
					
					
				  </div>
				</div>
			  </div>
			</div>
		  </div>
		</div>
		
			
			<div class="row">
      			<div class="col-md-6 col-sm-6 col-xs-12 col-lg-6 OverallPerformance">
					<div class="x_panel tile overallbspi">
						<div class="x_title">
						  <h2 class="reporttitle monthwiseavgbspi">Overall Performance</h2>
						  <div class="clearfix"></div>
						</div>
						<div class="panel panel-default">
							<div class="panel-body reportChartContainer" style="margin: 29px 0;">
								<div id="chartOverallPerformance" ></div>
							</div>
						</div>
					</div>
				</div>
				<div class="col-md-6 col-sm-6 col-xs-12 col-lg-6">
					<div class="x_panel tile">
						<div class="x_title">
						  <h2 class="reporttitle">Average Skill Score</h2>
						  <div class="clearfix"></div>
						</div>
						<div class="x_title">
							<div class="row"  >
							<input type="button" value="ALL" id="ALL" name="viewreport" class="btn btn-success skillwisescore_M SkillActive" />
							<input type="button" value="M" id="59" name="viewreport" class="btn btn-success skillwisescore_M" />
							<input type="button" value="VP" id="60" name="viewreport" class="btn btn-success skillwisescore_M" />
							<input type="button" value="FA" id="61" name="viewreport" class="btn btn-success skillwisescore_M" />
							<input type="button" value="PS" id="62" name="viewreport" class="btn btn-success skillwisescore_M" />
							<input type="button" value="L" id="63" name="viewreport" class="btn btn-success skillwisescore_M" />
							</div>
						</div>
						<div class="panel panel-default">
							<div class="panel-body reportChartContainer">
							<div style="display:none; text-align:center;" id="iddivLoading6" class="loading"><img src="<?php echo base_url(); ?>assets/images/ajax-page-loader.gif"  style="width:50px;"  /></div>
								<div id="SkillScore"></div>
							</div>
						</div>
					</div>
                </div>
				
 			</div>	
		
			
			<div class="row">
				<div class="col-md-12 col-sm-12 col-xs-12 col-lg-12 landingContainer" style="overflow-x:auto" >
					<div class="x_panel tile">
						<div class="x_title">
						  <h2 class="reporttitle monthwiseavgbspi">Game Play Status</h2>
						  <div class="clearfix"></div>
						</div>
						<table id="GamePlayStatus" class="table table-striped table-bordered table-hover table-condensed dt-responsive">
							<thead>
								<tr>
									<th>S.No.</th>
									<th>Month</th>
									<th>Total</th>
									<th>Completed</th>
									<th>Incomplete</th>
								</tr>
							</thead>
							<tbody>
							<?php 
							$ini=0;  
							$i=1;$result=array();
							foreach($academicMonths as $am)
							{  
							?>
								<tr>
								<td><?php echo $i; ?></td>
								<td><?php echo $am['monthName']; ?></td>
								<td><?php if($userattemptbymon[$am['monthNumber']]['attempt']!=''){echo $userattemptbymon[$am['monthNumber']]['attempt'];}else{echo "0";} ?></td>
								<td><?php if($usercompletebymon[$am['monthNumber']]['comp']!=''){echo $usercompletebymon[$am['monthNumber']]['comp'];}else{ echo "0";} ?></td>
								<td><?php echo $userattemptbymon[$am['monthNumber']]['attempt']-$usercompletebymon[$am['monthNumber']]['comp'] ; ?></td>
								</tr> 
							<?php  $i++;$ini++;
							}  ?> 
							</tbody>
						</table>
					</div>
				</div>
			</div>	
	
	
</div>

</div>
<style>
.dataTables_wrapper{overflow: auto;}
#GamePlayStatus tfoot{display: table-header-group;}
#GamePlayStatus thead{background-color:#1abb9c;color:#FFF;}
.countdata {
    min-height:0px;
}
.x_panel{height:auto;}
.improvement{color: #000 !important;font-size: 25px;}
</style>
<script src="<?php echo base_url(); ?>assets/js/jquery.min.js" type="text/javascript"></script>
<script src="<?php echo base_url(); ?>assets/js/highcharts.js"></script>

<link href="<?php echo base_url(); ?>assets/css/jquery.dataTables.css" rel="stylesheet" type="text/css">
<link href="<?php echo base_url(); ?>assets/css/dataTables.tableTools.css" rel="stylesheet" type="text/css">
<script src="<?php echo base_url(); ?>assets/js/jquery.dataTables.js" type="text/javascript"></script>
<script src="<?php echo base_url(); ?>assets/js/dataTables.tableTools.js" type="text/javascript"></script>
 <script>
$('#GamePlayStatus').DataTable({"lengthMenu": [[10,  -1], [10,  "All"]]});

Student_avgskillscore('');
 
function Student_avgskillscore(sid)
{
	var userid = "<?php echo $studentdetails[0]['id']; ?>";
	if(sid=='')
	{
		var skillid="ALL";
	}
	else
	{
		var skillid=sid;
	}
	$("#iddivLoading6").show();
	$.ajax({
    type: "POST",
    url:  "<?php echo base_url(); ?>index.php/home/ajax_studentskillscore",
    data: {type:'overallskillscore',userid:userid,skillid:skillid,username:'<?php echo $studentdetails[0]['username']; ?>'},
    success: function(result){
		$("#iddivLoading6").hide();
		$('#SkillScore').html(result);	
    }
});
}
$('.skillwisescore_M').click(function(){ // skillscorechart();
	
	$('.skillwisescore_M').removeClass('SkillActive');
	$(this).addClass('SkillActive');
	
	var skillid = $(this).attr('id');
	Student_avgskillscore(skillid);
});
 
$(document).ready(function(){
	
    chart = new Highcharts.Chart({
        chart: {
			renderTo: 'chartOverallPerformance',
            type: 'column'
        },
        title: {
            text: ''
        },
        
        xAxis: {
            categories: [
			<?php $ini=0; foreach($academicMonths as $am){
				$ini++;
				if($ini>1){echo ",";}
				echo "'".$am['monthName']."'";
			} ?>
                
            ],
            crosshair: true
        },
        yAxis: {
            min: 0,tickInterval: 10,max:100,
            title: {
                text: 'Score'
            }
        },
		
		
       
        plotOptions: {
            column: {
            dataLabels: {
                enabled: true,
                crop: false,
                overflow: 'none'
            }
            }
        },
		credits: {
      enabled: false
  },
        series: [{showInLegend: true,  color:"#1abb9c",
            name: 'BSPI Score',
            data: [
			<?php $ini=0; foreach($academicMonths as $am){
				if(isset($OverallPerformance_value[$am['monthNumber']]))
				{
					$val=$OverallPerformance_value[$am['monthNumber']];
				}
				else
				{
					$val=0;
				}
				$ini++;
				if($ini>1){echo ",";}
				echo "".$val."";
			} ?>
			
			]

        },{showInLegend: true,  color:"#7cb5ec",
            name: 'Training Days',
            data: [<?php $ini=0;  foreach($academicMonths as $am){
				if(isset($arrPlayedDays[$am['monthNumber']]))
				{
					$val1=$arrPlayedDays[$am['monthNumber']];
				}
				else
				{
					$val1=0;
				}
				$ini++;
				if($ini>1){echo ",";}
				echo "".$val1."";
			} ?>]

        }]
    });
	

});

 </script>    
<script src="<?php echo base_url(); ?>assets/js/jquery.slimscroll.js" type="text/javascript"></script>
 <!-- Chart.js -->
    <script src="<?php echo base_url(); ?>assets/js/ChartNew.min.js"></script>
	<!-- easy-pie-chart -->
    <script src="<?php echo base_url(); ?>assets/js/jquery.easypiechart.min.js"></script>
    <!-- jQuery Sparklines -->