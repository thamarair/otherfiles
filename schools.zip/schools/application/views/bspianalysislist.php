<div class="right_col" role="main">
<div class="row">

	<div class="col-md-12 col-lg-12 col-sm-12 col-xs-12">
		<div class="x_panel tile">
			<div class="x_title">
				<h2 class="reporttitle">BSPI Analysis</h2>
				<div class="clearfix"></div>
			</div>
			<div class="x_content" >
			<table id="dataTable" class="table table-bordered table-condensed table-hover table-striped dataTable">
						<thead style="background-color:#1abb9c; color:#FFF;">
							<tr>
								<th>S.No</th>
								<th>Name</th>
								<th>User Name</th>
								<th>Grade</th>
								<th>Section</th>
								<th>BSPI</th>	
							</tr>
						</thead>
						<tbody>
						<?php
							$i=0;
							foreach($userlist as $bspi)
							{ $i++;
								?>
								
									<tr>
									<td><?php echo $i; ?></td>
									<td><a href="index.php?act=users_detailed_report&txtStudentName=<?php echo $bspi['username']; ?>" style="text-decoration:underline;" target="_blank"><?php echo $bspi['name']; ?></a></td>
									<td><?php echo $bspi['username']; ?></td>
									<td><?php echo $bspi['grade']; ?></td>
									<td><?php echo $bspi['section']; ?></td>
									<td><?php echo round($bspi['finalscore'], 2); ?></td>
									</tr>
								
							
						<?php 	} ?>
						</tbody> 
						</table>
	 

	<link href="<?php echo base_url(); ?>assets/css/jquery.dataTables.css" rel="stylesheet" type="text/css">
	<link href="<?php echo base_url(); ?>assets/css/dataTables.tableTools.css" rel="stylesheet" type="text/css">
	<script src="<?php echo base_url(); ?>assets/js/jquery.min.js" type="text/javascript"></script>
	<script src="<?php echo base_url(); ?>assets/js/jquery.dataTables.js" type="text/javascript"></script>
	<script src="<?php echo base_url(); ?>assets/js/dataTables.tableTools.js" type="text/javascript"></script>
	<script>
	$('.dataTable').DataTable({
		"lengthMenu": [[10,  -1], [10,  "All"]]
		//"scrollX": true
	});
	</script>
				</div>
			</div>
		</div>
	</div>
</div>
<style>
.dataTables_wrapper{overflow: auto;}
</style>