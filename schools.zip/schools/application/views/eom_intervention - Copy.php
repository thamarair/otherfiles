<div style="">
	<div class="x_panel tile">
		<div class="x_title">
		  <!--<h2 class="reporttitle monthwiseavgbspi">Utilization Report</h2>
		  <ul class="nav navbar-right panel_toolbox">
				<li><a class="collapse-link bounce"><i class="fa fa-chevron-up"></i></a></li>
				<li class="dropdown open">
					<a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="true"><i class="glyphicon glyphicon-eye-open"></i></a>
					<ul class="dropdown-menu" role="menu">
					   <li><a href="javascript:;" id="INchview">Chart <i class="glyphicon glyphicon-indent-left"></i></a></li>
					   <li><a href="javascript:;" id="INtblview">Table <i class="glyphicon glyphicon-th"></i></a></li>
					</ul>
				</li>
			</ul>-->
		  <div class="clearfix"></div>
		</div>
		<div class="x_content" >
			<div class="" role="tabpanel" data-example-id="togglable-tabs">
					<ul id="myTab" class="nav nav-tabs bar_tabs" role="tablist">
						<?php
							if($filter=='<=20')
							{ 
								$filter1="INActive";
							}
							else if($filter=='>20and<=40')
							{ 
								$filter2="INActive";
							}
							else if($filter=='>40and<=60')
							{ 
								$filter3="INActive";
							}
							else if($filter=='>60and<=80')
							{ 
								$filter4="INActive";
							}
							else if($filter=='>80')
							{ 
								$filter5="INActive";
							}
							else
							{
								$filter1="INActive";
							}
						?>
						 <li class="intervention_filter"><a href="javascript:;" id="&lt;=20" class="in_fl <?php echo $filter1;?>">&lt;=20</a></li>
						 <li class="intervention_filter"><a href="javascript:;" id="&gt;20and&lt;=40" class="in_fl <?php echo $filter2; ?>">&gt; 20 and &lt;= 40 </a></li>
						 <li class="intervention_filter"><a href="javascript:;" id="&gt;40and&lt;=60" class="in_fl <?php echo $filter3; ?>">&gt; 40 and &lt;= 60</a></li>
						 <li class="intervention_filter"><a href="javascript:;" id="&gt;60and&lt;=80" class="in_fl <?php echo $filter4; ?>">&gt; 60 and &lt;= 80</a></li>
						 <li class="intervention_filter"><a href="javascript:;" id="&gt;80" class="in_fl <?php echo $filter5; ?>">&gt;80</a></li>
					</ul>
					<input type="hidden" id="month" class="" value="" >
				</div>
			<div id="intervetionreport"></div>
			<div id="intervetionreport1"></div>
		</div>
	</div>
	<div class="x_panel tile">
		<div class="x_title"></div>
		<div class="x_content" >
			<div class="intervetionTbl" > 
				<table id="invertionbspianalysis" class="table table-bordered table-condensed table-hover table-striped">
									<thead>
										<tr>
											<th>S.No.</th>
											<th>Grade</th>
											<th>Section</th>
											<th><a href="#unattended" style="color:#fff; text-decoration: underline;">Unattended User</a></th>
											<th><a href="#twenty" style="color:#fff; text-decoration: underline;">Rigorous and immediate intervention needed. But don’t feel low. Kids can certainly improve! (<20)</a></th>
											<th><a href="#forty" style="color:#fff; text-decoration: underline;">Needs Immediate Intervention. Mistakes are the stepping stones to success. You can surely do it! (20-40)</a></th>
											<th><a href="#sixty" style="color:#fff; text-decoration: underline;">Intervention will enhance curriculum performance. Everyone has caliber; a bit of push can cause wonders! (40-60)</a></th>
											<th><a href="#eighty" style="color:#fff; text-decoration: underline;">You definitely have a spark. Some determination and you will reach there! (60-80)</a></th>
											<th><a href="#morethaneigthy" style="color:#fff; text-decoration: underline;">Prodigy! This is fantastic. Keep it up and Carry it further! (>80)</a></th>
										</tr>
									</thead>
									<tfoot align="right">
						<tr><th></th><th></th><th></th><th></th><th></th><th></th><th></th><th></th><th></th></tr>
					</tfoot>
				<tbody>
				<?php $j=1;
				//foreach($query as $key1=>$val1){//echo "<pre>";print_r($key1);exit; /*echo "<pre>";print_r($val3);exit; */
				$lesstwentyTotal=0;$fortyTotal=0;$sixtyTotal=0;$eightTotal=0;$aboveeightyTotal=0;
				foreach($TotalGradeSec as $row)
				{
					$key1=$row['id']."-".$row['section'];
				?>
						<tr>
							<td><?php echo $j; ?></td>
							<td><?php echo $row['classname']; ?></td>
							<td><?php echo $row['section']; ?></td>
							<td><?php if(!isset($queryna[$key1])){echo "0";}else{echo $queryna[$key1];}?></td>
							<td><?php if(!isset($query1[$key1])){echo "0";}else{echo $query1[$key1]; $lesstwentyTotal+=$query1[$key1];}?></td>
							<td><?php if(!isset($query2[$key1])){echo "0";}else{echo $query2[$key1]; $fortyTotal+=$query2[$key1];}?></td>
							<td><?php if(!isset($query3[$key1])){echo "0";}else{echo $query3[$key1]; $sixtyTotal+=$query3[$key1];}?></td>
							<td><?php if(!isset($query4[$key1])){echo "0";}else{echo $query4[$key1]; $eightTotal+=$query4[$key1];}?></td>
							<td><?php if(!isset($query5[$key1])){echo "0";}else{echo $query5[$key1]; $aboveeightyTotal+=$query5[$key1];}?></td>
							
							
							<!--<td><?php if(isset($query1['<=20'])){echo $query1['<=20'];}else{echo "0";} ?></td>
							<td><?php if(isset($query1['20-40'])){echo $query1['20-40'];}else{echo "0";}?></td>
							<td><?php if(isset($query1['40-60'])){echo $query1['40-60'];}else{echo "0";} ?></td>
							<td><?php if(isset($query1['60-80'])){echo $query1['60-80'];}else{echo "0";} ?></td>
							<td><?php if(isset($query1['>80'])){echo $query1['>80'];}else{echo "0";}?></td>-->
						</tr>
				<?php $j++;	} ?>
				</tbody> 
				</table>
			


			<h2 style="text-align:center;" id="unattended">Intervention Report - Unattended User</h2>
			<div style="overflow-x:auto">
			<table id="dataTable7" class="table table-bordered table-condensed table-hover table-striped">
								<thead>
									<tr>
										<th>S.No.</th>
										<th>Name</th>
										<th>Grade</th>
										<th>Section</th>
									</tr>
								</thead>
			<tbody>
			<?php $j=1;
			foreach($NotAttendedUser as $row) {  /* echo "<pre>";print_r($key3); echo "<pre>";print_r($val3);exit; */?>
					<tr>
						<td><?php echo $j; ?></td>
						<td><a href="<?php echo base_url(); ?>index.php/home/studentprofile/<?php echo $row['username']; ?>" style="text-decoration:underline;" ><?php echo $row['fname'] ?></a></td>
						<td><?php echo $row['gradename'] ?></td>
						<td><?php echo $row['section'] ?></td>
					</tr>
			<?php $j++;	} ?>	
			</tbody> 
			</table>
			</div>
	<?php if($filter=='<=20'){  ?>
			<h2 style="text-align:center;" id="twenty">List of students with BSPI <20</h2>
			<div style="overflow-x:auto">
			<table id="dataTable2" class="table table-bordered table-condensed table-hover table-striped">
								<thead>
									<tr>
										<th>S.No.</th>
										<th>Name</th>
										<th>Grade</th>
										<th>Section</th>
										<th>BSPI</th>
									</tr>
								</thead>
			<tbody>
			<?php $j=1;
			foreach($Twenty as $row) {  /* echo "<pre>";print_r($key3); echo "<pre>";print_r($val3);exit; */?>
					<tr>
						<td><?php echo $j; ?></td>
						<td><a href="<?php echo base_url(); ?>index.php/home/studentprofile/<?php echo $row['username']; ?>" style="text-decoration:underline;" ><?php echo $row['name'] ?></a></td>
						<td><?php echo $row['grade'] ?></td>
						<td><?php echo $row['section'] ?></td>
						<td><?php echo round($row['finalscore'],2); ?></td>
					</tr>
			<?php $j++;	} ?>	
			</tbody> 
			</table>
			</div>
	<?php } ?>
	<?php if($filter=='>20and<=40'){  ?>
			<h2 style="text-align:center;" id="forty">List of students with BSPI 20-40</h2>
			<div style="overflow-x:auto">
			<table id="dataTable3" class="table table-bordered table-condensed table-hover table-striped">
								<thead>
									<tr>
										<th>S.No.</th>
										<th>Name</th>
										<th>Grade</th>
										<th>Section</th>
										<th>BSPI</th>
									</tr>
								</thead>
			<tbody>
			<?php $j=1;
			foreach($TwentytoForty as $row) {  /* echo "<pre>";print_r($key3); echo "<pre>";print_r($val3);exit; */?>
					<tr>
						<td><?php echo $j; ?></td>
						<td><a href="<?php echo base_url(); ?>index.php/home/studentprofile/<?php echo $row['username']; ?>" style="text-decoration:underline;" ><?php echo $row['name'] ?></a></td>
						<td><?php echo $row['grade'] ?></td>
						<td><?php echo $row['section'] ?></td>
						<td><?php echo round($row['finalscore'],2); ?></td>
					</tr>
			<?php $j++;	} ?>	
			</tbody> 
			</table>
			</div>
	<?php } ?>
	<?php if($filter=='>40and<=60'){  ?>
			<h2 style="text-align:center;" id="sixty">List of students with BSPI 40-60</h2>
			<div style="overflow-x:auto">
			<table id="dataTable4" class="table table-bordered table-condensed table-hover table-striped">
								<thead>
									<tr>
										<th>S.No.</th>
										<th>Name</th>
										<th>Grade</th>
										<th>Section</th>
										<th>BSPI</th>
									</tr>
								</thead>
			<tbody>
			<?php $j=1;
			foreach($FortytoSixty as $row) {  /* echo "<pre>";print_r($key3); echo "<pre>";print_r($val3);exit; */?>
					<tr>
						<td><?php echo $j; ?></td>
						<td><a href="<?php echo base_url(); ?>index.php/home/studentprofile/<?php echo $row['username']; ?>" style="text-decoration:underline;" ><?php echo $row['name'] ?></a></td>
						<td><?php echo $row['grade'] ?></td>
						<td><?php echo $row['section'] ?></td>
						<td><?php echo round($row['finalscore'],2); ?></td>
					</tr>
			<?php $j++;	} ?>	
			</tbody> 
			</table>
			</div>
	<?php } ?>	
	<?php if($filter=='>60and<=80'){  ?>
			<h2 style="text-align:center;" id="eighty">List of students with BSPI 60-80</h2>
			<div style="overflow-x:auto">
			<table id="dataTable5" class="table table-bordered table-condensed table-hover table-striped">
								<thead>
									<tr>
										<th>S.No.</th>
										<th>Name</th>
										<th>Grade</th>
										<th>Section</th>
										<th>BSPI</th>
									</tr>
								</thead>
			<tbody>
			<?php $j=1;
			foreach($SixtytoEighty as $row) {  /* echo "<pre>";print_r($key3); echo "<pre>";print_r($val3);exit; */?>
					<tr>
						<td><?php echo $j; ?></td>
						<td><a href="<?php echo base_url(); ?>index.php/home/studentprofile/<?php echo $row['username']; ?>" style="text-decoration:underline;" ><?php echo $row['name'] ?></a></td>
						<td><?php echo $row['grade'] ?></td>
						<td><?php echo $row['section'] ?></td>
						<td><?php echo round($row['finalscore'],2); ?></td>
					</tr>
			<?php $j++;	} ?>	
			</tbody> 
			</table>
			</div>
	<?php } ?>	
	<?php if($filter=='>80'){  ?>
			<h2 style="text-align:center;" id="morethaneigthy">List of students with BSPI > 80 </h2>
			<div style="overflow-x:auto">
			<table id="dataTable6" class="table table-bordered table-condensed table-hover table-striped">
								<thead>
									<tr>
										<th>S.No.</th>
										<th>Name</th>
										<th>Grade</th>
										<th>Section</th>
										<th>BSPI</th>
									</tr>
								</thead>
			<tbody>
			<?php $j=1;
			foreach($AboveEighty as $row) {  /* echo "<pre>";print_r($key3); echo "<pre>";print_r($val3);exit; */?>
					<tr>
						<td><?php echo $j; ?></td>
						<td><a href="<?php echo base_url(); ?>index.php/home/studentprofile/<?php echo $row['username']; ?>" style="text-decoration:underline;" ><?php echo $row['name'] ?></a></td>
						<td><?php echo $row['grade'] ?></td>
						<td><?php echo $row['section'] ?></td>
						<td><?php echo round($row['finalscore'],2); ?></td>
					</tr>
			<?php $j++;	} ?>	
			</tbody> 
			</table>
			</div>
	<?php } ?>
		</div>
		
		
	</div>
</div>
</div>
<!--
<link href="../css/jquery.dataTables.css" rel="stylesheet" type="text/css">
<link href="../css/dataTables.tableTools.css" rel="stylesheet" type="text/css">
<script src="../js/jquery.dataTables.js" type="text/javascript"></script>
<script src="../js/dataTables.tableTools.js" type="text/javascript"></script>
-->
<script src="<?php echo base_url(); ?>assets/js/drilldown.js"></script>
<script>


$('#invertionbspianalysis').DataTable( {
	
	"lengthMenu": [[10,  -1], [10,  "All"]],
	
	"footerCallback": function ( row, data, start, end, display ) {
            var api = this.api(), data;
 
            // converting to interger to find total
            var intVal = function ( i ) {
                return typeof i === 'string' ?
                    i.replace(/[\$,]/g, '')*1 :
                    typeof i === 'number' ?
                        i : 0;
            };
 
            // computing column Total of the complete result 
            var userTotal = api
                .column( 1 )
                .data()
                .reduce( function (a, b) {
                    return intVal(a) + intVal(b);
                }, 0 );
				
	    var lesstwentyTotal = api
                .column( 2 )
                .data()
                .reduce( function (a, b) {
                    return intVal(a) + intVal(b);
                }, 0 );
				
            var fortyTotal = api
                .column( 3 )
                .data()
                .reduce( function (a, b) {
                    return intVal(a) + intVal(b);
                }, 0 );
				
	     var sixtyTotal = api
                .column( 4 )
                .data()
                .reduce( function (a, b) {
                    return intVal(a) + intVal(b);
                }, 0 );
				
	     var eightyTotal = api
                .column( 5 )
                .data()
                .reduce( function (a, b) {
                    return intVal(a) + intVal(b);
                }, 0 );
				
				var moreeightyTotal = api
                .column( 6 )
                .data()
                .reduce( function (a, b) {
                    return intVal(a) + intVal(b);
                }, 0 );
				
				var sevenTotal = api
                .column( 7 )
                .data()
                .reduce( function (a, b) {
                    return intVal(a) + intVal(b);
                }, 0 );
				
				var eightTotal = api
                .column( 8 )
                .data()
                .reduce( function (a, b) {
                    return intVal(a) + intVal(b);
                }, 0 );
			
				
            // Update footer by showing the total with the reference of the column index 
	    $( api.column( 0 ).footer() ).html('Total');
            $( api.column( 1 ).footer() ).html(userTotal);
            $( api.column( 2 ).footer() ).html(lesstwentyTotal);
            $( api.column( 3 ).footer() ).html(fortyTotal);
            $( api.column( 4 ).footer() ).html(sixtyTotal);
            $( api.column( 5 ).footer() ).html(eightyTotal);
			$( api.column( 6 ).footer() ).html(moreeightyTotal);
			$( api.column( 7 ).footer() ).html(sevenTotal);
			$( api.column( 8 ).footer() ).html(eightTotal);
        },
	
	
	
	
});

$('#dataTable2').DataTable( {
	
	"lengthMenu": [[10,  -1], [10,  "All"]]
});

$('#dataTable3').DataTable( {
	
	"lengthMenu": [[10,  -1], [10,  "All"]]
});

$('#dataTable4').DataTable( {
	
	"lengthMenu": [[10,  -1], [10,  "All"]]
});

$('#dataTable5').DataTable( {
	
	"lengthMenu": [[10,  -1], [10,  "All"]]
});

$('#dataTable6').DataTable( {
	
	"lengthMenu": [[10,  -1], [10,  "All"]]
});

$('#dataTable7').DataTable( {
	
	"lengthMenu": [[10,  -1], [10,  "All"]]
});

</script>
<style>
.reporttitle { color:#1abb9c; }
thead{ background-color: #1abb9c; color: #fff;}
</style>

<script type="text/javascript">

var filter='<?php echo $filter; ?>';
var categories;
if(filter=='<=20')
{ 
	categories='<=20';
}
else if(filter=='>20and<=40')
{ 
	categories='>20and<=40';
}
else if(filter=='>40and<=60')
{ 
	categories='>40and<=60';
}
else if(filter=='>60and<=80')
{ 
	categories='>60and<=80';
}
else if(filter=='>80')
{ 
	categories='>80';
} 

// Create the chart
Highcharts.chart('intervetionreport', {
    chart: {
        type: 'column'
    },
    title: {
        text: ''
    },
    subtitle: {
        text: ''
    },
    xAxis: {
        type: 'category'
    },
    yAxis: {
        title: {
            text: 'Total percent market share'
        }

    },
    legend: {
        enabled: false
    },
    plotOptions: {
        series: {
            borderWidth: 0,
            dataLabels: {
                enabled: true,
                format: '{point.y:.f}%'
            }
        }
    },

    tooltip: {
        headerFormat: '<span style="font-size:11px">{series.name}</span><br>',
        pointFormat: '<span style="color:{point.color}">{point.name}</span>: <b>{point.y:.2f}%</b> of total<br/>'
    },

    "series": [
        {
            "name": "Grade",
            "colorByPoint": true,
            "data": [
			
			<?php $j=1;
					$lesstwentyTotal=0;$fortyTotal=0;$sixtyTotal=0;$eightTotal=0;$aboveeightyTotal=0;
					foreach($TotalGrade as $row)
					{ 
						$key1=$row['id'];
						$name=$row['classname'];
						if(!isset($q1[$key1])){$lesstwentyTotal=0;}else{$lesstwentyTotal=$q1[$key1];}
						if(!isset($q2[$key1])){$fortyTotal=0;}else{$fortyTotal=$q2[$key1];}
						if(!isset($q3[$key1])){$sixtyTotal=0;}else{$sixtyTotal=$q3[$key1];}
						if(!isset($q4[$key1])){$eightTotal=0;}else{$eightTotal=$q4[$key1];}
						if(!isset($q5[$key1])){$aboveeightyTotal=0;}else{$aboveeightyTotal=$q5[$key1];}
						
						if($filter=='<=20')
						{ 
							$result=$lesstwentyTotal;
						}
						else if($filter=='>20and<=40')
						{ 
							$result=$fortyTotal;
						}
						else if($filter=='>40and<=60')
						{ 
							$result=$sixtyTotal;
						}
						else if($filter=='>60and<=80')
						{ 
							$result=$eightTotal;
						}
						else if($filter=='>80')
						{ 
							$result=$aboveeightyTotal;
						}
					?>
			
                {
                    "name":'<?php echo $row['classname']; ?>',
                    "y": <?php echo $result; ?>,
                    "drilldown":'<?php echo $row['id']; ?>',
                }, 
		<?php } ?>
            ]
        }
    ],
    "drilldown": {
        "series": [
				<?php $j=1;
					$lesstwentyTotal=0;$fortyTotal=0;$sixtyTotal=0;$eightTotal=0;$aboveeightyTotal=0;
					foreach($TotalGradeSec as $row)
					{ 
						$key1=$row['id']."-".$row['section'];
						$name=$row['classname']."-".$row['section'];
						if(!isset($query1[$key1])){$lesstwentyTotal=0;}else{$lesstwentyTotal=$query1[$key1];}
						if(!isset($query2[$key1])){$fortyTotal=0;}else{$fortyTotal=$query2[$key1];}
						if(!isset($query3[$key1])){$sixtyTotal=0;}else{$sixtyTotal=$query3[$key1];}
						if(!isset($query4[$key1])){$eightTotal=0;}else{$eightTotal=$query4[$key1];}
						if(!isset($query5[$key1])){$aboveeightyTotal=0;}else{$aboveeightyTotal=$query5[$key1];}
						
						if($filter=='<=20')
						{ 
							$result=$lesstwentyTotal;
						}
						else if($filter=='>20and<=40')
						{ 
							$result=$fortyTotal;
						}
						else if($filter=='>40and<=60')
						{ 
							$result=$sixtyTotal;
						}
						else if($filter=='>60and<=80')
						{ 
							$result=$eightTotal;
						}
						else if($filter=='>80')
						{ 
							$result=$aboveeightyTotal;
						}
					?>
						{
							"name": "<?php echo $row['classname']; ?>",
							"id": "<?php echo $row['id']; ?>",
							"data": [
								[
									"<?php echo $name; ?>",
									<?php echo $result; ?>
								],
							]
						},
				<?php } ?>
             
        ]
    }
});

$(".in_fl").click(function()
{
	$(".in_fl").removeClass('INActive');
	$(this).addClass('INActive');
	eom_intervention_filter($(this).attr('id'));
});
$("#INchview").click(function(){
	$(".intervetionTbl").hide();$("#intervetionreport").show();
});
$("#INtblview").click(function(){
	$("#intervetionreport").hide();
	$(".intervetionTbl").show();
});

function eom_intervention_filter(filter)
{
	var month=$('#month').val();
	var grade=$('#ddlgradefilter1').val();
	$("#iddivLoading1").show();
	$.ajax({
		type: "POST",
		data: {month:month,grade:grade,filter:filter},
		url: "<?php echo base_url(); ?>index.php/home/eom_intervention", 
		success: function(result)
		{
				$("#iddivLoading1").hide();		
				$('#interventiontab').html('');			
				$('#interventiontab').html(result);
			
		}
	});
}
</script>