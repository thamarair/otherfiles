
<h3>Skill Toppers of each class</h3>
<table id="SkilldataTable" class="table table-bordered table-condensed table-hover table-striped dataTable1">
		<thead style="background-color:#1abb9c; color:#FFF;">
			
			<tr>
				<th>S.No.</th>
				<th>Grade</th>
				<th>Section</th>
				<th>Memory</th>
				<th>Visual Processing</th>
				<th>Focus & Attention</th>
				<th>Problem Solving</th>	
				<th>Linguistics</th>
			</tr>
		</thead>
<?php   $j=1; 
foreach($sections as $section)
{ ?>
	
		
		<tbody>
			<tr>
				<td><?php echo $j; ?></td>
				<td><?php echo $section['classname']; ?></td>
				<td><?php echo $section['section']; ?></td>
				<td><?php echo $aTop[$section['id']."-".$section['section']."-59"][0]['name']." - ".$aTop[$section['id']."-".$section['section']."-59"][0]['score']; ?></td>
				<td><?php echo $aTop[$section['id']."-".$section['section']."-60"][0]['name']." - ".$aTop[$section['id']."-".$section['section']."-60"][0]['score']; ?></td>
				<td><?php echo $aTop[$section['id']."-".$section['section']."-61"][0]['name']." - ".$aTop[$section['id']."-".$section['section']."-61"][0]['score']; ?></td>
				<td><?php echo $aTop[$section['id']."-".$section['section']."-62"][0]['name']." - ".$aTop[$section['id']."-".$section['section']."-62"][0]['score']; ?></td>
				<td><?php echo $aTop[$section['id']."-".$section['section']."-63"][0]['name']." - ".$aTop[$section['id']."-".$section['section']."-63"][0]['score']; ?></td>
			</tr>	
	
<?php $i++; $j++; } 
?>
</tbody>                
</table>
<?php 
 
?>
	

</div>
</div>
</div>
</div>
</div>


<link href="<?php echo base_url(); ?>assets/css/jquery.dataTables.css" rel="stylesheet" type="text/css">
<link href="<?php echo base_url(); ?>assets/css/dataTables.tableTools.css" rel="stylesheet" type="text/css">
<script src="<?php echo base_url(); ?>assets/js/jquery.dataTables.js" type="text/javascript"></script>
<script src="<?php echo base_url(); ?>assets/js/dataTables.tableTools.js" type="text/javascript"></script>
<script>
$('#SkilldataTable').DataTable({
	"lengthMenu": [[10,  -1], [10,  "All"]]
	//"scrollX": true
});
</script>
					