<?php 
/*$background_colors = array('#a226ff', '#fd31a2', '#28d86e', '#f3db2f', '#3141fd', '#f39c2f', '#f32fdb', '#4b3eb7', '#1db9b9', '#b9a61d', '#b91d1d', '#bcc70d');*/
$background_colors = array('#1abb9c', '#73879c', '#1abb9c', '#73879c', '#1abb9c', '#73879c', '#1abb9c', '#73879c', '#1abb9c', '#73879c', '#1abb9c','#73879c');
?>
        <div class="right_col" role="main">
          <!-- top tiles -->
          <div class="row tile_count">
		  <div class="col-md-2 col-sm-2 col-xs-6 tile_stats_count">
               
             </div> 
			<div class="col-md-2 col-sm-2 col-xs-6 tile_stats_count">
              <span class="count_top"><i class="fa fa-user"></i> Total Users</span>
              <div class="count green"><?php echo $totalusers[0]['total']; ?></div>
             </div> 
            <div class="col-md-2 col-sm-2 col-xs-6 tile_stats_count">
              <span class="count_top"><i class="fa fa-puzzle-piece"></i> Puzzles Attempted</span>
              <div class="count "><?php echo $puzzledatas[0]['attempted_question_count']; ?></div>
             </div>
            <div class="col-md-2 col-sm-2 col-xs-6 tile_stats_count">
              <span class="count_top"><i class="fa fa-puzzle-piece"></i> Puzzles Solved</span>
              <div class="count green"><?php echo $puzzledatas[0]['answer_school_count']; ?></div>
             </div>
			 <div class="col-md-2 col-sm-2 col-xs-6 tile_stats_count">
              <span class="count_top"><i class="fa fa-clock-o"></i> Minutes Trained</span>
              <div class="count "><?php echo floor($puzzledatas[0]['gtime_school_count']/60); ?></div>
             </div>
			 <!--<div class="col-md-2 col-sm-2 col-xs-6 tile_stats_count">
              <span class="count_top"><i class="fa fa-gamepad"></i> Average BSPI</span>
              <div class="count green"><?php echo $SchoolAvgBspi['0']['bspi']; ?></div>
             </div>-->
			 <div class="col-md-2 col-sm-2 col-xs-6 tile_stats_count">
				<span class="count_top"><i class="fa fa-user"></i> Start date</span>
				<div class="count "><?php echo date("d-m-Y", strtotime($schooldetails[0]['start_date'])); ?></div> 
            </div>
            <!--<div class="col-md-2 col-sm-4 col-xs-6 tile_stats_count" style="padding-left:10px;">
              <img src="images/bandwidth.png" alt="Profile Image" width="250px" >	
             </div>-->
          </div>
<!-- /top tiles -->
<div class="col-md-12 col-sm-12 col-xs-12">

<div class="row">
<div class="col-md-12 col-sm-12 col-xs-12">
<div class="x_panel tile">
<div class="x_title">
<h2 class="reporttitle">User count by grade</h2>

	<ul class="nav navbar-right panel_toolbox">
        <li><a class="collapse-link bounce"><i class="fa fa-chevron-up"></i></a></li>
     </ul>
	 <div class="clearfix"></div>
</div>
<div class="clearfix"></div>

<div class="x_content" >
<?php $i=0;foreach($gradewiseuserscount as $grade) { ?>
	<div class="animated flipInY col-lg-3 col-md-3 col-sm-6 col-xs-12">
		<a href="<?php echo base_url(); ?>index.php/home/gradeuser/<?php echo $grade['grade_id']; ?>" style="display:block;overflow: hidden;" >
		
		<div class="tile-stats">
			<div class="toppart" style="background-color: <?php echo$background_colors[$i]; ?>;color:#fff;">
			<div class="icon"><i class="fa fa-users"></i></div>
				<div class="count"><?php echo $grade['total']; ?></div>
				<h4><?php  echo $grade['gradename'];?></h4>
			</div>
			<div class="footerpart">
				<p class="pull-left"> View More</p><span class="pull-right"><i style="margin-right:5px" class="fa fa-arrow-circle-right"></i></span>
			</div>
		</div>
		</a>
</div><?php $i++;} ?>
</div>
</div>
</div>

<div class="col-md-12 col-lg-12 col-sm-12 col-xs-12">
<div class="x_panel tile">
<div class="x_title">
<h2 class="reporttitle">Daily session tracker - <?php echo date("d-m-Y"); ?></h2>
<div class="clearfix"></div>
</div>
<div class="clearfix"></div>
	<div id="result"></div>
</div>
</div>
</div>
<!--
<div class="row" id="Monthwise">
	<div class="col-md-12 col-sm-12  col-xs-12">
		  <div class="x_panel tile">
			<div class="x_title">
			  <h2 class="reporttitle monthwiseavgbspi">Average BSPI score by month</h2>
			  <div class="clearfix"></div>
			</div>
			<div class="x_title">
				<div class="gradeFilter1 gf">
					<label>Grade :</label>
					 <select name="ddlgradefilter1" id="ddlgradefilter1" > 
						<option value="">ALL Grades</option>
						<?php $i=0;foreach($gradewiseuserscount as $grade) { ?>
							<option value="<?php echo $grade['grade_id']; ?>"><?php echo $grade['gradename']; ?></option>
						<?php } ?>
					 </select>
				</div>
			</div>
			<div style="display:none; text-align:center;" id="iddivLoading5" class="loading"><img src="<?php echo base_url(); ?>assets/images/ajax-page-loader.gif"  style="width:50px;"  /></div>
			<div id="monthwisebspi"></div>
		  </div>
	</div>
	<div class="col-md-12 col-sm-12 col-xs-12">
	  <div class="x_panel tile">
		<div class="x_title">
		  <h2 class="reporttitle">Average Skill score by month</h2>
		  <div class="clearfix"></div>
		</div>
		<div class="x_title">
		  <input type="button" value="ALL" id="ALL" name="viewreport" class="btn btn-success skillwisescore_M SkillActive" />
			<input type="button" value="M" id="59" name="viewreport" class="btn btn-success skillwisescore_M" />
			<input type="button" value="VP" id="60" name="viewreport" class="btn btn-success skillwisescore_M" />
			<input type="button" value="FA" id="61" name="viewreport" class="btn btn-success skillwisescore_M" />
			<input type="button" value="PS" id="62" name="viewreport" class="btn btn-success skillwisescore_M" />
			<input type="button" value="L" id="63" name="viewreport" class="btn btn-success skillwisescore_M" />
			<div class="gradeFilter2 gf">
				<label>Grade :</label>
				<select name="ddlgradefilter2" id="ddlgradefilter2" > 
						<option value="">ALL Grades</option>
						<?php $i=0;foreach($gradewiseuserscount as $grade) { ?>
							<option value="<?php echo $grade['grade_id']; ?>"><?php echo $grade['gradename']; ?></option>
						<?php } ?>
				</select>
			</div>
		</div>
		<div style="display:none; text-align:center;" id="iddivLoading6" class="loading"><img src="<?php echo base_url(); ?>assets/images/ajax-page-loader.gif"  style="width:50px;"  /></div>
		<div id="monthwiseskillscore"></div>
	  </div>
	</div>
</div>

-->


</div>
<!--
<div class="col-md-4 col-sm-4 col-xs-4">

<div class="row" id="Monthwise">
	<div class="col-md-12 col-sm-12 col-xs-12 ipadwidth">
	  <div class="x_panel tile">
		<div class="x_title">
		  <h2 class="reporttitle">Intervention Report</h2>
 		  
		  <div class="clearfix"></div>
		</div>
		<div style="display:none; text-align:center;" id="iddivLoading7"  class="loading"><img src="<?php echo base_url(); ?>assets/images/ajax-page-loader.gif" style="width:50px;" /></div>
		<div id="intervetionreport"></div>
	  </div>
	</div>
	<div class="col-md-12 col-sm-12 col-xs-12 ipadwidth">
	  <div class="x_panel tile">
		<div class="x_title">
		  <h2 class="reporttitle">BSPI Toppers</h2><div><a class="btn btn-round viewmore" href="<?php echo base_url(); ?>index.php/home/bspitopper" >View More</a></div>
		  
		  <div class="clearfix"></div>
		</div>
		<div style="display:none; text-align:center;" id="iddivLoading3"  class="loading"><img src="<?php echo base_url(); ?>assets/images/ajax-page-loader.gif" style="width:50px;" /></div>
		<div id="bspitopper_rprt" ></div>
	  </div>
	</div>
	
	<div class="col-md-12 col-sm-12 col-xs-12 ipadwidth">
	  <div class="x_panel tile">
		<div class="x_title">
		  <h2 class="reporttitle">Skill Toppers</h2><div><a class="btn btn-round viewmore" href="<?php echo base_url(); ?>index.php/home/skilltopper" >View More</a></div>
		  
		  <div class="clearfix"></div>
		</div>
		<div style="display:none; text-align:center;" id="iddivLoading2"  class="loading"><img src="<?php echo base_url(); ?>assets/images/ajax-page-loader.gif" style="width:50px;" /></div>
		<div id="skilltoppers_rprt" ></div>
	  </div>
	</div>
	
	<div class="col-md-12 col-sm-12 col-xs-12 ipadwidth">
	  <div class="x_panel tile">
		<div class="x_title">
		  <h2 class="reporttitle">Crownies Toppers</h2><div><a class="btn btn-round viewmore" href="<?php echo base_url(); ?>index.php/home/crownytopper" >View More</a></div>
		  
		  <div class="clearfix"></div>
		</div>
		<div style="display:none; text-align:center;" id="iddivLoading4" class="loading"><img src="<?php echo base_url(); ?>assets/images/ajax-page-loader.gif"  style="width:50px;"  /></div>
	   <div id="crownytopper_rprt"></div>
	  </div>
	</div>
</div>

</div> -->
<div class="clearfix"></div>
<div class="row">
	<div class="col-md-12 col-sm-12 col-xs-12">
		<div class="x_panel tile">
			<div class="x_title">
				<h2 class="reporttitle">Weekly time table </h2>
				<ul class="nav navbar-right panel_toolbox">
					<li><a class="collapse-link bounce"><i class="fa fa-chevron-up"></i></a></li>
				 </ul>
				 <div class="clearfix"></div>
			</div>
			<div class="clearfix"></div>
			<div class="x_content" >
			<div style="display:none; text-align:center;" id="iddivLoading11"  class="loading"><img src="<?php echo base_url(); ?>assets/images/ajax-page-loader.gif" style="width:50px;" /></div>
				<div class="row" id="TimeTable-div">
					<div class="col-md-12 col-lg-12 col-sm-12 col-xs-12">
						<div class="col-md-4 col-lg-4 col-sm-4 col-xs-4">
							<ul class="liststyle" style="padding:0">
								<li class="col-md-3 col-lg-3 col-sm-3 col-xs-3">
									<div id="prevmonth" style="background-color:#73879c" class="prevmonth month common" data-monthstartdate="<?php echo date('Y-m-d',strtotime('first day of last month')); ?>" data-monthenddate="<?php echo date('Y-m-d',strtotime('last day of last month')); ?>"><<</div>
								</li>
								<li class="col-md-6 col-lg-6 col-sm-6 col-xs-6">
									<div id="currentmonth" class="currentmonth  common active" data-monthstartdate="<?php echo date('Y-m-01');  ?>" data-monthenddate="<?php echo date('Y-m-t')?>" ><?php echo date('M Y'); ?></div>
									<div id="defaultmonth" class="currentmonth month" data-monthstartdate="<?php echo date('Y-m-01');  ?>" data-monthenddate="<?php echo date('Y-m-t')?>" style="display:none;"><?php echo date('M Y'); ?></div>
								</li>
								<li class="col-md-3 col-lg-3 col-sm-3 col-xs-3">
									<div  id="nextmonth"  style="background-color:#73879c" class="nextmonth month common" data-monthstartdate="<?php echo date('Y-m-d',strtotime('first day of next month'));  ?>" data-monthenddate="<?php echo date('Y-m-d',strtotime('last day of next month')); ?>">>></div>
								</li>
							</ul>
						</div>
						<div class="col-md-8 col-lg-8 col-sm-8 col-xs-8" id="Weekcontent">
							<ul class="liststyle">
								<li class="col-md-20 col-lg-20 col-sm-20 col-xs-20">
									<div class="week common" id="W1" data-startdate="" data-enddate="">WEEK 1</div>
								</li>
								<li class="col-md-20 col-lg-20 col-sm-20 col-xs-20">
									<div class="week common" id="W2" data-startdate="" data-enddate="">WEEK 2</div>
								</li>
								<li class="col-md-20 col-lg-20 col-sm-20 col-xs-20">
									<div class="week common" id="W3" data-startdate="" data-enddate="">WEEK 3</div>
								</li>
								<li class="col-md-20 col-lg-20 col-sm-20 col-xs-20">
									<div class="week common" id="W4" data-startdate="" data-enddate="">WEEK 4</div>
								</li>
								<li class="col-md-20 col-lg-20 col-sm-20 col-xs-20">
									<div class="week common" id="W5" data-startdate="" data-enddate="">WEEK 5</div>
								</li>
							</ul>
						</div>
					</div>
				</div>
				<div id="timetable"></div>
			</div>
		</div>
	</div>
</div>
 
</div>
	
 
        <!-- /page content -->

<script src="<?php echo base_url(); ?>assets/js/jquery.min.js" type="text/javascript"></script>
<script src="<?php echo base_url(); ?>assets/js/highcharts.js"></script>
<script>

$(document).ready(function(){
	
	 todaysession();
	 
	 //timetable();
});
 
function todaysession()
{
	
	$.ajax({
	  url: "<?php echo base_url(); ?>index.php/home/todaysession",
	 // dataType:"json",
	  data:{},
	  success: function(result){
		  $("#result").html(result);
		  
	  }
	});
}

function timetable(startdate,enddate)
{
	$("#iddivLoading11").show();
	$.ajax({
	  url: "<?php echo base_url(); ?>index.php/home/timetable",
	 // dataType:"json",
	  type:"POST",
	  data:{startdate:startdate,enddate:enddate},
	  success: function(result){
		  $("#iddivLoading11").hide();
		  $("#timetable").html(result);
	  }
	});
}
</script>
<script type="text/javascript">
$(document).ready(function(){
	var fromdate=$("#currentmonth").attr('data-monthstartdate');
	var todate=$("#currentmonth").attr('data-monthenddate');
	GetWeeks1(fromdate,todate,'ONLOAD');

$(".month").click(function(){
		$("#currentmonth").addClass(' active');
		if($(this).attr('id')=='prevmonth')
		{
			GetNextPrevMonthDate('PREVMONTHS');
		}
		else if($(this).attr('id')=='nextmonth')
		{
			GetNextPrevMonthDate('NEXTMONTHS');
		}
		$("#selecteddate").html('');
});	
//$(".week").live("click",function(){ 
$(document).on('click','.week',function(e) 
{
	$(".week").removeClass('active');
	$(this).addClass('active');
	startdate=$(this).attr('data-startdate');
	enddate=$(this).attr('data-enddate');
	GetWeekDateData(startdate,enddate);
	GetDateFilter();
});
/* $("#searchstart").click(function(){
		$("#ajaxresult").html('');
		$(".loader").show();
		GetDateFilter();
});
$("#resetstart").click(function(){
	$(".loader").show();
	GetCurrentMonWeek();
	var fromdate=$("#defaultmonth").attr('data-monthstartdate');
	var todate=$("#defaultmonth").attr('data-monthenddate');
	GetWeeks1(fromdate,todate,'ONLOAD');
	$(".searchemptypart1").html('');
}); */
function GetCurrentMonWeek()
{
	$("#currentmonth").attr('data-monthstartdate',$("#defaultmonth").attr('data-monthstartdate'));		
	$("#currentmonth").attr('data-monthenddate',$("#defaultmonth").attr('data-monthenddate'));
	$("#currentmonth").text($("#defaultmonth").text());
}
function GetNextPrevMonthDate(monthtype)
{
	$.ajax({
		 url: "<?php echo base_url(); ?>index.php/home/GetNextPrevMonthDate",
		type:"POST",
		dataType: "json",
		data:{type:monthtype,currentmondate:$("#currentmonth").attr('data-monthstartdate')},
		success:function(result){
		$("#currentmonth").attr('data-monthstartdate',result.start_date);		
		$("#currentmonth").attr('data-monthenddate',result.end_date);
		$("#currentmonth").text(result.monthofyear);
	
		var fromdate=$("#currentmonth").attr('data-monthstartdate');
		var todate=$("#currentmonth").attr('data-monthenddate');
		GetWeeks(fromdate,todate,'');
		}
	});
}
function GetWeeks(fromdate,todate,loadtype)
{
	
	$.ajax({
		 url: "<?php echo base_url(); ?>index.php/home/GetWeeks",
		type:"POST",
		data:{fromdate:fromdate,todate:todate,type:'WEEKS',loadtype:loadtype},
		success:function(result){	//alert(result);			
		 $('#Weekcontent').html(result);
		 GetDateFilter();
		 GetWeekDateData($("#W1").attr('data-startdate'),$("#W1").attr('data-enddate'));
		}
	});
	
}
function GetWeeks1(fromdate,todate,loadtype)
{ 
	$.ajax({
		url: "<?php echo base_url(); ?>index.php/home/GetWeeks",
		type:"POST",
		data:{fromdate:fromdate,todate:todate,type:'WEEKS',loadtype:loadtype},
		success:function(result){	//alert(result);			
		 $('#Weekcontent').html(result);
		 GetDateFilter();
		}
	});
	
}
function GetDateFilter()
{
		var startdate='';
		var enddate='';
		
		$("#Weekcontent .active").each(function(){
			if($(this).hasClass('active'))
			{ 
				if($(this).hasClass('month'))
				{
					startdate=$(this).attr('data-monthstartdate');
					enddate=$(this).attr('data-monthenddate');
				}
				else if($(this).hasClass('week'))
				{ 
					startdate=$(this).attr('data-startdate');
					enddate=$(this).attr('data-enddate');
				}
				//alert("startdate="+startdate+"enddate="+enddate);		
			}
			
		});
			GetTimeTable(startdate,enddate);
}
function GetTimeTable(startdate,enddate)
{
	if(startdate!=''){
	var fd = new Date(startdate);
	var ed = new Date(enddate);
	var sdate=fd.getDate() + '-' + (fd.getMonth() + 1) + '-' +  fd.getFullYear();
	var fdate=ed.getDate() + '-' + (ed.getMonth() + 1) + '-' +  ed.getFullYear();
		$("#selecteddate").html('<div class="success week">'+fd.getDate()+'<sup>'+nth(fd.getDate())+'</sup> - '+ed.getDate()+'<sup>'+nth(ed.getDate())+'</sup></div>');
	}
	timetable(startdate,enddate);	
}
function GetWeekDateData(startdate,enddate)
{ 
	if(startdate!=''){
	var fd = new Date(startdate);
	var ed = new Date(enddate);
	var sdate=fd.getDate() + '-' + (fd.getMonth() + 1) + '-' +  fd.getFullYear();
	var fdate=ed.getDate() + '-' + (ed.getMonth() + 1) + '-' +  ed.getFullYear();
		$("#selecteddate").html('<div class="success week">'+fd.getDate()+'<sup>'+nth(fd.getDate())+'</sup> - '+ed.getDate()+'<sup>'+nth(ed.getDate())+'</sup></div>');
	}
}
function nth(d) {
  if(d>3 && d<21) return 'th'; // thanks kennebec
  switch (d % 10) {
        case 1:  return "st";
        case 2:  return "nd";
        case 3:  return "rd";
        default: return "th";
    }
} 
/* $("#currentmonth").click(function(){
	var orgid=$("#ddorganizationname").val();
	var fromdate=$("#currentmonth").attr('data-monthstartdate');
	var todate=$("#currentmonth").attr('data-monthenddate');
	$(".month").removeClass(' active');
	$(this).addClass(' active');
	GetWeeks(orgid,fromdate,todate);
});	
$("#nextmonth").click(function(){
	var orgid=$("#ddorganizationname").val();
	var fromdate=$("#nextmonth").attr('data-monthstartdate');
	var todate=$("#nextmonth").attr('data-monthenddate');
	$(".month").removeClass(' active');
	$(this).addClass(' active');
	GetWeeks(orgid,fromdate,todate);	
});	
$("#prevmonth").click(function(){
	var orgid=$("#ddorganizationname").val();
	var fromdate=$("#prevmonth").attr('data-monthstartdate');
	var todate=$("#prevmonth").attr('data-monthenddate');
	$(".month").removeClass(' active');
	$(this).addClass(' active');
	GetWeeks(orgid,fromdate,todate);
});	 */
});
monthwisebspi_report();

$("#ddlgradefilter1").change(function(){
	monthwisebspi_report();
});
function monthwisebspi_report()
{
	var grade_id=$("#ddlgradefilter1").val();
	
	$("#iddivLoading5").show();
	$.ajax({
    type: "POST",
	tryCount : 0,
    retryLimit : 3,
	dataType: "json",
	async: true,
    url: "<?php echo base_url(); ?>index.php/home/monthwiseavgbspi",
    data: {type:'monthwisebspi',grade_id:grade_id},
    success: function(result)
	{
		   $("#iddivLoading5").hide();
		/* $('#monthwisebspi').html(result); */
			monthwisebspichart(result);
    }	,
    error : function(xhr, textStatus, errorThrown ) 
	{
        if (textStatus == 'timeout') {
            this.tryCount++;
            if (this.tryCount <= this.retryLimit) {
                //try again
                $.ajax(this);
                return;
            }            
            return;
        }
        if (xhr.status == 500) {
        } else {
        }
    }
	
	});
} 
function monthwisebspichart(result)
{
	if($("#ddlgradefilter1").val()!=''){var TitleContent=$("#ddlgradefilter1 option:selected").text();}else{var TitleContent=''}
	
   $('#monthwisebspi').highcharts({
		chart: {
            type: 'column'
        },
		
        title: {
            text: TitleContent,
            x: -20 //center
        },
        subtitle: {
            text: '',
            x: -20
        },
        xAxis: {
            categories:result.categories
        },
        yAxis: {
            min: 0,tickInterval: 10,max:100,
            title: {
                text: 'Score'
            },
            plotLines: [{
                value: 0,
                width: 1,
                color: '#ff3300'
            }]
        },
        tooltip: {
            valueSuffix: '',
			 shared: true
        },
		plotOptions: {
        column: {
            dataLabels: {
                enabled: true,
                crop: false,
                overflow: 'none'
            }
        }
    },
        credits: {
      enabled: false
  },
        series: [
		
		{
			showInLegend: true,   
			name: 'Training BSPI',
			color: '#1abb9c',
            data:result.data
        },
		{
			name: 'Assessment BSPI',
			type: 'spline',
			color: '#ff9900',
			data: result.asap, 
        }
		
		
		]
    });

}
monthwiseskillscore_report('ALL');
$("#ddlgradefilter2").change(function(){
	var skillid = $(".SkillActive").attr('id');
	monthwiseskillscore_report(skillid);
});
$('.skillwisescore_M').click(function()
{ 
	$('.skillwisescore_M').removeClass('SkillActive');
	$(this).addClass('SkillActive');
	
	var skillid = $(this).attr('id');
	 monthwiseskillscore_report(skillid);
});
function monthwiseskillscore_report(skillid)
{
	$("#iddivLoading6").show();
	
	var grade_id=$("#ddlgradefilter2").val();
	
	$.ajax({
    type: "POST",
	tryCount : 0,
    retryLimit : 3,
    url:  "<?php echo base_url(); ?>index.php/home/monthwiseskillscore",
    data: {type:'monthwiseskillscore',skillid:skillid,grade_id:grade_id},
    success: function(result){
	$("#iddivLoading6").hide();
		$('#monthwiseskillscore').html(result);
    },
    error : function(xhr, textStatus, errorThrown ) 
	{
        if (textStatus == 'timeout') 
		{
            this.tryCount++;
            if (this.tryCount <= this.retryLimit) 
			{
                //try again
                $.ajax(this);
                return;
            }            
            return;
        }
        if (xhr.status == 500) 
		{
        } else 
		{
        }
    }
});
	
}
//intervetionreport();
function intervetionreport()
{
	$("#iddivLoading7").show();	
	$.ajax({
    type: "POST", 
    url:  "<?php echo base_url(); ?>index.php/home/intervetionreport",
    data: {},
    success: function(result)
	{
		$("#iddivLoading7").hide();
		$('#intervetionreport').html(result);
    } 
});
	
}

 

//setTimeout(function() { skilltoppersreport();  }, 10);
//setTimeout(function() { bspitooper_rprt('');  }, 0);
//setTimeout(function() { crownytooper_rprt('');  }, 100);
 $(function(){
   /* $('#skilltoppers_rprt').slimScroll({
        height: '400px',
		alwaysVisible: true
    });*/
});

$(function(){
   /* $('#crownytopper_rprt').slimScroll({
        height: '400px',
		alwaysVisible: false	
    });*/
});

$(function(){
    /*$('#bspitopper_rprt').slimScroll({
        height: '400px',
		alwaysVisible: false
		
		
    });*/
});
function skilltoppersreport()
{
	$("#iddivLoading2").show();
	$.ajax({
    type: "POST",
	tryCount : 0,
    retryLimit : 3,
    url: "<?php echo base_url(); ?>index.php/home/homeskilltopper",
    data: {type:'skilltoppers'},
    success: function(result){
		$("#iddivLoading2").hide();
		$('#skilltoppers_rprt').html(result);
    },
    error : function(xhr, textStatus, errorThrown ) {
		//alert(textStatus);
        if (textStatus == 'timeout') {
            this.tryCount++;
            if (this.tryCount <= this.retryLimit) {
                //try again
                $.ajax(this);
                return;
            }            
            return;
        }
        if (xhr.status == 500) {
        } else {
        }
    }
});
	
}
function bspitooper_rprt()
{
	$("#iddivLoading3").show();
	$.ajax({
    type: "POST",
	tryCount : 0,
    retryLimit : 3,
    url: "<?php echo base_url(); ?>index.php/home/homebspitopper",
    data: {type:'bspitopper'},
    success: function(result){
		$("#iddivLoading3").hide();
	$('#bspitopper_rprt').html(result);
    }
	,
    error : function(xhr, textStatus, errorThrown ) {
        if (textStatus == 'timeout') {
            this.tryCount++;
            if (this.tryCount <= this.retryLimit) {
                //try again
                $.ajax(this);
                return;
            }            
            return;
        }
        if (xhr.status == 500) {
        } else {
        }
    }
});
	
}
function crownytooper_rprt()
{
	$("#iddivLoading4").show();
	$.ajax({
    type: "POST",
	tryCount : 0,
    retryLimit : 3,
    url: "<?php echo base_url(); ?>index.php/home/homecrownytopper",
    data: {type:'crownytopper'},
    success: function(result)
	{
		$("#iddivLoading4").hide();
		$('#crownytopper_rprt').html(result);
    },
    error : function(xhr, textStatus, errorThrown)
	{
        if (textStatus == 'timeout')
		{
            this.tryCount++;
            if (this.tryCount <= this.retryLimit)
			{
                //try again
                $.ajax(this);
                return;
            }            
            return;
        }
        if (xhr.status == 500)
		{
			
        } 
		else
		{
			
        }
    }
});
	
}
 
</script>    
<script src="<?php echo base_url(); ?>assets/js/jquery.slimscroll.js" type="text/javascript"></script>
<style>
td span{line-height:0;}
</style>
