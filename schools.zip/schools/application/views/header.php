<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Skillangels | Schools Admin </title>
	<link href="<?php echo base_url(); ?>assets/css/bootstrap-multiselect.css" type="text/css" />
	<link href="<?php echo base_url(); ?>assets/css/bootstrap.min.css" rel="stylesheet">
    <link href="<?php echo base_url(); ?>assets/css/font-awesome.min.css" rel="stylesheet">
    <link href="<?php echo base_url(); ?>assets/css/nprogress.css" rel="stylesheet">
	<link href="<?php echo base_url(); ?>assets/css/green.css" rel="stylesheet">
	<link href="<?php echo base_url(); ?>assets/css/bootstrap-progressbar-3.3.4.min.css" rel="stylesheet">
	<link href="<?php echo base_url(); ?>assets/css/jqvmap.min.css" rel="stylesheet"/>
	<link href="<?php echo base_url(); ?>assets/css/daterangepicker.css" rel="stylesheet">
	<link href="<?php echo base_url(); ?>assets/css/custom.css" rel="stylesheet"> 
    <link href="<?php echo base_url(); ?>assets/css/animate.min.css" rel="stylesheet">
 
    <link href="<?php echo base_url(); ?>assets/css/jquery.dataTables.css" rel="stylesheet" type="text/css">
    <link href="<?php echo base_url(); ?>assets/css/dataTables.tableTools.css" rel="stylesheet" type="text/css">
	
	   
<body class="nav-md">
    <div class="container body">
      <div class="main_container">
        <div class="col-md-3 left_col">
          <div class="left_col scroll-view">
           

         

            <!-- menu profile quick info -->
            <div class="profile clearfix">
              <div class="profile_pic">
               <a href="javascript:;"><img src="<?php echo base_url(); ?>assets/images/web_logo.png" style="width:150px;" alt="..." class="">
              </div>
             
            </div>
            <!-- /menu profile quick info -->

            <br>
<div id="sidebar-menu" class="main_menu_side hidden-print main_menu">
              <div class="menu_section">
                <ul class="nav side-menu">
                  <li><a id="Dashboard" class="Dashboard menu" href="<?php echo base_url(); ?>index.php/home/dashboard/"><i class="fa fa-home"></i>Dashboard</a>
                        </li>
						<!--<li><a id="EomReports" class="EomReports menu" href="<?php echo base_url(); ?>index.php/home/eom/"><i class="fa fa-table"></i>EOM Report</a>
                        </li>
						<li><a id="BSPI_Toppers" class="EomReports menu" href="<?php echo base_url(); ?>index.php/home/bspitopper/"><i class="fa fa-table"></i>BSPI Toppers</a>
                        </li>
						<li><a id="Skill_Toppers" class="EomReports menu" href="<?php echo base_url(); ?>index.php/home/skilltopper/"><i class="fa fa-table"></i>Skill Toppers</a>
                        </li>
						<li><a id="Crownie_Toppers" class="EomReports menu" href="<?php echo base_url(); ?>index.php/home/crownytopper/"><i class="fa fa-table"></i>Crownie Toppers</a>
                        </li>
						-->
						<li><a id="User_Score" class="EomReports menu" href="<?php echo base_url(); ?>index.php/home/userperformance/"><i class="fa fa-table"></i>User Score</a>
                        </li>
                    </ul>
              </div>

            </div>
			</div>

        </div>

        <!-- top navigation -->
        <div class="top_nav">
          <div class="nav_menu">
            <nav>
              <div class="nav toggle">
                <a id="menu_toggle"><i class="fa fa-bars"></i></a>
              </div>
				
              <ul class="nav navbar-nav navbar-right">
			  <li class="col-sm-6">
				<div class="schooltitle" style="display:inline;"><span style="font-size:20px;" class="topHead"> 
				<?php
				if($this->session->aid=='64')
				{
					echo "Vidyalaya";
				}
				else
				{
					echo $schooldetails[0]['school_name'] ." - ".$schooldetails[0]['country'];
				}


				?>
				
				
				</span></div>
			  </li>
                 <li class="col-sm-3 dateinfo">
					<span class="count_top" ><i class="fa fa-calendar"></i> Academic Year</span><span class="count">  <?php echo $schooldetails[0]['acade_id']; ?></span>
                </li> 
				<li class="col-sm-2 dateinfo">
                  <span class="count_top"><i class="fa fa-calendar"></i> Current Date</span><span class="count">  <?php echo date('d-m-Y'); ?></span>
                </li>
				<li class="col-sm-1 dateinfo"><span class="count_top">
					<a href="<?php echo base_url(); ?>index.php/home/logout" class="" style="font-weight:bold;"><i class="fa fa-power-off" aria-hidden="true"></i> Logout</a></span>
				</li>
               </ul>
			   
            </nav>
          </div>
        </div>
        <!-- /top navigation -->

        <!-- page content -->
        
<style>
.bounce {
    animation: bounce 2s infinite;
    -webkit-animation: bounce 2s infinite;
    -moz-animation: bounce 2s infinite;
    -o-animation: bounce 2s infinite;
}
 
@-webkit-keyframes bounce {
    0%, 20%, 50%, 80%, 100% {-webkit-transform: translateY(0);} 
    40% {-webkit-transform: translateY(-10px);}
    60% {-webkit-transform: translateY(-5px);}
}
 
@-moz-keyframes bounce {
    0%, 20%, 50%, 80%, 100% {-moz-transform: translateY(0);}
    40% {-moz-transform: translateY(-10px);}
    60% {-moz-transform: translateY(-5px);}
}
 
@-o-keyframes bounce {
    0%, 20%, 50%, 80%, 100% {-o-transform: translateY(0);}
    40% {-o-transform: translateY(-10px);}
    60% {-o-transform: translateY(-5px);}
}
@keyframes bounce {
    0%, 20%, 50%, 80%, 100% {transform: translateY(0);}
    40% {transform: translateY(-10px);}
    60% {transform: translateY(-5px);}
}
.panel_toolbox>li>a {
    background: #1abb9c;
}
.panel_toolbox>li>a{color: #ffffff;}
.viewmore {
    float: right;
    margin-top: 5px;
    background-color: #1abb9c;
    color: #fff;
}
.star{color:#fd0303 !important;font-size: 16px;}
.info{color:#f17a87 !important;font-size: 14px;}
.memory_c { color: #ff3300; }
.visual_c { color: #9a1e00; }
.focus_c { color: #ff9900; }
.problem_c { color: #05b923; }
.ling_c { color: #33ccff; }
.countdata {
    background-color: #6f7977;
    padding-top: 10px;
    text-align: center;
    color: #fff;
    min-height: 97px;
}
.newcolor1 {
    background-color: #1abb9c;
}
.countdata label {
    font-size: 17px;
}
.countval {
    display: block;
    font-size: 17px;
    font-weight: bold;
}
.back-button {
    height: 32px;
    border: none;
    background: #635c5c;
    width: 78px;
    line-height: 32px;
    /* -webkit-transform: rotate(-90deg); */
    font-weight: 600;
    color: white;
    /* transform: rotate(-90deg); */
    -ms-transform: rotate(-90deg);
    -moz-transform: rotate(-90deg);
    text-align: center;
    font-size: 17px;
    position: fixed;
    right: -14px;
    top: 12%;
    font-family: "Roboto", helvetica, arial, sans-serif;
    z-index: 999;
	
}
.back-button:hover{  color: white;background: #635c5c;}
</style>
<?php if($returnURL!='' && $this->uri->segment(2)!="dashboard" ){?>
<a id="popup" class="back-button" href="<?php echo $returnURL; ?>">Back</a>
<?php } ?>
<div id="loginloadimage" style="display:none;"></div>

<div id="pwdModal" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true">
  <div class="modal-dialog">
  <div class="modal-content"> 
   <div style="display:none;" id="loadingimg" class="loading"></div>
      <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
		  <h3 class="text-center modalheading"></h3>
		  <div class="col-md-12 col-sm-12 col-xs-12" >
                <div class="panel panel-default">
                    <div class="panel-body">
                        <div class="text-center">
                          <div class="modaldata"></div>
                        </div>
                    </div>
                </div>
            </div>
      </div>
	</div>
  </div>
</div>