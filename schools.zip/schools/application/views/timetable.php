<?php

	$curdate = date("Y-m-d");$curmon='';$curtue='';$curwed='';$curthur='';$curfri='';$cursat='';
    /* $curmon = date("Y-m-d", strtotime('monday this week'));
	$curtue = date("Y-m-d", strtotime('tuesday this week'));
	$curwed = date("Y-m-d", strtotime('wednesday this week'));
	$curthur = date("Y-m-d", strtotime('thursday this week'));
	$curfri = date("Y-m-d", strtotime('friday this week'));
	$cursat = date("Y-m-d", strtotime('saturday this week'));
	
	$curmon = date('Y-m-d',strtotime('last monday'));
	$curtue = date('Y-m-d',strtotime('last tuesday'));
	$curwed = date('Y-m-d',strtotime('last wednesday'));
	$curthur = date('Y-m-d',strtotime('last thursday'));
	$curfri = date('Y-m-d',strtotime('last friday'));
	$cursat = date('Y-m-d',strtotime('last saturday')); */
	$days1=$startdate;
	$days2=date('Y-m-d', strtotime($startdate."+1 days"));
	$days3=date('Y-m-d', strtotime($startdate."+2 days"));
	$days4=date('Y-m-d', strtotime($startdate."+3 days"));
	$days5=date('Y-m-d', strtotime($startdate."+4 days"));
	$days6=date('Y-m-d', strtotime($startdate."+5 days"));
	
	$dayname1=date('l',strtotime($startdate));
	if($days2<=$e1){$dayname2=date('l', strtotime($startdate."+1 days"));}else{$dayname2='';}
	if($days3<=$e1){$dayname3=date('l', strtotime($startdate."+2 days"));}else{$dayname3='';}
	if($days4<=$e1){$dayname4=date('l', strtotime($startdate."+3 days"));}else{$dayname4='';}
	if($days5<=$e1){$dayname5=date('l', strtotime($startdate."+4 days"));}else{$dayname5='';}
	if($days6<=$e1){$dayname6=date('l', strtotime($startdate."+5 days"));}else{$dayname6='';}
	
	
	if($dayname1=='Monday'){$curmon=$days1;}
	else if($dayname1=='Tuesday'){$curtue=$days1;}
	else if($dayname1=='Wednesday'){$curwed=$days1;}
	else if($dayname1=='Thursday'){$curthur=$days1;}
	else if($dayname1=='Friday'){$curfri=$days1;}
	else if($dayname1=='Saturday'){$cursat=$days1;}
	
	if($dayname2=='Monday'){$curmon=$days2;}
	else if($dayname2=='Tuesday'){$curtue=$days2;}
	else if($dayname2=='Wednesday'){$curwed=$days2;}
	else if($dayname2=='Thursday'){$curthur=$days2;}
	else if($dayname2=='Friday'){$curfri=$days2;}
	else if($dayname2=='Saturday'){$cursat=$days2;}
	
	if($dayname3=='Monday'){$curmon=$days3;}
	else if($dayname3=='Tuesday'){$curtue=$days3;}
	else if($dayname3=='Wednesday'){$curwed=$days3;}
	else if($dayname3=='Thursday'){$curthur=$days3;}
	else if($dayname3=='Friday'){$curfri=$days3;}
	else if($dayname3=='Saturday'){$cursat=$days3;}
	
	if($dayname4=='Monday'){$curmon=$days4;}
	else if($dayname4=='Tuesday'){$curtue=$days4;}
	else if($dayname4=='Wednesday'){$curwed=$days4;}
	else if($dayname4=='Thursday'){$curthur=$days4;}
	else if($dayname4=='Friday'){$curfri=$days4;}
	else if($dayname4=='Saturday'){$cursat=$days4;}
	
	if($dayname5=='Monday'){$curmon=$days5;}
	else if($dayname5=='Tuesday'){$curtue=$days5;}
	else if($dayname5=='Wednesday'){$curwed=$days5;}
	else if($dayname5=='Thursday'){$curthur=$days5;}
	else if($dayname5=='Friday'){$curfri=$days5;}
	else if($dayname5=='Saturday'){$cursat=$days5;}
	
	if($dayname6=='Monday'){$curmon=$days6;}
	else if($dayname6=='Tuesday'){$curtue=$days6;}
	else if($dayname6=='Wednesday'){$curwed=$days6;}
	else if($dayname6=='Thursday'){$curthur=$days6;}
	else if($dayname6=='Friday'){$curfri=$days6;}
	else if($dayname6=='Saturday'){$cursat=$days6;}
	
	//echo '<pre>'; print_r($timetable); exit;
	//echo $curmon."==".$curtue."==".$curwed."==".$curthur."==".$curfri."==".$cursat;exit;
 ?>
 <div class="row">
				<div class="col-lg-2" style="text-align: inherit";>
				  <div class='currentday'></div> - Current Day</div>
				  <div class="col-lg-2">
				  <div class='leavedate'></div> - Leave Day</div>
				  </div>
				  
 <table class="table table-striped table-bordered table-hover table-condensed">
					<thead>
					  <tr class="table-info">
						<th>Period/Day</th>
						<th <?php if(in_array($curmon,$LeaveList)){?>class="curday1"<?php } else if(date('Y-m-d')==$curmon){?>class="curday"<?php } else if(in_array($curmon,$LeaveList)){?>class="curday1"<?php } ?>>					
						Mon <?php 
						if($curmon!=''){?><?php  if(date('Y-m-d')==$curmon){ echo '-'.' ' .date('d-m-Y',strtotime($curmon)).'<br/> '.'( Today )'; } else { echo '-'.' '. date('d-m-Y',strtotime($curmon)); } } ?></th>
						
						
						<th <?php if(in_array($curtue,$LeaveList)){?>class="curday1"<?php }  else if(date('Y-m-d')==$curtue) {?>class="curday"<?php } else if(in_array($curtue,$LeaveList)){?>class="curday1"<?php } ?>>
							Tue  <?php 
						if($curtue!=''){?><?php if(date('Y-m-d')==$curtue){ echo '-'.' ' .date("d-m-Y").'<br/> '.'( Today )'; } else { echo '-'.' '. date('d-m-Y',strtotime($curtue)); } }?></th>
						
						
						<th <?php if(in_array($curwed,$LeaveList)){?>class="curday1"<?php } else if(date('Y-m-d')==$curwed) {?>class="curday"<?php } else if(in_array($curwed,$LeaveList)){?>class="curday1"<?php } ?>> Wed <?php 
						if($curwed!=''){?><?php if(date('Y-m-d')==$curwed){ echo '-'.' ' .date("d-m-Y", strtotime($curdate)).'<br/> '.'( Today )'; } else { echo '-'.' '. date('d-m-Y',strtotime($curwed)); } } ?></th>
						
						
						<th <?php if(in_array($curthur,$LeaveList)){?>class="curday1"<?php } else if(date('Y-m-d')==$curthur) {?>class="curday"<?php } else if(in_array($curthur,$LeaveList)){?>class="curday1"<?php } ?>>Thur <?php 
						if($curthur!=''){?><?php if(date('Y-m-d')==$curthur){ echo '-'.' ' .date("d-m-Y").'<br/> '.'( Today )'; } else { echo '-'.' '. date('d-m-Y',strtotime($curthur)); } } ?></th>
						
						
						<th <?php if(in_array($curfri,$LeaveList)){?>class="curday1"<?php } else if(date('Y-m-d')==$curfri) {?>class="curday"<?php } else if(in_array($curfri,$LeaveList)){?>class="curday1"<?php } ?>>Fri <?php 
						if($curfri!=''){?><?php if(date('Y-m-d')==$curfri){ echo '-'.' ' .date("d-m-Y", strtotime($curdate)).'<br/> '.'( Today )'; } else { echo '-'.' '. date('d-m-Y',strtotime($curfri)); } } ?></th>
						
						
						<th <?php if(in_array($cursat,$LeaveList)){?>class="curday1"<?php } else if(date('Y-m-d')==$cursat) {?>class="curday"<?php } else if(in_array($cursat,$LeaveList)){?>class="curday1"<?php } ?>>Sat <?php 
						if($cursat!=''){?><?php if(date('Y-m-d')==$cursat){ echo '-'.' ' .date("d-m-Y").'<br/> '.'( Today )'; } else { echo '-'.' '. date('d-m-Y',strtotime($cursat)); } } ?></th>
					  </tr>
					</thead>
					<tbody>
				<?php 
				
				

				//for ($ini=1;$ini<=10;$ini++){ 
				$ini = 1;
				foreach($timetable as $PeriodList) 
				{
				 if($curmon!='')
				 {
					if(in_array($curmon,$LeaveList)){$classm="curday1";$varmon=$PeriodList['monday_grade']."  ".$PeriodList['monday_section'];}
					
					
					else if(date('Y-m-d')==$curmon){$classm="curday";$varmon="<a href='javascript:;'  style='text-decoration: underline'; title='' rel='tooltip' class='' data-grade='".$PeriodList['monday_grade']."' data-section='".$PeriodList['monday_section']."' data-date='".$curmon."'>".$PeriodList['monday_grade']."  ".$PeriodList['monday_section']."</a>";}
					
					else if(in_array($curmon,$LeaveList)){$classm="curday1";$varmon=$PeriodList['monday_grade']."  ".$PeriodList['monday_section'];}
					
					else{$classm="";$varmon="<a href='javascript:;' title='' rel='tooltip'  style='text-decoration: underline'; class='' data-grade='".$PeriodList['monday_grade']."' data-section='".$PeriodList['monday_section']."' data-date='".$curmon."'>".$PeriodList['monday_grade']."  ".$PeriodList['monday_section']."</a>";}
				 }
				
				/*-------------------------------------------------------------------*/
				if($curtue!='')
				 {
					if(in_array($curtue,$LeaveList)){$classt="curday1";$vartue=$PeriodList['tuesday_grade']."  ".$PeriodList['tuesday_section'];}
					 
					
					else if(date('Y-m-d')==$curtue){$classt="curday";$vartue="<a href='javascript:;'  style='text-decoration: underline'; title='' rel='tooltip' class='over' data-grade='".$PeriodList['tuesday_grade']."' data-section='".$PeriodList['tuesday_section']."' data-date='".$curtue."'>".$PeriodList['tuesday_grade']."  ".$PeriodList['tuesday_section']."</a>";}
					
					else if(in_array($curtue,$LeaveList)){$classt="curday1";$vartue=$PeriodList['tuesday_grade']."  ".$PeriodList['tuesday_section'];}
					 
					
					else{$classt="";$vartue="<a href='javascript:;' title=''  style='text-decoration: underline'; rel='tooltip' class='over' data-grade='".$PeriodList['tuesday_grade']."' data-section='".$PeriodList['tuesday_section']."' data-date='".$curtue."'>".$PeriodList['tuesday_grade']."  ".$PeriodList['tuesday_section']."</a>";}
				 }
				
				/*-------------------------------------------------------------------*/
				if($curwed!='')
				{
					if(in_array($curwed,$LeaveList)){$classw="curday1";$varwed=$PeriodList['wednesday_grade']."  ".$PeriodList['wednesday_section'];}
				
					else if(date('Y-m-d')==$curwed){$classw="curday";$varwed="<a href='javascript:;'  style='text-decoration: underline'; title='' rel='tooltip' class='over' data-grade='".$PeriodList['wednesday_grade']."' data-section='".$PeriodList['wednesday_section']."' data-date='".$curwed."'>".$PeriodList['wednesday_grade']."  ".$PeriodList['wednesday_section']."</a>";}
					
					else  if(in_array($curwed,$LeaveList)){$classw="curday1";$varwed=$PeriodList['wednesday_grade']."  ".$PeriodList['wednesday_section'];}
					
					else{$classw="";$varwed="<a href='javascript:;' title=''  style='text-decoration: underline'; rel='tooltip' class='over' data-grade='".$PeriodList['wednesday_grade']."' data-section='".$PeriodList['wednesday_section']."' data-date='".$curwed."'>".$PeriodList['wednesday_grade']."  ".$PeriodList['wednesday_section']."</a>";}
				}
				/*-------------------------------------------------------------------*/
				if($curthur!='')
				{
					if(in_array($curthur,$LeaveList)){$classth="curday1";$varthr=$PeriodList['thursday_grade']."  ".$PeriodList['thursday_section'];}
						
					else if(date('Y-m-d')==$curthur){$classth="curday";$varthr="<a href='javascript:;'  style='text-decoration: underline'; title='' rel='tooltip' class='over' data-grade='".$PeriodList['thursday_grade']."' data-section='".$PeriodList['thursday_section']."' data-date='".$curthur."'>".$PeriodList['thursday_grade']."  ".$PeriodList['thursday_section']."</a>";}
					
					else if(in_array($curthur,$LeaveList)){$classth="curday1";$varthr=$PeriodList['thursday_grade']."  ".$PeriodList['thursday_section'];}
					
					else{$classth="";$varthr="<a href='javascript:;'  style='text-decoration: underline'; title='' rel='tooltip' class='over' data-grade='".$PeriodList['thursday_grade']."' data-section='".$PeriodList['thursday_section']."' data-date='".$curthur."'>".$PeriodList['thursday_grade']."  ".$PeriodList['thursday_section']."</a>";}
				}
				/*-------------------------------------------------------------------*/
				if($curfri!='')
				{
					if(in_array($curfri,$LeaveList)){$classf="curday1";$varfri=$PeriodList['friday_grade']."  ".$PeriodList['friday_section'];} 
				
					else if(date('Y-m-d')==$curfri){$classf="curday";$varfri="<a href='javascript:;'  style='text-decoration: underline'; title='' rel='tooltip' class='over' data-grade='".$PeriodList['friday_grade']."' data-section='".$PeriodList['friday_section']."' data-date='".$curfri."'>".$PeriodList['friday_grade']."  ".$PeriodList['friday_section']."</a>";}
					 
					else if(in_array($curfri,$LeaveList)){$classf="curday1";$varfri=$PeriodList['friday_grade']."  ".$PeriodList['friday_section'];} 
				
					else{$classf="";$varfri="<a href='javascript:;' title='' rel='tooltip'  style='text-decoration: underline'; class='over' data-grade='".$PeriodList['friday_grade']."' data-section='".$PeriodList['friday_section']."' data-date='".$curfri."'>".$PeriodList['friday_grade']."  ".$PeriodList['friday_section']."</a>";}
				}
				/*-------------------------------------------------------------------*/
				if($cursat!='')
				{
					if(in_array($cursat,$LeaveList)){$classsa="curday1";$varsat=$PeriodList['saturday_grade']."  ".$PeriodList['saturday_section'];} 
					
					else if(date('Y-m-d')==$cursat){$classsa="curday";$varsat="<a href='javascript:;'  style='text-decoration: underline'; title='' rel='tooltip' class='over' data-grade='".$PeriodList['saturday_grade']."' data-section='".$PeriodList['saturday_section']."' data-date='".$cursat."'>".$PeriodList['saturday_grade']."  ".$PeriodList['saturday_section']."</a>";}
					
					else if(in_array($cursat,$LeaveList)){$classsa="curday1";$varsat=$PeriodList['saturday_grade']."  ".$PeriodList['saturday_section'];} 
					
					else{$classsa="";$varsat="<a href='javascript:;' title='' rel='tooltip' class='over'  style='text-decoration: underline'; data-grade='".$PeriodList['saturday_grade']."' data-section='".$PeriodList['saturday_section']."' data-date='".$cursat."'>".$PeriodList['saturday_grade']."  ".$PeriodList['saturday_section']."</a>";}
				}
				/*-------------------------------------------------------------------*/
			
				?>
				  <tr>
				<?php   //date("g:i A", strtotime($bookingTime)); ?>
				
					<td><span style="font-weight:bold">Period</span> <?php if($PeriodList['start_time']!='' && $PeriodList['end_time']!='') { $timing = '('.date("g:i A", strtotime($PeriodList['start_time'])).' - '.date("g:i A", strtotime($PeriodList['end_time'])).')'; } else { $timing='';} echo $ini.'<br/>'.'<span style="font-size:10px">'.$timing."</span>".'<br/>'; if($PeriodList['remarks']!='') { echo $remarks = '['.$PeriodList['remarks'].']'; } else { echo $remarks=''; } ?></td>
					<td class='<?php echo $classm;  ?>'><?php echo $varmon; ?></td>
					<td class='<?php echo $classt;  ?>'><?php echo $vartue; ?></td>
					<td class='<?php echo $classw;  ?>'><?php echo $varwed; ?></td>
					<td class='<?php echo $classth;  ?>'><?php echo $varthr; ?></td>
					<td class='<?php echo $classf;  ?>'><?php echo $varfri; ?></td>
					<td class='<?php echo $classsa;  ?>'><?php echo $varsat; ?></td>
				  </tr>
				<?php $ini++; } ?>
					  
					</tbody>
				  </table>
</div>
</div>











</div>
</div>
</div>

<script>
 $( function()
{ 
    var targets = $( '[rel~=tooltip]' ),
        target  = false,
        tooltip = false,
        title   = false;
 
    targets.bind( 'click', function()
    {  target  = $( this );tip='';
		$(".tooltip").remove();
		var grade=target.attr('data-grade');
		var section=target.attr('data-section');
		var sessiondate=target.attr('data-date');
		 $.ajax({
			url: "<?php echo base_url(); ?>index.php/home/getsessioninfo", 
			//url: "templates/ajax_gradeinfo.php", 
			method:'POST',
			data:{grade:grade,section:section,sessiondate:sessiondate},
			success: function(result)
			{ target.attr( 'title','');
		tip= result;
        tooltip = $( '<div class="tooltip"></div>' );
        if( !tip || tip == '' )
            return false;
 
        target.removeAttr( 'title' );
        tooltip.css( 'opacity', 0 )
               .html( tip )
               .appendTo( 'body' );
 
        var init_tooltip = function()
        {	/* alert($( window ).width() +"<"+ tooltip.outerWidth()); */
            if( $( window ).width() < tooltip.outerWidth() * 1.5 )
				if($( window ).width()<='375')
				{
					tooltip.css( 'max-width', $( window ).width() / 1.5 );
				}
				else
				{
					tooltip.css( 'max-width', $( window ).width() / 2 );
				}
            else
                tooltip.css( 'max-width', 340 );
 
            var pos_left = target.offset().left + ( target.outerWidth() / 2 ) - ( tooltip.outerWidth() / 2 ),
                pos_top  = target.offset().top - tooltip.outerHeight() - 20;
 
            if( pos_left < 0 )
            {
                pos_left = target.offset().left + target.outerWidth() / 2 - 20;
                tooltip.addClass( 'left' );
            }
            else
                tooltip.removeClass( 'left' );
 
            if( pos_left + tooltip.outerWidth() > $( window ).width() )
            {
                pos_left = target.offset().left - tooltip.outerWidth() + target.outerWidth() / 2 + 20;
                tooltip.addClass( 'right' );
            }
            else
                tooltip.removeClass( 'right' );
 
            if( pos_top < 0 )
            {
                var pos_top  = target.offset().top + target.outerHeight();
                tooltip.addClass( 'top' );
            }
            else
                tooltip.removeClass( 'top' );
 
            tooltip.css( { left: pos_left, top: pos_top } )
                   .animate( { top: '+=10', opacity: 1 }, 50 );
        };
 
        init_tooltip();
        $( window ).resize( init_tooltip );
 
        var remove_tooltip = function()
        {
            tooltip.animate( { top: '-=10', opacity: 0 }, 50, function()
            {
                $( this ).remove();
            });
 
            target.attr( 'title', tip );
        };
 
       target.bind( 'click', remove_tooltip );
       //tooltip.bind( 'click', remove_tooltip );
		   $(".closeicon").click(function(){
				$(".tooltip").remove();
			});
	   }
    });
}); 

});

 </script>

<style>
thead {
    background-color: #1abb9c;
    color: #fff;
}

.curday{background-color: #02b0f9 !important;color:#fff;}
.curday1{background-color:#cccccc  !important;color:#fff;}
.curday a{color:#fff;}

.currentday {	box-sizing: border-box;
    background-color: #02b0f9;
    width: 15px;
    height: 13px;
display: inline-block; }

.leavedate {
	box-sizing: border-box;
    background-color: #cccccc;
    width: 15px;
    height: 13px;
    display: inline-block;}

  
/*	ul.top_profiles_small{height:117px;overflow-y: scroll;} */
@media (min-width: 768px)
{
.tile_count .tile_stats_count .count {
    font-size: 22px !important;
}
}

.viewmore {    float: right;
    margin-top: 5px;
    background-color: #1abb9c;
	color: #fff;
}

.viewmore:hover { 
    color: #fff;
}
#GradeDetails .x_panel{height:640px;}
/*#Monthwise .x_panel{height:528px;}*/

 .tooltip
{
    text-align: center;
    color: #fff;
    background: #1abb9c;
    position: absolute;
    z-index: 100;
    padding: 5px; 
	min-height: 160px;
	
	border: 5px solid green;
	border-radius: 10px;
}
.tooltip table thead
{
	border: 1px solid #ddd;
    overflow: hidden;
}
.tooltip table thead th {
    background-color: #2a3f54;
    text-align: center;
    border: 1px solid #ccc;
	padding: 6px;
}
.tooltip table tbody {
    border: 1px solid #ccc;
}
.tooltip table tbody td {
    border: 1px solid #ccc;
}

.closeicon {background-image: url(<?php echo base_url(); ?>assets/images/cross.png);background-repeat: no-repeat;background-position: right top;}
.tooltip a{
	
    cursor: pointer;
	color: #fbff00;
    font-weight: bold;
    text-decoration: underline;
	}
    .tooltip:after /* triangle decoration */
    {
        width: 0;
        height: 0;
        border-left: 10px solid transparent;
        border-right: 10px solid transparent;
        border-top: 10px solid #111;
        content: '';
        position: absolute;
        left: 50%;
        bottom: -10px;
        margin-left: -10px;
    }
 
        .tooltip.top:after
        {
            border-top-color: transparent;
            border-bottom: 10px solid #111;
            top: -20px;
            bottom: auto;
        }
 
        .tooltip.left:after
        {
            left: 10px;
            margin: 0;
        }
 
        .tooltip.right:after
        {
            right: 10px;
            left: auto;
            margin: 0;
        }
	
</style>
<link href="<?php echo base_url(); ?>assets/css/jquery.dataTables.css" rel="stylesheet" type="text/css">
<link href="<?php echo base_url(); ?>assets/css/dataTables.tableTools.css" rel="stylesheet" type="text/css">
<script src="<?php echo base_url(); ?>assets/js/jquery.dataTables.js" type="text/javascript"></script>
<script src="<?php echo base_url(); ?>assets/js/dataTables.tableTools.js" type="text/javascript"></script>
					
					