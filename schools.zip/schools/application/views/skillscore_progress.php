<?php 
		foreach($getmonths as $key1=>$val1) {
			
			$query1[$getmonths[$key1]['monthNumber'].'-'.$getmonths[$key1]['yearName']] =  $val1;
	
		}		
		foreach($getmnthwiseskillscores as $key2=>$val2) {
			
			$query2[$getmnthwiseskillscores[$key2]['monthNumber'].'-'.$getmnthwiseskillscores[$key2]['yearName']] =  $val2;

		} 
		
			
	// echo '<pre>'; print_r($query1);
	//echo '<pre>'; print_r($query2);  
		?>

<script>
	chart = new Highcharts.Chart({
        chart: {
			renderTo: 'skillscoremnthwise<?php echo $skill; ?>',
            type: 'column'
        },
        title: {
            text: ''
        },
        
        xAxis: {
            categories: ['Assessment',<?php $ini=0; foreach($getmonths as $am){
				$ini++;
				if($ini>1){echo ",";}
				echo "'".$am['monthName']."'";
			} ?>,'Post Assessment'],
            crosshair: true,
			max:<?php echo $this->session->month_interval; ?>
        },
		
        yAxis: {
            min: 0,tickInterval: 10,max:100,
            title: {
                text: 'Score'
            }
        },
		
		
       
        plotOptions: {
            column: {
            dataLabels: {
                enabled: true,
                crop: false,
                overflow: 'none'
            }
            }
        },
		credits: {
      enabled: false
  },<?php if($skill==59) { $color='#da0404'; } if($skill==60) { $color='#ffc000'; } if($skill==61) { $color='#92d050'; } if($skill==62) { $color='#ff6600'; } if($skill==63) { $color='#00b0f0'; }?>
        series: [{showInLegend: true,  color:'<?php echo $color; ?>',
            name: 'Month wise scores',
            data: [<?php echo $getasapscore_M[0]['game_score']; ?>,<?php $ini=0; foreach($query1 as $key3=>$val3) { 
				$ini++;
				if($ini>1){echo ",";}
				if(isset($query2[$val3['monthNumber']."-".$val3['yearName']]['gamescore'])){
					
					echo "".round($query2[$val3['monthNumber']."-".$val3['yearName']]['gamescore'],2);
					
					}

					else if($val3['yearName']."".$val3['monthNumber']<=date("Ym")) 
				{ 
					echo 0;
				}
					
					else { echo NULL;}
					
			} ?>,<?php echo NULL; ?>]

        }]
    });
		</script>