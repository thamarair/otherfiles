<option value="">Select Student</option>

<?php $i=0; foreach($studentname as $res) { $i++; ?> 
<option id="<?php echo $res['id']; ?>" value="<?php echo $res['username']; ?>" ><?php echo $res['fname'].'-'.$res['username']; ?></option>
<?php }?>