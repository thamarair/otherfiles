<?php
date_default_timezone_set('Asia/Kolkata');

$compusers[$completeusers['sid']][$completeusers['grade_id']][$completeusers['section']]= $completeusers['cuser'];
	foreach($schools as $key1=>$val1) {
		
		$scklschedule[$schools[$key1]['school_id'].'-'.$schools[$key1]['gradeid'].'-'.$schools[$key1]['section'] ] =  $val1;
	}
	foreach($completeusers as $key2=>$val2) {
		
		$compusers[$completeusers[$key2]['sid'].'-'.$completeusers[$key2]['grade_id'].'-'.$completeusers[$key2]['section'] ] =  $val2;
	}
 ?>
 
 <?php
 if(count($scklschedule)>0)
 {
	 ?>
 <table id="dataTable" class="table table-bordered table-condensed table-hover table-striped dataTable">
                    <thead style="background-color:#1abb9c; color:#FFF;">
						<tr>
							<!--<th>S.No.</th>-->
							<th>Period</th>
							<th>Time</th>
							<th>Class</th>
							<!--<th>Section</th>-->
							<th>No. of students as per schedule</th>
							<th>Logged in User</th>
							<th>Actual attendance for the session</th>
							<!--<th>Attendance %</th>-->
							<th>Actual Completion for the session</th>
							<!--<th>Completion %</th>
							<th>Inference</th>-->
						 </tr>
					 </thead>
		<tbody>
		<?php $i=1;//echo strtotime(date(('H:i:s'))).">=".strtotime('9:00:00');
		
		foreach($scklschedule as $key3=>$val3) {
			
			$scklschedule[$key3]['cccount'] =  $compusers[$key3]['cuser'];
			
			if($compusers[$key3]['cuser']=='') { $completedUser=0; } else { $completedUser=$compusers[$key3]['cuser']; }
			
			if($val3['attendusers']!=0){ $AttendancePer=(($val3['attendusers']*100)/$val3['regusers']);}else{  $AttendancePer="0";  }
			
			if($completedUser!=0){ $CompletionPer=(($completedUser*100)/$val3['attendusers']);}else{ $CompletionPer="0"; }
			
			if($AttendancePer>=90 && $CompletionPer>=80)
			{
				$Inference="Super, keep it up!";
			}
			else if(($AttendancePer>=70 && $AttendancePer<90) && ($CompletionPer>=70&& $CompletionPer<80))
			{
				$Inference="Practice helps! Keep going!";
			}
			else if(($AttendancePer<70 && $AttendancePer>0) && ($CompletionPer<70 && $CompletionPer>0))
			{
				$Inference="Can I assist!";
			}
			else
			{
				if(strtotime(date(('H:i:s')))>strtotime('9:00:00'))
				{
					$Inference="Can I help you?";
				}
				else
				{
					$Inference="Yet to play";
				}
			}
			?>
			
			
			 <tr>
							<!--<td><?php echo $i; ?></td>-->
							<td><?php echo $val3['period']; ?></td>
							<td><?php if($val3['start_time']==''){ echo '-'; } else { echo date("g:i A", strtotime($val3['start_time'])).' - '.date("g:i A", strtotime($val3['end_time'])); } ?><br/><?php if($val3['remarks']!=''){ echo $remarks = '<b>['.$val3['remarks'].']</b>'; } else { echo $remarks=''; }?></td>
							<td><?php echo $val3['grade']." ".$val3['section']; ?></td>
							<!--<td><?php echo $val3['section']; ?></td>-->
							<td><?php echo $val3['regusers']; ?></td>
							<td><?php echo $val3['loginuser']; ?></td>
							<td><?php echo $val3['attendusers']; ?></td>
							<!--<td><?php echo round($AttendancePer,2)." %"; ?></td>-->
							<td><?php echo $completedUser; ?></td>
							<!--<td><?php echo round($CompletionPer,2)." %"; ?></td>
							<td><?php echo $Inference; ?></td>-->
				</tr>			
			
			
	<?php $i++;	} ?>
	
	</tbody>                

	</table>
 <?php } else { ?>
	<h3 class="Nosession text-center">No sessions today</h3>
 
<?php } ?>
<link href="<?php echo base_url(); ?>assets/css/jquery.dataTables.css" rel="stylesheet" type="text/css">
<link href="<?php echo base_url(); ?>assets/css/dataTables.tableTools.css" rel="stylesheet" type="text/css">
<script src="<?php echo base_url(); ?>assets/js/jquery.dataTables.js" type="text/javascript"></script>
<script src="<?php echo base_url(); ?>assets/js/dataTables.tableTools.js" type="text/javascript"></script>
<script>
$('.dataTable').DataTable({
	"lengthMenu": [[10,  -1], [10,  "All"]]
	//"scrollX": true
});
</script>
					