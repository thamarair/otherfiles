	<?php 
	if($aTop!=0)
	{  
	?>
	 
	
	<table id="SkilldataTable" class="table table-bordered table-condensed table-hover table-striped dataTable1">
		<thead style="background-color:#1abb9c; color:#FFF;">
			<tr>
				<th>S.No.</th>
				<th>Grade</th>
			<?php if($filter=='No'){ ?>
				<th>Section</th>
			<?php } ?>
				<th>Memory</th>
				<th>Visual Processing</th>
				<th>Focus & Attention</th>
				<th>Problem Solving</th>	
				<th>Linguistics</th>
			</tr>
		</thead>
		<tbody>
		<?php
		$j=1; 
		foreach($sections as $section)
		{ 
			if($filter=='No')
			{ // Grade and Section Wise
				if(isset($aTop[$section['id']."-".$section['section']."-59"][0]['name']))
				{
					$ME=$aTop[$section['id']."-".$section['section']."-59"][0]['name']." - ".$aTop[$section['id']."-".$section['section']."-59"][0]['score'];
					
					$MEU=$aTop[$section['id']."-".$section['section']."-59"][0]['username'];
					
				}else{$ME="-";$MEU="-";}
				
				if(isset($aTop[$section['id']."-".$section['section']."-60"][0]['name']))
				{
					$VP=$aTop[$section['id']."-".$section['section']."-60"][0]['name']." - ".$aTop[$section['id']."-".$section['section']."-60"][0]['score'];
					
					$VPU=$aTop[$section['id']."-".$section['section']."-60"][0]['username'];
					
				}else{$VP="-";$VPU="-";}
				
				if(isset($aTop[$section['id']."-".$section['section']."-61"][0]['name']))
				{
					$FA=$aTop[$section['id']."-".$section['section']."-61"][0]['name']." - ".$aTop[$section['id']."-".$section['section']."-61"][0]['score'];
					
					$FAU=$aTop[$section['id']."-".$section['section']."-61"][0]['username'];
					
				}else{$FA="-";$FAU="-";}
				
				if(isset($aTop[$section['id']."-".$section['section']."-62"][0]['name']))
				{
					$PS=$aTop[$section['id']."-".$section['section']."-62"][0]['name']." - ".$aTop[$section['id']."-".$section['section']."-62"][0]['score'];
					
					$PSU=$aTop[$section['id']."-".$section['section']."-62"][0]['username'];
					
				}else{$PS="-";$PSU="-";}
				
				if(isset($aTop[$section['id']."-".$section['section']."-63"][0]['name']))
				{
					$LI=$aTop[$section['id']."-".$section['section']."-63"][0]['name']." - ".$aTop[$section['id']."-".$section['section']."-63"][0]['score'];
					
					$LIU=$aTop[$section['id']."-".$section['section']."-63"][0]['username'];
					
				}else{$LI="-";$LIU="-";}
			}
			else
			{// Grade  Wise only
				
				if(isset($aTop[$section['id']."-59"][0]['name']))
				{
					$ME=$aTop[$section['id']."-59"][0]['name']." - ".$aTop[$section['id']."-59"][0]['score'];
					
					$MEU=$aTop[$section['id']."-59"][0]['username'];
					
				}else{$ME="-";$MEU="-";}
				
				if(isset($aTop[$section['id']."-60"][0]['name']))
				{
					$VP=$aTop[$section['id']."-60"][0]['name']." - ".$aTop[$section['id']."-60"][0]['score'];
					
					$VPU=$aTop[$section['id']."-60"][0]['username'];
					
				}else{$VP="-";$VPU="-";}
				
				if(isset($aTop[$section['id']."-61"][0]['name']))
				{
					$FA=$aTop[$section['id']."-61"][0]['name']." - ".$aTop[$section['id']."-61"][0]['score'];
					
					$FAU=$aTop[$section['id']."-61"][0]['username'];
					
				}else{$FA="-";$FAU="-";}
				
				if(isset($aTop[$section['id']."-62"][0]['name']))
				{
					$PS=$aTop[$section['id']."-62"][0]['name']." - ".$aTop[$section['id']."-62"][0]['score'];
					
					$PSU=$aTop[$section['id']."-62"][0]['username'];
					
				}else{$PS="-";$PSU="-";}
				
				if(isset($aTop[$section['id']."-63"][0]['name']))
				{
					$LI=$aTop[$section['id']."-63"][0]['name']." - ".$aTop[$section['id']."-63"][0]['score'];
					
					$LIU=$aTop[$section['id']."-63"][0]['username'];
					
				}else{$LI="-";$LIU="-";}
			}
			
		
		?>
			<tr>
				<td><?php echo $j; ?></td>
				<td><?php echo $section['classname']; ?></td>
				<?php if($filter=='No'){ ?>
				<td><?php echo $section['section']; ?></td>
				<?php } ?>				
				<td><?php echo $ME; ?></td>
				<td><?php echo $VP; ?></td>
				<td><?php echo $FA; ?></td>
				<td><?php echo $PS; ?></td>
				<td><?php echo $LI; ?></td>
			</tr>	
		<?php $i++; $j++; } 
		?>
		</tbody>                
		</table>
	<?php }
		else
		{?>
			<div class="text-center rederror">Please select grade</div>
	<?php } ?>
</div>
</div>
</div>
</div>
</div>


<link href="<?php echo base_url(); ?>assets/css/jquery.dataTables.css" rel="stylesheet" type="text/css">
<link href="<?php echo base_url(); ?>assets/css/dataTables.tableTools.css" rel="stylesheet" type="text/css">
<script src="<?php echo base_url(); ?>assets/js/jquery.dataTables.js" type="text/javascript"></script>
<script src="<?php echo base_url(); ?>assets/js/dataTables.tableTools.js" type="text/javascript"></script>
<script>
$('#SkilldataTable').DataTable({
	"lengthMenu": [[10,  -1], [10,  "All"]]
	//"scrollX": true
});
</script>
					