	<?php 
	if($aTop!=0)
	{
	?>
	 
	
	<table id="BSPIdataTable" class="table table-bordered table-condensed table-hover table-striped dataTable">
		<thead style="background-color:#1abb9c; color:#FFF;">
			
			<tr>
				<th>S.No.</th>
				<th>Grade</th>
				<?php if($filter=='No'){ ?>
					<th>Section</th>
				<?php } ?>
				<th>Name</th>
				<th>BSPI Score</th>
			</tr>
		</thead>
		<tbody>
			<?php $j=1; 
			foreach($sections as $section)
			{
					if($filter=='No')
					{ // Grade and Section Wise
						if(isset($aTop[$section['id']."-".$section['section']][0]['username']))
						{
							$BspiTopperName=$aTop[$section['id']."-".$section['section']][0]['name'];
							$BspiTopperUsername=$aTop[$section['id']."-".$section['section']][0]['username'];
							$BspiTopperScore=$aTop[$section['id']."-".$section['section']][0]['bspi'];
						}
						else
						{
							$BspiTopperName="-";
							$BspiTopperUsername="-";
							$BspiTopperScore="-";
						}
					}
					else
					{// Grade  Wise only
						
						if(isset($aTop[$section['id']][0]['username']))
						{
							$BspiTopperName=$aTop[$section['id']][0]['name'];
							$BspiTopperUsername=$aTop[$section['id']][0]['username'];
							$BspiTopperScore=$aTop[$section['id']][0]['bspi'];
						}
						else
						{
							$BspiTopperName="-";
							$BspiTopperUsername="-";
							$BspiTopperScore="-";
						}
					}
				?>
				<tr>
					<td><?php echo $j; ?></td>
					<td><?php echo $section['classname']; ?></td>
					<?php if($filter=='No'){ ?>
						<td><?php echo $section['section']; ?></td>
					<?php } ?>					
					<td><?php echo $BspiTopperName; ?></td>
					<td><?php echo $BspiTopperScore; ?></td>
				</tr>
	<?php $j++;	} ?>	
		
		</tbody>                
	</table>
	<?php }
		else
		{?>
			<div class="text-center rederror">Please select grade</div>
<?php   } ?>
</div>
</div>
</div>
</div>
</div>


<link href="<?php echo base_url(); ?>assets/css/jquery.dataTables.css" rel="stylesheet" type="text/css">
<link href="<?php echo base_url(); ?>assets/css/dataTables.tableTools.css" rel="stylesheet" type="text/css">
<script src="<?php echo base_url(); ?>assets/js/jquery.dataTables.js" type="text/javascript"></script>
<script src="<?php echo base_url(); ?>assets/js/dataTables.tableTools.js" type="text/javascript"></script>
<script>
$('#BSPIdataTable').DataTable({
	"lengthMenu": [[10,  -1], [10,  "All"]]
	//"scrollX": true
});
</script>
					