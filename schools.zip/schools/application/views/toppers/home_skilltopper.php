<ul class="list-unstyled top_profiles scroll-view">
  <?php foreach($SkilTopper as $topusers) { ?>
  <li class="media event">
	<a class="pull-left <?php if($topusers['gs_id']==59) { echo 'memory_c'; } ?><?php if($topusers['gs_id']==60) { echo 'visual_c'; } ?><?php if($topusers['gs_id']==61) { echo 'focus_c'; } ?><?php if($topusers['gs_id']==62) { echo 'problem_c'; } ?><?php if($topusers['gs_id']==63) { echo 'ling_c'; } ?> profile_thumb">
	  <i class="fa fa-user <?php if($topusers['gs_id']==59) { echo 'memory_c'; } ?><?php if($topusers['gs_id']==60) { echo 'visual_c'; } ?><?php if($topusers['gs_id']==61) { echo 'focus_c'; } ?><?php if($topusers['gs_id']==62) { echo 'problem_c'; } ?><?php if($topusers['gs_id']==63) { echo 'ling_c'; } ?>"></i>
	</a>
	 <div class="media-body">
	 <a href="<?php echo base_url(); ?>index.php/home/studentprofile/<?php echo $topusers['username']; ?>" style="text-decoration:underline;" ><?php echo $topusers['name']; ?></a>
	  <p><strong><?php echo round($topusers['finalscore'], 2); ?></strong> - <?php echo $topusers['skillname'] ?></p>
	  <p> <small><?php echo $topusers['gradename'].' - '.$topusers['section']; ?></small>
	  </p>
	</div>
  </li> <?php } ?>
</ul>