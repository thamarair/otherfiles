<ul class="list-unstyled top_profiles top_profiles_small scroll-view">
<?php foreach($CrownyTopper as $crownytopper) { ?>
<li class="media event">
<a class="pull-left border-green profile_thumb">
<i class="fa fa-user green"></i>
</a>
<div class="media-body">
<a href="<?php echo base_url(); ?>index.php/home/studentprofile/<?php echo $crownytopper['username']; ?>" style="text-decoration:underline;" ><?php echo $crownytopper['name']; ?></a>
<p><strong><?php echo $crownytopper['points']; ?></strong></p>
<p> <small><?php echo $crownytopper['classname'].' - '.$crownytopper['section']; ?></small>
</p>
</div>
</li> <?php } ?>
</ul>