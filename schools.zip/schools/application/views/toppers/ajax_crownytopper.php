	<?php 
	if($aTop!=0)
	{ 
	?>
	 
	
	<table id="CrownydataTable" class="table table-bordered table-condensed table-hover table-striped dataTable1">
		<thead style="background-color:#1abb9c; color:#FFF;">
			<tr>
				<th>S.No.</th>
				<th>Grade</th>
				<?php if($filter=='No'){ ?>
					<th>Section</th>
				<?php } ?>
				<th>Crownies</th> 
		</thead>
		<tbody>
		<?php
		$j=1; 
		foreach($sections as $section)
		{ 
			if($filter=='No')
			{ // Grade and Section Wise
				if(isset($aTop[$section['id']."-".$section['section']][0]['name']))
				{
					$CrownyTopper=$aTop[$section['id']."-".$section['section']][0]['name']." - ".$aTop[$section['id']."-".$section['section']][0]['points'];
					
					$username=$aTop[$section['id']."-".$section['section']][0]['username'];
				}
				else
				{
					$CrownyTopper="-";$username="";
				}
			}
			else
			{// Grade  Wise only
				
				if(isset($aTop[$section['id']][0]['name']))
				{
					$CrownyTopper=$aTop[$section['id']][0]['name']." - ".$aTop[$section['id']][0]['points'];
					
					$username=$aTop[$section['id']][0]['username'];
				}
				else
				{
					$CrownyTopper="-";$username='';
				}
			}
		?>
			<tr>
				<td><?php echo $j; ?></td>
				<td><?php echo $section['classname']; ?></td>
				<?php if($filter=='No'){ ?>
						<td><?php echo $section['section']; ?></td>
				<?php } ?>
				<td><?php echo $CrownyTopper; ?></td>
			</tr>	
		<?php $i++; $j++; } 
		?>
		</tbody>                
		</table>
	<?php }
		else
		{?>
			<div class="text-center rederror">Please select grade</div>
	<?php } ?>
</div>
</div>
</div>
</div>
</div>


<link href="<?php echo base_url(); ?>assets/css/jquery.dataTables.css" rel="stylesheet" type="text/css">
<link href="<?php echo base_url(); ?>assets/css/dataTables.tableTools.css" rel="stylesheet" type="text/css">
<script src="<?php echo base_url(); ?>assets/js/jquery.dataTables.js" type="text/javascript"></script>
<script src="<?php echo base_url(); ?>assets/js/dataTables.tableTools.js" type="text/javascript"></script>
<script>
$('#CrownydataTable').DataTable({
	"lengthMenu": [[10,  -1], [10,  "All"]]
	//"scrollX": true
});
</script>
					