<script src="<?php echo base_url(); ?>assets/js/jquery.min.js" type="text/javascript"></script>
<div class="right_col" role="main">
<!-- top tiles -->

<!-- /top tiles -->
<div class="row">

 
<div class="col-md-12 col-sm-12 col-xs-12">
<div class="x_panel tile">
<div class="x_title">
<h2 class="reporttitle">Crownies Toppers</h2>

	<ul class="nav navbar-right panel_toolbox">
        <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a></li>
     </ul>
	 <div class="clearfix"></div>
</div>
<div class="clearfix"></div>
<div class="x_content">
		<div class="row">
		<div class="col-md-12 col-sm-12 col-xs-12 col-lg-12">
		<form name="frmOverallToppers" id="frmOverallToppers" method="post">
		<div class="panel panel-default">
		<div class="panel-body reportChartContainer">

		<div class="row">
		<div class="col-md-1 col-sm-1 col-xs-2 col-lg-2">

		<label>Grade</label></div>

		<div class="col-md-11 col-sm-11 col-xs-10 col-lg-10">
		<div class="" data-toggle="buttons" id="academicgrades">

		<?php foreach($GradeList as $grades)
		{
		?>
			<label for="genre2" class="btn btn-default btngrades"><?php echo trim(str_replace("Grade",'',$grades['classname'])); ?><input data-value="<?php echo $grades['id']; ?>" class="chkGrade" name="chkGrade"  type="checkbox" /></label>

<?php	} ?>
	
		
		<label><input type="button" name="allgrade" value="Select All" class="select_all btn btn-success"  id="0"  /></label>	
		<label><input type="button" name="allgrade_unselect" value="Un-Select All" class="un_select_all btn btn-success"  id="1"  /></label>
		</div>
		
		<input type="hidden" value="" name="hdnGradeID" id="hdnGradeID" /> 
		</div>
		</div>

		 

		<div class="row">
		<div class="col-md-1 col-sm-1 col-xs-2 col-lg-2">
		<div class="" data-toggle="buttons" id="">
		<label>Filter</label>
		</div></div>

		<div class="col-md-11 col-sm-11 col-xs-10 col-lg-10">
		<div class="" data-toggle="buttons" id="">

		<label for="genre2" class="btn btn-default across">Across all section<input value="Yes"  class="users" name="filter"  type="radio" /></label>

		<label for="genre2" class="btn btn-default sectionwise">Section wise<input value="No"  class="users" name="filter"  type="radio" /></label>

		<input type="button" value="Search" name="btnSearch" id="btnSearch" class="btn btn-success" />	
		<input type="button" value="Reset" onclick="javascript:window.location.href=window.location.href.split('?')[0]+'?act=bspitopper';" name="btnReset" id="btnReset" class="btn btn-warning" />
		</div>
		</div>
		</div>



		</div>
		</div>
		</form>
		</div>
		</div>
		
</div>
<div class="row">
			<div id="bspitoppers"></div>
		</div>
</div>
</div>
 
</div>
</div>
<script>
		$('#academicgrades').find('input').on('change', function() 
		{ 
			var monthval = [];
			$('#academicgrades').find('input:checked').each(function()
			{
				monthval.push($(this).data('value'));
			});
			$('#hdnGradeID').val(monthval.join(','));
			//alert(monthval); 
		});

		$('.select_all').on('click',function()
		{
			$('.chkGrade').each(function(){
				this.checked = true;
				$(this).parent().addClass('active');

			});
			var monthval = [];
			$('#academicgrades').find('input:checked').each(function()
			{
				monthval.push($(this).data('value'));
			});
			$('#hdnGradeID').val(monthval.join(','));
		});
		$('.un_select_all').on('click',function()
		{
			$('.chkGrade').each(function(){ 
				this.checked = false;
				$(this).parent().removeClass('active');
			});
			$('#hdnGradeID').val('');
		});
		 
loadbspi();
function loadbspi()
{ 
	$('.chkGrade').each(function(){
		this.checked = true;
		$(this).parent().addClass('active');

	});
	var monthval = [];
	$('#academicgrades').find('input:checked').each(function()
	{
		monthval.push($(this).data('value'));
	});
	$('#hdnGradeID').val(monthval.join(','));
	
	$('.chkGrade').each(function(){ 
		this.checked = false;
		$(this).parent().removeClass('active');
	});
}
</script>
<script>
$('#btnSearch').click(function(){
crownytoppers();
});

function crownytoppers()
{
	var gradeids = $('#hdnGradeID').val(); 
	var filter = $('input[name=filter]:checked' ).val();	
	$("#loginloadimage").show();
	$.ajax({
	type: "POST",
	url: "<?php echo base_url(); ?>index.php/home/ajax_crownytopper",
	data: {gradeids:gradeids,filter:filter},
	success: function(result){
	//	alert(result);
	$("#loginloadimage").hide();
	$('#bspitoppers').html(result);
	}
	});
}
</script>				
<script>
$(document).ready(function(){
	
		/* $("input[name=allgrade]").click();
		$("input:radio:first").click();
		$(".across input:radio:first").click(); */
		$("#btnSearch").click();
});
</script>
              
			
</div>

 <style>
 .clsListHead{    padding-top: 5px;
    padding-bottom: 5px;
        background-color: #1abb9c;
    color: #fff;}
	.reporttitle { color:#1abb9c; }
	
.rederror
{
	color: red;
    font-size: 17px;
}

.btn-default.active{color: #fff;background-color: #337ab7;border-color: #ffffff;}
</style>
 
  
 