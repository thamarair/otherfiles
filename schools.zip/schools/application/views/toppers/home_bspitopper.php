<ul class="list-unstyled top_profiles top_profiles_small scroll-view">                       
<?php foreach($BspiTopper as $bspitopper) { ?>
	<li class="media event">
	<a class="pull-left border-green profile_thumb">
	<i class="fa fa-user green"></i>
	</a>
	<div class="media-body">
	<a href="<?php echo base_url(); ?>index.php/home/studentprofile/<?php echo $bspitopper['username']; ?>" style="text-decoration:underline;" ><?php echo $bspitopper['name']; ?></a>
	<p><strong><?php echo round($bspitopper['finalscore'], 2); ?></strong></p>
	<p> <small><?php echo $bspitopper['gradename'].' - '.$bspitopper['section']; ?></small>
	</p>
	</div>
	</li> <?php } ?>
</ul>