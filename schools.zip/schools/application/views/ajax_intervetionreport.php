
<script type="text/javascript">
			
Highcharts.chart('intervetionreport', {
    chart: {
        type: 'column'
    },
    title: {
        text: ''
    },
    subtitle: {
        text: ''
    },
    xAxis: {
        categories: [
            '<= 20',
            '> 20 and <= 40',
            '> 40 and <= 60',
            '> 60 and <= 80',
            '> 80'
        ],
        crosshair: true
    },
    yAxis: {
        min: 0,
        title: {
            text: 'No. of users'
        }
    },
    tooltip: {
        headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
        pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
            '<td style="padding:0"><b>{point.y:.f}</b></td></tr>',
        footerFormat: '</table>',
        shared: true,
        useHTML: true
    },
    plotOptions: {
        column: {
            pointPadding: 0.2,
            borderWidth: 0
        }
    },
	credits: {
      enabled: false
  },
    series: [{
        name: 'Assessment',
		color: '#f90',
        data: [<?php echo $scorerange_asap[0]['<=20'];?>,<?php echo $scorerange_asap[0]['20-40'];?>,<?php echo $scorerange_asap[0]['40-60'];?>,<?php echo $scorerange_asap[0]['60-80'];?>,<?php echo $scorerange_asap[0]['>80'];?>]

    }, {
        name: 'Training',
		color: '#1abb9c',
        data: [<?php echo $scorerange_clp[0]['<=20'];?>,<?php echo $scorerange_clp[0]['20-40'];?>,<?php echo $scorerange_clp[0]['40-60'];?>,<?php echo $scorerange_clp[0]['60-80'];?>,<?php echo $scorerange_clp[0]['>80'];?>]

    }]
});
</script>
<div id="intervetionreport"></div>