<?php 
$background_colors = array('#1abb9c', '#73879c', '#1abb9c', '#73879c', '#1abb9c', '#73879c', '#1abb9c', '#73879c', '#1abb9c', '#73879c', '#1abb9c','#73879c');

?>
<div class="right_col" role="main">
<div class="row">
	<div class="col-md-12 col-sm-12 col-xs-12">
		<div class="x_panel tile" style="text-align: center;background: #73879c;color: #fff;padding: 0;">
			<h2 class="reporttitle">User Score</h2> 
		</div>
	</div>
</div>
<div class="row">
	<div class="col-md-12 col-lg-12 col-sm-12 col-xs-12">
		<div class="x_panel tile">
			<div class="x_title">
				<!--<table border="0" cellspacing="5" cellpadding="5">
					<tbody>
						<tr>
							<td><h4>CLP BSPI Start Range:</h4></td>
							<td><input type="text" id="min" name="min"></td>
						
							<td><h4>CLP BSPI end Range:</h4></td>
							<td><input type="text" id="max" name="max"></td>
						</tr>
					</tbody>
				</table>-->
				
			</div>
			<div class="x_content" >
				
				<table id="Userscore" class="table table-bordered table-condensed table-hover table-striped dataTable">
						<thead style="background-color:#1abb9c; color:#FFF;">
							<tr>
								<th>S.No.</th>
								<!--<th>Username</th>-->
								<th class="select-filter">Name</th>
								<th class="select-filter">Grade</th>
								<th class="select-filter">Section</th>
								
								<th >Memory</th>
								<th >Visual Processing</th>
								<th >Focus and Attention</th>
								<th >Problem Solving</th>
								<th >Linguistics</th>
								
								<th >CLP BSPI</th>
								<th >ASAP BSPI</th>
								<th >Improvement %</th>
								<th>Total Question Attended</th>
								<th>Total Correct Answered</th>
								
								<th>Total Time Spend in sec</th>
								<th>Total Time Spend in min</th>
								<th>Scheduled Session</th>
								<th>Attended Session</th>
								<th>Completed Session</th>
								
								<th>ME No. of Times Played</th>
								<th>VP No. of Times Played</th>
								<th>FA No. of Times Played</th>
								<th>PS No. of Times Played</th>
								<th>LI No. of Times Played</th>
							</tr>
						</thead>
						<tfoot >
							<tr>
								<th></th>
								<!--<th></th>-->
								<th></th>
								<th></th>
								<th></th>
								
								<th></th>				
								<th></th>
								<th></th>
								<th></th>
								<th></th>
								
								<th></th>
								<th></th>
								<th></th>
								<th></th>
								<th></th>
								
								<th></th>
								<th></th>
								<th></th>
								<th></th>
								<th></th> 
								
								<th></th>
								<th></th>
								<th></th>
								<th></th>
								<th></th>
						</tr>
					</tfoot>
				<tbody>
				<?php $j=1;
				foreach($userskillscore as $row) {
					// [0] => MAX && [1] => AVG Skill Score
					$ME=explode(",",$row['Memory']);
					$VP=explode(",",$row['VP']);
					$FA=explode(",",$row['FA']);
					$PS=explode(",",$row['PS']);
					$LI=explode(",",$row['LI']);
					
					$clp_bspi=round(($ME[0]+$VP[0]+$FA[0]+$PS[0]+$LI[0])/5,2);
					$asap_bspi=$row['asapbspi'];
					if($clp_bspi>$asap_bspi)
					{
						$growth_percentage=round(((($clp_bspi-$asap_bspi)/$asap_bspi)*100),2);
						$growth_icon="fa fa-arrow-up";
						$growth_color="green";
					}
					else
					{
						$growth_percentage=round(((($asap_bspi-$clp_bspi)/$clp_bspi)*100),2);
						$growth_icon="fa fa-arrow-down";
						$growth_color="red";
					}
					
					$m=$v=$f=$p=$l=0;
					/*  echo "<pre>";print_r($row);exit;  echo "<pre>";print_r($row);exit;  */?>
						<tr>
							<td><?php echo $j; ?></td>
							<!--<td><?php echo $row['username']; ?></td>-->
							<td class="looklikelink" onclick="window.location='<?php echo base_url(); ?>index.php/home/studentprofile/<?php echo $row['username']; ?>'">
								
									<?php echo $row['fname']; ?>
								
							</td>
							<td><?php echo $row['classname']; ?></td>
							<td><?php echo $row['section']; ?></td>
							<td><?php if($ME[1]==''){ echo "-"; $m=0;} else { echo $m=round($ME[1],2);} ?></td>
							<td><?php if($VP[1]==''){ echo "-"; $v=0;} else { echo $v=round($VP[1],2);} ?></td>
							<td><?php if($FA[1]==''){ echo "-"; $f=0;} else { echo $f=round($FA[1],2);} ?></td>
							<td><?php if($PS[1]==''){ echo "-"; $p=0;} else { echo $p=round($PS[1],2);} ?></td>
							<td><?php if($LI[1]==''){ echo "-"; $l=0;} else { echo $l=round($LI[1],2);} ?></td>
				 
							<td><?php echo round(($ME[0]+$VP[0]+$FA[0]+$PS[0]+$LI[0])/5,2); ?></td>
							
							<td><?php echo $row['asapbspi']; ?></td>
							<td><i class="<?php echo $growth_icon; ?>" style="font-size:24px;color:<?php echo $growth_color; ?>"></i>  <?php echo $growth_percentage; ?></td>
							<td><?php echo $row['attempt_question']; ?></td>
							<td><?php echo $row['answer']; ?></td>
							<td><?php echo $row['rtime']; ?></td>
							<td><?php echo floor($row['rtime']/60); ?></td>
							<td><?php echo $row['scheduled_session']; ?></td>
							<td><?php echo $row['AttendedSession']; ?></td>
							<td><?php echo $row['CompletedSession']; ?></td>
							
							<td><?php echo $row['MEnoftimesplayed']; ?></td>
							<td><?php echo $row['VPnoftimesplayed']; ?></td>
							<td><?php echo $row['FAnoftimesplayed']; ?></td>
							<td><?php echo $row['PSnoftimesplayed']; ?></td>
							<td><?php echo $row['LInoftimesplayed']; ?></td>
						</tr>
				<?php $j++;	} ?>	
				</tbody> 
			</table>
			</div>
		</div>
	</div>
</div>
	 
<div class="clearfix"></div>
</div>
<style>
.dataTables_wrapper{overflow: auto;}
#Userscore tfoot{display: table-header-group;background: #1abb9c;}
.looklikelink {
    color: #0048bc;
    text-decoration: underline;    cursor: pointer;
}
#UserScore select {
	width: 100%;
    color: #1abb9c;
    border: 2px solid;
    font-weight: bold;
	font-size:20px;
}
</style>
<script src="<?php echo base_url(); ?>assets/js/jquery.min.js" type="text/javascript"></script>
<link href="<?php echo base_url(); ?>assets/css/jquery.dataTables.css" rel="stylesheet" type="text/css">
	<link href="<?php echo base_url(); ?>assets/css/dataTables.tableTools.css" rel="stylesheet" type="text/css">
	<script src="<?php echo base_url(); ?>assets/js/jquery.min.js" type="text/javascript"></script>
	<script src="<?php echo base_url(); ?>assets/js/jquery.dataTables.js" type="text/javascript"></script>
	<script src="<?php echo base_url(); ?>assets/js/dataTables.tableTools.js" type="text/javascript"></script>
	<script>

	$(document).ready(function() {
		var table = $('#Userscore').DataTable( {
			"order": [[ 9, "desc" ]],
			initComplete: function () {
				this.api().columns('.select-filter').every( function () {
					var column = this; //console.log(column);
					var select = $('<select><option value=""></option></select>')
						.appendTo( $(column.footer()).empty() )
						.on( 'change', function () {
							var val = $.fn.dataTable.util.escapeRegex(
								$(this).val()
							);
							column.search( val ? '^'+val+'$' : '', true, false ).draw();
						});
					column.data().unique().sort().each( function ( d, j ) 
					{
						select.append( '<option value="'+d+'">'+d+'</option>')
					});
				});
			},
			"rowCallback": function (nRow, aData, iDisplayIndex) {
				 var oSettings = this.fnSettings ();
				 $("td:first", nRow).html(oSettings._iDisplayStart+iDisplayIndex +1);
				 return nRow;
			}
		} );
		 $('#min, #max').keyup( function() {
			table.draw();
		});
		$.fn.dataTable.ext.search.push(
			function( settings, data, dataIndex ) {
				var min = parseInt( $('#min').val(), 10 );
				var max = parseInt( $('#max').val(), 10 );
				var age = parseFloat( data[9] ) || 0; // use data for the age column
		 
				if ( ( isNaN( min ) && isNaN( max ) ) ||
					 ( isNaN( min ) && age <= max ) ||
					 ( min <= age   && isNaN( max ) ) ||
					 ( min <= age   && age <= max ) )
				{
					return true;
				}
				return false;
			});
		});
	
</script> 