<option value="">Select Section</option>

<?php $i=0; foreach($getsection as $res) { $i++; ?> 
<option id="<?php echo $res['section']; ?>" value="<?php echo $res['section']; ?>" ><?php echo $res['section']; ?></option>
<?php }?>