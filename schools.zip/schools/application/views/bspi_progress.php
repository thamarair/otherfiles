<?php 

		foreach($getmonths as $key1=>$val1) {
			
			$query1[$getmonths[$key1]['monthNumber'].'-'.$getmonths[$key1]['yearName']] =  $val1;
	
		}		
		foreach($getmnthwisebspi as $key2=>$val2) {
			
			$query2[$getmnthwisebspi[$key2]['monthNumber'].'-'.$getmnthwisebspi[$key2]['yearName']] =  $val2;

		} 
		foreach($getmnthwisebspi_topscore as $key4=>$val4) {
			
			$query4[$getmnthwisebspi_topscore[$key4]['monthNumber'].'-'.$getmnthwisebspi_topscore[$key4]['yearName']] =  $val4;

		} 
	/* echo '<pre>'; print_r($query1);
	echo '<pre>'; print_r($query2);  */
		?>

<script>

	chart = new Highcharts.Chart({
        chart: {
			renderTo: 'chartOverallPerformance',
            type: 'column'
        },
        title: {
            text: ''
        },
        
        xAxis: {
            categories: ['Assessment',
			<?php $ini=0; foreach($getmonths as $am){
				$ini++;
				if($ini>1){echo ",";}
				echo "'".$am['monthName']."'";
			} ?>,'Post Assessment'
                
            ],
            crosshair: true,
			max:<?php echo $this->session->month_interval; ?>
        },
		
        yAxis: {
            min: 0,tickInterval: 10,max:100,
            title: {
                text: 'Score'
            }
        },
		
		
       
        plotOptions: {
            column: {
            dataLabels: {
                enabled: true,
                crop: false,
                overflow: 'none'
            }
            }
        },
		credits: {
      enabled: false
  },
        series: [{showInLegend: true,  color:"blue",
            name: 'BSPI Score',
            data: [<?php if(isset($asapbspi[0]['bspi'])) { echo $asapbspi[0]['bspi']; } else { echo NULL; } ?>,
			<?php $ini=0; foreach($query1 as $key3=>$val3) { 
				$ini++;
				if($ini>1){echo ",";}
				if(isset($query2[$val3['monthNumber']."-".$val3['yearName']]['finalscore']))
				
				{
					echo "".$query2[$val3['monthNumber']."-".$val3['yearName']]['finalscore'];
					
				}
				
				else if($val3['yearName']."".$val3['monthNumber']<=date("Ym")) 
				{ 
					echo 0;
				}
				
				else{
					
				echo NULL;
				
				}
			} ?>,<?php echo NULL; ?>
			
			]

        },
		{showInLegend: true,  color:"green",
            name: 'High Score',
            data: [<?php if(isset($max_asapbspi[0]['highscore'])) { echo $max_asapbspi[0]['highscore']; } else { echo NULL; }   ?>,
			<?php $ini=0; foreach($query1 as $key3=>$val5) { 
				$ini++;
				if($ini>1){echo ",";}
				if(isset($query4[$val5['monthNumber']."-".$val5['yearName']]['finalscore']))
				{
					
					echo "".$query4[$val5['monthNumber']."-".$val5['yearName']]['finalscore'];
					
				}
				
				else if($val5['yearName']."".$val5['monthNumber']<=date("Ym")) 
				{ 
					echo 0;
				}
				
				
				else{
					
					echo NULL;
					
					}
			} ?>,<?php echo NULL; ?>
			
			]

        }]
    });

		</script>