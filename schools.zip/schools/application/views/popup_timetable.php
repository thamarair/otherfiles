<div class="closeicon">
<div class="info"><h3><?php echo $grade.'-'.$section; ?></h3></div></div>
<table>
<thead>
<tr><th>Registered Users</th><th>Attended Users</th><th>Completed Users</th></tr>
</thead>
<tbody>
<tr>
<td><?php echo $regusers[0]['registereduser']; ?></td><td><?php echo $trainingtaken[0]['TrainingTaken']; ?></td><td><?php echo $trainingfullytaken[0]['TrainingFullyTaken']; ?></td>
</tr>
<!--<tr><a target="_blank" href="<?php echo base_url(); ?>index.php/home/sessiondetails/<?php echo $grade; ?>/<?php echo $section; ?>/<?php echo $sessiondate; ?>">View More</a></tr>-->
</tbody>
</table>