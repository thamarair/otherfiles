	<h3>BSPI Toppers of each class</h3>
	<table id="BSPIdataTable" class="table table-bordered table-condensed table-hover table-striped dataTable">
		<thead style="background-color:#1abb9c; color:#FFF;">
			
			<tr>
				<th>S.No.</th>
				<th>Grade</th>
				<th>Section</th>
				<th>Name</th>
				<th>BSPI Score</th>
			</tr>
		</thead>
		<tbody>
		<?php $j=1; //echo "<pre>";print_r($bspitopper_gradewise);exit;
		foreach($bspitopper_gradewise as $row) {?>
			<tr>
				<td><?php echo $j; ?></td>
				<td><?php echo $row['classname']; ?></td>
				<td><?php echo $row['section']; ?></td>
				<td><?php echo $row['username']; ?></td>
				<td><?php echo $row['bspi']; ?></td>
			</tr>
		<?php $j++;	} ?>	
	
	</tbody>                
					</table>

</div>
</div>
</div>
</div>
</div>


<link href="<?php echo base_url(); ?>assets/css/jquery.dataTables.css" rel="stylesheet" type="text/css">
<link href="<?php echo base_url(); ?>assets/css/dataTables.tableTools.css" rel="stylesheet" type="text/css">
<script src="<?php echo base_url(); ?>assets/js/jquery.dataTables.js" type="text/javascript"></script>
<script src="<?php echo base_url(); ?>assets/js/dataTables.tableTools.js" type="text/javascript"></script>
<script>
$('#BSPIdataTable').DataTable({
	"lengthMenu": [[10,  -1], [10,  "All"]]
	//"scrollX": true
});
</script>
					