<div class="right_col" role="main">
<div class="row">
<div class="col-md-12 col-sm-12 col-xs-12">
<div class="x_panel tile">
<div class="x_title">
<h2 class="reporttitle">User Performance</h2>

<h2 class="reporttitle"></h2>
<div class="clearfix"></div>
</div>
<div class="clearfix"></div>

	 
</div>
</div>
	 
		
		 </div>
 <div class="loading" style="display:none;" ><img src="<?php echo base_url(); ?>assets/images/ajax-page-loader.gif" style="width:80px;" /></div>
<div id="clpresult"></div> 
</div>		
		

<link href="<?php echo base_url(); ?>assets/css/jquery.dataTables.css" rel="stylesheet" type="text/css">
<link href="<?php echo base_url(); ?>assets/css/dataTables.tableTools.css" rel="stylesheet" type="text/css">
<script src="<?php echo base_url(); ?>assets/js/jquery.min.js" type="text/javascript"></script>
<script src="<?php echo base_url(); ?>assets/js/jquery.dataTables.js" type="text/javascript"></script>
<script src="<?php echo base_url(); ?>assets/js/dataTables.tableTools.js" type="text/javascript"></script>
<script>
$(document).ready(function(){		$('.loading').show();
	$.ajax	({			type:"POST",			url:"<?php echo base_url()."index.php/home/clp_userperformance"; ?>",			data:{},			success:function(result)			{				//alert ('success');				$('.loading').hide();				$('#clpresult').html(result);			}	});
});</script>
<style>
.reporttitle { color:#1abb9c; }
thead{ background-color: #1abb9c; color: #fff;}
body{ padding-right: 0px !important; }
body.modal-open { padding-right: 0px !important; }
.modal-content {width: 70%;margin: 0 auto;}
.modaldata table{margin: 0 auto;}
.modaldata td{text-align:justify;}
.modalheading{color: #0d77de;font-weight: bold;}
.panel-default{border-color: #5187bd;background: #3d6a96;color: #fff;}

.loading {
  position: fixed;
  z-index: 999;
  height: 2em;
  width: 2em;
  overflow: show;
  margin: auto;
  top: 0;
  left: 0;
  bottom: 0;
  right: 0;
}

.loading:before {
  content: '';
  display: block;
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background-color: rgba(0,0,0,0.3);
}

/* :not(:required) hides these rules from IE9 and below */
.loading:not(:required) {
  /* hide "loading..." text */
  font: 0/0 a;
  color: transparent;
  text-shadow: none;
  background-color: transparent;
  border: 0;
}
</style>
