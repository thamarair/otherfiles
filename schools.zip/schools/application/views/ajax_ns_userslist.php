<div class="row">
	<div class="col-md-12 col-lg-12 col-sm-12 col-xs-12">
		<div class="x_panel tile">
			<div class="x_title">
				<h2 class="reporttitle"><?php echo $title; ?> - <?php echo $loguserslist[0]['gradename'].' '.$loguserslist[0]['section']; ?></h2>
				<div class="clearfix"></div>
			</div>
			<div class="x_content" >
			<table id="dataTable_N" class="table table-bordered table-condensed table-hover table-striped dataTable_N">
						<thead style="background-color:#1abb9c; color:#FFF;">
							<tr>
								<th>S.No.</th>
								<th>Student name</th>
							</tr>
						</thead>
						<tfoot>
            <tr>
                <th></th>
                <th></th>
            </tr>
        </tfoot>
	<tbody>
		<?php $i=1;
		foreach($loguserslist as $res) {	?>
			
			
			 <tr>
			 <td><?php echo $i; ?></td>
			 <td><?php echo $res['name']; ?></td>
			 </tr>			
			
			
	<?php $i++;	} ?>
	
	</tbody>   
		
	</table>
	 
	

	
	<script> 
	
	$(document).ready(function() {
		$('#dataTable_N').DataTable( {
			"lengthMenu": [[10,  -1], [10,  "All"]],
			initComplete: function () {
				this.api().columns().every( function () {
					var column = this; //console.log(column);
					var select = $('<select><option value=""></option></select>')
						.appendTo( $(column.footer()).empty() )
						.on( 'change', function () {
							var val = $.fn.dataTable.util.escapeRegex(
								$(this).val()
							);
	 
							column
								.search( val ? '^'+val+'$' : '', true, false )
								.draw();
						} );
	 
					column.data().unique().sort().each( function ( d, j ) {
						select.append( '<option value="'+d+'">'+d+'</option>' )
					} );
				});
			}
		} );
	});
	</script>
				</div>
			</div>
		</div>
	</div>
<style>
.dataTables_wrapper{overflow: auto;}
#dataTable_N tfoot{display: table-header-group;}

.loading {
  position: fixed;
  z-index: 999;
  height: 2em;
  width: 2em;
  overflow: show;
  margin: auto;
  top: 0;
  left: 0;
  bottom: 0;
  right: 0;
}

.loading:before {
  content: '';
  display: block;
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background-color: rgba(0,0,0,0.3);
}

/* :not(:required) hides these rules from IE9 and below */
.loading:not(:required) {
  /* hide "loading..." text */
  font: 0/0 a;
  color: transparent;
  text-shadow: none;
  background-color: transparent;
  border: 0;
}
</style>