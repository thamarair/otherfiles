<?php
$curdate = date("d-m-Y");
    $curmon = date("d-m-Y", strtotime('monday this week'));
	$curtue = date("d-m-Y", strtotime('tuesday this week'));
	$curwed = date("d-m-Y", strtotime('wednesday this week'));
	$curthur = date("d-m-Y", strtotime('thursday this week'));
	$curfri = date("d-m-Y", strtotime('friday this week'));
	$cursat = date("d-m-Y", strtotime('saturday this week'));
	
	$lastmon = date('d-m-Y',strtotime('last monday'));
	$lastue = date('d-m-Y',strtotime('last tuesday'));
	$lastwed = date('d-m-Y',strtotime('last wednesday'));
	$lastthur = date('d-m-Y',strtotime('last thursday'));
	$lastfri = date('d-m-Y',strtotime('last friday'));
	$lastsat = date('d-m-Y',strtotime('last saturday'));
	
	
 ?>
 
 <table class="table table-striped table-bordered table-hover table-condensed">
					<thead>
					  <tr class="table-info">
						<th>Period/Day</th>
						<th <?php if(in_array($curmon,$LeaveList)){?>class="curday1"<?php } else if(strcasecmp('monday',date('l'))==0){?>class="curday"<?php } else if(in_array($lastmon,$LeaveList)){?>class="curday1"<?php } ?>>Mon <?php  if(strcasecmp('monday',date('l'))==0){ echo '-'.' ' .date("d-m-Y").'<br/> '.'( Today )'; } else { echo '-'.' '. date('d-m-Y',strtotime('last monday')); } ?></th>
						
						
						<th <?php if(in_array($curtue,$LeaveList)){?>class="curday1"<?php }  else if(strcasecmp('tuesday',date('l'))==0) {?>class="curday"<?php } else if(in_array($lastue,$LeaveList)){?>class="curday1"<?php } ?>>Tue  <?php if(strcasecmp('tuesday',date('l'))==0){ echo '-'.' ' .date("d-m-Y").'<br/> '.'( Today )'; } else { echo '-'.' '. date('d-m-Y',strtotime('last tuesday')); } ?></th>
						
						
						<th <?php if(in_array($curwed,$LeaveList)){?>class="curday1"<?php } else if(strcasecmp('wednesday',date('l'))==0) {?>class="curday"<?php } else if(in_array($lastwed,$LeaveList)){?>class="curday1"<?php } ?>>Wed <?php if(strcasecmp('wednesday',date('l'))==0){ echo '-'.' ' .date("d-m-Y", strtotime($curdate)).'<br/> '.'( Today )'; } else { echo '-'.' '. date('d-m-Y',strtotime('last wednesday')); } ?></th>
						
						
						<th <?php if(in_array($curthur,$LeaveList)){?>class="curday1"<?php } else if(strcasecmp('thursday',date('l'))==0) {?>class="curday"<?php } else if(in_array($lastthur,$LeaveList)){?>class="curday1"<?php } ?>>Thur <?php if(strcasecmp('thursday',date('l'))==0){ echo '-'.' ' .date("d-m-Y").'<br/> '.'( Today )'; } else { echo '-'.' '. date('d-m-Y',strtotime('last thursday')); } ?></th>
						
						
						<th <?php if(in_array($curfri,$LeaveList)){?>class="curday1"<?php } else if(strcasecmp('friday',date('l'))==0) {?>class="curday"<?php } else if(in_array($lastfri,$LeaveList)){?>class="curday1"<?php } ?>>Fri <?php if(strcasecmp('friday',date('l'))==0){ echo '-'.' ' .date("d-m-Y", strtotime($curdate)).'<br/> '.'( Today )'; } else { echo '-'.' '. date('d-m-Y',strtotime('last friday')); } ?></th>
						
						
						<th <?php if(in_array($cursat,$LeaveList)){?>class="curday1"<?php } else if(strcasecmp('saturday',date('l'))==0) {?>class="curday"<?php } else if(in_array($lastsat,$LeaveList)){?>class="curday1"<?php } ?>>Sat <?php if(strcasecmp('saturday',date('l'))==0){ echo '-'.' ' .date("d-m-Y").'<br/> '.'( Today )'; } else { echo '-'.' '. date('d-m-Y',strtotime('last saturday')); } ?></th>
					  </tr>
					</thead>
					<tbody>
					<?php 
					
					

					for ($ini=1;$ini<=10;$ini++){ 
					
					
					if(in_array($curmon,$LeaveList)){$classm="curday1";$varmon=$PeriodList[$ini]['monday_grade']."  ".$PeriodList[$ini]['monday_section'];}
					
					
					else if(strcasecmp('monday',date('l'))==0){$classm="curday";$varmon="<a href='javascript:;'  style='text-decoration: underline'; title='' rel='tooltip' class='' data-grade='".$PeriodList[$ini]['monday_grade']."' data-section='".$PeriodList[$ini]['monday_section']."' data-date='".date('Y-m-d')."'>".$PeriodList[$ini]['monday_grade']."  ".$PeriodList[$ini]['monday_section']."</a>";}
					
					else if(in_array($lastmon,$LeaveList)){$classm="curday1";$varmon=$PeriodList[$ini]['monday_grade']."  ".$PeriodList[$ini]['monday_section'];}
					
					else{$classm="";$varmon="<a href='javascript:;' title='' rel='tooltip'  style='text-decoration: underline'; class='' data-grade='".$PeriodList[$ini]['monday_grade']."' data-section='".$PeriodList[$ini]['monday_section']."' data-date='".date('Y-m-d',strtotime('last monday'))."'>".$PeriodList[$ini]['monday_grade']."  ".$PeriodList[$ini]['monday_section']."</a>";}
					
					/*-------------------------------------------------------------------*/
					 if(in_array($curtue,$LeaveList)){$classt="curday1";$vartue=$PeriodList[$ini]['tuesday_grade']."  ".$PeriodList[$ini]['tuesday_section'];}
					 
					
					else if(strcasecmp('tuesday',date('l'))==0){$classt="curday";$vartue="<a href='javascript:;'  style='text-decoration: underline'; title='' rel='tooltip' class='over' data-grade='".$PeriodList[$ini]['tuesday_grade']."' data-section='".$PeriodList[$ini]['tuesday_section']."' data-date='".date('Y-m-d')."'>".$PeriodList[$ini]['tuesday_grade']."  ".$PeriodList[$ini]['tuesday_section']."</a>";}
					
					else if(in_array($lastue,$LeaveList)){$classt="curday1";$vartue=$PeriodList[$ini]['tuesday_grade']."  ".$PeriodList[$ini]['tuesday_section'];}
					 
					
					else{$classt="";$vartue="<a href='javascript:;' title=''  style='text-decoration: underline'; rel='tooltip' class='over' data-grade='".$PeriodList[$ini]['tuesday_grade']."' data-section='".$PeriodList[$ini]['tuesday_section']."' data-date='".date('Y-m-d',strtotime('last tuesday'))."'>".$PeriodList[$ini]['tuesday_grade']."  ".$PeriodList[$ini]['tuesday_section']."</a>";}
					
					/*-------------------------------------------------------------------*/
					
					 if(in_array($curwed,$LeaveList)){$classw="curday1";$varwed=$PeriodList[$ini]['wednesday_grade']."  ".$PeriodList[$ini]['wednesday_section'];}
					
					else if(strcasecmp('wednesday',date('l'))==0){$classw="curday";$varwed="<a href='javascript:;'  style='text-decoration: underline'; title='' rel='tooltip' class='over' data-grade='".$PeriodList[$ini]['wednesday_grade']."' data-section='".$PeriodList[$ini]['wednesday_section']."' data-date='".date('Y-m-d')."'>".$PeriodList[$ini]['wednesday_grade']."  ".$PeriodList[$ini]['wednesday_section']."</a>";}
					
					else  if(in_array($lastwed,$LeaveList)){$classw="curday1";$varwed=$PeriodList[$ini]['wednesday_grade']."  ".$PeriodList[$ini]['wednesday_section'];}
					
					else{$classw="";$varwed="<a href='javascript:;' title=''  style='text-decoration: underline'; rel='tooltip' class='over' data-grade='".$PeriodList[$ini]['wednesday_grade']."' data-section='".$PeriodList[$ini]['wednesday_section']."' data-date='".date('Y-m-d',strtotime('last wednesday'))."'>".$PeriodList[$ini]['wednesday_grade']."  ".$PeriodList[$ini]['wednesday_section']."</a>";}
					/*-------------------------------------------------------------------*/
					
					if(in_array($curthur,$LeaveList)){$classth="curday1";$varthr=$PeriodList[$ini]['thursday_grade']."  ".$PeriodList[$ini]['thursday_section'];}
						
					else if(strcasecmp('thursday',date('l'))==0){$classth="curday";$varthr="<a href='javascript:;'  style='text-decoration: underline'; title='' rel='tooltip' class='over' data-grade='".$PeriodList[$ini]['thursday_grade']."' data-section='".$PeriodList[$ini]['thursday_section']."' data-date='".date('Y-m-d')."'>".$PeriodList[$ini]['thursday_grade']."  ".$PeriodList[$ini]['thursday_section']."</a>";}
					
					else if(in_array($lastthur,$LeaveList)){$classth="curday1";$varthr=$PeriodList[$ini]['thursday_grade']."  ".$PeriodList[$ini]['thursday_section'];}
					
					else{$classth="";$varthr="<a href='javascript:;'  style='text-decoration: underline'; title='' rel='tooltip' class='over' data-grade='".$PeriodList[$ini]['thursday_grade']."' data-section='".$PeriodList[$ini]['thursday_section']."' data-date='".date('Y-m-d',strtotime('last thursday'))."'>".$PeriodList[$ini]['thursday_grade']."  ".$PeriodList[$ini]['thursday_section']."</a>";}
					/*-------------------------------------------------------------------*/
					if(in_array($curfri,$LeaveList)){$classf="curday1";$varfri=$PeriodList[$ini]['friday_grade']."  ".$PeriodList[$ini]['friday_section'];} 
					
				 else if(strcasecmp('friday',date('l'))==0){$classf="curday";$varfri="<a href='javascript:;'  style='text-decoration: underline'; title='' rel='tooltip' class='over' data-grade='".$PeriodList[$ini]['friday_grade']."' data-section='".$PeriodList[$ini]['friday_section']."' data-date='".date('Y-m-d')."'>".$PeriodList[$ini]['friday_grade']."  ".$PeriodList[$ini]['friday_section']."</a>";}
				 
				 else if(in_array($lastfri,$LeaveList)){$classf="curday1";$varfri=$PeriodList[$ini]['friday_grade']."  ".$PeriodList[$ini]['friday_section'];} 
					
					else{$classf="";$varfri="<a href='javascript:;' title='' rel='tooltip'  style='text-decoration: underline'; class='over' data-grade='".$PeriodList[$ini]['friday_grade']."' data-section='".$PeriodList[$ini]['friday_section']."' data-date='".date('Y-m-d',strtotime('last friday'))."'>".$PeriodList[$ini]['friday_grade']."  ".$PeriodList[$ini]['friday_section']."</a>";}
					/*-------------------------------------------------------------------*/
					if(in_array($cursat,$LeaveList)){$classsa="curday1";$varsat=$PeriodList[$ini]['saturday_grade']."  ".$PeriodList[$ini]['saturday_section'];} 
					
					else if(strcasecmp('saturday',date('l'))==0){$classsa="curday";$varsat="<a href='javascript:;'  style='text-decoration: underline'; title='' rel='tooltip' class='over' data-grade='".$PeriodList[$ini]['saturday_grade']."' data-section='".$PeriodList[$ini]['saturday_section']."' data-date='".date('Y-m-d')."'>".$PeriodList[$ini]['saturday_grade']."  ".$PeriodList[$ini]['saturday_section']."</a>";}
					
					else if(in_array($lastsat,$LeaveList)){$classsa="curday1";$varsat=$PeriodList[$ini]['saturday_grade']."  ".$PeriodList[$ini]['saturday_section'];} 
					
					else{$classsa="";$varsat="<a href='javascript:;' title='' rel='tooltip' class='over'  style='text-decoration: underline'; data-grade='".$PeriodList[$ini]['saturday_grade']."' data-section='".$PeriodList[$ini]['saturday_section']."' data-date='".date('Y-m-d',strtotime('last saturday'))."'>".$PeriodList[$ini]['saturday_grade']."  ".$PeriodList[$ini]['saturday_section']."</a>";}
					/*-------------------------------------------------------------------*/
					//echo date('Y-m-d',strtotime('last monday'));
					// echo date('Y-m-d');
					?>
					  <tr>
					<?php   //date("g:i A", strtotime($bookingTime)); ?>
					
						<td>Period <?php if($PeriodList[$ini]['start_time']!='' && $PeriodList[$ini]['end_time']!='') { $timing = '('.date("g:i A", strtotime($PeriodList[$ini]['start_time'])).' - '.date("g:i A", strtotime($PeriodList[$ini]['end_time'])).')'; } else { $timing='';} echo $ini.' '.$timing.'<br/>'; if($PeriodList[$ini]['remarks']!='') { echo $remarks = '['.$PeriodList[$ini]['remarks'].']'; } else { echo $remarks=''; } ?></td>
						<td class='<?php echo $classm;  ?>'><?php echo $varmon; ?></td>
						<td class='<?php echo $classt;  ?>'><?php echo $vartue; ?></td>
						<td class='<?php echo $classw;  ?>'><?php echo $varwed; ?></td>
						<td class='<?php echo $classth;  ?>'><?php echo $varthr; ?></td>
						<td class='<?php echo $classf;  ?>'><?php echo $varfri; ?></td>
						<td class='<?php echo $classsa;  ?>'><?php echo $varsat; ?></td>
					  </tr>
					<?php } ?>
					  
					</tbody>
				  </table>
</div>
</div>











</div>
</div>
</div>

<style>
thead {
    background-color: #1abb9c;
    color: #fff;
}
</style>
<link href="<?php echo base_url(); ?>assets/css/jquery.dataTables.css" rel="stylesheet" type="text/css">
<link href="<?php echo base_url(); ?>assets/css/dataTables.tableTools.css" rel="stylesheet" type="text/css">
<script src="<?php echo base_url(); ?>assets/js/jquery.dataTables.js" type="text/javascript"></script>
<script src="<?php echo base_url(); ?>assets/js/dataTables.tableTools.js" type="text/javascript"></script>
					
					