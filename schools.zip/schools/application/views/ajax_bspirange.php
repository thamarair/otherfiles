<?php if($Summary[0]['HdMessage']!='')
{ ?>
	<div class="row">
		<div class="HDMsg">
			<?php echo $Summary[0]['HdMessage']; ?>
		</div>
	</div>	
<?php } ?>
		<div class="x_panel tile">
			<div class="x_title">
			 
			 <!-- <ul class="nav navbar-right panel_toolbox">
					<li><a class="collapse-link bounce"><i class="fa fa-chevron-up"></i></a></li>
					 <li class="dropdown open">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="true"><i class="glyphicon glyphicon-eye-open"></i></a>
                        <ul class="dropdown-menu" role="menu">
						   <li><a href="javascript:;" id="URchview">Chart <i class="glyphicon glyphicon-indent-left"></i></a></li>
						  <li><a href="javascript:;" id="URtblview">Table <i class="glyphicon glyphicon-th"></i></a></li>
                        </ul>
					</li>
				</ul>-->
			  <div class="clearfix"></div>
			</div>
			<div class="x_content" >
				<div id="Utilizationreport"></div>
			</div>
		</div>
		<div class="x_panel tile">
			<div class="x_title"></div>
			<div class="x_content" >
				<div id="UtilizationTbl">
				<table id="bspirange" class="table table-bordered table-condensed table-hover table-striped" >
					<thead>
						<tr>
							<th>S.No.</th>
							<th>BSPI Score Range</th>
							<th>Description</th>
							<th>Number of students in Pre Assessment</th>
							<th>Number of students in current Month</th>
						</tr>
					</thead>
					<tfoot align="right"><tr><th></th><th></th><th></th><th></th><th></th></tr></tfoot>
					<tbody>
						<tr style="background:#ef4747;color:#fff;">
						<!--<td><a href="<?php echo base_url(); ?>index.php/home/bspianalysislist/<?php echo "1/".$monthNumber[0]."/".$monthNumber[1]; ?>" target="_blank" class="newlink" > < 20 </a></td>-->
						<td> 1 </td>
						<td> < 20 </td>
						<td>Rigorous and immediate intervention needed. But don’t feel low. Kids can certainly improve!</td>
						<td><?php if(!isset($asapcount[0]['<=20'])){echo "0";}else{echo $asapcount[0]['<=20'];} ?></td>
						<td><?php if(!isset($clpcount[0]['<=20'])){echo "0";}else{echo $clpcount[0]['<=20'];} ?></td>
						</tr>
						
						<tr style="background:#eb7961;color:#fff;">
						<!--<td><a href="<?php echo base_url(); ?>index.php/home/bspianalysislist/<?php echo "2/".$monthNumber[0]."/".$monthNumber[1]; ?>" target="_blank" class="newlink">  20 -40 </a> </td>-->
						<td> 2 </td>
						<td>  20 -40 </td>
						<td> Needs Immediate Intervention. Mistakes are the stepping stones to success. You can surely do it!</td>
						<td><?php if(!isset($asapcount[0]['20-40'])){echo "0";}else{echo $asapcount[0]['20-40'];} ?></td>
						<td><?php if(!isset($clpcount[0]['20-40'])){echo "0";}else{echo $clpcount[0]['20-40'];} ?></td>			
						</tr>
						
						<tr  style="background:#fbad17;color:#fff;">
						<!--<td> <a href="<?php echo base_url(); ?>index.php/home/bspianalysislist/<?php echo "3/".$monthNumber[0]."/".$monthNumber[1]; ?>" target="_blank" class="newlink">40 - 60</a> </td>-->
						<td> 3 </td>
						<td> 40 - 60 </td>
						<td>Intervention will enhance curriculum performance. Everyone has caliber; a bit of push can cause wonders!</td>
						<td><?php if(!isset($asapcount[0]['40-60'])){echo "0";}else{echo $asapcount[0]['40-60'];} ?></td>
						<td><?php if(!isset($clpcount[0]['40-60'])){echo "0";}else{echo $clpcount[0]['40-60'];} ?></td>			
						</tr>
						
						<tr style="background:#fec250;color:#fff;">
						<!--<td> <a href="<?php echo base_url(); ?>index.php/home/bspianalysislist/<?php echo "4/".$monthNumber[0]."/".$monthNumber[1]; ?>" target="_blank" class="newlink">60 - 80</a> </td>-->
						<td> 4 </td>
						<td> 60 - 80  </td>
						<td>You definitely have a spark. Some determination and you will reach there!</td>
						<td><?php if(!isset($asapcount[0]['60-80'])){echo "0";}else{echo $asapcount[0]['60-80'];} ?></td>
						<td><?php if(!isset($clpcount[0]['60-80'])){echo "0";}else{echo $clpcount[0]['60-80'];} ?></td>			
						</tr>
						
						<tr style="background:#9acc59;color:#fff;">
						<!--<td> <a href="<?php echo base_url(); ?>index.php/home/bspianalysislist/<?php echo "5/".$monthNumber[0]."/".$monthNumber[1]; ?>" target="_blank" class="newlink">> 80 </a> </td>-->
						<td> 5 </td>
						<td>  > 80  </td>
						<td>Prodigy! This is fantastic. Keep it up and Carry it further!</td>
						<td><?php if(!isset($asapcount[0]['>80'])){echo "0";}else{echo $asapcount[0]['>80'];} ?></td>
						<td><?php if(!isset($clpcount[0]['>80'])){echo "0";}else{echo $clpcount[0]['>80'];} ?></td>			
						</tr>
				</tbody>
			</table>
<?php if($Summary[0]['FooMessage']!='')
{ ?>
	<div class="row">
		<div class="FOOMsg">
			<?php echo $Summary[0]['FooMessage']; ?>
		</div>
	</div>	
<?php } ?>
	</div>
</div>
</div>
</div>

<script>
$('#bspirange').DataTable( {

"lengthMenu": [[10,  -1], [10,  "All"]],

});
$("#URchview").click(function(){
	$("#UtilizationTbl").hide();$("#Utilizationreport").show();
});
$("#URtblview").click(function(){
	$("#Utilizationreport").hide();
	$("#UtilizationTbl").show();
});
</script>
<style>
	.newlink{color: #fff;
    text-decoration: underline;}
</style>

<script type="text/javascript">
			
Highcharts.chart('Utilizationreport', {
    chart: {
        type: 'column'
    },
    title: {
        text: ''
    },
    subtitle: {
        text: ''
    },
    xAxis: {
        categories: [
            '<= 20',
            '> 20 and <= 40',
            '> 40 and <= 60',
            '> 60 and <= 80',
            '> 80'
        ],
        crosshair: true
    },
    yAxis: {
        min: 0,
        title: {
            text: 'No. of users'
        }
    },
    tooltip: {
        headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
        pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
            '<td style="padding:0"><b>{point.y:.f}</b></td></tr>',
        footerFormat: '</table>',
        shared: true,
        useHTML: true
    },
    plotOptions: {
        column: {
            pointPadding: 0.2,
            borderWidth: 0
        }
    },
	credits: {
      enabled: false
  },
    series: [{
        name: 'Number of students in Pre Assessment',
		color: '#f90',
        data: [<?php if(!isset($asapcount[0]['<=20'])){echo "0";}else{echo $asapcount[0]['<=20'];} ?>,<?php if(!isset($asapcount[0]['20-40'])){echo "0";}else{echo $asapcount[0]['20-40'];}?>,<?php if(!isset($asapcount[0]['40-60'])){echo "0";}else{echo $asapcount[0]['40-60'];}?>,<?php if(!isset($asapcount[0]['60-80'])){echo "0";}else{echo $asapcount[0]['60-80'];}?>,<?php if(!isset($asapcount[0]['>80'])){echo "0";}else{echo $asapcount[0]['>80'];}?>]

    }, {
        name: 'Number of students in current Month',
		color: '#1abb9c',
        data: [<?php if(!isset($clpcount[0]['<=20'])){echo "0";}else{echo $clpcount[0]['<=20'];}?>,<?php if(!isset($clpcount[0]['20-40'])){echo "0";}else{echo $clpcount[0]['20-40'];}?>,<?php if(!isset($clpcount[0]['40-60'])){echo "0";}else{echo $clpcount[0]['40-60'];}?>,<?php if(!isset($clpcount[0]['60-80'])){echo "0";}else{echo $clpcount[0]['60-80'];}?>,<?php if(!isset($clpcount[0]['>80'])){echo "0";}else{echo $clpcount[0]['>80'];}?>]

    }]
});
</script>
