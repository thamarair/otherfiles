 <div class="right_col" role="main">  
<div class="row">
	<div class="col-lg-12">
		<h2 class="page-header1 reporttitle">Tracking Report</h2>
	</div>
</div>	
			<br/>
			  <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                  <div class="x_title">
                   <div class="row">  
						<div class="" role="tabpanel" data-example-id="togglable-tabs">
							<ul id="myTab" class="nav nav-tabs bar_tabs" role="tablist">
							<li class="filterlabel">Month : </li>
							 <?php $ini=0; //echo "<pre>";print_r($academicMonths);exit;
								$lastmonthcount=count($academicMonths);
								$mydate=strtotime('2018-05-31');
							 foreach($academicMonths as $am){ 
							 if(strtotime($am['startdate']) > $mydate)
							 {
								if($am['monthNumber']==date('m',strtotime('last day of previous month'))) { $class = "class='active'"; $classa = "activemonth";}	?>
								<li role="monthtab" <?php echo $class; ?>><a href="javascript:;" id="<?php echo $am['monthNumber'].'-'.$am['yearNumber'];?>" role="tab" data-toggle="tab" data-month="<?php echo $am['startdate']."/".$am['enddate']; ?>" aria-expanded="true" class="month <?php echo $classa; ?>"><?php echo $am['monthName']; ?></a>
								</li>
							 <?php }  } ?>
								<div class="gradeFilter1 gf">
									<label>Grade :</label>
									 <select name="ddlgradefilter1" id="ddlgradefilter1" > 
										<option value="">ALL</option>
										<?php $i=0;foreach($gradewiseuserscount as $grade) { ?>
											<option value="<?php echo $grade['grade_id']; ?>"><?php echo $grade['gradename']; ?></option>
										<?php } ?>
									 </select>
								</div>
							</ul>
							<input type="hidden" id="month" class="" value="" >
						</div>
						
					</div>
                    
                    <div class="clearfix"></div>
                  </div>
				<div class="row">
					<div style="display:none; text-align:center;" id="iddivLoading11" class="loader"><img src="<?php echo base_url(); ?>assets/images/ajax-page-loader.gif"  style="width:50px;" /></div>
					<div id="Summaryofutilization" ></div>
				</div>
 
                  <div class="x_content">
					<div class="" role="tabpanel" data-example-id="togglable-tabs">
                      <ul id="myTab" class="nav nav-tabs bar_tabs" role="tablist">
                        <li role="presentation" class="active"><a href="#tab_content1" id="home-tab" role="tab" data-toggle="tab" aria-expanded="true" class="utilizetab tab2">Utilization Report</a>
                        </li>
                        <!--<li role="presentation"><a href="#tab_content2" role="tab" id="profile-tab" class="bspitab" data-toggle="tab" aria-expanded="false">BSPI</a>
                        </li>-->
                        <li role="presentation"><a href="#tab_content3" role="tab" id="profile-tab2" data-toggle="tab" aria-expanded="false" class="topperslisttab tab2">BSPI Topper</a>
                        </li>
						
						<li role="presentation"><a href="#tab_content6" role="tab" id="profile-tab6" data-toggle="tab" aria-expanded="false" class="SkillTopper tab2">Skill Topper</a>
                        </li>
						
						<li role="presentation" ><a href="#tab_content4" role="tab" id="profile-tab3" data-toggle="tab" aria-expanded="false" class="interventiontab tab2">Intervention</a>
                        </li>
                      </ul>
                      <div id="myTabContent" class="tab-content">
						<div style="display:none; text-align:center;" id="iddivLoading1" class="loader"><img src="<?php echo base_url(); ?>assets/images/ajax-page-loader.gif"  style="width:50px;"  />Please wait loading data..</div>
						
                        <div role="tabpanel" class="tab-pane fade active in" id="tab_content1" aria-labelledby="home-tab">
							<div id="utilizetab_result" ></div>
                        </div>
                        <!--<div role="tabpanel" class="tab-pane fade" id="tab_content2" aria-labelledby="profile-tab">
							<div id="bspiresult"></div>
                        </div>-->
                        <div role="tabpanel" class="tab-pane fade" id="tab_content3" aria-labelledby="profile-tab">
							<div id="topperslist"></div>
                        </div>
						
						<div role="tabpanel" class="tab-pane fade" id="tab_content4" aria-labelledby="profile-tab">
							<div id="interventiontab" style="overflow:auto"></div>
                        </div>
						
						<div role="tabpanel" class="tab-pane fade" id="tab_content5" aria-labelledby="profile-tab">
						    <div id="int_lowerattemptstab"></div>
                        </div>
						
						<div role="tabpanel" class="tab-pane fade" id="tab_content6" aria-labelledby="profile-tab">
							<div id="SkillTopper"></div>
                        </div>
						
						<!--<div role="tabpanel" class="tab-pane fade" id="tab_content7" aria-labelledby="profile-tab7">
							<div id="summarytab_res"></div>
                        </div>-->
						
                      </div>
                    </div>
					
							
                  </div>
                </div>
        </div>
</div>
<script src="<?php echo base_url(); ?>assets/js/jquery.min.js" type="text/javascript"></script>
<script src="<?php echo base_url(); ?>assets/js/highcharts.js"></script>
<script>

$(document).ready(function(){
	$("#month").val($(".activemonth").attr('data-month'));
$("#ddlgradefilter1").change(function(){
	
	$('#topperslist').html('');
	$('#interventiontab').html('');	
	$('#SkillTopper').html('');	
	
	var curTab=$(".InnerActive").attr('id');
	if(curTab=='home-tab')
	{
		tracking_report1();
		tracking_summaryofutilization();
	}
	else if(curTab=='profile-tab2')
	{
		bspitopper_gradewise();tracking_summaryofutilization();
	}
	else if(curTab=='profile-tab6')
	{
		skilltopper_gradewise();tracking_summaryofutilization();
	}
	else if(curTab=='profile-tab3')
	{
		eom_intervention();tracking_summaryofutilization();
	}
	else
	{
		tracking_report1();
		tracking_summaryofutilization();
	}
});
	
	tracking_summaryofutilization();
	tracking_report1();
	
	$('.utilizetab').click(function(){
		$(".tab2").removeClass('InnerActive');
		$(this).addClass('InnerActive');
		if($('#utilizetab_result').is(':empty'))
		{
			tracking_report1();
		}
	});
	$('.topperslisttab').click(function(){
		$(".tab2").removeClass('InnerActive');
		$(this).addClass('InnerActive');
		if($('#topperslist').is(':empty'))
		{
			bspitopper_gradewise();
		}
	});
	$('.SkillTopper').click(function(){
		$(".tab2").removeClass('InnerActive');
		$(this).addClass('InnerActive');
		if($('#SkillTopper').is(':empty'))
		{
			skilltopper_gradewise();
		}
	});
	$('.interventiontab').click(function(){
		$(".tab2").removeClass('InnerActive');
		$(this).addClass('InnerActive');
		if($('#interventiontab').is(':empty'))
		{
			eom_intervention();
		}
	});
});
 
$(".month").click(function()
{
		$("#month").val($(this).attr('data-month'));
		$(".month").parent().removeClass('active');
		$(".month").removeClass('activemonth');
		$(this).parent().addClass('active');
		$(this).addClass('activemonth');
		
		$('#topperslist').html('');
		$('#interventiontab').html('');	
		$('#SkillTopper').html('');	
		
		var curTab=$(".InnerActive").attr('id');
		if(curTab=='home-tab')
		{
			tracking_report1();
			tracking_summaryofutilization();
		}
		else if(curTab=='profile-tab2')
		{
			bspitopper_gradewise();tracking_summaryofutilization();
		}
		else if(curTab=='profile-tab6')
		{
			skilltopper_gradewise();tracking_summaryofutilization();
		}
		else if(curTab=='profile-tab3')
		{
			eom_intervention();tracking_summaryofutilization();
		}
		else
		{
			tracking_report1();
			tracking_summaryofutilization();
		}
		
		 
		
		var curmonth=$(this).attr('id').split('-');//console.log(curmonth);alert(curmonth[0]);
		if(curmonth[0]=='08'){$(".Summarytab").show();}else{$(".Summarytab").hide();}
});
 
 
function tracking_summaryofutilization()
{
	
	var schoolid = '<?php echo $this->session->schoolid; ?>';
	var month=$('#month').val();
	var grade=$('#ddlgradefilter1').val();
	$("#iddivLoading11").show(); 

	$.ajax({
		type: "POST",
		//dataType: "json",
		url: "<?php echo base_url(); ?>index.php/home/ajax_eom_summaryofutilization",
		data: {schoolid:schoolid,month:month,grade:grade},
		success: function(result){
			//alert(result);
				$("#iddivLoading11").hide(); 
				$('#Summaryofutilization').html(result);
		}
	});
	
}

function tracking_report1()
{	
	var month=$('#month').val();
	var grade=$('#ddlgradefilter1').val();
	$("#iddivLoading1").show();
	$.ajax({
		type: "POST",
		//dataType: "json",
		url: "<?php echo base_url(); ?>index.php/home/bspirange",
		data: {month:month,grade:grade},
		success: function(result)
		{	
				$("#iddivLoading1").hide();		 
				$('#utilizetab_result').html(result);
				$("#monname").html($(".activemonth").text());
		}
	});
	
}

function bspitopper_gradewise()
{	
	
	var month=$('#month').val();
	var grade=$('#ddlgradefilter1').val();
	
	$("#iddivLoading1").show();
		
	$.ajax({
		type: "POST",
		//dataType: "json",
		url: "<?php echo base_url(); ?>index.php/home/bspitopper_gradewise",
		data: {month:month,grade:grade},
		success: function(result){	
			$("#iddivLoading1").hide();		
			$('#topperslist').html('');			
			$('#topperslist').html(result);
		}
	});
	
}
function skilltopper_gradewise()
{	
	
	var month=$('#month').val();
	var grade=$('#ddlgradefilter1').val();
	$("#iddivLoading1").show();
		
	$.ajax({
		type: "POST",
		//dataType: "json",
		url: "<?php echo base_url(); ?>index.php/home/skilltopper_gradewise",
		data: {month:month,grade:grade},
		success: function(result){	
			$("#iddivLoading1").hide();		
			$('#SkillTopper').html('');			
			$('#SkillTopper').html(result);
		}
	});
	
}
function eom_intervention()
{
	var month=$('#month').val();
	var grade=$('#ddlgradefilter1').val();
	$("#iddivLoading1").show();
	var filter='<=20';
	$.ajax({
		type: "POST",
		data: {month:month,grade:grade,filter:filter},
		url: "<?php echo base_url(); ?>index.php/home/eom_intervention", 
		success: function(result)
		{
				$("#iddivLoading1").hide();		
				$('#interventiontab').html('');			
				$('#interventiontab').html(result);
			
		}
	});
}
</script>

<style>
.HDMsg{padding:10px;}
.FOOMsg{padding:10px;}

thead {
    background-color: #1abb9c;
    color: #fff;
}
.reporttitle { color:#1abb9c; }
ul.bar_tabs>li a {background: #26b99a; color:#fff;padding: 10px 10px; }
.nav>li>a:hover { background-color: #2a3f54; }
.countdata{background-color:#6f7977;padding-top: 10px;text-align: center;color: #fff;min-height:97px;}
.countdata label{font-size: 17px;}
.low{    font-size: 9px;}
.newcolor1{background-color:#1abb9c;}
.countval{display: block;font-size: 17px;font-weight: bold;}
.cent{font-size: 11px;}
.low{display: block;color: #f0f0f0;}
.reportmsg{background:#f5f7fa;color: #000;padding: 8px;font-size: 15px;}
#summarytab_res #INTERVENTION br{display:none;}
.x_title{border-bottom:none;}
</style>