<?php 
		foreach($schools as $key1=>$val1) {
			
			$scklschedule[$schools[$key1]['school_id'].'-'.$schools[$key1]['grade_id'].'-'.$schools[$key1]['section'] ] =  $val1;
	
		}
		
		
		foreach($completeusers as $key2=>$val2) {
			
			$compusers[$completeusers[$key2]['sid'].'-'.$completeusers[$key2]['grade_id'].'-'.$completeusers[$key2]['section'] ] =  $val2;

		}

?>
 <div class="loading" id="loading2" style="display:none;" ><img src="<?php echo base_url(); ?>assets/images/ajax-page-loader.gif" style="width:80px;" /></div>
<div class="right_col" role="main">
<div class="row">

	<div class="col-md-12 col-lg-12 col-sm-12 col-xs-12">
		<div class="x_panel tile">
			<div class="x_title">
				<h2 class="reporttitle">Non Schedule Session Details : <?php echo date("d-m-Y", strtotime($date)); ?></h2>
				<div class="clearfix"></div>
			</div>
			<div class="x_content" >
			<table id="dataTable" class="table table-bordered table-condensed table-hover table-striped dataTable">
						<thead style="background-color:#1abb9c; color:#FFF;">
							<tr>
								<th>S.No.</th>
								<th>Grade</th>
								<th>Section</th>
								<th>Registered Users</th>
								<th>Logged in Users</th>
								<th>Attended Users</th>
								<th>Completed Users</th>
							</tr>
						</thead>
						<tfoot>
            <tr>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
				<th></th>
            </tr>
        </tfoot>
	<tbody>
		<?php $i=1;
		foreach($scklschedule as $key3=>$val3) {
			
			$scklschedule[$key3]['cccount'] =  $compusers[$key3]['cuser'];
			?>
			
			
			 <tr>
							<td><?php echo $i; ?></td>
							<td><?php echo $val3['gradename']; ?></td>
							<td><?php echo $val3['section']; ?></td>
							<td><?php echo $val3['regusers']; ?></td>
							<td><a href="javascript:;" class="nspopup" data-type="logusers" data-grade="<?php echo $val3['grade_id']; ?>" data-sec="<?php echo $val3['section']; ?>" id="" ><?php echo $val3['loggedinuser']; ?></a></td>
							
							<td><?php if($val3['attendusers']==0) { echo $val3['attendusers']; } else { ?>
							<a href="javascript:;" class="nspopup" data-type="attnusers" data-grade="<?php echo $val3['grade_id']; ?>" data-sec="<?php echo $val3['section']; ?>" id="" ><?php echo $val3['attendusers']; ?></a><?php } ?></td>
							
							<!--<td><?php if($compusers[$key3]['cuser']=='') { echo 0; } else { ?><?php echo $compusers[$key3]['cuser']; } ?></td>-->
							
							<td><?php if($compusers[$key3]['cuser']=='') { echo 0; } else { ?><a href="javascript:;" class="nspopup" data-type="cmptusers" data-grade="<?php echo $val3['grade_id']; ?>" data-sec="<?php echo $val3['section']; ?>" id="" ><?php echo $compusers[$key3]['cuser']; } ?></a></td>
							
							
							</tr>			
			
			
	<?php $i++;	} ?>
	
	</tbody>   
		
	</table>
	 
	<div id="ns-userslist" class="modal fade" role="dialog">
  <div class="modal-dialog" id="">
    <!-- Modal content-->
    <div class="modal-content" style="box-shadow: none;border: none;">
    
	 <div class="modal-header" style="text-align:center;">
<button type="button" class="close" data-dismiss="modal" style="color: #000;opacity: 1;font-size: 30px;
">&times;</button>
			<h2 class="modal-title" id="scheduledate" style="text-align: center;"></h2>
      </div>
     
      <div class="modal-body"  style="padding:0px;">
	  
	  <div id="userslist-ns"></div>
      </div>
    </div>
  </div>
</div>

	<link href="<?php echo base_url(); ?>assets/css/jquery.dataTables.css" rel="stylesheet" type="text/css">
	<link href="<?php echo base_url(); ?>assets/css/dataTables.tableTools.css" rel="stylesheet" type="text/css">
	<script src="<?php echo base_url(); ?>assets/js/jquery.min.js" type="text/javascript"></script>
	<script src="<?php echo base_url(); ?>assets/js/jquery.dataTables.js" type="text/javascript"></script>
	<script src="<?php echo base_url(); ?>assets/js/dataTables.tableTools.js" type="text/javascript"></script>
	
	<script>
	/* $('.dataTable').DataTable({
		"lengthMenu": [[10,  -1], [10,  "All"]]
		//"scrollX": true
	}); */
	
	$(".nspopup").click(function()
	{
		$('#loading2').show();
	var gradeid = $(this).data('grade');
	var section = $(this).data('sec');
	var type = $(this).data('type');
	var date = '<?php echo $date; ?>';
	var date_heading = '<?php echo date("d-m-Y", strtotime($date)); ?>';
	//alert(date); return false;
	$.ajax({
		type: "POST",
		//dataType: "json",
		url: "<?php echo base_url(); ?>index.php/home/nonschedule_userslist",
		data: {gradeid:gradeid,section:section,type:type,date:date},
		success: function(result){
			$('#loading2').hide();
			//console.log(result); return false;
			$('#ns-userslist').modal('show');
			$('#userslist-ns').html(result);
			$('#scheduledate').html(date_heading);
		}
	});
		
	});

	$(document).ready(function() {
		$('#dataTable').DataTable( {
			initComplete: function () {
				this.api().columns().every( function () {
					var column = this; //console.log(column);
					var select = $('<select><option value=""></option></select>')
						.appendTo( $(column.footer()).empty() )
						.on( 'change', function () {
							var val = $.fn.dataTable.util.escapeRegex(
								$(this).val()
							);
	 
							column
								.search( val ? '^'+val+'$' : '', true, false )
								.draw();
						} );
	 
					column.data().unique().sort().each( function ( d, j ) {
						select.append( '<option value="'+d+'">'+d+'</option>' )
					} );
				});
			}
		} );
	});
	</script>
				</div>
			</div>
		</div>
	</div>
</div>
<style>
.nspopup { text-decoration: underline; }

.dataTables_wrapper{overflow: auto;}
#dataTable tfoot{display: table-header-group;}

.loading {
  position: fixed;
  z-index: 999;
  height: 2em;
  width: 2em;
  overflow: show;
  margin: auto;
  top: 0;
  left: 0;
  bottom: 0;
  right: 0;
}

.loading:before {
  content: '';
  display: block;
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background-color: rgba(0,0,0,0.3);
}

/* :not(:required) hides these rules from IE9 and below */
.loading:not(:required) {
  /* hide "loading..." text */
  font: 0/0 a;
  color: transparent;
  text-shadow: none;
  background-color: transparent;
  border: 0;
}
</style>