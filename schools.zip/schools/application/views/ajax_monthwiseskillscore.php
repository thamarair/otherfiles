<script type="text/javascript">
			
		$('#monthlyskillscore').highcharts({
		chart: {
            type: 'line'
        },
		
        title: {
            text: '<?php echo $GraphTitle; ?>',
            x: -20 //center
        },
        subtitle: {
            text: '',
            x: -20
        },
        xAxis: {
            categories: [<?php $ini=0; foreach($academicMonths as $am){
				$ini++;
				if($ini>1){echo ",";}
				echo "'".$am['monthName']."'";
			} ?>]
        },
        yAxis: {
            min: 0,tickInterval: 10,max:100,
            title: {
                text: 'Score'
            },
            plotLines: [{
                value: 0,
                width: 1,
                color: '#ff3300'
            }]
        },
        tooltip: {
            valueSuffix: '',
			shared: true
        },
		plotOptions: {
        line: {
            dataLabels: {
                enabled: false
            },
            enableMouseTracking: true
        }
    },
        credits: {
      enabled: false
  },
        series: [
		<?php foreach($SkillList as $result)
		{ ?> 
			{showInLegend: true,   
			 name: '<?php echo $result['name']; if(count($SkillList)!=5 ) {echo " Score in Training";} ?>',
			 color: '<?php echo $result['colorcode']; ?>',
				data: [<?php $ini=0; foreach($academicMonths as $am)
				{
					$ini++;
					if($ini>1){echo ",";}
					if(isset($monthwiseskillscore[$am['monthNumber']][$result['name']])){
					echo "".round($monthwiseskillscore[$am['monthNumber']][$result['name']],2)."";
					}
					else{echo "0";}
				} ?>]
			},
			<?php if(count($SkillList)!=5 ) {?>
			{
				name: '<?php echo $result['name']; ?> Score in Assessment',
				dashStyle: 'shortdash',
				color: '<?php echo $result['colorcode']; ?>',
				data: [<?php $ini1=0; foreach($academicMonths as $am)
				{
					$ini1++;
					if($ini1>1){echo ",";}
					echo "".round($asapavgskillscore[0]['skillscore'],2)."";
				} ?>] 
			},
		<?php } ?>
		<?php } ?>
		
		]
    });

</script>
<div id="monthlyskillscore"></div>