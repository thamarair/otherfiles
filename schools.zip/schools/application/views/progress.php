 <style>
.loading {
  position: fixed;
  z-index: 999;
  height: 2em;
  width: 2em;
  overflow: show;
  margin: auto;
  top: 0;
  left: 0;
  bottom: 0;
  right: 0;
}

.loading:before {
  content: '';
  display: block;
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background-color: rgba(0,0,0,0.3);
}

/* :not(:required) hides these rules from IE9 and below */
.loading:not(:required) {
  /* hide "loading..." text */
  font: 0/0 a;
  color: transparent;
  text-shadow: none;
  background-color: transparent;
  border: 0;
}
</style>
 <div class="right_col" role="main">  
  <div class="row">
  <div class="col-lg-12">
                    <h1 class="page-header reporttitle">Progress Charts</h1>
					<div style="text-align: right;font-size: 15px;color: #000;"><span style="color: red;font-size: 18px;">*</span> Scores calculated upto till date</div>
                </div>
				
			</div>	
			<br/>
			  <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                  <div class="x_title">
                   <form role="form" id="srchfrm" style="" enctype="multipart/form-data" accept-charset="utf-8" name="srchfrm" class="col-md-12">
                    <div class="form-group row">
                        <div class="col-lg-2">
                            <Select class="form-control" name="grade" id="grade">
							<option value="">Select Grade</option>
							<?php $i=0; foreach($getgrade as $res) { $i++; ?> 
							<option id="<?php echo $res['class_id']; ?>" value="<?php echo $res['class_id']; ?>"><?php echo $res['classname']; ?></option>
							<?php }?></select>
                        </div>
                        <div class="col-lg-2">
                            <Select class="form-control" name="section" id="section" >
							<option value="">Select Section</option></select>
                        </div>
                        <div class="col-lg-3">
						<Select class="form-control" name="studentname" id="studentname" >
							<option value="">Select Student</option></select>
                            <!--<input class="form-control" name="studentname" id="studentname" placeholder="Selet Student" type="text">-->
                        </div>
						
						<div class="col-lg-4">
                            <input class="btn btn-success" id="btnsbmt" value="Submit" type="button">
							 <input class="btn btn-danger" id="reset" value="Reset" type="reset">
                        </div>
						
						
                    </div></form>
                    <div class="clearfix"></div>
                  </div>
				
 
                  
                </div>
        </div>
		<div class="row">
		<div class="loading" id="loading1" style="display:none;" ><img src="<?php echo base_url(); ?>assets/images/ajax-page-loader.gif" style="width:80px;" /></div>
		<div class="col-6 col-md-6 col-sm-6 col-xs-6 chart1" style="display:none;">
 
 <div><h2 id="MonthID1"><span class="col-lg-10">BSPI Progress</span>  <span class="col-lg-2" style="text-decoration: none;float: none;"></span></h2></div>
 <div id="container3"  style="background:#fff;padding-top:20px;border: 1px solid #ccc;" >
</div>
 </div>
 
 <div class="col-6 col-md-6 col-sm-6 col-xs-6 chart1" style="display:none;">
 <div class="loading" id="loading2" style="display:none;" ><img src="<?php echo base_url(); ?>assets/images/ajax-page-loader.gif" style="width:80px;" /></div>
 <div><h2 id="MonthID1"><span class="col-lg-10">Month wise Average BSPI Score </span>  <span class="col-lg-2" style="text-decoration: none;float: none;"></span></h2></div>
 <div id="chartOverallPerformance"  style="background:#fff;padding-top:20px;border: 1px solid #ccc;" >
</div>
 </div>
 
 </div>
 
 <div class="row">
  <div class="col-6 col-md-6 col-sm-6 col-xs-6 chart1" style="display:none;">
 <div class="loading"  id="loading3" style="display:none;" ><img src="<?php echo base_url(); ?>assets/images/ajax-page-loader.gif" style="width:80px;" /></div>
 <div><h2 id="MonthID1"><span class="col-lg-10">Skill Progress - Memory</span>  <span class="col-lg-2" style="text-decoration: none;float: none;"></span></h2></div>
 <div id="skillscoremnthwise59"  style="background:#fff;padding-top:20px;border: 1px solid #ccc;" >
</div>
 </div>
 
 <div class="col-6 col-md-6 col-sm-6 col-xs-6 chart1" style="display:none;">
 <div class="loading" style="display:none;" ><img src="<?php echo base_url(); ?>assets/images/ajax-page-loader.gif" style="width:80px;" /></div>
 <div><h2 id="MonthID1"><span class="col-lg-10">Skill Progress - Visual Processing</span>  <span class="col-lg-2" style="text-decoration: none;float: none;"></span></h2></div>
 <div id="skillscoremnthwise60"  style="background:#fff;padding-top:20px;border: 1px solid #ccc;" >
</div>
 </div> </div>
 
 <div class="row">
 <div class="col-6 col-md-6 col-sm-6 col-xs-6 chart1" style="display:none;">
 <div class="loading" style="display:none;" ><img src="<?php echo base_url(); ?>assets/images/ajax-page-loader.gif" style="width:80px;" /></div>
 <div><h2 id="MonthID1"><span class="col-lg-10">Skill Progress - Focus & Attention</span>  <span class="col-lg-2" style="text-decoration: none;float: none;"></span></h2></div>
 <div id="skillscoremnthwise61"  style="background:#fff;padding-top:20px;border: 1px solid #ccc;" >
</div>
 </div> 
 
 <div class="col-6 col-md-6 col-sm-6 col-xs-6 chart1" style="display:none;">
 <div class="loading" style="display:none;" ><img src="<?php echo base_url(); ?>assets/images/ajax-page-loader.gif" style="width:80px;" /></div>
 <div><h2 id="MonthID1"><span class="col-lg-10">Skill Progress - Problem Solving</span>  <span class="col-lg-2" style="text-decoration: none;float: none;"></span></h2></div>
 <div id="skillscoremnthwise62"  style="background:#fff;padding-top:20px;border: 1px solid #ccc;" >
</div>
 </div> </div>
 
 <div class="row">
 <div class="col-6 col-md-6 col-sm-6 col-xs-6 chart1" style="display:none;">
 <div class="loading" style="display:none;" ><img src="<?php echo base_url(); ?>assets/images/ajax-page-loader.gif" style="width:80px;" /></div>
 <div><h2 id="MonthID1"><span class="col-lg-10">Skill Progress - Linguistics</span>  <span class="col-lg-2" style="text-decoration: none;float: none;"></span></h2></div>
 <div id="skillscoremnthwise63"  style="background:#fff;padding-top:20px;border: 1px solid #ccc;" >
</div>
 </div></div>
 
</div>

<script src="<?php echo base_url(); ?>assets/js/jquery.min.js" type="text/javascript"></script>
<script src="<?php echo base_url(); ?>assets/js/typeahead.js" type="text/javascript"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js"></script>
<link rel="stylesheet" href="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/themes/smoothness/jquery-ui.css">
<script src="<?php echo base_url(); ?>assets/js/jquery.validate.js"></script>
<script src="<?php echo base_url(); ?>assets/js/highcharts.js"></script>
<script src="<?php echo base_url(); ?>assets/js/highcharts-more.js"></script>

<script>

$(document).ready(function(){
	});
 
 $("#reset").click(function()
{
	location.reload();
});
$("#grade").change(function()
{
	var gradeid = $('#grade').val();
		$.ajax({
		type: "POST",
		url: "<?php echo base_url(); ?>index.php/home/getsection",
		data: {gradeid:gradeid},
		success: function(result){
			
		$('#section').html(result);
		}
	});
});

$("#section").change(function()
{
	var gradeid = $('#grade').val();
	var section = $('#section').val();
	
		$.ajax({
		type: "POST",
		url: "<?php echo base_url(); ?>index.php/home/getstudentname",
		data: {gradeid:gradeid,section:section},
		success: function(result){
			
		$('#studentname').html(result);
		}
	});
});

$("#btnsbmt").click(function()
{
	if($("#srchfrm").valid()==true)
		{
	var gradeid = $('#grade').val();
	var section = $('#section').val();
	var student = $('#studentname').val();
	
	setTimeout(function(){ bspi_progress(gradeid,section,student); }, 200);
	setTimeout(function(){ skillscores_m(gradeid,section,student,59); }, 700);
	setTimeout(function(){ skillscores_m(gradeid,section,student,60); }, 1200);
	setTimeout(function(){ skillscores_m(gradeid,section,student,61); }, 1700);
	setTimeout(function(){ skillscores_m(gradeid,section,student,62); }, 2200);
	setTimeout(function(){ skillscores_m(gradeid,section,student,63); }, 2700);
	setTimeout(function(){ bspi_progress2(gradeid,section,student); }, 3200);

	
 
	
	$(".chart1").show();
		}
});

	
 /*  $( "#studentname" ).autocomplete({
	
		source: "<?php echo base_url(); ?>index.php/home/getstudentname",
		//data:{gradeid:gradeid,section:section},
        select: function( event, result ) {
			
			alert(result);
        // event.preventDefault();
        // $("#studentname").val(result.item.id);
        }
 }); */ 
 
 /* $('#studentname').typeahead({
            source: function (query, result) {
				var gradeid = $('#grade').val();
				var section = $('#section').val();
				var name = $('#studentname').val();
                $.ajax({
                    url: "<?php echo base_url(); ?>index.php/home/getstudentname",
					data:{gradeid:gradeid,section:section,name:name},            
                    dataType: "json",
                    type: "POST",
                    success: function (data) {
						alert(data.username);
						// result($.map(data, function (item) {
							// return item;
                        // }));
                    }
                });
            }
        }); */

 function skillscores_m(gradeid,section,student,skillid)
{
	$('#loading3').show();
	$.ajax({
		type: "POST",
		//dataType: "json",
		url: "<?php echo base_url(); ?>index.php/home/skillscores_m",
		data: {gradeid:gradeid,section:section,student:student,skillid:skillid},
		success: function(result){
			$('#loading3').hide();
			if(skillid==59) {
			$('#skillscoremnthwise59').html(result); }
			if(skillid==60) {
			$('#skillscoremnthwise60').html(result); }
			if(skillid==61) {
			$('#skillscoremnthwise61').html(result); }
			if(skillid==62) {
			$('#skillscoremnthwise62').html(result); }
			if(skillid==63) {
			$('#skillscoremnthwise63').html(result); }
			
		}
	});
}


 function bspi_progress2(gradeid,section,student)
{
	$('#loading2').show();
	$.ajax({
		type: "POST",
		//dataType: "json",
		url: "<?php echo base_url(); ?>index.php/home/bspi_progress_report2",
		data: {gradeid:gradeid,section:section,student:student},
		success: function(result){
			$('#loading2').hide();
			$('#chartOverallPerformance').html(result);
			
		}
	});
}

 function bspi_progress(gradeid,section,student)
{
	$('#loading1').show();
	$.ajax({
		type: "POST",
		dataType: "json",
		url: "<?php echo base_url(); ?>index.php/home/bspi_progress",
		data: {gradeid:gradeid,section:section,student:student},
		success: function(result){
			$('#loading1').hide();
			bspichart(result.clpbspi,result.asapbspi);
			
			
		}
	});
}




function bspichart(clpbspi,asapbspi)
 {
	 
	 
	
	 var chart3 = Highcharts.chart('container3', {

    chart: {
        type: 'bar',
		backgroundColor:'transparent'
	
	 
    },

    title: {
        text: ''
    },

    subtitle: {
        text: ''
    },
	tooltip: {enabled: true},exporting:false,credits: {
      enabled: false
  },
	
    xAxis: {
        categories: ['Scores'],
		gridLineWidth: 0,
  minorGridLineWidth: 0,
  labels: {
            style: {}
        }
       
    },
  
    yAxis: {
        allowDecimals: false,
        title: {
            text: '',style: {}
        },
		 max: 100 ,
		 min:0,
		 minTickInterval : 10,
  gridLineWidth: 0,
  minorGridLineWidth: 0,
  labels: {
            style: {}
        }
		
    },
	
 plotOptions: {
	  
    bar: {
        dataLabels: {
            enabled: true,
			
			style: {}
             
        }
    }
},	
// legend: {
            // layout: 'horizontal',
            // align: 'center',
            // verticalAlign: 'bottom',
            // symbolHeight:10,
			// symbolWidth:30,
            // borderWidth: 0
        // },
   
    series: [
	{
		showInLegend: true,
        name:"Assessment",
		data: [{y:asapbspi}]
	},
	{
		showInLegend: true,
        name:"Current",
		data: [{y:clpbspi}]
	}
	
	 ] 

});
 }
 
 $("#srchfrm").validate({
		
		rules : {
               // fdbksubject : {required:true},
				grade : {required:true},
				section : {required:true},
				studentname : {required:true}
				//skillname : {required:true}
            },
			
		messages: {
            "grade": {required: "Please select grade"},
			"section": {required: "Please select section"},
			"studentname": {required: "Please select student"}
			//"skillname": {required: "Please select any one"}
           
        },
		
		
		errorPlacement: function(error, element) {
    if (element.attr("type") === "radio") {
        error.insertAfter(element.parent().parent());
    } 
	else if (element.attr("type") === "checkbox") {
        error.insertAfter(element.parent().parent());
    } 
	else {
        error.insertAfter(element);
    }
	
},
		highlight: function(input) {
           // $(input).addClass('error');
        } 
    });
 
</script>

<style>
.HDMsg{padding:10px;}
.FOOMsg{padding:10px;}

thead {
    background-color: #1abb9c;
    color: #fff;
}
.reporttitle { color:#1abb9c; }
ul.bar_tabs>li a {background: #26b99a; color:#fff;padding: 10px 10px; }
.nav>li>a:hover { background-color: #2a3f54; }
.countdata{background-color:#6f7977;padding-top: 10px;text-align: center;color: #fff;min-height:97px;}
.countdata label{font-size: 17px;}
.low{    font-size: 9px;}
.newcolor1{background-color:#1abb9c;}
.countval{display: block;font-size: 17px;font-weight: bold;}
.cent{font-size: 11px;}
.low{display: block;color: #f0f0f0;}
.reportmsg{background:#f5f7fa;color: #000;padding: 8px;font-size: 15px;}
#summarytab_res #INTERVENTION br{display:none;}
.error { color: red;}
</style>