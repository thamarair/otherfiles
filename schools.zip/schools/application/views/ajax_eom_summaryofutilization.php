<?php //echo '<pre>'; print_r($arrtotsession); exit;
$percent = $regattenduser[0]['attenusers']/$regattenduser[0]['totaluser'];
$perc1 = round( $percent * 100, 2 );
$percent1 = $completeduser[0]['completeduser'] /$regattenduser[0]['totaluser'];
$perc2 = round( $percent1 * 100, 2 ); 

$usession=round(($arrattendsession[0]['attendsession']/$arrtotsession[0]['totalsession'])* 100,2);
?>

<div class="row">
	<div class="col-md-12 col-sm-12 col-xs-12">						
		<div class="col-md-4 col-sm-4 col-xs-12 countdata"><label class="text-center">Total Session<span class="low">(For this month)</span></label><span class="countval"><?php echo $arrtotsession[0]['totalsession']; ?></span></div>
		<div class="col-md-4 col-sm-4 col-xs-12 countdata newcolor1"><label class="text-center">Half Class Session <span class="low">(Atleast one user has attended the session)</span></label><span class="countval"><?php echo $arrattendsession[0]['halfattendsession'];?> <span class="cent"></span></span></div>
		<div class="col-md-4 col-sm-4 col-xs-12 countdata"><label class="text-center">Full Class Session <span class="low">(Session having minimum <?php echo $this->session->percentage; ?> % of attendance)</span></label><span class="countval"><?php echo $arrattendsession[0]['attendsession'];?> <span class="cent"></span></span></div>
		<!--<div class="col-md-3 col-sm-3 col-xs-12 countdata newcolor1"><label class="text-center">Utilized  Session %<span class="low">(Full class session/Total Session)*100</span></label><span class="countval"><?php echo $usession;?> <span class="cent"></span></span></div>-->
		
<?php if($this->session->schoolid==4){ ?>
		<!--<div class="col-md-2 col-sm-2 col-xs-12 countdata"><label class="text-center">Completed User %<span class="low">(Completed user/Expected user)*100</span></label><span class="countval"> 48.73 <span class="cent"></span></span></div>-->
<?php } else { ?>
		<!--div class="col-md-2 col-sm-2 col-xs-12 countdata"><label class="text-center">Completed User %<span class="low">(Completed user/Expected user)*100</span></label><span class="countval"><?php echo $perc2;?> <span class="cent"></span></span></div>-->
<?php } ?>
	</div>
</div>