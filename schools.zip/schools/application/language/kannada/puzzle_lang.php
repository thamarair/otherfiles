<?php
defined('BASEPATH') OR exit('No direct script access allowed');


$lang['msgdashboard'] = 'ಡ್ಯಾಶ್ಬೋರ್ಡ್ ಸ್ವಾಗತ';



?>
