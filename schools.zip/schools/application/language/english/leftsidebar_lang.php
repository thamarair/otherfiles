<?php
defined('BASEPATH') OR exit('No direct script access allowed');


$lang['goodday'] = 'Good day';
$lang['lastplayed'] = 'You last played on';
$lang['greetingmessage1'] = 'Thanks for subscribing to SkillAngels. </p> <p>I am sure you will enjoy the learning process Good Luck';
$lang['greetingmessage2'] = 'Nice to see you pay so much attention';



?>
