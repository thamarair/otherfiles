<?php echo $this->ajax_pagination->create_links(); ?>
                  <div class="x_content">
                    <div class="row">
                      <div class="col-md-12 col-sm-12 col-xs-12 text-center"> 
                      </div>

                      <div class="clearfix"></div>
<?php 
	$ini=0; 
	foreach($userslist as $res){
	$ini++;
	?>	
                      <div class="col-md-4 col-sm-4 col-xs-12 profile_details">
                        <div class="well profile_view" style="background:#f4f7ff">
                          <div class="col-sm-12" style="min-height: 260px;">
						  <div class="col-sm-6">
                            <h4 class="brief"><i><b><?php echo $res['fname']; ?></b></i></h4></div>
							<?php if($res['patienttype']!='') { ?>
							<div class="col-sm-6">
                            <h5 style="float:right" class="brief"><i><b> Type : <?php  echo $res['patienttype']; ?></b></i></h5></div><?php } ?>
                            <div class="left col-xs-7 <?php if($res['status']==0) { ?> inactiveelement <?php } ?>">
                              <ul class="list-unstyled">
							   <li><i class="fa fa-circle"></i> <?php echo $res['programname']; ?></li>
							    <li><i class="fa fa-book"></i> <?php echo $res['gradename']; ?></li>
							  <li><i class="fa fa-user"></i> <?php echo $res['parentname']; ?></li>
							  <li><i class="fa fa-mobile-phone"></i> <?php echo $res['mobile']; ?></li>
                                <li><i class="fa fa-envelope-o"></i> <?php echo $res['email']; ?></li>
                                <li><i class="fa fa-birthday-cake"></i> <?php echo $res['dob']; ?></li>
								<li><i class="fa fa-map-marker"></i> <?php echo $res['address']; ?> <?php echo $res['city']; ?>, <?php echo $res['statename']; ?></li>
								<?php if($res['creation_date']!='0000-00-00') { ?>
								<li>Registered Date : <?php echo date('d-m-Y',strtotime($res['creation_date'])); ?></li><?php } ?>
                              </ul>
                            </div>
							<?php if($res['avatarimage']==""){$res['avatarimage']="assets/images/avatar.png";} 
  if(file_exists(APPPATH."../assets/".$res['avatarimage'])=='false')
   {$res['avatarimage']="assets/images/avatar.png";}else{$res['avatarimage']=$res['avatarimage'];} ?>
                            <div class="right col-xs-5 text-center">
                              <img src="<?php echo base_url(); ?><?php echo $res['avatarimage']; ?>" style="width:100px;height:100px;" alt="profileimage" class="img-circle img-responsive">
                            </div>
                          </div>
                          <div class="col-xs-12 bottom text-center" style="background:#93c5c7">
                            <div class="col-xs-12 col-sm-6 emphasis">
                            </div>
                             <div class="col-xs-12 col-sm-6 emphasis">
                              <?php if($res['programid']==1)
							  { ?>
								  <a style="float:right" href="<?php echo base_url(); ?>index.php/sa_reports/userview/<?php echo $res['id']; ?>" class="btn btn-success btn-xs">
									<i class="fa fa-user"> </i> View Details New
								  </a> 
							  <?php } else if($res['programid']==2){ ?>
							 	  <a style="float:right" href="<?php echo base_url(); ?>index.php/ba_reports/userview/<?php echo $res['id']; ?>" class="btn btn-success btn-xs">
									<i class="fa fa-user"> </i> View Details new
								  </a>	
							  <?php } else if($res['programid']==2){ ?>
									<a style="float:right" href="<?php echo base_url(); ?>index.php/ka_reports/userview/<?php echo $res['id']; ?>" class="btn btn-success btn-xs">
									<i class="fa fa-user"> </i> View Details new
								  </a>
							  <?php } ?>
                            </div> 
                          </div>
                        </div>
	</div><?php } ?>
                    </div>
					<?php echo $this->ajax_pagination->create_links(); ?>
                  </div>
               