-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 27, 2019 at 12:44 PM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 7.3.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sk_blessedangels_kinder`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `checkbandwidthisexist` (IN `inschoolid` INT(11))  BEGIN

select count(ID) as isexist from bandwidth_log where school_id=inschoolid and TIMESTAMPDIFF(MINUTE,`updatedtime`,now())<(select TimeInterval from bandwidth_config where ID=1 and status=1) and status=1;

END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `checkparentisactive` (IN `inuserid` VARCHAR(11), IN `inlogin_session_id` VARCHAR(255))  BEGIN

IF(inuserid!='')THEN

Update school_parent_master SET last_active_datetime=NOW() where id=inuserid;

select count(id) as isalive FROM school_parent_master a WHERE id=inuserid AND session_id=inlogin_session_id AND status=1;

END IF;

END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `checkuserisactive` (IN `inuserid` VARCHAR(11), IN `inlogin_session_id` VARCHAR(255))  BEGIN

IF(inuserid!='')THEN

Update users SET last_active_datetime=NOW() where id=inuserid;

select count(id) as isalive FROM users a WHERE id=inuserid AND session_id=inlogin_session_id AND status=1;

END IF;


END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `GameAssignLogic` (IN `inChildID` INT(11), IN `inorg_id` INT(11), IN `ingrade_id` INT(11), IN `ingp_id` INT(11), IN `insid` INT(11), IN `insection` VARCHAR(16), IN `inpuzzle_cycle` INT(11))  BEGIN

DECLARE OGameExist INT(11);
DECLARE OGameLimit INT(11);
DECLARE ONewGameAvailable INT(11);
DECLARE OPuzzleCyle INT(11);

SET OGameExist=(SELECT COUNT(*) from rand_selection where user_id=inChildID and grade_id=ingrade_id and played="N" order by id DESC limit 2);
SET OPuzzleCyle=inpuzzle_cycle;
IF(OGameExist=0 OR OGameExist=1)THEN
	SET OGameLimit=2-OGameExist;
	IF(OGameLimit!=0)THEN
	
		SET ONewGameAvailable=(select count(gid) from game_group_mapping where org_id=inorg_id and grade_id=ingrade_id and status=1 and gid not in(select gid from rand_selection where user_id=inChildID and (puzzle_cycle=inpuzzle_cycle OR played="N") ) order by id ASC limit OGameLimit);
		IF(ONewGameAvailable=0)THEN
		
			SET OPuzzleCyle=inpuzzle_cycle+1;
		
			INSERT INTO rand_selection (gc_id, gs_id, gid, gp_id, grade_id, section, school_id, user_id, created_date, puzzle_cycle)
			select 1 as gc_id,groupid,gid,ingp_id,ingrade_id,insection,insid,inChildID,NOW(),OPuzzleCyle from game_group_mapping where org_id=inorg_id and grade_id=ingrade_id and status=1 and gid not in(select gid from rand_selection where user_id=inChildID and (puzzle_cycle=OPuzzleCyle OR played="N") ) order by id ASC limit OGameLimit;
			
			UPDATE users SET puzzle_cycle=OPuzzleCyle WHERE id=inChildID;
			 
		ELSE
			SET OPuzzleCyle=inpuzzle_cycle;
			INSERT INTO rand_selection (gc_id, gs_id, gid, gp_id, grade_id, section, school_id, user_id, created_date, puzzle_cycle)
			select 1 as gc_id,groupid,gid,ingp_id,ingrade_id,insection,insid,inChildID,NOW(),OPuzzleCyle from game_group_mapping where org_id=inorg_id and grade_id=ingrade_id and status=1 and gid not in(select gid from rand_selection where user_id=inChildID and (puzzle_cycle=OPuzzleCyle OR played="N") ) order by id ASC limit OGameLimit;
		
		END IF;
		
	END IF;

END IF;


SELECT g.gname,rs.gid,g.img_path,g.game_html,rs.puzzle_cycle,

(select count(*) as tot_game_played from game_reports where gu_id = inChildID and puzzle_cycle=OPuzzleCyle and site_type="WEB" and g_id=rs.gid) as tot_game_played,

(select count(DISTINCT g_id) from game_reports where gu_id = inChildID and site_type="WEB" and lastupdate=CURDATE()) as played_game_day,

(select MAX(game_score) from game_reports where gu_id =  inChildID and puzzle_cycle=rs.puzzle_cycle and site_type="WEB" and g_id=rs.gid) as tot_game_score,

(select COALESCE(SUM(star),0) from game_reports where gu_id =  inChildID and puzzle_cycle=rs.puzzle_cycle and site_type="WEB"  and g_id=rs.gid) as TotalStar 

from rand_selection  as rs

JOIN games AS g ON rs.gid = g.gid

where user_id=inChildID and played="N" order by id DESC limit 2;


END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `GetBadgeData` (IN `inSID` INT(11), IN `inGID` INT(11), IN `instartdate` DATE, IN `inenddate` DATE)  BEGIN

DECLARE OUTSPARKY TEXT;
DECLARE OUTSUPERBRAIN TEXT;
DECLARE OUTSUPERGOER TEXT;
DECLARE OUTSUPERANGEL TEXT;
DECLARE OUTISEXIST INT(11);

SET OUTISEXIST=(SELECT COUNT(ID) from userbadge_data where S_ID=inSID and G_ID=inGID and MonthNumber=date_format(CURDATE()-INTERVAL 1 MONTH,'%m'));

IF(OUTISEXIST=0)THEN

SET OUTSPARKY=(select group_concat(U_ID) as U_ID from (select U_ID,points,monthName,monthNumber,S_ID,G_ID from (select a2.U_ID AS U_ID,sum(a2.Points) AS points,date_format(a2.Datetime,'%b') AS monthName,date_format(a2.Datetime,'%m') AS monthNumber,a2.S_ID,a2.G_ID from user_sparkies_history a2 where (date_format(a2.Datetime,'%Y-%m-%d') between instartdate and inenddate) group by date_format(a2.Datetime,'%m'),a2.U_ID) a1 where a1.G_ID=inGID and a1.S_ID=inSID and a1.points=(select points from vv2 where vv2.monthNumber =a1.monthNumber and vv2.monthNumber=date_format(CURDATE()-INTERVAL 1 MONTH,'%m')  and vv2.G_ID=inGID and vv2.S_ID=inSID ) ) as a5 group by monthNumber);

SET OUTSUPERBRAIN=(select GROUP_CONCAT(gu_id) as gu_id from(select bspi,monthName,monthNumber,sid,gu_id,grade_id,(select username from users where id = gu_id) as username,(select classname from class where id = grade_id)as classname,(select school_name from schools where id = sid)as school_name from(select avg(bspi2.score) AS bspi,bspi2.gu_id AS gu_id,date_format(bspi2.lastupdate,'%m') AS monthNumber,date_format(bspi2.lastupdate,'%b') AS monthName,u.sid AS sid,u.grade_id AS grade_id from (vi_1dayuserscore bspi2 join users u on((u.id = bspi2.gu_id))) where (date_format(bspi2.lastupdate,'%Y-%m-%d') between instartdate and inenddate) group by bspi2.gu_id,month(bspi2.lastupdate)) as a1 where a1.grade_id=inGID and a1.sid=inSID and ROUND(a1.bspi,2)=(select bspi from vi_maxbspibymsg as vv3 where vv3.monthNumber =a1.monthNumber and vv3.monthNumber=date_format(CURDATE()-INTERVAL 1 MONTH,'%m') and vv3.grade_id=inGID and vv3.sid=inSID)) as a5 group by monthNumber);

SET OUTSUPERGOER=(select group_concat(gu_id) as gu_id from (select countofplayed,gu_id,monthName,monthNumber,grad_ID,gs_ID,(select username from users where id = gu_id) as username from (select count(gu_id) AS countofplayed,gu_id AS gu_id,date_format(lastupdate,'%b') AS monthName,date_format(lastupdate,'%m') AS monthNumber,(select sid from users where (id = gu_id)) AS gs_ID,(select grade_id from users where (id = gu_id)) AS grad_ID from game_reports where (convert(date_format(lastupdate,'%Y-%m-%d') using latin1) between instartdate and inenddate) group by date_format(lastupdate,'%m'),gu_id) a1 where a1.grad_ID=inGID and a1.gs_ID=inSID and a1.countofplayed in (select countofval from vi_gameplayed v where v.monthNumber=a1.monthNumber and v.monthNumber=date_format(CURDATE()-INTERVAL 1 MONTH,'%m')  and v.school_id=inSID and v.grad_id=inGID) ) as a5 group by monthNumber);

SET OUTSUPERANGEL=(select group_concat(gu_id) as gu_id from (select ans,gu_id,monthName,monthNumber,grad_ID,gs_ID,(select username from users where id = gu_id) as username from (select sum(answer) as ans,game_reports.gu_id AS gu_id,date_format(game_reports.lastupdate,'%b') AS monthName,date_format(game_reports.lastupdate,'%m') AS monthNumber,(select users.sid from users where (users.id = game_reports.gu_id)) AS gs_ID,(select users.grade_id from users where (users.id = game_reports.gu_id)) AS grad_ID from game_reports where (convert(date_format(game_reports.lastupdate,'%Y-%m-%d') using latin1) between instartdate and inenddate) group by date_format(game_reports.lastupdate,'%m'),game_reports.gu_id) a1 where a1.grad_ID=inGID and a1.gs_ID=inSID and a1.ans in (select ans from superangel v where v.monthNumber=a1.monthNumber and v.monthNumber=date_format(CURDATE()-INTERVAL 1 MONTH,'%m') and v.gs_ID=inSID and v.grad_ID=inGID)) as a5 group by monthNumber);


INSERT INTO userbadge_data(S_ID,G_ID,MonthNumber,Sparkies,SuperBrian,SuperGoer,SuperAngel,isexist,Datetime)SELECT inSID,inGID,date_format(CURDATE()-INTERVAL 1 MONTH,'%m'),OUTSPARKY,OUTSUPERBRAIN,OUTSUPERGOER,OUTSUPERANGEL,1,NOW();

END IF;


END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getMyCurrentSparkies` (IN `inSID` INT(11), IN `inGID` INT(11), IN `inUID` INT(11), IN `instartdate` DATE, IN `inenddate` DATE)  BEGIN

Select sum(Points) as mysparkies from user_sparkies_history where S_ID=inSID and G_ID=inGID and U_ID=inUID AND DATE(Datetime) between instartdate and inenddate;

END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getMyCurrentSparkies~old` (IN `inSID` INT(11), IN `inGID` INT(11), IN `inUID` INT(11))  BEGIN

Select sum(Points) as mysparkies from user_sparkies_history where S_ID=inSID and G_ID=inGID and U_ID=inUID;

END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getNewsFeed` (IN `inSID` INT(11), IN `inGID` INT(11), IN `inUID` INT(11), IN `intype` VARCHAR(55), IN `instartdate` DATE, IN `inenddate` DATE)  BEGIN

DECLARE OUTTYPE INT(11);

IF(intype='ALL')THEN
	SET OUTTYPE=(select Type from newsfeed_config where status=1);
	IF(OUTTYPE=1)THEN
		SELECT U_ID,(select avatarimage from users where id=U_ID) as avatarimage,REPLACE(scenario,'#NAME#',(select username from users where id=U_ID)) as scenario from user_newsfeed_history where S_ID=inSID and U_ID in (select id from users where status=1 and visible=1)  AND DATE(Datetime) between instartdate and inenddate  ORDER BY ID DESC LIMIT 100;
	ELSE
		SELECT U_ID,(select avatarimage from users where id=U_ID) as avatarimage,REPLACE(scenario,'#NAME#',(select username from users where id=U_ID)) as scenario from user_newsfeed_history where G_ID=inGID and U_ID in (select id from users where status=1 and visible=1) AND DATE(Datetime) between instartdate and inenddate  ORDER BY ID DESC LIMIT 100;
	END IF;
ELSE
		SELECT U_ID,(select avatarimage from users where id=U_ID) as avatarimage,REPLACE(scenario,'#NAME#','You') as scenario from user_newsfeed_history where U_ID=inUID and U_ID in (select id from users where status=1 and visible=1) AND DATE(Datetime) between instartdate and inenddate ORDER BY ID DESC LIMIT 100;	
END IF;
	
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getNewsFeedCount` (IN `inSID` INT(11), IN `inGID` INT(11), IN `inUID` INT(11), IN `intype` VARCHAR(55), IN `instartdate` DATE, IN `inenddate` DATE)  BEGIN
DECLARE OUTTYPE INT(11);
DECLARE OUTMINECOUNT INT(11);
DECLARE OUTALLCOUNT INT(11);


	SET OUTTYPE=(select Type from newsfeed_config where status=1);
	IF(OUTTYPE=1)THEN
		SET OUTALLCOUNT=(SELECT COUNT(U_ID) As ALLCount from user_newsfeed_history where S_ID=inSID and U_ID in (select id from users where status=1 and visible=1) AND DATE(Datetime) between instartdate and inenddate AND DATE(Datetime)=CURDATE() ORDER BY ID DESC);
	ELSE
		SET OUTALLCOUNT=(SELECT COUNT(U_ID) As ALLCount from user_newsfeed_history where S_ID=inSID and G_ID=inGID and U_ID in (select id from users where status=1 and visible=1) AND DATE(Datetime) between instartdate and inenddate AND DATE(Datetime)=CURDATE() ORDER BY ID DESC);
	END IF;

		SET OUTMINECOUNT=(SELECT COUNT(U_ID) As MineCount from user_newsfeed_history where U_ID=inUID and U_ID in (select id from users where status=1 and visible=1) AND DATE(Datetime) between instartdate and inenddate AND DATE(Datetime)=CURDATE() ORDER BY ID DESC);	

	
select 	OUTALLCOUNT,OUTMINECOUNT;

END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getNewsFeedCount~old` (IN `inSID` INT(11), IN `inGID` INT(11), IN `inUID` INT(11), IN `intype` VARCHAR(55))  BEGIN
DECLARE OUTTYPE INT(11);
DECLARE OUTMINECOUNT INT(11);
DECLARE OUTALLCOUNT INT(11);


	SET OUTTYPE=(select Type from newsfeed_config where status=1);
	IF(OUTTYPE=1)THEN
		SET OUTALLCOUNT=(SELECT COUNT(U_ID) As ALLCount from user_newsfeed_history where S_ID=inSID  ORDER BY ID DESC);
	ELSE
		SET OUTALLCOUNT=(SELECT COUNT(U_ID) As ALLCount from user_newsfeed_history where G_ID=inGID ORDER BY ID DESC);
	END IF;

		SET OUTMINECOUNT=(SELECT COUNT(U_ID) As MineCount from user_newsfeed_history where U_ID=inUID ORDER BY ID DESC);	

	
select 	OUTALLCOUNT,OUTMINECOUNT;

END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getNewsFeed~old` (IN `inSID` INT(11), IN `inGID` INT(11), IN `inUID` INT(11), IN `intype` VARCHAR(55))  BEGIN

DECLARE OUTTYPE INT(11);

IF(intype='ALL')THEN
	SET OUTTYPE=(select Type from newsfeed_config where status=1);
	IF(OUTTYPE=1)THEN
		SELECT U_ID,(select avatarimage from users where id=U_ID) as avatarimage,REPLACE(scenario,'#NAME#',(select username from users where id=U_ID)) as scenario from user_newsfeed_history where S_ID=inSID  ORDER BY ID DESC;
	ELSE
		SELECT U_ID,(select avatarimage from users where id=U_ID) as avatarimage,REPLACE(scenario,'#NAME#',(select username from users where id=U_ID)) as scenario from user_newsfeed_history where G_ID=inGID ORDER BY ID DESC;
	END IF;
ELSE
		SELECT U_ID,(select avatarimage from users where id=U_ID) as avatarimage,REPLACE(scenario,'#NAME#','You') as scenario from user_newsfeed_history where U_ID=inUID ORDER BY ID DESC;	
END IF;
	
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `insertbandwidth` (IN `inschoolid` INT(11), IN `inuser_id` INT(11), IN `inBps` VARCHAR(110), IN `inKbps` VARCHAR(110), IN `inMbps` VARCHAR(110))  BEGIN
DECLARE OUTisexist INT(11);
SET OUTisexist=(select count(ID) as isexist from bandwidth_log where school_id=inschoolid and TIMESTAMPDIFF(MINUTE,`updatedtime`,now())<(select TimeInterval from bandwidth_config where ID=1 and status=1) and status=1);

IF(OUTisexist=0)THEN
	Insert into bandwidth_log(school_id,user_id,bandwidth_bps,bandwidth_kbps,bandwidth_mbps,status,updatedtime)values(inschoolid,inuser_id,inBps,inKbps,inMbps,1,NOW());
END IF;

END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `insertnewsfeeddata` (IN `inSID` INT(11), IN `inGID` INT(11), IN `inUID` INT(11), IN `inScenarioCode` VARCHAR(55), IN `inTotal_Ques` INT(11), IN `inAttempt_Ques` INT(11), IN `inAnswer` INT(11), IN `inGame_Score` INT(11), IN `inPlanid` INT(11), IN `inGameid` INT(11), IN `inDate` VARCHAR(55))  BEGIN

DECLARE OUTGAMENAME VARCHAR(55);
DECLARE OUTNTHTIME INT(11);
DECLARE NOOFTIMESPLAY INT(11);
DECLARE OUTSKILLNAME VARCHAR(55);
DECLARE OUTCURPOSITION INT(11);
DECLARE OUTSTATUS INT(11);
DECLARE OUTTHEME VARCHAR(55);
DECLARE OUTLASTMONDATA INT(11);

SET OUTGAMENAME=(SELECT gname from games where gid=inGameid);
SET OUTNTHTIME=(SELECT COUNT(*) from game_reports where g_id=inGameid AND gp_id=inPlanid and gu_id=inUID and lastupdate=CURDATE());
SET NOOFTIMESPLAY=(SELECT ntimes from game_limit where g_id=inGameid AND gp_id=inPlanid);
SET OUTSKILLNAME=(SELECT name from category_skills where id=(select gs_id from games where gid=inGameid));

IF(inScenarioCode='GAME_END')THEN
	INSERT INTO user_newsfeed_history(S_ID,G_ID,U_ID,Scenario,Datetime)SELECT inSID,inGID,inUID,REPLACE(REPLACE(Scenario,'#GN#',OUTGAMENAME),'#NTH#',OUTNTHTIME),NOW() from newsfeedmaster where Code='1GAME_COMPLETE' and Status=1; 	
	IF(NOOFTIMESPLAY=OUTNTHTIME)THEN
	INSERT INTO user_newsfeed_history(S_ID,G_ID,U_ID,Scenario,Datetime)SELECT inSID,inGID,inUID,REPLACE(Scenario,'#SKILLNAME#',OUTSKILLNAME),NOW() from newsfeedmaster where Code='1SKILL_COMPLETE' and Status=1;
	END IF;
END IF;

    SET OUTCURPOSITION=(Select FLOOR(sum(Points)/100) as curpos from user_sparkies_history where S_ID=inSID and G_ID=inGID and U_ID=inUID);
	IF(OUTCURPOSITION!=0)THEN
	SET OUTSTATUS=(select count(ID) from newsfeed_data_status where U_ID=inUID and Value=OUTCURPOSITION and Value!=0);
	ELSE
	SET OUTSTATUS=-1;
	END IF;
	IF(OUTSTATUS=0)THEN
	INSERT INTO user_newsfeed_history(S_ID,G_ID,U_ID,Scenario,Datetime)SELECT inSID,inGID,inUID,REPLACE(Scenario,'#POINTVAL#',(OUTCURPOSITION*100)),NOW() from newsfeedmaster where Code='SPARKEY_LIMIT' and Status=1;
	INSERT INTO newsfeed_data_status(S_ID,G_ID,U_ID,Value)SELECT inSID,inGID,inUID,OUTCURPOSITION;
           IF(OUTCURPOSITION=10 || OUTCURPOSITION=20 || OUTCURPOSITION=30 || OUTCURPOSITION=40)THEN
	SET OUTTHEME=(SELECT theme_name from thememaster where sparky_range=(OUTCURPOSITION*100) and status=1);
		INSERT INTO user_newsfeed_history(S_ID,G_ID,U_ID,Scenario,Datetime)SELECT inSID,inGID,inUID,REPLACE(Scenario,'#THEME#',OUTTHEME),NOW() from newsfeedmaster where Code='THEME_ACTIVATION' and Status=1;	
	END IF;
    
	END IF;
    
    SET OUTLASTMONDATA=(SELECT COUNT(ID) from userbadge_data where S_ID=inSID and G_ID=inGID and MonthNumber=date_format(CURDATE()-INTERVAL 1 MONTH,'%m') and isexist=1);
IF(OUTLASTMONDATA>=1)THEN
		
    INSERT INTO user_newsfeed_history(S_ID,G_ID,U_ID,Scenario,Datetime)SELECT inSID,inGID,id,REPLACE(REPLACE((select Scenario from newsfeedmaster where Code='BADGES' and Status=1),'#MONTH#',CONCAT(date_format(CURDATE()-INTERVAL 1 MONTH,'%b'),'-',date_format(CURDATE(),'%Y'))),'#B#','Super Brain'),NOW() FROM users where FIND_IN_SET(id,(select SuperBrian from userbadge_data where S_ID=inSID and G_ID=inGID and MonthNumber=date_format(CURDATE()-INTERVAL 1 MONTH,'%m') and isexist=1));
	
	INSERT INTO user_newsfeed_history(S_ID,G_ID,U_ID,Scenario,Datetime)SELECT inSID,inGID,id,REPLACE(REPLACE((select Scenario from newsfeedmaster where Code='BADGES' and Status=1),'#MONTH#',CONCAT(date_format(CURDATE()-INTERVAL 1 MONTH,'%b'),'-',date_format(CURDATE(),'%Y'))),'#B#','Super Goer'),NOW() FROM users where FIND_IN_SET(id,(select SuperGoer from userbadge_data where S_ID=inSID and G_ID=inGID and MonthNumber=date_format(CURDATE()-INTERVAL 1 MONTH,'%m') and isexist=1));
	
	INSERT INTO user_newsfeed_history(S_ID,G_ID,U_ID,Scenario,Datetime)SELECT inSID,inGID,id,REPLACE(REPLACE((select Scenario from newsfeedmaster where Code='BADGES' and Status=1),'#MONTH#',CONCAT(date_format(CURDATE()-INTERVAL 1 MONTH,'%b'),'-',date_format(CURDATE(),'%Y'))),'#B#','Super Angel'),NOW() FROM users where FIND_IN_SET(id,(select SuperAngel from userbadge_data where S_ID=inSID and G_ID=inGID and MonthNumber=date_format(CURDATE()-INTERVAL 1 MONTH,'%m') and isexist=1));
UPDATE userbadge_data SET isexist=0 where S_ID=inSID and G_ID=inGID and MonthNumber=date_format(CURDATE()-INTERVAL 1 MONTH,'%m');	
	
END IF;



END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `insertsparkies` (IN `inSID` INT(11), IN `inGID` INT(11), IN `inUID` INT(11), IN `inScenarioCode` VARCHAR(55), IN `inTotal_Ques` INT(11), IN `inAttempt_Ques` INT(11), IN `inAnswer` INT(11), IN `inGame_Score` INT(11), IN `inDateTime` VARCHAR(55))  BEGIN



IF(inScenarioCode='GAME_END')THEN

	INSERT INTO user_sparkies_history(S_ID,G_ID,U_ID,Scenario_ID,Type,Points,Datetime)SELECT inSID,inGID,inUID,ID,Type,Points,inDateTime from sparkiesmaster where Code='ONE_Q' and Status=1;

END IF;


END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `insertsparkiesnew` (IN `inSID` INT(11), IN `inGID` INT(11), IN `inUID` INT(11), IN `inScenarioCode` VARCHAR(55), IN `inTotal_Ques` INT(11), IN `inAttempt_Ques` INT(11), IN `inAnswer` INT(11), IN `inGame_Score` INT(11), IN `inPlanid` INT(11), IN `inGameid` INT(11), IN `inDateTime` VARCHAR(55))  BEGIN

DECLARE OUTPOINTS INT(11);
DECLARE NOOFTIMESPLAY INT(11);
DECLARE NOOFTIMESPLAYED INT(11);
DECLARE OUTWEEKEND INT(11);
DECLARE OUTFIRSTLOGIN INT(11);
DECLARE OUTSECTIONNAME Varchar(16);
DECLARE OUTGRADENAME Varchar(16);
DECLARE OUTAVAIBILITY INT(11);	
DECLARE OUTTIME INT(11);
DECLARE OUTAID INT(11);

SET OUTPOINTS=0;

IF(inScenarioCode='GAME_END')THEN
	IF(inAttempt_Ques>=1)THEN 
		INSERT INTO user_sparkies_history(S_ID,G_ID,U_ID,Scenario_ID,Type,Points,Datetime,ScenarioCode,Gameid)SELECT inSID,inGID,inUID,ID,Type,(inAttempt_Ques * Points),inDateTime,inScenarioCode,inGameid from sparkiesmaster where Code='ONE_Q' and Status=1;
		SET OUTPOINTS=OUTPOINTS + (inAttempt_Ques * (SELECT Points from sparkiesmaster where Code='ONE_Q' and Status=1));
	END IF;	
	IF(inAttempt_Ques='10')THEN
		INSERT INTO user_sparkies_history(S_ID,G_ID,U_ID,Scenario_ID,Type,Points,Datetime,ScenarioCode,Gameid)SELECT inSID,inGID,inUID,ID,Type,Points,inDateTime,inScenarioCode,inGameid from sparkiesmaster where Code='ALL_Q' and Status=1;
		SET OUTPOINTS=OUTPOINTS + (SELECT Points from sparkiesmaster where Code='ALL_Q' and Status=1);
	END IF;
	IF(inAnswer>=1)THEN
		INSERT INTO user_sparkies_history(S_ID,G_ID,U_ID,Scenario_ID,Type,Points,Datetime,ScenarioCode,Gameid)SELECT inSID,inGID,inUID,ID,Type,(inAnswer * Points),inDateTime,inScenarioCode,inGameid from sparkiesmaster where Code='1QC' and Status=1;
		SET OUTPOINTS=OUTPOINTS + (inAnswer * (SELECT Points from sparkiesmaster where Code='1QC' and Status=1));
	END IF;
	IF(inAnswer='10')THEN
		INSERT INTO user_sparkies_history(S_ID,G_ID,U_ID,Scenario_ID,Type,Points,Datetime,ScenarioCode,Gameid)SELECT inSID,inGID,inUID,ID,Type,Points,inDateTime,inScenarioCode,inGameid from sparkiesmaster where Code='10QC' and Status=1;
		SET OUTPOINTS=OUTPOINTS + (SELECT Points from sparkiesmaster where Code='10QC' and Status=1);
	END IF;	
	IF(inGame_Score>=60)THEN
		INSERT INTO user_sparkies_history(S_ID,G_ID,U_ID,Scenario_ID,Type,Points,Datetime,ScenarioCode,Gameid)SELECT inSID,inGID,inUID,ID,Type,Points,inDateTime,inScenarioCode,inGameid from sparkiesmaster where Code='ABOVE_60' and Status=1;
		SET OUTPOINTS=OUTPOINTS + (SELECT Points from sparkiesmaster where Code='ABOVE_60' and Status=1);
	END IF;
    
    SET NOOFTIMESPLAY=(SELECT ntimes from game_limit where g_id=inGameid AND gp_id=inPlanid );
	SET NOOFTIMESPLAYED=(SELECT COUNT(*) from game_reports where g_id=inGameid AND gp_id=inPlanid and gu_id=inUID and lastupdate=CURDATE());
	IF(NOOFTIMESPLAY=NOOFTIMESPLAYED)THEN
		INSERT INTO user_sparkies_history(S_ID,G_ID,U_ID,Scenario_ID,Type,Points,Datetime,ScenarioCode,Gameid)SELECT inSID,inGID,inUID,ID,Type,Points,inDateTime,inScenarioCode,inGameid from sparkiesmaster where Code='ALL5TGP' and Status=1;
		SET OUTPOINTS=OUTPOINTS + (SELECT Points from sparkiesmaster where Code='ALL5TGP' and Status=1);
	END IF;
		
    INSERT INTO user_sparkies_history(S_ID,G_ID,U_ID,Scenario_ID,Type,Points,Datetime,ScenarioCode,Gameid)SELECT inSID,inGID,inUID,ID,Type,Points,inDateTime,inScenarioCode,inGameid from sparkiesmaster where Code='NOTPOAG' and Status=1;
    
	SET OUTPOINTS=OUTPOINTS + (SELECT Points from sparkiesmaster where Code='NOTPOAG' and Status=1);
    
END IF;
IF(inScenarioCode='LOGIN')THEN
	SET OUTFIRSTLOGIN=(select count(ID) as firstlogin  from user_sparkies_history where U_ID=inUID and date(Datetime)=CURDATE());
	SET OUTWEEKEND=(SELECT DAYOFWEEK(CURDATE()) = 7 or DAYOFWEEK(CURDATE()) =1);
	
			SET OUTSECTIONNAME=(select section from users where id=inUID);
			SET OUTGRADENAME=(select grade_id from users where id=inUID);
			SET OUTTIME=(SELECT curtime() >= '18:00:00' OR curtime() <= "06:00:00");
			SET OUTAID=(select academic_id from schools where id=inSID);
			
			SET OUTAVAIBILITY=(select (CASE DAYNAME(NOW())
            WHEN 'Monday'    THEN (SELECT '1' from schools_period_schedule where `monday_grade`=(select replace(classname,'Grade ','') from class where id=OUTGRADENAME) and `monday_section`=OUTSECTIONNAME and `school_id`=inSID and academic_id=OUTAID)
            WHEN 'Tuesday'   THEN (SELECT '1' from schools_period_schedule where `tuesday_grade`=(select replace(classname,'Grade ','') from class where id=OUTGRADENAME) and `tuesday_section`=OUTSECTIONNAME and `school_id`=inSID and academic_id=OUTAID)
            WHEN 'Wednesday' THEN (SELECT '1' from schools_period_schedule where `wednesday_grade`=(select replace(classname,'Grade ','') from class where id=OUTGRADENAME) and `wednesday_section`=OUTSECTIONNAME and `school_id`=inSID and academic_id=OUTAID)
            WHEN 'Thursday'  THEN (SELECT '1' from schools_period_schedule where `thursday_grade`=(select replace(classname,'Grade ','') from class where id=OUTGRADENAME) and `thursday_section`=OUTSECTIONNAME and `school_id`=inSID and academic_id=OUTAID)
            WHEN 'Friday'    THEN (SELECT '1' from schools_period_schedule where `friday_grade`=(select replace(classname,'Grade ','') from class where id=OUTGRADENAME) and `friday_section`=OUTSECTIONNAME and `school_id`=inSID and academic_id=OUTAID)
			WHEN 'Saturday'    THEN (SELECT '1' from schools_period_schedule where `saturday_grade`=(select replace(classname,'Grade ','') from class where id=OUTGRADENAME) and `saturday_section`=OUTSECTIONNAME and `school_id`=inSID and academic_id=OUTAID)
			WHEN 'Friday'    THEN (SELECT '1' from schools_period_schedule where `sunday_grade`=(select replace(classname,'Grade ','') from class where id=OUTGRADENAME) and `sunday_section`=OUTSECTIONNAME and `school_id`=inSID and academic_id=OUTAID)
            END) as isexist);
			
		IF(OUTFIRSTLOGIN=0)THEN 
			IF(OUTWEEKEND=1)THEN
				INSERT INTO user_sparkies_history(S_ID,G_ID,U_ID,Scenario_ID,Type,Points,Datetime,ScenarioCode)SELECT inSID,inGID,inUID,ID,Type,Points,NOW(),inScenarioCode from sparkiesmaster where Code='WEEKEND' and Status=1;
				SET OUTPOINTS=OUTPOINTS + (SELECT Points from sparkiesmaster where Code='WEEKEND' and Status=1);
			END IF;
			
			IF(OUTAVAIBILITY=1)THEN
				INSERT INTO user_sparkies_history(S_ID,G_ID,U_ID,Scenario_ID,Type,Points,Datetime,ScenarioCode)SELECT inSID,inGID,inUID,ID,Type,Points,NOW(),inScenarioCode from sparkiesmaster where Code='FLOSSD' and Status=1;
				SET OUTPOINTS=OUTPOINTS + (SELECT Points from sparkiesmaster where Code='FLOSSD' and Status=1);
			ELSE
				INSERT INTO user_sparkies_history(S_ID,G_ID,U_ID,Scenario_ID,Type,Points,Datetime,ScenarioCode)SELECT inSID,inGID,inUID,ID,Type,Points,NOW(),inScenarioCode from sparkiesmaster where Code='FLFH' and Status=1;
				SET OUTPOINTS=OUTPOINTS + (SELECT Points from sparkiesmaster where Code='FLFH' and Status=1);
			
			END IF;
			
			IF(OUTTIME=1)THEN
				INSERT INTO user_sparkies_history(S_ID,G_ID,U_ID,Scenario_ID,Type,Points,Datetime,ScenarioCode)SELECT inSID,inGID,inUID,ID,Type,Points,NOW(),inScenarioCode from sparkiesmaster where Code='6T6' and Status=1;
				SET OUTPOINTS=OUTPOINTS + (SELECT Points from sparkiesmaster where Code='6T6' and Status=1);
			END IF;
            
			IF(LAST_DAY(CURDATE())=date(NOW()))THEN
				IF(day(last_day(CURDATE()))=(SELECT count(distinct(date(Datetime))) as monplayed from user_sparkies_history where month(Datetime)=MONTH(NOW()) and U_ID=inUID))THEN
					INSERT INTO user_sparkies_history(S_ID,G_ID,U_ID,Scenario_ID,Type,Points,Datetime,ScenarioCode)SELECT inSID,inGID,inUID,ID,Type,Points,NOW(),inScenarioCode from sparkiesmaster where Code='ALLDAY' and Status=1;
					SET OUTPOINTS=OUTPOINTS + (SELECT Points from sparkiesmaster where Code='ALLDAY' and Status=1);
				END IF;
			END IF;
	
		END IF;
END IF;


SELECT OUTPOINTS;
 
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `insertsparkiesnew~100417` (IN `inSID` INT(11), IN `inGID` INT(11), IN `inUID` INT(11), IN `inScenarioCode` VARCHAR(55), IN `inTotal_Ques` INT(11), IN `inAttempt_Ques` INT(11), IN `inAnswer` INT(11), IN `inGame_Score` INT(11), IN `inPlanid` INT(11), IN `inGameid` INT(11), IN `inDateTime` VARCHAR(55))  BEGIN

DECLARE OUTPOINTS INT(11);
DECLARE NOOFTIMESPLAY INT(11);
DECLARE NOOFTIMESPLAYED INT(11);

SET OUTPOINTS=0;

IF(inScenarioCode='GAME_END')THEN
	IF(inAttempt_Ques>=1)THEN 
		INSERT INTO user_sparkies_history(S_ID,G_ID,U_ID,Scenario_ID,Type,Points,Datetime)SELECT inSID,inGID,inUID,ID,Type,Points,inDateTime from sparkiesmaster where Code='ONE_Q' and Status=1;
		SET OUTPOINTS=OUTPOINTS + (SELECT Points from sparkiesmaster where Code='ONE_Q' and Status=1);
	END IF;	
	IF(inAttempt_Ques='10')THEN
		INSERT INTO user_sparkies_history(S_ID,G_ID,U_ID,Scenario_ID,Type,Points,Datetime)SELECT inSID,inGID,inUID,ID,Type,Points,inDateTime from sparkiesmaster where Code='ALL_Q' and Status=1;
		SET OUTPOINTS=OUTPOINTS + (SELECT Points from sparkiesmaster where Code='ALL_Q' and Status=1);
	END IF;
	IF(inAnswer>=1)THEN
		INSERT INTO user_sparkies_history(S_ID,G_ID,U_ID,Scenario_ID,Type,Points,Datetime)SELECT inSID,inGID,inUID,ID,Type,Points,inDateTime from sparkiesmaster where Code='1QC' and Status=1;
		SET OUTPOINTS=OUTPOINTS + (SELECT Points from sparkiesmaster where Code='1QC' and Status=1);
	END IF;
	IF(inAnswer='10')THEN
		INSERT INTO user_sparkies_history(S_ID,G_ID,U_ID,Scenario_ID,Type,Points,Datetime)SELECT inSID,inGID,inUID,ID,Type,Points,inDateTime from sparkiesmaster where Code='10QC' and Status=1;
		SET OUTPOINTS=OUTPOINTS + (SELECT Points from sparkiesmaster where Code='10QC' and Status=1);
	END IF;	
	IF(inGame_Score>=60)THEN
		INSERT INTO user_sparkies_history(S_ID,G_ID,U_ID,Scenario_ID,Type,Points,Datetime)SELECT inSID,inGID,inUID,ID,Type,Points,inDateTime from sparkiesmaster where Code='ABOVE_60' and Status=1;
		SET OUTPOINTS=OUTPOINTS + (SELECT Points from sparkiesmaster where Code='ABOVE_60' and Status=1);
	END IF;
    
    SET NOOFTIMESPLAY=(SELECT ntimes from game_limit where g_id=inGameid AND gp_id=inPlanid);
	SET NOOFTIMESPLAYED=(SELECT COUNT(id) from game_reports where g_id=inGameid AND gp_id=inPlanid and gu_id=inUID);
	IF(NOOFTIMESPLAY=NOOFTIMESPLAYED)THEN
		INSERT INTO user_sparkies_history(S_ID,G_ID,U_ID,Scenario_ID,Type,Points,Datetime)SELECT inSID,inGID,inUID,ID,Type,Points,inDateTime from sparkiesmaster where Code='ALL5TGP' and Status=1;
		SET OUTPOINTS=OUTPOINTS + (SELECT Points from sparkiesmaster where Code='ALL5TGP' and Status=1);
	END IF;
    
    

END IF;

SELECT  OUTPOINTS;
 
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `insertsparkiesnew~100417.1` (IN `inSID` INT(11), IN `inGID` INT(11), IN `inUID` INT(11), IN `inScenarioCode` VARCHAR(55), IN `inTotal_Ques` INT(11), IN `inAttempt_Ques` INT(11), IN `inAnswer` INT(11), IN `inGame_Score` INT(11), IN `inPlanid` INT(11), IN `inGameid` INT(11), IN `inDateTime` VARCHAR(55))  BEGIN

DECLARE OUTPOINTS INT(11);
DECLARE NOOFTIMESPLAY INT(11);
DECLARE NOOFTIMESPLAYED INT(11);
DECLARE OUTWEEKEND INT(11);
DECLARE OUTFIRSTLOGIN INT(11);
DECLARE OUTSECTIONNAME Varchar(16);
DECLARE OUTGRADENAME Varchar(16);
DECLARE OUTCOLGRADENAME VARCHAR(55);
DECLARE OUTCOLSECTIONNAME VARCHAR(55);
DECLARE OUTAVAIBILITY INT(11);	
	
SET OUTPOINTS=0;

IF(inScenarioCode='GAME_END')THEN
	IF(inAttempt_Ques>=1)THEN 
		INSERT INTO user_sparkies_history(S_ID,G_ID,U_ID,Scenario_ID,Type,Points,Datetime)SELECT inSID,inGID,inUID,ID,Type,Points,inDateTime from sparkiesmaster where Code='ONE_Q' and Status=1;
		SET OUTPOINTS=OUTPOINTS + (SELECT Points from sparkiesmaster where Code='ONE_Q' and Status=1);
	END IF;	
	IF(inAttempt_Ques='10')THEN
		INSERT INTO user_sparkies_history(S_ID,G_ID,U_ID,Scenario_ID,Type,Points,Datetime)SELECT inSID,inGID,inUID,ID,Type,Points,inDateTime from sparkiesmaster where Code='ALL_Q' and Status=1;
		SET OUTPOINTS=OUTPOINTS + (SELECT Points from sparkiesmaster where Code='ALL_Q' and Status=1);
	END IF;
	IF(inAnswer>=1)THEN
		INSERT INTO user_sparkies_history(S_ID,G_ID,U_ID,Scenario_ID,Type,Points,Datetime)SELECT inSID,inGID,inUID,ID,Type,Points,inDateTime from sparkiesmaster where Code='1QC' and Status=1;
		SET OUTPOINTS=OUTPOINTS + (SELECT Points from sparkiesmaster where Code='1QC' and Status=1);
	END IF;
	IF(inAnswer='10')THEN
		INSERT INTO user_sparkies_history(S_ID,G_ID,U_ID,Scenario_ID,Type,Points,Datetime)SELECT inSID,inGID,inUID,ID,Type,Points,inDateTime from sparkiesmaster where Code='10QC' and Status=1;
		SET OUTPOINTS=OUTPOINTS + (SELECT Points from sparkiesmaster where Code='10QC' and Status=1);
	END IF;	
	IF(inGame_Score>=60)THEN
		INSERT INTO user_sparkies_history(S_ID,G_ID,U_ID,Scenario_ID,Type,Points,Datetime)SELECT inSID,inGID,inUID,ID,Type,Points,inDateTime from sparkiesmaster where Code='ABOVE_60' and Status=1;
		SET OUTPOINTS=OUTPOINTS + (SELECT Points from sparkiesmaster where Code='ABOVE_60' and Status=1);
	END IF;
    
    SET NOOFTIMESPLAY=(SELECT ntimes from game_limit where g_id=inGameid AND gp_id=inPlanid);
	SET NOOFTIMESPLAYED=(SELECT COUNT(id) from game_reports where g_id=inGameid AND gp_id=inPlanid and gu_id=inUID);
	IF(NOOFTIMESPLAY=NOOFTIMESPLAYED)THEN
		INSERT INTO user_sparkies_history(S_ID,G_ID,U_ID,Scenario_ID,Type,Points,Datetime)SELECT inSID,inGID,inUID,ID,Type,Points,inDateTime from sparkiesmaster where Code='ALL5TGP' and Status=1;
		SET OUTPOINTS=OUTPOINTS + (SELECT Points from sparkiesmaster where Code='ALL5TGP' and Status=1);
	END IF;
		
    INSERT INTO user_sparkies_history(S_ID,G_ID,U_ID,Scenario_ID,Type,Points,Datetime)SELECT inSID,inGID,inUID,ID,Type,Points,inDateTime from sparkiesmaster where Code='NOTPOAG' and Status=1;
	SET OUTPOINTS=OUTPOINTS + (SELECT Points from sparkiesmaster where Code='NOTPOAG' and Status=1);
    
END IF;
IF(inScenarioCode='LOGIN')THEN
	SET OUTFIRSTLOGIN=(select count(ID) as firstlogin  from user_sparkies_history where U_ID=inUID and date(Datetime)=CURDATE());
	SET OUTWEEKEND=(SELECT DAYOFWEEK(CURDATE()) = 7 or DAYOFWEEK(CURDATE()) = 1);
		IF(OUTFIRSTLOGIN=0)THEN 
			IF(OUTWEEKEND=1)THEN
				INSERT INTO user_sparkies_history(S_ID,G_ID,U_ID,Scenario_ID,Type,Points,Datetime)SELECT inSID,inGID,inUID,ID,Type,Points,inDateTime from sparkiesmaster where Code='WEEKEND' and Status=1;
				SET OUTPOINTS=OUTPOINTS + (SELECT Points from sparkiesmaster where Code='WEEKEND' and Status=1);
			END IF;
			
			SET OUTSECTIONNAME=(select section from users where id=inUID);
			SET OUTGRADENAME=(select REPLACE(classname,'Grade ','') as classname  from class  where id=(select grade_id from users where id=inUID));
            SET OUTCOLGRADENAME=(select CONCAT(LOWER(DAYNAME(CURDATE())),'_grade') as gradename from schools_period_schedule where school_id=inSID limit 1 );
			SET OUTCOLSECTIONNAME=(select CONCAT(LOWER(DAYNAME(CURDATE())),'_section') as sectionname from schools_period_schedule where school_id=inSID limit 1 );
	
    SET OUTAVAIBILITY=(SELECt COUNT(schedule_id) as availability from schools_period_schedule where school_id=inSID and OUTCOLGRADENAME=OUTGRADENAME and OUTCOLSECTIONNAME=OUTSECTIONNAME);
	
		END IF;
END IF;


SELECT OUTPOINTS,OUTCOLGRADENAME,OUTGRADENAME,OUTCOLSECTIONNAME,OUTSECTIONNAME,OUTAVAIBILITY;
 
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `insertsparkiesnew~200318` (IN `inSID` INT(11), IN `inGID` INT(11), IN `inUID` INT(11), IN `inScenarioCode` VARCHAR(55), IN `inTotal_Ques` INT(11), IN `inAttempt_Ques` INT(11), IN `inAnswer` INT(11), IN `inGame_Score` INT(11), IN `inPlanid` INT(11), IN `inGameid` INT(11), IN `inDateTime` VARCHAR(55))  BEGIN

DECLARE OUTPOINTS INT(11);
DECLARE NOOFTIMESPLAY INT(11);
DECLARE NOOFTIMESPLAYED INT(11);
DECLARE OUTWEEKEND INT(11);
DECLARE OUTFIRSTLOGIN INT(11);
DECLARE OUTSECTIONNAME Varchar(16);
DECLARE OUTGRADENAME Varchar(16);
DECLARE OUTAVAIBILITY INT(11);	
DECLARE OUTTIME INT(11);
DECLARE OUTAID INT(11);

SET OUTPOINTS=0;

IF(inScenarioCode='GAME_END')THEN
	IF(inAttempt_Ques>=1)THEN 
		INSERT INTO user_sparkies_history(S_ID,G_ID,U_ID,Scenario_ID,Type,Points,Datetime)SELECT inSID,inGID,inUID,ID,Type,(inAttempt_Ques * Points),inDateTime from sparkiesmaster where Code='ONE_Q' and Status=1;
		SET OUTPOINTS=OUTPOINTS + (inAttempt_Ques * (SELECT Points from sparkiesmaster where Code='ONE_Q' and Status=1));
	END IF;	
	IF(inAttempt_Ques='10')THEN
		INSERT INTO user_sparkies_history(S_ID,G_ID,U_ID,Scenario_ID,Type,Points,Datetime)SELECT inSID,inGID,inUID,ID,Type,Points,inDateTime from sparkiesmaster where Code='ALL_Q' and Status=1;
		SET OUTPOINTS=OUTPOINTS + (SELECT Points from sparkiesmaster where Code='ALL_Q' and Status=1);
	END IF;
	IF(inAnswer>=1)THEN
		INSERT INTO user_sparkies_history(S_ID,G_ID,U_ID,Scenario_ID,Type,Points,Datetime)SELECT inSID,inGID,inUID,ID,Type,(inAnswer * Points),inDateTime from sparkiesmaster where Code='1QC' and Status=1;
		SET OUTPOINTS=OUTPOINTS + (inAnswer * (SELECT Points from sparkiesmaster where Code='1QC' and Status=1));
	END IF;
	IF(inAnswer='10')THEN
		INSERT INTO user_sparkies_history(S_ID,G_ID,U_ID,Scenario_ID,Type,Points,Datetime)SELECT inSID,inGID,inUID,ID,Type,Points,inDateTime from sparkiesmaster where Code='10QC' and Status=1;
		SET OUTPOINTS=OUTPOINTS + (SELECT Points from sparkiesmaster where Code='10QC' and Status=1);
	END IF;	
	IF(inGame_Score>=60)THEN
		INSERT INTO user_sparkies_history(S_ID,G_ID,U_ID,Scenario_ID,Type,Points,Datetime)SELECT inSID,inGID,inUID,ID,Type,Points,inDateTime from sparkiesmaster where Code='ABOVE_60' and Status=1;
		SET OUTPOINTS=OUTPOINTS + (SELECT Points from sparkiesmaster where Code='ABOVE_60' and Status=1);
	END IF;
    
    SET NOOFTIMESPLAY=(SELECT ntimes from game_limit where g_id=inGameid AND gp_id=inPlanid );
	SET NOOFTIMESPLAYED=(SELECT COUNT(*) from game_reports where g_id=inGameid AND gp_id=inPlanid and gu_id=inUID and lastupdate=CURDATE());
	IF(NOOFTIMESPLAY=NOOFTIMESPLAYED)THEN
		INSERT INTO user_sparkies_history(S_ID,G_ID,U_ID,Scenario_ID,Type,Points,Datetime)SELECT inSID,inGID,inUID,ID,Type,Points,inDateTime from sparkiesmaster where Code='ALL5TGP' and Status=1;
		SET OUTPOINTS=OUTPOINTS + (SELECT Points from sparkiesmaster where Code='ALL5TGP' and Status=1);
	END IF;
		
    INSERT INTO user_sparkies_history(S_ID,G_ID,U_ID,Scenario_ID,Type,Points,Datetime)SELECT inSID,inGID,inUID,ID,Type,Points,inDateTime from sparkiesmaster where Code='NOTPOAG' and Status=1;
    
	SET OUTPOINTS=OUTPOINTS + (SELECT Points from sparkiesmaster where Code='NOTPOAG' and Status=1);
    
END IF;
IF(inScenarioCode='LOGIN')THEN
	SET OUTFIRSTLOGIN=(select count(ID) as firstlogin  from user_sparkies_history where U_ID=inUID and date(Datetime)=CURDATE());
	SET OUTWEEKEND=(SELECT DAYOFWEEK(CURDATE()) = 7 or DAYOFWEEK(CURDATE()) = 1);
	
			SET OUTSECTIONNAME=(select section from users where id=inUID);
			SET OUTGRADENAME=(select grade_id from users where id=inUID);
			SET OUTTIME=(SELECT curtime() >= '18:00:00' OR curtime() <= "06:00:00");
			SET OUTAID=(select academic_id from schools where id=inSID);
			
			SET OUTAVAIBILITY=(select (CASE DAYNAME(NOW())
            WHEN 'Monday'    THEN (SELECT '1' from schools_period_schedule where `monday_grade`=(select replace(classname,'Grade ','') from class where id=OUTGRADENAME) and `monday_section`=OUTSECTIONNAME and `school_id`=inSID and academic_id=OUTAID)
            WHEN 'Tuesday'   THEN (SELECT '1' from schools_period_schedule where `tuesday_grade`=(select replace(classname,'Grade ','') from class where id=OUTGRADENAME) and `tuesday_section`=OUTSECTIONNAME and `school_id`=inSID and academic_id=OUTAID)
            WHEN 'Wednesday' THEN (SELECT '1' from schools_period_schedule where `wednesday_grade`=(select replace(classname,'Grade ','') from class where id=OUTGRADENAME) and `wednesday_section`=OUTSECTIONNAME and `school_id`=inSID and academic_id=OUTAID)
            WHEN 'Thursday'  THEN (SELECT '1' from schools_period_schedule where `thursday_grade`=(select replace(classname,'Grade ','') from class where id=OUTGRADENAME) and `thursday_section`=OUTSECTIONNAME and `school_id`=inSID and academic_id=OUTAID)
            WHEN 'Friday'    THEN (SELECT '1' from schools_period_schedule where `friday_grade`=(select replace(classname,'Grade ','') from class where id=OUTGRADENAME) and `friday_section`=OUTSECTIONNAME and `school_id`=inSID and academic_id=OUTAID)
			WHEN 'Saturday'    THEN (SELECT '1' from schools_period_schedule where `saturday_grade`=(select replace(classname,'Grade ','') from class where id=OUTGRADENAME) and `saturday_section`=OUTSECTIONNAME and `school_id`=inSID and academic_id=OUTAID)
			WHEN 'Friday'    THEN (SELECT '1' from schools_period_schedule where `sunday_grade`=(select replace(classname,'Grade ','') from class where id=OUTGRADENAME) and `sunday_section`=OUTSECTIONNAME and `school_id`=inSID and academic_id=OUTAID)
            END) as isexist);
			
		IF(OUTFIRSTLOGIN=0)THEN 
			IF(OUTWEEKEND=1)THEN
				INSERT INTO user_sparkies_history(S_ID,G_ID,U_ID,Scenario_ID,Type,Points,Datetime)SELECT inSID,inGID,inUID,ID,Type,Points,NOW() from sparkiesmaster where Code='WEEKEND' and Status=1;
				SET OUTPOINTS=OUTPOINTS + (SELECT Points from sparkiesmaster where Code='WEEKEND' and Status=1);
			END IF;
			
			IF(OUTAVAIBILITY=1)THEN
				INSERT INTO user_sparkies_history(S_ID,G_ID,U_ID,Scenario_ID,Type,Points,Datetime)SELECT inSID,inGID,inUID,ID,Type,Points,NOW() from sparkiesmaster where Code='FLOSSD' and Status=1;
				SET OUTPOINTS=OUTPOINTS + (SELECT Points from sparkiesmaster where Code='FLOSSD' and Status=1);
			ELSE
				INSERT INTO user_sparkies_history(S_ID,G_ID,U_ID,Scenario_ID,Type,Points,Datetime)SELECT inSID,inGID,inUID,ID,Type,Points,NOW() from sparkiesmaster where Code='FLFH' and Status=1;
				SET OUTPOINTS=OUTPOINTS + (SELECT Points from sparkiesmaster where Code='FLFH' and Status=1);
			
			END IF;
			
			IF(OUTTIME=1)THEN
				INSERT INTO user_sparkies_history(S_ID,G_ID,U_ID,Scenario_ID,Type,Points,Datetime)SELECT inSID,inGID,inUID,ID,Type,Points,NOW() from sparkiesmaster where Code='6T6' and Status=1;
				SET OUTPOINTS=OUTPOINTS + (SELECT Points from sparkiesmaster where Code='6T6' and Status=1);
			END IF;
            
			IF(LAST_DAY(CURDATE())=date(NOW()))THEN
				IF(day(last_day(CURDATE()))=(SELECT count(distinct(date(Datetime))) as monplayed from user_sparkies_history where month(Datetime)=MONTH(NOW()) and U_ID=inUID))THEN
					INSERT INTO user_sparkies_history(S_ID,G_ID,U_ID,Scenario_ID,Type,Points,Datetime)SELECT inSID,inGID,inUID,ID,Type,Points,NOW() from sparkiesmaster where Code='ALLDAY' and Status=1;
					SET OUTPOINTS=OUTPOINTS + (SELECT Points from sparkiesmaster where Code='ALLDAY' and Status=1);
				END IF;
			END IF;
	
		END IF;
END IF;


SELECT OUTPOINTS;
 
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `insertsparkiesnew~200318v1` (IN `inSID` INT(11), IN `inGID` INT(11), IN `inUID` INT(11), IN `inScenarioCode` VARCHAR(55), IN `inTotal_Ques` INT(11), IN `inAttempt_Ques` INT(11), IN `inAnswer` INT(11), IN `inGame_Score` INT(11), IN `inPlanid` INT(11), IN `inGameid` INT(11), IN `inDateTime` VARCHAR(55))  BEGIN

DECLARE OUTPOINTS INT(11);
DECLARE NOOFTIMESPLAY INT(11);
DECLARE NOOFTIMESPLAYED INT(11);
DECLARE OUTWEEKEND INT(11);
DECLARE OUTFIRSTLOGIN INT(11);
DECLARE OUTSECTIONNAME Varchar(16);
DECLARE OUTGRADENAME Varchar(16);
DECLARE OUTAVAIBILITY INT(11);	
DECLARE OUTTIME INT(11);
DECLARE OUTAID INT(11);

SET OUTPOINTS=0;

IF(inScenarioCode='GAME_END')THEN
	IF(inAttempt_Ques>=1)THEN 
		INSERT INTO user_sparkies_history(S_ID,G_ID,U_ID,Scenario_ID,Type,Points,Datetime,ScenarioCode)SELECT inSID,inGID,inUID,ID,Type,(inAttempt_Ques * Points),inDateTime,inScenarioCode from sparkiesmaster where Code='ONE_Q' and Status=1;
		SET OUTPOINTS=OUTPOINTS + (inAttempt_Ques * (SELECT Points from sparkiesmaster where Code='ONE_Q' and Status=1));
	END IF;	
	IF(inAttempt_Ques='10')THEN
		INSERT INTO user_sparkies_history(S_ID,G_ID,U_ID,Scenario_ID,Type,Points,Datetime,ScenarioCode)SELECT inSID,inGID,inUID,ID,Type,Points,inDateTime,inScenarioCode from sparkiesmaster where Code='ALL_Q' and Status=1;
		SET OUTPOINTS=OUTPOINTS + (SELECT Points from sparkiesmaster where Code='ALL_Q' and Status=1);
	END IF;
	IF(inAnswer>=1)THEN
		INSERT INTO user_sparkies_history(S_ID,G_ID,U_ID,Scenario_ID,Type,Points,Datetime,ScenarioCode)SELECT inSID,inGID,inUID,ID,Type,(inAnswer * Points),inDateTime,inScenarioCode from sparkiesmaster where Code='1QC' and Status=1;
		SET OUTPOINTS=OUTPOINTS + (inAnswer * (SELECT Points from sparkiesmaster where Code='1QC' and Status=1));
	END IF;
	IF(inAnswer='10')THEN
		INSERT INTO user_sparkies_history(S_ID,G_ID,U_ID,Scenario_ID,Type,Points,Datetime,ScenarioCode)SELECT inSID,inGID,inUID,ID,Type,Points,inDateTime,inScenarioCode from sparkiesmaster where Code='10QC' and Status=1;
		SET OUTPOINTS=OUTPOINTS + (SELECT Points from sparkiesmaster where Code='10QC' and Status=1);
	END IF;	
	IF(inGame_Score>=60)THEN
		INSERT INTO user_sparkies_history(S_ID,G_ID,U_ID,Scenario_ID,Type,Points,Datetime,ScenarioCode)SELECT inSID,inGID,inUID,ID,Type,Points,inDateTime,inScenarioCode from sparkiesmaster where Code='ABOVE_60' and Status=1;
		SET OUTPOINTS=OUTPOINTS + (SELECT Points from sparkiesmaster where Code='ABOVE_60' and Status=1);
	END IF;
    
    SET NOOFTIMESPLAY=(SELECT ntimes from game_limit where g_id=inGameid AND gp_id=inPlanid );
	SET NOOFTIMESPLAYED=(SELECT COUNT(*) from game_reports where g_id=inGameid AND gp_id=inPlanid and gu_id=inUID and lastupdate=CURDATE());
	IF(NOOFTIMESPLAY=NOOFTIMESPLAYED)THEN
		INSERT INTO user_sparkies_history(S_ID,G_ID,U_ID,Scenario_ID,Type,Points,Datetime,ScenarioCode)SELECT inSID,inGID,inUID,ID,Type,Points,inDateTime,inScenarioCode from sparkiesmaster where Code='ALL5TGP' and Status=1;
		SET OUTPOINTS=OUTPOINTS + (SELECT Points from sparkiesmaster where Code='ALL5TGP' and Status=1);
	END IF;
		
    INSERT INTO user_sparkies_history(S_ID,G_ID,U_ID,Scenario_ID,Type,Points,Datetime,ScenarioCode)SELECT inSID,inGID,inUID,ID,Type,Points,inDateTime,inScenarioCode from sparkiesmaster where Code='NOTPOAG' and Status=1;
    
	SET OUTPOINTS=OUTPOINTS + (SELECT Points from sparkiesmaster where Code='NOTPOAG' and Status=1);
    
END IF;
IF(inScenarioCode='LOGIN')THEN
	SET OUTFIRSTLOGIN=(select count(ID) as firstlogin  from user_sparkies_history where U_ID=inUID and date(Datetime)=CURDATE());
	SET OUTWEEKEND=(SELECT DAYOFWEEK(CURDATE()) = 7 or DAYOFWEEK(CURDATE()) = 1);
	
			SET OUTSECTIONNAME=(select section from users where id=inUID);
			SET OUTGRADENAME=(select grade_id from users where id=inUID);
			SET OUTTIME=(SELECT curtime() >= '18:00:00' OR curtime() <= "06:00:00");
			SET OUTAID=(select academic_id from schools where id=inSID);
			
			SET OUTAVAIBILITY=(select (CASE DAYNAME(NOW())
            WHEN 'Monday'    THEN (SELECT '1' from schools_period_schedule where `monday_grade`=(select replace(classname,'Grade ','') from class where id=OUTGRADENAME) and `monday_section`=OUTSECTIONNAME and `school_id`=inSID and academic_id=OUTAID)
            WHEN 'Tuesday'   THEN (SELECT '1' from schools_period_schedule where `tuesday_grade`=(select replace(classname,'Grade ','') from class where id=OUTGRADENAME) and `tuesday_section`=OUTSECTIONNAME and `school_id`=inSID and academic_id=OUTAID)
            WHEN 'Wednesday' THEN (SELECT '1' from schools_period_schedule where `wednesday_grade`=(select replace(classname,'Grade ','') from class where id=OUTGRADENAME) and `wednesday_section`=OUTSECTIONNAME and `school_id`=inSID and academic_id=OUTAID)
            WHEN 'Thursday'  THEN (SELECT '1' from schools_period_schedule where `thursday_grade`=(select replace(classname,'Grade ','') from class where id=OUTGRADENAME) and `thursday_section`=OUTSECTIONNAME and `school_id`=inSID and academic_id=OUTAID)
            WHEN 'Friday'    THEN (SELECT '1' from schools_period_schedule where `friday_grade`=(select replace(classname,'Grade ','') from class where id=OUTGRADENAME) and `friday_section`=OUTSECTIONNAME and `school_id`=inSID and academic_id=OUTAID)
			WHEN 'Saturday'    THEN (SELECT '1' from schools_period_schedule where `saturday_grade`=(select replace(classname,'Grade ','') from class where id=OUTGRADENAME) and `saturday_section`=OUTSECTIONNAME and `school_id`=inSID and academic_id=OUTAID)
			WHEN 'Friday'    THEN (SELECT '1' from schools_period_schedule where `sunday_grade`=(select replace(classname,'Grade ','') from class where id=OUTGRADENAME) and `sunday_section`=OUTSECTIONNAME and `school_id`=inSID and academic_id=OUTAID)
            END) as isexist);
			
		IF(OUTFIRSTLOGIN=0)THEN 
			IF(OUTWEEKEND=1)THEN
				INSERT INTO user_sparkies_history(S_ID,G_ID,U_ID,Scenario_ID,Type,Points,Datetime,ScenarioCode)SELECT inSID,inGID,inUID,ID,Type,Points,NOW(),inScenarioCode from sparkiesmaster where Code='WEEKEND' and Status=1;
				SET OUTPOINTS=OUTPOINTS + (SELECT Points from sparkiesmaster where Code='WEEKEND' and Status=1);
			END IF;
			
			IF(OUTAVAIBILITY=1)THEN
				INSERT INTO user_sparkies_history(S_ID,G_ID,U_ID,Scenario_ID,Type,Points,Datetime,ScenarioCode)SELECT inSID,inGID,inUID,ID,Type,Points,NOW(),inScenarioCode from sparkiesmaster where Code='FLOSSD' and Status=1;
				SET OUTPOINTS=OUTPOINTS + (SELECT Points from sparkiesmaster where Code='FLOSSD' and Status=1);
			ELSE
				INSERT INTO user_sparkies_history(S_ID,G_ID,U_ID,Scenario_ID,Type,Points,Datetime,ScenarioCode)SELECT inSID,inGID,inUID,ID,Type,Points,NOW(),inScenarioCode from sparkiesmaster where Code='FLFH' and Status=1;
				SET OUTPOINTS=OUTPOINTS + (SELECT Points from sparkiesmaster where Code='FLFH' and Status=1);
			
			END IF;
			
			IF(OUTTIME=1)THEN
				INSERT INTO user_sparkies_history(S_ID,G_ID,U_ID,Scenario_ID,Type,Points,Datetime,ScenarioCode)SELECT inSID,inGID,inUID,ID,Type,Points,NOW(),inScenarioCode from sparkiesmaster where Code='6T6' and Status=1;
				SET OUTPOINTS=OUTPOINTS + (SELECT Points from sparkiesmaster where Code='6T6' and Status=1);
			END IF;
            
			IF(LAST_DAY(CURDATE())=date(NOW()))THEN
				IF(day(last_day(CURDATE()))=(SELECT count(distinct(date(Datetime))) as monplayed from user_sparkies_history where month(Datetime)=MONTH(NOW()) and U_ID=inUID))THEN
					INSERT INTO user_sparkies_history(S_ID,G_ID,U_ID,Scenario_ID,Type,Points,Datetime,ScenarioCode)SELECT inSID,inGID,inUID,ID,Type,Points,NOW(),inScenarioCode from sparkiesmaster where Code='ALLDAY' and Status=1;
					SET OUTPOINTS=OUTPOINTS + (SELECT Points from sparkiesmaster where Code='ALLDAY' and Status=1);
				END IF;
			END IF;
	
		END IF;
END IF;


SELECT OUTPOINTS;
 
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `insertsparkiesnew~260318` (IN `inSID` INT(11), IN `inGID` INT(11), IN `inUID` INT(11), IN `inScenarioCode` VARCHAR(55), IN `inTotal_Ques` INT(11), IN `inAttempt_Ques` INT(11), IN `inAnswer` INT(11), IN `inGame_Score` INT(11), IN `inPlanid` INT(11), IN `inGameid` INT(11), IN `inDateTime` VARCHAR(55))  BEGIN

DECLARE OUTPOINTS INT(11);
DECLARE NOOFTIMESPLAY INT(11);
DECLARE NOOFTIMESPLAYED INT(11);
DECLARE OUTWEEKEND INT(11);
DECLARE OUTFIRSTLOGIN INT(11);
DECLARE OUTSECTIONNAME Varchar(16);
DECLARE OUTGRADENAME Varchar(16);
DECLARE OUTAVAIBILITY INT(11);	
DECLARE OUTTIME INT(11);
DECLARE OUTAID INT(11);

SET OUTPOINTS=0;

IF(inScenarioCode='GAME_END')THEN
	IF(inAttempt_Ques>=1)THEN 
		INSERT INTO user_sparkies_history(S_ID,G_ID,U_ID,Scenario_ID,Type,Points,Datetime,ScenarioCode,Gameid)SELECT inSID,inGID,inUID,ID,Type,(inAttempt_Ques * Points),inDateTime,inScenarioCode,inGameid from sparkiesmaster where Code='ONE_Q' and Status=1;
		SET OUTPOINTS=OUTPOINTS + (inAttempt_Ques * (SELECT Points from sparkiesmaster where Code='ONE_Q' and Status=1));
	END IF;	
	IF(inAttempt_Ques='10')THEN
		INSERT INTO user_sparkies_history(S_ID,G_ID,U_ID,Scenario_ID,Type,Points,Datetime,ScenarioCode,Gameid)SELECT inSID,inGID,inUID,ID,Type,Points,inDateTime,inScenarioCode,inGameid from sparkiesmaster where Code='ALL_Q' and Status=1;
		SET OUTPOINTS=OUTPOINTS + (SELECT Points from sparkiesmaster where Code='ALL_Q' and Status=1);
	END IF;
	IF(inAnswer>=1)THEN
		INSERT INTO user_sparkies_history(S_ID,G_ID,U_ID,Scenario_ID,Type,Points,Datetime,ScenarioCode,Gameid)SELECT inSID,inGID,inUID,ID,Type,(inAnswer * Points),inDateTime,inScenarioCode,inGameid from sparkiesmaster where Code='1QC' and Status=1;
		SET OUTPOINTS=OUTPOINTS + (inAnswer * (SELECT Points from sparkiesmaster where Code='1QC' and Status=1));
	END IF;
	IF(inAnswer='10')THEN
		INSERT INTO user_sparkies_history(S_ID,G_ID,U_ID,Scenario_ID,Type,Points,Datetime,ScenarioCode,Gameid)SELECT inSID,inGID,inUID,ID,Type,Points,inDateTime,inScenarioCode,inGameid from sparkiesmaster where Code='10QC' and Status=1;
		SET OUTPOINTS=OUTPOINTS + (SELECT Points from sparkiesmaster where Code='10QC' and Status=1);
	END IF;	
	IF(inGame_Score>=60)THEN
		INSERT INTO user_sparkies_history(S_ID,G_ID,U_ID,Scenario_ID,Type,Points,Datetime,ScenarioCode,Gameid)SELECT inSID,inGID,inUID,ID,Type,Points,inDateTime,inScenarioCode,inGameid from sparkiesmaster where Code='ABOVE_60' and Status=1;
		SET OUTPOINTS=OUTPOINTS + (SELECT Points from sparkiesmaster where Code='ABOVE_60' and Status=1);
	END IF;
    
    SET NOOFTIMESPLAY=(SELECT ntimes from game_limit where g_id=inGameid AND gp_id=inPlanid );
	SET NOOFTIMESPLAYED=(SELECT COUNT(*) from game_reports where g_id=inGameid AND gp_id=inPlanid and gu_id=inUID and lastupdate=CURDATE());
	IF(NOOFTIMESPLAY=NOOFTIMESPLAYED)THEN
		INSERT INTO user_sparkies_history(S_ID,G_ID,U_ID,Scenario_ID,Type,Points,Datetime,ScenarioCode,Gameid)SELECT inSID,inGID,inUID,ID,Type,Points,inDateTime,inScenarioCode,inGameid from sparkiesmaster where Code='ALL5TGP' and Status=1;
		SET OUTPOINTS=OUTPOINTS + (SELECT Points from sparkiesmaster where Code='ALL5TGP' and Status=1);
	END IF;
		
    INSERT INTO user_sparkies_history(S_ID,G_ID,U_ID,Scenario_ID,Type,Points,Datetime,ScenarioCode,Gameid)SELECT inSID,inGID,inUID,ID,Type,Points,inDateTime,inScenarioCode,inGameid from sparkiesmaster where Code='NOTPOAG' and Status=1;
    
	SET OUTPOINTS=OUTPOINTS + (SELECT Points from sparkiesmaster where Code='NOTPOAG' and Status=1);
    
END IF;
IF(inScenarioCode='LOGIN')THEN
	SET OUTFIRSTLOGIN=(select count(ID) as firstlogin  from user_sparkies_history where U_ID=inUID and date(Datetime)=CURDATE());
	SET OUTWEEKEND=(SELECT DAYOFWEEK(CURDATE()) = 7 or DAYOFWEEK(CURDATE()) =2);
	
			SET OUTSECTIONNAME=(select section from users where id=inUID);
			SET OUTGRADENAME=(select grade_id from users where id=inUID);
			SET OUTTIME=(SELECT curtime() >= '18:00:00' OR curtime() <= "06:00:00");
			SET OUTAID=(select academic_id from schools where id=inSID);
			
			SET OUTAVAIBILITY=(select (CASE DAYNAME(NOW())
            WHEN 'Monday'    THEN (SELECT '1' from schools_period_schedule where `monday_grade`=(select replace(classname,'Grade ','') from class where id=OUTGRADENAME) and `monday_section`=OUTSECTIONNAME and `school_id`=inSID and academic_id=OUTAID)
            WHEN 'Tuesday'   THEN (SELECT '1' from schools_period_schedule where `tuesday_grade`=(select replace(classname,'Grade ','') from class where id=OUTGRADENAME) and `tuesday_section`=OUTSECTIONNAME and `school_id`=inSID and academic_id=OUTAID)
            WHEN 'Wednesday' THEN (SELECT '1' from schools_period_schedule where `wednesday_grade`=(select replace(classname,'Grade ','') from class where id=OUTGRADENAME) and `wednesday_section`=OUTSECTIONNAME and `school_id`=inSID and academic_id=OUTAID)
            WHEN 'Thursday'  THEN (SELECT '1' from schools_period_schedule where `thursday_grade`=(select replace(classname,'Grade ','') from class where id=OUTGRADENAME) and `thursday_section`=OUTSECTIONNAME and `school_id`=inSID and academic_id=OUTAID)
            WHEN 'Friday'    THEN (SELECT '1' from schools_period_schedule where `friday_grade`=(select replace(classname,'Grade ','') from class where id=OUTGRADENAME) and `friday_section`=OUTSECTIONNAME and `school_id`=inSID and academic_id=OUTAID)
			WHEN 'Saturday'    THEN (SELECT '1' from schools_period_schedule where `saturday_grade`=(select replace(classname,'Grade ','') from class where id=OUTGRADENAME) and `saturday_section`=OUTSECTIONNAME and `school_id`=inSID and academic_id=OUTAID)
			WHEN 'Friday'    THEN (SELECT '1' from schools_period_schedule where `sunday_grade`=(select replace(classname,'Grade ','') from class where id=OUTGRADENAME) and `sunday_section`=OUTSECTIONNAME and `school_id`=inSID and academic_id=OUTAID)
            END) as isexist);
			
		IF(OUTFIRSTLOGIN=0)THEN 
			IF(OUTWEEKEND=1)THEN
				INSERT INTO user_sparkies_history(S_ID,G_ID,U_ID,Scenario_ID,Type,Points,Datetime,ScenarioCode)SELECT inSID,inGID,inUID,ID,Type,Points,NOW(),inScenarioCode from sparkiesmaster where Code='WEEKEND' and Status=1;
				SET OUTPOINTS=OUTPOINTS + (SELECT Points from sparkiesmaster where Code='WEEKEND' and Status=1);
			END IF;
			
			IF(OUTAVAIBILITY=1)THEN
				INSERT INTO user_sparkies_history(S_ID,G_ID,U_ID,Scenario_ID,Type,Points,Datetime,ScenarioCode)SELECT inSID,inGID,inUID,ID,Type,Points,NOW(),inScenarioCode from sparkiesmaster where Code='FLOSSD' and Status=1;
				SET OUTPOINTS=OUTPOINTS + (SELECT Points from sparkiesmaster where Code='FLOSSD' and Status=1);
			ELSE
				INSERT INTO user_sparkies_history(S_ID,G_ID,U_ID,Scenario_ID,Type,Points,Datetime,ScenarioCode)SELECT inSID,inGID,inUID,ID,Type,Points,NOW(),inScenarioCode from sparkiesmaster where Code='FLFH' and Status=1;
				SET OUTPOINTS=OUTPOINTS + (SELECT Points from sparkiesmaster where Code='FLFH' and Status=1);
			
			END IF;
			
			IF(OUTTIME=1)THEN
				INSERT INTO user_sparkies_history(S_ID,G_ID,U_ID,Scenario_ID,Type,Points,Datetime,ScenarioCode)SELECT inSID,inGID,inUID,ID,Type,Points,NOW(),inScenarioCode from sparkiesmaster where Code='6T6' and Status=1;
				SET OUTPOINTS=OUTPOINTS + (SELECT Points from sparkiesmaster where Code='6T6' and Status=1);
			END IF;
            
			IF(LAST_DAY(CURDATE())=date(NOW()))THEN
				IF(day(last_day(CURDATE()))=(SELECT count(distinct(date(Datetime))) as monplayed from user_sparkies_history where month(Datetime)=MONTH(NOW()) and U_ID=inUID))THEN
					INSERT INTO user_sparkies_history(S_ID,G_ID,U_ID,Scenario_ID,Type,Points,Datetime,ScenarioCode)SELECT inSID,inGID,inUID,ID,Type,Points,NOW(),inScenarioCode from sparkiesmaster where Code='ALLDAY' and Status=1;
					SET OUTPOINTS=OUTPOINTS + (SELECT Points from sparkiesmaster where Code='ALLDAY' and Status=1);
				END IF;
			END IF;
	
		END IF;
END IF;


SELECT OUTPOINTS;
 
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `insertsparkiesnew~old1` (IN `inSID` INT(11), IN `inGID` INT(11), IN `inUID` INT(11), IN `inScenarioCode` VARCHAR(55), IN `inTotal_Ques` INT(11), IN `inAttempt_Ques` INT(11), IN `inAnswer` INT(11), IN `inGame_Score` INT(11), IN `inDateTime` VARCHAR(55))  BEGIN

DECLARE OUTPOINTS INT(11);

SET OUTPOINTS=0;

IF(inScenarioCode='GAME_END')THEN
	IF(inAttempt_Ques>=1)THEN 
		INSERT INTO user_sparkies_history(S_ID,G_ID,U_ID,Scenario_ID,Type,Points,Datetime)SELECT inSID,inGID,inUID,ID,Type,Points,inDateTime from sparkiesmaster where Code='ONE_Q' and Status=1;
		SET OUTPOINTS=OUTPOINTS + (SELECT Points from sparkiesmaster where Code='ONE_Q' and Status=1);
	END IF;	
	IF(inAttempt_Ques='10')THEN
		INSERT INTO user_sparkies_history(S_ID,G_ID,U_ID,Scenario_ID,Type,Points,Datetime)SELECT inSID,inGID,inUID,ID,Type,Points,inDateTime from sparkiesmaster where Code='ALL_Q' and Status=1;
		SET OUTPOINTS=OUTPOINTS + (SELECT Points from sparkiesmaster where Code='ALL_Q' and Status=1);
	END IF;
	IF(inAnswer>=1)THEN
		INSERT INTO user_sparkies_history(S_ID,G_ID,U_ID,Scenario_ID,Type,Points,Datetime)SELECT inSID,inGID,inUID,ID,Type,Points,inDateTime from sparkiesmaster where Code='1QC' and Status=1;
		SET OUTPOINTS=OUTPOINTS + (SELECT Points from sparkiesmaster where Code='1QC' and Status=1);
	END IF;
	IF(inAnswer='10')THEN
		INSERT INTO user_sparkies_history(S_ID,G_ID,U_ID,Scenario_ID,Type,Points,Datetime)SELECT inSID,inGID,inUID,ID,Type,Points,inDateTime from sparkiesmaster where Code='10QC' and Status=1;
		SET OUTPOINTS=OUTPOINTS + (SELECT Points from sparkiesmaster where Code='10QC' and Status=1);
	END IF;	
	IF(inGame_Score>=60)THEN
		INSERT INTO user_sparkies_history(S_ID,G_ID,U_ID,Scenario_ID,Type,Points,Datetime)SELECT inSID,inGID,inUID,ID,Type,Points,inDateTime from sparkiesmaster where Code='ABOVE_60' and Status=1;
		SET OUTPOINTS=OUTPOINTS + (SELECT Points from sparkiesmaster where Code='ABOVE_60' and Status=1);
	END IF;

END IF;

SELECT  OUTPOINTS;
 
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `IsChildLogin` (IN `inusername` VARCHAR(255), IN `inpwd` VARCHAR(255), IN `inidealtime` VARCHAR(55), IN `inuserid` INT(11))  BEGIN

select count(id) as islogin FROM users a WHERE username=inusername AND password=SHA1(CONCAT(salt1,inpwd,salt2)) AND status=1 AND islogin=1 AND TIMESTAMPDIFF(MINUTE,last_active_datetime,NOW())<=inidealtime;

END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `IsLogin` (IN `inusername` VARCHAR(255) CHARSET utf8, IN `inpwd` VARCHAR(255) CHARSET utf8, IN `inidealtime` VARCHAR(55) CHARSET utf8, IN `inuserid` INT(11))  BEGIN

select count(id) as islogin FROM school_parent_master a WHERE username=inusername AND password=SHA1(CONCAT(salt1,inpwd,salt2)) AND status=1 AND islogin=1 AND TIMESTAMPDIFF(MINUTE,last_active_datetime,NOW())<=inidealtime;

END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_Add_Payment` (IN `insubscribed_userid` VARCHAR(255) CHARSET utf8, IN `inamount` DECIMAL(10,2), IN `inpaymentstatus` ENUM('RS','P','S','F'), IN `inpayment_mode` ENUM('LIVE','TEST'))  NO SQL
BEGIN

INSERT INTO tbl_payment(Subscribed_userid,Amount,Payment_status,Payment_mode,Created_on ) VALUES (insubscribed_userid,inamount,inpaymentstatus,inpayment_mode,now() );
SELECT @@Identity as payinsertid;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_Update_Payment` (IN `inPayment_Id` INT, IN `inBilling_name` VARCHAR(255), IN `inBilling_tel` VARCHAR(255), IN `inBilling_email` VARCHAR(255), IN `inPayment_response` TEXT, IN `inAuthDesc` VARCHAR(255), IN `inChecksum` VARCHAR(255), IN `inMerchant_Param` VARCHAR(255), IN `inBank_refrence_no` VARCHAR(255), IN `inNb_order_no` VARCHAR(255), IN `inCard_category` VARCHAR(255), IN `inBank_name` VARCHAR(255), IN `inBankRespCode` VARCHAR(255), IN `inBankRespMsg` VARCHAR(255), IN `inPaymentStatus` ENUM('RS','P','S','F'), IN `inBilling_address` TEXT, IN `inBilling_country` VARCHAR(255), IN `inBilling_state` VARCHAR(255), IN `inBilling_city` VARCHAR(255), IN `inBilling_zip` VARCHAR(255))  NO SQL
BEGIN

 
IF(inPayment_Id !='' || inPayment_Id!=0)
THEN
UPDATE tbl_payment SET 
Billing_name=inBilling_name
,Billing_tel=inBilling_tel,
Billing_email=inBilling_email,
Billing_address=inBilling_address,
Billing_country=inBilling_country,
Billing_state=inBilling_state,
Billing_city=inBilling_city,
Billing_zip=inBilling_zip,
Payment_response=inPayment_response,
AuthDesc=inAuthDesc,
Check_sum=inChecksum ,
Merchant_Param = inMerchant_Param ,
Bank_refrence_no =inBank_refrence_no ,
Nb_order_no = inNb_order_no ,
Card_category =inCard_category,

Bank_name= inBank_name, 
BankRespCode=inBankRespCode ,
Payment_status = inPaymentStatus,
BankRespMsg= inBankRespMsg WHERE ID =inPayment_Id;
END IF;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_Update_Payment_Subscribe` (IN `inPayment_id` INT, IN `inPaymentStatus` ENUM('N','Y'))  NO SQL
BEGIN

UPDATE registration  SET paymentstatus=inPaymentStatus WHERE id IN (SELECT Subscribed_userid FROM tbl_payment WHERE ID=inPayment_id);

END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_Update_Payment~1303` (IN `inPayment_Id` INT, IN `inBilling_name` VARCHAR(255), IN `inBilling_tel` VARCHAR(255), IN `inBilling_email` VARCHAR(255), IN `inPayment_response` TEXT, IN `inAuthDesc` VARCHAR(255), IN `inChecksum` VARCHAR(255), IN `inMerchant_Param` VARCHAR(255), IN `inBank_refrence_no` VARCHAR(255), IN `inNb_order_no` VARCHAR(255), IN `inCard_category` VARCHAR(255), IN `inBank_name` VARCHAR(255), IN `inBankRespCode` VARCHAR(255), IN `inBankRespMsg` VARCHAR(255), IN `inPaymentStatus` ENUM('RS','P','S','F'))  NO SQL
BEGIN

 
IF(inPayment_Id !='' || inPayment_Id!=0)
THEN
UPDATE tbl_payment SET Billing_name=inBilling_name
,Billing_tel=inBilling_tel,
Billing_email=inBilling_email,
Payment_response=inPayment_response,
AuthDesc=inAuthDesc,
Check_sum=inChecksum ,
Merchant_Param = inMerchant_Param ,
Bank_refrence_no =inBank_refrence_no ,
Nb_order_no = inNb_order_no ,
Card_category =inCard_category,

Bank_name= inBank_name, 
BankRespCode=inBankRespCode ,
Payment_status = inPaymentStatus,
BankRespMsg= inBankRespMsg WHERE ID =inPayment_Id;
END IF;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `TESTING` (IN `inuid` INT(11), IN `insid` INT(11))  BEGIN

DECLARE OUTSECTIONNAME Varchar(16);
DECLARE OUTGRADENAME Varchar(16);
DECLARE OUTAVAIBILITY INT(11);

SET OUTSECTIONNAME=(select section from users where id=inuid);
SET OUTGRADENAME=(select REPLACE(classname,'Grade ','') as classname  from class  where id=(select grade_id from users where id=inuid));

SET OUTAVAIBILITY=(select COUNT(schedule_id)  from schools_period_schedule where school_id=insid  and 1 IN ((CASE WHEN (monday_grade=OUTGRADENAME and monday_section=OUTSECTIONNAME) OR (tuesday_grade=OUTGRADENAME and tuesday_section=OUTSECTIONNAME) OR   (wednesday_grade=OUTGRADENAME and wednesday_section=OUTSECTIONNAME) OR   (thursday_grade=OUTGRADENAME and thursday_section=OUTSECTIONNAME) OR  (friday_grade=OUTGRADENAME and friday_section=OUTSECTIONNAME) >0 THEN 1 ELSE 0 END )));

select OUTSECTIONNAME,OUTGRADENAME,OUTAVAIBILITY;

END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `TodayTimerInsert` (IN `inChildID` INT(11), IN `incurdate` DATE, IN `incurdatetime` DATETIME)  BEGIN

DECLARE OMaxPlayTime INT(11);
DECLARE OSumoftotTimeUsed INT(11);
DECLARE ORemainingTime INT(11);
DECLARE OTodayInsert INT(11);



SET OMaxPlayTime=(select time_limit as value from users where id=inChildID);
SET OSumoftotTimeUsed=(SELECT SUM(TimeLoggedIn) as LoggedIntime from(SELECT TIMESTAMPDIFF(SECOND,created_date,lastupdate) AS TimeLoggedIn FROM user_login_log WHERE userid=inChildID and date(created_date)=incurdate) as a2 );

SET ORemainingTime=OMaxPlayTime-OSumoftotTimeUsed;

IF(OSumoftotTimeUsed>=OMaxPlayTime)THEN
		
	SET OTodayInsert=(Select count(id) as isexist from userplaytime where userid=inChildID and expiredon=incurdate);
	IF(OTodayInsert=0)THEN
		Insert into userplaytime(userid,expiredon,expireddatetime)values(inChildID,incurdate,incurdatetime); 
	END IF;
END IF; 

Select OMaxPlayTime,OSumoftotTimeUsed,ORemainingTime;

END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `updateuserloginstatus` (IN `inuserid` VARCHAR(11), IN `inlogin_session_id` VARCHAR(255))  BEGIN

Update users set islogin=0 WHERE id=inuserid AND status=1;


END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `Update_Academic_Year` (IN `inacademic_start` VARCHAR(100) CHARSET utf8, IN `inacademic_end` VARCHAR(100) CHARSET utf8)  BEGIN
DECLARE inIsChange INT(11);
SELECT COUNT(id) FROM academic_year WHERE startdate=inacademic_start AND enddate=inacademic_end INTO inIsChange;
START TRANSACTION;
IF inIsChange=0 THEN
UPDATE academic_year SET startdate=inacademic_start , enddate=inacademic_end;
RENAME TABLE game_reports TO game_reports_2015_16;
CREATE TABLE IF NOT EXISTS game_reports (id int(11) NOT NULL AUTO_INCREMENT,gu_id int(10) NOT NULL,gc_id int(10) NOT NULL,gs_id int(10) NOT NULL,gp_id varchar(100) NOT NULL,g_id int(30) NOT NULL,total_question varchar(15) NOT NULL,attempt_question varchar(20) NOT NULL,answer varchar(20) NOT NULL,game_score varchar(50) NOT NULL,gtime varchar(100) NOT NULL,rtime varchar(100) NOT NULL,crtime varchar(100) NOT NULL,wrtime varchar(100) NOT NULL,lastupdate date NOT NULL,createdby varchar(100) NOT NULL,creation_date date NOT NULL,modifiedby varchar(100) NOT NULL,modified_date timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,PRIMARY KEY (id)) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;
INSERT INTO game_reports (id, gu_id, gc_id, gs_id, gp_id, g_id, total_question, attempt_question, answer, game_score, gtime, rtime, crtime, wrtime, lastupdate, createdby, creation_date, modifiedby, modified_date) select id, gu_id, gc_id, gs_id, gp_id, g_id, total_question, attempt_question, answer, game_score, gtime, rtime, crtime, wrtime, lastupdate, createdby, creation_date, modifiedby, modified_date FROM game_reports_2015_16;
DELETE  FROM game_reports;
update users set status='0' where sid=1 and gp_id = 8;
update users set gp_id=gp_id+1,grade_id=(select grade_id from g_plans where id=gp_id limit 1) where sid=1 and gp_id between 1 and 7;
update users set status='0' where sid IN (2,6) and gp_id=8;
update users set gp_id=gp_id+1,grade_id=(select grade_id from g_plans where id=gp_id limit 1) where sid IN (2,6) and gp_id between 1 and 7;
update users set gp_id=1,grade_id=(select grade_id from g_plans where id=1 limit 1) where gp_id=11 and sid IN (2,6);
update users set gp_id=gp_id+1,grade_id=(select grade_id from g_plans where id=gp_id limit 1) where gp_id=10 and sid IN (2,6);
update users set status='0' where sid=3 and gp_id=5;
update users set gp_id=gp_id+1,grade_id=(select grade_id from g_plans where id=gp_id limit 1) where gp_id IN(3,4) and sid=3;
update users set status='0' where sid=4 and gp_id=21;
update users set gp_id=gp_id+1,grade_id=(select grade_id from g_plans where id=gp_id limit 1) where sid=4 and gp_id between 14 and 20;
update users set status='0' where sid=5 and gp_id=31;
update users set gp_id=gp_id+1,grade_id=(select grade_id from g_plans where id=gp_id limit 1) where sid=5 and gp_id between 22 and 30;
update users set status='0' where sid=8 and gp_id=8;
update users set gp_id=gp_id+1,grade_id=(select grade_id from  g_plans where id=gp_id limit 1) where gp_id IN (6,7) and sid =8;
update users set status='0' where sid=9 and gp_id=37;
update users set gp_id=gp_id+1,grade_id=(select grade_id from  g_plans where id=gp_id limit 1) where sid=9 and gp_id between 32 and 36;
update users set gp_id=gp_id+1,grade_id=(select grade_id from  g_plans where id=gp_id limit 1) where gp_id IN(38,39) and sid=9;
update users set gp_id=32,grade_id=(select grade_id from  g_plans where id=1 limit 1) where gp_id=40 and sid =9;
update users set status='0' where sid=10 and gp_id=50;
update users set gp_id=gp_id+1,grade_id=(select grade_id from g_plans where id=gp_id limit 1) where sid=10 and gp_id between 41 and 49;
update users set status='0' where sid=11 and gp_id=60;
update users set gp_id=gp_id+1,grade_id=(select grade_id from g_plans where id=gp_id limit 1) where sid=11 and gp_id between 51 and 59;
END IF;
COMMIT ;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `Update_Academic_Year_15_16_ck_grg` (IN `inacademic_start` VARCHAR(100) CHARSET utf8, IN `inacademic_end` VARCHAR(100) CHARSET utf8)  BEGIN
DECLARE inIsChange INT(11);
SELECT COUNT(id) FROM academic_year WHERE startdate=inacademic_start AND enddate=inacademic_end INTO inIsChange;
START TRANSACTION;
IF inIsChange=0 THEN
UPDATE academic_year SET startdate=inacademic_start , enddate=inacademic_end;

update users set status='0' where sid=1 and gp_id = 8;
update users set gp_id=gp_id+1,grade_id=(select grade_id from g_plans where id=gp_id limit 1) where sid=1 and gp_id between 1 and 7;

update users set status='0' where sid=4 and gp_id=21;
update users set gp_id=gp_id+1,grade_id=(select grade_id from g_plans where id=gp_id limit 1) where sid=4 and gp_id between 14 and 20;

END IF;
COMMIT ;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `Update_Academic_Year_New_Year` ()  BEGIN
START TRANSACTION;
update users set status='0' where sid=1 and gp_id = 8;
update users set gp_id=gp_id+1,grade_id=(select grade_id from g_plans where id=gp_id limit 1) where sid=1 and gp_id between 1 and 7;
update users set status='0' where sid IN (2,6) and gp_id=8;
update users set gp_id=gp_id+1,grade_id=(select grade_id from g_plans where id=gp_id limit 1) where sid IN (2,6) and gp_id between 1 and 7;
update users set gp_id=1,grade_id=(select grade_id from g_plans where id=1 limit 1) where gp_id=11 and sid IN (2,6);
update users set gp_id=gp_id+1,grade_id=(select grade_id from g_plans where id=gp_id limit 1) where gp_id=10 and sid IN (2,6);
update users set status='0' where sid=3 and gp_id=5;
update users set gp_id=gp_id+1,grade_id=(select grade_id from g_plans where id=gp_id limit 1) where gp_id IN(3,4) and sid=3;
update users set status='0' where sid=4 and gp_id=21;
update users set gp_id=gp_id+1,grade_id=(select grade_id from g_plans where id=gp_id limit 1) where sid=4 and gp_id between 14 and 20;
update users set status='0' where sid=5 and gp_id=31;
update users set gp_id=gp_id+1,grade_id=(select grade_id from g_plans where id=gp_id limit 1) where sid=5 and gp_id between 22 and 30;
update users set status='0' where sid=8 and gp_id=8;
update users set gp_id=gp_id+1,grade_id=(select grade_id from  g_plans where id=gp_id limit 1) where gp_id IN (6,7) and sid =8;
update users set status='0' where sid=9 and gp_id=37;
update users set gp_id=gp_id+1,grade_id=(select grade_id from  g_plans where id=gp_id limit 1) where sid=9 and gp_id between 32 and 36;
update users set gp_id=gp_id+1,grade_id=(select grade_id from  g_plans where id=gp_id limit 1) where gp_id IN(38,39) and sid=9;
update users set gp_id=32,grade_id=(select grade_id from  g_plans where id=1 limit 1) where gp_id=40 and sid =9;
update users set status='0' where sid=10 and gp_id=50;
update users set gp_id=gp_id+1,grade_id=(select grade_id from g_plans where id=gp_id limit 1) where sid=10 and gp_id between 41 and 49;
update users set status='0' where sid=11 and gp_id=60;
update users set gp_id=gp_id+1,grade_id=(select grade_id from g_plans where id=gp_id limit 1) where sid=11 and gp_id between 51 and 59;
COMMIT ;
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `academic_year`
--

CREATE TABLE `academic_year` (
  `id` int(11) NOT NULL,
  `academicyear` int(5) NOT NULL,
  `startdate` varchar(100) NOT NULL,
  `enddate` varchar(100) NOT NULL,
  `createdby` varchar(100) NOT NULL,
  `creation_date` date NOT NULL,
  `modifieby` varchar(100) NOT NULL,
  `modified_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `academic_year`
--

INSERT INTO `academic_year` (`id`, `academicyear`, `startdate`, `enddate`, `createdby`, `creation_date`, `modifieby`, `modified_date`) VALUES
(19, 0, '2016-06-01', '2017-05-31', '', '0000-00-00', '', '2017-06-03 22:43:05'),
(20, 0, '2017-06-01', '2018-05-31', '', '0000-00-00', '', '2017-06-03 22:43:00');

-- --------------------------------------------------------

--
-- Table structure for table `academy_admin_password_history`
--

CREATE TABLE `academy_admin_password_history` (
  `ID` int(11) NOT NULL,
  `centerid` int(11) NOT NULL,
  `randid` varchar(55) NOT NULL,
  `requestdatetime` datetime NOT NULL,
  `processdatetime` datetime NOT NULL,
  `update_password` varchar(400) NOT NULL,
  `ip` varchar(100) NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `academy_admin_password_history`
--

INSERT INTO `academy_admin_password_history` (`ID`, `centerid`, `randid`, `requestdatetime`, `processdatetime`, `update_password`, `ip`, `status`) VALUES
(1, 5, '8865365', '2018-05-08 18:27:40', '0000-00-00 00:00:00', '123456', '157.50.229.251', 0);

-- --------------------------------------------------------

--
-- Table structure for table `accesslog`
--

CREATE TABLE `accesslog` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `deviceid` text NOT NULL,
  `Keyval` varchar(255) NOT NULL,
  `timestamp` datetime NOT NULL,
  `Version` varchar(55) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(10) NOT NULL,
  `email` varchar(100) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `fname` varchar(100) NOT NULL,
  `lname` varchar(100) NOT NULL,
  `mobile` int(12) NOT NULL,
  `level` int(10) NOT NULL,
  `orgpwd` varchar(110) NOT NULL,
  `status` int(11) NOT NULL,
  `createdby` varchar(100) NOT NULL,
  `creation_date` date NOT NULL,
  `modifiedby` varchar(100) NOT NULL,
  `modified_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `isdemo` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `email`, `username`, `password`, `fname`, `lname`, `mobile`, `level`, `orgpwd`, `status`, `createdby`, `creation_date`, `modifiedby`, `modified_date`, `isdemo`) VALUES
(1, 'admin@skillangels.com', 'superadmin', 'e10adc3949ba59abbe56e057f20f883e', 'SkillAngles', 'Admin', 2147483647, 1, '123456', 1, '', '0000-00-00', '', '2018-05-07 16:10:53', 0);

-- --------------------------------------------------------

--
-- Table structure for table `admin_login_log`
--

CREATE TABLE `admin_login_log` (
  `ID` int(11) NOT NULL,
  `adminid` int(11) NOT NULL,
  `sessionid` varchar(255) NOT NULL,
  `created_date` datetime NOT NULL,
  `lastupdate` datetime NOT NULL,
  `logout_date` datetime NOT NULL,
  `ip` varchar(50) NOT NULL,
  `country` varchar(800) NOT NULL,
  `region` varchar(800) NOT NULL,
  `city` varchar(800) NOT NULL,
  `browser` text NOT NULL,
  `isp` text NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `admin_password_history`
--

CREATE TABLE `admin_password_history` (
  `ID` int(11) NOT NULL,
  `adminid` int(11) NOT NULL,
  `randid` varchar(55) NOT NULL,
  `requestdatetime` datetime NOT NULL,
  `processdatetime` datetime NOT NULL,
  `update_password` varchar(400) NOT NULL,
  `ip` varchar(100) NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `android_games`
--

CREATE TABLE `android_games` (
  `id` int(100) NOT NULL,
  `gname` varchar(100) NOT NULL,
  `img_path` varchar(100) NOT NULL,
  `gpath` varchar(100) NOT NULL,
  `createdby` varchar(100) NOT NULL,
  `creation_date` date NOT NULL,
  `modifiedby` varchar(100) NOT NULL,
  `modified_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `app_remainingtime`
--

CREATE TABLE `app_remainingtime` (
  `id` int(11) NOT NULL,
  `ChildId` int(11) NOT NULL,
  `RemainingTime` int(11) NOT NULL,
  `Curdate` date NOT NULL,
  `Last_Modified_Date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `asap_gamedata`
--

CREATE TABLE `asap_gamedata` (
  `id` int(11) NOT NULL,
  `gu_id` int(10) NOT NULL,
  `gc_id` int(10) NOT NULL,
  `gs_id` int(10) NOT NULL,
  `gp_id` varchar(100) NOT NULL,
  `g_id` int(30) NOT NULL,
  `total_question` varchar(15) NOT NULL,
  `attempt_question` varchar(20) NOT NULL,
  `answer` varchar(20) NOT NULL,
  `game_score` varchar(50) NOT NULL,
  `gtime` varchar(100) NOT NULL,
  `rtime` varchar(100) NOT NULL,
  `crtime` varchar(100) NOT NULL,
  `wrtime` varchar(100) NOT NULL,
  `lastupdate` date NOT NULL,
  `createdby` varchar(100) NOT NULL,
  `creation_date` date NOT NULL,
  `modifiedby` varchar(100) NOT NULL,
  `modified_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `Is_schedule` int(11) NOT NULL,
  `org_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `asap_gamescore`
--

CREATE TABLE `asap_gamescore` (
  `id` int(11) NOT NULL,
  `gu_id` int(11) NOT NULL,
  `org_id` int(11) NOT NULL,
  `ME` varchar(110) NOT NULL,
  `VP` varchar(110) NOT NULL,
  `FA` varchar(110) NOT NULL,
  `PS` varchar(110) NOT NULL,
  `LI` varchar(110) NOT NULL,
  `created_on` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `asap_game_mapping`
--

CREATE TABLE `asap_game_mapping` (
  `id` int(11) NOT NULL,
  `name` varchar(110) NOT NULL,
  `sid` int(11) NOT NULL,
  `grade_id` int(11) NOT NULL,
  `org_id` int(11) NOT NULL,
  `ME` int(11) NOT NULL,
  `VP` int(11) NOT NULL,
  `FA` int(11) NOT NULL,
  `PS` int(11) NOT NULL,
  `LI` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `created_on` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `assignedgames`
--

CREATE TABLE `assignedgames` (
  `id` int(11) NOT NULL,
  `Assigned_id` int(11) NOT NULL,
  `GameId` int(11) NOT NULL,
  `ChildId` int(11) NOT NULL,
  `Assgined_date` date NOT NULL,
  `Assigned_game` varchar(255) NOT NULL,
  `GameCycle` int(11) NOT NULL,
  `App_randomid` varchar(255) NOT NULL,
  `Status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `bandwidth_config`
--

CREATE TABLE `bandwidth_config` (
  `ID` int(11) NOT NULL,
  `TimeInterval` int(11) NOT NULL,
  `Status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bandwidth_config`
--

INSERT INTO `bandwidth_config` (`ID`, `TimeInterval`, `Status`) VALUES
(1, 10, 1);

-- --------------------------------------------------------

--
-- Table structure for table `bandwidth_log`
--

CREATE TABLE `bandwidth_log` (
  `ID` int(11) NOT NULL,
  `school_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `bandwidth_bps` varchar(110) NOT NULL,
  `bandwidth_kbps` varchar(110) NOT NULL,
  `bandwidth_mbps` varchar(110) NOT NULL,
  `status` int(11) NOT NULL,
  `updatedtime` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `category_skills`
--

CREATE TABLE `category_skills` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `icon` varchar(250) NOT NULL,
  `description` text NOT NULL,
  `category_id` int(11) NOT NULL,
  `status` int(1) NOT NULL,
  `colorcode` varchar(100) NOT NULL,
  `createdby` varchar(100) NOT NULL,
  `creation_date` date NOT NULL,
  `modifiedby` varchar(100) NOT NULL,
  `modified_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `category_skills`
--

INSERT INTO `category_skills` (`id`, `name`, `icon`, `description`, `category_id`, `status`, `colorcode`, `createdby`, `creation_date`, `modifiedby`, `modified_date`) VALUES
(59, 'Memory', '1403077986Memory.png', 'Memory Skill', 1, 0, '#ff3300', '', '0000-00-00', '', '2017-07-23 06:44:00'),
(60, 'Visual Processing', '1403077998VisualProcessing.png', 'Visual Processing', 1, 0, '#9a1e00', '', '0000-00-00', '', '2017-07-23 06:44:11'),
(61, 'Focus & Attention', '1403078012Focus_Attention.png', 'Focus & Attention', 1, 0, '#ff9900', '', '0000-00-00', '', '2017-07-23 06:44:22'),
(62, 'Problem Solving', '1403078026ProblemSolving.png', 'Problem Solving', 1, 0, '#05b923', '', '0000-00-00', '', '2017-07-23 06:44:40'),
(63, 'Linguistics', '1403078039Linguistics.png', 'Linguistics', 1, 0, '#33ccff', '', '0000-00-00', '', '2017-07-23 06:44:44'),
(69, 'Maths', '1402513038Icon.png', '', 5, 0, '', '', '0000-00-00', '', '2014-06-09 13:27:18'),
(70, 'Life Skills', '1402513057Icon.png', '', 6, 0, '', '', '0000-00-00', '', '2014-06-09 13:27:37');

-- --------------------------------------------------------

--
-- Table structure for table `center_login_log`
--

CREATE TABLE `center_login_log` (
  `ID` int(11) NOT NULL,
  `centerid` int(11) NOT NULL,
  `sessionid` varchar(255) NOT NULL,
  `created_date` datetime NOT NULL,
  `lastupdate` datetime NOT NULL,
  `logout_date` datetime NOT NULL,
  `ip` varchar(50) NOT NULL,
  `country` varchar(800) NOT NULL,
  `region` varchar(800) NOT NULL,
  `city` varchar(800) NOT NULL,
  `browser` text NOT NULL,
  `isp` text NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `challenge`
--

CREATE TABLE `challenge` (
  `sno` int(11) NOT NULL,
  `question` text NOT NULL,
  `choice1` text NOT NULL,
  `choice2` text NOT NULL,
  `choice3` text NOT NULL,
  `choice4` text NOT NULL,
  `answer` text NOT NULL,
  `solution` text NOT NULL,
  `referred` text NOT NULL,
  `ques_no` text NOT NULL,
  `exam_date` text NOT NULL,
  `grade` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `challenge`
--

INSERT INTO `challenge` (`sno`, `question`, `choice1`, `choice2`, `choice3`, `choice4`, `answer`, `solution`, `referred`, `ques_no`, `exam_date`, `grade`) VALUES
(1, 'AZ, CX, FU, ?', ' IR ', 'IV', 'JQ ', 'KP', '3', 'A->C->F->J\nZ->X->U>Q\nThus, JQ', 'SSC CGL 2014', '16', '12 Jan, 2018', 6),
(2, '1, 2, 6, 24, ? ,720 ', '3', '5', '120', '8', '3', '1x2 = 2, 2x3 = 6, \n6x4 = 24, 24x5 = 120, \n120 x 6 = 720', 'SSC CGL 2014', '17', '12 Jan, 2018', 6),
(3, ' Suket has three daughters and each daughter has a brother. How many male members are there in the family ? ', '4', '2', '3', '1', '2', 'Father and a brother. \nTotally 2 male', 'SSC CGL 2014', '19', '12 Jan, 2018', 6),
(4, 'Which one of the given responses would be a meaningful order of the following ?\n\n1. apartment \n 2. town  3. street  4. building  5. complex ', ' 1, 5, 4, 3, 2 ', '4, 5, 3, 2, 1 ', '2, 1, 3, 4, 5 ', '1, 4, 5, 3, 2', '4', 'No Explanation', 'SSC CGL 2014', '13', '12 Jan, 2018', 6),
(5, 'A father is nine times as old as his son and the mother is eight times as old as the son.  The sum of the father\'s and mother\'s age is 51 years. What is the age of the son?', '7 years', '5 years', '4 years', '3 years', '4', 'Let son age be x.\n9x + 8x = 51\nx = 3', 'Civil Services 2014', '16', '12 Jan, 2018', 7),
(6, 'If A runs less fast than B, and B runs as fast but not faster than C; Then, as compared to A, C runs', ' slower than A', 'faster than A', 'with same speed as A', 'Given data is not sufficient to determine', '2', 'B and C are in same speed. \nA is behind B.\nSo, A is also behind C. Therefore,\nC runs faster than A', 'Civil Services 2014', '29', '16 Jan, 2018', 6),
(7, 'Each of A, B, C and D has Rs. 100.  A pays Rs.20 to B, who pays Rs.10 to C, who gets Rs.30 from D.  In this context, which one of the following is not correct? ', ' C is the richest', 'D is the poorest', 'C has more than what A and D have together', 'B is richer than D', '3', 'Final remainings: \n A - 80, B - 110, C - 140,\n D - 70', 'Civil Services 2014', '30', '16 Jan, 2018', 7),
(8, 'If CASUAL is coded as SACLAU, then what would be the code of\nMATRIC ?', ' CIRTAM     ', 'TMAICR    ', 'TAMCIR    ', 'ATMCIR', '3', 'Coding pattern:\nReversal of three letters', 'SSC CGL 2014', '26', '16 Jan, 2018', 6),
(9, '4, 6, 10, 16, 24, ?', '28', '30', '34', '40', '3', 'Increasing by multiples of 2', 'SSC CGL 2015', '3', '16 Jan, 2018', 7),
(10, ' 7           5             3 \n \n 8           4             9\n 2           8             ?\n----------------------------\n112      160         162', '4', '6', '8', '12', '3', 'Product of each column\nis displayed in last row', 'SSC CGL 2015', '20', '16 Jan, 2018', 7),
(11, 'MAN : PDQ :: WAN : ?', 'ZDQ', 'NAW', 'YQD', 'YDQ', '1', 'M -> P (2 letters after M)\nA -> D (2 letters after A)\nN -> Q (2 letters after N)\nSimilarly, WAN -> ZDQ', 'SSC CGL 2015', '27', '17, Jan 2018', 6),
(12, 'How many 5\'s are there in the following number sequence which are immediately followed by 4 but not immediately preceded by 6? \n\n8 9 5 4 2 5 4 8 5 5 7 8 6 4 4 5 6 6 5 4 7 5 4 4 6 3 8 ', '1', '2', '4', '3', '2', 'No Explanation', 'SSC CGL 2015', '45', '17, Jan 2018', 6),
(13, 'APPROACHED : ROACHEDAPP : : BARGAINED : ? ', 'AINEDBARG ', 'GAINEDBAR ', 'GAINEDRAB \n', 'RABGAINED', '2', 'First three letters are moved to last', 'SSC CGL 2014', '4', '17, Jan 2018', 6),
(14, 'From the given alternative words, select the word which\ncannot be formed using the letters of the given word : TRIVANDRUM', ' RAIN ', 'DRUM ', 'TRAIN ', 'DRUK', '4', 'No Explanation', 'SSC CGL 2014', '23', '17, Jan 2018', 6),
(15, 'A shopkeeper quotes the rate on the price tag by replacing numbers with letters as follows :\n\n0  1   2   3    4  5   6   7   8   9 \nB  R  O  W  N  S   T   I   C  K\nIf a customer purchases two items whose price tags read IIT and NICK, what is the total amount he has to Pay?', '4776', '4765', '5565', '5665', '3', 'IIT => 776\nNICK => 4789\nIIT + NICK = 776 + 4789 \n = 5565', 'SSC CGL 2014', '25', '17, Jan 2018', 7),
(16, 'APPLE: 50 : : ORANGE : ???¡?', '60', '69', '61', '63', '1', 'A - 1, P - 16, L -12, E - 5\nAPPLE = 1+16+16+12+5 = 50\nO - 15, R- 18, A - 1, N - 14, G - 7, E - 5\nORANGE = 15+18+1+14+7+5 = 60', 'SSC CGL 2012', '4', '18 Jan, 2018', 8),
(17, 'Identify the wrong number in the series:\n\n5, 13, 29, 61, 120, 253', '120', '253', '61', '29', '1', '5 + 8 = 13\n13 + 16 (8*2) = 29\n29 +  32 (16*2) = 61\n61 + 64 (32*2) = 125\n125 + 128(64*2) = 253', 'SSC CGL 2012', '26', '18 Jan, 2018', 8),
(18, '\nIf L denotes x, \nM denotes /,\nP denotes +, \nQ denotes - ,\nthen 16 P 24 M 8 Q 6 M 2 L 3 = ?                                            ', '10', '9', '12', '11', '1', '= (16 + 24) / (8 - 6) / (2 x 3)\n= 10', 'SSC CGL 2012', '32', '18 Jan, 2018', 7),
(19, 'The number 20% more than 80 is', '36', '30', '90', '96', '4', '.20 * 80 / 100 = 16\nTherefore, 80 + 16 = 96', 'SSC CGL 2012', '140', '18 Jan, 2018', 7),
(20, 'From the given alternatives select the \nword which cannot be formed by using the letters of the given word. \nAPPROPRIATE', 'PIRATE       ', 'APPROVE \n', 'PROPER     ', 'RAPPORT', '2', 'V is not present in the given\nword', 'SSC CGL 2012', '33', '18 Jan, 2018', 6),
(21, 'Four persons A, B, C, D consisting of two married couples are in a  group.  Both the women are shorter than \ntheir respective husbands.  A is the tallest among the four.  C is taller than B.  D is B\'s brother.  In this context, which one of the following statements is not correct?', ' All four have family ties', 'B is the shortest among \nthe four', 'C is taller than D', 'A is B\'s husband', '3', 'A,B - couple (A- male, B- female)\nC,D - couple (C- male, D- female)\nDescending order as per heights\nbased on the data given, \nA-D-C-B', 'Civil Services 2015', '17', '19 Jan, 2018', 7),
(22, 'Two equal glasses of same type are respectively 1/3\nand 1/4 full of milk.  They are then filled up with water and the contents are mixed in a pot.  What is the ratio of milk and water in the pot?', '7:17', '1:3', '9:21', '11:23', '1', 'Milk => 1/4 + 1/3 = 7/12\nWater => (1-1/4) + (1-1/3) = 17/12\nTherefore, 7:17', 'Civil Services 2015', '35', '19 Jan, 2018', 8),
(23, 'In a parking area, the total number of wheels of all the cars (4 wheelers) and scooters/bikes (2 wheelers) is \n100 more than twice the number of parked vehicles. The number of cars parked is ', '35', '45', '50', '55', '3', 'Let, cars = 50, bikes = y\nNo.of cars * 4(wheels) + No.of bikes *\n2(wheels) = 2 (No.of cars + No.of \nbikes) + 100;\n\n50 * 4 + y * 2 = 2( 50 + y) + 100\n200 + 2y = 100 + 2y + 100\n200 = 200\nThus, solved.', 'Civil Services 2015', '38', '19 Jan, 2018', 8),
(24, 'Out of 130 students appearing in an exam, 62 failed in English, 52 failed in Maths,\nwhereas 24 failed in both.  The no.of students who passed finally is ', '40', '50', '55', '60', '1', 'Failed in Both = 24\nFailed in English only = 62 - 24 = 38\nFailed in Maths only = 52 - 24 = 28\n\nTotal no.of failures = 24 + 38 + 28 = 90\nTherefore, Total - Failures = Passes\n                    130  -  90  = 40', 'Civil Services 2015', '36', '19 Jan, 2018', 7),
(25, 'In a group of persons travelling in a bus, 6 persons can speak Tamil, 15 can speak\nHindi and 6 can speak Gujarati.  In that group none can speak any other language. If 2 persons in the group can speak two languages only and one person can speak all the three languages, then how many persons are there in the group?', '21', '22', '23', '24', '1', 'Tamil speaking (with all three languge\nknown person ) = 6\nGujarati speaking (with 2 lang known\nperson and excluding all lang\nknown person) = 15 - 1\nHindi speaking (excluding all lang\nknown person and 2 lang known person)\n= 6 - 3\n\n6 + (15 - 1) + (6 - 3) = 23', 'Civil Services 2015', '37', '19 Jan, 2018', 8),
(26, 'Examine the following statements:\n\ni) Lady\'s finger is tastier than cabbage\nii) Cauliflower is tastier than lady\'s finger\niii) Cabbage is not tastier than peas.\nThe conclusion that can be drawn from these statements is that', ' Peas are as tasty as the lady\'s finger', 'Peas are as tasty as the cauliflower and\nlady\'s finger', 'Cabbage is the least tasty of the four\nvegetables', ' Cauliflower is tastier \nthan cabbage.', '4', 'No Explanation', 'Civil Services 2015', '32', '22, Jan 2018', 6),
(27, 'The monthly incomes of Peter and Paul are in the ratio of 4:3.  Their expenses are in the ratio 3:2.  If each saves Rs.6000 at the end of the month, their monthly incomes respectively are (in Rs.)', '24000 & 18000', '28000 & 21000', '32000 & 24000  ', '34000 & 26000', '1', 'Let A\'s income = 4x, B\'s income = 3x\nA\'s expense = 4x - 6000\nB\'s expense = 3x - 6000\nExpense ratio = 3:2\nTherefore, (4x - 6000) 2 = (3x - 6000) 3\nx = 6000\nThus, A\'s income = 24000, \nB\'s income = 18000', 'Civil Services 2015', '70', '22, Jan 2018', 7),
(28, 'In a plane, line X is perpendicular to line Y and parallel to line Z. Line U is \nperpendicular to both  lines V and W. Line X is perpendicular to line V. Which one of the following statements is correct?', ' Z,U and W are parallel', 'X, V and Y are  parallel', 'Z, V and U are all perpendicular to W', 'Y, V and W are \nparallel', '4', 'parallel -> Y, V, W\n            -> U, X, Z', 'Civil Services 2015', '76', '22, Jan 2018', 8),
(29, 'In a box of marbles, there are three less\nwhite marbles than the red ones and five more white marbles than the green ones. If there are a total of 10 white marbles, how many marbles are there in the box?', '26', '28', '32', '36', '2', 'White = 10\nGreen = White - 5 = 5\nRed = White + 3 = 13\nTherefore, total = 10 + 5 +13 = 28', 'Civil Services 2015', '', '22, Jan 2018', 7),
(30, 'Each of the six friends A, B, C, D, E and F scored different marks in an examination. C scored more than \nonly A and E.  D scored less than only B.  E did not score the least. The one who scored the third highest marks scored 81 marks. E scored 62 marks. Which of the following could possibly be C\'s score?', '70', '94', '86', '61', '1', 'C is between F and E.\nTherefore, C\'s mark should be between\n81 and 62. So, 70 is the answer', 'IBPS PO 2012', '19', '23 Jan, 2018', 8),
(31, 'Each of the six friends A, B, C, D, E and F scored different marks in an examination. C scored more than \nonly A and E.  D scored less than only B.  E did not score the least. The one who scored the third highest marks scored 81 marks.  E scored 62 marks. Which of the following is true with respect to the given information?', ' D\'s score was definitely less than 60.', 'F scored the maximum marks.', 'Only two people scored more than C\n', ' None is true', '4', 'As per the data analysed,\nnone of the given statements is true', 'IBPS PO 2012', '20', '23 Jan, 2018', 8),
(32, 'Each of the six friends A, B, C, D, E and F scored different marks in an examination. C scored more than \nonly A and E.  D scored less than only B.  E did not score the least. The one who scored the third highest marks scored 81 marks.  E scored 62 marks.  The person who scored the maximum, scored 13 more than F\'s marks.  Which of the following can be D\'s score?', '94', '60', '89', '78', '3', 'F - 81, B - 13 + F = 94\nTherefore, D\'s score lies between 81 \nand 94. So, 89 is the answer', 'IBPS PO 2012', '21', '23 Jan, 2018', 8),
(33, '4003 X 77 - 21015 = ? X 116', '2477', '2478', '2467', '2476', '4', 'No Explanation', 'IBPS PO 2012', '51', '23 Jan, 2018', 7),
(34, 'The fare of a bus is Rs. X for the first 5 kms\nand Rs. 13/km thereafter.  If the passenger pays Rs. 2402 for a journey of  187kms, what is the value of X?', '29', '39', '36', '31', '3', '182 = (2402-X)/13\n=> X = 36', 'IBPS PO 2012', '88', '23 Jan, 2018', 7),
(35, 'A military code writes SYSTEM as SYSMET and NEARER as AENRER.  Using the same code, FRACTION can be written as:', 'CARFTION', 'FRACNOIT', 'NOITCARF', 'CARFNOIT', '4', 'No Explanation', 'UPSC Prelims 2016', '1', '24 Jan, 2018', 6),
(36, 'How many numbers are there between 100\nand 300 which either begin with or end with 2?', '110', '111', '112', 'None of the\r\nabove', '1', '200 to 299 => 100 numbers\n102, 112, 122, 132, 142, 152, 162, 172,\n182, 192 => 10 numbers\nTotally 110 numbers', 'UPSC Prelims 2016', '3', '24 Jan, 2018', 7),
(37, 'Five people A, B, C, D, E are seated about\na round table.  Every chair is spaced equidistant from adjacent chairs.\ni) C is seated next to A\nii) A is seated two seats from D\niii) B is not seated next to A\nOn the basis of above information, which of\nthe following must be true?\n1) D is seated next to B\n2) E is seated next to A\n3) D and C are separated by two seats', ' 1 only', '1 and 2 only', '3 only   ', 'Neither 1 nor 2 nor 3', '2', 'In round table, the seating arrangement\nis:\nC-A-E-B-D', 'UPSC Prelims 2016', '32', '24 Jan, 2018', 8),
(38, 'There are some nectar-filled flowers on a \ntree and some bees are hovering on it.  If one bee lands on each flower, one bee will be left out.  If two bees land on each flower,\none flower will be left out. The no.of flowers and bees respectively are', ' 2 and 4', '3 and 2', '3 and 4 ', '4 and 3', '3', 'No Explanation', 'UPSC Prelims 2016', '34', '24 Jan, 2018', 7),
(39, 'In a class, there are 18 very tall boys.  If these constitute three-fourths of the boys and the total no.of boys is two-thirds of \nthe total no.of students in the class, what\nis the no.of girls in the class?', '6', '12', '18', '21', '2', 'Boys + Girls = Total students\nBoys(3/4) = 18 => Boys = 24\nTotal students(2/3)  = 24  => x = 36\nTherefore, Girls = 36 - 24 = 12', 'UPSC Prelims 2016', '51', '24 Jan, 2018', 8),
(40, 'A person allows 10% discount for cash payment from the marked price of a toy and still he makes a 10% gain.  What is the cost price of the toy which is marked Rs.770?', 'Rs. 610', 'Rs. 620', 'Rs. 630 ', 'Rs. 640', '3', '10% of 770 = 77 \nTherefore, toy sold at 770 - 77 = 693\n10% of 630 = 63 => 630 + 63 = 693\nThus, the actual cost of the toy iss 630', 'UPSC Prelims 2016', '20', '25 Jan, 2018', 7),
(41, 'In a class of 60 students, where the no.of girls is twice that of boys, Kamal, a boy ranked 17th from the top.  If there are 9 girls ahead of Kamal, the no.of boys in rank\nafter him is: ', '13', '12', '7', '3', '2', '2x (girls) + x (boys) = 60\nx = 20\nTherefore, boys = 20, girls = 40\n17 - 9 = 8 (boys ahead of kamal\nincluding him)\nTherefore, total boys - boys ahead of\nkamal including him = 20 - 8 = 12', 'UPSC Prelims 2016', '14', '25 Jan, 2018', 6),
(42, 'The average monthly income of a person in\na certain family of 5 is Rs.10,000.  What will be the average monthly income of a\nperson in the same family if the income of one person increased by Rs. 1,20,000 per year?', 'Rs. 12,000', 'Rs. 16,000', 'Rs. 20,000', 'Rs. 34,000', '1', 'Average income of a person = Rs.10,000\nTotal income of the family = 5 x 10000\n                                          = 50,000\nIncrease in income per year = 1,20,000\nIncrease in income per month = 1,20,000/12\n                                                 = 10,000\nTotal income of the family = 50,000 + 10,000\n                                          = 60,000\nAverage income of a person = 60,000/5\n                                              = 12,000', 'UPSC Prelims 2016', '17', '25 Jan, 2018', 8),
(43, 'There is an order of 19000 quantity of a \nparticular product from a customer.  The firm produces 1000 quantity of that product per day out of which 5% are unfit for sale. In how many days will the order be completed?', '18', '19', '20', '22', '3', 'Unfit product produced per day \n= 1000 * 5 / 100 = 50\nFit product produced per day \n= 1000 - 50 = 950\nTotal quantity required  = 19000\nNo.of days to produce 19000 = 19000/950\n = 20 days', 'UPSC Prelims 2018', '40', '25 Jan, 2018', 8),
(44, 'A class starts at 11.00 am. and lasts till 2.27 pm.  Four periods of equal duration are held during this interval.  After every period, a rest of 5 minutes is given to the students.  The exact duration of each \nperiod is:', ' 48 minutes', '50 minutes', '51 minutes ', '53 minutes', '1', 'Total minutes between 11am and 2.27pm \n= 207 minutes\nTotal periods = 4\nTotal break period = 3 * 5 =15 mins\n(4th period ends at 2.27. So no break after\nthat)\nTotal class period = 207 - 15 = 192 minutes\nTherefore,\nminutes per period = 192/4 = 48 minutes', 'UPSC Prelims 2016', '46', '25 Jan, 2018', 8),
(45, 'In aid of charity, every student in a class\ncontributes as many rupees as the no.of students in that class.  With the additional\ncontribution of Rs.2 by one student only, the total collection is Rs. 443.  Then how many students are there in the class?', '12', '21', '43', '45', '2', '443 - 2 = 441\n(441 is the total of equal amount shared by\ntotal no.of student)\nTotal no.of students = Amount shared/head\nTherefore, 21*21 = 441\nTotal no.of students = 21', 'UPSC Prelims 2016', '49', '25 Jan, 2018', 7),
(46, 'A person is standing on the first step from \nthe bottom of a ladder.  If he has to climb 4 more steps to reach exactly the middle step, how many steps does the ladder have?', '8', '9', '10', '11', '2', 'No.of steps below middle step = No.of \nsteps above middle step\nTotal steps = Middle step + 2 * (No.of steps\nbelow middle step)\n= 1 + 2*4 = 9', 'UPSC Prelims 2016', '73', '29 Jan, 2018', 6),
(47, 'A person walks 12 km due north, then 15km due east, after than 19km due west and then 15km due south.  How far is he from \nthe starting point?', ' 5km', '9 km', '37 km     ', '61 km', '1', 'From starting point he is 4km due west and\n3 km due south (with 90 degrees)\nWith pythogoras theorem,\n(4 * 4) + (3 * 3) = 25\nsquare root of 25 = 5.\nThus, 5km away from starting point', 'UPSC Prelims 2016', '78', '29 Jan, 2018', 6),
(48, 'Point R is 10 metres north of point A. Point\nK is exactly in the middle of the points R and A.  Point N is 7 metres east of point A. Point M is 7 metres east of point K. Point S is 6 metres north of point M.  What is the distance between points S and N?', '13 metres', '16 metres', '11 metres ', '12 metres', '3', 'S, M and N lie in the same line with M\nin the middle way.\nDistance between S and M is 6 metres.\nDistance between M and N is 5 metres.\nTherefore, distance between S and N is\n5 + 6 = 11 metres', 'IBPS PO 2013', '32', '29 Jan, 2018', 7),
(49, 'How many 3 digit number can be formed using the 4th, 7th and 9th digits of the \nnumber 937862541 each of which is \ncompletely divisible by 7?', 'None', 'One', 'Two      ', 'Three', '3', 'The digits are 8,5,1.\nThe numbers formed using these digits are:\n851, 815, 518, 581, 185, 158\nAmong these, those divisible by 7 are\n518 and 581.  Therefore, 2 numbers ', 'IBPS PO 2013', '31', '29 Jan, 2018', 7),
(50, 'In a certain code language, DHIE is written as WSRV and AEFB is written as ZVUY.  How will GKLH be written in that code language?', 'SQNR', 'TQMP', 'TRDO \n', 'TPOS', '4', 'No.of letters from A of the corresponding letter in \nactual word = No.of letters from Z in the coded word', 'IBPS PO 2013', '36', '30 Jan, 2018', 6),
(51, 'A person travels from P to Q at a speed of 40 kmph and returns to Q by increasing \nhis speed by 50%.  What is his average speed for both the trips?', ' 36kmph', '45 kmph', '48 kmph    ', '50 kmph  ', '3', 'Speed while going = 40 km/hr\r\nSpeed while returning = 150% of 40 \n= 60 km/hr\r\n\r\nAverage speed = \r\n2xyx+y=2?40?6040+60=4800100=48Km/hr', 'IBPS PO 2013', '139', '30 Jan, 2018', 8),
(52, 'CFIL:ORUX :: GDJM:?', 'HJLN', 'NQST', 'PSVY ', 'RTVX', '3', 'Pattern followed is 12 letters left between\neach letter. ', 'SSC CGL Tier I 2011', '1', '30 Jan, 2018', 7),
(53, 'Find the odd one: \n', 'ABYZ', 'CDWX', 'EFUV  ', 'GHTV', '4', 'Pattern followed is corresponding letters \nfrom the begining and end of alphabets', 'SSC CGL Tier I 2011', '11', '30 Jan, 2018', 6),
(54, 'Arrange the following words as per order in the dictionary.\n\n1) Preposition      2) Preperatively   \n3) Preposterous   4) Preponderate\n5) Prepossess', ' 2,4,1,5,3', '1,5,2,4,3', '5,4,2,3,1 ', ' 4,2,5,1,3', '1', 'No Explanation', 'SSC CGL Tier I 2011', '19', '30 Jan, 2018', 6),
(55, 'Complete the series:\n\n?, DREQ, GUHT, JXKW', 'EFRS', 'TGSF', 'JWVI ', ' AOBN', '1', 'No Explanation', 'SSC CGL Tier I 2011', '21', '31 Jan, 2018', 7),
(56, 'In a race, a competitor has to collect 6 apples which are kept in a straight line on a track and\nbucket is placed at the beginning of the track which is a starting point.  The condition is that the competitor can pick only one apple at a time, run back with it and drop it in the bucket. If he has to drop all the apples in the bucket, how much total distance he has to run if the bucket is 5 meters from the first apple and all other apples are placed 3 meters apart?', ' 40 m', '50 m', '75 m   ', ' 150 m', '4', 'Sum of the distances covered during collection \nof each apple \n= 10 + 16 + 22 + 28 + 34 + 40\n= 150', 'UPSC Prelims 2016', '18', '31 Jan, 2018', 7),
(57, 'A ate grapes and pineapple; B ate grapes and\noranges; C ate oranges, pineapple and apple; D ate grapes, apple and pineapple.  After taking fruits, B and C fell sick.  In the light of\nthe above facts, it can be said that the cause \nof sickness was ', ' Apple', 'Pineapple', 'Grapes  ', 'Oranges', '4', 'B => grapes, oranges\nC => oranges, pineapple, apple\nBoth had oranges in common and none other \nhad oranges. So, B and C fell ill because of \norange. Others did not fall ill because they did not\ntake orange', 'UPSC Prelims 2016', '27', '31 Jan, 2018', 7),
(58, 'A person X was driving in a place where all\nroads ran either north-south or east-west, forming a grid.  Roads are at a distance of 1km from each other in a parallel.  He started at the intersection of two roads, drove 3km north, 3km west and 4km south.  Which further route could bring him back to his starting point, if the same route is not repeated?', '3km east, then 2km south', '3km east, then 1km north', '1km north, then 2km west', '3km south, then 1km north', '2', 'No Explanation', 'UPSC Prelims 2016', '29', '31 Jan, 2018', 6),
(59, 'There are five hobby clubs in a college viz., \nphotography, yachting, chess, electronics and gardening. The gardening group meets every second day, the electronics group meets every third day, the chess group meets every fourth day, the yachting group meets every fifth day and the photography group meets every sixth day. How many times do all the five groups meet on the same day within 180 days?', '5', '18', '10', '3', '4', 'All five hobby clubs will meet on the day that is \nmultiple of 2, 3, 4, 5 and 6.\r\n\r\nLCM of 2, 3, 4, 5 and 6 = 60.\r\n\r\nAll five groups will meet every 60th day. So, in \n180 days, they will meet 3 times - 60th, 120th \nand 180th day.\r\n\r\nThe correct option is B.', 'UPSC Prelims 2016', '33', '31 Jan, 2018', 8),
(60, 'There were 50 faculty member comprising 30 \nmales and the rest females. No male faculty member knew music, but many of the female faculty members did. The Head of the institution invited six faculty members to a tea party by draw of lots. At the party is was discovered that no members knew music. The conclusion is that: ', 'the party comprised male the party ', 'the party comprised only those female faculty members who could not give renderings in music \n', 'the party comprised both male and female faculty members ', 'nothing can be said about  the gender composition of the party and', '4', 'No Explanation', 'UPSC Prelims 2016', '31', '1 Feb, 2018', 7),
(61, 'Consider the following statements:\n\n1. Either A and B are of the same age or A is older than B\n2. Either C and D are of the same age or D is older than C\n3. B is older than C\nWhich of the following conclusions can be drawn from the above statements? ', ' A is older than B\n\n', 'B and D are of the same age\n\n', 'D is older than C', 'A is older than C', '4', 'A equal or elder to B\nC equal or elder to D\nB is elder to C\nTherefore, C and D are younger to A and B \nirrespective of A and B\'s age.\n\nSo, answer is (d)', 'UPSC Prelims 2016', '52', '1 Feb, 2018', 8),
(62, 'A daily train is to be introduced between station\nA and station B starting from each end at 6 AM and the journey is to be completed in 42 hours.  What is the number of trains needed in order to maintain the Shuttle Service?', '2', '3', '4', '7', '3', 'Total time taken for a train to complete its \ntravel from A to B and back to A from B is 84 hrs.\nThere are 3 days and 12 hours  in 84 hrs. \nThat requires 3 train for 3 days and 1 more train\nto start before the first train reaches back in 12 hrs.\nMaking it toally 3 + 1  = 4 trains.', 'UPSC Prelims 2016', '58', '1 Feb, 2018', 8),
(63, 'Between 6 PM and 7 PM the minute hand of a clock will be ahead of the hour hand by 3 minutes at', ' 6.15 pm', '6.18 pm', '6.36 pm      ', '6.48 pm', '3', 'Hour hands moves at 12, 24, 36, 48 and 60th mins.\nTherefore when the minute hand is at 36th min, \nhour hand will be 3 minutes behind it,', 'UPSC Prelims 2015', '8', '1 Feb, 2018', 8),
(64, 'There are 5 tasks and 5 persons. Task - 1 cannot be assigned to either person-1 or person-2, Task-2 must be assigned to either person-3 or person4. Every person is to be assigned one task. In how many ways can the assignment be done?', '6', '12', '24', '144', '3', '2nd task can be done by persons 3 or 4 i.e. 2 ways \n1st task can be done by persons 3,4 or 5 i.e.3 ways \nbut one of the persons 3 or 4 have already done\ntask 2 so 1st task can be done by (3-1) 2 persons \ni.e. 2 ways\nNow remaining 3 tasks can be done by (5-2) \n3 persons i.e. (3x2x1) ways\n\nSo total (2x2x3x2x1) = 24\n\n\n\n \n \n', 'UPSC Prelims 2015', '9', '1 Feb, 2018', 8),
(65, 'In a society it is customary for friends of the same sex to hug and for friends of opposite sex to shake hands when they meet. A group of friends met in a party and there were 24 handshakes. Which one among the following numbers indicates the possible number of hugs?', '39', '30', '21', '20', '3', 'chances of getting 24 hand shakes\n(a) 6 g 4 b  (b) 8 g 3 b  (c)12 g 2 b\n\nexplanation: In option (c) one boy can shake hands\nwith 12 girls similary other boy.  so total shakes done 24, imilarly other options.\nsimilarly no of hugs done for:\n(a) (5+4+3+2+1)+(3+2+1)=21\n(b) (7+6+5+4+3+2+1)+(2+1)=31\n(c) (11+10+9+8+7+6+4+3+2+1)+1=62\n\nAvailable option is 21.  So, it must be 6 vs 4\n(boys/girls).  Answer: 21', 'UPSC Prelims 2015', '14', '2 Feb, 2018', 8),
(66, 'Two men Anil and David, and two women Shabnam and Rekha, are in a sales group. Only two speak tamil. The other two speak\nMarathi.  Only one man and one woman can drive a car.  Shabnam speaks Marathi.  Anil speaks Tamil.  Both Rekha and David can drive. Which of the following statements is true?', ' Both the tamil speakers can drive a car', 'Both the marathi speakers can drive a \ncar.', 'Both of those who can drive a car speaks\nMarathi', 'One of those who \ncan drive a car speaks\r\nTamil', '4', 'No Explanation', 'UPSC Prelims 2015', '15', '2 Feb, 2018', 7),
(67, 'A cow costs more than 4 goats but less than 5 goats. If a goat costs between Rs.600 and \nRs.800 which of the following is a most valid conclusion ?', ' A cow costs more than Rs. 2,500.\n', 'A cow costs less than Rs. 3,600.\n', 'A cow costs between Rs. 2,600\nand Rs. 3,800', 'A cow costs between \nRs. 2400 and\r\nRs. 4000', '4', 'A goat min cost = 400\nA goat max cost = 800\n\nA cow cost lies between the total cost of 4 goats\nand 5 goats\nMin cost of 4 goats = 400 * 4 = 2400\nMax cost of 5 goats = 800 * 5 = 4000\nTherefore, answer is option D', 'UPSC Prelims 2015', '17', '2 Feb, 2018', 8),
(68, 'Candidates in a competitive examination \nconsisted of 60% men and 40% women. 70% men and 75% women cleared the qualifying test and entered the final test where 80% men and 70% women were successful. Which of the following statements is correct?', 'Success rate is higher for women.', 'overall success rate is below 50%', 'More men cleared the examination than \nwomen', 'Both (a) and (b)', '3', '80/100(70/100(60/100) > 70/100(75/100(40/100))\n0.21 > 0.336\n\nTherefore,\nGents > Ladies', 'UPSC Prelims 2015', '20', '2 Feb, 2018', 8),
(69, 'A selection is to be made for one post of \nPrincipal and two posts of Vice-Principal. Amongst the six candidates called for the interview, only two are eligible for the post of Principal while they all are eligible for the post of Vice-Principal. The number of possible combinations of selectees is :', '4', '12', '18', 'None of the above', '4', 'Total number of ways = 2C1 . 5C2 = 2 x 5!/3!2! \n= 2 x 10 = 210', 'UPSC Prelims 2015', '28', '2 Feb, 2018', 7),
(70, 'Consider the following statements and conclusions:\n\nStatements:\nSome men are great.         Some men are wise.\nConclusion I: Men are either great or wise.\nConclusion II: Some men are neither great nor wise.\nWhich one of the following is correct?', 'Only conclusion I is valid', 'Only conclusion II is valid', 'Both the conclusions are valid', 'Neither of the \nconclusions is valid', '2', 'No Explanation', 'UPSC Prelims 2015', '35', '3 Feb, 2018', 6),
(71, 'Usha runs faster than Kamala, Priti runs slower than Swati, Swati runs slower than Kamala. Who is the slowest\nrunner ?', 'Kamala', 'Priti', 'Swati        ', 'Usha', '2', 'Running order from fast to slow:\nUsha -> Kamala -> Swati -> Priti', 'UPSC Prelims 2015', '40', '3 Feb, 2018', 6),
(72, 'What is the missing number X of the series\n7, X, 21, 31, 43?', '11', '12', '13', '14', '3', 'Series: \n7 -> (7+6) = 13 -> (13+8) = 21 -> (21+10) = 31 ->\n(31 + 12) = 43', 'UPSC Prelims 2015', '53', '3 Feb, 2018', 7),
(73, 'In a test, a candidate attempted only 8 \nquestions and secured 50% marks in each of the questions. If he obtained a total of 40% in the test and all questions in the test carried equal marks, how many questions were there in the test?', '8', '10', '15', '16', '2', 'Let x questions be there with 10 marks for each \nquestion.\nMaximum marks = 10x\n8*5 = 40% of 10x\nx = 10', 'UPSC Prelims 2015', '55', '3 Feb, 2018', 8),
(74, 'A father is nine times as old as his son and the\nmother is eight times as old as the son. The sum of the father\'s and the mother\'s age is 51 years. What is the age of the son?', '3 years', '4 years', '7 years       ', '5 years', '1', 'Let age of son be x.\r\nFather\'s age = 9x and Mother\'s age = 8x\r\n9x + 8x = 51\r\n\r\nx = 3', 'UPSC Prelims 2015', '56', '3 Feb, 2018', 7),
(75, 'Consider the following statements :\n\n1. A man had a wife, two sons and two daughters in his family.\n2. The daughters were invited to a feat and the male members of the family went out to take part in a picnic.\n3. The man\'s father did not return from his work. \nWhich of the following statements is true?', 'Only the man\'s wife was left at home.', 'It is likely that the man\'s wife was left\nat home', 'None was left at home', 'More than one person \nwas left at home', '2', 'No Explanation', 'UPSC Prelims 2015', '58', '6 Feb, 2018', 7),
(76, 'Geeta: Naresh has become a better boxer\nsince he started meditation\n Radha: Impossible.  A boxer\'s most important asset is his aggressiveness.', 'meditation tends to make a person less\naggressive', 'meditation has little or no effect on the\nperson who practices it', 'Naresh was a poor boxer earlier because\nhe was not aggressive enough', 'Naresh would not \nhave taken to \r\nmeditation as he \nwas a boxer', '1', 'No Explanation', 'UPSC Prelims 2015', '59', '6 Feb, 2018', 6),
(77, 'Examine the following statements: \n\n1. All colours are pleasant. \n2. Some colours are pleasant. \n3. No colour is pleasant. \n4. Some colours are not pleasant. \nGiven that statement 4 is true, what can be definitely concluded?', '1 and 2 are true.', '3 is true.', '2 is false', '1 is false.', '4', 'No Explanation', 'UPSC Prelims 2017', '10', '6 Feb, 2018', 7),
(78, 'How many numbers are there between 99 and\n1000 such that the digit 8 occupies the units place?', '64', '80', '90', '104', '3', '100 - 200 => 10 such digits\nSimilarly, 100 - 1000 => 90 such digits', 'UPSC Prelims 2017', '11', '6 Feb, 2018', 6),
(79, 'The age of Mr. X last year was the square of a \nnumber and it would be the cube of a number next year. What the least number is of years he must wait for his age to become the cube of a number again?', '42', '38', '25', '16', '2', 'Square of a number = last year age\n5 square                   = 25\n\nPresent age = last year age + 1 = 25 + 1 = 26\nNext year age = 27 = cube of 3\n\nNext cube of a number is 4 cube = 64\n\nMinimum years to attain 64 from present age \n= 64 - 26  38', 'UPSC Prelims 2017', '13', '6 Feb, 2018', 7),
(80, 'A bag contains 20 balls. 8 balls are green, 7 are white and 5 are red. What is the minimum \nnumber of balls that must be picked up from the bag blindfolded (without replacing any of it) to be assured of picking at least one ball of each colour?', '17', '16', '13', '11', '2', ' Possibilities of all green at first = 8\nPossibilities of all white next = 7\nPossibility of one red = 1\n8 + 7 + 1 = 16', 'UPSC Prelims 2017', '16', '7 Feb, 2018', 6),
(81, 'If 2 boys and 2 girls are to be arranged in a \nrow so that the girls are not next to each other, how many possible arrangements are there?', '3', '6', '12', '24', '3', 'Varying positions: \nG1 B1  G2  B2, G1  B2  G2  B1, G2 B1  G1 B2,\nG2 B2 G1 B1, B1 G1 B2 G2, B1 G2 B2 G1, \nB2 G1 B1 G2, B2 G2 B1 G1, G1 B1 B2 G2, \nG2 B1 B2 G1, G1 B2 B1 G2, G1 B1 B2 G2\n\nTherefore, 12 possibile positions', 'UPSC Prelims 2017', '17', '7 Feb, 2018', 6),
(82, 'Consider the following A, B, C, D, E, F, G and H are standing in a row facing North. B is not \nneighbor of G. F is to the immediate right of G and neighbor of E. G is not at the extreme end. A is sixth to the left of E. H is sixth to the \nright of C. Which one of the following is correct in respect of the above?', 'C is to the immediate left of A.', 'D is immediate neighbour of B and F.', 'G is to the immediate right of D. ', 'A and E are at the \nextreme ends.', '3', 'Based on the data given, the positions of A-H\nstarting from right to left is as follows:\nH E F G D B C A\n\nTherefore, option c is the right answer', 'UPSC Prelims 2017', '19', '7 Feb, 2018', 7),
(83, 'In a certain code, \'256\' means \'red colour chalk\', \'589\' means \'green colour flower\' and \n\'254\' means \'white colour chalk\'. The digit in the code that indicates white\' is', '2', '4', '5', '8', '2', '5 - colour\n2 - chalk\nTherefore, 4 -> white', 'UPSC Prelims 2017', '20', '7 Feb, 2018', 6),
(84, 'In a school, there are five teachers A, B, C, D and E. A and B teach Hindi and English. C \nand B teach English and Geography. D and A teach Mathematics and Hindi. E and B teach History and French. Who teaches maximum number of subjects?', 'A', 'B', 'D         ', 'E', '2', 'Based on the data given, no.of subjects handled\nby each teacher:\nA - 3\nB - 5\nC - 2 \nD - 2\nE - 2\nTherefore, B handles maximum no.of subjects', 'UPSC Prelims 2017', '32', '7 Feb, 2018', 6),
(85, 'What is the total number of digits printed, if a book containing 150 pages is to be numbered from 1 to 150?', '262', '342', '360', '450', '2', 'Single digit nos: 1 to 9 = 9 x 1 = 9\nDouble digit nos: 10 - 99 = 90 x 2  = 180\nTriple digit nos: 100 - 150 = 51 x 3 = 153\nTotal digits = 9 + 180 + 153 = 342', 'UPSC Prelims 2017', '40', '8 Feb, 2018', 6),
(86, 'Suppose the average weight of 9 persons is \n50 kg. The average weight of the first 5 \npersons is 45 kg, whereas the average weight \nof the last 5 persons is 55 kg. Then the weight of the 5th person will be', '45 kg\n', '47.5 kg\n', '50 kg', '52.5 Kg', '3', 'The average weight of 9 persons is 50 kg. So, total\nweight of all the persons = 50x9 = 450 kg.\nThe average weight of the first 5 persons is 45 kg. \nSo, their total weight = 45x5 = 225 kg.     \nThe average weight of the last 5 persons is 55 kg. \nSo, their total weight = 55x5 = 275 kg. \nThe fifth person has been included in both the last cases.\nHence, the weight of the fifth person =275+225-450 = 50 kg \n\n', 'UPSC Prelims 2017', '48', '8 Feb, 2018', 8),
(87, 'There are certain 2-digit numbers. The \ndifference between the number and the one obtained on reversing it is always 27. How \nmany such maximum 2-digit numbers are \nthere?\n', '3', '4', '5', 'None of the above', '4', 'Let the numbers be of the form xy and yx, \ni.e. 10x + y and 10y + x (where y > x)\nAs per the question, (10y + x) - (10x + y) = 27\nOr 9y - 9x = 27\nOr y - x = 3\nOr y = x + 3\nSo, possible sets of the value of x and y are: \n(1, 4), (2, 5), (3, 6), (4, 7), (5, 8) and (6, 9), \ni.e. 6 such numbers are there.', 'UPSC Prelims 2017', '39', '8 Feb, 2018', 8),
(88, 'A clock strikes once at 1 o\'clock, twice at 2 o\'clock and thrice at 3 o\'clock, and so on. If it takes 12 seconds to strike at 5 o\'clock, what \nis the time taken by it to strike at 10 o\'clock?', ' 20 seconds\n', '24 seconds\n', '28 seconds\n', '30 seconds', '2', 'At 5 o\'clock the clock will strike 5 times. It\'s given that it takes 12 seconds to do so. Now, at 10 o\'clock the clock will strike 10 times. Hence, the time taken by it to strike = 12 x 2 = 24 seconds', 'UPSC Prelims 2017', '53', '8 Feb, 2018', 6),
(89, 'There are thirteen 2-digit consecutive odd \nnumbers. If 39 is the mean of the first live such numbers, then what is the mean of all the thirteen numbers?', '47', '49', '51', '45', '1', 'These are consecutive odd numbers. The mean of \nthe first 5 such numbers will be third such number,\r\nwhich is given to be as 39.\r\nHence, the series is: 35, 37, 39, 41, 43, 45, 47, \n49, 51 and so on.\r\nNow, mean of all the thirteen numbers \n= {[(13 -1)/2] + 1} th term = 7th term from the start, \ni.e. 47. ', 'UPSC Prelims 2017', '55', '8 Feb, 2018', 8),
(90, 'If second and fourth Saturdays and ,all the \nSundays are taken as only holidays for an office, what would be the minimum number of possible working days of any month of any year?', '23', '22', '21', '20', '1', 'No Explanation', 'UPSC Prelims 2017', '', '9 Feb, 2018', 7),
(91, '15 students failed in a class of 52. After removing the names of failed students, a merit order list has been prepared in which the \nposition of Ramesh is 22nd from the top. What is his position from the bottom?', ' 18th\n', '17th\n', '16th\n', '15th', '3', '15 students failed in a class of 52. Hence, number of students that passed \n= 52 - 15 = 37\n\nIn the list of passed students, position of Ramesh is 22nd from the top.\n\nSo, his position from the bottom = (37 + 1) - 22 \n\n= 38 - 22 = 16th', 'UPSC Prelims 2017', '78', '9 Feb, 2018', 6),
(92, '\nConsider the following:\nA + B means A is the son of B.\nA - B means A is the wife of B.\nWhat does the expression P + R - Q mean?', 'Q is the son of P.\n', 'Q is the wife of P.\n', 'Q is the father of P.', 'None of the above', '3', 'A + B means A is the son of B; A - B means A is \nthe wife of B\n\nSo, P + R - Q may be depicted as:\n\n        R-  <-----> Q+\n         |\n         |\n        P+\n\nIt\'s clear that Q is the father of P\n', 'UPSC Prelims 2017', '79', '9 Feb, 2018', 6),
(93, 'Gopal bought a cell phone and sold it to Ram \nat 10% profit. Then Ram wanted to sell it back \nto Gopal at 10% loss. What will be Gopal\'s \nposition if he agreed?', ' Neither loss nor gain\n', 'Loss 1%\n', 'Gain 1%', 'Gain 0.5%', '3', 'Let cost price for Gopal = Rs. 100\nHe sold it to Ram at 10% profit. So, his selling price \n= 100 + 10% of 100 = 100 + 10 = Rs. 110\nNow, if Ram resales it to Gopal at 10% loss, his \nselling price = 110 ??Â??º?? 10% of 110 = 110 ??Â??º?? 11 \n= Rs. 99\nAs far as Gopal is concerned, in this second \ntransaction, by buying a Rs. 100 pen at Rs 99, \nhe registers a gain of 1%.', 'UPSC Prelims 2017', '80', '9 Feb, 2018', 8),
(94, 'There are four routes to travel from city A to \ncity B and six routes from city B to city C. How many routes are possible to travel from the city A to city C?', '24', '12', '10', '8', '1', 'Simple arithmetic. For every one route, you will \nhave six routes to take. So, total number of routes\nis\n6 X 4 = 24', 'UPSC Prelims 2011', '34', '12 Feb, 2018', 6),
(95, 'A contract on construction job specifies a \npenalty for delay in completion of the work beyond a certain date is as follows: Rs. 200 for the first day, Rs. 250 for the second day, Rs. 300 for the third day etc., the penalty for each succeeding day being 50 more than that of the preceding day. How much penalty should the contractor pay if he delays the work by 10 days ?', 'Rs. 4950\n', 'Rs. 4250\n', 'Rs. 3600', 'Rs. 650', '2', 'The penalty for delay on first day is 200, for second \nday is 250, for third day is 300 and so on.\r\nThe penalties form an arithmetic progression (AP) \nwith a common difference of 50 and first element\r\n(a) as 200.\r\nThe sum of penalties for 10 days is thus same as \nthe sum of numbers in the A.P. with n as 10.\r\nSum of AP (formula) = n/2 [2a + (n-1) d] \n= 10/2 [ 2 X 200 + (10-1) X 50 ] = 4250', 'UPSC Prelims 2011', '35', '12 Feb, 2018', 8),
(96, 'A person has only Rs. 1 and Rs. 2 coins with \nher. If the total number of coins that she has is 50 and the amount of money with her is Rs.75, then the number of Rs. 1 and Rs. 2 coins are, \nrespectively', ' 15 and 35\n', '35 and 15\n', '30 and 20', '25 and 25', '4', 'Let the Rs. 1 and Rs. 2 coins be x and y in number \nrespectively.\r\nGiven x + y = 50 and x + 2y = 75\r\nSolving the above two equations, you get x = 25 \nand y = 25. ', 'UPSC Prelims 2011', '39', '12 Feb, 2018', 7),
(97, 'Three persons start walking together and their steps measure 40 cm, 42 cm and 45 cm\nrespectively. What is the minimum distance each should walk so that each can cover the same distance in complete steps ?', '25 m 20 cm\n', '50 m 40 cm\n', '75 m 60 cm\n', '100 m 80 cm', '1', ' Take the LCM of 40, 42 and 45 to know at what \npoint will they find a common multiple. It is 2520 cm \ni.e. 25 m 20 cm.', 'UPSC Prelims 2011', '40', '13 Feb, 2018', 8),
(98, 'If a bus travels 160 km in 4 hours and a train travels 320 km in 5 hours at uniform speeds, then what is the ratio of the distances travelled by them in one hour?', ' 8 : 5\n', '5 : 8\n', '4 : 5', ' 1 : 2', '2', 'Take the ratio of both the speeds. \nBus = 40 kmph, so 40 Kms in one hour. \nTrain = 64 kmph, so 64 kms in one hour.\r\nRatio = 40:64 = 5:8', 'UPSC Prelims 2011', '41', '13 Feb, 2018', 7),
(99, 'There are 100 students in a particular class. 60% students play cricket, 30% student play \nfootball and 10% student play both the games. What is the number of students who play neither cricket nor football?', '25', '20', '18', '15', '2', 'If 60% play cricket, and 30% play football then total \npercentage that plays both = 60 + 30 = 90%\r\nBut out of these, 10% that play both need to be \nsubtracted as they are counted twice. \nSo, 80% play both. Those who play neither will \nbe 100-80 = 20%.', 'UPSC Prelims 2011', '42', '13 Feb, 2018', 8),
(100, 'A village having a population of 4000 requires 150 liters of water per head per day. It has a tank measuring 20 m x 15 m x 6 m. The water of this tank will last for', ' 2 days\n', '3 days\n', '4 days', '5 days', '2', 'Total requirement = 4000 X 150 = 6,00,000 litres\nVolume (capacity) of tank = L x B x H (for cuboids ) \n= 20 X 15 X 6 = 1800 m3\n1m = 1000 litres\nSo, capacity = 18,00, 000\nSo water will last for 18,00,000/6,00,000 = 3 days', 'UPSC Prelims 2011', '43', '13 Feb, 2018', 8),
(101, 'A student on her first 3 tests receives on an \naverage score of N points. If she exceeds her previous average score by 20 points on her fourth test, then what is the average score for the first 4 tests?', ' N + 20\n', 'N + 10\n', 'N + 4', ' N + 5', '4', 'The average score of student in 3 tests is N points.\nHence the total score = 3N points.\nGiven the score in fourth test = N + 20, the average \nscore of student in four tests will be \n= (3N+N+20)/4 = N+5', 'UPSC Prelims 2011', '49', '13 Feb, 2018', 8),
(102, 'In a group of persons, 70% of the persons are \nmale and 30% of the persons are married. If two sevenths of males are married, what fraction of the females is single ?', '2/7', '1/3', '3/7', '2/3', '4', '70% males, so 30% females.\nIf 2/7th of males are married, this means 2/7 (70 %) \n= 20% males are married. \nSo, 10% females are married (out of 30% total \nmarried). \nSo, single females will be 20% out of total 30% \nfemales. The fraction is 2/3.', 'UPSC Prelims 2011', '50', '14 Feb, 2018', 8),
(103, 'The houses of A and B face each other on a road going north-south, A\'s being on the western side. A comes out of his house, turns \nleft, travels 5 km, turns right, travels 5 km to \nthe front of D\'s house. B does exactly the same and reaches the front of C\'s house. In this context, which one of the following statements is correct?', 'C and D live on the same street.\n', 'C\'s house faces south.\n', 'The houses of C and D are less than \n20 km apart.', ' None of the above', '3', 'The distance between C and D, is twice the distance between C and A.\nBetween C and A, we use Pythagoras theorem  i.e. square root of\nSo, distance between C-D will = 14.12 km approximately\n', 'UPSC Prelims 2011', '51', '14 Feb, 2018', 7),
(104, '\nIn a queue, Mr. X is fourteenth from the front and Mr. Y is seventeenth from the end, while Mr. Z is exactly in between Mr. X and Mr. Y. \nIf Mr. X is ahead Mr. Y and there are 48 persons in the queue, how many persons are then between Mr. X and Mr. Z ?', '6', '7', '8', '9', '3', 'Since X is 14th from the front, Y is 17th from the \nend, and also X is ahead of Y, there must be \n48 - (14 + 17) = 17 persons in between X and Y.\nNow, as there are equal number of people between \nX and Z; and Z and Y. So, the number of persons\nbetween X and Z has to be 8.\n\nIt will be like - 13 ---X ----(8)----Y----(8)-----Z', 'UPSC Prelims 2011', '63', '14 Feb, 2018', 6),
(105, 'In five flats, one above the other, live five \nprofessionals. The professor has to go up to meet his IAS officer friend. The doctor is equally friendly to all, and has to go up as frequently as go down. The engineer has to go up to meet his MLA friend above whose flat lives the professor\'s friend. From the ground floor to the top floor, in what order do the five professionals live?', ' Engineer, Professor, Doctor, IAS officer, \nMLA', 'Professor, Engineer, Doctor, IAS officer,\nMLA', 'IAS officer, Engineer, Doctor, Professor,\nMLA', 'Professor, Engineer, \nDoctor, MLA, \r\nIAS officer', '4', 'S1: IAS>....>Prof\r\nS2: Doc is in the middle\r\nS3: IAS>..MLA>..>Engineer\r\nNow only way in which these can be satisfied is:\r\nIAS>MLA>Doctor> Engineer> Professor ', 'UPSC Prelims 2012', '15', '14 Feb, 2018', 7),
(106, 'Consider the following statements:\n\n1. All X-brand cars parked here are white.\n2. Some of them have radial tyres\n3. All X-brand cars manufactured after 1986 have radial tyres are parked here.\n4. All cars are not X-brand.\nWhich one of the following conclusions can be drawn from the above statements?', ' Only white cars are parked here.', 'Some white X-brand cars with radial \ntyres are parked here.', 'Cars other than X-brand cannot have \nradial tyres.', 'Most of the X-brand \ncars are manufactured\n before 1986.', '2', 'Take (a): Its wrong because only X-brand cars \nparked here are white.\r\nTake (b): All X-brand cars are white and some have \nradial tyres which means its correct.\r\nTake (c): Its an out of the league statement. ?\r\nTake (d): An illogical and out of the context \nstatement', 'UPSC Prelims 2012', '46', '14 Feb, 2018', 7),
(107, 'Gita is prettier than Sita but not as pretty as \nRita. Then,', ' Sita is not as pretty as Gita', 'Sita is prettier than Rita', 'Rita is not as pretty as Gita', 'Gita is prettier than Rita', '1', 'Simple symbols will get you the answer.\r\nR> G>S\r\nOptions (b), (c) and (d) are false.', 'UPSC Prelims 2012', '63', '15 Feb, 2018', 6),
(108, 'Given that,\n1. A is the brother of B\n2. C is the father of A.\n3. D is brother of E.\n4. E is the daughter of B\nThen, the uncle of D is?', ' A', 'B', 'C\n', 'E', '1', 'Draw a family tree diagram and it becomes easy.\nC\n(Arrow denotes father/mother - son relationship)\nA - B\n |\nD - E (Dash denotes brothers/sisters)\nUncle of D is A.', 'UPSC Prelims 2012', '64', '15 Feb, 2018', 6),
(109, 'Examine the following statements:\n\n1. Rama scored more than Rani\n2. Rani scored less than Ratna\n3. Ratna scored more than Rama\n4. Padma scored more than Rama but less than Ratna.\nWho scored the highest?', 'Rama', 'Padma', 'Rani', 'Ratna', '4', 'Again simple symbols.\r\nS1: Rama>...... Rani\r\nS2: Ratna>.....Rani\r\nS3: Ratna>...>Rama>...Rani\r\nS4: Ratna>Padma>Rama>Rani\r\nRatna scored the highest.', 'UPSC Prelims 2012', '65', '15 Feb, 2018', 6),
(110, 'Mr. Kumar drives to work at an average speed of 48km/hr. The time taken to cover the first 60% of the distance is 10 minutes more \nthan the time taken to cover the remaining\ndistance. How far is his office?', ' 30km', '40km', '45km', '48km', '2', 'Let the distance be N.\r\nFirst 60% distance is covered in 10 more minutes \nmore time than that of the rest 40%\r\ndistance\r\nSo, 0.6 x N distance is covered in 10 more minutes \nmore than that of the rest 0.4 x N\r\ndistance\r\nWhich means 0.2 x N is covered in 10 minutes \ni.e., 1/6 hr\r\nHence, Average speed = distance/time \n= 0.2 x N /(1/6) = 48\r\n=> x = 48/6 x 0.2 =40 km', 'UPSC Prelims 2012', '62', '16 Feb, 2018', 8),
(111, 'Ten new TV shows started in January- 5 \nsitcoms, 3 drama and 2 news magazines. By April, only seven of the new shows were still on, five of them being sitcoms.\nBased on the above information, for conclusions, as given below, have been made. Which of these logically follows from the information given above?', ' Only one news magazine show is still \ngoing on.', 'Only one of the drama show is still going \non.', 'At least one discontinued show was a \ndrama.', 'Viewers prefer sitcoms \nover drama.', '3', 'Three shows were discontinued as given. Since no \nsitcoms shows were discontinued, the discontinued \nones must be either drama or news magazines. \nNow, there were only two news magazines. So, \natleast one discontinued show was a drama.\r', 'UPSC Prelims 2012', '59', '16 Feb, 2018', 7);
INSERT INTO `challenge` (`sno`, `question`, `choice1`, `choice2`, `choice3`, `choice4`, `answer`, `solution`, `referred`, `ques_no`, `exam_date`, `grade`) VALUES
(112, 'Examine the following statements:\n\n1. Either A & B are of same age or A is older than B\n2. Either C & D are of same age or D is older than C\n3. B is older than C\nWhich of the following conclusions can be drawn from the above statements?', 'A is older than B\n', 'B and D are of the same age', 'D is older than C', 'A is older than C', '4', 'From S1: A>=B\r\nFrom S2: D>=C\r\nFrom S3: B>C\r\nNow if B (which is either equal or older than A) is \ngreater than C, then A has to be older than\r\nC.\r', 'UPSC Prelims 2012', '55', '16 Feb, 2018', 7),
(113, 'A gardener has 1000 plants: He wants to plant \nthem in such a way that the number of rows and the number of columns remains the same. What is the minimum number of plants that he needs more for this purpose?', '14', '24', '32', '34', '2', '31 x 31 = 1024\nThat\'s the first number that exceeds 1000 on its\nsquare.\nTherefore, 1024-1000 = 24\nSo, 24 more plants needed to arrange them in \n31 rows and 31 columns', 'UPSC Prelims 2013', '4', '16 Feb, 2018', 6),
(114, 'A sum of RS. 700 has to be used to give \nseven cash prizes to the students of a school \nfor their overall academic performance. If each\nprize is Rs. 20 less than its preceding prize, \nthen what is the least value of the prize?', 'RS. 30\n', 'RS. 40\n', 'RS. 60\n', ' RS. 80', '2', 'X + X+20 + X+40 +... X+120=700\n \n=> 7X+(20+40+...+120)=700\n\n=> 7X+20(1+2+3+...+6)=700 => 7X+20(21)=700\n \n=> 7X=280 =>X=40', 'UPSC Prelims 2013', '5', '16 Feb, 2018', 7),
(115, 'Out of 120 applications for a post, 70 are male and 80 have a driver\'s license. What is the ratio between the minimum to maximum number of males having driver\'s license?', '1 to 2\n', '2 to 3\n', '3 to 7', ' 5 to 7', '3', 'Number of females = 120 - 70 = 50\n\nSo, a case where minimum number of males have driving license would mean all females have driving license. All 50 females have driver\'s license. \n\nSo, only 30 males with license (minimum number).\n\nNow, where maximum number of males will have license, all 70 should have license (only 10 females would have license then).\n\nRatio: 30/70 = 3 to 7', 'UPSC Prelims 2013', '', '19 Feb, 2018', 8),
(116, 'In a garrison, there was food for 1000 soldiers for one month. After 10 days, 1000 more soldiers joined the garrison. How long would the soldiers be able to carry on with the remaining food?', '25 days\n', '20 days\n', '15 days\n', '10 days', '4', 'After 10 days, the remaining food would be sufficient for the 1000 soldiers for 20 more days So, If 1000 more soldiers are added, it shall be sufficient for only 10 days (as the no. of soldiers is doubled, the days are halved)', 'UPSC Prelims 2013', '7', '19 Feb, 2018', 8),
(117, 'The tank-full petrol in Arun\'s motor-cycle lasts \nfor 10 days. If he starts using 25% more everyday, how many days will the tank-full petrol last?', '5', '6', '7', '8', '4', 'Total consumption is say N. So daily consumption \nis N/10. Now if daily increases by 25%, then totally\r\nits 1.25N. So, when you divide 10 by 1.25N, it will \nbe N/8. It will go for 8 days', 'UPSC Prelims 2013', '8', '19 Feb, 2018', 7),
(118, ' A person can walk a certain distance and \ndrive back in six hours. He can also walk both ways in 10 hours. How much time will he take to drive both ways?', 'Two hours\n', 'Two and a half hours\n', 'Five and a half hours\n', 'Four hours', '1', '2-way walk = 10 hrs, therefore 1-way walk = 5 hrs\n1-way walk + 1-way Drive = 6 hrs; therefore 1-way \ndrive = 6-5= 1 hr\nHence, 2-way drive = 2 hrs', 'UPSC Prelims 2013', '9', '19 Feb, 2018', 7),
(119, 'Four friends, A, B, C and D distribute some money among themselves in such a manner \nthat A gets one less than B, C gets 5 more than D, D gets 3 more than B. \nWho gets the smallest amount?', ' A', 'B', 'C\n', 'D', '1', 'S1 - A = B - 1\n\nS2 - C = D + 5\n\nS3 - D = B + 3\n\nSo, C > D > B > A', 'UPSC Prelims 2013', '40', '19 Feb, 2018', 6),
(120, 'Five cities P, Q, R, S and T are connected by different\nmodes of transport as follows:\nP and Q are connected by boat as well as rail.\nSand R are connected by bus and boat.\nQ and T are connected by air only.\nP and R are connected by boat only.\nT and R are connected by rail and bus.\nIf a person visits each of the places starting from P and gets back to P, which of the following places must he visit twice?', ' Q', 'R', 'S', 'T', '2', 'Because the node at R leads to S from where there \nis no other way. So, one has to return to R in any\r\npossible way', 'UPSC Prelims 2013', '42', '20 Feb, 2018', 7),
(121, ' Seven men, A, B, C, D, E, F and G are \nstanding in a queue in that order. Each one is wearing a cap of a different colour like violet, indigo, blue, green, yellow, orange and red. D is able to see in front of him green and blue, but not violet. E can see violet and yellow, but not red. G can see caps of all colours other than orange. If E is wearing an indigo coloured cap, then the colour of the cap worn by F is', 'Blue', 'Violet', 'Red', 'Orange', '3', 'From the data,\nA/B/C   - green/blue/yellow\nD - violet\nE - indigo\nG - orange', 'UPSC Prelims 2013', '60', '20 Feb, 2018', 8),
(122, ' There are some balls of red, green and yellow \ncolour lying on a table. There are as many red balls as there are yellow balls. There are twice as many yellow balls as there are green ones. The number of red balls', 'is equal to the sum of yellow and green balls.', 'is double the number of green balls.', 'is equal to yellow balls minus green balls.\n', 'cannot be ascertained.', '2', 'Simple arithmetic. R=Y= 2G', 'UPSC Prelims 2013', '61', '20 Feb, 2018', 6),
(123, 'A, B, C, D and E belong to five different cities \nP, Q, R, Sand T (not necessarily in that order). Each one of them comes from a different city. Further it is given that:\n1. B and C do not belong to Q.\n2. B and E do not belong to P and R.\n3. A and C do not belong to R, Sand T.\n4. D and E do not belong to Q and T.\nWhich one of the following statements is not \ncorrect?', ' C belongs to P', 'D belongs to R', 'A belongs to Q', ' B belongs to S', '4', 'From the data given,\nQ - A, P - C, R - D, S - E, T - B', 'UPSC Prelims 2013', '59', '20 Feb, 2018', 7),
(124, 'A is sister of B.  B is married to D.  B and D \nhave a daughter G.  How is G related to A?', ' Sister', 'Daughter', 'Niece\n', 'Cousin', '3', 'A sister of B.\nB - D\n   |\n   G\nObviously, G is niece of A\n', 'SSC CGL Tier I 2016', '10', '21 Feb, 2018', 6),
(125, 'Select the related number from the given \nalternatives.\n147:741 :: 869: ?', '896', '968', '689', '986', '2', 'Reverse of the number', 'SSC CGL Tier I 2016', '3', '21 Feb, 2018', 6),
(126, 'Select the related letters from the given \nalternatives.\nEGIK:FHJL :: MOQS: ?', 'LNOQ', 'NPRT', 'KMOQ       ', 'NRPT', '2', 'Consecutive letters forms the pattern', 'SSC CGL Tier I 2016', '2', '21 Feb, 2018', 6),
(127, 'Find the missing number in the following series\n43, 172, 86, 344, ?', '172', '258', '129', '430', '1', '43 x 4 = 172, 172 / 2 = 86, 86 x 4 = 344, \n344 / 2 = 172', 'SSC CGL Tier I 2016', '9', '21 Feb, 2018', 8),
(128, 'Anil is as much younger to Vivek as he is \nelder to Tarun.  If the total of the ages of Vivek and Tarun is 48 years, how old is Anil?', '26', '33', '24', '18', '3', 'Anil age - A, Vivek age - V, Tarun age - T\nA = V - A, A = T + A\n2A = V + T => 2A = 48 => A = 24\nTherefore, Anil age = 24', 'SSC CGL Tier I 2016', '11', '21 Feb, 2018', 7),
(129, 'From the given alternative words, select the \nword which cannot be formed using the letters of the given word : CHRONOLOGICAL', 'CALL', 'LOGIC', 'CALICO      ', 'ANALOGY', '4', 'No Explanation', 'SSC CGL Tier I 2016', '12', '22 Feb, 2018', 6),
(130, 'If HOUSE is written as FQSUC, then how can\nCHAIR be written in that code?', ' DIBJS', 'SBJID', 'SHBGD         ', 'AJYKP', '4', 'Odd positioned letters - 2 letters backward\nEven positioned letters - 2 letters forward', 'SSC CGL Tier I 2016', '13', '22 Feb, 2018', 6),
(131, 'Arrange the following words as per order in the\ndictionary.\n1) Organ               2) Origin  \n3) Orient               4) Organic\n5) Organise', ' 1,5,3,4,2', '1, 5, 4, 2, 3', '1, 4, 5, 3, 2', '1, 4, 5, 2, 3', '3', 'No Explanation', 'SSC CGL Tier I 2016', '7', '22 Feb, 2018', 6),
(132, 'Ramesh starts his journey by walking 2kms\ntowards north.  Then he takes a right turn and walks 1 km.  Again takes a right turn and walks 2km.   Now which direction is he facing?', ' East', 'West', 'South        ', 'North', '3', '1: Towards North\n2: Takes right -> West\n3: Takes right -.>South', 'SSC CGL Tier I 2016', '17', '22 Feb, 2018', 6),
(133, 'The average of 12 numbers is 9.  If each \nnumber is multiplied by 2 and then added to 3, the average of the new set of numbers is', '9', '18', '21', '27', '3', 'Similarly, the average is multiplied by2 and added\nto 3.\n=> 9 x 2 + 3 = 21', 'SSC CGL Tier I 2016', '64', '22 Feb, 2018', 7),
(134, 'Find the odd letters from the given alternatives', ' JKLM', 'NOPQ', 'RSTU  ', 'VWXZ', '4', 'It should be VWXY. Instead, it is VWXZ. \nSo, that\'s the answer', 'SSC CGL Tier I 2016', '5', '23 Feb, 2018', 6),
(135, 'If P denotes division, Q dennotes multiplication,\nR denotes addition and S denotes subtraction, then what is the value of 18Q12P4R5S6 ? ', '64', '53', '81', '24', '2', '18 x 12 = 216 / 4 = 54 + 5 = 59 - 6 = 53', 'SSC CGL Tier I 2016', '14', '23 Feb, 2018', 7),
(136, 'If Usha is taller than Nisha; Nisha is taller than\nAsha; Alka is taller than Usha; Harsha is shorter than Asha;  then who among them is the tallest ?', ' Usha', 'Alka', 'Nisha  ', 'Asha', '2', 'Order based on heights from tall to short:\nAlka -> usha -> Nisha -> Asha -> Harsha', 'SSC CGL Tier I 2016\n(02-09-2016) shift I', '11', '23 Feb, 2018', 6),
(137, 'A and B are standing at a place \"P\".  They\nstart moving in the opposite directions at the speed of 5kmph and 4kmph respectively.  What will be the distance between them after\n3 hours?', ' 3kms', '21 kms', '18 kms  ', '27 kms', '4', 'A, per hour = 5 km => 3 hours = 15 kms\nB, per hour = 4 km => 3 hours = 12 kms\nTherefore, 15 + 12 = 27 kms is the distance\nbetween A and B', 'SSC CGL Tier I 2016\n(02-09-2016) shift I', '10', '23 Feb, 2018', 7),
(138, 'Arrange, the following words as per order in the dictionary and then choose the one which comes last.', ' Qualify', 'Quarter', 'Quarrel   ', 'Quaver', '4', 'No Explanation', 'SSC CGL Tier I 2016\n(02-09-2016) shift I', '7', '23 Feb, 2018', 6),
(139, 'A series is given, With one term missing. \nChoose the correct alternative from the given ones that will complete the series. \n2,7, 14, 23, 34,? ', '47', '39', '42', '46', '1', 'Pattern is formed by adding the consecutive\nodd numbers to each term', 'SSC CGL Tier I 2016\n(02-09-2016) shift I', '9', '27 Feb, 2018', 7),
(140, 'If in a code GONE is written as ILPB then how\nmay CRIB be written in that code? ', 'EUKY', 'EKUY', 'EYUK ', 'EOKY', '4', 'G->H ->I       =>      C->D->E\nO->N->M->L =>      R->Q->P->O\nN->O->P       =>      I->J->K\nE->D->C->B  =>     B->A->Z->Y\nILPB              =>     EOKY', 'SSC CGL Tier I 2016\n(02-09-2016) shift I', '13', '27 Feb, 2018', 6),
(141, '\nSelect the related letters from the given alternatives.\nAKU:?: :CMW : DNX', 'BGL', 'BLQ', 'BGQ', 'BLV', '4', 'C-D, M-N, W-X Similarly,A-B, K-L, U-V', 'SSC CGL Tier I 2016\n(02-09-2016) shift I', '2', '', 6),
(142, 'Select the related number from the given alternatives.\n5:100::7:?\n', '49', '196', '91', '135', '2', '5*5*4 = 100\nSimilarly,\n7*7*4=196', 'SSC CGL Tier I 2016\n(02-09-2016) shift I', '3', '27 Feb, 2018', 7),
(143, 'From the given alternative  words, select the \nword which cannot be formed using the letters of the given word :\nDHARAMSALA', 'MASALA', 'ARAMANA', 'RAMA', 'SAHARA', '2', 'No Explanation', 'SSC CGL Tier I 2016\n(02-09-2016) shift I', '12', '27 Feb, 2018', 6),
(144, '20, ?, 29, 40, 58, 85', '23', '25', '27', '31', '1', 'The differences of the differences between the\nnumbers are odd number sequence from 3\n(3,5,7,9).\n20,          23,         29,         40,         58,          85\n        3,            6,           11,         18,           27\n                3,           5,            7,            9', 'SBI PO, 2016', '28', '6 March, 2018', 8),
(145, 'Statements :\r\nR ? O < A ? M; L=D ? A\r\nConclusions :\r\nI. R < L\r\nII.D > O', 'If only conclusion I is true.', 'If either conclusion I or II is true', 'If only conclusion II is true.', ' If both conclusions \nI and II are true.', '4', 'No Explanation', 'SBI PO, 2016', 'Reasoning\n4', '6 March, 2018', 7),
(146, 'D is the mother of S. S is the sister of T. T is the mother \nof R. R is the only son of J. J is the father of U. U is married to K. How is J related to D ?', ' Brother-in-law', 'Son-in-law', 'Grandson\n\n', 'Son', '2', 'No Explanation', 'SBI PO, 2016', 'Reasoning \n12', '6 March, 2018', 7),
(147, 'D is the mother of S. S is the sister of T. T is the mother \nof R. R is the only son of J. J is the father of U. U is married to K. How is S related to R ?', 'Sister-in-law', 'Mother-in-law', 'Grandmother\n', ' Aunt', '4', 'No Explanation', 'SBI PO, 2016', 'Reasoning \n14', '6 March, 2018', 7),
(148, 'D is the mother of S. S is the sister of T. T is the mother \nof R. R is the only son of J. J is the father of U. U is married to K. If R is the father of X, then how is K related to X ?', 'Father', 'Aunt', 'Uncle\n', ' Father-in-law', '3', 'No Explanation', 'SBI PO, 2016', 'Reasoning\n13', '6 March, 2018', 7),
(149, 'Point J is 20m to the north of Point G. Point G is 10m to the west of Point K. Point K is 15m to the south of Point L. Ashish is standing at Point T which is 30m to the east of Point L. He starts walking towards south and walks for 35m. He takes a right turn and stops at Point M after walking for 40m. How far and in which direction is Point G with respect to Point M ?', '15m towards South', '15m towards West', '20m towards South\n', '20m towards North', '4', 'No Explanation', 'SBI PO, 2016', 'Reasoning\n25', '7 March, 2018', 8),
(150, 'Point J is 20m to the north of Point G. Point G is 10m to \nthe west of Point K. Point K is 15m to the south of Point L. Ashish is standing at Point T which is 30m to the east of Point L. He starts walking towards south and walks for 35m. He takes a right turn and stops at Point M after walking for 40m. If Ashish walks for 10m towards north from his final position to reach Point D, how much distance will he have to cover in order to reach Point J ?', '10 m', '35 m', '25 m\n', '20m', '3', 'No Explanation', 'SBI PO, 2017', 'Reasoning\n26', '7 March, 2018', 8),
(151, 'Each of the six friends, I, J, K, L, M and N working in an office handles different number of projects in a month. I handles the second lowest number of projects. K handles more projects than L and M but less than J. J did not handle the maximum number of projects. M did not handle the minimum number of projects. The one who handle the third highest number of projects handled 31 projects. L handled 12 projects. How many projects did j possibly handle', '28', '10', '36', '9', '3', 'N > J > K > M > I > L\n|                        |        \n\n12                  31', 'SBI PO, 2018', 'Reasoning\n27', '7 March, 2018', 8),
(152, 'Each of the six friends, I, J, K, L, M and N working in an \noffice handles different number of projects in a month. I handles the second lowest number of projects. K handles more projects than L and M but less than J. J did not handle the maximum number of projects. M did not handle the minimum number of projects. The one who handle the third highest number of projects handled 31 projects. L handled 12 projects. Which of the following is true regarding the number of projects handled by N ?', '22', '14', '19', '9', '2', 'N > J > K > M > I > L\n             |                  |\n            31               12', 'SBI PO, 2019', 'Reasoning\n28', '7 March, 2018', 8),
(153, 'Each of the six friends, I, J, K, L, M and N working in an \noffice handles different number of projects in a month. I handles the second lowest number of projects. K handles more projects than L and M but less than J. J did not handle the maximum number of projects. M did not handle the minimum number of projects. The one who handle the third highest number of projects handled 31 projects. L handled 12 projects. Which of the following is true regarding the number of projects handled by N ?', ' No one handles more projects than N.', 'Only J handled more number of projects \nthan N.', 'N possibly handled 24 projects.\n\n', ' N handled more\n number of \nprojects than \nonly three. people.', '1', 'N > J > K > M > I > L\n             |                  |\n            31               12', 'SBI PO, 2020', 'Reasoning\n29', '7 March, 2018', 8),
(154, ' ???? of ???æ of 1240=? ', '220', '465', '410', '800', '2', '1/2(3/4(1240)) = 3720/8 = 465', 'RBI Assistant\nPaper - 2014', '', '12 March, 2018', 8),
(155, 'P and Q are sisters. R and S are brothers. P\'s daughter is\nR\'s sister. What is Q\'s relationto S? ', 'Mother .', 'Grandmother', 'Sister', 'Aunt', '4', 'P, Q => Sisters\nR, S => Brothers\nR, S => Sons of P\nTherefore, Q is aunt to S', 'SSC CGL Tier I\n28-08-16 (Shift I)', '10', '12 March, 2018', 6),
(156, 'P started walking from North to South. She turned right at\r\nright angle and then again right at right angle. In which\r\ndirection was she ultimately walking?', 'North \n', 'East', 'South ', 'West', '1', 'No Explanation', 'SSC CGL Tier I\n28-08-16 (Shift I)', '17', '12 March, 2018', 6),
(157, 'Find the odd letters from the given alternatives.', 'AEIM ', 'BFJN', 'CGKO ', 'FDKN', '4', 'Consecutive letters of the first option is given\nin the succeeding options', 'SSC CGL Tier I\n28-08-16 (Shift I)', '5', '12 March, 2018', 6),
(158, 'A*B means multiply A by B; A@B means divide A by B, \nA? B means add B to A and A=B means subtract B from \nA.  Then find the value of 10* 10 = 5\"\' 10? 50@10', '100', '45', '1000', '55', '4', 'IO *10 = 5 * 10? 50@ 10\r\n=> 10 X 10 - 5 X 10 + 50 + 10\r\n=> 10 X 10- 5 X IQ+ 5\r\n=>100-50+5 = 55', 'SSC CGL Tier I\n28-08-16 (Shift I)', '14', '12 March, 2018', 7),
(159, 'A man was 32 years of age when he had his first son. His\nwife was 35 years of age when his son attained the age \nof 7 years. The difference between the age of the father \nand the mother is', '7 years', '3years', '5 years ', '4 years', '4', 'When the son was born,\nage of father = 32 years\nage of mother = 35 - 7 = 28 years\nDifference of their ages = 32 - 28 = 4 years', 'SSC CGL Tier I\n28-08-16 (Shift I)', '11', '12 March, 2018', 7),
(160, 'Find the odd word from the given alternatives.', 'Bigger', 'Faster', 'Greater', 'Taller', '2', 'Except faster, everything denotes shape and size', 'SSC CGL Tier I\n28-08-16 (Shift I)', '4', '12 March, 2018', 7),
(161, 'Select the related letters from the given alternatives.\r\nPZQW: NXOU :: FISK:?', 'EFPJ', 'FERI', 'DGQI ', 'HKVM', '3', 'No Explanation', 'SSC CGL Tier I\n28-08-16 (Shift I)', '1', '12 March, 2018', 6),
(162, 'X is the husband of Y. W is the daughter of X. Z is the\nhusband ofW. N is the daughter of Z. What is the \nrelationship of N to Y ?', 'Cousin', 'Niece', 'Daughter', 'Granddaughter', '4', 'Wis the daughter ofX andbY. W is the wife of Z.\r\nN is the daughter of W and Z.\r\nTherefore, N is the granddaughter of Y. ', 'SSC CGL Tier I\n30-08-16 (Shift I)', '11', '13 March, 2018', 7),
(163, 'A series is given, with one term missilng, Choose the\r\ncorrect alternative from the given ones that will complete\r\nthe series: 463,452,439,424,?', '407', '413', '419', '411', '1', '463 - 11 = 452 \n452-13 = 439\n439-15 = 424\n424 - 17 = 407', 'SSC CGL Tier I\n30-08-16 (Shift I)', '9', '13 March, 2018', 7),
(164, 'How many meaningful English words can be formed with\nthe letters PCYO using all the letters, but each letter only\nonce in each word?', 'None', 'One', 'Two', 'Three', '2', 'COPY is the only word that can be made out of\nPCYO. Therefore, answer is one', 'RBI Assistant\nPaper - 2012', '1', '14 March, 2018', 6),
(165, 'Each vowel of the word SAVOURY is changed to the next\nletter in the English alphabetical series and each \nconsonant is changed to the previous letter in the English\nalphabetical series.  If the new alphabets thus formed \nare arranged in alphabetical order (from left to right), \nwhich of the following will be fifth from right? ', 'U', 'R', 'Q', 'P', 'Q', 'SAVOURY => RBUPVQX\n=>When arranged in alphabetical order \n                   = BPQRUVX\nTherefore, the fifth letter from right is Q', 'RBI Assistant\nPaper - 2012', '8', '14 March, 2018', 7),
(166, 'How many such pair of letters are there in the word\nPACKETS, each of which has as many letters between\nthem in the word (in both forward and backward \ndirections) as they have between them in the English\nalphabetical series ? ', '0', 'Two', 'Three', 'Four', '2', 'S->T,\nC->D->E\nSo, two such combination', 'RBI Assistant\nPaper - 2012', '9', '14 March, 2018', 8),
(167, 'In a certain code,\n\'time and money\' is written as \'ma jo ki\',\n\'manage time well\' is written as \'pa ru jo\',\n\'earn more money\'  is written as \'zi ha ma\' and\n\'earn well enough\' is written as \'si ru ha\'\nWhat is the code for \'earn\' ?', 'si', 'ru', 'ha', 'ma', '3', 'earn more money\'  =>  \'zi ha ma\'\n\'earn well enough\' =>  \'si ru ha\'\n\nTherefore, earn => ha', 'RBI Assistant\nPaper - 2012', '21', '14 March, 2018', 6),
(168, 'In a certain code,\n\'time and money\' is written as \'ma jo ki\',\n\'manage time well\' is written as \'pa ru jo\',\n\'earn more money\'  is written as \'zi ha ma\' and\n\'earn well enough\' is written as \'si ru ha\'\nWhat is the code for \'manage\' ?', 'ru', 'pa', 'jo', 'ha', '2', 'time and money\' => \'ma jo ki\',\n\'manage time well\' => \'pa ru jo\'\nTherefore, time => jo\n\n\'earn well enough\' => \'si ru ha\'\n\'manage time well\' => \'pa ru jo\'\nTherefore, well => ru\n\n\'manage time well\' => \'pa ru jo\'\nTherefore, manage is coded as \"pa\"', 'RBI Assistant\nPaper - 2012', '23', '14 March, 2018', 6),
(169, 'In a certain code,\n\'time and money\' is written as \'ma jo ki\',\n\'manage time well\' is written as \'pa ru jo\',\n\'earn more money\'  is written as \'zi ha ma\' and\n\'earn well enough\' is written as \'si ru ha\'\nWhich of the following represent \"money matters\" ?', 'ki to', 'ma pa', 'fi ma', 'ha ma', '3', 'time and money\' => \'ma jo ki\',\n\'earn more money\'  => \'zi ha ma\'\nTherefore, money => ma\n\n\"matters\" never appear in the question; Same way, \n\"ha\", \"pa\" appears in the question. Therefore, \noptions b,d cant be the answer.  Option a cant be\nthe answer as it dont even have \"ma\" => money.\nTherefore the answer is fi ma', 'RBI Assistant\nPaper - 2012', '24', '14 March, 2018', 7),
(170, 'In a certain code,\n\'time and money\' is written as \'ma jo ki\',\n\'manage time well\' is written as \'pa ru jo\',\n\'earn more money\'  is written as \'zi ha ma\' and\n\'earn well enough\' is written as \'si ru ha\'\nWhich of the following may represent \"good enough\" ?', 'ru si', 'da ha', 'si pa', 'si da', '4', 'enough => \"si\"\nTherefore, option b is not the answer\n\npa => manage\nru => well\nTherefore, answer is si da', 'RBI Assistant\nPaper - 2012', '26', '14 March, 2018', 7),
(171, 'Eight persons P,Q,R,S,T,U,V and W are sitting around a \ncircular table facing the centre but not necessarily in the \nsame order. Also,\n1. Q and S are immediate neighbours of R.  \n2. U sits third to the left of P, P is an immediate neighbour \nof Q  \n3. T sits third to the right of W.  \nThen what is the position of W with respect to Q.? ', 'Third to the left', 'Third to the right', 'Second to the left', 'Second to the right', '1', 'As per the given data,\n\nP-Q-R-S-W-U-V-T', 'RBI Assistant\nPaper - 2014', '', '15 March, 2018', 8),
(172, 'How many meaningful English words can be formed with \nthe letters T, D, E, I using all the letters, but each letter \nonly once in each word? ', 'One', 'Two', 'Three', 'More than three', '4', 'Diet, Tide, Tied, Edit etc', 'RBI Assistant\nPaper - 2014', '', '15 March, 2018', 7),
(173, 'M L 5 # U 5 Q $ 5 & O 8 U F ! 7 C 9 D N 8 A % P O G N L \n3& P M G ! # $ A 9 H P % 9 $ A G D # W \nIn the above sequence, how many symbols are there \nwhich do have a number just before it and a vowel just \nafter it? \n ', 'One', 'Two', 'None', 'Three', '4', '5 # U, 5 & O, 9 $ A\nTherefore, three such combinations', 'RBI Assistant\nPaper - 2014', '', '15 March, 2018', 6),
(174, 'In the word MORNING, how many characters are there \nwhich have same gap with their adjacent letter as they have in alphabetical order in English? ', 'One', 'Two', 'Three', 'None', '1', 'G and I happens to be the only pair appearing\nwith same difference as in alphabetical series', 'RBI Assistant\nPaper - 2014', '', '15 March, 2018', 6),
(175, '1. If A + B means A is the father of B  \n2. A x B means A is the wife of B  \n3. A - B means A is the son of B...then  \n\nIf M x N - O is true, then which of the following is \ndefinitely true? ', 'O is wife of N', 'O is the father of M', 'M is the daughter of N', 'None of these', '4', 'M is the wife of N; i.e. N is the husband of M\nO is the parent of N; N is the son of O\n\nTherefore, none of the option is true', 'RBI Assistant\nPaper - 2014', '', '15 March, 2018', 7),
(176, 'What will come in place of question mark(?) in the \nfollowing number series:\n 45, 38, 31, 24, 17,?, 3 ', '33', '45', '15', '10', '4', 'Pattern formed by subtracting 7 from each term', 'RBI Assistant\nPaper - 2014', '', '15 March, 2018', 7),
(177, ' What will come in place of question mark(?) in the \nfollowing number series: \n5,15,35,75,155,? ', '295', '315', '275', '305', '2', 'Difference of two consecutive terms is multiplied \nby 2 and added to form the next term.', 'RBI Assistant\nPaper - 2014', '', '15 March, 2018', 8),
(178, ' Find the average of the following set of scores: \n214, 351, 109, 333, 752, 614, 456, 547 ? ', '482', '428', '424', 'None of the above', '4', 'The average is 422.  As the option is not available, \nnone of the above is the answer', 'RBI Assistant\nPaper - 2014', '', '15 March, 2018', 7),
(179, 'The average of four consecutive odd numbers A, B, C \nand D is 54. What is the product of A and C? ', '2905', '2805', '2703', '2404', '2', 'Let the four consecutive odd numbers A, B, C, D\nbe x, x+2, x+4, x+6\nx + x + 2 + x + 4 + x + 6 / 4 = 54\nTherefore, x = 51 => i.e A = 51\nThus, C = 54\nProduct of A and C = 51 x 54 = 2805', 'RBI Assistant\nPaper - 2014', '', '15 March, 2018', 8),
(180, '283.56+142.04+661.78=? ', '1080.28', '1087.28', '1080.38', 'None of the above', '4', '1087.38 is the total. As it is not available, none of\nthe above is the right answer', 'RBI Assistant\nPaper - 2014', '', '15 March, 2018', 7);

-- --------------------------------------------------------

--
-- Table structure for table `change_password_history`
--

CREATE TABLE `change_password_history` (
  `id` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `randid` int(11) NOT NULL,
  `requestdate` datetime NOT NULL,
  `updatedate` datetime NOT NULL,
  `newpwd` varchar(255) NOT NULL,
  `status` int(11) NOT NULL,
  `device` enum('WEB','APP') NOT NULL DEFAULT 'WEB'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `city`
--

CREATE TABLE `city` (
  `id` int(11) NOT NULL,
  `stateid` int(11) NOT NULL,
  `city_name` varchar(110) NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `city`
--

INSERT INTO `city` (`id`, `stateid`, `city_name`, `status`) VALUES
(1, 1, 'North Andaman', 1),
(2, 1, 'South Andaman', 1),
(3, 1, 'Nicobar', 1),
(4, 2, 'Adilabad', 1),
(5, 2, 'Anantapur', 1),
(6, 2, 'Chittoor', 1),
(7, 2, 'East Godavari', 1),
(8, 2, 'Guntur', 1),
(9, 2, 'Hyderabad', 1),
(10, 2, 'Karimnagar', 1),
(11, 2, 'Khammam', 1),
(12, 2, 'Krishna', 1),
(13, 2, 'Kurnool', 1),
(14, 2, 'Mahbubnagar', 1),
(15, 2, 'Medak', 1),
(16, 2, 'Nalgonda', 1),
(17, 2, 'Nizamabad', 1),
(18, 2, 'Prakasam', 1),
(19, 2, 'Ranga Reddy', 1),
(20, 2, 'Srikakulam', 1),
(21, 2, 'Sri Potti Sri Ramulu Nellore', 1),
(22, 2, 'Vishakhapatnam', 1),
(23, 2, 'Vizianagaram', 1),
(24, 2, 'Warangal', 1),
(25, 2, 'West Godavari', 1),
(26, 2, 'Cudappah', 1),
(27, 3, 'Anjaw', 1),
(28, 3, 'Changlang', 1),
(29, 3, 'East Siang', 1),
(30, 3, 'East Kameng', 1),
(31, 3, 'Kurung Kumey', 1),
(32, 3, 'Lohit', 1),
(33, 3, 'Lower Dibang Valley', 1),
(34, 3, 'Lower Subansiri', 1),
(35, 3, 'Papum Pare', 1),
(36, 3, 'Tawang', 1),
(37, 3, 'Tirap', 1),
(38, 3, 'Dibang Valley', 1),
(39, 3, 'Upper Siang', 1),
(40, 3, 'Upper Subansiri', 1),
(41, 3, 'West Kameng', 1),
(42, 3, 'West Siang', 1),
(43, 4, 'Baksa', 1),
(44, 4, 'Barpeta', 1),
(45, 4, 'Bongaigaon', 1),
(46, 4, 'Cachar', 1),
(47, 4, 'Chirang', 1),
(48, 4, 'Darrang', 1),
(49, 4, 'Dhemaji', 1),
(50, 4, 'Dima Hasao', 1),
(51, 4, 'Dhubri', 1),
(52, 4, 'Dibrugarh', 1),
(53, 4, 'Goalpara', 1),
(54, 4, 'Golaghat', 1),
(55, 4, 'Hailakandi', 1),
(56, 4, 'Jorhat', 1),
(57, 4, 'Kamrup', 1),
(58, 4, 'Kamrup Metropolitan', 1),
(59, 4, 'Karbi Anglong', 1),
(60, 4, 'Karimganj', 1),
(61, 4, 'Kokrajhar', 1),
(62, 4, 'Lakhimpur', 1),
(63, 4, 'Morigaon', 1),
(64, 4, 'Nagaon', 1),
(65, 4, 'Nalbari', 1),
(66, 4, 'Sivasagar', 1),
(67, 4, 'Sonitpur', 1),
(68, 4, 'Tinsukia', 1),
(69, 4, 'Udalguri', 1),
(70, 5, 'Araria', 1),
(71, 5, 'Arwal', 1),
(72, 5, 'Aurangabad', 1),
(73, 5, 'Banka', 1),
(74, 5, 'Begusarai', 1),
(75, 5, 'Bhagalpur', 1),
(76, 5, 'Bhojpur', 1),
(77, 5, 'Buxar', 1),
(78, 5, 'Darbhanga', 1),
(79, 5, 'East Champaran', 1),
(80, 5, 'Gaya', 1),
(81, 5, 'Gopalganj', 1),
(82, 5, 'Jamui', 1),
(83, 5, 'Jehanabad', 1),
(84, 5, 'Kaimur', 1),
(85, 5, 'Katihar', 1),
(86, 5, 'Khagaria', 1),
(87, 5, 'Kishanganj', 1),
(88, 5, 'Lakhisarai', 1),
(89, 5, 'Madhepura', 1),
(90, 5, 'Madhubani', 1),
(91, 5, 'Munger', 1),
(92, 5, 'Muzaffarpur', 1),
(93, 5, 'Nalanda', 1),
(94, 5, 'Nawada', 1),
(95, 5, 'Patna', 1),
(96, 5, 'Purnia', 1),
(97, 5, 'Rohtas', 1),
(98, 5, 'Saharsa', 1),
(99, 5, 'Samastipur', 1),
(100, 5, 'Saran', 1),
(101, 5, 'Sheikhpura', 1),
(102, 5, 'Sheohar', 1),
(103, 5, 'Sitamarhi', 1),
(104, 5, 'Siwan', 1),
(105, 5, 'Supaul', 1),
(106, 6, 'Chandigarh', 1),
(107, 7, 'Bastar', 1),
(108, 7, 'Bijapur', 1),
(109, 7, 'Bilaspur', 1),
(110, 7, 'Dantewada', 1),
(111, 7, 'Dhamtari', 1),
(112, 7, 'Durg', 1),
(113, 7, 'Jashpur', 1),
(114, 7, 'Janjgir-Champa', 1),
(115, 7, 'Korba', 1),
(116, 7, 'Koriya', 1),
(117, 7, 'Kanker', 1),
(118, 7, 'Kabirdham (formerly Kawardha)', 1),
(119, 7, 'Mahasamund', 1),
(120, 7, 'Narayanpur', 1),
(121, 7, 'Raigarh', 1),
(122, 7, 'Rajnandgaon', 1),
(123, 7, 'Raipur', 1),
(124, 7, 'Surguja', 1),
(125, 8, 'Dadra and Nagar Haveli', 1),
(126, 9, 'Daman', 1),
(127, 9, 'Diu', 1),
(128, 10, 'Central Delhi', 1),
(129, 10, 'East Delhi', 1),
(130, 10, 'New Delhi', 1),
(131, 10, 'North Delhi', 1),
(132, 10, 'North East Delhi', 1),
(133, 10, 'North West Delhi', 1),
(134, 10, 'South Delhi', 1),
(135, 10, 'South West Delhi', 1),
(136, 10, 'West Delhi', 1),
(137, 11, 'North Goa', 1),
(138, 11, 'South Goa', 1),
(139, 12, 'Ahmedabad', 1),
(140, 12, 'Amreli district', 1),
(141, 12, 'Anand', 1),
(142, 12, 'Banaskantha', 1),
(143, 12, 'Bharuch', 1),
(144, 12, 'Bhavnagar', 1),
(145, 12, 'Dahod', 1),
(146, 12, 'The Dangs', 1),
(147, 12, 'Gandhinagar', 1),
(148, 12, 'Jamnagar', 1),
(149, 12, 'Junagadh', 1),
(150, 12, 'Kutch', 1),
(151, 12, 'Kheda', 1),
(152, 12, 'Mehsana', 1),
(153, 12, 'Narmada', 1),
(154, 12, 'Navsari', 1),
(155, 12, 'Patan', 1),
(156, 12, 'Panchmahal', 1),
(157, 12, 'Porbandar', 1),
(158, 12, 'Rajkot', 1),
(159, 12, 'Sabarkantha', 1),
(160, 12, 'Surendranagar', 1),
(161, 12, 'Surat', 1),
(162, 12, 'Tapi', 1),
(163, 12, 'Vadodara', 1),
(164, 12, 'Valsad', 1),
(165, 13, 'Ambala', 1),
(166, 13, 'Bhiwani', 1),
(167, 13, 'Faridabad', 1),
(168, 13, 'Fatehabad', 1),
(169, 13, 'Gurgaon', 1),
(170, 13, 'Hissar', 1),
(171, 13, 'Jhajjar', 1),
(172, 13, 'Jind', 1),
(173, 13, 'Karnal', 1),
(174, 13, 'Kaithal', 1),
(175, 13, 'Kurukshetra', 1),
(176, 13, 'Mahendragarh', 1),
(177, 13, 'Mewat', 1),
(178, 13, 'Palwal', 1),
(179, 13, 'Panchkula', 1),
(180, 13, 'Panipat', 1),
(181, 13, 'Rewari', 1),
(182, 13, 'Rohtak', 1),
(183, 13, 'Sirsa', 1),
(184, 13, 'Sonipat', 1),
(185, 13, 'Yamuna Nagar', 1),
(186, 14, 'Bilaspur', 1),
(187, 14, 'Chamba', 1),
(188, 14, 'Hamirpur', 1),
(189, 14, 'Kangra', 1),
(190, 14, 'Kinnaur', 1),
(191, 14, 'Kullu', 1),
(192, 14, 'Lahaul and Spiti', 1),
(193, 14, 'Mandi', 1),
(194, 14, 'Shimla', 1),
(195, 14, 'Sirmaur', 1),
(196, 14, 'Solan', 1),
(197, 14, 'Una', 1),
(198, 15, 'Anantnag', 1),
(199, 15, 'Badgam', 1),
(200, 15, 'Bandipora', 1),
(201, 15, 'Baramulla', 1),
(202, 15, 'Doda', 1),
(203, 15, 'Ganderbal', 1),
(204, 15, 'Jammu', 1),
(205, 15, 'Kargil', 1),
(206, 15, 'Kathua', 1),
(207, 15, 'Kishtwar', 1),
(208, 15, 'Kupwara', 1),
(209, 15, 'Kulgam', 1),
(210, 15, 'Leh', 1),
(211, 15, 'Poonch', 1),
(212, 15, 'Pulwama', 1),
(213, 15, 'Rajouri', 1),
(214, 15, 'Ramban', 1),
(215, 15, 'Reasi', 1),
(216, 15, 'Samba', 1),
(217, 15, 'Shopian', 1),
(218, 15, 'Srinagar', 1),
(219, 15, 'Udhampur', 1),
(220, 16, 'Bokaro', 1),
(221, 16, 'Chatra', 1),
(222, 16, 'Deoghar', 1),
(223, 16, 'Dhanbad', 1),
(224, 16, 'Dumka', 1),
(225, 16, 'East Singhbhum', 1),
(226, 16, 'Garhwa', 1),
(227, 16, 'Giridih', 1),
(228, 16, 'Godda', 1),
(229, 16, 'Gumla', 1),
(230, 16, 'Hazaribag', 1),
(231, 16, 'Jamtara', 1),
(232, 16, 'Khunti', 1),
(233, 16, 'Koderma', 1),
(234, 16, 'Latehar', 1),
(235, 16, 'Lohardaga', 1),
(236, 16, 'Pakur', 1),
(237, 16, 'Palamu', 1),
(238, 16, 'Ramgarh', 1),
(239, 16, 'Ranchi', 1),
(240, 16, 'Sahibganj', 1),
(241, 16, 'Seraikela Kharsawan', 1),
(242, 16, 'Simdega', 1),
(243, 16, 'West Singhbhum', 1),
(244, 17, 'Bagalkot', 1),
(245, 17, 'Bangalore Rural', 1),
(246, 17, 'Bangalore Urban', 1),
(247, 17, 'Belgaum', 1),
(248, 17, 'Bellary', 1),
(249, 17, 'Bidar', 1),
(250, 17, 'Bijapur', 1),
(251, 17, 'Chamarajnagar', 1),
(252, 17, 'Chikkamagaluru', 1),
(253, 17, 'Chikkaballapur', 1),
(254, 17, 'Chitradurga', 1),
(255, 17, 'Davanagere', 1),
(256, 17, 'Dharwad', 1),
(257, 17, 'Dakshina Kannada', 1),
(258, 17, 'Gadag', 1),
(259, 17, 'Gulbarga', 1),
(260, 17, 'Hassan', 1),
(261, 17, 'Haveri district', 1),
(262, 17, 'Kodagu', 1),
(263, 17, 'Kolar', 1),
(264, 17, 'Koppal', 1),
(265, 17, 'Mandya', 1),
(266, 17, 'Mysore', 1),
(267, 17, 'Raichur', 1),
(268, 17, 'Shimoga', 1),
(269, 17, 'Tumkur', 1),
(270, 17, 'Udupi', 1),
(271, 17, 'Uttara Kannada', 1),
(272, 17, 'Ramanagara', 1),
(273, 17, 'Yadgir', 1),
(274, 18, 'Alappuzha', 1),
(275, 18, 'Ernakulam', 1),
(276, 18, 'Idukki', 1),
(277, 18, 'Kannur', 1),
(278, 18, 'Kasaragod', 1),
(279, 18, 'Kollam', 1),
(280, 18, 'Kottayam', 1),
(281, 18, 'Kozhikode', 1),
(282, 18, 'Malappuram', 1),
(283, 18, 'Palakkad', 1),
(284, 18, 'Pathanamthitta', 1),
(285, 18, 'Thrissur', 1),
(286, 18, 'Thiruvananthapuram', 1),
(287, 18, 'Wayanad', 1),
(288, 19, 'Lakshadweep', 1),
(289, 20, 'Agar', 1),
(290, 20, 'Alirajpur', 1),
(291, 20, 'Anuppur', 1),
(292, 20, 'Ashok Nagar', 1),
(293, 20, 'Balaghat', 1),
(294, 20, 'Barwani', 1),
(295, 20, 'Betul', 1),
(296, 20, 'Bhind', 1),
(297, 20, 'Bhopal', 1),
(298, 20, 'Burhanpur', 1),
(299, 20, 'Chhatarpur', 1),
(300, 20, 'Chhindwara', 1),
(301, 20, 'Damoh', 1),
(302, 20, 'Datia', 1),
(303, 20, 'Dewas', 1),
(304, 20, 'Dhar', 1),
(305, 20, 'Dindori', 1),
(306, 20, 'Guna', 1),
(307, 20, 'Gwalior', 1),
(308, 20, 'Harda', 1),
(309, 20, 'Hoshangabad', 1),
(310, 20, 'Indore', 1),
(311, 20, 'Jabalpur', 1),
(312, 20, 'Jhabua', 1),
(313, 20, 'Katni', 1),
(314, 20, 'Khandwa (East Nimar)', 1),
(315, 20, 'Khargone (West Nimar)', 1),
(316, 20, 'Mandla', 1),
(317, 20, 'Mandsaur', 1),
(318, 20, 'Morena', 1),
(319, 20, 'Narsinghpur', 1),
(320, 20, 'Neemuch', 1),
(321, 20, 'Panna', 1),
(322, 20, 'Raisen', 1),
(323, 20, 'Rajgarh', 1),
(324, 20, 'Ratlam', 1),
(325, 20, 'Rewa', 1),
(326, 20, 'Sagar', 1),
(327, 20, 'Satna', 1),
(328, 20, 'Sehore', 1),
(329, 20, 'Seoni', 1),
(330, 20, 'Shahdol', 1),
(331, 20, 'Shajapur', 1),
(332, 20, 'Sheopur', 1),
(333, 20, 'Shivpuri', 1),
(334, 20, 'Sidhi', 1),
(335, 20, 'Singrauli', 1),
(336, 20, 'Tikamgarh', 1),
(337, 20, 'Ujjain', 1),
(338, 20, 'Umaria', 1),
(339, 20, 'Vidisha', 1),
(340, 21, 'Ahmednagar', 1),
(341, 21, 'Akola', 1),
(342, 21, 'Amravati', 1),
(343, 21, 'Aurangabad', 1),
(344, 21, 'Beed', 1),
(345, 21, 'Bhandara', 1),
(346, 21, 'Buldhana', 1),
(347, 21, 'Chandrapur', 1),
(348, 21, 'Dhule', 1),
(349, 21, 'Gadchiroli', 1),
(350, 21, 'Gondia', 1),
(351, 21, 'Hingoli', 1),
(352, 21, 'Jalgaon', 1),
(353, 21, 'Jalna', 1),
(354, 21, 'Kolhapur', 1),
(355, 21, 'Latur', 1),
(356, 21, 'Mumbai City', 1),
(357, 21, 'Mumbai suburban', 1),
(358, 21, 'Nanded', 1),
(359, 21, 'Nandurbar', 1),
(360, 21, 'Nagpur', 1),
(361, 21, 'Nashik', 1),
(362, 21, 'Osmanabad', 1),
(363, 21, 'Parbhani', 1),
(364, 21, 'Pune', 1),
(365, 21, 'Raigad', 1),
(366, 21, 'Ratnagiri', 1),
(367, 21, 'Sangli', 1),
(368, 21, 'Satara', 1),
(369, 21, 'Sindhudurg', 1),
(370, 21, 'Solapur', 1),
(371, 21, 'Thane', 1),
(372, 21, 'Wardha', 1),
(373, 21, 'Washim', 1),
(374, 21, 'Yavatmal', 1),
(375, 22, 'Bishnupur', 1),
(376, 22, 'Churachandpur', 1),
(377, 22, 'Chandel', 1),
(378, 22, 'Imphal East', 1),
(379, 22, 'Senapati', 1),
(380, 22, 'Tamenglong', 1),
(381, 22, 'Thoubal', 1),
(382, 22, 'Ukhrul', 1),
(383, 22, 'Imphal West', 1),
(384, 23, 'East Garo Hills', 1),
(385, 23, 'East Khasi Hills', 1),
(386, 23, 'Jaintia Hills', 1),
(387, 23, 'Ri Bhoi', 1),
(388, 23, 'South Garo Hills', 1),
(389, 23, 'West Garo Hills', 1),
(390, 23, 'West Khasi Hills', 1),
(391, 24, 'Aizawl', 1),
(392, 24, 'Champhai', 1),
(393, 24, 'Kolasib', 1),
(394, 24, 'Lawngtlai', 1),
(395, 24, 'Lunglei', 1),
(396, 24, 'Mamit', 1),
(397, 24, 'Saiha', 1),
(398, 24, 'Serchhip', 1),
(399, 25, 'Dimapur', 1),
(400, 25, 'Kiphire', 1),
(401, 25, 'Kohima', 1),
(402, 25, 'Longleng', 1),
(403, 25, 'Mokokchung', 1),
(404, 25, 'Mon', 1),
(405, 25, 'Peren', 1),
(406, 25, 'Phek', 1),
(407, 25, 'Tuensang', 1),
(408, 25, 'Wokha', 1),
(409, 25, 'Zunheboto', 1),
(410, 26, 'Angul', 1),
(411, 26, 'Boudh (Bauda)', 1),
(412, 26, 'Bhadrak', 1),
(413, 26, 'Balangir', 1),
(414, 26, 'Bargarh (Baragarh)', 1),
(415, 26, 'Balasore', 1),
(416, 26, 'Cuttack', 1),
(417, 26, 'Debagarh (Deogarh)', 1),
(418, 26, 'Dhenkanal', 1),
(419, 26, 'Ganjam', 1),
(420, 26, 'Gajapati', 1),
(421, 26, 'Jharsuguda', 1),
(422, 26, 'Jajpur', 1),
(423, 26, 'Jagatsinghpur', 1),
(424, 26, 'Khordha', 1),
(425, 26, 'Kendujhar (Keonjhar)', 1),
(426, 26, 'Kalahandi', 1),
(427, 26, 'Kandhamal', 1),
(428, 26, 'Koraput', 1),
(429, 26, 'Kendrapara', 1),
(430, 26, 'Malkangiri', 1),
(431, 26, 'Mayurbhanj', 1),
(432, 26, 'Nabarangpur', 1),
(433, 26, 'Nuapada', 1),
(434, 26, 'Nayagarh', 1),
(435, 26, 'Puri', 1),
(436, 26, 'Rayagada', 1),
(437, 26, 'Sambalpur', 1),
(438, 26, 'Subarnapur (Sonepur)', 1),
(439, 26, 'Sundergarh', 1),
(440, 27, 'Karaikal', 1),
(441, 27, 'Mahe', 1),
(442, 27, 'Pondicherry', 1),
(443, 27, 'Yanam', 1),
(444, 28, 'Amritsar', 1),
(445, 28, 'Barnala', 1),
(446, 28, 'Bathinda', 1),
(447, 28, 'Firozpur', 1),
(448, 28, 'Faridkot', 1),
(449, 28, 'Fatehgarh Sahib', 1),
(450, 28, 'Fazilka[6]', 1),
(451, 28, 'Gurdaspur', 1),
(452, 28, 'Hoshiarpur', 1),
(453, 28, 'Jalandhar', 1),
(454, 28, 'Kapurthala', 1),
(455, 28, 'Ludhiana', 1),
(456, 28, 'Mansa', 1),
(457, 28, 'Moga', 1),
(458, 28, 'Sri Muktsar Sahib', 1),
(459, 28, 'Pathankot', 1),
(460, 28, 'Patiala', 1),
(461, 28, 'Rupnagar', 1),
(462, 28, 'Ajitgarh (Mohali)', 1),
(463, 28, 'Sangrur', 1),
(464, 28, 'Shahid Bhagat Singh Nagar', 1),
(465, 28, 'Tarn Taran', 1),
(466, 29, 'Ajmer', 1),
(467, 29, 'Alwar', 1),
(468, 29, 'Bikaner', 1),
(469, 29, 'Barmer', 1),
(470, 29, 'Banswara', 1),
(471, 29, 'Bharatpur', 1),
(472, 29, 'Baran', 1),
(473, 29, 'Bundi', 1),
(474, 29, 'Bhilwara', 1),
(475, 29, 'Churu', 1),
(476, 29, 'Chittorgarh', 1),
(477, 29, 'Dausa', 1),
(478, 29, 'Dholpur', 1),
(479, 29, 'Dungapur', 1),
(480, 29, 'Ganganagar', 1),
(481, 29, 'Hanumangarh', 1),
(482, 29, 'Jhunjhunu', 1),
(483, 29, 'Jalore', 1),
(484, 29, 'Jodhpur', 1),
(485, 29, 'Jaipur', 1),
(486, 29, 'Jaisalmer', 1),
(487, 29, 'Jhalawar', 1),
(488, 29, 'Karauli', 1),
(489, 29, 'Kota', 1),
(490, 29, 'Nagaur', 1),
(491, 29, 'Pali', 1),
(492, 29, 'Pratapgarh', 1),
(493, 29, 'Rajsamand', 1),
(494, 29, 'Sikar', 1),
(495, 29, 'Sawai Madhopur', 1),
(496, 29, 'Sirohi', 1),
(497, 29, 'Tonk', 1),
(498, 29, 'Udaipur', 1),
(499, 30, 'East Sikkim', 1),
(500, 30, 'North Sikkim', 1),
(501, 30, 'South Sikkim', 1),
(502, 30, 'West Sikkim', 1),
(503, 31, 'Ariyalur', 1),
(504, 31, 'Chennai', 1),
(505, 31, 'Coimbatore', 1),
(506, 31, 'Cuddalore', 1),
(507, 31, 'Dharmapuri', 1),
(508, 31, 'Dindigul', 1),
(509, 31, 'Erode', 1),
(510, 31, 'Kanchipuram', 1),
(511, 31, 'Kanyakumari', 1),
(512, 31, 'Karur', 1),
(513, 31, 'Krishnagiri', 1),
(514, 31, 'Madurai', 1),
(515, 31, 'Nagapattinam', 1),
(516, 31, 'Nilgiris', 1),
(517, 31, 'Namakkal', 1),
(518, 31, 'Perambalur', 1),
(519, 31, 'Pudukkottai', 1),
(520, 31, 'Ramanathapuram', 1),
(521, 31, 'Salem', 1),
(522, 31, 'Sivaganga', 1),
(523, 31, 'Tirupur', 1),
(524, 31, 'Tiruchirappalli', 1),
(525, 31, 'Theni', 1),
(526, 31, 'Tirunelveli', 1),
(527, 31, 'Thanjavur', 1),
(528, 31, 'Thoothukudi', 1),
(529, 31, 'Tiruvallur', 1),
(530, 31, 'Tiruvarur', 1),
(531, 31, 'Tiruvannamalai', 1),
(532, 31, 'Vellore', 1),
(533, 31, 'Viluppuram', 1),
(534, 31, 'Virudhunagar', 1),
(535, 32, 'Dhalai', 1),
(536, 32, 'North Tripura', 1),
(537, 32, 'South Tripura', 1),
(538, 32, 'Khowai[7]', 1),
(539, 32, 'West Tripura', 1),
(540, 33, 'Agra', 1),
(541, 33, 'Aligarh', 1),
(542, 33, 'Allahabad', 1),
(543, 33, 'Ambedkar Nagar', 1),
(544, 33, 'Auraiya', 1),
(545, 33, 'Azamgarh', 1),
(546, 33, 'Bagpat', 1),
(547, 33, 'Bahraich', 1),
(548, 33, 'Ballia', 1),
(549, 33, 'Balrampur', 1),
(550, 33, 'Banda', 1),
(551, 33, 'Barabanki', 1),
(552, 33, 'Bareilly', 1),
(553, 33, 'Basti', 1),
(554, 33, 'Bijnor', 1),
(555, 33, 'Budaun', 1),
(556, 33, 'Bulandshahr', 1),
(557, 33, 'Chandauli', 1),
(558, 33, 'Chhatrapati Shahuji Maharaj Nagar[8]', 1),
(559, 33, 'Chitrakoot', 1),
(560, 33, 'Deoria', 1),
(561, 33, 'Etah', 1),
(562, 33, 'Etawah', 1),
(563, 33, 'Faizabad', 1),
(564, 33, 'Farrukhabad', 1),
(565, 33, 'Fatehpur', 1),
(566, 33, 'Firozabad', 1),
(567, 33, 'Gautam Buddh Nagar', 1),
(568, 33, 'Ghaziabad', 1),
(569, 33, 'Ghazipur', 1),
(570, 33, 'Gonda', 1),
(571, 33, 'Gorakhpur', 1),
(572, 33, 'Hamirpur', 1),
(573, 33, 'Hardoi', 1),
(574, 33, 'Hathras', 1),
(575, 33, 'Jalaun', 1),
(576, 33, 'Jaunpur district', 1),
(577, 33, 'Jhansi', 1),
(578, 33, 'Jyotiba Phule Nagar', 1),
(579, 33, 'Kannauj', 1),
(580, 33, 'Kanpur', 1),
(581, 33, 'Kanshi Ram Nagar', 1),
(582, 33, 'Kaushambi', 1),
(583, 33, 'Kushinagar', 1),
(584, 33, 'Lakhimpur Kheri', 1),
(585, 33, 'Lalitpur', 1),
(586, 33, 'Lucknow', 1),
(587, 33, 'Maharajganj', 1),
(588, 33, 'Mahoba', 1),
(589, 33, 'Mainpuri', 1),
(590, 33, 'Mathura', 1),
(591, 33, 'Mau', 1),
(592, 33, 'Meerut', 1),
(593, 33, 'Mirzapur', 1),
(594, 33, 'Moradabad', 1),
(595, 33, 'Muzaffarnagar', 1),
(596, 33, 'Panchsheel Nagar district (Hapur)', 1),
(597, 33, 'Pilibhit', 1),
(598, 33, 'Pratapgarh', 1),
(599, 33, 'Raebareli', 1),
(600, 33, 'Ramabai Nagar (Kanpur Dehat)', 1),
(601, 33, 'Rampur', 1),
(602, 33, 'Saharanpur', 1),
(603, 33, 'Sant Kabir Nagar', 1),
(604, 33, 'Sant Ravidas Nagar', 1),
(605, 33, 'Shahjahanpur', 1),
(606, 33, 'Shamli[9]', 1),
(607, 33, 'Shravasti', 1),
(608, 33, 'Siddharthnagar', 1),
(609, 33, 'Sitapur', 1),
(610, 33, 'Sonbhadra', 1),
(611, 33, 'Sultanpur', 1),
(612, 33, 'Unnao', 1),
(613, 33, 'Varanasi', 1),
(614, 34, 'Almora', 1),
(615, 34, 'Bageshwar', 1),
(616, 34, 'Chamoli', 1),
(617, 34, 'Champawat', 1),
(618, 34, 'Dehradun', 1),
(619, 34, 'Haridwar', 1),
(620, 34, 'Nainital', 1),
(621, 34, 'Pauri Garhwal', 1),
(622, 34, 'Pithoragarh', 1),
(623, 34, 'Rudraprayag', 1),
(624, 34, 'Tehri Garhwal', 1),
(625, 34, 'Udham Singh Nagar', 1),
(626, 34, 'Uttarkashi', 1),
(627, 35, 'Bankura', 1),
(628, 35, 'Bardhaman', 1),
(629, 35, 'Birbhum', 1),
(630, 35, 'Cooch Behar', 1),
(631, 35, 'Dakshin Dinajpur', 1),
(632, 35, 'Darjeeling', 1),
(633, 35, 'Hooghly', 1),
(634, 35, 'Howrah', 1),
(635, 35, 'Jalpaiguri', 1),
(636, 35, 'Kolkata', 1),
(637, 35, 'Maldah', 1),
(638, 35, 'Murshidabad', 1),
(639, 35, 'Nadia', 1),
(640, 35, 'North 24 Parganas', 1),
(641, 35, 'Paschim Medinipur', 1),
(642, 35, 'Purba Medinipur', 1),
(643, 35, 'Purulia', 1),
(644, 35, 'South 24 Parganas', 1),
(645, 35, 'Uttar Dinajpur', 1);

-- --------------------------------------------------------

--
-- Table structure for table `class`
--

CREATE TABLE `class` (
  `id` int(11) NOT NULL,
  `classname` varchar(100) NOT NULL,
  `arclassname` varchar(45) CHARACTER SET utf8 DEFAULT NULL,
  `status` int(1) NOT NULL,
  `createdby` varchar(100) NOT NULL,
  `creation_date` date NOT NULL,
  `modifiedby` varchar(100) NOT NULL,
  `modified_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `sortby` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `class`
--

INSERT INTO `class` (`id`, `classname`, `arclassname`, `status`, `createdby`, `creation_date`, `modifiedby`, `modified_date`, `sortby`) VALUES
(1, 'Grade LKG', 'المرحلة الأولي من رياض الأطفال', 0, '', '0000-00-00', '', '2019-05-10 10:16:18', 2),
(2, 'Grade UKG', 'المرحلة الثانية من رياض الأطفال', 0, '', '0000-00-00', '', '2019-05-10 10:16:18', 3),
(3, 'Grade I', 'الصف الأول', 0, '', '0000-00-00', '', '2019-05-10 10:16:19', 4),
(4, 'Grade II', 'Grade II', 0, '', '0000-00-00', '', '2019-05-10 10:03:20', 5),
(5, 'Grade III', 'Grade III', 0, '', '0000-00-00', '', '2019-05-10 10:03:20', 6),
(6, 'Grade IV', 'Grade IV', 0, '', '0000-00-00', '', '2019-05-10 10:03:20', 7),
(7, 'Grade V', 'Grade V', 0, '', '0000-00-00', '', '2019-05-10 10:03:20', 8),
(8, 'Grade VI', 'Grade VI', 0, '', '0000-00-00', '', '2019-05-10 10:03:20', 9),
(9, 'Grade VII', 'Grade VII', 0, '', '0000-00-00', '', '2019-05-10 10:03:20', 10),
(10, 'Grade VIII', 'Grade VIII', 0, '', '0000-00-00', '', '2019-05-10 10:03:20', 11),
(11, 'Grade PREKG', 'مرحلة ما قبل رياض الأطفال', 0, '', '0000-00-00', '', '2019-05-10 10:15:26', 1);

-- --------------------------------------------------------

--
-- Table structure for table `class_plan_game`
--

CREATE TABLE `class_plan_game` (
  `id` int(11) NOT NULL,
  `class_id` int(11) NOT NULL,
  `plan_id` int(11) NOT NULL,
  `game_id` int(11) NOT NULL,
  `status` int(1) NOT NULL,
  `createdby` varchar(100) NOT NULL,
  `creation_date` date NOT NULL,
  `modifiedby` varchar(100) NOT NULL,
  `modified_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `class_plan_game`
--

INSERT INTO `class_plan_game` (`id`, `class_id`, `plan_id`, `game_id`, `status`, `createdby`, `creation_date`, `modifiedby`, `modified_date`) VALUES
(1, 3, 1, 1, 0, '', '0000-00-00', '', '2014-06-15 02:49:49'),
(2, 3, 1, 2, 0, '', '0000-00-00', '', '2014-06-15 02:49:49'),
(3, 3, 1, 3, 0, '', '0000-00-00', '', '2014-06-15 02:49:49'),
(4, 3, 1, 4, 0, '', '0000-00-00', '', '2014-06-15 02:49:49'),
(5, 3, 1, 5, 0, '', '0000-00-00', '', '2014-06-15 02:49:49'),
(6, 3, 1, 6, 0, '', '0000-00-00', '', '2014-06-15 02:49:49'),
(7, 3, 1, 7, 0, '', '0000-00-00', '', '2014-06-15 02:49:49'),
(8, 3, 1, 8, 0, '', '0000-00-00', '', '2014-06-15 02:49:49'),
(9, 3, 1, 9, 0, '', '0000-00-00', '', '2014-06-15 02:49:49'),
(10, 3, 1, 10, 0, '', '0000-00-00', '', '2014-06-15 02:49:49'),
(11, 3, 1, 11, 0, '', '0000-00-00', '', '2014-06-15 02:49:49'),
(12, 3, 1, 12, 0, '', '0000-00-00', '', '2014-06-15 02:49:49'),
(13, 3, 1, 15, 0, '', '0000-00-00', '', '2014-06-15 02:49:49'),
(14, 3, 1, 16, 0, '', '0000-00-00', '', '2014-06-15 02:49:49'),
(15, 3, 1, 17, 0, '', '0000-00-00', '', '2014-06-15 02:49:49'),
(16, 3, 1, 18, 0, '', '0000-00-00', '', '2014-06-15 02:49:49'),
(17, 3, 1, 19, 0, '', '0000-00-00', '', '2014-06-15 02:49:49'),
(18, 3, 1, 20, 0, '', '0000-00-00', '', '2014-06-15 02:49:49'),
(19, 3, 1, 21, 0, '', '0000-00-00', '', '2014-06-15 02:49:49'),
(20, 3, 1, 22, 0, '', '0000-00-00', '', '2014-06-15 02:49:49'),
(21, 3, 1, 23, 0, '', '0000-00-00', '', '2014-06-15 02:49:49'),
(22, 3, 1, 24, 0, '', '0000-00-00', '', '2014-06-15 02:49:49'),
(23, 3, 1, 25, 0, '', '0000-00-00', '', '2014-06-15 02:49:49'),
(24, 3, 1, 26, 0, '', '0000-00-00', '', '2014-06-15 02:49:49'),
(25, 3, 1, 27, 0, '', '0000-00-00', '', '2014-06-15 02:49:49'),
(26, 3, 1, 28, 0, '', '0000-00-00', '', '2014-06-15 02:49:49'),
(27, 3, 1, 29, 0, '', '0000-00-00', '', '2014-06-15 02:49:49'),
(28, 3, 1, 30, 0, '', '0000-00-00', '', '2014-06-15 02:49:49'),
(29, 3, 1, 31, 0, '', '0000-00-00', '', '2014-06-15 02:49:49'),
(30, 3, 1, 32, 0, '', '0000-00-00', '', '2014-06-15 02:49:49'),
(31, 3, 1, 33, 0, '', '0000-00-00', '', '2014-06-15 02:49:49'),
(32, 3, 1, 34, 0, '', '0000-00-00', '', '2014-06-15 02:49:49'),
(33, 3, 1, 35, 0, '', '0000-00-00', '', '2014-06-15 02:49:49'),
(34, 3, 1, 36, 0, '', '0000-00-00', '', '2014-06-15 02:49:49'),
(35, 3, 1, 37, 0, '', '0000-00-00', '', '2014-06-15 02:49:49'),
(36, 3, 1, 38, 0, '', '0000-00-00', '', '2014-06-15 02:49:49'),
(37, 3, 1, 39, 0, '', '0000-00-00', '', '2014-06-15 02:49:49'),
(38, 3, 1, 40, 0, '', '0000-00-00', '', '2014-06-15 02:49:49'),
(39, 3, 1, 41, 0, '', '0000-00-00', '', '2014-06-15 02:49:49'),
(40, 3, 1, 42, 0, '', '0000-00-00', '', '2014-06-15 02:49:49'),
(41, 4, 2, 43, 0, '', '0000-00-00', '', '2014-06-15 02:51:30'),
(42, 4, 2, 44, 0, '', '0000-00-00', '', '2014-06-15 02:51:30'),
(43, 4, 2, 45, 0, '', '0000-00-00', '', '2014-06-15 02:51:30'),
(44, 4, 2, 46, 0, '', '0000-00-00', '', '2014-06-15 02:51:30'),
(45, 4, 2, 47, 0, '', '0000-00-00', '', '2014-06-15 02:51:30'),
(46, 4, 2, 48, 0, '', '0000-00-00', '', '2014-06-15 02:51:30'),
(47, 4, 2, 49, 0, '', '0000-00-00', '', '2014-06-15 02:51:30'),
(48, 4, 2, 50, 0, '', '0000-00-00', '', '2014-06-15 02:51:30'),
(49, 4, 2, 51, 0, '', '0000-00-00', '', '2014-06-15 02:51:30'),
(50, 4, 2, 52, 0, '', '0000-00-00', '', '2014-06-15 02:51:30'),
(51, 4, 2, 53, 0, '', '0000-00-00', '', '2014-06-15 02:51:30'),
(52, 4, 2, 54, 0, '', '0000-00-00', '', '2014-06-15 02:51:30'),
(53, 4, 2, 55, 0, '', '0000-00-00', '', '2014-06-15 02:51:30'),
(54, 4, 2, 56, 0, '', '0000-00-00', '', '2014-06-15 02:51:30'),
(55, 4, 2, 57, 0, '', '0000-00-00', '', '2014-06-15 02:51:30'),
(56, 4, 2, 58, 0, '', '0000-00-00', '', '2014-06-15 02:51:30'),
(57, 4, 2, 59, 0, '', '0000-00-00', '', '2014-06-15 02:51:30'),
(58, 4, 2, 60, 0, '', '0000-00-00', '', '2014-06-15 02:51:30'),
(59, 4, 2, 61, 0, '', '0000-00-00', '', '2014-06-15 02:51:30'),
(60, 4, 2, 62, 0, '', '0000-00-00', '', '2014-06-15 02:51:30'),
(61, 4, 2, 63, 0, '', '0000-00-00', '', '2014-06-15 02:51:30'),
(62, 4, 2, 64, 0, '', '0000-00-00', '', '2014-06-15 02:51:30'),
(63, 4, 2, 65, 0, '', '0000-00-00', '', '2014-06-15 02:51:30'),
(64, 4, 2, 66, 0, '', '0000-00-00', '', '2014-06-15 02:51:30'),
(65, 4, 2, 67, 0, '', '0000-00-00', '', '2014-06-15 02:51:30'),
(66, 4, 2, 68, 0, '', '0000-00-00', '', '2014-06-15 02:51:30'),
(67, 4, 2, 69, 0, '', '0000-00-00', '', '2014-06-15 02:51:30'),
(68, 4, 2, 70, 0, '', '0000-00-00', '', '2014-06-15 02:51:30'),
(69, 4, 2, 71, 0, '', '0000-00-00', '', '2014-06-15 02:51:30'),
(70, 4, 2, 72, 0, '', '0000-00-00', '', '2014-06-15 02:51:30'),
(71, 4, 2, 73, 0, '', '0000-00-00', '', '2014-06-15 02:51:30'),
(72, 4, 2, 74, 0, '', '0000-00-00', '', '2014-06-15 02:51:30'),
(73, 4, 2, 75, 0, '', '0000-00-00', '', '2014-06-15 02:51:30'),
(74, 4, 2, 76, 0, '', '0000-00-00', '', '2014-06-15 02:51:30'),
(75, 4, 2, 77, 0, '', '0000-00-00', '', '2014-06-15 02:51:30'),
(76, 4, 2, 78, 0, '', '0000-00-00', '', '2014-06-15 02:51:30'),
(77, 4, 2, 79, 0, '', '0000-00-00', '', '2014-06-15 02:51:30'),
(78, 4, 2, 80, 0, '', '0000-00-00', '', '2014-06-15 02:51:30'),
(79, 4, 2, 81, 0, '', '0000-00-00', '', '2014-06-15 02:51:30'),
(80, 4, 2, 82, 0, '', '0000-00-00', '', '2014-06-15 02:51:30'),
(81, 5, 3, 83, 0, '', '0000-00-00', '', '2014-06-15 02:52:24'),
(82, 5, 3, 84, 0, '', '0000-00-00', '', '2014-06-15 02:52:24'),
(83, 5, 3, 85, 0, '', '0000-00-00', '', '2014-06-15 02:52:24'),
(84, 5, 3, 86, 0, '', '0000-00-00', '', '2014-06-15 02:52:24'),
(85, 5, 3, 87, 0, '', '0000-00-00', '', '2014-06-15 02:52:24'),
(86, 5, 3, 88, 0, '', '0000-00-00', '', '2014-06-15 02:52:24'),
(87, 5, 3, 89, 0, '', '0000-00-00', '', '2014-06-15 02:52:24'),
(88, 5, 3, 90, 0, '', '0000-00-00', '', '2014-06-15 02:52:24'),
(89, 5, 3, 91, 0, '', '0000-00-00', '', '2014-06-15 02:52:24'),
(90, 5, 3, 92, 0, '', '0000-00-00', '', '2014-06-15 02:52:24'),
(91, 5, 3, 93, 0, '', '0000-00-00', '', '2014-06-15 02:52:24'),
(92, 5, 3, 94, 0, '', '0000-00-00', '', '2014-06-15 02:52:24'),
(93, 5, 3, 95, 0, '', '0000-00-00', '', '2014-06-15 02:52:24'),
(94, 5, 3, 96, 0, '', '0000-00-00', '', '2014-06-15 02:52:24'),
(95, 5, 3, 97, 0, '', '0000-00-00', '', '2014-06-15 02:52:24'),
(96, 5, 3, 98, 0, '', '0000-00-00', '', '2014-06-15 02:52:24'),
(97, 5, 3, 99, 0, '', '0000-00-00', '', '2014-06-15 02:52:24'),
(98, 5, 3, 100, 0, '', '0000-00-00', '', '2014-06-15 02:52:24'),
(99, 5, 3, 101, 0, '', '0000-00-00', '', '2014-06-15 02:52:24'),
(100, 5, 3, 102, 0, '', '0000-00-00', '', '2014-06-15 02:52:24'),
(101, 5, 3, 103, 0, '', '0000-00-00', '', '2014-06-15 02:52:24'),
(102, 5, 3, 104, 0, '', '0000-00-00', '', '2014-06-15 02:52:24'),
(103, 5, 3, 105, 0, '', '0000-00-00', '', '2014-06-15 02:52:24'),
(104, 5, 3, 106, 0, '', '0000-00-00', '', '2014-06-15 02:52:24'),
(105, 5, 3, 107, 0, '', '0000-00-00', '', '2014-06-15 02:52:24'),
(106, 5, 3, 108, 0, '', '0000-00-00', '', '2014-06-15 02:52:24'),
(107, 5, 3, 109, 0, '', '0000-00-00', '', '2014-06-15 02:52:24'),
(108, 5, 3, 110, 0, '', '0000-00-00', '', '2014-06-15 02:52:24'),
(109, 5, 3, 111, 0, '', '0000-00-00', '', '2014-06-15 02:52:24'),
(110, 5, 3, 112, 0, '', '0000-00-00', '', '2014-06-15 02:52:24'),
(111, 5, 3, 113, 0, '', '0000-00-00', '', '2014-06-15 02:52:24'),
(112, 5, 3, 114, 0, '', '0000-00-00', '', '2014-06-15 02:52:24'),
(113, 5, 3, 115, 0, '', '0000-00-00', '', '2014-06-15 02:52:24'),
(114, 5, 3, 116, 0, '', '0000-00-00', '', '2014-06-15 02:52:24'),
(115, 5, 3, 117, 0, '', '0000-00-00', '', '2014-06-15 02:52:24'),
(116, 5, 3, 118, 0, '', '0000-00-00', '', '2014-06-15 02:52:24'),
(117, 5, 3, 119, 0, '', '0000-00-00', '', '2014-06-15 02:52:24'),
(118, 5, 3, 120, 0, '', '0000-00-00', '', '2014-06-15 02:52:24'),
(119, 5, 3, 121, 0, '', '0000-00-00', '', '2014-06-15 02:52:24'),
(120, 5, 3, 122, 0, '', '0000-00-00', '', '2014-06-15 02:52:24'),
(121, 6, 4, 123, 0, '', '0000-00-00', '', '2014-06-15 02:54:02'),
(122, 6, 4, 124, 0, '', '0000-00-00', '', '2014-06-15 02:54:02'),
(123, 6, 4, 125, 0, '', '0000-00-00', '', '2014-06-15 02:54:02'),
(124, 6, 4, 126, 0, '', '0000-00-00', '', '2014-06-15 02:54:02'),
(125, 6, 4, 127, 0, '', '0000-00-00', '', '2014-06-15 02:54:02'),
(126, 6, 4, 128, 0, '', '0000-00-00', '', '2014-06-15 02:54:02'),
(127, 6, 4, 129, 0, '', '0000-00-00', '', '2014-06-15 02:54:02'),
(128, 6, 4, 130, 0, '', '0000-00-00', '', '2014-06-15 02:54:02'),
(129, 6, 4, 131, 0, '', '0000-00-00', '', '2014-06-15 02:54:02'),
(130, 6, 4, 132, 0, '', '0000-00-00', '', '2014-06-15 02:54:02'),
(131, 6, 4, 133, 0, '', '0000-00-00', '', '2014-06-15 02:54:02'),
(132, 6, 4, 134, 0, '', '0000-00-00', '', '2014-06-15 02:54:02'),
(133, 6, 4, 135, 0, '', '0000-00-00', '', '2014-06-15 02:54:02'),
(134, 6, 4, 136, 0, '', '0000-00-00', '', '2014-06-15 02:54:02'),
(135, 6, 4, 137, 0, '', '0000-00-00', '', '2014-06-15 02:54:02'),
(136, 6, 4, 138, 0, '', '0000-00-00', '', '2014-06-15 02:54:02'),
(137, 6, 4, 139, 0, '', '0000-00-00', '', '2014-06-15 02:54:02'),
(138, 6, 4, 140, 0, '', '0000-00-00', '', '2014-06-15 02:54:02'),
(139, 6, 4, 141, 0, '', '0000-00-00', '', '2014-06-15 02:54:02'),
(140, 6, 4, 142, 0, '', '0000-00-00', '', '2014-06-15 02:54:02'),
(141, 6, 4, 143, 0, '', '0000-00-00', '', '2014-06-15 02:54:02'),
(142, 6, 4, 144, 0, '', '0000-00-00', '', '2014-06-15 02:54:02'),
(143, 6, 4, 145, 0, '', '0000-00-00', '', '2014-06-15 02:54:02'),
(144, 6, 4, 146, 0, '', '0000-00-00', '', '2014-06-15 02:54:02'),
(145, 6, 4, 147, 0, '', '0000-00-00', '', '2014-06-15 02:54:02'),
(146, 6, 4, 148, 0, '', '0000-00-00', '', '2014-06-15 02:54:02'),
(147, 6, 4, 149, 0, '', '0000-00-00', '', '2014-06-15 02:54:02'),
(148, 6, 4, 150, 0, '', '0000-00-00', '', '2014-06-15 02:54:02'),
(149, 6, 4, 151, 0, '', '0000-00-00', '', '2014-06-15 02:54:02'),
(150, 6, 4, 152, 0, '', '0000-00-00', '', '2014-06-15 02:54:02'),
(151, 6, 4, 153, 0, '', '0000-00-00', '', '2014-06-15 02:54:02'),
(152, 6, 4, 154, 0, '', '0000-00-00', '', '2014-06-15 02:54:02'),
(153, 6, 4, 155, 0, '', '0000-00-00', '', '2014-06-15 02:54:02'),
(154, 6, 4, 156, 0, '', '0000-00-00', '', '2014-06-15 02:54:02'),
(155, 6, 4, 157, 0, '', '0000-00-00', '', '2014-06-15 02:54:02'),
(156, 6, 4, 158, 0, '', '0000-00-00', '', '2014-06-15 02:54:02'),
(157, 6, 4, 159, 0, '', '0000-00-00', '', '2014-06-15 02:54:02'),
(158, 6, 4, 160, 0, '', '0000-00-00', '', '2014-06-15 02:54:02'),
(159, 6, 4, 161, 0, '', '0000-00-00', '', '2014-06-15 02:54:02'),
(160, 6, 4, 162, 0, '', '0000-00-00', '', '2014-06-15 02:54:02'),
(201, 7, 5, 163, 0, '', '0000-00-00', '', '2014-06-15 02:57:12'),
(202, 7, 5, 164, 0, '', '0000-00-00', '', '2014-06-15 02:57:13'),
(203, 7, 5, 165, 0, '', '0000-00-00', '', '2014-06-15 02:57:13'),
(204, 7, 5, 166, 0, '', '0000-00-00', '', '2014-06-15 02:57:13'),
(205, 7, 5, 167, 0, '', '0000-00-00', '', '2014-06-15 02:57:13'),
(206, 7, 5, 168, 0, '', '0000-00-00', '', '2014-06-15 02:57:13'),
(207, 7, 5, 169, 0, '', '0000-00-00', '', '2014-06-15 02:57:13'),
(208, 7, 5, 170, 0, '', '0000-00-00', '', '2014-06-15 02:57:13'),
(209, 7, 5, 171, 0, '', '0000-00-00', '', '2014-06-15 02:57:13'),
(210, 7, 5, 172, 0, '', '0000-00-00', '', '2014-06-15 02:57:13'),
(211, 7, 5, 173, 0, '', '0000-00-00', '', '2014-06-15 02:57:13'),
(212, 7, 5, 174, 0, '', '0000-00-00', '', '2014-06-15 02:57:13'),
(213, 7, 5, 175, 0, '', '0000-00-00', '', '2014-06-15 02:57:13'),
(214, 7, 5, 176, 0, '', '0000-00-00', '', '2014-06-15 02:57:13'),
(215, 7, 5, 177, 0, '', '0000-00-00', '', '2014-06-15 02:57:13'),
(216, 7, 5, 178, 0, '', '0000-00-00', '', '2014-06-15 02:57:13'),
(217, 7, 5, 179, 0, '', '0000-00-00', '', '2014-06-15 02:57:13'),
(218, 7, 5, 180, 0, '', '0000-00-00', '', '2014-06-15 02:57:13'),
(219, 7, 5, 181, 0, '', '0000-00-00', '', '2014-06-15 02:57:13'),
(220, 7, 5, 182, 0, '', '0000-00-00', '', '2014-06-15 02:57:13'),
(221, 7, 5, 183, 0, '', '0000-00-00', '', '2014-06-15 02:57:13'),
(222, 7, 5, 184, 0, '', '0000-00-00', '', '2014-06-15 02:57:13'),
(223, 7, 5, 185, 0, '', '0000-00-00', '', '2014-06-15 02:57:13'),
(224, 7, 5, 186, 0, '', '0000-00-00', '', '2014-06-15 02:57:13'),
(225, 7, 5, 187, 0, '', '0000-00-00', '', '2014-06-15 02:57:13'),
(226, 7, 5, 188, 0, '', '0000-00-00', '', '2014-06-15 02:57:13'),
(227, 7, 5, 189, 0, '', '0000-00-00', '', '2014-06-15 02:57:13'),
(228, 7, 5, 190, 0, '', '0000-00-00', '', '2014-06-15 02:57:13'),
(229, 7, 5, 191, 0, '', '0000-00-00', '', '2014-06-15 02:57:13'),
(230, 7, 5, 192, 0, '', '0000-00-00', '', '2014-06-15 02:57:13'),
(231, 7, 5, 193, 0, '', '0000-00-00', '', '2014-06-15 02:57:13'),
(232, 7, 5, 194, 0, '', '0000-00-00', '', '2014-06-15 02:57:13'),
(233, 7, 5, 195, 0, '', '0000-00-00', '', '2014-06-15 02:57:13'),
(234, 7, 5, 196, 0, '', '0000-00-00', '', '2014-06-15 02:57:13'),
(235, 7, 5, 197, 0, '', '0000-00-00', '', '2014-06-15 02:57:13'),
(236, 7, 5, 198, 0, '', '0000-00-00', '', '2014-06-15 02:57:13'),
(237, 7, 5, 199, 0, '', '0000-00-00', '', '2014-06-15 02:57:13'),
(238, 7, 5, 200, 0, '', '0000-00-00', '', '2014-06-15 02:57:13'),
(239, 7, 5, 201, 0, '', '0000-00-00', '', '2014-06-15 02:57:13'),
(240, 7, 5, 202, 0, '', '0000-00-00', '', '2014-06-15 02:57:13'),
(241, 8, 6, 203, 0, '', '0000-00-00', '', '2014-06-15 02:58:14'),
(242, 8, 6, 204, 0, '', '0000-00-00', '', '2014-06-15 02:58:14'),
(243, 8, 6, 205, 0, '', '0000-00-00', '', '2014-06-15 02:58:14'),
(244, 8, 6, 206, 0, '', '0000-00-00', '', '2014-06-15 02:58:14'),
(245, 8, 6, 207, 0, '', '0000-00-00', '', '2014-06-15 02:58:14'),
(246, 8, 6, 208, 0, '', '0000-00-00', '', '2014-06-15 02:58:14'),
(247, 8, 6, 209, 0, '', '0000-00-00', '', '2014-06-15 02:58:14'),
(248, 8, 6, 210, 0, '', '0000-00-00', '', '2014-06-15 02:58:14'),
(249, 8, 6, 211, 0, '', '0000-00-00', '', '2014-06-15 02:58:14'),
(250, 8, 6, 212, 0, '', '0000-00-00', '', '2014-06-15 02:58:14'),
(251, 8, 6, 213, 0, '', '0000-00-00', '', '2014-06-15 02:58:14'),
(252, 8, 6, 214, 0, '', '0000-00-00', '', '2014-06-15 02:58:14'),
(253, 8, 6, 215, 0, '', '0000-00-00', '', '2014-06-15 02:58:14'),
(254, 8, 6, 216, 0, '', '0000-00-00', '', '2014-06-15 02:58:14'),
(255, 8, 6, 217, 0, '', '0000-00-00', '', '2014-06-15 02:58:14'),
(256, 8, 6, 218, 0, '', '0000-00-00', '', '2014-06-15 02:58:14'),
(257, 8, 6, 219, 0, '', '0000-00-00', '', '2014-06-15 02:58:14'),
(258, 8, 6, 220, 0, '', '0000-00-00', '', '2014-06-15 02:58:14'),
(259, 8, 6, 221, 0, '', '0000-00-00', '', '2014-06-15 02:58:14'),
(260, 8, 6, 222, 0, '', '0000-00-00', '', '2014-06-15 02:58:14'),
(261, 8, 6, 223, 0, '', '0000-00-00', '', '2014-06-15 02:58:14'),
(262, 8, 6, 224, 0, '', '0000-00-00', '', '2014-06-15 02:58:14'),
(263, 8, 6, 225, 0, '', '0000-00-00', '', '2014-06-15 02:58:14'),
(264, 8, 6, 226, 0, '', '0000-00-00', '', '2014-06-15 02:58:14'),
(265, 8, 6, 227, 0, '', '0000-00-00', '', '2014-06-15 02:58:14'),
(266, 8, 6, 228, 0, '', '0000-00-00', '', '2014-06-15 02:58:14'),
(267, 8, 6, 229, 0, '', '0000-00-00', '', '2014-06-15 02:58:14'),
(268, 8, 6, 230, 0, '', '0000-00-00', '', '2014-06-15 02:58:14'),
(269, 8, 6, 231, 0, '', '0000-00-00', '', '2014-06-15 02:58:14'),
(270, 8, 6, 232, 0, '', '0000-00-00', '', '2014-06-15 02:58:14'),
(271, 8, 6, 233, 0, '', '0000-00-00', '', '2014-06-15 02:58:14'),
(272, 8, 6, 234, 0, '', '0000-00-00', '', '2014-06-15 02:58:14'),
(273, 8, 6, 235, 0, '', '0000-00-00', '', '2014-06-15 02:58:14'),
(274, 8, 6, 236, 0, '', '0000-00-00', '', '2014-06-15 02:58:14'),
(275, 8, 6, 237, 0, '', '0000-00-00', '', '2014-06-15 02:58:14'),
(276, 8, 6, 238, 0, '', '0000-00-00', '', '2014-06-15 02:58:14'),
(277, 8, 6, 239, 0, '', '0000-00-00', '', '2014-06-15 02:58:14'),
(278, 8, 6, 240, 0, '', '0000-00-00', '', '2014-06-15 02:58:14'),
(279, 8, 6, 241, 0, '', '0000-00-00', '', '2014-06-15 02:58:14'),
(280, 8, 6, 242, 0, '', '0000-00-00', '', '2014-06-15 02:58:14'),
(281, 9, 7, 243, 0, '', '0000-00-00', '', '2014-06-15 02:59:22'),
(282, 9, 7, 244, 0, '', '0000-00-00', '', '2014-06-15 02:59:22'),
(283, 9, 7, 245, 0, '', '0000-00-00', '', '2014-06-15 02:59:22'),
(284, 9, 7, 246, 0, '', '0000-00-00', '', '2014-06-15 02:59:22'),
(285, 9, 7, 247, 0, '', '0000-00-00', '', '2014-06-15 02:59:22'),
(286, 9, 7, 248, 0, '', '0000-00-00', '', '2014-06-15 02:59:22'),
(287, 9, 7, 249, 0, '', '0000-00-00', '', '2014-06-15 02:59:22'),
(288, 9, 7, 250, 0, '', '0000-00-00', '', '2014-06-15 02:59:22'),
(289, 9, 7, 251, 0, '', '0000-00-00', '', '2014-06-15 02:59:22'),
(290, 9, 7, 252, 0, '', '0000-00-00', '', '2014-06-15 02:59:22'),
(291, 9, 7, 253, 0, '', '0000-00-00', '', '2014-06-15 02:59:22'),
(292, 9, 7, 254, 0, '', '0000-00-00', '', '2014-06-15 02:59:22'),
(293, 9, 7, 255, 0, '', '0000-00-00', '', '2014-06-15 02:59:22'),
(294, 9, 7, 256, 0, '', '0000-00-00', '', '2014-06-15 02:59:22'),
(295, 9, 7, 257, 0, '', '0000-00-00', '', '2014-06-15 02:59:22'),
(296, 9, 7, 258, 0, '', '0000-00-00', '', '2014-06-15 02:59:22'),
(297, 9, 7, 259, 0, '', '0000-00-00', '', '2014-06-15 02:59:22'),
(298, 9, 7, 260, 0, '', '0000-00-00', '', '2014-06-15 02:59:22'),
(299, 9, 7, 261, 0, '', '0000-00-00', '', '2014-06-15 02:59:22'),
(300, 9, 7, 262, 0, '', '0000-00-00', '', '2014-06-15 02:59:22'),
(301, 9, 7, 263, 0, '', '0000-00-00', '', '2014-06-15 02:59:22'),
(302, 9, 7, 264, 0, '', '0000-00-00', '', '2014-06-15 02:59:22'),
(303, 9, 7, 265, 0, '', '0000-00-00', '', '2014-06-15 02:59:22'),
(304, 9, 7, 266, 0, '', '0000-00-00', '', '2014-06-15 02:59:22'),
(305, 9, 7, 267, 0, '', '0000-00-00', '', '2014-06-15 02:59:22'),
(306, 9, 7, 268, 0, '', '0000-00-00', '', '2014-06-15 02:59:22'),
(307, 9, 7, 269, 0, '', '0000-00-00', '', '2014-06-15 02:59:22'),
(308, 9, 7, 270, 0, '', '0000-00-00', '', '2014-06-15 02:59:22'),
(309, 9, 7, 271, 0, '', '0000-00-00', '', '2014-06-15 02:59:22'),
(310, 9, 7, 272, 0, '', '0000-00-00', '', '2014-06-15 02:59:22'),
(311, 9, 7, 273, 0, '', '0000-00-00', '', '2014-06-15 02:59:22'),
(312, 9, 7, 274, 0, '', '0000-00-00', '', '2014-06-15 02:59:22'),
(313, 9, 7, 275, 0, '', '0000-00-00', '', '2014-06-15 02:59:22'),
(314, 9, 7, 276, 0, '', '0000-00-00', '', '2014-06-15 02:59:22'),
(315, 9, 7, 277, 0, '', '0000-00-00', '', '2014-06-15 02:59:22'),
(316, 9, 7, 278, 0, '', '0000-00-00', '', '2014-06-15 02:59:22'),
(317, 9, 7, 279, 0, '', '0000-00-00', '', '2014-06-15 02:59:22'),
(318, 9, 7, 280, 0, '', '0000-00-00', '', '2014-06-15 02:59:22'),
(319, 9, 7, 281, 0, '', '0000-00-00', '', '2014-06-15 02:59:22'),
(320, 9, 7, 282, 0, '', '0000-00-00', '', '2014-06-15 02:59:22'),
(321, 10, 8, 283, 0, '', '0000-00-00', '', '2014-06-15 02:59:59'),
(322, 10, 8, 284, 0, '', '0000-00-00', '', '2014-06-15 02:59:59'),
(323, 10, 8, 285, 0, '', '0000-00-00', '', '2014-06-15 02:59:59'),
(324, 10, 8, 286, 0, '', '0000-00-00', '', '2014-06-15 02:59:59'),
(325, 10, 8, 287, 0, '', '0000-00-00', '', '2014-06-15 02:59:59'),
(326, 10, 8, 288, 0, '', '0000-00-00', '', '2014-06-15 02:59:59'),
(327, 10, 8, 289, 0, '', '0000-00-00', '', '2014-06-15 02:59:59'),
(328, 10, 8, 290, 0, '', '0000-00-00', '', '2014-06-15 02:59:59'),
(329, 10, 8, 291, 0, '', '0000-00-00', '', '2014-06-15 02:59:59'),
(330, 10, 8, 292, 0, '', '0000-00-00', '', '2014-06-15 02:59:59'),
(331, 10, 8, 293, 0, '', '0000-00-00', '', '2014-06-15 02:59:59'),
(332, 10, 8, 294, 0, '', '0000-00-00', '', '2014-06-15 02:59:59'),
(333, 10, 8, 295, 0, '', '0000-00-00', '', '2014-06-15 02:59:59'),
(334, 10, 8, 296, 0, '', '0000-00-00', '', '2014-06-15 02:59:59'),
(335, 10, 8, 297, 0, '', '0000-00-00', '', '2014-06-15 02:59:59'),
(336, 10, 8, 298, 0, '', '0000-00-00', '', '2014-06-15 02:59:59'),
(337, 10, 8, 299, 0, '', '0000-00-00', '', '2014-06-15 02:59:59'),
(338, 10, 8, 300, 0, '', '0000-00-00', '', '2014-06-15 02:59:59'),
(339, 10, 8, 301, 0, '', '0000-00-00', '', '2014-06-15 02:59:59'),
(340, 10, 8, 302, 0, '', '0000-00-00', '', '2014-06-15 02:59:59'),
(341, 10, 8, 303, 0, '', '0000-00-00', '', '2014-06-15 02:59:59'),
(342, 10, 8, 304, 0, '', '0000-00-00', '', '2014-06-15 02:59:59'),
(343, 10, 8, 306, 0, '', '0000-00-00', '', '2014-06-15 02:59:59'),
(344, 10, 8, 307, 0, '', '0000-00-00', '', '2014-06-15 02:59:59'),
(345, 10, 8, 308, 0, '', '0000-00-00', '', '2014-06-15 02:59:59'),
(346, 10, 8, 309, 0, '', '0000-00-00', '', '2014-06-15 02:59:59'),
(347, 10, 8, 310, 0, '', '0000-00-00', '', '2014-06-15 02:59:59'),
(348, 10, 8, 311, 0, '', '0000-00-00', '', '2014-06-15 02:59:59'),
(349, 10, 8, 312, 0, '', '0000-00-00', '', '2014-06-15 02:59:59'),
(350, 10, 8, 313, 0, '', '0000-00-00', '', '2014-06-15 02:59:59'),
(351, 10, 8, 314, 0, '', '0000-00-00', '', '2014-06-15 02:59:59'),
(352, 10, 8, 315, 0, '', '0000-00-00', '', '2014-06-15 02:59:59'),
(353, 10, 8, 316, 0, '', '0000-00-00', '', '2014-06-15 02:59:59'),
(354, 10, 8, 317, 0, '', '0000-00-00', '', '2014-06-15 02:59:59'),
(355, 10, 8, 318, 0, '', '0000-00-00', '', '2014-06-15 02:59:59'),
(356, 10, 8, 319, 0, '', '0000-00-00', '', '2014-06-15 02:59:59'),
(357, 10, 8, 320, 0, '', '0000-00-00', '', '2014-06-15 02:59:59'),
(358, 10, 8, 321, 0, '', '0000-00-00', '', '2014-06-15 02:59:59'),
(359, 10, 8, 322, 0, '', '0000-00-00', '', '2014-06-15 02:59:59'),
(360, 10, 8, 323, 0, '', '0000-00-00', '', '2014-06-15 02:59:59'),
(361, 3, 1, 324, 0, '', '0000-00-00', '', '2014-06-15 05:48:37'),
(362, 3, 1, 325, 0, '', '0000-00-00', '', '2014-06-15 05:48:37'),
(363, 3, 1, 326, 0, '', '0000-00-00', '', '2014-06-15 05:48:37'),
(364, 3, 1, 327, 0, '', '0000-00-00', '', '2014-06-15 05:48:37'),
(365, 3, 1, 328, 0, '', '0000-00-00', '', '2014-06-15 05:48:37'),
(366, 3, 1, 329, 0, '', '0000-00-00', '', '2014-06-15 05:48:37'),
(367, 3, 1, 330, 0, '', '0000-00-00', '', '2014-06-15 05:48:37'),
(368, 3, 1, 331, 0, '', '0000-00-00', '', '2014-06-15 05:48:37'),
(369, 3, 1, 332, 0, '', '0000-00-00', '', '2014-06-15 05:48:37'),
(370, 3, 1, 333, 0, '', '0000-00-00', '', '2014-06-15 05:48:37'),
(371, 4, 2, 334, 0, '', '0000-00-00', '', '2014-06-15 06:00:53'),
(372, 4, 2, 335, 0, '', '0000-00-00', '', '2014-06-15 06:00:53'),
(373, 4, 2, 336, 0, '', '0000-00-00', '', '2014-06-15 06:00:53'),
(374, 4, 2, 337, 0, '', '0000-00-00', '', '2014-06-15 06:00:53'),
(375, 4, 2, 338, 0, '', '0000-00-00', '', '2014-06-15 06:00:53'),
(376, 4, 2, 339, 0, '', '0000-00-00', '', '2014-06-15 06:00:53'),
(377, 4, 2, 340, 0, '', '0000-00-00', '', '2014-06-15 06:00:53'),
(378, 4, 2, 341, 0, '', '0000-00-00', '', '2014-06-15 06:00:53'),
(379, 4, 2, 342, 0, '', '0000-00-00', '', '2014-06-15 06:00:53'),
(380, 4, 2, 343, 0, '', '0000-00-00', '', '2014-06-15 06:00:53'),
(381, 5, 3, 344, 0, '', '0000-00-00', '', '2014-06-15 06:09:09'),
(382, 5, 3, 345, 0, '', '0000-00-00', '', '2014-06-15 06:09:09'),
(383, 5, 3, 346, 0, '', '0000-00-00', '', '2014-06-15 06:09:09'),
(384, 5, 3, 347, 0, '', '0000-00-00', '', '2014-06-15 06:09:09'),
(385, 5, 3, 348, 0, '', '0000-00-00', '', '2014-06-15 06:09:09'),
(386, 5, 3, 349, 0, '', '0000-00-00', '', '2014-06-15 06:09:09'),
(387, 5, 3, 350, 0, '', '0000-00-00', '', '2014-06-15 06:09:09'),
(388, 5, 3, 351, 0, '', '0000-00-00', '', '2014-06-15 06:09:09'),
(389, 5, 3, 352, 0, '', '0000-00-00', '', '2014-06-15 06:09:09'),
(390, 5, 3, 353, 0, '', '0000-00-00', '', '2014-06-15 06:09:09'),
(391, 6, 4, 354, 0, '', '0000-00-00', '', '2014-06-15 06:17:18'),
(392, 6, 4, 355, 0, '', '0000-00-00', '', '2014-06-15 06:17:18'),
(393, 6, 4, 356, 0, '', '0000-00-00', '', '2014-06-15 06:17:18'),
(394, 6, 4, 357, 0, '', '0000-00-00', '', '2014-06-15 06:17:18'),
(395, 6, 4, 358, 0, '', '0000-00-00', '', '2014-06-15 06:17:18'),
(396, 6, 4, 359, 0, '', '0000-00-00', '', '2014-06-15 06:17:18'),
(397, 6, 4, 360, 0, '', '0000-00-00', '', '2014-06-15 06:17:18'),
(398, 6, 4, 361, 0, '', '0000-00-00', '', '2014-06-15 06:17:18'),
(399, 6, 4, 362, 0, '', '0000-00-00', '', '2014-06-15 06:17:18'),
(400, 6, 4, 363, 0, '', '0000-00-00', '', '2014-06-15 06:17:18'),
(401, 7, 5, 364, 0, '', '0000-00-00', '', '2014-06-15 06:28:34'),
(402, 7, 5, 365, 0, '', '0000-00-00', '', '2014-06-15 06:28:34'),
(403, 7, 5, 366, 0, '', '0000-00-00', '', '2014-06-15 06:28:34'),
(404, 7, 5, 367, 0, '', '0000-00-00', '', '2014-06-15 06:28:34'),
(405, 7, 5, 368, 0, '', '0000-00-00', '', '2014-06-15 06:28:34'),
(406, 7, 5, 369, 0, '', '0000-00-00', '', '2014-06-15 06:28:34'),
(407, 7, 5, 370, 0, '', '0000-00-00', '', '2014-06-15 06:28:34'),
(408, 7, 5, 371, 0, '', '0000-00-00', '', '2014-06-15 06:28:34'),
(409, 7, 5, 372, 0, '', '0000-00-00', '', '2014-06-15 06:28:34'),
(410, 7, 5, 373, 0, '', '0000-00-00', '', '2014-06-15 06:28:34'),
(411, 8, 6, 374, 0, '', '0000-00-00', '', '2014-06-15 06:34:40'),
(412, 8, 6, 375, 0, '', '0000-00-00', '', '2014-06-15 06:34:40'),
(413, 8, 6, 376, 0, '', '0000-00-00', '', '2014-06-15 06:34:40'),
(414, 8, 6, 377, 0, '', '0000-00-00', '', '2014-06-15 06:34:40'),
(415, 8, 6, 378, 0, '', '0000-00-00', '', '2014-06-15 06:34:40'),
(416, 8, 6, 379, 0, '', '0000-00-00', '', '2014-06-15 06:34:40'),
(417, 8, 6, 380, 0, '', '0000-00-00', '', '2014-06-15 06:34:40'),
(418, 8, 6, 381, 0, '', '0000-00-00', '', '2014-06-15 06:34:40'),
(419, 8, 6, 382, 0, '', '0000-00-00', '', '2014-06-15 06:34:40'),
(420, 8, 6, 383, 0, '', '0000-00-00', '', '2014-06-15 06:34:40'),
(421, 9, 7, 384, 0, '', '0000-00-00', '', '2014-06-15 06:54:53'),
(422, 9, 7, 385, 0, '', '0000-00-00', '', '2014-06-15 06:54:53'),
(423, 9, 7, 386, 0, '', '0000-00-00', '', '2014-06-15 06:54:53'),
(424, 9, 7, 387, 0, '', '0000-00-00', '', '2014-06-15 06:54:53'),
(425, 9, 7, 388, 0, '', '0000-00-00', '', '2014-06-15 06:54:53'),
(426, 9, 7, 389, 0, '', '0000-00-00', '', '2014-06-15 06:54:53'),
(427, 9, 7, 390, 0, '', '0000-00-00', '', '2014-06-15 06:54:53'),
(428, 9, 7, 391, 0, '', '0000-00-00', '', '2014-06-15 06:54:53'),
(429, 9, 7, 392, 0, '', '0000-00-00', '', '2014-06-15 06:54:53'),
(430, 9, 7, 393, 0, '', '0000-00-00', '', '2014-06-15 06:54:53'),
(431, 10, 8, 394, 0, '', '0000-00-00', '', '2014-06-15 07:15:59'),
(432, 10, 8, 395, 0, '', '0000-00-00', '', '2014-06-15 07:15:59'),
(433, 10, 8, 396, 0, '', '0000-00-00', '', '2014-06-15 07:15:59'),
(434, 10, 8, 397, 0, '', '0000-00-00', '', '2014-06-15 07:15:59'),
(435, 10, 8, 398, 0, '', '0000-00-00', '', '2014-06-15 07:15:59'),
(436, 10, 8, 399, 0, '', '0000-00-00', '', '2014-06-15 07:15:59'),
(437, 10, 8, 400, 0, '', '0000-00-00', '', '2014-06-15 07:15:59'),
(438, 10, 8, 401, 0, '', '0000-00-00', '', '2014-06-15 07:15:59'),
(439, 10, 8, 402, 0, '', '0000-00-00', '', '2014-06-15 07:15:59'),
(440, 10, 8, 403, 0, '', '0000-00-00', '', '2014-06-15 07:15:59'),
(441, 3, 1, 404, 0, '', '0000-00-00', '', '2014-06-18 02:04:42'),
(442, 3, 1, 405, 0, '', '0000-00-00', '', '2014-06-18 02:04:42'),
(443, 3, 1, 406, 0, '', '0000-00-00', '', '2014-06-18 02:04:42'),
(444, 3, 1, 407, 0, '', '0000-00-00', '', '2014-06-18 02:04:42'),
(445, 3, 1, 408, 0, '', '0000-00-00', '', '2014-06-18 02:04:42'),
(446, 3, 1, 409, 0, '', '0000-00-00', '', '2014-06-18 02:04:42'),
(447, 3, 1, 410, 0, '', '0000-00-00', '', '2014-06-18 02:04:42'),
(448, 3, 1, 411, 0, '', '0000-00-00', '', '2014-06-18 02:04:42'),
(449, 3, 1, 412, 0, '', '0000-00-00', '', '2014-06-18 02:04:42'),
(450, 3, 1, 413, 0, '', '0000-00-00', '', '2014-06-18 02:04:42'),
(451, 4, 2, 404, 0, '', '0000-00-00', '', '2014-06-18 02:04:58'),
(452, 4, 2, 405, 0, '', '0000-00-00', '', '2014-06-18 02:04:58'),
(453, 4, 2, 406, 0, '', '0000-00-00', '', '2014-06-18 02:04:58'),
(454, 4, 2, 407, 0, '', '0000-00-00', '', '2014-06-18 02:04:58'),
(455, 4, 2, 408, 0, '', '0000-00-00', '', '2014-06-18 02:04:58'),
(456, 4, 2, 409, 0, '', '0000-00-00', '', '2014-06-18 02:04:58'),
(457, 4, 2, 410, 0, '', '0000-00-00', '', '2014-06-18 02:04:58'),
(458, 4, 2, 411, 0, '', '0000-00-00', '', '2014-06-18 02:04:58'),
(459, 4, 2, 412, 0, '', '0000-00-00', '', '2014-06-18 02:04:58'),
(460, 4, 2, 413, 0, '', '0000-00-00', '', '2014-06-18 02:04:58'),
(461, 5, 3, 404, 0, '', '0000-00-00', '', '2014-06-18 02:05:12'),
(462, 5, 3, 405, 0, '', '0000-00-00', '', '2014-06-18 02:05:12'),
(463, 5, 3, 406, 0, '', '0000-00-00', '', '2014-06-18 02:05:12'),
(464, 5, 3, 407, 0, '', '0000-00-00', '', '2014-06-18 02:05:12'),
(465, 5, 3, 408, 0, '', '0000-00-00', '', '2014-06-18 02:05:12'),
(466, 5, 3, 409, 0, '', '0000-00-00', '', '2014-06-18 02:05:12'),
(467, 5, 3, 410, 0, '', '0000-00-00', '', '2014-06-18 02:05:12'),
(468, 5, 3, 411, 0, '', '0000-00-00', '', '2014-06-18 02:05:12'),
(469, 5, 3, 412, 0, '', '0000-00-00', '', '2014-06-18 02:05:12'),
(470, 5, 3, 413, 0, '', '0000-00-00', '', '2014-06-18 02:05:12'),
(471, 6, 4, 404, 0, '', '0000-00-00', '', '2014-06-18 02:05:26'),
(472, 6, 4, 405, 0, '', '0000-00-00', '', '2014-06-18 02:05:26'),
(473, 6, 4, 406, 0, '', '0000-00-00', '', '2014-06-18 02:05:27'),
(474, 6, 4, 407, 0, '', '0000-00-00', '', '2014-06-18 02:05:27'),
(475, 6, 4, 408, 0, '', '0000-00-00', '', '2014-06-18 02:05:27'),
(476, 6, 4, 409, 0, '', '0000-00-00', '', '2014-06-18 02:05:27'),
(477, 6, 4, 410, 0, '', '0000-00-00', '', '2014-06-18 02:05:27'),
(478, 6, 4, 411, 0, '', '0000-00-00', '', '2014-06-18 02:05:27'),
(479, 6, 4, 412, 0, '', '0000-00-00', '', '2014-06-18 02:05:27'),
(480, 6, 4, 413, 0, '', '0000-00-00', '', '2014-06-18 02:05:27'),
(481, 8, 6, 404, 0, '', '0000-00-00', '', '2014-06-18 02:06:28'),
(482, 8, 6, 405, 0, '', '0000-00-00', '', '2014-06-18 02:06:28'),
(483, 8, 6, 406, 0, '', '0000-00-00', '', '2014-06-18 02:06:28'),
(484, 8, 6, 407, 0, '', '0000-00-00', '', '2014-06-18 02:06:28'),
(485, 8, 6, 408, 0, '', '0000-00-00', '', '2014-06-18 02:06:28'),
(486, 8, 6, 409, 0, '', '0000-00-00', '', '2014-06-18 02:06:28'),
(487, 8, 6, 410, 0, '', '0000-00-00', '', '2014-06-18 02:06:28'),
(488, 8, 6, 411, 0, '', '0000-00-00', '', '2014-06-18 02:06:28'),
(489, 8, 6, 412, 0, '', '0000-00-00', '', '2014-06-18 02:06:28'),
(490, 8, 6, 413, 0, '', '0000-00-00', '', '2014-06-18 02:06:28'),
(491, 9, 7, 404, 0, '', '0000-00-00', '', '2014-06-18 02:06:54'),
(492, 9, 7, 405, 0, '', '0000-00-00', '', '2014-06-18 02:06:54'),
(493, 9, 7, 406, 0, '', '0000-00-00', '', '2014-06-18 02:06:54'),
(494, 9, 7, 407, 0, '', '0000-00-00', '', '2014-06-18 02:06:54'),
(495, 9, 7, 408, 0, '', '0000-00-00', '', '2014-06-18 02:06:54'),
(496, 9, 7, 409, 0, '', '0000-00-00', '', '2014-06-18 02:06:54'),
(497, 9, 7, 410, 0, '', '0000-00-00', '', '2014-06-18 02:06:54'),
(498, 9, 7, 411, 0, '', '0000-00-00', '', '2014-06-18 02:06:54'),
(499, 9, 7, 412, 0, '', '0000-00-00', '', '2014-06-18 02:06:54'),
(500, 9, 7, 413, 0, '', '0000-00-00', '', '2014-06-18 02:06:54'),
(501, 10, 8, 404, 0, '', '0000-00-00', '', '2014-06-18 02:07:07'),
(502, 10, 8, 405, 0, '', '0000-00-00', '', '2014-06-18 02:07:07'),
(503, 10, 8, 406, 0, '', '0000-00-00', '', '2014-06-18 02:07:07'),
(504, 10, 8, 407, 0, '', '0000-00-00', '', '2014-06-18 02:07:07'),
(505, 10, 8, 408, 0, '', '0000-00-00', '', '2014-06-18 02:07:07'),
(506, 10, 8, 409, 0, '', '0000-00-00', '', '2014-06-18 02:07:07'),
(507, 10, 8, 410, 0, '', '0000-00-00', '', '2014-06-18 02:07:07'),
(508, 10, 8, 411, 0, '', '0000-00-00', '', '2014-06-18 02:07:07'),
(509, 10, 8, 412, 0, '', '0000-00-00', '', '2014-06-18 02:07:07'),
(510, 10, 8, 413, 0, '', '0000-00-00', '', '2014-06-18 02:07:07'),
(631, 7, 5, 404, 0, '', '0000-00-00', '', '2014-06-23 18:58:05'),
(632, 7, 5, 405, 0, '', '0000-00-00', '', '2014-06-23 18:58:06'),
(633, 7, 5, 406, 0, '', '0000-00-00', '', '2014-06-23 18:58:06'),
(634, 7, 5, 407, 0, '', '0000-00-00', '', '2014-06-23 18:58:06'),
(635, 7, 5, 408, 0, '', '0000-00-00', '', '2014-06-23 18:58:06'),
(636, 7, 5, 409, 0, '', '0000-00-00', '', '2014-06-23 18:58:06'),
(637, 7, 5, 410, 0, '', '0000-00-00', '', '2014-06-23 18:58:06'),
(638, 7, 5, 411, 0, '', '0000-00-00', '', '2014-06-23 18:58:06'),
(639, 7, 5, 412, 0, '', '0000-00-00', '', '2014-06-23 18:58:06'),
(640, 7, 5, 413, 0, '', '0000-00-00', '', '2014-06-23 18:58:06'),
(641, 3, 14, 1, 0, '', '0000-00-00', '', '2014-07-06 18:40:00'),
(642, 3, 14, 2, 0, '', '0000-00-00', '', '2014-07-06 18:40:01'),
(643, 3, 14, 3, 0, '', '0000-00-00', '', '2014-07-06 18:40:02'),
(644, 3, 14, 4, 0, '', '0000-00-00', '', '2014-07-06 18:40:02'),
(645, 3, 14, 5, 0, '', '0000-00-00', '', '2014-07-06 18:40:02'),
(646, 3, 14, 6, 0, '', '0000-00-00', '', '2014-07-06 18:40:02'),
(647, 3, 14, 9, 0, '', '0000-00-00', '', '2014-07-06 18:40:02'),
(648, 3, 14, 10, 0, '', '0000-00-00', '', '2014-07-06 18:40:02'),
(649, 3, 14, 11, 0, '', '0000-00-00', '', '2014-07-06 18:40:02'),
(650, 3, 14, 12, 0, '', '0000-00-00', '', '2014-07-06 18:40:02'),
(651, 3, 14, 15, 0, '', '0000-00-00', '', '2014-07-06 18:40:02'),
(652, 3, 14, 16, 0, '', '0000-00-00', '', '2014-07-06 18:40:02'),
(653, 3, 14, 19, 0, '', '0000-00-00', '', '2014-07-06 18:40:02'),
(654, 3, 14, 20, 0, '', '0000-00-00', '', '2014-07-06 18:40:02'),
(655, 3, 14, 21, 0, '', '0000-00-00', '', '2014-07-06 18:40:02'),
(656, 3, 14, 22, 0, '', '0000-00-00', '', '2014-07-06 18:40:02'),
(657, 3, 14, 23, 0, '', '0000-00-00', '', '2014-07-06 18:40:02'),
(658, 3, 14, 24, 0, '', '0000-00-00', '', '2014-07-06 18:40:02'),
(659, 3, 14, 27, 0, '', '0000-00-00', '', '2014-07-06 18:40:02'),
(660, 3, 14, 28, 0, '', '0000-00-00', '', '2014-07-06 18:40:02'),
(661, 3, 14, 29, 0, '', '0000-00-00', '', '2014-07-06 18:40:02'),
(662, 3, 14, 30, 0, '', '0000-00-00', '', '2014-07-06 18:40:02'),
(663, 3, 14, 31, 0, '', '0000-00-00', '', '2014-07-06 18:40:02'),
(664, 3, 14, 32, 0, '', '0000-00-00', '', '2014-07-06 18:40:02'),
(665, 3, 14, 35, 0, '', '0000-00-00', '', '2014-07-06 18:40:02'),
(666, 3, 14, 36, 0, '', '0000-00-00', '', '2014-07-06 18:40:02'),
(667, 3, 14, 37, 0, '', '0000-00-00', '', '2014-07-06 18:40:02'),
(668, 3, 14, 38, 0, '', '0000-00-00', '', '2014-07-06 18:40:02'),
(669, 3, 14, 39, 0, '', '0000-00-00', '', '2014-07-06 18:40:02'),
(670, 3, 14, 40, 0, '', '0000-00-00', '', '2014-07-06 18:40:02'),
(671, 4, 15, 43, 0, '', '0000-00-00', '', '2014-07-06 18:41:49'),
(672, 4, 15, 44, 0, '', '0000-00-00', '', '2014-07-06 18:41:49'),
(673, 4, 15, 45, 0, '', '0000-00-00', '', '2014-07-06 18:41:49'),
(674, 4, 15, 46, 0, '', '0000-00-00', '', '2014-07-06 18:41:49'),
(675, 4, 15, 47, 0, '', '0000-00-00', '', '2014-07-06 18:41:49'),
(676, 4, 15, 48, 0, '', '0000-00-00', '', '2014-07-06 18:41:49'),
(677, 4, 15, 51, 0, '', '0000-00-00', '', '2014-07-06 18:41:49'),
(678, 4, 15, 52, 0, '', '0000-00-00', '', '2014-07-06 18:41:49'),
(679, 4, 15, 53, 0, '', '0000-00-00', '', '2014-07-06 18:41:49'),
(680, 4, 15, 54, 0, '', '0000-00-00', '', '2014-07-06 18:41:49'),
(681, 4, 15, 55, 0, '', '0000-00-00', '', '2014-07-06 18:41:49'),
(682, 4, 15, 56, 0, '', '0000-00-00', '', '2014-07-06 18:41:49'),
(683, 4, 15, 59, 0, '', '0000-00-00', '', '2014-07-06 18:41:49'),
(684, 4, 15, 60, 0, '', '0000-00-00', '', '2014-07-06 18:41:49'),
(685, 4, 15, 61, 0, '', '0000-00-00', '', '2014-07-06 18:41:49'),
(686, 4, 15, 62, 0, '', '0000-00-00', '', '2014-07-06 18:41:49'),
(687, 4, 15, 63, 0, '', '0000-00-00', '', '2014-07-06 18:41:49'),
(688, 4, 15, 64, 0, '', '0000-00-00', '', '2014-07-06 18:41:49'),
(689, 4, 15, 67, 0, '', '0000-00-00', '', '2014-07-06 18:41:49'),
(690, 4, 15, 68, 0, '', '0000-00-00', '', '2014-07-06 18:41:49'),
(691, 4, 15, 69, 0, '', '0000-00-00', '', '2014-07-06 18:41:49'),
(692, 4, 15, 70, 0, '', '0000-00-00', '', '2014-07-06 18:41:49'),
(693, 4, 15, 71, 0, '', '0000-00-00', '', '2014-07-06 18:41:49'),
(694, 4, 15, 72, 0, '', '0000-00-00', '', '2014-07-06 18:41:49'),
(695, 4, 15, 75, 0, '', '0000-00-00', '', '2014-07-06 18:41:49'),
(696, 4, 15, 76, 0, '', '0000-00-00', '', '2014-07-06 18:41:49'),
(697, 4, 15, 77, 0, '', '0000-00-00', '', '2014-07-06 18:41:49'),
(698, 4, 15, 78, 0, '', '0000-00-00', '', '2014-07-06 18:41:49'),
(699, 4, 15, 79, 0, '', '0000-00-00', '', '2014-07-06 18:41:49'),
(700, 5, 16, 83, 0, '', '0000-00-00', '', '2014-07-06 18:42:59'),
(701, 5, 16, 84, 0, '', '0000-00-00', '', '2014-07-06 18:43:00'),
(702, 5, 16, 85, 0, '', '0000-00-00', '', '2014-07-06 18:43:00'),
(703, 5, 16, 86, 0, '', '0000-00-00', '', '2014-07-06 18:43:00'),
(704, 5, 16, 87, 0, '', '0000-00-00', '', '2014-07-06 18:43:00'),
(705, 5, 16, 88, 0, '', '0000-00-00', '', '2014-07-06 18:43:00'),
(706, 5, 16, 91, 0, '', '0000-00-00', '', '2014-07-06 18:43:00'),
(707, 5, 16, 92, 0, '', '0000-00-00', '', '2014-07-06 18:43:00'),
(708, 5, 16, 93, 0, '', '0000-00-00', '', '2014-07-06 18:43:00'),
(709, 5, 16, 94, 0, '', '0000-00-00', '', '2014-07-06 18:43:00'),
(710, 5, 16, 95, 0, '', '0000-00-00', '', '2014-07-06 18:43:00'),
(711, 5, 16, 96, 0, '', '0000-00-00', '', '2014-07-06 18:43:00'),
(712, 5, 16, 99, 0, '', '0000-00-00', '', '2014-07-06 18:43:00'),
(713, 5, 16, 100, 0, '', '0000-00-00', '', '2014-07-06 18:43:00'),
(714, 5, 16, 101, 0, '', '0000-00-00', '', '2014-07-06 18:43:00'),
(715, 5, 16, 102, 0, '', '0000-00-00', '', '2014-07-06 18:43:00'),
(716, 5, 16, 103, 0, '', '0000-00-00', '', '2014-07-06 18:43:00'),
(717, 5, 16, 104, 0, '', '0000-00-00', '', '2014-07-06 18:43:00'),
(718, 5, 16, 107, 0, '', '0000-00-00', '', '2014-07-06 18:43:00'),
(719, 5, 16, 108, 0, '', '0000-00-00', '', '2014-07-06 18:43:00'),
(720, 5, 16, 109, 0, '', '0000-00-00', '', '2014-07-06 18:43:00'),
(721, 5, 16, 110, 0, '', '0000-00-00', '', '2014-07-06 18:43:00'),
(722, 5, 16, 111, 0, '', '0000-00-00', '', '2014-07-06 18:43:00'),
(723, 5, 16, 112, 0, '', '0000-00-00', '', '2014-07-06 18:43:00'),
(724, 5, 16, 115, 0, '', '0000-00-00', '', '2014-07-06 18:43:00'),
(725, 5, 16, 116, 0, '', '0000-00-00', '', '2014-07-06 18:43:00'),
(726, 5, 16, 117, 0, '', '0000-00-00', '', '2014-07-06 18:43:00'),
(727, 5, 16, 118, 0, '', '0000-00-00', '', '2014-07-06 18:43:00'),
(728, 5, 16, 119, 0, '', '0000-00-00', '', '2014-07-06 18:43:00'),
(729, 5, 16, 120, 0, '', '0000-00-00', '', '2014-07-06 18:43:00'),
(730, 6, 17, 123, 0, '', '0000-00-00', '', '2014-07-06 18:44:10'),
(731, 6, 17, 124, 0, '', '0000-00-00', '', '2014-07-06 18:44:10'),
(732, 6, 17, 125, 0, '', '0000-00-00', '', '2014-07-06 18:44:10'),
(733, 6, 17, 126, 0, '', '0000-00-00', '', '2014-07-06 18:44:10'),
(734, 6, 17, 127, 0, '', '0000-00-00', '', '2014-07-06 18:44:10'),
(735, 6, 17, 128, 0, '', '0000-00-00', '', '2014-07-06 18:44:10'),
(736, 6, 17, 131, 0, '', '0000-00-00', '', '2014-07-06 18:44:10'),
(737, 6, 17, 132, 0, '', '0000-00-00', '', '2014-07-06 18:44:10'),
(738, 6, 17, 133, 0, '', '0000-00-00', '', '2014-07-06 18:44:10'),
(739, 6, 17, 134, 0, '', '0000-00-00', '', '2014-07-06 18:44:10'),
(740, 6, 17, 135, 0, '', '0000-00-00', '', '2014-07-06 18:44:10'),
(741, 6, 17, 136, 0, '', '0000-00-00', '', '2014-07-06 18:44:10'),
(742, 6, 17, 139, 0, '', '0000-00-00', '', '2014-07-06 18:44:10'),
(743, 6, 17, 140, 0, '', '0000-00-00', '', '2014-07-06 18:44:10'),
(744, 6, 17, 141, 0, '', '0000-00-00', '', '2014-07-06 18:44:10'),
(745, 6, 17, 142, 0, '', '0000-00-00', '', '2014-07-06 18:44:10'),
(746, 6, 17, 143, 0, '', '0000-00-00', '', '2014-07-06 18:44:10'),
(747, 6, 17, 144, 0, '', '0000-00-00', '', '2014-07-06 18:44:10'),
(748, 6, 17, 147, 0, '', '0000-00-00', '', '2014-07-06 18:44:10'),
(749, 6, 17, 148, 0, '', '0000-00-00', '', '2014-07-06 18:44:10'),
(750, 6, 17, 149, 0, '', '0000-00-00', '', '2014-07-06 18:44:10'),
(751, 6, 17, 150, 0, '', '0000-00-00', '', '2014-07-06 18:44:10'),
(752, 6, 17, 151, 0, '', '0000-00-00', '', '2014-07-06 18:44:10'),
(753, 6, 17, 152, 0, '', '0000-00-00', '', '2014-07-06 18:44:10'),
(754, 6, 17, 155, 0, '', '0000-00-00', '', '2014-07-06 18:44:10'),
(755, 6, 17, 156, 0, '', '0000-00-00', '', '2014-07-06 18:44:10'),
(756, 6, 17, 157, 0, '', '0000-00-00', '', '2014-07-06 18:44:10'),
(757, 6, 17, 158, 0, '', '0000-00-00', '', '2014-07-06 18:44:10'),
(758, 6, 17, 159, 0, '', '0000-00-00', '', '2014-07-06 18:44:10'),
(759, 6, 17, 160, 0, '', '0000-00-00', '', '2014-07-06 18:44:10'),
(760, 7, 18, 163, 0, '', '0000-00-00', '', '2014-07-06 18:51:58'),
(761, 7, 18, 164, 0, '', '0000-00-00', '', '2014-07-06 18:51:58'),
(762, 7, 18, 165, 0, '', '0000-00-00', '', '2014-07-06 18:51:58'),
(763, 7, 18, 166, 0, '', '0000-00-00', '', '2014-07-06 18:51:58'),
(764, 7, 18, 167, 0, '', '0000-00-00', '', '2014-07-06 18:51:58'),
(765, 7, 18, 168, 0, '', '0000-00-00', '', '2014-07-06 18:51:58'),
(766, 7, 18, 171, 0, '', '0000-00-00', '', '2014-07-06 18:51:58'),
(767, 7, 18, 172, 0, '', '0000-00-00', '', '2014-07-06 18:51:58'),
(768, 7, 18, 173, 0, '', '0000-00-00', '', '2014-07-06 18:51:58'),
(769, 7, 18, 174, 0, '', '0000-00-00', '', '2014-07-06 18:51:58'),
(770, 7, 18, 175, 0, '', '0000-00-00', '', '2014-07-06 18:51:58'),
(771, 7, 18, 176, 0, '', '0000-00-00', '', '2014-07-06 18:51:58'),
(772, 7, 18, 187, 0, '', '0000-00-00', '', '2014-07-06 18:51:58'),
(773, 7, 18, 188, 0, '', '0000-00-00', '', '2014-07-06 18:51:58'),
(774, 7, 18, 189, 0, '', '0000-00-00', '', '2014-07-06 18:51:58'),
(775, 7, 18, 190, 0, '', '0000-00-00', '', '2014-07-06 18:51:58'),
(776, 7, 18, 191, 0, '', '0000-00-00', '', '2014-07-06 18:51:58'),
(777, 7, 18, 192, 0, '', '0000-00-00', '', '2014-07-06 18:51:58'),
(778, 7, 18, 195, 0, '', '0000-00-00', '', '2014-07-06 18:51:58'),
(779, 7, 18, 196, 0, '', '0000-00-00', '', '2014-07-06 18:51:58'),
(780, 7, 18, 197, 0, '', '0000-00-00', '', '2014-07-06 18:51:58'),
(781, 7, 18, 198, 0, '', '0000-00-00', '', '2014-07-06 18:51:58'),
(782, 7, 18, 199, 0, '', '0000-00-00', '', '2014-07-06 18:51:58'),
(783, 7, 18, 200, 0, '', '0000-00-00', '', '2014-07-06 18:51:58'),
(784, 8, 19, 203, 0, '', '0000-00-00', '', '2014-07-06 18:53:47'),
(785, 8, 19, 204, 0, '', '0000-00-00', '', '2014-07-06 18:53:47'),
(786, 8, 19, 205, 0, '', '0000-00-00', '', '2014-07-06 18:53:47'),
(787, 8, 19, 206, 0, '', '0000-00-00', '', '2014-07-06 18:53:47'),
(788, 8, 19, 207, 0, '', '0000-00-00', '', '2014-07-06 18:53:47'),
(789, 8, 19, 208, 0, '', '0000-00-00', '', '2014-07-06 18:53:47'),
(790, 8, 19, 211, 0, '', '0000-00-00', '', '2014-07-06 18:53:47'),
(791, 8, 19, 212, 0, '', '0000-00-00', '', '2014-07-06 18:53:47'),
(792, 8, 19, 213, 0, '', '0000-00-00', '', '2014-07-06 18:53:47'),
(793, 8, 19, 214, 0, '', '0000-00-00', '', '2014-07-06 18:53:47'),
(794, 8, 19, 215, 0, '', '0000-00-00', '', '2014-07-06 18:53:47'),
(795, 8, 19, 216, 0, '', '0000-00-00', '', '2014-07-06 18:53:47'),
(796, 8, 19, 219, 0, '', '0000-00-00', '', '2014-07-06 18:53:47'),
(797, 8, 19, 220, 0, '', '0000-00-00', '', '2014-07-06 18:53:47'),
(798, 8, 19, 221, 0, '', '0000-00-00', '', '2014-07-06 18:53:47'),
(799, 8, 19, 222, 0, '', '0000-00-00', '', '2014-07-06 18:53:47'),
(800, 8, 19, 223, 0, '', '0000-00-00', '', '2014-07-06 18:53:47'),
(801, 8, 19, 224, 0, '', '0000-00-00', '', '2014-07-06 18:53:47'),
(802, 8, 19, 227, 0, '', '0000-00-00', '', '2014-07-06 18:53:47'),
(803, 8, 19, 228, 0, '', '0000-00-00', '', '2014-07-06 18:53:47'),
(804, 8, 19, 229, 0, '', '0000-00-00', '', '2014-07-06 18:53:47'),
(805, 8, 19, 230, 0, '', '0000-00-00', '', '2014-07-06 18:53:47'),
(806, 8, 19, 231, 0, '', '0000-00-00', '', '2014-07-06 18:53:47'),
(807, 8, 19, 232, 0, '', '0000-00-00', '', '2014-07-06 18:53:47'),
(808, 8, 19, 235, 0, '', '0000-00-00', '', '2014-07-06 18:53:47'),
(809, 8, 19, 236, 0, '', '0000-00-00', '', '2014-07-06 18:53:47'),
(810, 8, 19, 237, 0, '', '0000-00-00', '', '2014-07-06 18:53:47'),
(811, 8, 19, 238, 0, '', '0000-00-00', '', '2014-07-06 18:53:47'),
(812, 8, 19, 239, 0, '', '0000-00-00', '', '2014-07-06 18:53:47'),
(813, 8, 19, 240, 0, '', '0000-00-00', '', '2014-07-06 18:53:47'),
(814, 9, 20, 243, 0, '', '0000-00-00', '', '2014-07-06 18:54:45'),
(815, 9, 20, 244, 0, '', '0000-00-00', '', '2014-07-06 18:54:45'),
(816, 9, 20, 245, 0, '', '0000-00-00', '', '2014-07-06 18:54:45'),
(817, 9, 20, 246, 0, '', '0000-00-00', '', '2014-07-06 18:54:45'),
(818, 9, 20, 247, 0, '', '0000-00-00', '', '2014-07-06 18:54:45'),
(819, 9, 20, 248, 0, '', '0000-00-00', '', '2014-07-06 18:54:45'),
(820, 9, 20, 251, 0, '', '0000-00-00', '', '2014-07-06 18:54:45'),
(821, 9, 20, 252, 0, '', '0000-00-00', '', '2014-07-06 18:54:45'),
(822, 9, 20, 253, 0, '', '0000-00-00', '', '2014-07-06 18:54:45'),
(823, 9, 20, 254, 0, '', '0000-00-00', '', '2014-07-06 18:54:45'),
(824, 9, 20, 255, 0, '', '0000-00-00', '', '2014-07-06 18:54:45'),
(825, 9, 20, 256, 0, '', '0000-00-00', '', '2014-07-06 18:54:45'),
(826, 9, 20, 259, 0, '', '0000-00-00', '', '2014-07-06 18:54:45'),
(827, 9, 20, 260, 0, '', '0000-00-00', '', '2014-07-06 18:54:45'),
(828, 9, 20, 261, 0, '', '0000-00-00', '', '2014-07-06 18:54:45'),
(829, 9, 20, 262, 0, '', '0000-00-00', '', '2014-07-06 18:54:45'),
(830, 9, 20, 263, 0, '', '0000-00-00', '', '2014-07-06 18:54:45'),
(831, 9, 20, 264, 0, '', '0000-00-00', '', '2014-07-06 18:54:45'),
(832, 9, 20, 267, 0, '', '0000-00-00', '', '2014-07-06 18:54:45'),
(833, 9, 20, 268, 0, '', '0000-00-00', '', '2014-07-06 18:54:45'),
(834, 9, 20, 269, 0, '', '0000-00-00', '', '2014-07-06 18:54:45'),
(835, 9, 20, 270, 0, '', '0000-00-00', '', '2014-07-06 18:54:45'),
(836, 9, 20, 271, 0, '', '0000-00-00', '', '2014-07-06 18:54:45'),
(837, 9, 20, 272, 0, '', '0000-00-00', '', '2014-07-06 18:54:45'),
(838, 9, 20, 275, 0, '', '0000-00-00', '', '2014-07-06 18:54:45'),
(839, 9, 20, 276, 0, '', '0000-00-00', '', '2014-07-06 18:54:45'),
(840, 9, 20, 277, 0, '', '0000-00-00', '', '2014-07-06 18:54:45'),
(841, 9, 20, 278, 0, '', '0000-00-00', '', '2014-07-06 18:54:45'),
(842, 9, 20, 279, 0, '', '0000-00-00', '', '2014-07-06 18:54:45'),
(843, 9, 20, 280, 0, '', '0000-00-00', '', '2014-07-06 18:54:45'),
(844, 10, 21, 283, 0, '', '0000-00-00', '', '2014-07-06 18:55:46'),
(845, 10, 21, 284, 0, '', '0000-00-00', '', '2014-07-06 18:55:46'),
(846, 10, 21, 285, 0, '', '0000-00-00', '', '2014-07-06 18:55:46'),
(847, 10, 21, 286, 0, '', '0000-00-00', '', '2014-07-06 18:55:46'),
(848, 10, 21, 287, 0, '', '0000-00-00', '', '2014-07-06 18:55:46'),
(849, 10, 21, 288, 0, '', '0000-00-00', '', '2014-07-06 18:55:46'),
(850, 10, 21, 291, 0, '', '0000-00-00', '', '2014-07-06 18:55:46'),
(851, 10, 21, 292, 0, '', '0000-00-00', '', '2014-07-06 18:55:46'),
(852, 10, 21, 293, 0, '', '0000-00-00', '', '2014-07-06 18:55:46'),
(853, 10, 21, 294, 0, '', '0000-00-00', '', '2014-07-06 18:55:46'),
(854, 10, 21, 295, 0, '', '0000-00-00', '', '2014-07-06 18:55:46'),
(855, 10, 21, 296, 0, '', '0000-00-00', '', '2014-07-06 18:55:46'),
(856, 10, 21, 299, 0, '', '0000-00-00', '', '2014-07-06 18:55:46'),
(857, 10, 21, 300, 0, '', '0000-00-00', '', '2014-07-06 18:55:46'),
(858, 10, 21, 301, 0, '', '0000-00-00', '', '2014-07-06 18:55:46'),
(859, 10, 21, 302, 0, '', '0000-00-00', '', '2014-07-06 18:55:46'),
(860, 10, 21, 303, 0, '', '0000-00-00', '', '2014-07-06 18:55:46'),
(861, 10, 21, 304, 0, '', '0000-00-00', '', '2014-07-06 18:55:46'),
(862, 10, 21, 308, 0, '', '0000-00-00', '', '2014-07-06 18:55:46'),
(863, 10, 21, 309, 0, '', '0000-00-00', '', '2014-07-06 18:55:46'),
(864, 10, 21, 310, 0, '', '0000-00-00', '', '2014-07-06 18:55:46'),
(865, 10, 21, 311, 0, '', '0000-00-00', '', '2014-07-06 18:55:46'),
(866, 10, 21, 312, 0, '', '0000-00-00', '', '2014-07-06 18:55:46'),
(867, 10, 21, 313, 0, '', '0000-00-00', '', '2014-07-06 18:55:46'),
(868, 10, 21, 316, 0, '', '0000-00-00', '', '2014-07-06 18:55:46'),
(869, 10, 21, 317, 0, '', '0000-00-00', '', '2014-07-06 18:55:46'),
(870, 10, 21, 318, 0, '', '0000-00-00', '', '2014-07-06 18:55:46'),
(871, 10, 21, 319, 0, '', '0000-00-00', '', '2014-07-06 18:55:46'),
(872, 10, 21, 320, 0, '', '0000-00-00', '', '2014-07-06 18:55:46'),
(873, 10, 21, 321, 0, '', '0000-00-00', '', '2014-07-06 18:55:46'),
(994, 3, 24, 1, 0, '', '0000-00-00', '', '2014-07-14 14:13:24'),
(995, 3, 24, 2, 0, '', '0000-00-00', '', '2014-07-14 14:13:24'),
(996, 3, 24, 3, 0, '', '0000-00-00', '', '2014-07-14 14:13:24'),
(997, 3, 24, 4, 0, '', '0000-00-00', '', '2014-07-14 14:13:24'),
(998, 3, 24, 5, 0, '', '0000-00-00', '', '2014-07-14 14:13:24'),
(999, 3, 24, 6, 0, '', '0000-00-00', '', '2014-07-14 14:13:24'),
(1000, 3, 24, 7, 0, '', '0000-00-00', '', '2014-07-14 14:13:24'),
(1001, 3, 24, 8, 0, '', '0000-00-00', '', '2014-07-14 14:13:24'),
(1002, 3, 24, 9, 0, '', '0000-00-00', '', '2014-07-14 14:13:24'),
(1003, 3, 24, 10, 0, '', '0000-00-00', '', '2014-07-14 14:13:24'),
(1004, 3, 24, 11, 0, '', '0000-00-00', '', '2014-07-14 14:13:24'),
(1005, 3, 24, 12, 0, '', '0000-00-00', '', '2014-07-14 14:13:24'),
(1006, 3, 24, 15, 0, '', '0000-00-00', '', '2014-07-14 14:13:24'),
(1007, 3, 24, 16, 0, '', '0000-00-00', '', '2014-07-14 14:13:24'),
(1008, 3, 24, 17, 0, '', '0000-00-00', '', '2014-07-14 14:13:24'),
(1009, 3, 24, 18, 0, '', '0000-00-00', '', '2014-07-14 14:13:24'),
(1010, 3, 24, 19, 0, '', '0000-00-00', '', '2014-07-14 14:13:24'),
(1011, 3, 24, 20, 0, '', '0000-00-00', '', '2014-07-14 14:13:24'),
(1012, 3, 24, 21, 0, '', '0000-00-00', '', '2014-07-14 14:13:24'),
(1013, 3, 24, 22, 0, '', '0000-00-00', '', '2014-07-14 14:13:24'),
(1014, 3, 24, 23, 0, '', '0000-00-00', '', '2014-07-14 14:13:24'),
(1015, 3, 24, 24, 0, '', '0000-00-00', '', '2014-07-14 14:13:24'),
(1016, 3, 24, 25, 0, '', '0000-00-00', '', '2014-07-14 14:13:24'),
(1017, 3, 24, 26, 0, '', '0000-00-00', '', '2014-07-14 14:13:24'),
(1018, 3, 24, 27, 0, '', '0000-00-00', '', '2014-07-14 14:13:24'),
(1019, 3, 24, 28, 0, '', '0000-00-00', '', '2014-07-14 14:13:24'),
(1020, 3, 24, 29, 0, '', '0000-00-00', '', '2014-07-14 14:13:24'),
(1021, 3, 24, 30, 0, '', '0000-00-00', '', '2014-07-14 14:13:24'),
(1022, 3, 24, 31, 0, '', '0000-00-00', '', '2014-07-14 14:13:24'),
(1023, 3, 24, 32, 0, '', '0000-00-00', '', '2014-07-14 14:13:24'),
(1024, 3, 24, 33, 0, '', '0000-00-00', '', '2014-07-14 14:13:24'),
(1025, 3, 24, 34, 0, '', '0000-00-00', '', '2014-07-14 14:13:24'),
(1026, 3, 24, 35, 0, '', '0000-00-00', '', '2014-07-14 14:13:24'),
(1027, 3, 24, 36, 0, '', '0000-00-00', '', '2014-07-14 14:13:24'),
(1028, 3, 24, 37, 0, '', '0000-00-00', '', '2014-07-14 14:13:24'),
(1029, 3, 24, 38, 0, '', '0000-00-00', '', '2014-07-14 14:13:24'),
(1030, 3, 24, 39, 0, '', '0000-00-00', '', '2014-07-14 14:13:24'),
(1031, 3, 24, 40, 0, '', '0000-00-00', '', '2014-07-14 14:13:24'),
(1032, 3, 24, 41, 0, '', '0000-00-00', '', '2014-07-14 14:13:24'),
(1033, 3, 24, 42, 0, '', '0000-00-00', '', '2014-07-14 14:13:24'),
(1034, 3, 24, 324, 0, '', '0000-00-00', '', '2014-07-14 14:13:24'),
(1035, 3, 24, 325, 0, '', '0000-00-00', '', '2014-07-14 14:13:24'),
(1036, 3, 24, 326, 0, '', '0000-00-00', '', '2014-07-14 14:13:24'),
(1037, 3, 24, 327, 0, '', '0000-00-00', '', '2014-07-14 14:13:24'),
(1038, 3, 24, 328, 0, '', '0000-00-00', '', '2014-07-14 14:13:24'),
(1039, 3, 24, 329, 0, '', '0000-00-00', '', '2014-07-14 14:13:24'),
(1040, 3, 24, 330, 0, '', '0000-00-00', '', '2014-07-14 14:13:24'),
(1041, 3, 24, 331, 0, '', '0000-00-00', '', '2014-07-14 14:13:24'),
(1042, 3, 24, 332, 0, '', '0000-00-00', '', '2014-07-14 14:13:24'),
(1043, 3, 24, 333, 0, '', '0000-00-00', '', '2014-07-14 14:13:24'),
(1044, 3, 24, 404, 0, '', '0000-00-00', '', '2014-07-14 14:13:24'),
(1045, 3, 24, 405, 0, '', '0000-00-00', '', '2014-07-14 14:13:24'),
(1046, 3, 24, 406, 0, '', '0000-00-00', '', '2014-07-14 14:13:24'),
(1047, 3, 24, 407, 0, '', '0000-00-00', '', '2014-07-14 14:13:24'),
(1048, 3, 24, 408, 0, '', '0000-00-00', '', '2014-07-14 14:13:24'),
(1049, 3, 24, 409, 0, '', '0000-00-00', '', '2014-07-14 14:13:24'),
(1050, 3, 24, 410, 0, '', '0000-00-00', '', '2014-07-14 14:13:24'),
(1051, 3, 24, 411, 0, '', '0000-00-00', '', '2014-07-14 14:13:24'),
(1052, 3, 24, 412, 0, '', '0000-00-00', '', '2014-07-14 14:13:24'),
(1053, 3, 24, 413, 0, '', '0000-00-00', '', '2014-07-14 14:13:24'),
(1054, 4, 25, 43, 0, '', '0000-00-00', '', '2014-07-14 14:15:12'),
(1055, 4, 25, 44, 0, '', '0000-00-00', '', '2014-07-14 14:15:12'),
(1056, 4, 25, 45, 0, '', '0000-00-00', '', '2014-07-14 14:15:12'),
(1057, 4, 25, 46, 0, '', '0000-00-00', '', '2014-07-14 14:15:12');
INSERT INTO `class_plan_game` (`id`, `class_id`, `plan_id`, `game_id`, `status`, `createdby`, `creation_date`, `modifiedby`, `modified_date`) VALUES
(1058, 4, 25, 47, 0, '', '0000-00-00', '', '2014-07-14 14:15:12'),
(1059, 4, 25, 48, 0, '', '0000-00-00', '', '2014-07-14 14:15:12'),
(1060, 4, 25, 49, 0, '', '0000-00-00', '', '2014-07-14 14:15:12'),
(1061, 4, 25, 50, 0, '', '0000-00-00', '', '2014-07-14 14:15:12'),
(1062, 4, 25, 51, 0, '', '0000-00-00', '', '2014-07-14 14:15:12'),
(1063, 4, 25, 52, 0, '', '0000-00-00', '', '2014-07-14 14:15:12'),
(1064, 4, 25, 53, 0, '', '0000-00-00', '', '2014-07-14 14:15:12'),
(1065, 4, 25, 54, 0, '', '0000-00-00', '', '2014-07-14 14:15:12'),
(1066, 4, 25, 55, 0, '', '0000-00-00', '', '2014-07-14 14:15:12'),
(1067, 4, 25, 56, 0, '', '0000-00-00', '', '2014-07-14 14:15:12'),
(1068, 4, 25, 57, 0, '', '0000-00-00', '', '2014-07-14 14:15:12'),
(1069, 4, 25, 58, 0, '', '0000-00-00', '', '2014-07-14 14:15:12'),
(1070, 4, 25, 59, 0, '', '0000-00-00', '', '2014-07-14 14:15:12'),
(1071, 4, 25, 60, 0, '', '0000-00-00', '', '2014-07-14 14:15:12'),
(1072, 4, 25, 61, 0, '', '0000-00-00', '', '2014-07-14 14:15:12'),
(1073, 4, 25, 62, 0, '', '0000-00-00', '', '2014-07-14 14:15:12'),
(1074, 4, 25, 63, 0, '', '0000-00-00', '', '2014-07-14 14:15:12'),
(1075, 4, 25, 64, 0, '', '0000-00-00', '', '2014-07-14 14:15:12'),
(1076, 4, 25, 65, 0, '', '0000-00-00', '', '2014-07-14 14:15:12'),
(1077, 4, 25, 66, 0, '', '0000-00-00', '', '2014-07-14 14:15:12'),
(1078, 4, 25, 67, 0, '', '0000-00-00', '', '2014-07-14 14:15:12'),
(1079, 4, 25, 68, 0, '', '0000-00-00', '', '2014-07-14 14:15:12'),
(1080, 4, 25, 69, 0, '', '0000-00-00', '', '2014-07-14 14:15:12'),
(1081, 4, 25, 70, 0, '', '0000-00-00', '', '2014-07-14 14:15:12'),
(1082, 4, 25, 71, 0, '', '0000-00-00', '', '2014-07-14 14:15:12'),
(1083, 4, 25, 72, 0, '', '0000-00-00', '', '2014-07-14 14:15:12'),
(1084, 4, 25, 73, 0, '', '0000-00-00', '', '2014-07-14 14:15:12'),
(1085, 4, 25, 74, 0, '', '0000-00-00', '', '2014-07-14 14:15:12'),
(1086, 4, 25, 75, 0, '', '0000-00-00', '', '2014-07-14 14:15:12'),
(1087, 4, 25, 76, 0, '', '0000-00-00', '', '2014-07-14 14:15:12'),
(1088, 4, 25, 77, 0, '', '0000-00-00', '', '2014-07-14 14:15:12'),
(1089, 4, 25, 78, 0, '', '0000-00-00', '', '2014-07-14 14:15:12'),
(1090, 4, 25, 79, 0, '', '0000-00-00', '', '2014-07-14 14:15:12'),
(1091, 4, 25, 80, 0, '', '0000-00-00', '', '2014-07-14 14:15:12'),
(1092, 4, 25, 81, 0, '', '0000-00-00', '', '2014-07-14 14:15:12'),
(1093, 4, 25, 82, 0, '', '0000-00-00', '', '2014-07-14 14:15:12'),
(1094, 4, 25, 334, 0, '', '0000-00-00', '', '2014-07-14 14:15:12'),
(1095, 4, 25, 335, 0, '', '0000-00-00', '', '2014-07-14 14:15:12'),
(1096, 4, 25, 336, 0, '', '0000-00-00', '', '2014-07-14 14:15:12'),
(1097, 4, 25, 337, 0, '', '0000-00-00', '', '2014-07-14 14:15:12'),
(1098, 4, 25, 338, 0, '', '0000-00-00', '', '2014-07-14 14:15:12'),
(1099, 4, 25, 339, 0, '', '0000-00-00', '', '2014-07-14 14:15:12'),
(1100, 4, 25, 340, 0, '', '0000-00-00', '', '2014-07-14 14:15:12'),
(1101, 4, 25, 341, 0, '', '0000-00-00', '', '2014-07-14 14:15:12'),
(1102, 4, 25, 342, 0, '', '0000-00-00', '', '2014-07-14 14:15:12'),
(1103, 4, 25, 343, 0, '', '0000-00-00', '', '2014-07-14 14:15:12'),
(1104, 4, 25, 404, 0, '', '0000-00-00', '', '2014-07-14 14:15:12'),
(1105, 4, 25, 405, 0, '', '0000-00-00', '', '2014-07-14 14:15:12'),
(1106, 4, 25, 406, 0, '', '0000-00-00', '', '2014-07-14 14:15:12'),
(1107, 4, 25, 407, 0, '', '0000-00-00', '', '2014-07-14 14:15:12'),
(1108, 4, 25, 408, 0, '', '0000-00-00', '', '2014-07-14 14:15:12'),
(1109, 4, 25, 409, 0, '', '0000-00-00', '', '2014-07-14 14:15:12'),
(1110, 4, 25, 410, 0, '', '0000-00-00', '', '2014-07-14 14:15:12'),
(1111, 4, 25, 411, 0, '', '0000-00-00', '', '2014-07-14 14:15:12'),
(1112, 4, 25, 412, 0, '', '0000-00-00', '', '2014-07-14 14:15:12'),
(1113, 4, 25, 413, 0, '', '0000-00-00', '', '2014-07-14 14:15:12'),
(1114, 5, 26, 83, 0, '', '0000-00-00', '', '2014-07-14 14:16:37'),
(1115, 5, 26, 84, 0, '', '0000-00-00', '', '2014-07-14 14:16:37'),
(1116, 5, 26, 85, 0, '', '0000-00-00', '', '2014-07-14 14:16:37'),
(1117, 5, 26, 86, 0, '', '0000-00-00', '', '2014-07-14 14:16:37'),
(1118, 5, 26, 87, 0, '', '0000-00-00', '', '2014-07-14 14:16:37'),
(1119, 5, 26, 88, 0, '', '0000-00-00', '', '2014-07-14 14:16:37'),
(1120, 5, 26, 89, 0, '', '0000-00-00', '', '2014-07-14 14:16:37'),
(1121, 5, 26, 90, 0, '', '0000-00-00', '', '2014-07-14 14:16:37'),
(1122, 5, 26, 91, 0, '', '0000-00-00', '', '2014-07-14 14:16:37'),
(1123, 5, 26, 92, 0, '', '0000-00-00', '', '2014-07-14 14:16:37'),
(1124, 5, 26, 93, 0, '', '0000-00-00', '', '2014-07-14 14:16:37'),
(1125, 5, 26, 94, 0, '', '0000-00-00', '', '2014-07-14 14:16:37'),
(1126, 5, 26, 95, 0, '', '0000-00-00', '', '2014-07-14 14:16:37'),
(1127, 5, 26, 96, 0, '', '0000-00-00', '', '2014-07-14 14:16:37'),
(1128, 5, 26, 97, 0, '', '0000-00-00', '', '2014-07-14 14:16:37'),
(1129, 5, 26, 98, 0, '', '0000-00-00', '', '2014-07-14 14:16:37'),
(1130, 5, 26, 99, 0, '', '0000-00-00', '', '2014-07-14 14:16:37'),
(1131, 5, 26, 100, 0, '', '0000-00-00', '', '2014-07-14 14:16:37'),
(1132, 5, 26, 101, 0, '', '0000-00-00', '', '2014-07-14 14:16:37'),
(1133, 5, 26, 102, 0, '', '0000-00-00', '', '2014-07-14 14:16:37'),
(1134, 5, 26, 103, 0, '', '0000-00-00', '', '2014-07-14 14:16:37'),
(1135, 5, 26, 104, 0, '', '0000-00-00', '', '2014-07-14 14:16:37'),
(1136, 5, 26, 105, 0, '', '0000-00-00', '', '2014-07-14 14:16:37'),
(1137, 5, 26, 106, 0, '', '0000-00-00', '', '2014-07-14 14:16:37'),
(1138, 5, 26, 107, 0, '', '0000-00-00', '', '2014-07-14 14:16:37'),
(1139, 5, 26, 108, 0, '', '0000-00-00', '', '2014-07-14 14:16:37'),
(1140, 5, 26, 109, 0, '', '0000-00-00', '', '2014-07-14 14:16:37'),
(1141, 5, 26, 110, 0, '', '0000-00-00', '', '2014-07-14 14:16:37'),
(1142, 5, 26, 111, 0, '', '0000-00-00', '', '2014-07-14 14:16:37'),
(1143, 5, 26, 112, 0, '', '0000-00-00', '', '2014-07-14 14:16:37'),
(1144, 5, 26, 113, 0, '', '0000-00-00', '', '2014-07-14 14:16:37'),
(1145, 5, 26, 114, 0, '', '0000-00-00', '', '2014-07-14 14:16:37'),
(1146, 5, 26, 115, 0, '', '0000-00-00', '', '2014-07-14 14:16:37'),
(1147, 5, 26, 116, 0, '', '0000-00-00', '', '2014-07-14 14:16:37'),
(1148, 5, 26, 117, 0, '', '0000-00-00', '', '2014-07-14 14:16:37'),
(1149, 5, 26, 118, 0, '', '0000-00-00', '', '2014-07-14 14:16:37'),
(1150, 5, 26, 119, 0, '', '0000-00-00', '', '2014-07-14 14:16:37'),
(1151, 5, 26, 120, 0, '', '0000-00-00', '', '2014-07-14 14:16:37'),
(1152, 5, 26, 121, 0, '', '0000-00-00', '', '2014-07-14 14:16:37'),
(1153, 5, 26, 122, 0, '', '0000-00-00', '', '2014-07-14 14:16:37'),
(1154, 5, 26, 344, 0, '', '0000-00-00', '', '2014-07-14 14:16:38'),
(1155, 5, 26, 345, 0, '', '0000-00-00', '', '2014-07-14 14:16:38'),
(1156, 5, 26, 346, 0, '', '0000-00-00', '', '2014-07-14 14:16:38'),
(1157, 5, 26, 347, 0, '', '0000-00-00', '', '2014-07-14 14:16:38'),
(1158, 5, 26, 348, 0, '', '0000-00-00', '', '2014-07-14 14:16:38'),
(1159, 5, 26, 349, 0, '', '0000-00-00', '', '2014-07-14 14:16:38'),
(1160, 5, 26, 350, 0, '', '0000-00-00', '', '2014-07-14 14:16:38'),
(1161, 5, 26, 351, 0, '', '0000-00-00', '', '2014-07-14 14:16:38'),
(1162, 5, 26, 352, 0, '', '0000-00-00', '', '2014-07-14 14:16:38'),
(1163, 5, 26, 353, 0, '', '0000-00-00', '', '2014-07-14 14:16:38'),
(1164, 5, 26, 404, 0, '', '0000-00-00', '', '2014-07-14 14:16:38'),
(1165, 5, 26, 405, 0, '', '0000-00-00', '', '2014-07-14 14:16:38'),
(1166, 5, 26, 406, 0, '', '0000-00-00', '', '2014-07-14 14:16:38'),
(1167, 5, 26, 407, 0, '', '0000-00-00', '', '2014-07-14 14:16:38'),
(1168, 5, 26, 408, 0, '', '0000-00-00', '', '2014-07-14 14:16:38'),
(1169, 5, 26, 409, 0, '', '0000-00-00', '', '2014-07-14 14:16:38'),
(1170, 5, 26, 410, 0, '', '0000-00-00', '', '2014-07-14 14:16:38'),
(1171, 5, 26, 411, 0, '', '0000-00-00', '', '2014-07-14 14:16:38'),
(1172, 5, 26, 412, 0, '', '0000-00-00', '', '2014-07-14 14:16:38'),
(1173, 5, 26, 413, 0, '', '0000-00-00', '', '2014-07-14 14:16:38'),
(1174, 6, 27, 123, 0, '', '0000-00-00', '', '2014-07-14 14:19:25'),
(1175, 6, 27, 124, 0, '', '0000-00-00', '', '2014-07-14 14:19:25'),
(1176, 6, 27, 125, 0, '', '0000-00-00', '', '2014-07-14 14:19:25'),
(1177, 6, 27, 126, 0, '', '0000-00-00', '', '2014-07-14 14:19:25'),
(1178, 6, 27, 127, 0, '', '0000-00-00', '', '2014-07-14 14:19:25'),
(1179, 6, 27, 128, 0, '', '0000-00-00', '', '2014-07-14 14:19:25'),
(1180, 6, 27, 129, 0, '', '0000-00-00', '', '2014-07-14 14:19:25'),
(1181, 6, 27, 130, 0, '', '0000-00-00', '', '2014-07-14 14:19:25'),
(1182, 6, 27, 131, 0, '', '0000-00-00', '', '2014-07-14 14:19:25'),
(1183, 6, 27, 132, 0, '', '0000-00-00', '', '2014-07-14 14:19:25'),
(1184, 6, 27, 133, 0, '', '0000-00-00', '', '2014-07-14 14:19:25'),
(1185, 6, 27, 134, 0, '', '0000-00-00', '', '2014-07-14 14:19:25'),
(1186, 6, 27, 135, 0, '', '0000-00-00', '', '2014-07-14 14:19:25'),
(1187, 6, 27, 136, 0, '', '0000-00-00', '', '2014-07-14 14:19:25'),
(1188, 6, 27, 137, 0, '', '0000-00-00', '', '2014-07-14 14:19:25'),
(1189, 6, 27, 138, 0, '', '0000-00-00', '', '2014-07-14 14:19:25'),
(1190, 6, 27, 139, 0, '', '0000-00-00', '', '2014-07-14 14:19:25'),
(1191, 6, 27, 140, 0, '', '0000-00-00', '', '2014-07-14 14:19:25'),
(1192, 6, 27, 141, 0, '', '0000-00-00', '', '2014-07-14 14:19:25'),
(1193, 6, 27, 142, 0, '', '0000-00-00', '', '2014-07-14 14:19:25'),
(1194, 6, 27, 143, 0, '', '0000-00-00', '', '2014-07-14 14:19:25'),
(1195, 6, 27, 144, 0, '', '0000-00-00', '', '2014-07-14 14:19:25'),
(1196, 6, 27, 145, 0, '', '0000-00-00', '', '2014-07-14 14:19:25'),
(1197, 6, 27, 146, 0, '', '0000-00-00', '', '2014-07-14 14:19:25'),
(1198, 6, 27, 147, 0, '', '0000-00-00', '', '2014-07-14 14:19:25'),
(1199, 6, 27, 148, 0, '', '0000-00-00', '', '2014-07-14 14:19:25'),
(1200, 6, 27, 149, 0, '', '0000-00-00', '', '2014-07-14 14:19:25'),
(1201, 6, 27, 150, 0, '', '0000-00-00', '', '2014-07-14 14:19:25'),
(1202, 6, 27, 151, 0, '', '0000-00-00', '', '2014-07-14 14:19:25'),
(1203, 6, 27, 152, 0, '', '0000-00-00', '', '2014-07-14 14:19:25'),
(1204, 6, 27, 153, 0, '', '0000-00-00', '', '2014-07-14 14:19:25'),
(1205, 6, 27, 154, 0, '', '0000-00-00', '', '2014-07-14 14:19:25'),
(1206, 6, 27, 155, 0, '', '0000-00-00', '', '2014-07-14 14:19:25'),
(1207, 6, 27, 156, 0, '', '0000-00-00', '', '2014-07-14 14:19:25'),
(1208, 6, 27, 157, 0, '', '0000-00-00', '', '2014-07-14 14:19:25'),
(1209, 6, 27, 158, 0, '', '0000-00-00', '', '2014-07-14 14:19:25'),
(1210, 6, 27, 159, 0, '', '0000-00-00', '', '2014-07-14 14:19:25'),
(1211, 6, 27, 160, 0, '', '0000-00-00', '', '2014-07-14 14:19:25'),
(1212, 6, 27, 161, 0, '', '0000-00-00', '', '2014-07-14 14:19:25'),
(1213, 6, 27, 162, 0, '', '0000-00-00', '', '2014-07-14 14:19:25'),
(1214, 6, 27, 354, 0, '', '0000-00-00', '', '2014-07-14 14:19:25'),
(1215, 6, 27, 355, 0, '', '0000-00-00', '', '2014-07-14 14:19:25'),
(1216, 6, 27, 356, 0, '', '0000-00-00', '', '2014-07-14 14:19:25'),
(1217, 6, 27, 357, 0, '', '0000-00-00', '', '2014-07-14 14:19:25'),
(1218, 6, 27, 358, 0, '', '0000-00-00', '', '2014-07-14 14:19:25'),
(1219, 6, 27, 359, 0, '', '0000-00-00', '', '2014-07-14 14:19:25'),
(1220, 6, 27, 360, 0, '', '0000-00-00', '', '2014-07-14 14:19:25'),
(1221, 6, 27, 361, 0, '', '0000-00-00', '', '2014-07-14 14:19:25'),
(1222, 6, 27, 362, 0, '', '0000-00-00', '', '2014-07-14 14:19:25'),
(1223, 6, 27, 363, 0, '', '0000-00-00', '', '2014-07-14 14:19:25'),
(1224, 6, 27, 404, 0, '', '0000-00-00', '', '2014-07-14 14:19:25'),
(1225, 6, 27, 405, 0, '', '0000-00-00', '', '2014-07-14 14:19:25'),
(1226, 6, 27, 406, 0, '', '0000-00-00', '', '2014-07-14 14:19:25'),
(1227, 6, 27, 407, 0, '', '0000-00-00', '', '2014-07-14 14:19:25'),
(1228, 6, 27, 408, 0, '', '0000-00-00', '', '2014-07-14 14:19:25'),
(1229, 6, 27, 409, 0, '', '0000-00-00', '', '2014-07-14 14:19:25'),
(1230, 6, 27, 410, 0, '', '0000-00-00', '', '2014-07-14 14:19:25'),
(1231, 6, 27, 411, 0, '', '0000-00-00', '', '2014-07-14 14:19:25'),
(1232, 6, 27, 412, 0, '', '0000-00-00', '', '2014-07-14 14:19:25'),
(1233, 6, 27, 413, 0, '', '0000-00-00', '', '2014-07-14 14:19:25'),
(1234, 7, 28, 163, 0, '', '0000-00-00', '', '2014-07-14 14:22:52'),
(1235, 7, 28, 164, 0, '', '0000-00-00', '', '2014-07-14 14:22:52'),
(1236, 7, 28, 165, 0, '', '0000-00-00', '', '2014-07-14 14:22:52'),
(1237, 7, 28, 166, 0, '', '0000-00-00', '', '2014-07-14 14:22:52'),
(1238, 7, 28, 167, 0, '', '0000-00-00', '', '2014-07-14 14:22:52'),
(1239, 7, 28, 168, 0, '', '0000-00-00', '', '2014-07-14 14:22:52'),
(1240, 7, 28, 169, 0, '', '0000-00-00', '', '2014-07-14 14:22:52'),
(1241, 7, 28, 170, 0, '', '0000-00-00', '', '2014-07-14 14:22:52'),
(1242, 7, 28, 171, 0, '', '0000-00-00', '', '2014-07-14 14:22:52'),
(1243, 7, 28, 172, 0, '', '0000-00-00', '', '2014-07-14 14:22:52'),
(1244, 7, 28, 173, 0, '', '0000-00-00', '', '2014-07-14 14:22:52'),
(1245, 7, 28, 174, 0, '', '0000-00-00', '', '2014-07-14 14:22:52'),
(1246, 7, 28, 175, 0, '', '0000-00-00', '', '2014-07-14 14:22:52'),
(1247, 7, 28, 176, 0, '', '0000-00-00', '', '2014-07-14 14:22:52'),
(1248, 7, 28, 177, 0, '', '0000-00-00', '', '2014-07-14 14:22:52'),
(1249, 7, 28, 178, 0, '', '0000-00-00', '', '2014-07-14 14:22:52'),
(1250, 7, 28, 179, 0, '', '0000-00-00', '', '2014-07-14 14:22:52'),
(1251, 7, 28, 180, 0, '', '0000-00-00', '', '2014-07-14 14:22:52'),
(1252, 7, 28, 181, 0, '', '0000-00-00', '', '2014-07-14 14:22:52'),
(1253, 7, 28, 182, 0, '', '0000-00-00', '', '2014-07-14 14:22:52'),
(1254, 7, 28, 183, 0, '', '0000-00-00', '', '2014-07-14 14:22:52'),
(1255, 7, 28, 184, 0, '', '0000-00-00', '', '2014-07-14 14:22:52'),
(1256, 7, 28, 185, 0, '', '0000-00-00', '', '2014-07-14 14:22:52'),
(1257, 7, 28, 186, 0, '', '0000-00-00', '', '2014-07-14 14:22:52'),
(1258, 7, 28, 187, 0, '', '0000-00-00', '', '2014-07-14 14:22:52'),
(1259, 7, 28, 188, 0, '', '0000-00-00', '', '2014-07-14 14:22:52'),
(1260, 7, 28, 189, 0, '', '0000-00-00', '', '2014-07-14 14:22:52'),
(1261, 7, 28, 190, 0, '', '0000-00-00', '', '2014-07-14 14:22:52'),
(1262, 7, 28, 191, 0, '', '0000-00-00', '', '2014-07-14 14:22:52'),
(1263, 7, 28, 192, 0, '', '0000-00-00', '', '2014-07-14 14:22:52'),
(1264, 7, 28, 193, 0, '', '0000-00-00', '', '2014-07-14 14:22:52'),
(1265, 7, 28, 194, 0, '', '0000-00-00', '', '2014-07-14 14:22:52'),
(1266, 7, 28, 195, 0, '', '0000-00-00', '', '2014-07-14 14:22:52'),
(1267, 7, 28, 196, 0, '', '0000-00-00', '', '2014-07-14 14:22:52'),
(1268, 7, 28, 197, 0, '', '0000-00-00', '', '2014-07-14 14:22:52'),
(1269, 7, 28, 198, 0, '', '0000-00-00', '', '2014-07-14 14:22:52'),
(1270, 7, 28, 199, 0, '', '0000-00-00', '', '2014-07-14 14:22:52'),
(1271, 7, 28, 200, 0, '', '0000-00-00', '', '2014-07-14 14:22:52'),
(1272, 7, 28, 201, 0, '', '0000-00-00', '', '2014-07-14 14:22:52'),
(1273, 7, 28, 202, 0, '', '0000-00-00', '', '2014-07-14 14:22:52'),
(1274, 7, 28, 364, 0, '', '0000-00-00', '', '2014-07-14 14:22:52'),
(1275, 7, 28, 365, 0, '', '0000-00-00', '', '2014-07-14 14:22:52'),
(1276, 7, 28, 366, 0, '', '0000-00-00', '', '2014-07-14 14:22:52'),
(1277, 7, 28, 367, 0, '', '0000-00-00', '', '2014-07-14 14:22:52'),
(1278, 7, 28, 368, 0, '', '0000-00-00', '', '2014-07-14 14:22:52'),
(1279, 7, 28, 369, 0, '', '0000-00-00', '', '2014-07-14 14:22:52'),
(1280, 7, 28, 370, 0, '', '0000-00-00', '', '2014-07-14 14:22:52'),
(1281, 7, 28, 371, 0, '', '0000-00-00', '', '2014-07-14 14:22:52'),
(1282, 7, 28, 372, 0, '', '0000-00-00', '', '2014-07-14 14:22:52'),
(1283, 7, 28, 373, 0, '', '0000-00-00', '', '2014-07-14 14:22:52'),
(1284, 7, 28, 404, 0, '', '0000-00-00', '', '2014-07-14 14:22:52'),
(1285, 7, 28, 405, 0, '', '0000-00-00', '', '2014-07-14 14:22:52'),
(1286, 7, 28, 406, 0, '', '0000-00-00', '', '2014-07-14 14:22:52'),
(1287, 7, 28, 407, 0, '', '0000-00-00', '', '2014-07-14 14:22:52'),
(1288, 7, 28, 408, 0, '', '0000-00-00', '', '2014-07-14 14:22:52'),
(1289, 7, 28, 409, 0, '', '0000-00-00', '', '2014-07-14 14:22:52'),
(1290, 7, 28, 410, 0, '', '0000-00-00', '', '2014-07-14 14:22:52'),
(1291, 7, 28, 411, 0, '', '0000-00-00', '', '2014-07-14 14:22:52'),
(1292, 7, 28, 412, 0, '', '0000-00-00', '', '2014-07-14 14:22:52'),
(1293, 7, 28, 413, 0, '', '0000-00-00', '', '2014-07-14 14:22:52'),
(1294, 8, 29, 203, 0, '', '0000-00-00', '', '2014-07-14 14:25:11'),
(1295, 8, 29, 204, 0, '', '0000-00-00', '', '2014-07-14 14:25:11'),
(1296, 8, 29, 205, 0, '', '0000-00-00', '', '2014-07-14 14:25:11'),
(1297, 8, 29, 206, 0, '', '0000-00-00', '', '2014-07-14 14:25:11'),
(1298, 8, 29, 207, 0, '', '0000-00-00', '', '2014-07-14 14:25:11'),
(1299, 8, 29, 208, 0, '', '0000-00-00', '', '2014-07-14 14:25:11'),
(1300, 8, 29, 209, 0, '', '0000-00-00', '', '2014-07-14 14:25:11'),
(1301, 8, 29, 210, 0, '', '0000-00-00', '', '2014-07-14 14:25:11'),
(1302, 8, 29, 211, 0, '', '0000-00-00', '', '2014-07-14 14:25:11'),
(1303, 8, 29, 212, 0, '', '0000-00-00', '', '2014-07-14 14:25:11'),
(1304, 8, 29, 213, 0, '', '0000-00-00', '', '2014-07-14 14:25:11'),
(1305, 8, 29, 214, 0, '', '0000-00-00', '', '2014-07-14 14:25:11'),
(1306, 8, 29, 215, 0, '', '0000-00-00', '', '2014-07-14 14:25:11'),
(1307, 8, 29, 216, 0, '', '0000-00-00', '', '2014-07-14 14:25:11'),
(1308, 8, 29, 217, 0, '', '0000-00-00', '', '2014-07-14 14:25:11'),
(1309, 8, 29, 218, 0, '', '0000-00-00', '', '2014-07-14 14:25:11'),
(1310, 8, 29, 219, 0, '', '0000-00-00', '', '2014-07-14 14:25:11'),
(1311, 8, 29, 220, 0, '', '0000-00-00', '', '2014-07-14 14:25:11'),
(1312, 8, 29, 221, 0, '', '0000-00-00', '', '2014-07-14 14:25:11'),
(1313, 8, 29, 222, 0, '', '0000-00-00', '', '2014-07-14 14:25:11'),
(1314, 8, 29, 223, 0, '', '0000-00-00', '', '2014-07-14 14:25:11'),
(1315, 8, 29, 224, 0, '', '0000-00-00', '', '2014-07-14 14:25:11'),
(1316, 8, 29, 225, 0, '', '0000-00-00', '', '2014-07-14 14:25:11'),
(1317, 8, 29, 226, 0, '', '0000-00-00', '', '2014-07-14 14:25:11'),
(1318, 8, 29, 227, 0, '', '0000-00-00', '', '2014-07-14 14:25:11'),
(1319, 8, 29, 228, 0, '', '0000-00-00', '', '2014-07-14 14:25:11'),
(1320, 8, 29, 229, 0, '', '0000-00-00', '', '2014-07-14 14:25:11'),
(1321, 8, 29, 230, 0, '', '0000-00-00', '', '2014-07-14 14:25:11'),
(1322, 8, 29, 231, 0, '', '0000-00-00', '', '2014-07-14 14:25:11'),
(1323, 8, 29, 232, 0, '', '0000-00-00', '', '2014-07-14 14:25:11'),
(1324, 8, 29, 233, 0, '', '0000-00-00', '', '2014-07-14 14:25:11'),
(1325, 8, 29, 234, 0, '', '0000-00-00', '', '2014-07-14 14:25:11'),
(1326, 8, 29, 235, 0, '', '0000-00-00', '', '2014-07-14 14:25:11'),
(1327, 8, 29, 236, 0, '', '0000-00-00', '', '2014-07-14 14:25:11'),
(1328, 8, 29, 237, 0, '', '0000-00-00', '', '2014-07-14 14:25:11'),
(1329, 8, 29, 238, 0, '', '0000-00-00', '', '2014-07-14 14:25:11'),
(1330, 8, 29, 239, 0, '', '0000-00-00', '', '2014-07-14 14:25:11'),
(1331, 8, 29, 240, 0, '', '0000-00-00', '', '2014-07-14 14:25:11'),
(1332, 8, 29, 241, 0, '', '0000-00-00', '', '2014-07-14 14:25:11'),
(1333, 8, 29, 242, 0, '', '0000-00-00', '', '2014-07-14 14:25:11'),
(1334, 8, 29, 374, 0, '', '0000-00-00', '', '2014-07-14 14:25:11'),
(1335, 8, 29, 375, 0, '', '0000-00-00', '', '2014-07-14 14:25:11'),
(1336, 8, 29, 376, 0, '', '0000-00-00', '', '2014-07-14 14:25:11'),
(1337, 8, 29, 377, 0, '', '0000-00-00', '', '2014-07-14 14:25:11'),
(1338, 8, 29, 378, 0, '', '0000-00-00', '', '2014-07-14 14:25:11'),
(1339, 8, 29, 379, 0, '', '0000-00-00', '', '2014-07-14 14:25:11'),
(1340, 8, 29, 380, 0, '', '0000-00-00', '', '2014-07-14 14:25:11'),
(1341, 8, 29, 381, 0, '', '0000-00-00', '', '2014-07-14 14:25:11'),
(1342, 8, 29, 382, 0, '', '0000-00-00', '', '2014-07-14 14:25:11'),
(1343, 8, 29, 383, 0, '', '0000-00-00', '', '2014-07-14 14:25:11'),
(1344, 8, 29, 404, 0, '', '0000-00-00', '', '2014-07-14 14:25:11'),
(1345, 8, 29, 405, 0, '', '0000-00-00', '', '2014-07-14 14:25:11'),
(1346, 8, 29, 406, 0, '', '0000-00-00', '', '2014-07-14 14:25:11'),
(1347, 8, 29, 407, 0, '', '0000-00-00', '', '2014-07-14 14:25:11'),
(1348, 8, 29, 408, 0, '', '0000-00-00', '', '2014-07-14 14:25:11'),
(1349, 8, 29, 409, 0, '', '0000-00-00', '', '2014-07-14 14:25:11'),
(1350, 8, 29, 410, 0, '', '0000-00-00', '', '2014-07-14 14:25:11'),
(1351, 8, 29, 411, 0, '', '0000-00-00', '', '2014-07-14 14:25:11'),
(1352, 8, 29, 412, 0, '', '0000-00-00', '', '2014-07-14 14:25:11'),
(1353, 8, 29, 413, 0, '', '0000-00-00', '', '2014-07-14 14:25:11'),
(1354, 9, 30, 243, 0, '', '0000-00-00', '', '2014-07-14 14:27:07'),
(1355, 9, 30, 244, 0, '', '0000-00-00', '', '2014-07-14 14:27:07'),
(1356, 9, 30, 245, 0, '', '0000-00-00', '', '2014-07-14 14:27:07'),
(1357, 9, 30, 246, 0, '', '0000-00-00', '', '2014-07-14 14:27:07'),
(1358, 9, 30, 247, 0, '', '0000-00-00', '', '2014-07-14 14:27:07'),
(1359, 9, 30, 248, 0, '', '0000-00-00', '', '2014-07-14 14:27:07'),
(1360, 9, 30, 249, 0, '', '0000-00-00', '', '2014-07-14 14:27:07'),
(1361, 9, 30, 250, 0, '', '0000-00-00', '', '2014-07-14 14:27:07'),
(1362, 9, 30, 251, 0, '', '0000-00-00', '', '2014-07-14 14:27:07'),
(1363, 9, 30, 252, 0, '', '0000-00-00', '', '2014-07-14 14:27:07'),
(1364, 9, 30, 253, 0, '', '0000-00-00', '', '2014-07-14 14:27:07'),
(1365, 9, 30, 254, 0, '', '0000-00-00', '', '2014-07-14 14:27:07'),
(1366, 9, 30, 255, 0, '', '0000-00-00', '', '2014-07-14 14:27:07'),
(1367, 9, 30, 256, 0, '', '0000-00-00', '', '2014-07-14 14:27:07'),
(1368, 9, 30, 257, 0, '', '0000-00-00', '', '2014-07-14 14:27:07'),
(1369, 9, 30, 258, 0, '', '0000-00-00', '', '2014-07-14 14:27:07'),
(1370, 9, 30, 259, 0, '', '0000-00-00', '', '2014-07-14 14:27:07'),
(1371, 9, 30, 260, 0, '', '0000-00-00', '', '2014-07-14 14:27:07'),
(1372, 9, 30, 261, 0, '', '0000-00-00', '', '2014-07-14 14:27:07'),
(1373, 9, 30, 262, 0, '', '0000-00-00', '', '2014-07-14 14:27:07'),
(1374, 9, 30, 263, 0, '', '0000-00-00', '', '2014-07-14 14:27:07'),
(1375, 9, 30, 264, 0, '', '0000-00-00', '', '2014-07-14 14:27:07'),
(1376, 9, 30, 265, 0, '', '0000-00-00', '', '2014-07-14 14:27:07'),
(1377, 9, 30, 266, 0, '', '0000-00-00', '', '2014-07-14 14:27:07'),
(1378, 9, 30, 267, 0, '', '0000-00-00', '', '2014-07-14 14:27:07'),
(1379, 9, 30, 268, 0, '', '0000-00-00', '', '2014-07-14 14:27:07'),
(1380, 9, 30, 269, 0, '', '0000-00-00', '', '2014-07-14 14:27:07'),
(1381, 9, 30, 270, 0, '', '0000-00-00', '', '2014-07-14 14:27:07'),
(1382, 9, 30, 271, 0, '', '0000-00-00', '', '2014-07-14 14:27:07'),
(1383, 9, 30, 272, 0, '', '0000-00-00', '', '2014-07-14 14:27:07'),
(1384, 9, 30, 273, 0, '', '0000-00-00', '', '2014-07-14 14:27:07'),
(1385, 9, 30, 274, 0, '', '0000-00-00', '', '2014-07-14 14:27:07'),
(1386, 9, 30, 275, 0, '', '0000-00-00', '', '2014-07-14 14:27:07'),
(1387, 9, 30, 276, 0, '', '0000-00-00', '', '2014-07-14 14:27:07'),
(1388, 9, 30, 277, 0, '', '0000-00-00', '', '2014-07-14 14:27:07'),
(1389, 9, 30, 278, 0, '', '0000-00-00', '', '2014-07-14 14:27:07'),
(1390, 9, 30, 279, 0, '', '0000-00-00', '', '2014-07-14 14:27:07'),
(1391, 9, 30, 280, 0, '', '0000-00-00', '', '2014-07-14 14:27:07'),
(1392, 9, 30, 281, 0, '', '0000-00-00', '', '2014-07-14 14:27:07'),
(1393, 9, 30, 282, 0, '', '0000-00-00', '', '2014-07-14 14:27:07'),
(1394, 9, 30, 384, 0, '', '0000-00-00', '', '2014-07-14 14:27:07'),
(1395, 9, 30, 385, 0, '', '0000-00-00', '', '2014-07-14 14:27:07'),
(1396, 9, 30, 386, 0, '', '0000-00-00', '', '2014-07-14 14:27:07'),
(1397, 9, 30, 387, 0, '', '0000-00-00', '', '2014-07-14 14:27:07'),
(1398, 9, 30, 388, 0, '', '0000-00-00', '', '2014-07-14 14:27:07'),
(1399, 9, 30, 389, 0, '', '0000-00-00', '', '2014-07-14 14:27:07'),
(1400, 9, 30, 390, 0, '', '0000-00-00', '', '2014-07-14 14:27:07'),
(1401, 9, 30, 391, 0, '', '0000-00-00', '', '2014-07-14 14:27:07'),
(1402, 9, 30, 392, 0, '', '0000-00-00', '', '2014-07-14 14:27:07'),
(1403, 9, 30, 393, 0, '', '0000-00-00', '', '2014-07-14 14:27:07'),
(1404, 9, 30, 404, 0, '', '0000-00-00', '', '2014-07-14 14:27:07'),
(1405, 9, 30, 405, 0, '', '0000-00-00', '', '2014-07-14 14:27:07'),
(1406, 9, 30, 406, 0, '', '0000-00-00', '', '2014-07-14 14:27:07'),
(1407, 9, 30, 407, 0, '', '0000-00-00', '', '2014-07-14 14:27:07'),
(1408, 9, 30, 408, 0, '', '0000-00-00', '', '2014-07-14 14:27:07'),
(1409, 9, 30, 409, 0, '', '0000-00-00', '', '2014-07-14 14:27:07'),
(1410, 9, 30, 410, 0, '', '0000-00-00', '', '2014-07-14 14:27:07'),
(1411, 9, 30, 411, 0, '', '0000-00-00', '', '2014-07-14 14:27:07'),
(1412, 9, 30, 412, 0, '', '0000-00-00', '', '2014-07-14 14:27:07'),
(1413, 9, 30, 413, 0, '', '0000-00-00', '', '2014-07-14 14:27:07'),
(1414, 10, 31, 283, 0, '', '0000-00-00', '', '2014-07-14 14:28:19'),
(1415, 10, 31, 284, 0, '', '0000-00-00', '', '2014-07-14 14:28:19'),
(1416, 10, 31, 285, 0, '', '0000-00-00', '', '2014-07-14 14:28:19'),
(1417, 10, 31, 286, 0, '', '0000-00-00', '', '2014-07-14 14:28:19'),
(1418, 10, 31, 287, 0, '', '0000-00-00', '', '2014-07-14 14:28:19'),
(1419, 10, 31, 288, 0, '', '0000-00-00', '', '2014-07-14 14:28:19'),
(1420, 10, 31, 289, 0, '', '0000-00-00', '', '2014-07-14 14:28:19'),
(1421, 10, 31, 290, 0, '', '0000-00-00', '', '2014-07-14 14:28:19'),
(1422, 10, 31, 291, 0, '', '0000-00-00', '', '2014-07-14 14:28:19'),
(1423, 10, 31, 292, 0, '', '0000-00-00', '', '2014-07-14 14:28:19'),
(1424, 10, 31, 293, 0, '', '0000-00-00', '', '2014-07-14 14:28:19'),
(1425, 10, 31, 294, 0, '', '0000-00-00', '', '2014-07-14 14:28:19'),
(1426, 10, 31, 295, 0, '', '0000-00-00', '', '2014-07-14 14:28:19'),
(1427, 10, 31, 296, 0, '', '0000-00-00', '', '2014-07-14 14:28:19'),
(1428, 10, 31, 297, 0, '', '0000-00-00', '', '2014-07-14 14:28:19'),
(1429, 10, 31, 298, 0, '', '0000-00-00', '', '2014-07-14 14:28:19'),
(1430, 10, 31, 299, 0, '', '0000-00-00', '', '2014-07-14 14:28:19'),
(1431, 10, 31, 300, 0, '', '0000-00-00', '', '2014-07-14 14:28:19'),
(1432, 10, 31, 301, 0, '', '0000-00-00', '', '2014-07-14 14:28:19'),
(1433, 10, 31, 302, 0, '', '0000-00-00', '', '2014-07-14 14:28:19'),
(1434, 10, 31, 303, 0, '', '0000-00-00', '', '2014-07-14 14:28:19'),
(1435, 10, 31, 304, 0, '', '0000-00-00', '', '2014-07-14 14:28:19'),
(1436, 10, 31, 306, 0, '', '0000-00-00', '', '2014-07-14 14:28:19'),
(1437, 10, 31, 307, 0, '', '0000-00-00', '', '2014-07-14 14:28:19'),
(1438, 10, 31, 308, 0, '', '0000-00-00', '', '2014-07-14 14:28:19'),
(1439, 10, 31, 309, 0, '', '0000-00-00', '', '2014-07-14 14:28:19'),
(1440, 10, 31, 310, 0, '', '0000-00-00', '', '2014-07-14 14:28:19'),
(1441, 10, 31, 311, 0, '', '0000-00-00', '', '2014-07-14 14:28:19'),
(1442, 10, 31, 312, 0, '', '0000-00-00', '', '2014-07-14 14:28:19'),
(1443, 10, 31, 313, 0, '', '0000-00-00', '', '2014-07-14 14:28:19'),
(1444, 10, 31, 314, 0, '', '0000-00-00', '', '2014-07-14 14:28:19'),
(1445, 10, 31, 315, 0, '', '0000-00-00', '', '2014-07-14 14:28:19'),
(1446, 10, 31, 316, 0, '', '0000-00-00', '', '2014-07-14 14:28:19'),
(1447, 10, 31, 317, 0, '', '0000-00-00', '', '2014-07-14 14:28:19'),
(1448, 10, 31, 318, 0, '', '0000-00-00', '', '2014-07-14 14:28:19'),
(1449, 10, 31, 319, 0, '', '0000-00-00', '', '2014-07-14 14:28:19'),
(1450, 10, 31, 320, 0, '', '0000-00-00', '', '2014-07-14 14:28:19'),
(1451, 10, 31, 321, 0, '', '0000-00-00', '', '2014-07-14 14:28:19'),
(1452, 10, 31, 322, 0, '', '0000-00-00', '', '2014-07-14 14:28:19'),
(1453, 10, 31, 323, 0, '', '0000-00-00', '', '2014-07-14 14:28:19'),
(1454, 10, 31, 394, 0, '', '0000-00-00', '', '2014-07-14 14:28:19'),
(1455, 10, 31, 395, 0, '', '0000-00-00', '', '2014-07-14 14:28:19'),
(1456, 10, 31, 396, 0, '', '0000-00-00', '', '2014-07-14 14:28:19'),
(1457, 10, 31, 397, 0, '', '0000-00-00', '', '2014-07-14 14:28:19'),
(1458, 10, 31, 398, 0, '', '0000-00-00', '', '2014-07-14 14:28:19'),
(1459, 10, 31, 399, 0, '', '0000-00-00', '', '2014-07-14 14:28:19'),
(1460, 10, 31, 400, 0, '', '0000-00-00', '', '2014-07-14 14:28:19'),
(1461, 10, 31, 401, 0, '', '0000-00-00', '', '2014-07-14 14:28:19'),
(1462, 10, 31, 402, 0, '', '0000-00-00', '', '2014-07-14 14:28:19'),
(1463, 10, 31, 403, 0, '', '0000-00-00', '', '2014-07-14 14:28:19'),
(1464, 10, 31, 404, 0, '', '0000-00-00', '', '2014-07-14 14:28:19'),
(1465, 10, 31, 405, 0, '', '0000-00-00', '', '2014-07-14 14:28:19'),
(1466, 10, 31, 406, 0, '', '0000-00-00', '', '2014-07-14 14:28:19'),
(1467, 10, 31, 407, 0, '', '0000-00-00', '', '2014-07-14 14:28:19'),
(1468, 10, 31, 408, 0, '', '0000-00-00', '', '2014-07-14 14:28:19'),
(1469, 10, 31, 409, 0, '', '0000-00-00', '', '2014-07-14 14:28:19'),
(1470, 10, 31, 410, 0, '', '0000-00-00', '', '2014-07-14 14:28:19'),
(1471, 10, 31, 411, 0, '', '0000-00-00', '', '2014-07-14 14:28:19'),
(1472, 10, 31, 412, 0, '', '0000-00-00', '', '2014-07-14 14:28:19'),
(1473, 10, 31, 413, 0, '', '0000-00-00', '', '2014-07-14 14:28:19'),
(1474, 7, 18, 180, 0, '', '0000-00-00', '', '2014-07-15 13:34:25'),
(1475, 7, 18, 181, 0, '', '0000-00-00', '', '2014-07-15 13:34:26'),
(1476, 7, 18, 182, 0, '', '0000-00-00', '', '2014-07-15 13:34:26'),
(1477, 7, 18, 183, 0, '', '0000-00-00', '', '2014-07-15 13:34:26'),
(1478, 7, 18, 184, 0, '', '0000-00-00', '', '2014-07-15 13:34:26'),
(1479, 7, 18, 185, 0, '', '0000-00-00', '', '2014-07-15 13:34:26'),
(1540, 3, 39, 1, 0, '', '0000-00-00', '', '2015-04-27 23:26:23'),
(1541, 3, 39, 2, 0, '', '0000-00-00', '', '2015-04-27 23:26:23'),
(1542, 3, 39, 3, 0, '', '0000-00-00', '', '2015-04-27 23:26:23'),
(1543, 3, 39, 4, 0, '', '0000-00-00', '', '2015-04-27 23:26:23'),
(1544, 3, 39, 5, 0, '', '0000-00-00', '', '2015-04-27 23:26:23'),
(1545, 3, 39, 6, 0, '', '0000-00-00', '', '2015-04-27 23:26:23'),
(1546, 3, 39, 9, 0, '', '0000-00-00', '', '2015-04-27 23:26:23'),
(1547, 3, 39, 10, 0, '', '0000-00-00', '', '2015-04-27 23:26:23'),
(1548, 3, 39, 11, 0, '', '0000-00-00', '', '2015-04-27 23:26:23'),
(1549, 3, 39, 12, 0, '', '0000-00-00', '', '2015-04-27 23:26:23'),
(1550, 3, 39, 15, 0, '', '0000-00-00', '', '2015-04-27 23:26:23'),
(1551, 3, 39, 16, 0, '', '0000-00-00', '', '2015-04-27 23:26:23'),
(1552, 3, 39, 19, 0, '', '0000-00-00', '', '2015-04-27 23:26:23'),
(1553, 3, 39, 20, 0, '', '0000-00-00', '', '2015-04-27 23:26:23'),
(1554, 3, 39, 21, 0, '', '0000-00-00', '', '2015-04-27 23:26:23'),
(1555, 3, 39, 22, 0, '', '0000-00-00', '', '2015-04-27 23:26:23'),
(1556, 3, 39, 23, 0, '', '0000-00-00', '', '2015-04-27 23:26:23'),
(1557, 3, 39, 24, 0, '', '0000-00-00', '', '2015-04-27 23:26:23'),
(1558, 3, 39, 27, 0, '', '0000-00-00', '', '2015-04-27 23:26:23'),
(1559, 3, 39, 28, 0, '', '0000-00-00', '', '2015-04-27 23:26:23'),
(1560, 3, 39, 29, 0, '', '0000-00-00', '', '2015-04-27 23:26:23'),
(1561, 3, 39, 30, 0, '', '0000-00-00', '', '2015-04-27 23:26:23'),
(1562, 3, 39, 31, 0, '', '0000-00-00', '', '2015-04-27 23:26:23'),
(1563, 3, 39, 32, 0, '', '0000-00-00', '', '2015-04-27 23:26:23'),
(1564, 3, 39, 35, 0, '', '0000-00-00', '', '2015-04-27 23:26:23'),
(1565, 3, 39, 36, 0, '', '0000-00-00', '', '2015-04-27 23:26:23'),
(1566, 3, 39, 37, 0, '', '0000-00-00', '', '2015-04-27 23:26:23'),
(1567, 3, 39, 38, 0, '', '0000-00-00', '', '2015-04-27 23:26:23'),
(1568, 3, 39, 39, 0, '', '0000-00-00', '', '2015-04-27 23:26:23'),
(1569, 3, 39, 40, 0, '', '0000-00-00', '', '2015-04-27 23:26:23'),
(1570, 4, 40, 43, 0, '', '0000-00-00', '', '2015-04-27 23:27:37'),
(1571, 4, 40, 44, 0, '', '0000-00-00', '', '2015-04-27 23:27:37'),
(1572, 4, 40, 45, 0, '', '0000-00-00', '', '2015-04-27 23:27:37'),
(1573, 4, 40, 46, 0, '', '0000-00-00', '', '2015-04-27 23:27:37'),
(1574, 4, 40, 47, 0, '', '0000-00-00', '', '2015-04-27 23:27:37'),
(1575, 4, 40, 48, 0, '', '0000-00-00', '', '2015-04-27 23:27:37'),
(1576, 4, 40, 51, 0, '', '0000-00-00', '', '2015-04-27 23:27:37'),
(1577, 4, 40, 52, 0, '', '0000-00-00', '', '2015-04-27 23:27:37'),
(1578, 4, 40, 53, 0, '', '0000-00-00', '', '2015-04-27 23:27:37'),
(1579, 4, 40, 54, 0, '', '0000-00-00', '', '2015-04-27 23:27:37'),
(1580, 4, 40, 55, 0, '', '0000-00-00', '', '2015-04-27 23:27:37'),
(1581, 4, 40, 56, 0, '', '0000-00-00', '', '2015-04-27 23:27:37'),
(1582, 4, 40, 59, 0, '', '0000-00-00', '', '2015-04-27 23:27:37'),
(1583, 4, 40, 60, 0, '', '0000-00-00', '', '2015-04-27 23:27:37'),
(1584, 4, 40, 61, 0, '', '0000-00-00', '', '2015-04-27 23:27:37'),
(1585, 4, 40, 62, 0, '', '0000-00-00', '', '2015-04-27 23:27:37'),
(1586, 4, 40, 63, 0, '', '0000-00-00', '', '2015-04-27 23:27:37'),
(1587, 4, 40, 64, 0, '', '0000-00-00', '', '2015-04-27 23:27:37'),
(1588, 4, 40, 67, 0, '', '0000-00-00', '', '2015-04-27 23:27:37'),
(1589, 4, 40, 68, 0, '', '0000-00-00', '', '2015-04-27 23:27:37'),
(1590, 4, 40, 69, 0, '', '0000-00-00', '', '2015-04-27 23:27:37'),
(1591, 4, 40, 70, 0, '', '0000-00-00', '', '2015-04-27 23:27:37'),
(1592, 4, 40, 71, 0, '', '0000-00-00', '', '2015-04-27 23:27:37'),
(1593, 4, 40, 72, 0, '', '0000-00-00', '', '2015-04-27 23:27:37'),
(1594, 4, 40, 75, 0, '', '0000-00-00', '', '2015-04-27 23:27:37'),
(1595, 4, 40, 76, 0, '', '0000-00-00', '', '2015-04-27 23:27:37'),
(1596, 4, 40, 77, 0, '', '0000-00-00', '', '2015-04-27 23:27:37'),
(1597, 4, 40, 78, 0, '', '0000-00-00', '', '2015-04-27 23:27:37'),
(1598, 4, 40, 79, 0, '', '0000-00-00', '', '2015-04-27 23:27:37'),
(1599, 4, 40, 80, 0, '', '0000-00-00', '', '2015-04-27 23:27:37'),
(1600, 5, 32, 83, 0, '', '0000-00-00', '', '2015-04-27 23:29:07'),
(1601, 5, 32, 84, 0, '', '0000-00-00', '', '2015-04-27 23:29:07'),
(1602, 5, 32, 85, 0, '', '0000-00-00', '', '2015-04-27 23:29:07'),
(1603, 5, 32, 86, 0, '', '0000-00-00', '', '2015-04-27 23:29:07'),
(1604, 5, 32, 87, 0, '', '0000-00-00', '', '2015-04-27 23:29:07'),
(1605, 5, 32, 88, 0, '', '0000-00-00', '', '2015-04-27 23:29:07'),
(1606, 5, 32, 91, 0, '', '0000-00-00', '', '2015-04-27 23:29:07'),
(1607, 5, 32, 92, 0, '', '0000-00-00', '', '2015-04-27 23:29:07'),
(1608, 5, 32, 93, 0, '', '0000-00-00', '', '2015-04-27 23:29:07'),
(1609, 5, 32, 94, 0, '', '0000-00-00', '', '2015-04-27 23:29:07'),
(1610, 5, 32, 95, 0, '', '0000-00-00', '', '2015-04-27 23:29:07'),
(1611, 5, 32, 96, 0, '', '0000-00-00', '', '2015-04-27 23:29:07'),
(1612, 5, 32, 99, 0, '', '0000-00-00', '', '2015-04-27 23:29:07'),
(1613, 5, 32, 100, 0, '', '0000-00-00', '', '2015-04-27 23:29:07'),
(1614, 5, 32, 101, 0, '', '0000-00-00', '', '2015-04-27 23:29:07'),
(1615, 5, 32, 102, 0, '', '0000-00-00', '', '2015-04-27 23:29:07'),
(1616, 5, 32, 103, 0, '', '0000-00-00', '', '2015-04-27 23:29:07'),
(1617, 5, 32, 104, 0, '', '0000-00-00', '', '2015-04-27 23:29:07'),
(1618, 5, 32, 107, 0, '', '0000-00-00', '', '2015-04-27 23:29:07'),
(1619, 5, 32, 108, 0, '', '0000-00-00', '', '2015-04-27 23:29:07'),
(1620, 5, 32, 109, 0, '', '0000-00-00', '', '2015-04-27 23:29:07'),
(1621, 5, 32, 110, 0, '', '0000-00-00', '', '2015-04-27 23:29:07'),
(1622, 5, 32, 111, 0, '', '0000-00-00', '', '2015-04-27 23:29:07'),
(1623, 5, 32, 112, 0, '', '0000-00-00', '', '2015-04-27 23:29:07'),
(1624, 5, 32, 115, 0, '', '0000-00-00', '', '2015-04-27 23:29:07'),
(1625, 5, 32, 116, 0, '', '0000-00-00', '', '2015-04-27 23:29:07'),
(1626, 5, 32, 117, 0, '', '0000-00-00', '', '2015-04-27 23:29:07'),
(1627, 5, 32, 118, 0, '', '0000-00-00', '', '2015-04-27 23:29:07'),
(1628, 5, 32, 119, 0, '', '0000-00-00', '', '2015-04-27 23:29:07'),
(1629, 5, 32, 120, 0, '', '0000-00-00', '', '2015-04-27 23:29:07'),
(1630, 6, 33, 123, 0, '', '0000-00-00', '', '2015-04-27 23:30:18'),
(1631, 6, 33, 124, 0, '', '0000-00-00', '', '2015-04-27 23:30:18'),
(1632, 6, 33, 125, 0, '', '0000-00-00', '', '2015-04-27 23:30:18'),
(1633, 6, 33, 126, 0, '', '0000-00-00', '', '2015-04-27 23:30:18'),
(1634, 6, 33, 127, 0, '', '0000-00-00', '', '2015-04-27 23:30:18'),
(1635, 6, 33, 128, 0, '', '0000-00-00', '', '2015-04-27 23:30:18'),
(1636, 6, 33, 131, 0, '', '0000-00-00', '', '2015-04-27 23:30:18'),
(1637, 6, 33, 132, 0, '', '0000-00-00', '', '2015-04-27 23:30:18'),
(1638, 6, 33, 133, 0, '', '0000-00-00', '', '2015-04-27 23:30:18'),
(1639, 6, 33, 134, 0, '', '0000-00-00', '', '2015-04-27 23:30:18'),
(1640, 6, 33, 135, 0, '', '0000-00-00', '', '2015-04-27 23:30:18'),
(1641, 6, 33, 136, 0, '', '0000-00-00', '', '2015-04-27 23:30:18'),
(1642, 6, 33, 139, 0, '', '0000-00-00', '', '2015-04-27 23:30:18'),
(1643, 6, 33, 140, 0, '', '0000-00-00', '', '2015-04-27 23:30:18'),
(1644, 6, 33, 141, 0, '', '0000-00-00', '', '2015-04-27 23:30:18'),
(1645, 6, 33, 142, 0, '', '0000-00-00', '', '2015-04-27 23:30:18'),
(1646, 6, 33, 143, 0, '', '0000-00-00', '', '2015-04-27 23:30:18'),
(1647, 6, 33, 144, 0, '', '0000-00-00', '', '2015-04-27 23:30:18'),
(1648, 6, 33, 147, 0, '', '0000-00-00', '', '2015-04-27 23:30:18'),
(1649, 6, 33, 148, 0, '', '0000-00-00', '', '2015-04-27 23:30:18'),
(1650, 6, 33, 149, 0, '', '0000-00-00', '', '2015-04-27 23:30:18'),
(1651, 6, 33, 150, 0, '', '0000-00-00', '', '2015-04-27 23:30:18'),
(1652, 6, 33, 151, 0, '', '0000-00-00', '', '2015-04-27 23:30:18'),
(1653, 6, 33, 152, 0, '', '0000-00-00', '', '2015-04-27 23:30:18'),
(1654, 6, 33, 155, 0, '', '0000-00-00', '', '2015-04-27 23:30:18'),
(1655, 6, 33, 156, 0, '', '0000-00-00', '', '2015-04-27 23:30:18'),
(1656, 6, 33, 157, 0, '', '0000-00-00', '', '2015-04-27 23:30:18'),
(1657, 6, 33, 158, 0, '', '0000-00-00', '', '2015-04-27 23:30:18'),
(1658, 6, 33, 159, 0, '', '0000-00-00', '', '2015-04-27 23:30:18'),
(1659, 6, 33, 160, 0, '', '0000-00-00', '', '2015-04-27 23:30:18'),
(1660, 7, 34, 163, 0, '', '0000-00-00', '', '2015-04-27 23:31:46'),
(1661, 7, 34, 164, 0, '', '0000-00-00', '', '2015-04-27 23:31:46'),
(1662, 7, 34, 165, 0, '', '0000-00-00', '', '2015-04-27 23:31:46'),
(1663, 7, 34, 166, 0, '', '0000-00-00', '', '2015-04-27 23:31:46'),
(1664, 7, 34, 167, 0, '', '0000-00-00', '', '2015-04-27 23:31:46'),
(1665, 7, 34, 168, 0, '', '0000-00-00', '', '2015-04-27 23:31:46'),
(1666, 7, 34, 171, 0, '', '0000-00-00', '', '2015-04-27 23:31:46'),
(1667, 7, 34, 172, 0, '', '0000-00-00', '', '2015-04-27 23:31:46'),
(1668, 7, 34, 173, 0, '', '0000-00-00', '', '2015-04-27 23:31:46'),
(1669, 7, 34, 174, 0, '', '0000-00-00', '', '2015-04-27 23:31:46'),
(1670, 7, 34, 175, 0, '', '0000-00-00', '', '2015-04-27 23:31:46'),
(1671, 7, 34, 176, 0, '', '0000-00-00', '', '2015-04-27 23:31:46'),
(1672, 7, 34, 179, 0, '', '0000-00-00', '', '2015-04-27 23:31:46'),
(1673, 7, 34, 180, 0, '', '0000-00-00', '', '2015-04-27 23:31:46'),
(1674, 7, 34, 181, 0, '', '0000-00-00', '', '2015-04-27 23:31:46'),
(1675, 7, 34, 182, 0, '', '0000-00-00', '', '2015-04-27 23:31:46'),
(1676, 7, 34, 183, 0, '', '0000-00-00', '', '2015-04-27 23:31:46'),
(1677, 7, 34, 184, 0, '', '0000-00-00', '', '2015-04-27 23:31:46'),
(1678, 7, 34, 187, 0, '', '0000-00-00', '', '2015-04-27 23:31:46'),
(1679, 7, 34, 188, 0, '', '0000-00-00', '', '2015-04-27 23:31:46'),
(1680, 7, 34, 189, 0, '', '0000-00-00', '', '2015-04-27 23:31:46'),
(1681, 7, 34, 190, 0, '', '0000-00-00', '', '2015-04-27 23:31:46'),
(1682, 7, 34, 191, 0, '', '0000-00-00', '', '2015-04-27 23:31:46'),
(1683, 7, 34, 192, 0, '', '0000-00-00', '', '2015-04-27 23:31:46'),
(1684, 7, 34, 195, 0, '', '0000-00-00', '', '2015-04-27 23:31:46'),
(1685, 7, 34, 196, 0, '', '0000-00-00', '', '2015-04-27 23:31:46'),
(1686, 7, 34, 197, 0, '', '0000-00-00', '', '2015-04-27 23:31:46'),
(1687, 7, 34, 198, 0, '', '0000-00-00', '', '2015-04-27 23:31:46'),
(1688, 7, 34, 199, 0, '', '0000-00-00', '', '2015-04-27 23:31:46'),
(1689, 7, 34, 200, 0, '', '0000-00-00', '', '2015-04-27 23:31:46'),
(1690, 8, 35, 203, 0, '', '0000-00-00', '', '2015-04-27 23:33:00'),
(1691, 8, 35, 204, 0, '', '0000-00-00', '', '2015-04-27 23:33:00'),
(1692, 8, 35, 205, 0, '', '0000-00-00', '', '2015-04-27 23:33:00'),
(1693, 8, 35, 206, 0, '', '0000-00-00', '', '2015-04-27 23:33:00'),
(1694, 8, 35, 207, 0, '', '0000-00-00', '', '2015-04-27 23:33:00'),
(1695, 8, 35, 208, 0, '', '0000-00-00', '', '2015-04-27 23:33:00'),
(1696, 8, 35, 211, 0, '', '0000-00-00', '', '2015-04-27 23:33:00'),
(1697, 8, 35, 212, 0, '', '0000-00-00', '', '2015-04-27 23:33:00'),
(1698, 8, 35, 213, 0, '', '0000-00-00', '', '2015-04-27 23:33:00'),
(1699, 8, 35, 214, 0, '', '0000-00-00', '', '2015-04-27 23:33:00'),
(1700, 8, 35, 215, 0, '', '0000-00-00', '', '2015-04-27 23:33:00'),
(1701, 8, 35, 216, 0, '', '0000-00-00', '', '2015-04-27 23:33:00'),
(1702, 8, 35, 219, 0, '', '0000-00-00', '', '2015-04-27 23:33:00'),
(1703, 8, 35, 220, 0, '', '0000-00-00', '', '2015-04-27 23:33:00'),
(1704, 8, 35, 221, 0, '', '0000-00-00', '', '2015-04-27 23:33:00'),
(1705, 8, 35, 222, 0, '', '0000-00-00', '', '2015-04-27 23:33:00'),
(1706, 8, 35, 223, 0, '', '0000-00-00', '', '2015-04-27 23:33:00'),
(1707, 8, 35, 224, 0, '', '0000-00-00', '', '2015-04-27 23:33:00'),
(1708, 8, 35, 227, 0, '', '0000-00-00', '', '2015-04-27 23:33:00'),
(1709, 8, 35, 228, 0, '', '0000-00-00', '', '2015-04-27 23:33:00'),
(1710, 8, 35, 229, 0, '', '0000-00-00', '', '2015-04-27 23:33:00'),
(1711, 8, 35, 230, 0, '', '0000-00-00', '', '2015-04-27 23:33:00'),
(1712, 8, 35, 231, 0, '', '0000-00-00', '', '2015-04-27 23:33:00'),
(1713, 8, 35, 232, 0, '', '0000-00-00', '', '2015-04-27 23:33:00'),
(1714, 8, 35, 235, 0, '', '0000-00-00', '', '2015-04-27 23:33:00'),
(1715, 8, 35, 236, 0, '', '0000-00-00', '', '2015-04-27 23:33:00'),
(1716, 8, 35, 237, 0, '', '0000-00-00', '', '2015-04-27 23:33:00'),
(1717, 8, 35, 238, 0, '', '0000-00-00', '', '2015-04-27 23:33:00'),
(1718, 8, 35, 239, 0, '', '0000-00-00', '', '2015-04-27 23:33:00'),
(1719, 8, 35, 240, 0, '', '0000-00-00', '', '2015-04-27 23:33:00'),
(1720, 9, 36, 243, 0, '', '0000-00-00', '', '2015-04-27 23:34:50'),
(1721, 9, 36, 244, 0, '', '0000-00-00', '', '2015-04-27 23:34:50'),
(1722, 9, 36, 245, 0, '', '0000-00-00', '', '2015-04-27 23:34:50'),
(1723, 9, 36, 246, 0, '', '0000-00-00', '', '2015-04-27 23:34:50'),
(1724, 9, 36, 247, 0, '', '0000-00-00', '', '2015-04-27 23:34:50'),
(1725, 9, 36, 248, 0, '', '0000-00-00', '', '2015-04-27 23:34:50'),
(1726, 9, 36, 251, 0, '', '0000-00-00', '', '2015-04-27 23:34:50'),
(1727, 9, 36, 252, 0, '', '0000-00-00', '', '2015-04-27 23:34:50'),
(1728, 9, 36, 253, 0, '', '0000-00-00', '', '2015-04-27 23:34:50'),
(1729, 9, 36, 254, 0, '', '0000-00-00', '', '2015-04-27 23:34:50'),
(1730, 9, 36, 255, 0, '', '0000-00-00', '', '2015-04-27 23:34:50'),
(1731, 9, 36, 256, 0, '', '0000-00-00', '', '2015-04-27 23:34:50'),
(1732, 9, 36, 259, 0, '', '0000-00-00', '', '2015-04-27 23:34:50'),
(1733, 9, 36, 260, 0, '', '0000-00-00', '', '2015-04-27 23:34:50'),
(1734, 9, 36, 261, 0, '', '0000-00-00', '', '2015-04-27 23:34:50'),
(1735, 9, 36, 262, 0, '', '0000-00-00', '', '2015-04-27 23:34:50'),
(1736, 9, 36, 263, 0, '', '0000-00-00', '', '2015-04-27 23:34:50'),
(1737, 9, 36, 264, 0, '', '0000-00-00', '', '2015-04-27 23:34:50'),
(1738, 9, 36, 267, 0, '', '0000-00-00', '', '2015-04-27 23:34:50'),
(1739, 9, 36, 268, 0, '', '0000-00-00', '', '2015-04-27 23:34:50'),
(1740, 9, 36, 269, 0, '', '0000-00-00', '', '2015-04-27 23:34:50'),
(1741, 9, 36, 270, 0, '', '0000-00-00', '', '2015-04-27 23:34:50'),
(1742, 9, 36, 271, 0, '', '0000-00-00', '', '2015-04-27 23:34:50'),
(1743, 9, 36, 272, 0, '', '0000-00-00', '', '2015-04-27 23:34:50'),
(1744, 9, 36, 275, 0, '', '0000-00-00', '', '2015-04-27 23:34:50'),
(1745, 9, 36, 276, 0, '', '0000-00-00', '', '2015-04-27 23:34:50'),
(1746, 9, 36, 277, 0, '', '0000-00-00', '', '2015-04-27 23:34:50'),
(1747, 9, 36, 278, 0, '', '0000-00-00', '', '2015-04-27 23:34:50'),
(1748, 9, 36, 279, 0, '', '0000-00-00', '', '2015-04-27 23:34:50'),
(1749, 9, 36, 280, 0, '', '0000-00-00', '', '2015-04-27 23:34:50'),
(1750, 10, 37, 283, 0, '', '0000-00-00', '', '2015-04-27 23:37:26'),
(1751, 10, 37, 284, 0, '', '0000-00-00', '', '2015-04-27 23:37:26'),
(1752, 10, 37, 285, 0, '', '0000-00-00', '', '2015-04-27 23:37:26'),
(1753, 10, 37, 286, 0, '', '0000-00-00', '', '2015-04-27 23:37:26'),
(1754, 10, 37, 287, 0, '', '0000-00-00', '', '2015-04-27 23:37:26'),
(1755, 10, 37, 288, 0, '', '0000-00-00', '', '2015-04-27 23:37:26'),
(1756, 10, 37, 291, 0, '', '0000-00-00', '', '2015-04-27 23:37:26'),
(1757, 10, 37, 292, 0, '', '0000-00-00', '', '2015-04-27 23:37:26'),
(1758, 10, 37, 293, 0, '', '0000-00-00', '', '2015-04-27 23:37:26'),
(1759, 10, 37, 294, 0, '', '0000-00-00', '', '2015-04-27 23:37:26'),
(1760, 10, 37, 295, 0, '', '0000-00-00', '', '2015-04-27 23:37:26'),
(1761, 10, 37, 296, 0, '', '0000-00-00', '', '2015-04-27 23:37:26'),
(1762, 10, 37, 299, 0, '', '0000-00-00', '', '2015-04-27 23:37:26'),
(1763, 10, 37, 300, 0, '', '0000-00-00', '', '2015-04-27 23:37:26'),
(1764, 10, 37, 301, 0, '', '0000-00-00', '', '2015-04-27 23:37:26'),
(1765, 10, 37, 302, 0, '', '0000-00-00', '', '2015-04-27 23:37:26'),
(1766, 10, 37, 303, 0, '', '0000-00-00', '', '2015-04-27 23:37:26'),
(1767, 10, 37, 304, 0, '', '0000-00-00', '', '2015-04-27 23:37:26'),
(1768, 10, 37, 308, 0, '', '0000-00-00', '', '2015-04-27 23:37:26'),
(1769, 10, 37, 309, 0, '', '0000-00-00', '', '2015-04-27 23:37:26'),
(1770, 10, 37, 310, 0, '', '0000-00-00', '', '2015-04-27 23:37:26'),
(1771, 10, 37, 311, 0, '', '0000-00-00', '', '2015-04-27 23:37:26'),
(1772, 10, 37, 312, 0, '', '0000-00-00', '', '2015-04-27 23:37:26'),
(1773, 10, 37, 313, 0, '', '0000-00-00', '', '2015-04-27 23:37:26'),
(1774, 10, 37, 316, 0, '', '0000-00-00', '', '2015-04-27 23:37:26'),
(1775, 10, 37, 317, 0, '', '0000-00-00', '', '2015-04-27 23:37:26'),
(1776, 10, 37, 318, 0, '', '0000-00-00', '', '2015-04-27 23:37:26'),
(1777, 10, 37, 319, 0, '', '0000-00-00', '', '2015-04-27 23:37:26'),
(1778, 10, 37, 320, 0, '', '0000-00-00', '', '2015-04-27 23:37:26'),
(1779, 10, 37, 321, 0, '', '0000-00-00', '', '2015-04-27 23:37:26'),
(1960, 3, 43, 1, 0, '', '0000-00-00', '', '2015-05-12 10:46:29'),
(1961, 3, 43, 2, 0, '', '0000-00-00', '', '2015-05-12 10:46:29'),
(1962, 3, 43, 3, 0, '', '0000-00-00', '', '2015-05-12 10:46:29'),
(1963, 3, 43, 4, 0, '', '0000-00-00', '', '2015-05-12 10:46:29'),
(1964, 3, 43, 5, 0, '', '0000-00-00', '', '2015-05-12 10:46:29'),
(1965, 3, 43, 6, 0, '', '0000-00-00', '', '2015-05-12 10:46:29'),
(1966, 3, 43, 9, 0, '', '0000-00-00', '', '2015-05-12 10:46:29'),
(1967, 3, 43, 10, 0, '', '0000-00-00', '', '2015-05-12 10:46:29'),
(1968, 3, 43, 11, 0, '', '0000-00-00', '', '2015-05-12 10:46:29'),
(1969, 3, 43, 12, 0, '', '0000-00-00', '', '2015-05-12 10:46:29'),
(1970, 3, 43, 15, 0, '', '0000-00-00', '', '2015-05-12 10:46:29'),
(1971, 3, 43, 16, 0, '', '0000-00-00', '', '2015-05-12 10:46:29'),
(1972, 3, 43, 19, 0, '', '0000-00-00', '', '2015-05-12 10:46:29'),
(1973, 3, 43, 20, 0, '', '0000-00-00', '', '2015-05-12 10:46:29'),
(1974, 3, 43, 21, 0, '', '0000-00-00', '', '2015-05-12 10:46:29'),
(1975, 3, 43, 22, 0, '', '0000-00-00', '', '2015-05-12 10:46:29'),
(1976, 3, 43, 23, 0, '', '0000-00-00', '', '2015-05-12 10:46:29'),
(1977, 3, 43, 24, 0, '', '0000-00-00', '', '2015-05-12 10:46:29'),
(1978, 3, 43, 27, 0, '', '0000-00-00', '', '2015-05-12 10:46:29'),
(1979, 3, 43, 28, 0, '', '0000-00-00', '', '2015-05-12 10:46:29'),
(1980, 3, 43, 29, 0, '', '0000-00-00', '', '2015-05-12 10:46:29'),
(1981, 3, 43, 30, 0, '', '0000-00-00', '', '2015-05-12 10:46:29'),
(1982, 3, 43, 31, 0, '', '0000-00-00', '', '2015-05-12 10:46:29'),
(1983, 3, 43, 32, 0, '', '0000-00-00', '', '2015-05-12 10:46:29'),
(1984, 3, 43, 35, 0, '', '0000-00-00', '', '2015-05-12 10:46:29'),
(1985, 3, 43, 36, 0, '', '0000-00-00', '', '2015-05-12 10:46:29'),
(1986, 3, 43, 37, 0, '', '0000-00-00', '', '2015-05-12 10:46:29'),
(1987, 3, 43, 38, 0, '', '0000-00-00', '', '2015-05-12 10:46:29'),
(1988, 3, 43, 39, 0, '', '0000-00-00', '', '2015-05-12 10:46:29'),
(1989, 3, 43, 40, 0, '', '0000-00-00', '', '2015-05-12 10:46:29'),
(1990, 4, 44, 43, 0, '', '0000-00-00', '', '2015-05-12 10:47:13'),
(1991, 4, 44, 44, 0, '', '0000-00-00', '', '2015-05-12 10:47:13'),
(1992, 4, 44, 45, 0, '', '0000-00-00', '', '2015-05-12 10:47:13'),
(1993, 4, 44, 46, 0, '', '0000-00-00', '', '2015-05-12 10:47:13'),
(1994, 4, 44, 47, 0, '', '0000-00-00', '', '2015-05-12 10:47:13'),
(1995, 4, 44, 48, 0, '', '0000-00-00', '', '2015-05-12 10:47:13'),
(1996, 4, 44, 51, 0, '', '0000-00-00', '', '2015-05-12 10:47:13'),
(1997, 4, 44, 52, 0, '', '0000-00-00', '', '2015-05-12 10:47:13'),
(1998, 4, 44, 53, 0, '', '0000-00-00', '', '2015-05-12 10:47:13'),
(1999, 4, 44, 54, 0, '', '0000-00-00', '', '2015-05-12 10:47:13'),
(2000, 4, 44, 55, 0, '', '0000-00-00', '', '2015-05-12 10:47:13'),
(2001, 4, 44, 56, 0, '', '0000-00-00', '', '2015-05-12 10:47:13'),
(2002, 4, 44, 59, 0, '', '0000-00-00', '', '2015-05-12 10:47:13'),
(2003, 4, 44, 60, 0, '', '0000-00-00', '', '2015-05-12 10:47:13'),
(2004, 4, 44, 61, 0, '', '0000-00-00', '', '2015-05-12 10:47:13'),
(2005, 4, 44, 62, 0, '', '0000-00-00', '', '2015-05-12 10:47:13'),
(2006, 4, 44, 63, 0, '', '0000-00-00', '', '2015-05-12 10:47:13'),
(2007, 4, 44, 64, 0, '', '0000-00-00', '', '2015-05-12 10:47:13'),
(2008, 4, 44, 67, 0, '', '0000-00-00', '', '2015-05-12 10:47:13'),
(2009, 4, 44, 68, 0, '', '0000-00-00', '', '2015-05-12 10:47:13'),
(2010, 4, 44, 69, 0, '', '0000-00-00', '', '2015-05-12 10:47:13'),
(2011, 4, 44, 70, 0, '', '0000-00-00', '', '2015-05-12 10:47:13'),
(2012, 4, 44, 71, 0, '', '0000-00-00', '', '2015-05-12 10:47:13'),
(2013, 4, 44, 72, 0, '', '0000-00-00', '', '2015-05-12 10:47:13'),
(2014, 4, 44, 75, 0, '', '0000-00-00', '', '2015-05-12 10:47:13'),
(2015, 4, 44, 76, 0, '', '0000-00-00', '', '2015-05-12 10:47:13'),
(2016, 4, 44, 77, 0, '', '0000-00-00', '', '2015-05-12 10:47:13'),
(2017, 4, 44, 78, 0, '', '0000-00-00', '', '2015-05-12 10:47:13'),
(2018, 4, 44, 79, 0, '', '0000-00-00', '', '2015-05-12 10:47:13'),
(2019, 4, 44, 80, 0, '', '0000-00-00', '', '2015-05-12 10:47:13'),
(2020, 5, 45, 83, 0, '', '0000-00-00', '', '2015-05-12 10:48:02'),
(2021, 5, 45, 84, 0, '', '0000-00-00', '', '2015-05-12 10:48:02'),
(2022, 5, 45, 85, 0, '', '0000-00-00', '', '2015-05-12 10:48:02'),
(2023, 5, 45, 86, 0, '', '0000-00-00', '', '2015-05-12 10:48:02'),
(2024, 5, 45, 87, 0, '', '0000-00-00', '', '2015-05-12 10:48:02'),
(2025, 5, 45, 88, 0, '', '0000-00-00', '', '2015-05-12 10:48:02'),
(2026, 5, 45, 91, 0, '', '0000-00-00', '', '2015-05-12 10:48:02'),
(2027, 5, 45, 92, 0, '', '0000-00-00', '', '2015-05-12 10:48:02'),
(2028, 5, 45, 93, 0, '', '0000-00-00', '', '2015-05-12 10:48:02'),
(2029, 5, 45, 94, 0, '', '0000-00-00', '', '2015-05-12 10:48:02'),
(2030, 5, 45, 95, 0, '', '0000-00-00', '', '2015-05-12 10:48:02'),
(2031, 5, 45, 96, 0, '', '0000-00-00', '', '2015-05-12 10:48:02'),
(2032, 5, 45, 99, 0, '', '0000-00-00', '', '2015-05-12 10:48:02'),
(2033, 5, 45, 100, 0, '', '0000-00-00', '', '2015-05-12 10:48:02'),
(2034, 5, 45, 101, 0, '', '0000-00-00', '', '2015-05-12 10:48:02'),
(2035, 5, 45, 102, 0, '', '0000-00-00', '', '2015-05-12 10:48:02'),
(2036, 5, 45, 103, 0, '', '0000-00-00', '', '2015-05-12 10:48:02'),
(2037, 5, 45, 104, 0, '', '0000-00-00', '', '2015-05-12 10:48:02'),
(2038, 5, 45, 107, 0, '', '0000-00-00', '', '2015-05-12 10:48:02'),
(2039, 5, 45, 108, 0, '', '0000-00-00', '', '2015-05-12 10:48:02'),
(2040, 5, 45, 109, 0, '', '0000-00-00', '', '2015-05-12 10:48:02'),
(2041, 5, 45, 110, 0, '', '0000-00-00', '', '2015-05-12 10:48:02'),
(2042, 5, 45, 111, 0, '', '0000-00-00', '', '2015-05-12 10:48:02'),
(2043, 5, 45, 112, 0, '', '0000-00-00', '', '2015-05-12 10:48:02'),
(2044, 5, 45, 115, 0, '', '0000-00-00', '', '2015-05-12 10:48:02'),
(2045, 5, 45, 116, 0, '', '0000-00-00', '', '2015-05-12 10:48:02'),
(2046, 5, 45, 117, 0, '', '0000-00-00', '', '2015-05-12 10:48:02'),
(2047, 5, 45, 118, 0, '', '0000-00-00', '', '2015-05-12 10:48:02'),
(2048, 5, 45, 119, 0, '', '0000-00-00', '', '2015-05-12 10:48:02'),
(2049, 5, 45, 120, 0, '', '0000-00-00', '', '2015-05-12 10:48:02'),
(2050, 6, 46, 123, 0, '', '0000-00-00', '', '2015-05-12 10:48:43'),
(2051, 6, 46, 124, 0, '', '0000-00-00', '', '2015-05-12 10:48:43'),
(2052, 6, 46, 125, 0, '', '0000-00-00', '', '2015-05-12 10:48:43'),
(2053, 6, 46, 126, 0, '', '0000-00-00', '', '2015-05-12 10:48:43'),
(2054, 6, 46, 127, 0, '', '0000-00-00', '', '2015-05-12 10:48:43');
INSERT INTO `class_plan_game` (`id`, `class_id`, `plan_id`, `game_id`, `status`, `createdby`, `creation_date`, `modifiedby`, `modified_date`) VALUES
(2055, 6, 46, 128, 0, '', '0000-00-00', '', '2015-05-12 10:48:43'),
(2056, 6, 46, 131, 0, '', '0000-00-00', '', '2015-05-12 10:48:43'),
(2057, 6, 46, 132, 0, '', '0000-00-00', '', '2015-05-12 10:48:43'),
(2058, 6, 46, 133, 0, '', '0000-00-00', '', '2015-05-12 10:48:43'),
(2059, 6, 46, 134, 0, '', '0000-00-00', '', '2015-05-12 10:48:43'),
(2060, 6, 46, 135, 0, '', '0000-00-00', '', '2015-05-12 10:48:43'),
(2061, 6, 46, 136, 0, '', '0000-00-00', '', '2015-05-12 10:48:43'),
(2062, 6, 46, 139, 0, '', '0000-00-00', '', '2015-05-12 10:48:43'),
(2063, 6, 46, 140, 0, '', '0000-00-00', '', '2015-05-12 10:48:43'),
(2064, 6, 46, 141, 0, '', '0000-00-00', '', '2015-05-12 10:48:43'),
(2065, 6, 46, 142, 0, '', '0000-00-00', '', '2015-05-12 10:48:43'),
(2066, 6, 46, 143, 0, '', '0000-00-00', '', '2015-05-12 10:48:43'),
(2067, 6, 46, 144, 0, '', '0000-00-00', '', '2015-05-12 10:48:43'),
(2068, 6, 46, 147, 0, '', '0000-00-00', '', '2015-05-12 10:48:43'),
(2069, 6, 46, 148, 0, '', '0000-00-00', '', '2015-05-12 10:48:43'),
(2070, 6, 46, 149, 0, '', '0000-00-00', '', '2015-05-12 10:48:43'),
(2071, 6, 46, 150, 0, '', '0000-00-00', '', '2015-05-12 10:48:43'),
(2072, 6, 46, 151, 0, '', '0000-00-00', '', '2015-05-12 10:48:43'),
(2073, 6, 46, 152, 0, '', '0000-00-00', '', '2015-05-12 10:48:43'),
(2074, 6, 46, 155, 0, '', '0000-00-00', '', '2015-05-12 10:48:43'),
(2075, 6, 46, 156, 0, '', '0000-00-00', '', '2015-05-12 10:48:43'),
(2076, 6, 46, 157, 0, '', '0000-00-00', '', '2015-05-12 10:48:43'),
(2077, 6, 46, 158, 0, '', '0000-00-00', '', '2015-05-12 10:48:43'),
(2078, 6, 46, 159, 0, '', '0000-00-00', '', '2015-05-12 10:48:43'),
(2079, 6, 46, 160, 0, '', '0000-00-00', '', '2015-05-12 10:48:43'),
(2080, 7, 47, 163, 0, '', '0000-00-00', '', '2015-05-12 10:50:29'),
(2081, 7, 47, 164, 0, '', '0000-00-00', '', '2015-05-12 10:50:29'),
(2082, 7, 47, 165, 0, '', '0000-00-00', '', '2015-05-12 10:50:29'),
(2083, 7, 47, 166, 0, '', '0000-00-00', '', '2015-05-12 10:50:29'),
(2084, 7, 47, 167, 0, '', '0000-00-00', '', '2015-05-12 10:50:29'),
(2085, 7, 47, 168, 0, '', '0000-00-00', '', '2015-05-12 10:50:29'),
(2086, 7, 47, 171, 0, '', '0000-00-00', '', '2015-05-12 10:50:29'),
(2087, 7, 47, 172, 0, '', '0000-00-00', '', '2015-05-12 10:50:29'),
(2088, 7, 47, 173, 0, '', '0000-00-00', '', '2015-05-12 10:50:29'),
(2089, 7, 47, 174, 0, '', '0000-00-00', '', '2015-05-12 10:50:29'),
(2090, 7, 47, 175, 0, '', '0000-00-00', '', '2015-05-12 10:50:29'),
(2091, 7, 47, 176, 0, '', '0000-00-00', '', '2015-05-12 10:50:29'),
(2092, 7, 47, 179, 0, '', '0000-00-00', '', '2015-05-12 10:50:29'),
(2093, 7, 47, 180, 0, '', '0000-00-00', '', '2015-05-12 10:50:29'),
(2094, 7, 47, 181, 0, '', '0000-00-00', '', '2015-05-12 10:50:29'),
(2095, 7, 47, 182, 0, '', '0000-00-00', '', '2015-05-12 10:50:29'),
(2096, 7, 47, 183, 0, '', '0000-00-00', '', '2015-05-12 10:50:29'),
(2097, 7, 47, 184, 0, '', '0000-00-00', '', '2015-05-12 10:50:29'),
(2098, 7, 47, 187, 0, '', '0000-00-00', '', '2015-05-12 10:50:29'),
(2099, 7, 47, 188, 0, '', '0000-00-00', '', '2015-05-12 10:50:29'),
(2100, 7, 47, 189, 0, '', '0000-00-00', '', '2015-05-12 10:50:29'),
(2101, 7, 47, 190, 0, '', '0000-00-00', '', '2015-05-12 10:50:29'),
(2102, 7, 47, 191, 0, '', '0000-00-00', '', '2015-05-12 10:50:29'),
(2103, 7, 47, 192, 0, '', '0000-00-00', '', '2015-05-12 10:50:29'),
(2104, 7, 47, 195, 0, '', '0000-00-00', '', '2015-05-12 10:50:29'),
(2105, 7, 47, 196, 0, '', '0000-00-00', '', '2015-05-12 10:50:29'),
(2106, 7, 47, 197, 0, '', '0000-00-00', '', '2015-05-12 10:50:29'),
(2107, 7, 47, 198, 0, '', '0000-00-00', '', '2015-05-12 10:50:29'),
(2108, 7, 47, 199, 0, '', '0000-00-00', '', '2015-05-12 10:50:29'),
(2109, 7, 47, 200, 0, '', '0000-00-00', '', '2015-05-12 10:50:29'),
(2110, 8, 48, 203, 0, '', '0000-00-00', '', '2015-05-12 10:51:19'),
(2111, 8, 48, 204, 0, '', '0000-00-00', '', '2015-05-12 10:51:19'),
(2112, 8, 48, 205, 0, '', '0000-00-00', '', '2015-05-12 10:51:19'),
(2113, 8, 48, 206, 0, '', '0000-00-00', '', '2015-05-12 10:51:19'),
(2114, 8, 48, 207, 0, '', '0000-00-00', '', '2015-05-12 10:51:19'),
(2115, 8, 48, 208, 0, '', '0000-00-00', '', '2015-05-12 10:51:19'),
(2116, 8, 48, 211, 0, '', '0000-00-00', '', '2015-05-12 10:51:19'),
(2117, 8, 48, 212, 0, '', '0000-00-00', '', '2015-05-12 10:51:19'),
(2118, 8, 48, 213, 0, '', '0000-00-00', '', '2015-05-12 10:51:19'),
(2119, 8, 48, 214, 0, '', '0000-00-00', '', '2015-05-12 10:51:19'),
(2120, 8, 48, 215, 0, '', '0000-00-00', '', '2015-05-12 10:51:19'),
(2121, 8, 48, 216, 0, '', '0000-00-00', '', '2015-05-12 10:51:19'),
(2122, 8, 48, 219, 0, '', '0000-00-00', '', '2015-05-12 10:51:19'),
(2123, 8, 48, 220, 0, '', '0000-00-00', '', '2015-05-12 10:51:19'),
(2124, 8, 48, 221, 0, '', '0000-00-00', '', '2015-05-12 10:51:19'),
(2125, 8, 48, 222, 0, '', '0000-00-00', '', '2015-05-12 10:51:19'),
(2126, 8, 48, 223, 0, '', '0000-00-00', '', '2015-05-12 10:51:19'),
(2127, 8, 48, 224, 0, '', '0000-00-00', '', '2015-05-12 10:51:19'),
(2128, 8, 48, 227, 0, '', '0000-00-00', '', '2015-05-12 10:51:19'),
(2129, 8, 48, 228, 0, '', '0000-00-00', '', '2015-05-12 10:51:19'),
(2130, 8, 48, 229, 0, '', '0000-00-00', '', '2015-05-12 10:51:19'),
(2131, 8, 48, 230, 0, '', '0000-00-00', '', '2015-05-12 10:51:19'),
(2132, 8, 48, 231, 0, '', '0000-00-00', '', '2015-05-12 10:51:19'),
(2133, 8, 48, 232, 0, '', '0000-00-00', '', '2015-05-12 10:51:19'),
(2134, 8, 48, 235, 0, '', '0000-00-00', '', '2015-05-12 10:51:19'),
(2135, 8, 48, 236, 0, '', '0000-00-00', '', '2015-05-12 10:51:19'),
(2136, 8, 48, 237, 0, '', '0000-00-00', '', '2015-05-12 10:51:19'),
(2137, 8, 48, 238, 0, '', '0000-00-00', '', '2015-05-12 10:51:19'),
(2138, 8, 48, 239, 0, '', '0000-00-00', '', '2015-05-12 10:51:19'),
(2139, 8, 48, 240, 0, '', '0000-00-00', '', '2015-05-12 10:51:19'),
(2140, 9, 49, 243, 0, '', '0000-00-00', '', '2015-05-12 10:52:28'),
(2141, 9, 49, 244, 0, '', '0000-00-00', '', '2015-05-12 10:52:28'),
(2142, 9, 49, 245, 0, '', '0000-00-00', '', '2015-05-12 10:52:28'),
(2143, 9, 49, 246, 0, '', '0000-00-00', '', '2015-05-12 10:52:28'),
(2144, 9, 49, 247, 0, '', '0000-00-00', '', '2015-05-12 10:52:28'),
(2145, 9, 49, 248, 0, '', '0000-00-00', '', '2015-05-12 10:52:28'),
(2146, 9, 49, 251, 0, '', '0000-00-00', '', '2015-05-12 10:52:28'),
(2147, 9, 49, 252, 0, '', '0000-00-00', '', '2015-05-12 10:52:28'),
(2148, 9, 49, 253, 0, '', '0000-00-00', '', '2015-05-12 10:52:28'),
(2149, 9, 49, 254, 0, '', '0000-00-00', '', '2015-05-12 10:52:28'),
(2150, 9, 49, 255, 0, '', '0000-00-00', '', '2015-05-12 10:52:28'),
(2151, 9, 49, 256, 0, '', '0000-00-00', '', '2015-05-12 10:52:28'),
(2152, 9, 49, 259, 0, '', '0000-00-00', '', '2015-05-12 10:52:28'),
(2153, 9, 49, 260, 0, '', '0000-00-00', '', '2015-05-12 10:52:28'),
(2154, 9, 49, 261, 0, '', '0000-00-00', '', '2015-05-12 10:52:28'),
(2155, 9, 49, 262, 0, '', '0000-00-00', '', '2015-05-12 10:52:28'),
(2156, 9, 49, 263, 0, '', '0000-00-00', '', '2015-05-12 10:52:28'),
(2157, 9, 49, 264, 0, '', '0000-00-00', '', '2015-05-12 10:52:28'),
(2158, 9, 49, 267, 0, '', '0000-00-00', '', '2015-05-12 10:52:28'),
(2159, 9, 49, 268, 0, '', '0000-00-00', '', '2015-05-12 10:52:28'),
(2160, 9, 49, 269, 0, '', '0000-00-00', '', '2015-05-12 10:52:28'),
(2161, 9, 49, 270, 0, '', '0000-00-00', '', '2015-05-12 10:52:28'),
(2162, 9, 49, 271, 0, '', '0000-00-00', '', '2015-05-12 10:52:28'),
(2163, 9, 49, 272, 0, '', '0000-00-00', '', '2015-05-12 10:52:28'),
(2164, 9, 49, 275, 0, '', '0000-00-00', '', '2015-05-12 10:52:28'),
(2165, 9, 49, 276, 0, '', '0000-00-00', '', '2015-05-12 10:52:28'),
(2166, 9, 49, 277, 0, '', '0000-00-00', '', '2015-05-12 10:52:28'),
(2167, 9, 49, 278, 0, '', '0000-00-00', '', '2015-05-12 10:52:28'),
(2168, 9, 49, 279, 0, '', '0000-00-00', '', '2015-05-12 10:52:28'),
(2169, 9, 49, 280, 0, '', '0000-00-00', '', '2015-05-12 10:52:28'),
(2170, 10, 50, 283, 0, '', '0000-00-00', '', '2015-05-12 10:54:07'),
(2171, 10, 50, 284, 0, '', '0000-00-00', '', '2015-05-12 10:54:07'),
(2172, 10, 50, 285, 0, '', '0000-00-00', '', '2015-05-12 10:54:07'),
(2173, 10, 50, 286, 0, '', '0000-00-00', '', '2015-05-12 10:54:07'),
(2174, 10, 50, 287, 0, '', '0000-00-00', '', '2015-05-12 10:54:07'),
(2175, 10, 50, 288, 0, '', '0000-00-00', '', '2015-05-12 10:54:07'),
(2176, 10, 50, 291, 0, '', '0000-00-00', '', '2015-05-12 10:54:07'),
(2177, 10, 50, 292, 0, '', '0000-00-00', '', '2015-05-12 10:54:07'),
(2178, 10, 50, 293, 0, '', '0000-00-00', '', '2015-05-12 10:54:07'),
(2179, 10, 50, 294, 0, '', '0000-00-00', '', '2015-05-12 10:54:07'),
(2180, 10, 50, 295, 0, '', '0000-00-00', '', '2015-05-12 10:54:07'),
(2181, 10, 50, 296, 0, '', '0000-00-00', '', '2015-05-12 10:54:07'),
(2182, 10, 50, 299, 0, '', '0000-00-00', '', '2015-05-12 10:54:07'),
(2183, 10, 50, 300, 0, '', '0000-00-00', '', '2015-05-12 10:54:07'),
(2184, 10, 50, 301, 0, '', '0000-00-00', '', '2015-05-12 10:54:07'),
(2185, 10, 50, 302, 0, '', '0000-00-00', '', '2015-05-12 10:54:07'),
(2186, 10, 50, 303, 0, '', '0000-00-00', '', '2015-05-12 10:54:07'),
(2187, 10, 50, 304, 0, '', '0000-00-00', '', '2015-05-12 10:54:07'),
(2188, 10, 50, 308, 0, '', '0000-00-00', '', '2015-05-12 10:54:07'),
(2189, 10, 50, 309, 0, '', '0000-00-00', '', '2015-05-12 10:54:07'),
(2190, 10, 50, 310, 0, '', '0000-00-00', '', '2015-05-12 10:54:07'),
(2191, 10, 50, 311, 0, '', '0000-00-00', '', '2015-05-12 10:54:07'),
(2192, 10, 50, 312, 0, '', '0000-00-00', '', '2015-05-12 10:54:07'),
(2193, 10, 50, 313, 0, '', '0000-00-00', '', '2015-05-12 10:54:07'),
(2194, 10, 50, 316, 0, '', '0000-00-00', '', '2015-05-12 10:54:07'),
(2195, 10, 50, 317, 0, '', '0000-00-00', '', '2015-05-12 10:54:07'),
(2196, 10, 50, 318, 0, '', '0000-00-00', '', '2015-05-12 10:54:07'),
(2197, 10, 50, 319, 0, '', '0000-00-00', '', '2015-05-12 10:54:07'),
(2198, 10, 50, 320, 0, '', '0000-00-00', '', '2015-05-12 10:54:07'),
(2199, 10, 50, 321, 0, '', '0000-00-00', '', '2015-05-12 10:54:07'),
(2260, 3, 53, 1, 0, '', '0000-00-00', '', '2015-05-12 19:54:35'),
(2261, 3, 53, 2, 0, '', '0000-00-00', '', '2015-05-12 19:54:35'),
(2262, 3, 53, 3, 0, '', '0000-00-00', '', '2015-05-12 19:54:35'),
(2263, 3, 53, 4, 0, '', '0000-00-00', '', '2015-05-12 19:54:35'),
(2264, 3, 53, 5, 0, '', '0000-00-00', '', '2015-05-12 19:54:35'),
(2265, 3, 53, 6, 0, '', '0000-00-00', '', '2015-05-12 19:54:35'),
(2266, 3, 53, 7, 0, '', '0000-00-00', '', '2015-05-12 19:54:35'),
(2267, 3, 53, 8, 0, '', '0000-00-00', '', '2015-05-12 19:54:35'),
(2268, 3, 53, 9, 0, '', '0000-00-00', '', '2015-05-12 19:54:35'),
(2269, 3, 53, 10, 0, '', '0000-00-00', '', '2015-05-12 19:54:35'),
(2270, 3, 53, 11, 0, '', '0000-00-00', '', '2015-05-12 19:54:35'),
(2271, 3, 53, 12, 0, '', '0000-00-00', '', '2015-05-12 19:54:35'),
(2272, 3, 53, 15, 0, '', '0000-00-00', '', '2015-05-12 19:54:35'),
(2273, 3, 53, 16, 0, '', '0000-00-00', '', '2015-05-12 19:54:35'),
(2274, 3, 53, 17, 0, '', '0000-00-00', '', '2015-05-12 19:54:35'),
(2275, 3, 53, 18, 0, '', '0000-00-00', '', '2015-05-12 19:54:35'),
(2276, 3, 53, 19, 0, '', '0000-00-00', '', '2015-05-12 19:54:35'),
(2277, 3, 53, 20, 0, '', '0000-00-00', '', '2015-05-12 19:54:35'),
(2278, 3, 53, 21, 0, '', '0000-00-00', '', '2015-05-12 19:54:35'),
(2279, 3, 53, 22, 0, '', '0000-00-00', '', '2015-05-12 19:54:35'),
(2280, 3, 53, 23, 0, '', '0000-00-00', '', '2015-05-12 19:54:35'),
(2281, 3, 53, 24, 0, '', '0000-00-00', '', '2015-05-12 19:54:35'),
(2282, 3, 53, 25, 0, '', '0000-00-00', '', '2015-05-12 19:54:35'),
(2283, 3, 53, 26, 0, '', '0000-00-00', '', '2015-05-12 19:54:35'),
(2284, 3, 53, 27, 0, '', '0000-00-00', '', '2015-05-12 19:54:35'),
(2285, 3, 53, 28, 0, '', '0000-00-00', '', '2015-05-12 19:54:35'),
(2286, 3, 53, 29, 0, '', '0000-00-00', '', '2015-05-12 19:54:35'),
(2287, 3, 53, 30, 0, '', '0000-00-00', '', '2015-05-12 19:54:35'),
(2288, 3, 53, 31, 0, '', '0000-00-00', '', '2015-05-12 19:54:35'),
(2289, 3, 53, 32, 0, '', '0000-00-00', '', '2015-05-12 19:54:35'),
(2290, 3, 53, 33, 0, '', '0000-00-00', '', '2015-05-12 19:54:35'),
(2291, 3, 53, 34, 0, '', '0000-00-00', '', '2015-05-12 19:54:35'),
(2292, 3, 53, 35, 0, '', '0000-00-00', '', '2015-05-12 19:54:35'),
(2293, 3, 53, 36, 0, '', '0000-00-00', '', '2015-05-12 19:54:35'),
(2294, 3, 53, 37, 0, '', '0000-00-00', '', '2015-05-12 19:54:35'),
(2295, 3, 53, 38, 0, '', '0000-00-00', '', '2015-05-12 19:54:35'),
(2296, 3, 53, 39, 0, '', '0000-00-00', '', '2015-05-12 19:54:35'),
(2297, 3, 53, 40, 0, '', '0000-00-00', '', '2015-05-12 19:54:35'),
(2298, 3, 53, 41, 0, '', '0000-00-00', '', '2015-05-12 19:54:35'),
(2299, 3, 53, 42, 0, '', '0000-00-00', '', '2015-05-12 19:54:35'),
(2300, 3, 53, 324, 0, '', '0000-00-00', '', '2015-05-12 19:54:35'),
(2301, 3, 53, 325, 0, '', '0000-00-00', '', '2015-05-12 19:54:35'),
(2302, 3, 53, 326, 0, '', '0000-00-00', '', '2015-05-12 19:54:35'),
(2303, 3, 53, 327, 0, '', '0000-00-00', '', '2015-05-12 19:54:35'),
(2304, 3, 53, 328, 0, '', '0000-00-00', '', '2015-05-12 19:54:35'),
(2305, 3, 53, 329, 0, '', '0000-00-00', '', '2015-05-12 19:54:35'),
(2306, 3, 53, 330, 0, '', '0000-00-00', '', '2015-05-12 19:54:35'),
(2307, 3, 53, 331, 0, '', '0000-00-00', '', '2015-05-12 19:54:35'),
(2308, 3, 53, 332, 0, '', '0000-00-00', '', '2015-05-12 19:54:35'),
(2309, 3, 53, 333, 0, '', '0000-00-00', '', '2015-05-12 19:54:35'),
(2310, 3, 53, 404, 0, '', '0000-00-00', '', '2015-05-12 19:54:35'),
(2311, 3, 53, 405, 0, '', '0000-00-00', '', '2015-05-12 19:54:35'),
(2312, 3, 53, 406, 0, '', '0000-00-00', '', '2015-05-12 19:54:35'),
(2313, 3, 53, 407, 0, '', '0000-00-00', '', '2015-05-12 19:54:35'),
(2314, 3, 53, 408, 0, '', '0000-00-00', '', '2015-05-12 19:54:35'),
(2315, 3, 53, 409, 0, '', '0000-00-00', '', '2015-05-12 19:54:35'),
(2316, 3, 53, 410, 0, '', '0000-00-00', '', '2015-05-12 19:54:35'),
(2317, 3, 53, 411, 0, '', '0000-00-00', '', '2015-05-12 19:54:35'),
(2318, 3, 53, 412, 0, '', '0000-00-00', '', '2015-05-12 19:54:35'),
(2319, 3, 53, 413, 0, '', '0000-00-00', '', '2015-05-12 19:54:35'),
(2320, 4, 54, 43, 0, '', '0000-00-00', '', '2015-05-12 19:55:31'),
(2321, 4, 54, 44, 0, '', '0000-00-00', '', '2015-05-12 19:55:31'),
(2322, 4, 54, 45, 0, '', '0000-00-00', '', '2015-05-12 19:55:31'),
(2323, 4, 54, 46, 0, '', '0000-00-00', '', '2015-05-12 19:55:31'),
(2324, 4, 54, 47, 0, '', '0000-00-00', '', '2015-05-12 19:55:31'),
(2325, 4, 54, 48, 0, '', '0000-00-00', '', '2015-05-12 19:55:31'),
(2326, 4, 54, 49, 0, '', '0000-00-00', '', '2015-05-12 19:55:31'),
(2327, 4, 54, 50, 0, '', '0000-00-00', '', '2015-05-12 19:55:31'),
(2328, 4, 54, 51, 0, '', '0000-00-00', '', '2015-05-12 19:55:31'),
(2329, 4, 54, 52, 0, '', '0000-00-00', '', '2015-05-12 19:55:31'),
(2330, 4, 54, 53, 0, '', '0000-00-00', '', '2015-05-12 19:55:31'),
(2331, 4, 54, 54, 0, '', '0000-00-00', '', '2015-05-12 19:55:31'),
(2332, 4, 54, 55, 0, '', '0000-00-00', '', '2015-05-12 19:55:31'),
(2333, 4, 54, 56, 0, '', '0000-00-00', '', '2015-05-12 19:55:31'),
(2334, 4, 54, 57, 0, '', '0000-00-00', '', '2015-05-12 19:55:31'),
(2335, 4, 54, 58, 0, '', '0000-00-00', '', '2015-05-12 19:55:31'),
(2336, 4, 54, 59, 0, '', '0000-00-00', '', '2015-05-12 19:55:31'),
(2337, 4, 54, 60, 0, '', '0000-00-00', '', '2015-05-12 19:55:31'),
(2338, 4, 54, 61, 0, '', '0000-00-00', '', '2015-05-12 19:55:31'),
(2339, 4, 54, 62, 0, '', '0000-00-00', '', '2015-05-12 19:55:31'),
(2340, 4, 54, 63, 0, '', '0000-00-00', '', '2015-05-12 19:55:31'),
(2341, 4, 54, 64, 0, '', '0000-00-00', '', '2015-05-12 19:55:31'),
(2342, 4, 54, 65, 0, '', '0000-00-00', '', '2015-05-12 19:55:31'),
(2343, 4, 54, 66, 0, '', '0000-00-00', '', '2015-05-12 19:55:31'),
(2344, 4, 54, 67, 0, '', '0000-00-00', '', '2015-05-12 19:55:31'),
(2345, 4, 54, 68, 0, '', '0000-00-00', '', '2015-05-12 19:55:31'),
(2346, 4, 54, 69, 0, '', '0000-00-00', '', '2015-05-12 19:55:31'),
(2347, 4, 54, 70, 0, '', '0000-00-00', '', '2015-05-12 19:55:31'),
(2348, 4, 54, 71, 0, '', '0000-00-00', '', '2015-05-12 19:55:31'),
(2349, 4, 54, 72, 0, '', '0000-00-00', '', '2015-05-12 19:55:31'),
(2350, 4, 54, 73, 0, '', '0000-00-00', '', '2015-05-12 19:55:31'),
(2351, 4, 54, 74, 0, '', '0000-00-00', '', '2015-05-12 19:55:31'),
(2352, 4, 54, 75, 0, '', '0000-00-00', '', '2015-05-12 19:55:31'),
(2353, 4, 54, 76, 0, '', '0000-00-00', '', '2015-05-12 19:55:31'),
(2354, 4, 54, 77, 0, '', '0000-00-00', '', '2015-05-12 19:55:31'),
(2355, 4, 54, 78, 0, '', '0000-00-00', '', '2015-05-12 19:55:31'),
(2356, 4, 54, 79, 0, '', '0000-00-00', '', '2015-05-12 19:55:31'),
(2357, 4, 54, 80, 0, '', '0000-00-00', '', '2015-05-12 19:55:31'),
(2358, 4, 54, 81, 0, '', '0000-00-00', '', '2015-05-12 19:55:31'),
(2359, 4, 54, 82, 0, '', '0000-00-00', '', '2015-05-12 19:55:31'),
(2360, 4, 54, 334, 0, '', '0000-00-00', '', '2015-05-12 19:55:31'),
(2361, 4, 54, 335, 0, '', '0000-00-00', '', '2015-05-12 19:55:31'),
(2362, 4, 54, 336, 0, '', '0000-00-00', '', '2015-05-12 19:55:31'),
(2363, 4, 54, 337, 0, '', '0000-00-00', '', '2015-05-12 19:55:31'),
(2364, 4, 54, 338, 0, '', '0000-00-00', '', '2015-05-12 19:55:31'),
(2365, 4, 54, 339, 0, '', '0000-00-00', '', '2015-05-12 19:55:31'),
(2366, 4, 54, 340, 0, '', '0000-00-00', '', '2015-05-12 19:55:31'),
(2367, 4, 54, 341, 0, '', '0000-00-00', '', '2015-05-12 19:55:31'),
(2368, 4, 54, 342, 0, '', '0000-00-00', '', '2015-05-12 19:55:31'),
(2369, 4, 54, 343, 0, '', '0000-00-00', '', '2015-05-12 19:55:31'),
(2370, 4, 54, 404, 0, '', '0000-00-00', '', '2015-05-12 19:55:31'),
(2371, 4, 54, 405, 0, '', '0000-00-00', '', '2015-05-12 19:55:31'),
(2372, 4, 54, 406, 0, '', '0000-00-00', '', '2015-05-12 19:55:31'),
(2373, 4, 54, 407, 0, '', '0000-00-00', '', '2015-05-12 19:55:31'),
(2374, 4, 54, 408, 0, '', '0000-00-00', '', '2015-05-12 19:55:31'),
(2375, 4, 54, 409, 0, '', '0000-00-00', '', '2015-05-12 19:55:31'),
(2376, 4, 54, 410, 0, '', '0000-00-00', '', '2015-05-12 19:55:31'),
(2377, 4, 54, 411, 0, '', '0000-00-00', '', '2015-05-12 19:55:31'),
(2378, 4, 54, 412, 0, '', '0000-00-00', '', '2015-05-12 19:55:31'),
(2379, 4, 54, 413, 0, '', '0000-00-00', '', '2015-05-12 19:55:31'),
(2380, 5, 55, 83, 0, '', '0000-00-00', '', '2015-05-12 19:56:49'),
(2381, 5, 55, 84, 0, '', '0000-00-00', '', '2015-05-12 19:56:49'),
(2382, 5, 55, 85, 0, '', '0000-00-00', '', '2015-05-12 19:56:49'),
(2383, 5, 55, 86, 0, '', '0000-00-00', '', '2015-05-12 19:56:49'),
(2384, 5, 55, 87, 0, '', '0000-00-00', '', '2015-05-12 19:56:49'),
(2385, 5, 55, 88, 0, '', '0000-00-00', '', '2015-05-12 19:56:49'),
(2386, 5, 55, 89, 0, '', '0000-00-00', '', '2015-05-12 19:56:49'),
(2387, 5, 55, 90, 0, '', '0000-00-00', '', '2015-05-12 19:56:49'),
(2388, 5, 55, 91, 0, '', '0000-00-00', '', '2015-05-12 19:56:49'),
(2389, 5, 55, 92, 0, '', '0000-00-00', '', '2015-05-12 19:56:49'),
(2390, 5, 55, 93, 0, '', '0000-00-00', '', '2015-05-12 19:56:49'),
(2391, 5, 55, 94, 0, '', '0000-00-00', '', '2015-05-12 19:56:49'),
(2392, 5, 55, 95, 0, '', '0000-00-00', '', '2015-05-12 19:56:49'),
(2393, 5, 55, 96, 0, '', '0000-00-00', '', '2015-05-12 19:56:49'),
(2394, 5, 55, 97, 0, '', '0000-00-00', '', '2015-05-12 19:56:49'),
(2395, 5, 55, 98, 0, '', '0000-00-00', '', '2015-05-12 19:56:49'),
(2396, 5, 55, 99, 0, '', '0000-00-00', '', '2015-05-12 19:56:49'),
(2397, 5, 55, 100, 0, '', '0000-00-00', '', '2015-05-12 19:56:49'),
(2398, 5, 55, 101, 0, '', '0000-00-00', '', '2015-05-12 19:56:49'),
(2399, 5, 55, 102, 0, '', '0000-00-00', '', '2015-05-12 19:56:49'),
(2400, 5, 55, 103, 0, '', '0000-00-00', '', '2015-05-12 19:56:49'),
(2401, 5, 55, 104, 0, '', '0000-00-00', '', '2015-05-12 19:56:49'),
(2402, 5, 55, 105, 0, '', '0000-00-00', '', '2015-05-12 19:56:49'),
(2403, 5, 55, 106, 0, '', '0000-00-00', '', '2015-05-12 19:56:49'),
(2404, 5, 55, 107, 0, '', '0000-00-00', '', '2015-05-12 19:56:49'),
(2405, 5, 55, 108, 0, '', '0000-00-00', '', '2015-05-12 19:56:49'),
(2406, 5, 55, 109, 0, '', '0000-00-00', '', '2015-05-12 19:56:49'),
(2407, 5, 55, 110, 0, '', '0000-00-00', '', '2015-05-12 19:56:49'),
(2408, 5, 55, 111, 0, '', '0000-00-00', '', '2015-05-12 19:56:49'),
(2409, 5, 55, 112, 0, '', '0000-00-00', '', '2015-05-12 19:56:49'),
(2410, 5, 55, 113, 0, '', '0000-00-00', '', '2015-05-12 19:56:49'),
(2411, 5, 55, 114, 0, '', '0000-00-00', '', '2015-05-12 19:56:49'),
(2412, 5, 55, 115, 0, '', '0000-00-00', '', '2015-05-12 19:56:49'),
(2413, 5, 55, 116, 0, '', '0000-00-00', '', '2015-05-12 19:56:49'),
(2414, 5, 55, 117, 0, '', '0000-00-00', '', '2015-05-12 19:56:49'),
(2415, 5, 55, 118, 0, '', '0000-00-00', '', '2015-05-12 19:56:49'),
(2416, 5, 55, 119, 0, '', '0000-00-00', '', '2015-05-12 19:56:49'),
(2417, 5, 55, 120, 0, '', '0000-00-00', '', '2015-05-12 19:56:49'),
(2418, 5, 55, 121, 0, '', '0000-00-00', '', '2015-05-12 19:56:49'),
(2419, 5, 55, 122, 0, '', '0000-00-00', '', '2015-05-12 19:56:49'),
(2420, 5, 55, 344, 0, '', '0000-00-00', '', '2015-05-12 19:56:49'),
(2421, 5, 55, 345, 0, '', '0000-00-00', '', '2015-05-12 19:56:49'),
(2422, 5, 55, 346, 0, '', '0000-00-00', '', '2015-05-12 19:56:49'),
(2423, 5, 55, 347, 0, '', '0000-00-00', '', '2015-05-12 19:56:49'),
(2424, 5, 55, 348, 0, '', '0000-00-00', '', '2015-05-12 19:56:49'),
(2425, 5, 55, 349, 0, '', '0000-00-00', '', '2015-05-12 19:56:49'),
(2426, 5, 55, 350, 0, '', '0000-00-00', '', '2015-05-12 19:56:49'),
(2427, 5, 55, 351, 0, '', '0000-00-00', '', '2015-05-12 19:56:49'),
(2428, 5, 55, 352, 0, '', '0000-00-00', '', '2015-05-12 19:56:49'),
(2429, 5, 55, 353, 0, '', '0000-00-00', '', '2015-05-12 19:56:49'),
(2430, 5, 55, 404, 0, '', '0000-00-00', '', '2015-05-12 19:56:49'),
(2431, 5, 55, 405, 0, '', '0000-00-00', '', '2015-05-12 19:56:49'),
(2432, 5, 55, 406, 0, '', '0000-00-00', '', '2015-05-12 19:56:49'),
(2433, 5, 55, 407, 0, '', '0000-00-00', '', '2015-05-12 19:56:49'),
(2434, 5, 55, 408, 0, '', '0000-00-00', '', '2015-05-12 19:56:49'),
(2435, 5, 55, 409, 0, '', '0000-00-00', '', '2015-05-12 19:56:49'),
(2436, 5, 55, 410, 0, '', '0000-00-00', '', '2015-05-12 19:56:49'),
(2437, 5, 55, 411, 0, '', '0000-00-00', '', '2015-05-12 19:56:49'),
(2438, 5, 55, 412, 0, '', '0000-00-00', '', '2015-05-12 19:56:49'),
(2439, 5, 55, 413, 0, '', '0000-00-00', '', '2015-05-12 19:56:49'),
(2440, 6, 56, 123, 0, '', '0000-00-00', '', '2015-05-12 19:59:32'),
(2441, 6, 56, 124, 0, '', '0000-00-00', '', '2015-05-12 19:59:32'),
(2442, 6, 56, 125, 0, '', '0000-00-00', '', '2015-05-12 19:59:32'),
(2443, 6, 56, 126, 0, '', '0000-00-00', '', '2015-05-12 19:59:32'),
(2444, 6, 56, 127, 0, '', '0000-00-00', '', '2015-05-12 19:59:32'),
(2445, 6, 56, 128, 0, '', '0000-00-00', '', '2015-05-12 19:59:32'),
(2446, 6, 56, 129, 0, '', '0000-00-00', '', '2015-05-12 19:59:32'),
(2447, 6, 56, 130, 0, '', '0000-00-00', '', '2015-05-12 19:59:32'),
(2448, 6, 56, 131, 0, '', '0000-00-00', '', '2015-05-12 19:59:32'),
(2449, 6, 56, 132, 0, '', '0000-00-00', '', '2015-05-12 19:59:32'),
(2450, 6, 56, 133, 0, '', '0000-00-00', '', '2015-05-12 19:59:32'),
(2451, 6, 56, 134, 0, '', '0000-00-00', '', '2015-05-12 19:59:32'),
(2452, 6, 56, 135, 0, '', '0000-00-00', '', '2015-05-12 19:59:32'),
(2453, 6, 56, 136, 0, '', '0000-00-00', '', '2015-05-12 19:59:32'),
(2454, 6, 56, 137, 0, '', '0000-00-00', '', '2015-05-12 19:59:32'),
(2455, 6, 56, 138, 0, '', '0000-00-00', '', '2015-05-12 19:59:32'),
(2456, 6, 56, 139, 0, '', '0000-00-00', '', '2015-05-12 19:59:32'),
(2457, 6, 56, 140, 0, '', '0000-00-00', '', '2015-05-12 19:59:32'),
(2458, 6, 56, 141, 0, '', '0000-00-00', '', '2015-05-12 19:59:32'),
(2459, 6, 56, 142, 0, '', '0000-00-00', '', '2015-05-12 19:59:32'),
(2460, 6, 56, 143, 0, '', '0000-00-00', '', '2015-05-12 19:59:32'),
(2461, 6, 56, 144, 0, '', '0000-00-00', '', '2015-05-12 19:59:32'),
(2462, 6, 56, 145, 0, '', '0000-00-00', '', '2015-05-12 19:59:32'),
(2463, 6, 56, 146, 0, '', '0000-00-00', '', '2015-05-12 19:59:32'),
(2464, 6, 56, 147, 0, '', '0000-00-00', '', '2015-05-12 19:59:32'),
(2465, 6, 56, 148, 0, '', '0000-00-00', '', '2015-05-12 19:59:32'),
(2466, 6, 56, 149, 0, '', '0000-00-00', '', '2015-05-12 19:59:32'),
(2467, 6, 56, 150, 0, '', '0000-00-00', '', '2015-05-12 19:59:32'),
(2468, 6, 56, 151, 0, '', '0000-00-00', '', '2015-05-12 19:59:32'),
(2469, 6, 56, 152, 0, '', '0000-00-00', '', '2015-05-12 19:59:32'),
(2470, 6, 56, 153, 0, '', '0000-00-00', '', '2015-05-12 19:59:32'),
(2471, 6, 56, 154, 0, '', '0000-00-00', '', '2015-05-12 19:59:32'),
(2472, 6, 56, 155, 0, '', '0000-00-00', '', '2015-05-12 19:59:32'),
(2473, 6, 56, 156, 0, '', '0000-00-00', '', '2015-05-12 19:59:32'),
(2474, 6, 56, 157, 0, '', '0000-00-00', '', '2015-05-12 19:59:32'),
(2475, 6, 56, 158, 0, '', '0000-00-00', '', '2015-05-12 19:59:32'),
(2476, 6, 56, 159, 0, '', '0000-00-00', '', '2015-05-12 19:59:32'),
(2477, 6, 56, 160, 0, '', '0000-00-00', '', '2015-05-12 19:59:32'),
(2478, 6, 56, 161, 0, '', '0000-00-00', '', '2015-05-12 19:59:32'),
(2479, 6, 56, 162, 0, '', '0000-00-00', '', '2015-05-12 19:59:32'),
(2480, 6, 56, 354, 0, '', '0000-00-00', '', '2015-05-12 19:59:32'),
(2481, 6, 56, 355, 0, '', '0000-00-00', '', '2015-05-12 19:59:32'),
(2482, 6, 56, 356, 0, '', '0000-00-00', '', '2015-05-12 19:59:32'),
(2483, 6, 56, 357, 0, '', '0000-00-00', '', '2015-05-12 19:59:32'),
(2484, 6, 56, 358, 0, '', '0000-00-00', '', '2015-05-12 19:59:32'),
(2485, 6, 56, 359, 0, '', '0000-00-00', '', '2015-05-12 19:59:32'),
(2486, 6, 56, 360, 0, '', '0000-00-00', '', '2015-05-12 19:59:32'),
(2487, 6, 56, 361, 0, '', '0000-00-00', '', '2015-05-12 19:59:32'),
(2488, 6, 56, 362, 0, '', '0000-00-00', '', '2015-05-12 19:59:32'),
(2489, 6, 56, 363, 0, '', '0000-00-00', '', '2015-05-12 19:59:32'),
(2490, 6, 56, 404, 0, '', '0000-00-00', '', '2015-05-12 19:59:32'),
(2491, 6, 56, 405, 0, '', '0000-00-00', '', '2015-05-12 19:59:32'),
(2492, 6, 56, 406, 0, '', '0000-00-00', '', '2015-05-12 19:59:32'),
(2493, 6, 56, 407, 0, '', '0000-00-00', '', '2015-05-12 19:59:32'),
(2494, 6, 56, 408, 0, '', '0000-00-00', '', '2015-05-12 19:59:32'),
(2495, 6, 56, 409, 0, '', '0000-00-00', '', '2015-05-12 19:59:32'),
(2496, 6, 56, 410, 0, '', '0000-00-00', '', '2015-05-12 19:59:32'),
(2497, 6, 56, 411, 0, '', '0000-00-00', '', '2015-05-12 19:59:32'),
(2498, 6, 56, 412, 0, '', '0000-00-00', '', '2015-05-12 19:59:32'),
(2499, 6, 56, 413, 0, '', '0000-00-00', '', '2015-05-12 19:59:32'),
(2500, 7, 57, 163, 0, '', '0000-00-00', '', '2015-05-12 20:00:55'),
(2501, 7, 57, 164, 0, '', '0000-00-00', '', '2015-05-12 20:00:55'),
(2502, 7, 57, 165, 0, '', '0000-00-00', '', '2015-05-12 20:00:55'),
(2503, 7, 57, 166, 0, '', '0000-00-00', '', '2015-05-12 20:00:55'),
(2504, 7, 57, 167, 0, '', '0000-00-00', '', '2015-05-12 20:00:55'),
(2505, 7, 57, 168, 0, '', '0000-00-00', '', '2015-05-12 20:00:55'),
(2506, 7, 57, 169, 0, '', '0000-00-00', '', '2015-05-12 20:00:55'),
(2507, 7, 57, 170, 0, '', '0000-00-00', '', '2015-05-12 20:00:55'),
(2508, 7, 57, 171, 0, '', '0000-00-00', '', '2015-05-12 20:00:55'),
(2509, 7, 57, 172, 0, '', '0000-00-00', '', '2015-05-12 20:00:55'),
(2510, 7, 57, 173, 0, '', '0000-00-00', '', '2015-05-12 20:00:55'),
(2511, 7, 57, 174, 0, '', '0000-00-00', '', '2015-05-12 20:00:55'),
(2512, 7, 57, 175, 0, '', '0000-00-00', '', '2015-05-12 20:00:55'),
(2513, 7, 57, 176, 0, '', '0000-00-00', '', '2015-05-12 20:00:55'),
(2514, 7, 57, 177, 0, '', '0000-00-00', '', '2015-05-12 20:00:55'),
(2515, 7, 57, 178, 0, '', '0000-00-00', '', '2015-05-12 20:00:55'),
(2516, 7, 57, 179, 0, '', '0000-00-00', '', '2015-05-12 20:00:55'),
(2517, 7, 57, 180, 0, '', '0000-00-00', '', '2015-05-12 20:00:55'),
(2518, 7, 57, 181, 0, '', '0000-00-00', '', '2015-05-12 20:00:55'),
(2519, 7, 57, 182, 0, '', '0000-00-00', '', '2015-05-12 20:00:55'),
(2520, 7, 57, 183, 0, '', '0000-00-00', '', '2015-05-12 20:00:55'),
(2521, 7, 57, 184, 0, '', '0000-00-00', '', '2015-05-12 20:00:55'),
(2522, 7, 57, 185, 0, '', '0000-00-00', '', '2015-05-12 20:00:55'),
(2523, 7, 57, 186, 0, '', '0000-00-00', '', '2015-05-12 20:00:55'),
(2524, 7, 57, 187, 0, '', '0000-00-00', '', '2015-05-12 20:00:55'),
(2525, 7, 57, 188, 0, '', '0000-00-00', '', '2015-05-12 20:00:55'),
(2526, 7, 57, 189, 0, '', '0000-00-00', '', '2015-05-12 20:00:55'),
(2527, 7, 57, 190, 0, '', '0000-00-00', '', '2015-05-12 20:00:55'),
(2528, 7, 57, 191, 0, '', '0000-00-00', '', '2015-05-12 20:00:55'),
(2529, 7, 57, 192, 0, '', '0000-00-00', '', '2015-05-12 20:00:55'),
(2530, 7, 57, 193, 0, '', '0000-00-00', '', '2015-05-12 20:00:55'),
(2531, 7, 57, 194, 0, '', '0000-00-00', '', '2015-05-12 20:00:55'),
(2532, 7, 57, 195, 0, '', '0000-00-00', '', '2015-05-12 20:00:55'),
(2533, 7, 57, 196, 0, '', '0000-00-00', '', '2015-05-12 20:00:55'),
(2534, 7, 57, 197, 0, '', '0000-00-00', '', '2015-05-12 20:00:55'),
(2535, 7, 57, 198, 0, '', '0000-00-00', '', '2015-05-12 20:00:55'),
(2536, 7, 57, 199, 0, '', '0000-00-00', '', '2015-05-12 20:00:55'),
(2537, 7, 57, 200, 0, '', '0000-00-00', '', '2015-05-12 20:00:55'),
(2538, 7, 57, 201, 0, '', '0000-00-00', '', '2015-05-12 20:00:55'),
(2539, 7, 57, 202, 0, '', '0000-00-00', '', '2015-05-12 20:00:55'),
(2540, 7, 57, 364, 0, '', '0000-00-00', '', '2015-05-12 20:00:55'),
(2541, 7, 57, 365, 0, '', '0000-00-00', '', '2015-05-12 20:00:55'),
(2542, 7, 57, 366, 0, '', '0000-00-00', '', '2015-05-12 20:00:55'),
(2543, 7, 57, 367, 0, '', '0000-00-00', '', '2015-05-12 20:00:55'),
(2544, 7, 57, 368, 0, '', '0000-00-00', '', '2015-05-12 20:00:55'),
(2545, 7, 57, 369, 0, '', '0000-00-00', '', '2015-05-12 20:00:55'),
(2546, 7, 57, 370, 0, '', '0000-00-00', '', '2015-05-12 20:00:55'),
(2547, 7, 57, 371, 0, '', '0000-00-00', '', '2015-05-12 20:00:55'),
(2548, 7, 57, 372, 0, '', '0000-00-00', '', '2015-05-12 20:00:55'),
(2549, 7, 57, 373, 0, '', '0000-00-00', '', '2015-05-12 20:00:55'),
(2550, 7, 57, 404, 0, '', '0000-00-00', '', '2015-05-12 20:00:55'),
(2551, 7, 57, 405, 0, '', '0000-00-00', '', '2015-05-12 20:00:55'),
(2552, 7, 57, 406, 0, '', '0000-00-00', '', '2015-05-12 20:00:55'),
(2553, 7, 57, 407, 0, '', '0000-00-00', '', '2015-05-12 20:00:55'),
(2554, 7, 57, 408, 0, '', '0000-00-00', '', '2015-05-12 20:00:55'),
(2555, 7, 57, 409, 0, '', '0000-00-00', '', '2015-05-12 20:00:55'),
(2556, 7, 57, 410, 0, '', '0000-00-00', '', '2015-05-12 20:00:55'),
(2557, 7, 57, 411, 0, '', '0000-00-00', '', '2015-05-12 20:00:55'),
(2558, 7, 57, 412, 0, '', '0000-00-00', '', '2015-05-12 20:00:55'),
(2559, 7, 57, 413, 0, '', '0000-00-00', '', '2015-05-12 20:00:55'),
(2560, 8, 58, 203, 0, '', '0000-00-00', '', '2015-05-12 20:02:41'),
(2561, 8, 58, 204, 0, '', '0000-00-00', '', '2015-05-12 20:02:41'),
(2562, 8, 58, 205, 0, '', '0000-00-00', '', '2015-05-12 20:02:41'),
(2563, 8, 58, 206, 0, '', '0000-00-00', '', '2015-05-12 20:02:41'),
(2564, 8, 58, 207, 0, '', '0000-00-00', '', '2015-05-12 20:02:41'),
(2565, 8, 58, 208, 0, '', '0000-00-00', '', '2015-05-12 20:02:41'),
(2566, 8, 58, 209, 0, '', '0000-00-00', '', '2015-05-12 20:02:41'),
(2567, 8, 58, 210, 0, '', '0000-00-00', '', '2015-05-12 20:02:41'),
(2568, 8, 58, 211, 0, '', '0000-00-00', '', '2015-05-12 20:02:41'),
(2569, 8, 58, 212, 0, '', '0000-00-00', '', '2015-05-12 20:02:41'),
(2570, 8, 58, 213, 0, '', '0000-00-00', '', '2015-05-12 20:02:41'),
(2571, 8, 58, 214, 0, '', '0000-00-00', '', '2015-05-12 20:02:41'),
(2572, 8, 58, 215, 0, '', '0000-00-00', '', '2015-05-12 20:02:41'),
(2573, 8, 58, 216, 0, '', '0000-00-00', '', '2015-05-12 20:02:41'),
(2574, 8, 58, 217, 0, '', '0000-00-00', '', '2015-05-12 20:02:41'),
(2575, 8, 58, 218, 0, '', '0000-00-00', '', '2015-05-12 20:02:41'),
(2576, 8, 58, 219, 0, '', '0000-00-00', '', '2015-05-12 20:02:41'),
(2577, 8, 58, 220, 0, '', '0000-00-00', '', '2015-05-12 20:02:41'),
(2578, 8, 58, 221, 0, '', '0000-00-00', '', '2015-05-12 20:02:41'),
(2579, 8, 58, 222, 0, '', '0000-00-00', '', '2015-05-12 20:02:41'),
(2580, 8, 58, 223, 0, '', '0000-00-00', '', '2015-05-12 20:02:41'),
(2581, 8, 58, 224, 0, '', '0000-00-00', '', '2015-05-12 20:02:41'),
(2582, 8, 58, 225, 0, '', '0000-00-00', '', '2015-05-12 20:02:41'),
(2583, 8, 58, 226, 0, '', '0000-00-00', '', '2015-05-12 20:02:41'),
(2584, 8, 58, 227, 0, '', '0000-00-00', '', '2015-05-12 20:02:41'),
(2585, 8, 58, 228, 0, '', '0000-00-00', '', '2015-05-12 20:02:41'),
(2586, 8, 58, 229, 0, '', '0000-00-00', '', '2015-05-12 20:02:41'),
(2587, 8, 58, 230, 0, '', '0000-00-00', '', '2015-05-12 20:02:41'),
(2588, 8, 58, 231, 0, '', '0000-00-00', '', '2015-05-12 20:02:41'),
(2589, 8, 58, 232, 0, '', '0000-00-00', '', '2015-05-12 20:02:41'),
(2590, 8, 58, 233, 0, '', '0000-00-00', '', '2015-05-12 20:02:41'),
(2591, 8, 58, 234, 0, '', '0000-00-00', '', '2015-05-12 20:02:41'),
(2592, 8, 58, 235, 0, '', '0000-00-00', '', '2015-05-12 20:02:41'),
(2593, 8, 58, 236, 0, '', '0000-00-00', '', '2015-05-12 20:02:41'),
(2594, 8, 58, 237, 0, '', '0000-00-00', '', '2015-05-12 20:02:41'),
(2595, 8, 58, 238, 0, '', '0000-00-00', '', '2015-05-12 20:02:41'),
(2596, 8, 58, 239, 0, '', '0000-00-00', '', '2015-05-12 20:02:41'),
(2597, 8, 58, 240, 0, '', '0000-00-00', '', '2015-05-12 20:02:41'),
(2598, 8, 58, 241, 0, '', '0000-00-00', '', '2015-05-12 20:02:41'),
(2599, 8, 58, 242, 0, '', '0000-00-00', '', '2015-05-12 20:02:41'),
(2600, 8, 58, 374, 0, '', '0000-00-00', '', '2015-05-12 20:02:41'),
(2601, 8, 58, 375, 0, '', '0000-00-00', '', '2015-05-12 20:02:41'),
(2602, 8, 58, 376, 0, '', '0000-00-00', '', '2015-05-12 20:02:41'),
(2603, 8, 58, 377, 0, '', '0000-00-00', '', '2015-05-12 20:02:41'),
(2604, 8, 58, 378, 0, '', '0000-00-00', '', '2015-05-12 20:02:41'),
(2605, 8, 58, 379, 0, '', '0000-00-00', '', '2015-05-12 20:02:41'),
(2606, 8, 58, 380, 0, '', '0000-00-00', '', '2015-05-12 20:02:41'),
(2607, 8, 58, 381, 0, '', '0000-00-00', '', '2015-05-12 20:02:41'),
(2608, 8, 58, 382, 0, '', '0000-00-00', '', '2015-05-12 20:02:41'),
(2609, 8, 58, 383, 0, '', '0000-00-00', '', '2015-05-12 20:02:41'),
(2610, 8, 58, 404, 0, '', '0000-00-00', '', '2015-05-12 20:02:41'),
(2611, 8, 58, 405, 0, '', '0000-00-00', '', '2015-05-12 20:02:41'),
(2612, 8, 58, 406, 0, '', '0000-00-00', '', '2015-05-12 20:02:41'),
(2613, 8, 58, 407, 0, '', '0000-00-00', '', '2015-05-12 20:02:41'),
(2614, 8, 58, 408, 0, '', '0000-00-00', '', '2015-05-12 20:02:41'),
(2615, 8, 58, 409, 0, '', '0000-00-00', '', '2015-05-12 20:02:41'),
(2616, 8, 58, 410, 0, '', '0000-00-00', '', '2015-05-12 20:02:41'),
(2617, 8, 58, 411, 0, '', '0000-00-00', '', '2015-05-12 20:02:41'),
(2618, 8, 58, 412, 0, '', '0000-00-00', '', '2015-05-12 20:02:41'),
(2619, 8, 58, 413, 0, '', '0000-00-00', '', '2015-05-12 20:02:41'),
(2620, 9, 59, 243, 0, '', '0000-00-00', '', '2015-05-12 20:04:56'),
(2621, 9, 59, 244, 0, '', '0000-00-00', '', '2015-05-12 20:04:56'),
(2622, 9, 59, 245, 0, '', '0000-00-00', '', '2015-05-12 20:04:56'),
(2623, 9, 59, 246, 0, '', '0000-00-00', '', '2015-05-12 20:04:56'),
(2624, 9, 59, 247, 0, '', '0000-00-00', '', '2015-05-12 20:04:56'),
(2625, 9, 59, 248, 0, '', '0000-00-00', '', '2015-05-12 20:04:56'),
(2626, 9, 59, 249, 0, '', '0000-00-00', '', '2015-05-12 20:04:56'),
(2627, 9, 59, 250, 0, '', '0000-00-00', '', '2015-05-12 20:04:56'),
(2628, 9, 59, 251, 0, '', '0000-00-00', '', '2015-05-12 20:04:56'),
(2629, 9, 59, 252, 0, '', '0000-00-00', '', '2015-05-12 20:04:56'),
(2630, 9, 59, 253, 0, '', '0000-00-00', '', '2015-05-12 20:04:56'),
(2631, 9, 59, 254, 0, '', '0000-00-00', '', '2015-05-12 20:04:56'),
(2632, 9, 59, 255, 0, '', '0000-00-00', '', '2015-05-12 20:04:56'),
(2633, 9, 59, 256, 0, '', '0000-00-00', '', '2015-05-12 20:04:56'),
(2634, 9, 59, 257, 0, '', '0000-00-00', '', '2015-05-12 20:04:56'),
(2635, 9, 59, 258, 0, '', '0000-00-00', '', '2015-05-12 20:04:56'),
(2636, 9, 59, 259, 0, '', '0000-00-00', '', '2015-05-12 20:04:56'),
(2637, 9, 59, 260, 0, '', '0000-00-00', '', '2015-05-12 20:04:56'),
(2638, 9, 59, 261, 0, '', '0000-00-00', '', '2015-05-12 20:04:56'),
(2639, 9, 59, 262, 0, '', '0000-00-00', '', '2015-05-12 20:04:56'),
(2640, 9, 59, 263, 0, '', '0000-00-00', '', '2015-05-12 20:04:56'),
(2641, 9, 59, 264, 0, '', '0000-00-00', '', '2015-05-12 20:04:56'),
(2642, 9, 59, 265, 0, '', '0000-00-00', '', '2015-05-12 20:04:56'),
(2643, 9, 59, 266, 0, '', '0000-00-00', '', '2015-05-12 20:04:56'),
(2644, 9, 59, 267, 0, '', '0000-00-00', '', '2015-05-12 20:04:56'),
(2645, 9, 59, 268, 0, '', '0000-00-00', '', '2015-05-12 20:04:56'),
(2646, 9, 59, 269, 0, '', '0000-00-00', '', '2015-05-12 20:04:56'),
(2647, 9, 59, 270, 0, '', '0000-00-00', '', '2015-05-12 20:04:56'),
(2648, 9, 59, 271, 0, '', '0000-00-00', '', '2015-05-12 20:04:56'),
(2649, 9, 59, 272, 0, '', '0000-00-00', '', '2015-05-12 20:04:56'),
(2650, 9, 59, 273, 0, '', '0000-00-00', '', '2015-05-12 20:04:56'),
(2651, 9, 59, 274, 0, '', '0000-00-00', '', '2015-05-12 20:04:56'),
(2652, 9, 59, 275, 0, '', '0000-00-00', '', '2015-05-12 20:04:56'),
(2653, 9, 59, 276, 0, '', '0000-00-00', '', '2015-05-12 20:04:56'),
(2654, 9, 59, 277, 0, '', '0000-00-00', '', '2015-05-12 20:04:56'),
(2655, 9, 59, 278, 0, '', '0000-00-00', '', '2015-05-12 20:04:56'),
(2656, 9, 59, 279, 0, '', '0000-00-00', '', '2015-05-12 20:04:56'),
(2657, 9, 59, 280, 0, '', '0000-00-00', '', '2015-05-12 20:04:56'),
(2658, 9, 59, 281, 0, '', '0000-00-00', '', '2015-05-12 20:04:56'),
(2659, 9, 59, 282, 0, '', '0000-00-00', '', '2015-05-12 20:04:56'),
(2660, 9, 59, 384, 0, '', '0000-00-00', '', '2015-05-12 20:04:56'),
(2661, 9, 59, 385, 0, '', '0000-00-00', '', '2015-05-12 20:04:56'),
(2662, 9, 59, 386, 0, '', '0000-00-00', '', '2015-05-12 20:04:56'),
(2663, 9, 59, 387, 0, '', '0000-00-00', '', '2015-05-12 20:04:56'),
(2664, 9, 59, 388, 0, '', '0000-00-00', '', '2015-05-12 20:04:56'),
(2665, 9, 59, 389, 0, '', '0000-00-00', '', '2015-05-12 20:04:56'),
(2666, 9, 59, 390, 0, '', '0000-00-00', '', '2015-05-12 20:04:56'),
(2667, 9, 59, 391, 0, '', '0000-00-00', '', '2015-05-12 20:04:56'),
(2668, 9, 59, 392, 0, '', '0000-00-00', '', '2015-05-12 20:04:56'),
(2669, 9, 59, 393, 0, '', '0000-00-00', '', '2015-05-12 20:04:56'),
(2670, 9, 59, 404, 0, '', '0000-00-00', '', '2015-05-12 20:04:56'),
(2671, 9, 59, 405, 0, '', '0000-00-00', '', '2015-05-12 20:04:56'),
(2672, 9, 59, 406, 0, '', '0000-00-00', '', '2015-05-12 20:04:56'),
(2673, 9, 59, 407, 0, '', '0000-00-00', '', '2015-05-12 20:04:56'),
(2674, 9, 59, 408, 0, '', '0000-00-00', '', '2015-05-12 20:04:56'),
(2675, 9, 59, 409, 0, '', '0000-00-00', '', '2015-05-12 20:04:56'),
(2676, 9, 59, 410, 0, '', '0000-00-00', '', '2015-05-12 20:04:56'),
(2677, 9, 59, 411, 0, '', '0000-00-00', '', '2015-05-12 20:04:56'),
(2678, 9, 59, 412, 0, '', '0000-00-00', '', '2015-05-12 20:04:56'),
(2679, 9, 59, 413, 0, '', '0000-00-00', '', '2015-05-12 20:04:56'),
(2680, 10, 60, 283, 0, '', '0000-00-00', '', '2015-05-12 20:06:27'),
(2681, 10, 60, 284, 0, '', '0000-00-00', '', '2015-05-12 20:06:27'),
(2682, 10, 60, 285, 0, '', '0000-00-00', '', '2015-05-12 20:06:27'),
(2683, 10, 60, 286, 0, '', '0000-00-00', '', '2015-05-12 20:06:27'),
(2684, 10, 60, 287, 0, '', '0000-00-00', '', '2015-05-12 20:06:27'),
(2685, 10, 60, 288, 0, '', '0000-00-00', '', '2015-05-12 20:06:27'),
(2686, 10, 60, 289, 0, '', '0000-00-00', '', '2015-05-12 20:06:27'),
(2687, 10, 60, 290, 0, '', '0000-00-00', '', '2015-05-12 20:06:27'),
(2688, 10, 60, 291, 0, '', '0000-00-00', '', '2015-05-12 20:06:27'),
(2689, 10, 60, 292, 0, '', '0000-00-00', '', '2015-05-12 20:06:27'),
(2690, 10, 60, 293, 0, '', '0000-00-00', '', '2015-05-12 20:06:27'),
(2691, 10, 60, 294, 0, '', '0000-00-00', '', '2015-05-12 20:06:27'),
(2692, 10, 60, 295, 0, '', '0000-00-00', '', '2015-05-12 20:06:27'),
(2693, 10, 60, 296, 0, '', '0000-00-00', '', '2015-05-12 20:06:27'),
(2694, 10, 60, 297, 0, '', '0000-00-00', '', '2015-05-12 20:06:27'),
(2695, 10, 60, 298, 0, '', '0000-00-00', '', '2015-05-12 20:06:27'),
(2696, 10, 60, 299, 0, '', '0000-00-00', '', '2015-05-12 20:06:27'),
(2697, 10, 60, 300, 0, '', '0000-00-00', '', '2015-05-12 20:06:27'),
(2698, 10, 60, 301, 0, '', '0000-00-00', '', '2015-05-12 20:06:27'),
(2699, 10, 60, 302, 0, '', '0000-00-00', '', '2015-05-12 20:06:27'),
(2700, 10, 60, 303, 0, '', '0000-00-00', '', '2015-05-12 20:06:27'),
(2701, 10, 60, 304, 0, '', '0000-00-00', '', '2015-05-12 20:06:27'),
(2702, 10, 60, 306, 0, '', '0000-00-00', '', '2015-05-12 20:06:27'),
(2703, 10, 60, 307, 0, '', '0000-00-00', '', '2015-05-12 20:06:27'),
(2704, 10, 60, 308, 0, '', '0000-00-00', '', '2015-05-12 20:06:27'),
(2705, 10, 60, 309, 0, '', '0000-00-00', '', '2015-05-12 20:06:27'),
(2706, 10, 60, 310, 0, '', '0000-00-00', '', '2015-05-12 20:06:27'),
(2707, 10, 60, 311, 0, '', '0000-00-00', '', '2015-05-12 20:06:27'),
(2708, 10, 60, 312, 0, '', '0000-00-00', '', '2015-05-12 20:06:27'),
(2709, 10, 60, 313, 0, '', '0000-00-00', '', '2015-05-12 20:06:27'),
(2710, 10, 60, 314, 0, '', '0000-00-00', '', '2015-05-12 20:06:27'),
(2711, 10, 60, 315, 0, '', '0000-00-00', '', '2015-05-12 20:06:27'),
(2712, 10, 60, 316, 0, '', '0000-00-00', '', '2015-05-12 20:06:27'),
(2713, 10, 60, 317, 0, '', '0000-00-00', '', '2015-05-12 20:06:27'),
(2714, 10, 60, 318, 0, '', '0000-00-00', '', '2015-05-12 20:06:27'),
(2715, 10, 60, 319, 0, '', '0000-00-00', '', '2015-05-12 20:06:27'),
(2716, 10, 60, 320, 0, '', '0000-00-00', '', '2015-05-12 20:06:27'),
(2717, 10, 60, 321, 0, '', '0000-00-00', '', '2015-05-12 20:06:27'),
(2718, 10, 60, 322, 0, '', '0000-00-00', '', '2015-05-12 20:06:27'),
(2719, 10, 60, 323, 0, '', '0000-00-00', '', '2015-05-12 20:06:27'),
(2720, 10, 60, 394, 0, '', '0000-00-00', '', '2015-05-12 20:06:27'),
(2721, 10, 60, 395, 0, '', '0000-00-00', '', '2015-05-12 20:06:27'),
(2722, 10, 60, 396, 0, '', '0000-00-00', '', '2015-05-12 20:06:27'),
(2723, 10, 60, 397, 0, '', '0000-00-00', '', '2015-05-12 20:06:27'),
(2724, 10, 60, 398, 0, '', '0000-00-00', '', '2015-05-12 20:06:27'),
(2725, 10, 60, 399, 0, '', '0000-00-00', '', '2015-05-12 20:06:27'),
(2726, 10, 60, 400, 0, '', '0000-00-00', '', '2015-05-12 20:06:27'),
(2727, 10, 60, 401, 0, '', '0000-00-00', '', '2015-05-12 20:06:27'),
(2728, 10, 60, 402, 0, '', '0000-00-00', '', '2015-05-12 20:06:27'),
(2729, 10, 60, 403, 0, '', '0000-00-00', '', '2015-05-12 20:06:27'),
(2730, 10, 60, 404, 0, '', '0000-00-00', '', '2015-05-12 20:06:27'),
(2731, 10, 60, 405, 0, '', '0000-00-00', '', '2015-05-12 20:06:27'),
(2732, 10, 60, 406, 0, '', '0000-00-00', '', '2015-05-12 20:06:27'),
(2733, 10, 60, 407, 0, '', '0000-00-00', '', '2015-05-12 20:06:27'),
(2734, 10, 60, 408, 0, '', '0000-00-00', '', '2015-05-12 20:06:27'),
(2735, 10, 60, 409, 0, '', '0000-00-00', '', '2015-05-12 20:06:27'),
(2736, 10, 60, 410, 0, '', '0000-00-00', '', '2015-05-12 20:06:28'),
(2737, 10, 60, 411, 0, '', '0000-00-00', '', '2015-05-12 20:06:28'),
(2738, 10, 60, 412, 0, '', '0000-00-00', '', '2015-05-12 20:06:28'),
(2739, 10, 60, 413, 0, '', '0000-00-00', '', '2015-05-12 20:06:28'),
(2860, 7, 61, 163, 0, '', '0000-00-00', '', '2015-08-02 11:04:27'),
(2861, 7, 61, 164, 0, '', '0000-00-00', '', '2015-08-02 11:04:27'),
(2862, 7, 61, 165, 0, '', '0000-00-00', '', '2015-08-02 11:04:27'),
(2863, 7, 61, 166, 0, '', '0000-00-00', '', '2015-08-02 11:04:27'),
(2864, 7, 61, 167, 0, '', '0000-00-00', '', '2015-08-02 11:04:27'),
(2865, 7, 61, 168, 0, '', '0000-00-00', '', '2015-08-02 11:04:27'),
(2866, 7, 61, 171, 0, '', '0000-00-00', '', '2015-08-02 11:04:27'),
(2867, 7, 61, 172, 0, '', '0000-00-00', '', '2015-08-02 11:04:27'),
(2868, 7, 61, 173, 0, '', '0000-00-00', '', '2015-08-02 11:04:27'),
(2869, 7, 61, 174, 0, '', '0000-00-00', '', '2015-08-02 11:04:27'),
(2870, 7, 61, 175, 0, '', '0000-00-00', '', '2015-08-02 11:04:27'),
(2871, 7, 61, 176, 0, '', '0000-00-00', '', '2015-08-02 11:04:27'),
(2872, 7, 61, 179, 0, '', '0000-00-00', '', '2015-08-02 11:04:27'),
(2873, 7, 61, 180, 0, '', '0000-00-00', '', '2015-08-02 11:04:27'),
(2874, 7, 61, 181, 0, '', '0000-00-00', '', '2015-08-02 11:04:27'),
(2875, 7, 61, 182, 0, '', '0000-00-00', '', '2015-08-02 11:04:27'),
(2876, 7, 61, 183, 0, '', '0000-00-00', '', '2015-08-02 11:04:27'),
(2877, 7, 61, 184, 0, '', '0000-00-00', '', '2015-08-02 11:04:27'),
(2878, 7, 61, 187, 0, '', '0000-00-00', '', '2015-08-02 11:04:27'),
(2879, 7, 61, 188, 0, '', '0000-00-00', '', '2015-08-02 11:04:27'),
(2880, 7, 61, 189, 0, '', '0000-00-00', '', '2015-08-02 11:04:27'),
(2881, 7, 61, 190, 0, '', '0000-00-00', '', '2015-08-02 11:04:27'),
(2882, 7, 61, 191, 0, '', '0000-00-00', '', '2015-08-02 11:04:27'),
(2883, 7, 61, 192, 0, '', '0000-00-00', '', '2015-08-02 11:04:27'),
(2884, 7, 61, 195, 0, '', '0000-00-00', '', '2015-08-02 11:04:27'),
(2885, 7, 61, 196, 0, '', '0000-00-00', '', '2015-08-02 11:04:27'),
(2886, 7, 61, 197, 0, '', '0000-00-00', '', '2015-08-02 11:04:27'),
(2887, 7, 61, 198, 0, '', '0000-00-00', '', '2015-08-02 11:04:27'),
(2888, 7, 61, 199, 0, '', '0000-00-00', '', '2015-08-02 11:04:27'),
(2889, 7, 61, 202, 0, '', '0000-00-00', '', '2015-08-02 11:04:27'),
(2890, 8, 62, 203, 0, '', '0000-00-00', '', '2015-08-02 11:05:52'),
(2891, 8, 62, 204, 0, '', '0000-00-00', '', '2015-08-02 11:05:52'),
(2892, 8, 62, 205, 0, '', '0000-00-00', '', '2015-08-02 11:05:52'),
(2893, 8, 62, 206, 0, '', '0000-00-00', '', '2015-08-02 11:05:52'),
(2894, 8, 62, 207, 0, '', '0000-00-00', '', '2015-08-02 11:05:52'),
(2895, 8, 62, 208, 0, '', '0000-00-00', '', '2015-08-02 11:05:52'),
(2896, 8, 62, 211, 0, '', '0000-00-00', '', '2015-08-02 11:05:52'),
(2897, 8, 62, 212, 0, '', '0000-00-00', '', '2015-08-02 11:05:52'),
(2898, 8, 62, 213, 0, '', '0000-00-00', '', '2015-08-02 11:05:52'),
(2899, 8, 62, 214, 0, '', '0000-00-00', '', '2015-08-02 11:05:52'),
(2900, 8, 62, 215, 0, '', '0000-00-00', '', '2015-08-02 11:05:52'),
(2901, 8, 62, 216, 0, '', '0000-00-00', '', '2015-08-02 11:05:52'),
(2902, 8, 62, 219, 0, '', '0000-00-00', '', '2015-08-02 11:05:52'),
(2903, 8, 62, 220, 0, '', '0000-00-00', '', '2015-08-02 11:05:52'),
(2904, 8, 62, 221, 0, '', '0000-00-00', '', '2015-08-02 11:05:52'),
(2905, 8, 62, 222, 0, '', '0000-00-00', '', '2015-08-02 11:05:52'),
(2906, 8, 62, 223, 0, '', '0000-00-00', '', '2015-08-02 11:05:52'),
(2907, 8, 62, 224, 0, '', '0000-00-00', '', '2015-08-02 11:05:52'),
(2908, 8, 62, 227, 0, '', '0000-00-00', '', '2015-08-02 11:05:52'),
(2909, 8, 62, 228, 0, '', '0000-00-00', '', '2015-08-02 11:05:52'),
(2910, 8, 62, 229, 0, '', '0000-00-00', '', '2015-08-02 11:05:52'),
(2911, 8, 62, 230, 0, '', '0000-00-00', '', '2015-08-02 11:05:52'),
(2912, 8, 62, 231, 0, '', '0000-00-00', '', '2015-08-02 11:05:52'),
(2913, 8, 62, 232, 0, '', '0000-00-00', '', '2015-08-02 11:05:52'),
(2914, 8, 62, 235, 0, '', '0000-00-00', '', '2015-08-02 11:05:52'),
(2915, 8, 62, 236, 0, '', '0000-00-00', '', '2015-08-02 11:05:52'),
(2916, 8, 62, 237, 0, '', '0000-00-00', '', '2015-08-02 11:05:52'),
(2917, 8, 62, 238, 0, '', '0000-00-00', '', '2015-08-02 11:05:52'),
(2918, 8, 62, 239, 0, '', '0000-00-00', '', '2015-08-02 11:05:52'),
(2919, 8, 62, 240, 0, '', '0000-00-00', '', '2015-08-02 11:05:52'),
(2920, 9, 63, 243, 0, '', '0000-00-00', '', '2015-08-02 11:08:54'),
(2921, 9, 63, 244, 0, '', '0000-00-00', '', '2015-08-02 11:08:54'),
(2922, 9, 63, 245, 0, '', '0000-00-00', '', '2015-08-02 11:08:54'),
(2923, 9, 63, 246, 0, '', '0000-00-00', '', '2015-08-02 11:08:54'),
(2924, 9, 63, 247, 0, '', '0000-00-00', '', '2015-08-02 11:08:54'),
(2925, 9, 63, 248, 0, '', '0000-00-00', '', '2015-08-02 11:08:54'),
(2926, 9, 63, 251, 0, '', '0000-00-00', '', '2015-08-02 11:08:54'),
(2927, 9, 63, 252, 0, '', '0000-00-00', '', '2015-08-02 11:08:54'),
(2928, 9, 63, 253, 0, '', '0000-00-00', '', '2015-08-02 11:08:54'),
(2929, 9, 63, 254, 0, '', '0000-00-00', '', '2015-08-02 11:08:54'),
(2930, 9, 63, 255, 0, '', '0000-00-00', '', '2015-08-02 11:08:54'),
(2931, 9, 63, 256, 0, '', '0000-00-00', '', '2015-08-02 11:08:54'),
(2932, 9, 63, 259, 0, '', '0000-00-00', '', '2015-08-02 11:08:54'),
(2933, 9, 63, 260, 0, '', '0000-00-00', '', '2015-08-02 11:08:54'),
(2934, 9, 63, 261, 0, '', '0000-00-00', '', '2015-08-02 11:08:54'),
(2935, 9, 63, 262, 0, '', '0000-00-00', '', '2015-08-02 11:08:54'),
(2936, 9, 63, 263, 0, '', '0000-00-00', '', '2015-08-02 11:08:54'),
(2937, 9, 63, 264, 0, '', '0000-00-00', '', '2015-08-02 11:08:54'),
(2938, 9, 63, 267, 0, '', '0000-00-00', '', '2015-08-02 11:08:54'),
(2939, 9, 63, 268, 0, '', '0000-00-00', '', '2015-08-02 11:08:54'),
(2940, 9, 63, 269, 0, '', '0000-00-00', '', '2015-08-02 11:08:54'),
(2941, 9, 63, 270, 0, '', '0000-00-00', '', '2015-08-02 11:08:54'),
(2942, 9, 63, 271, 0, '', '0000-00-00', '', '2015-08-02 11:08:54'),
(2943, 9, 63, 272, 0, '', '0000-00-00', '', '2015-08-02 11:08:54'),
(2944, 9, 63, 275, 0, '', '0000-00-00', '', '2015-08-02 11:08:54'),
(2945, 9, 63, 276, 0, '', '0000-00-00', '', '2015-08-02 11:08:54'),
(2946, 9, 63, 277, 0, '', '0000-00-00', '', '2015-08-02 11:08:54'),
(2947, 9, 63, 278, 0, '', '0000-00-00', '', '2015-08-02 11:08:54'),
(2948, 9, 63, 279, 0, '', '0000-00-00', '', '2015-08-02 11:08:54'),
(2949, 9, 63, 280, 0, '', '0000-00-00', '', '2015-08-02 11:08:54'),
(2950, 10, 64, 283, 0, '', '0000-00-00', '', '2015-08-02 11:10:43'),
(2951, 10, 64, 284, 0, '', '0000-00-00', '', '2015-08-02 11:10:43'),
(2952, 10, 64, 285, 0, '', '0000-00-00', '', '2015-08-02 11:10:43'),
(2953, 10, 64, 286, 0, '', '0000-00-00', '', '2015-08-02 11:10:43'),
(2954, 10, 64, 287, 0, '', '0000-00-00', '', '2015-08-02 11:10:43'),
(2955, 10, 64, 288, 0, '', '0000-00-00', '', '2015-08-02 11:10:43'),
(2956, 10, 64, 291, 0, '', '0000-00-00', '', '2015-08-02 11:10:43'),
(2957, 10, 64, 292, 0, '', '0000-00-00', '', '2015-08-02 11:10:43'),
(2958, 10, 64, 293, 0, '', '0000-00-00', '', '2015-08-02 11:10:43'),
(2959, 10, 64, 294, 0, '', '0000-00-00', '', '2015-08-02 11:10:43'),
(2960, 10, 64, 295, 0, '', '0000-00-00', '', '2015-08-02 11:10:43'),
(2961, 10, 64, 296, 0, '', '0000-00-00', '', '2015-08-02 11:10:43'),
(2962, 10, 64, 299, 0, '', '0000-00-00', '', '2015-08-02 11:10:43'),
(2963, 10, 64, 300, 0, '', '0000-00-00', '', '2015-08-02 11:10:43'),
(2964, 10, 64, 301, 0, '', '0000-00-00', '', '2015-08-02 11:10:43'),
(2965, 10, 64, 302, 0, '', '0000-00-00', '', '2015-08-02 11:10:43'),
(2966, 10, 64, 303, 0, '', '0000-00-00', '', '2015-08-02 11:10:43'),
(2967, 10, 64, 304, 0, '', '0000-00-00', '', '2015-08-02 11:10:43'),
(2968, 10, 64, 308, 0, '', '0000-00-00', '', '2015-08-02 11:10:43'),
(2969, 10, 64, 309, 0, '', '0000-00-00', '', '2015-08-02 11:10:43'),
(2970, 10, 64, 310, 0, '', '0000-00-00', '', '2015-08-02 11:10:43'),
(2971, 10, 64, 311, 0, '', '0000-00-00', '', '2015-08-02 11:10:43'),
(2972, 10, 64, 312, 0, '', '0000-00-00', '', '2015-08-02 11:10:43'),
(2973, 10, 64, 313, 0, '', '0000-00-00', '', '2015-08-02 11:10:43'),
(2974, 10, 64, 316, 0, '', '0000-00-00', '', '2015-08-02 11:10:43'),
(2975, 10, 64, 317, 0, '', '0000-00-00', '', '2015-08-02 11:10:43'),
(2976, 10, 64, 318, 0, '', '0000-00-00', '', '2015-08-02 11:10:43'),
(2977, 10, 64, 319, 0, '', '0000-00-00', '', '2015-08-02 11:10:43'),
(2978, 10, 64, 320, 0, '', '0000-00-00', '', '2015-08-02 11:10:43'),
(2979, 10, 64, 321, 0, '', '0000-00-00', '', '2015-08-02 11:10:43'),
(2980, 7, 61, 364, 0, '', '0000-00-00', '', '2015-08-02 11:13:37'),
(2981, 7, 61, 365, 0, '', '0000-00-00', '', '2015-08-02 11:13:37'),
(2982, 7, 61, 366, 0, '', '0000-00-00', '', '2015-08-02 11:13:37'),
(2983, 7, 61, 367, 0, '', '0000-00-00', '', '2015-08-02 11:13:37'),
(2984, 7, 61, 368, 0, '', '0000-00-00', '', '2015-08-02 11:13:37'),
(2985, 7, 61, 369, 0, '', '0000-00-00', '', '2015-08-02 11:13:37'),
(2986, 7, 61, 370, 0, '', '0000-00-00', '', '2015-08-02 11:13:37'),
(2987, 7, 61, 371, 0, '', '0000-00-00', '', '2015-08-02 11:13:37'),
(2988, 7, 61, 372, 0, '', '0000-00-00', '', '2015-08-02 11:13:37'),
(2989, 7, 61, 373, 0, '', '0000-00-00', '', '2015-08-02 11:13:37');
INSERT INTO `class_plan_game` (`id`, `class_id`, `plan_id`, `game_id`, `status`, `createdby`, `creation_date`, `modifiedby`, `modified_date`) VALUES
(2990, 7, 61, 404, 0, '', '0000-00-00', '', '2015-08-02 11:13:37'),
(2991, 7, 61, 405, 0, '', '0000-00-00', '', '2015-08-02 11:13:37'),
(2992, 7, 61, 406, 0, '', '0000-00-00', '', '2015-08-02 11:13:37'),
(2993, 7, 61, 407, 0, '', '0000-00-00', '', '2015-08-02 11:13:37'),
(2994, 7, 61, 408, 0, '', '0000-00-00', '', '2015-08-02 11:13:37'),
(2995, 7, 61, 409, 0, '', '0000-00-00', '', '2015-08-02 11:13:37'),
(2996, 7, 61, 410, 0, '', '0000-00-00', '', '2015-08-02 11:13:37'),
(2997, 7, 61, 411, 0, '', '0000-00-00', '', '2015-08-02 11:13:37'),
(2998, 7, 61, 412, 0, '', '0000-00-00', '', '2015-08-02 11:13:37'),
(2999, 7, 61, 413, 0, '', '0000-00-00', '', '2015-08-02 11:13:37'),
(3000, 8, 62, 374, 0, '', '0000-00-00', '', '2015-08-02 11:14:31'),
(3001, 8, 62, 375, 0, '', '0000-00-00', '', '2015-08-02 11:14:31'),
(3002, 8, 62, 376, 0, '', '0000-00-00', '', '2015-08-02 11:14:31'),
(3003, 8, 62, 377, 0, '', '0000-00-00', '', '2015-08-02 11:14:31'),
(3004, 8, 62, 378, 0, '', '0000-00-00', '', '2015-08-02 11:14:31'),
(3005, 8, 62, 379, 0, '', '0000-00-00', '', '2015-08-02 11:14:31'),
(3006, 8, 62, 380, 0, '', '0000-00-00', '', '2015-08-02 11:14:31'),
(3007, 8, 62, 381, 0, '', '0000-00-00', '', '2015-08-02 11:14:31'),
(3008, 8, 62, 382, 0, '', '0000-00-00', '', '2015-08-02 11:14:31'),
(3009, 8, 62, 383, 0, '', '0000-00-00', '', '2015-08-02 11:14:31'),
(3010, 8, 62, 404, 0, '', '0000-00-00', '', '2015-08-02 11:14:31'),
(3011, 8, 62, 405, 0, '', '0000-00-00', '', '2015-08-02 11:14:31'),
(3012, 8, 62, 406, 0, '', '0000-00-00', '', '2015-08-02 11:14:31'),
(3013, 8, 62, 407, 0, '', '0000-00-00', '', '2015-08-02 11:14:31'),
(3014, 8, 62, 408, 0, '', '0000-00-00', '', '2015-08-02 11:14:31'),
(3015, 8, 62, 409, 0, '', '0000-00-00', '', '2015-08-02 11:14:31'),
(3016, 8, 62, 410, 0, '', '0000-00-00', '', '2015-08-02 11:14:31'),
(3017, 8, 62, 411, 0, '', '0000-00-00', '', '2015-08-02 11:14:31'),
(3018, 8, 62, 412, 0, '', '0000-00-00', '', '2015-08-02 11:14:31'),
(3019, 8, 62, 413, 0, '', '0000-00-00', '', '2015-08-02 11:14:31'),
(3020, 9, 63, 384, 0, '', '0000-00-00', '', '2015-08-02 11:15:20'),
(3021, 9, 63, 385, 0, '', '0000-00-00', '', '2015-08-02 11:15:20'),
(3022, 9, 63, 386, 0, '', '0000-00-00', '', '2015-08-02 11:15:20'),
(3023, 9, 63, 387, 0, '', '0000-00-00', '', '2015-08-02 11:15:20'),
(3024, 9, 63, 388, 0, '', '0000-00-00', '', '2015-08-02 11:15:20'),
(3025, 9, 63, 389, 0, '', '0000-00-00', '', '2015-08-02 11:15:20'),
(3026, 9, 63, 390, 0, '', '0000-00-00', '', '2015-08-02 11:15:20'),
(3027, 9, 63, 391, 0, '', '0000-00-00', '', '2015-08-02 11:15:20'),
(3028, 9, 63, 392, 0, '', '0000-00-00', '', '2015-08-02 11:15:20'),
(3029, 9, 63, 393, 0, '', '0000-00-00', '', '2015-08-02 11:15:20'),
(3030, 9, 63, 404, 0, '', '0000-00-00', '', '2015-08-02 11:15:20'),
(3031, 9, 63, 405, 0, '', '0000-00-00', '', '2015-08-02 11:15:20'),
(3032, 9, 63, 406, 0, '', '0000-00-00', '', '2015-08-02 11:15:20'),
(3033, 9, 63, 407, 0, '', '0000-00-00', '', '2015-08-02 11:15:20'),
(3034, 9, 63, 408, 0, '', '0000-00-00', '', '2015-08-02 11:15:20'),
(3035, 9, 63, 409, 0, '', '0000-00-00', '', '2015-08-02 11:15:20'),
(3036, 9, 63, 410, 0, '', '0000-00-00', '', '2015-08-02 11:15:20'),
(3037, 9, 63, 411, 0, '', '0000-00-00', '', '2015-08-02 11:15:20'),
(3038, 9, 63, 412, 0, '', '0000-00-00', '', '2015-08-02 11:15:20'),
(3039, 9, 63, 413, 0, '', '0000-00-00', '', '2015-08-02 11:15:20'),
(3040, 10, 64, 394, 0, '', '0000-00-00', '', '2015-08-02 11:16:05'),
(3041, 10, 64, 395, 0, '', '0000-00-00', '', '2015-08-02 11:16:05'),
(3042, 10, 64, 396, 0, '', '0000-00-00', '', '2015-08-02 11:16:05'),
(3043, 10, 64, 397, 0, '', '0000-00-00', '', '2015-08-02 11:16:05'),
(3044, 10, 64, 398, 0, '', '0000-00-00', '', '2015-08-02 11:16:05'),
(3045, 10, 64, 399, 0, '', '0000-00-00', '', '2015-08-02 11:16:05'),
(3046, 10, 64, 400, 0, '', '0000-00-00', '', '2015-08-02 11:16:05'),
(3047, 10, 64, 401, 0, '', '0000-00-00', '', '2015-08-02 11:16:05'),
(3048, 10, 64, 402, 0, '', '0000-00-00', '', '2015-08-02 11:16:05'),
(3049, 10, 64, 403, 0, '', '0000-00-00', '', '2015-08-02 11:16:05'),
(3050, 10, 64, 404, 0, '', '0000-00-00', '', '2015-08-02 11:16:05'),
(3051, 10, 64, 405, 0, '', '0000-00-00', '', '2015-08-02 11:16:05'),
(3052, 10, 64, 406, 0, '', '0000-00-00', '', '2015-08-02 11:16:05'),
(3053, 10, 64, 407, 0, '', '0000-00-00', '', '2015-08-02 11:16:05'),
(3054, 10, 64, 408, 0, '', '0000-00-00', '', '2015-08-02 11:16:05'),
(3055, 10, 64, 409, 0, '', '0000-00-00', '', '2015-08-02 11:16:05'),
(3056, 10, 64, 410, 0, '', '0000-00-00', '', '2015-08-02 11:16:05'),
(3057, 10, 64, 411, 0, '', '0000-00-00', '', '2015-08-02 11:16:05'),
(3058, 10, 64, 412, 0, '', '0000-00-00', '', '2015-08-02 11:16:05'),
(3059, 10, 64, 413, 0, '', '0000-00-00', '', '2015-08-02 11:16:05'),
(3060, 6, 65, 123, 0, '', '0000-00-00', '', '0000-00-00 00:00:00'),
(3061, 6, 65, 124, 0, '', '0000-00-00', '', '0000-00-00 00:00:00'),
(3062, 6, 65, 125, 0, '', '0000-00-00', '', '0000-00-00 00:00:00'),
(3063, 6, 65, 126, 0, '', '0000-00-00', '', '0000-00-00 00:00:00'),
(3064, 6, 65, 127, 0, '', '0000-00-00', '', '0000-00-00 00:00:00'),
(3065, 6, 65, 128, 0, '', '0000-00-00', '', '0000-00-00 00:00:00'),
(3066, 6, 65, 131, 0, '', '0000-00-00', '', '0000-00-00 00:00:00'),
(3067, 6, 65, 132, 0, '', '0000-00-00', '', '0000-00-00 00:00:00'),
(3068, 6, 65, 133, 0, '', '0000-00-00', '', '0000-00-00 00:00:00'),
(3069, 6, 65, 134, 0, '', '0000-00-00', '', '0000-00-00 00:00:00'),
(3070, 6, 65, 135, 0, '', '0000-00-00', '', '0000-00-00 00:00:00'),
(3071, 6, 65, 136, 0, '', '0000-00-00', '', '0000-00-00 00:00:00'),
(3072, 6, 65, 139, 0, '', '0000-00-00', '', '0000-00-00 00:00:00'),
(3073, 6, 65, 140, 0, '', '0000-00-00', '', '0000-00-00 00:00:00'),
(3074, 6, 65, 141, 0, '', '0000-00-00', '', '0000-00-00 00:00:00'),
(3075, 6, 65, 142, 0, '', '0000-00-00', '', '0000-00-00 00:00:00'),
(3076, 6, 65, 143, 0, '', '0000-00-00', '', '0000-00-00 00:00:00'),
(3077, 6, 65, 144, 0, '', '0000-00-00', '', '0000-00-00 00:00:00'),
(3078, 6, 65, 147, 0, '', '0000-00-00', '', '0000-00-00 00:00:00'),
(3079, 6, 65, 148, 0, '', '0000-00-00', '', '0000-00-00 00:00:00'),
(3080, 6, 65, 149, 0, '', '0000-00-00', '', '0000-00-00 00:00:00'),
(3081, 6, 65, 150, 0, '', '0000-00-00', '', '0000-00-00 00:00:00'),
(3082, 6, 65, 151, 0, '', '0000-00-00', '', '0000-00-00 00:00:00'),
(3083, 6, 65, 152, 0, '', '0000-00-00', '', '0000-00-00 00:00:00'),
(3084, 6, 65, 155, 0, '', '0000-00-00', '', '0000-00-00 00:00:00'),
(3085, 6, 65, 156, 0, '', '0000-00-00', '', '0000-00-00 00:00:00'),
(3086, 6, 65, 157, 0, '', '0000-00-00', '', '0000-00-00 00:00:00'),
(3087, 6, 65, 158, 0, '', '0000-00-00', '', '0000-00-00 00:00:00'),
(3088, 6, 65, 159, 0, '', '0000-00-00', '', '0000-00-00 00:00:00'),
(3089, 6, 65, 160, 0, '', '0000-00-00', '', '0000-00-00 00:00:00'),
(3090, 7, 66, 163, 0, '', '0000-00-00', '', '0000-00-00 00:00:00'),
(3091, 7, 66, 164, 0, '', '0000-00-00', '', '0000-00-00 00:00:00'),
(3092, 7, 66, 165, 0, '', '0000-00-00', '', '0000-00-00 00:00:00'),
(3093, 7, 66, 166, 0, '', '0000-00-00', '', '0000-00-00 00:00:00'),
(3094, 7, 66, 167, 0, '', '0000-00-00', '', '0000-00-00 00:00:00'),
(3095, 7, 66, 168, 0, '', '0000-00-00', '', '0000-00-00 00:00:00'),
(3096, 7, 66, 171, 0, '', '0000-00-00', '', '0000-00-00 00:00:00'),
(3097, 7, 66, 172, 0, '', '0000-00-00', '', '0000-00-00 00:00:00'),
(3098, 7, 66, 173, 0, '', '0000-00-00', '', '0000-00-00 00:00:00'),
(3099, 7, 66, 174, 0, '', '0000-00-00', '', '0000-00-00 00:00:00'),
(3100, 7, 66, 175, 0, '', '0000-00-00', '', '0000-00-00 00:00:00'),
(3101, 7, 66, 176, 0, '', '0000-00-00', '', '0000-00-00 00:00:00'),
(3102, 7, 66, 187, 0, '', '0000-00-00', '', '0000-00-00 00:00:00'),
(3103, 7, 66, 188, 0, '', '0000-00-00', '', '0000-00-00 00:00:00'),
(3104, 7, 66, 189, 0, '', '0000-00-00', '', '0000-00-00 00:00:00'),
(3105, 7, 66, 190, 0, '', '0000-00-00', '', '0000-00-00 00:00:00'),
(3106, 7, 66, 191, 0, '', '0000-00-00', '', '0000-00-00 00:00:00'),
(3107, 7, 66, 192, 0, '', '0000-00-00', '', '0000-00-00 00:00:00'),
(3108, 7, 66, 195, 0, '', '0000-00-00', '', '0000-00-00 00:00:00'),
(3109, 7, 66, 196, 0, '', '0000-00-00', '', '0000-00-00 00:00:00'),
(3110, 7, 66, 197, 0, '', '0000-00-00', '', '0000-00-00 00:00:00'),
(3111, 7, 66, 198, 0, '', '0000-00-00', '', '0000-00-00 00:00:00'),
(3112, 7, 66, 199, 0, '', '0000-00-00', '', '0000-00-00 00:00:00'),
(3113, 7, 66, 200, 0, '', '0000-00-00', '', '0000-00-00 00:00:00'),
(3114, 8, 67, 203, 0, '', '0000-00-00', '', '0000-00-00 00:00:00'),
(3115, 8, 67, 204, 0, '', '0000-00-00', '', '0000-00-00 00:00:00'),
(3116, 8, 67, 205, 0, '', '0000-00-00', '', '0000-00-00 00:00:00'),
(3117, 8, 67, 206, 0, '', '0000-00-00', '', '0000-00-00 00:00:00'),
(3118, 8, 67, 207, 0, '', '0000-00-00', '', '0000-00-00 00:00:00'),
(3119, 8, 67, 208, 0, '', '0000-00-00', '', '0000-00-00 00:00:00'),
(3120, 8, 67, 211, 0, '', '0000-00-00', '', '0000-00-00 00:00:00'),
(3121, 8, 67, 212, 0, '', '0000-00-00', '', '0000-00-00 00:00:00'),
(3122, 8, 67, 213, 0, '', '0000-00-00', '', '0000-00-00 00:00:00'),
(3123, 8, 67, 214, 0, '', '0000-00-00', '', '0000-00-00 00:00:00'),
(3124, 8, 67, 215, 0, '', '0000-00-00', '', '0000-00-00 00:00:00'),
(3125, 8, 67, 216, 0, '', '0000-00-00', '', '0000-00-00 00:00:00'),
(3126, 8, 67, 219, 0, '', '0000-00-00', '', '0000-00-00 00:00:00'),
(3127, 8, 67, 220, 0, '', '0000-00-00', '', '0000-00-00 00:00:00'),
(3128, 8, 67, 221, 0, '', '0000-00-00', '', '0000-00-00 00:00:00'),
(3129, 8, 67, 222, 0, '', '0000-00-00', '', '0000-00-00 00:00:00'),
(3130, 8, 67, 223, 0, '', '0000-00-00', '', '0000-00-00 00:00:00'),
(3131, 8, 67, 224, 0, '', '0000-00-00', '', '0000-00-00 00:00:00'),
(3132, 8, 67, 227, 0, '', '0000-00-00', '', '0000-00-00 00:00:00'),
(3133, 8, 67, 228, 0, '', '0000-00-00', '', '0000-00-00 00:00:00'),
(3134, 8, 67, 229, 0, '', '0000-00-00', '', '0000-00-00 00:00:00'),
(3135, 8, 67, 230, 0, '', '0000-00-00', '', '0000-00-00 00:00:00'),
(3136, 8, 67, 231, 0, '', '0000-00-00', '', '0000-00-00 00:00:00'),
(3137, 8, 67, 232, 0, '', '0000-00-00', '', '0000-00-00 00:00:00'),
(3138, 8, 67, 235, 0, '', '0000-00-00', '', '0000-00-00 00:00:00'),
(3139, 8, 67, 236, 0, '', '0000-00-00', '', '0000-00-00 00:00:00'),
(3140, 8, 67, 237, 0, '', '0000-00-00', '', '0000-00-00 00:00:00'),
(3141, 8, 67, 238, 0, '', '0000-00-00', '', '0000-00-00 00:00:00'),
(3142, 8, 67, 239, 0, '', '0000-00-00', '', '0000-00-00 00:00:00'),
(3143, 8, 67, 240, 0, '', '0000-00-00', '', '0000-00-00 00:00:00'),
(3144, 9, 68, 243, 0, '', '0000-00-00', '', '0000-00-00 00:00:00'),
(3145, 9, 68, 244, 0, '', '0000-00-00', '', '0000-00-00 00:00:00'),
(3146, 9, 68, 245, 0, '', '0000-00-00', '', '0000-00-00 00:00:00'),
(3147, 9, 68, 246, 0, '', '0000-00-00', '', '0000-00-00 00:00:00'),
(3148, 9, 68, 247, 0, '', '0000-00-00', '', '0000-00-00 00:00:00'),
(3149, 9, 68, 248, 0, '', '0000-00-00', '', '0000-00-00 00:00:00'),
(3150, 9, 68, 251, 0, '', '0000-00-00', '', '0000-00-00 00:00:00'),
(3151, 9, 68, 252, 0, '', '0000-00-00', '', '0000-00-00 00:00:00'),
(3152, 9, 68, 253, 0, '', '0000-00-00', '', '0000-00-00 00:00:00'),
(3153, 9, 68, 254, 0, '', '0000-00-00', '', '0000-00-00 00:00:00'),
(3154, 9, 68, 255, 0, '', '0000-00-00', '', '0000-00-00 00:00:00'),
(3155, 9, 68, 256, 0, '', '0000-00-00', '', '0000-00-00 00:00:00'),
(3156, 9, 68, 259, 0, '', '0000-00-00', '', '0000-00-00 00:00:00'),
(3157, 9, 68, 260, 0, '', '0000-00-00', '', '0000-00-00 00:00:00'),
(3158, 9, 68, 261, 0, '', '0000-00-00', '', '0000-00-00 00:00:00'),
(3159, 9, 68, 262, 0, '', '0000-00-00', '', '0000-00-00 00:00:00'),
(3160, 9, 68, 263, 0, '', '0000-00-00', '', '0000-00-00 00:00:00'),
(3161, 9, 68, 264, 0, '', '0000-00-00', '', '0000-00-00 00:00:00'),
(3162, 9, 68, 267, 0, '', '0000-00-00', '', '0000-00-00 00:00:00'),
(3163, 9, 68, 268, 0, '', '0000-00-00', '', '0000-00-00 00:00:00'),
(3164, 9, 68, 269, 0, '', '0000-00-00', '', '0000-00-00 00:00:00'),
(3165, 9, 68, 270, 0, '', '0000-00-00', '', '0000-00-00 00:00:00'),
(3166, 9, 68, 271, 0, '', '0000-00-00', '', '0000-00-00 00:00:00'),
(3167, 9, 68, 272, 0, '', '0000-00-00', '', '0000-00-00 00:00:00'),
(3168, 9, 68, 275, 0, '', '0000-00-00', '', '0000-00-00 00:00:00'),
(3169, 9, 68, 276, 0, '', '0000-00-00', '', '0000-00-00 00:00:00'),
(3170, 9, 68, 277, 0, '', '0000-00-00', '', '0000-00-00 00:00:00'),
(3171, 9, 68, 278, 0, '', '0000-00-00', '', '0000-00-00 00:00:00'),
(3172, 9, 68, 279, 0, '', '0000-00-00', '', '0000-00-00 00:00:00'),
(3173, 9, 68, 280, 0, '', '0000-00-00', '', '0000-00-00 00:00:00'),
(3174, 10, 69, 283, 0, '', '0000-00-00', '', '0000-00-00 00:00:00'),
(3175, 10, 69, 284, 0, '', '0000-00-00', '', '0000-00-00 00:00:00'),
(3176, 10, 69, 285, 0, '', '0000-00-00', '', '0000-00-00 00:00:00'),
(3177, 10, 69, 286, 0, '', '0000-00-00', '', '0000-00-00 00:00:00'),
(3178, 10, 69, 287, 0, '', '0000-00-00', '', '0000-00-00 00:00:00'),
(3179, 10, 69, 288, 0, '', '0000-00-00', '', '0000-00-00 00:00:00'),
(3180, 10, 69, 291, 0, '', '0000-00-00', '', '0000-00-00 00:00:00'),
(3181, 10, 69, 292, 0, '', '0000-00-00', '', '0000-00-00 00:00:00'),
(3182, 10, 69, 293, 0, '', '0000-00-00', '', '0000-00-00 00:00:00'),
(3183, 10, 69, 294, 0, '', '0000-00-00', '', '0000-00-00 00:00:00'),
(3184, 10, 69, 295, 0, '', '0000-00-00', '', '0000-00-00 00:00:00'),
(3185, 10, 69, 296, 0, '', '0000-00-00', '', '0000-00-00 00:00:00'),
(3186, 10, 69, 299, 0, '', '0000-00-00', '', '0000-00-00 00:00:00'),
(3187, 10, 69, 300, 0, '', '0000-00-00', '', '0000-00-00 00:00:00'),
(3188, 10, 69, 301, 0, '', '0000-00-00', '', '0000-00-00 00:00:00'),
(3189, 10, 69, 302, 0, '', '0000-00-00', '', '0000-00-00 00:00:00'),
(3190, 10, 69, 303, 0, '', '0000-00-00', '', '0000-00-00 00:00:00'),
(3191, 10, 69, 304, 0, '', '0000-00-00', '', '0000-00-00 00:00:00'),
(3192, 10, 69, 308, 0, '', '0000-00-00', '', '0000-00-00 00:00:00'),
(3193, 10, 69, 309, 0, '', '0000-00-00', '', '0000-00-00 00:00:00'),
(3194, 10, 69, 310, 0, '', '0000-00-00', '', '0000-00-00 00:00:00'),
(3195, 10, 69, 311, 0, '', '0000-00-00', '', '0000-00-00 00:00:00'),
(3196, 10, 69, 312, 0, '', '0000-00-00', '', '0000-00-00 00:00:00'),
(3197, 10, 69, 313, 0, '', '0000-00-00', '', '0000-00-00 00:00:00'),
(3198, 10, 69, 316, 0, '', '0000-00-00', '', '0000-00-00 00:00:00'),
(3199, 10, 69, 317, 0, '', '0000-00-00', '', '0000-00-00 00:00:00'),
(3200, 10, 69, 318, 0, '', '0000-00-00', '', '0000-00-00 00:00:00'),
(3201, 10, 69, 319, 0, '', '0000-00-00', '', '0000-00-00 00:00:00'),
(3202, 10, 69, 320, 0, '', '0000-00-00', '', '0000-00-00 00:00:00'),
(3203, 10, 69, 321, 0, '', '0000-00-00', '', '0000-00-00 00:00:00'),
(3204, 7, 66, 180, 0, '', '0000-00-00', '', '0000-00-00 00:00:00'),
(3205, 7, 66, 181, 0, '', '0000-00-00', '', '0000-00-00 00:00:00'),
(3206, 7, 66, 182, 0, '', '0000-00-00', '', '0000-00-00 00:00:00'),
(3207, 7, 66, 183, 0, '', '0000-00-00', '', '0000-00-00 00:00:00'),
(3208, 7, 66, 184, 0, '', '0000-00-00', '', '0000-00-00 00:00:00'),
(3209, 7, 66, 185, 0, '', '0000-00-00', '', '0000-00-00 00:00:00'),
(3233, 3, 83, 8, 0, '', '0000-00-00', '', '2016-07-19 19:35:57'),
(3234, 3, 83, 9, 0, '', '0000-00-00', '', '2016-07-19 19:35:58'),
(3235, 3, 83, 25, 0, '', '0000-00-00', '', '2016-07-19 19:35:58'),
(3236, 3, 83, 31, 0, '', '0000-00-00', '', '2016-07-19 19:35:58'),
(3237, 3, 83, 35, 0, '', '0000-00-00', '', '2016-07-19 19:35:58'),
(3238, 4, 84, 49, 0, '', '0000-00-00', '', '2016-07-19 19:36:57'),
(3239, 4, 84, 55, 0, '', '0000-00-00', '', '2016-07-19 19:36:57'),
(3240, 4, 84, 64, 0, '', '0000-00-00', '', '2016-07-19 19:36:57'),
(3241, 4, 84, 69, 0, '', '0000-00-00', '', '2016-07-19 19:36:57'),
(3242, 4, 84, 79, 0, '', '0000-00-00', '', '2016-07-19 19:36:57'),
(3243, 5, 85, 83, 0, '', '0000-00-00', '', '2016-07-19 19:38:05'),
(3244, 5, 85, 94, 0, '', '0000-00-00', '', '2016-07-19 19:38:05'),
(3245, 5, 85, 103, 0, '', '0000-00-00', '', '2016-07-19 19:38:05'),
(3246, 5, 85, 108, 0, '', '0000-00-00', '', '2016-07-19 19:38:05'),
(3247, 5, 85, 121, 0, '', '0000-00-00', '', '2016-07-19 19:38:05'),
(3248, 6, 86, 130, 0, '', '0000-00-00', '', '2016-07-19 19:39:10'),
(3249, 6, 86, 133, 0, '', '0000-00-00', '', '2016-07-19 19:39:10'),
(3250, 6, 86, 146, 0, '', '0000-00-00', '', '2016-07-19 19:39:10'),
(3251, 6, 86, 148, 0, '', '0000-00-00', '', '2016-07-19 19:39:10'),
(3252, 6, 86, 158, 0, '', '0000-00-00', '', '2016-07-19 19:39:10'),
(3253, 7, 87, 167, 0, '', '0000-00-00', '', '2016-07-19 19:40:15'),
(3254, 7, 87, 171, 0, '', '0000-00-00', '', '2016-07-19 19:40:15'),
(3255, 7, 87, 183, 0, '', '0000-00-00', '', '2016-07-19 19:40:15'),
(3256, 7, 87, 193, 0, '', '0000-00-00', '', '2016-07-19 19:40:15'),
(3257, 7, 87, 202, 0, '', '0000-00-00', '', '2016-07-19 19:40:15'),
(3258, 8, 88, 205, 0, '', '0000-00-00', '', '2016-07-19 20:26:38'),
(3259, 8, 88, 213, 0, '', '0000-00-00', '', '2016-07-19 20:26:38'),
(3260, 8, 88, 225, 0, '', '0000-00-00', '', '2016-07-19 20:26:38'),
(3261, 8, 88, 227, 0, '', '0000-00-00', '', '2016-07-19 20:26:38'),
(3262, 8, 88, 237, 0, '', '0000-00-00', '', '2016-07-19 20:26:38'),
(3263, 9, 89, 246, 0, '', '0000-00-00', '', '2016-07-19 20:27:39'),
(3264, 9, 89, 254, 0, '', '0000-00-00', '', '2016-07-19 20:27:39'),
(3265, 9, 89, 259, 0, '', '0000-00-00', '', '2016-07-19 20:27:39'),
(3266, 9, 89, 271, 0, '', '0000-00-00', '', '2016-07-19 20:27:39'),
(3267, 9, 89, 275, 0, '', '0000-00-00', '', '2016-07-19 20:27:39'),
(3268, 10, 90, 287, 0, '', '0000-00-00', '', '2016-07-19 20:28:30'),
(3269, 10, 90, 297, 0, '', '0000-00-00', '', '2016-07-19 20:28:30'),
(3270, 10, 90, 301, 0, '', '0000-00-00', '', '2016-07-19 20:28:30'),
(3271, 10, 90, 313, 0, '', '0000-00-00', '', '2016-07-19 20:28:30'),
(3272, 10, 90, 318, 0, '', '0000-00-00', '', '2016-07-19 20:28:30'),
(3273, 3, 1, 514, 0, '', '0000-00-00', '', '2016-07-19 20:28:30'),
(3274, 11, 91, 521, 0, '', '2017-09-25', '', '2017-12-10 04:09:58'),
(3275, 11, 91, 522, 0, '', '2017-09-25', '', '2017-12-10 04:09:58'),
(3276, 11, 91, 523, 0, '', '2017-09-25', '', '2017-12-10 04:09:58'),
(3277, 11, 91, 524, 0, '', '2017-09-25', '', '2017-12-10 04:09:58'),
(3278, 11, 91, 525, 0, '', '2017-09-25', '', '2017-12-10 04:09:58'),
(3279, 11, 91, 526, 0, '', '2017-09-25', '', '2017-12-10 04:09:58'),
(3280, 11, 91, 527, 0, '', '2017-09-25', '', '2017-12-10 04:09:58'),
(3281, 11, 91, 528, 0, '', '2017-09-25', '', '2017-12-10 04:09:58'),
(3282, 11, 91, 529, 0, '', '2017-09-25', '', '2017-12-10 04:09:58'),
(3283, 11, 91, 530, 0, '', '2017-09-25', '', '2017-12-10 04:09:58'),
(3284, 11, 91, 531, 0, '', '2017-09-25', '', '2017-12-10 04:09:58'),
(3285, 11, 91, 532, 0, '', '2017-09-25', '', '2017-12-10 04:09:58'),
(3286, 11, 91, 533, 0, '', '2017-09-25', '', '2017-12-10 04:09:58'),
(3287, 11, 91, 534, 0, '', '2017-09-25', '', '2017-12-10 04:09:58'),
(3288, 11, 91, 535, 0, '', '2017-09-25', '', '2017-12-10 04:09:58'),
(3289, 11, 91, 536, 0, '', '2017-09-25', '', '2017-12-10 04:09:58'),
(3290, 11, 91, 537, 0, '', '2017-09-25', '', '2017-12-10 04:09:58'),
(3291, 11, 91, 538, 0, '', '2017-09-25', '', '2017-12-10 04:09:58'),
(3292, 11, 91, 539, 0, '', '2017-09-25', '', '2017-12-10 04:09:58'),
(3293, 11, 91, 540, 0, '', '2017-09-25', '', '2017-12-10 04:09:58'),
(3294, 11, 91, 541, 0, '', '2017-09-25', '', '2017-12-10 04:09:58'),
(3295, 11, 91, 542, 0, '', '2017-09-25', '', '2017-12-10 04:09:58'),
(3296, 11, 91, 543, 0, '', '2017-09-25', '', '2017-12-10 04:09:58'),
(3297, 11, 91, 544, 0, '', '2017-09-25', '', '2017-12-10 04:09:58'),
(3298, 11, 91, 545, 0, '', '2017-09-25', '', '2017-12-10 04:09:58'),
(3299, 11, 91, 546, 0, '', '2017-09-25', '', '2017-12-10 04:09:58'),
(3300, 11, 91, 547, 0, '', '2017-09-25', '', '2017-12-10 04:09:58'),
(3301, 11, 91, 548, 0, '', '2017-09-25', '', '2017-12-10 04:09:58'),
(3302, 11, 91, 549, 0, '', '2017-09-25', '', '2017-12-10 04:09:58'),
(3303, 11, 91, 550, 0, '', '2017-09-25', '', '2017-12-10 04:09:58'),
(3304, 11, 91, 551, 0, '', '2017-09-25', '', '2017-12-10 04:09:58'),
(3305, 11, 91, 552, 0, '', '2017-09-25', '', '2017-12-10 04:09:58'),
(3306, 11, 91, 553, 0, '', '2017-09-25', '', '2017-12-10 04:09:58'),
(3307, 11, 91, 554, 0, '', '2017-09-25', '', '2017-12-10 04:09:58'),
(3308, 11, 91, 555, 0, '', '2017-09-25', '', '2017-12-10 04:09:58'),
(3309, 11, 91, 556, 0, '', '2017-09-25', '', '2017-12-10 04:09:58'),
(3310, 11, 91, 557, 0, '', '2017-09-25', '', '2017-12-10 04:09:58'),
(3311, 11, 91, 558, 0, '', '2017-09-25', '', '2017-12-10 04:09:58'),
(3312, 11, 91, 559, 0, '', '2017-09-25', '', '2017-12-10 04:09:58'),
(3313, 11, 91, 560, 0, '', '2017-09-25', '', '2017-12-10 04:09:58'),
(3314, 1, 10, 561, 0, '', '2017-09-25', '', '2017-12-10 04:09:58'),
(3315, 1, 10, 562, 0, '', '2017-09-25', '', '2017-12-10 04:09:58'),
(3316, 1, 10, 563, 0, '', '2017-09-25', '', '2017-12-10 04:09:58'),
(3317, 1, 10, 564, 0, '', '2017-09-25', '', '2017-12-10 04:09:58'),
(3318, 1, 10, 565, 0, '', '2017-09-25', '', '2017-12-10 04:09:58'),
(3319, 1, 10, 566, 0, '', '2017-09-25', '', '2017-12-10 04:09:58'),
(3320, 1, 10, 567, 0, '', '2017-09-25', '', '2017-12-10 04:09:58'),
(3321, 1, 10, 568, 0, '', '2017-09-25', '', '2017-12-10 04:09:58'),
(3322, 1, 10, 569, 0, '', '2017-09-25', '', '2017-12-10 04:09:58'),
(3323, 1, 10, 570, 0, '', '2017-09-25', '', '2017-12-10 04:09:58'),
(3324, 1, 10, 571, 0, '', '2017-09-25', '', '2017-12-10 04:09:58'),
(3325, 1, 10, 572, 0, '', '2017-09-25', '', '2017-12-10 04:09:58'),
(3326, 1, 10, 573, 0, '', '2017-09-25', '', '2017-12-10 04:09:58'),
(3327, 1, 10, 574, 0, '', '2017-09-25', '', '2017-12-10 04:09:58'),
(3328, 1, 10, 575, 0, '', '2017-09-25', '', '2017-12-10 04:09:58'),
(3329, 1, 10, 576, 0, '', '2017-09-25', '', '2017-12-10 04:09:58'),
(3330, 1, 10, 577, 0, '', '2017-09-25', '', '2017-12-10 04:09:58'),
(3331, 1, 10, 578, 0, '', '2017-09-25', '', '2017-12-10 04:09:58'),
(3332, 1, 10, 579, 0, '', '2017-09-25', '', '2017-12-10 04:09:58'),
(3333, 1, 10, 580, 0, '', '2017-09-25', '', '2017-12-10 04:09:58'),
(3334, 1, 10, 581, 0, '', '2017-09-25', '', '2017-12-10 04:09:58'),
(3335, 1, 10, 582, 0, '', '2017-09-25', '', '2017-12-10 04:09:58'),
(3336, 1, 10, 583, 0, '', '2017-09-25', '', '2017-12-10 04:09:58'),
(3337, 1, 10, 584, 0, '', '2017-09-25', '', '2017-12-10 04:09:58'),
(3338, 1, 10, 585, 0, '', '2017-09-25', '', '2017-12-10 04:09:58'),
(3339, 1, 10, 586, 0, '', '2017-09-25', '', '2017-12-10 04:09:58'),
(3340, 1, 10, 587, 0, '', '2017-09-25', '', '2017-12-10 04:09:58'),
(3341, 1, 10, 588, 0, '', '2017-09-25', '', '2017-12-10 04:09:58'),
(3342, 1, 10, 589, 0, '', '2017-09-25', '', '2017-12-10 04:09:58'),
(3343, 1, 10, 590, 0, '', '2017-09-25', '', '2017-12-10 04:09:58'),
(3344, 1, 10, 591, 0, '', '2017-09-25', '', '2017-12-10 04:09:58'),
(3345, 1, 10, 592, 0, '', '2017-09-25', '', '2017-12-10 04:09:58'),
(3346, 1, 10, 593, 0, '', '2017-09-25', '', '2017-12-10 04:09:58'),
(3347, 1, 10, 594, 0, '', '2017-09-25', '', '2017-12-10 04:09:58'),
(3348, 1, 10, 595, 0, '', '2017-09-25', '', '2017-12-10 04:09:58'),
(3349, 1, 10, 596, 0, '', '2017-09-25', '', '2017-12-10 04:09:58'),
(3350, 1, 10, 597, 0, '', '2017-09-25', '', '2017-12-10 04:09:58'),
(3351, 1, 10, 598, 0, '', '2017-09-25', '', '2017-12-10 04:09:58'),
(3352, 1, 10, 599, 0, '', '2017-09-25', '', '2017-12-10 04:09:58'),
(3353, 1, 10, 600, 0, '', '2017-09-25', '', '2017-12-10 04:09:58'),
(3354, 2, 11, 601, 0, '', '2017-09-25', '', '2017-12-10 19:10:12'),
(3355, 2, 11, 602, 0, '', '2017-09-25', '', '2017-12-10 19:10:12'),
(3356, 2, 11, 603, 0, '', '2017-09-25', '', '2017-12-10 19:10:12'),
(3357, 2, 11, 604, 0, '', '2017-09-25', '', '2017-12-10 19:10:12'),
(3358, 2, 11, 605, 0, '', '2017-09-25', '', '2017-12-10 19:10:12'),
(3359, 2, 11, 606, 0, '', '2017-09-25', '', '2017-12-10 19:10:12'),
(3360, 2, 11, 607, 0, '', '2017-09-25', '', '2017-12-10 19:10:12'),
(3361, 2, 11, 608, 0, '', '2017-09-25', '', '2017-12-10 19:10:12'),
(3362, 2, 11, 609, 0, '', '2017-09-25', '', '2017-12-10 19:10:12'),
(3363, 2, 11, 610, 0, '', '2017-09-25', '', '2017-12-10 19:10:12'),
(3364, 2, 11, 611, 0, '', '2017-09-25', '', '2017-12-10 19:10:12'),
(3365, 2, 11, 612, 0, '', '2017-09-25', '', '2017-12-10 19:10:12'),
(3366, 2, 11, 613, 0, '', '2017-09-25', '', '2017-12-10 19:10:12'),
(3367, 2, 11, 614, 0, '', '2017-09-25', '', '2017-12-10 19:10:12'),
(3368, 2, 11, 615, 0, '', '2017-09-25', '', '2017-12-10 19:10:12'),
(3369, 2, 11, 616, 0, '', '2017-09-25', '', '2017-12-10 19:10:12'),
(3370, 2, 11, 617, 0, '', '2017-09-25', '', '2017-12-10 19:10:12'),
(3371, 2, 11, 618, 0, '', '2017-09-25', '', '2017-12-10 19:10:12'),
(3372, 2, 11, 619, 0, '', '2017-09-25', '', '2017-12-10 19:10:12'),
(3373, 2, 11, 620, 0, '', '2017-09-25', '', '2017-12-10 19:10:12'),
(3374, 2, 11, 621, 0, '', '2017-09-25', '', '2017-12-10 19:10:12'),
(3375, 2, 11, 622, 0, '', '2017-09-25', '', '2017-12-10 19:10:12'),
(3376, 2, 11, 623, 0, '', '2017-09-25', '', '2017-12-10 19:10:12'),
(3377, 2, 11, 624, 0, '', '2017-09-25', '', '2017-12-10 19:10:12'),
(3378, 2, 11, 625, 0, '', '2017-09-25', '', '2017-12-10 19:10:12'),
(3379, 2, 11, 626, 0, '', '2017-09-25', '', '2017-12-10 19:10:12'),
(3380, 2, 11, 627, 0, '', '2017-09-25', '', '2017-12-10 19:10:12'),
(3381, 2, 11, 628, 0, '', '2017-09-25', '', '2017-12-10 19:10:12'),
(3382, 2, 11, 629, 0, '', '2017-09-25', '', '2017-12-10 19:10:12'),
(3383, 2, 11, 630, 0, '', '2017-09-25', '', '2017-12-10 19:10:12'),
(3384, 2, 11, 631, 0, '', '2017-09-25', '', '2017-12-10 19:10:12'),
(3385, 2, 11, 632, 0, '', '2017-09-25', '', '2017-12-10 19:10:12'),
(3386, 2, 11, 633, 0, '', '2017-09-25', '', '2017-12-10 19:10:12'),
(3387, 2, 11, 634, 0, '', '2017-09-25', '', '2017-12-10 19:10:12'),
(3388, 2, 11, 635, 0, '', '2017-09-25', '', '2017-12-10 19:10:12'),
(3389, 2, 11, 636, 0, '', '2017-09-25', '', '2017-12-10 19:10:12'),
(3390, 2, 11, 637, 0, '', '2017-09-25', '', '2017-12-10 19:10:12'),
(3391, 2, 11, 638, 0, '', '2017-09-25', '', '2017-12-10 19:10:12'),
(3392, 2, 11, 639, 0, '', '2017-09-25', '', '2017-12-10 19:10:12'),
(3393, 2, 11, 640, 0, '', '2017-09-25', '', '2017-12-10 19:10:12');

-- --------------------------------------------------------

--
-- Table structure for table `class_skill_game`
--

CREATE TABLE `class_skill_game` (
  `id` int(11) NOT NULL,
  `class_id` int(11) NOT NULL,
  `skill_id` int(11) NOT NULL,
  `game_id` int(11) NOT NULL,
  `status` int(1) NOT NULL,
  `createdby` varchar(100) NOT NULL,
  `creation_date` date NOT NULL,
  `modifiedby` varchar(100) NOT NULL,
  `modified_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `class_skill_game`
--

INSERT INTO `class_skill_game` (`id`, `class_id`, `skill_id`, `game_id`, `status`, `createdby`, `creation_date`, `modifiedby`, `modified_date`) VALUES
(1, 3, 59, 1, 0, '', '0000-00-00', '', '2014-06-15 02:15:37'),
(2, 3, 59, 2, 0, '', '0000-00-00', '', '2014-06-15 02:15:37'),
(3, 3, 59, 3, 0, '', '0000-00-00', '', '2014-06-15 02:15:37'),
(4, 3, 59, 4, 0, '', '0000-00-00', '', '2014-06-15 02:15:37'),
(5, 3, 59, 5, 0, '', '0000-00-00', '', '2014-06-15 02:15:37'),
(6, 3, 59, 6, 0, '', '0000-00-00', '', '2014-06-15 02:15:37'),
(7, 3, 59, 7, 0, '', '0000-00-00', '', '2014-06-15 02:15:37'),
(8, 3, 59, 8, 0, '', '0000-00-00', '', '2014-06-15 02:15:37'),
(9, 3, 60, 9, 0, '', '0000-00-00', '', '2014-06-15 02:20:51'),
(10, 3, 60, 10, 0, '', '0000-00-00', '', '2014-06-15 02:20:51'),
(11, 3, 60, 11, 0, '', '0000-00-00', '', '2014-06-15 02:20:51'),
(12, 3, 60, 12, 0, '', '0000-00-00', '', '2014-06-15 02:20:51'),
(13, 3, 60, 15, 0, '', '0000-00-00', '', '2014-06-15 02:20:51'),
(14, 3, 60, 16, 0, '', '0000-00-00', '', '2014-06-15 02:20:51'),
(15, 3, 60, 17, 0, '', '0000-00-00', '', '2014-06-15 02:20:51'),
(16, 3, 60, 18, 0, '', '0000-00-00', '', '2014-06-15 02:20:51'),
(17, 3, 61, 19, 0, '', '0000-00-00', '', '2014-06-15 02:21:08'),
(18, 3, 61, 20, 0, '', '0000-00-00', '', '2014-06-15 02:21:08'),
(19, 3, 61, 21, 0, '', '0000-00-00', '', '2014-06-15 02:21:08'),
(20, 3, 61, 22, 0, '', '0000-00-00', '', '2014-06-15 02:21:08'),
(21, 3, 61, 23, 0, '', '0000-00-00', '', '2014-06-15 02:21:08'),
(22, 3, 61, 24, 0, '', '0000-00-00', '', '2014-06-15 02:21:08'),
(23, 3, 61, 25, 0, '', '0000-00-00', '', '2014-06-15 02:21:08'),
(24, 3, 61, 26, 0, '', '0000-00-00', '', '2014-06-15 02:21:08'),
(25, 3, 62, 27, 0, '', '0000-00-00', '', '2014-06-15 02:21:26'),
(26, 3, 62, 28, 0, '', '0000-00-00', '', '2014-06-15 02:21:26'),
(27, 3, 62, 29, 0, '', '0000-00-00', '', '2014-06-15 02:21:26'),
(28, 3, 62, 30, 0, '', '0000-00-00', '', '2014-06-15 02:21:26'),
(29, 3, 62, 31, 0, '', '0000-00-00', '', '2014-06-15 02:21:26'),
(30, 3, 62, 32, 0, '', '0000-00-00', '', '2014-06-15 02:21:26'),
(31, 3, 62, 33, 0, '', '0000-00-00', '', '2014-06-15 02:21:26'),
(32, 3, 62, 34, 0, '', '0000-00-00', '', '2014-06-15 02:21:26'),
(33, 3, 63, 35, 0, '', '0000-00-00', '', '2014-06-15 02:21:41'),
(34, 3, 63, 36, 0, '', '0000-00-00', '', '2014-06-15 02:21:42'),
(35, 3, 63, 37, 0, '', '0000-00-00', '', '2014-06-15 02:21:42'),
(36, 3, 63, 38, 0, '', '0000-00-00', '', '2014-06-15 02:21:42'),
(37, 3, 63, 39, 0, '', '0000-00-00', '', '2014-06-15 02:21:42'),
(38, 3, 63, 40, 0, '', '0000-00-00', '', '2014-06-15 02:21:42'),
(39, 3, 63, 41, 0, '', '0000-00-00', '', '2014-06-15 02:21:42'),
(40, 3, 63, 42, 0, '', '0000-00-00', '', '2014-06-15 02:21:42'),
(41, 4, 59, 43, 0, '', '0000-00-00', '', '2014-06-15 02:22:20'),
(42, 4, 59, 44, 0, '', '0000-00-00', '', '2014-06-15 02:22:20'),
(43, 4, 59, 45, 0, '', '0000-00-00', '', '2014-06-15 02:22:20'),
(44, 4, 59, 46, 0, '', '0000-00-00', '', '2014-06-15 02:22:20'),
(45, 4, 59, 47, 0, '', '0000-00-00', '', '2014-06-15 02:22:20'),
(46, 4, 59, 48, 0, '', '0000-00-00', '', '2014-06-15 02:22:20'),
(47, 4, 59, 49, 0, '', '0000-00-00', '', '2014-06-15 02:22:20'),
(48, 4, 59, 50, 0, '', '0000-00-00', '', '2014-06-15 02:22:20'),
(49, 4, 60, 51, 0, '', '0000-00-00', '', '2014-06-15 02:22:40'),
(50, 4, 60, 52, 0, '', '0000-00-00', '', '2014-06-15 02:22:41'),
(51, 4, 60, 53, 0, '', '0000-00-00', '', '2014-06-15 02:22:41'),
(52, 4, 60, 54, 0, '', '0000-00-00', '', '2014-06-15 02:22:41'),
(53, 4, 60, 55, 0, '', '0000-00-00', '', '2014-06-15 02:22:41'),
(54, 4, 60, 56, 0, '', '0000-00-00', '', '2014-06-15 02:22:41'),
(55, 4, 60, 57, 0, '', '0000-00-00', '', '2014-06-15 02:22:41'),
(56, 4, 60, 58, 0, '', '0000-00-00', '', '2014-06-15 02:22:41'),
(57, 4, 61, 59, 0, '', '0000-00-00', '', '2014-06-15 02:23:01'),
(58, 4, 61, 60, 0, '', '0000-00-00', '', '2014-06-15 02:23:01'),
(59, 4, 61, 61, 0, '', '0000-00-00', '', '2014-06-15 02:23:01'),
(60, 4, 61, 62, 0, '', '0000-00-00', '', '2014-06-15 02:23:01'),
(61, 4, 61, 63, 0, '', '0000-00-00', '', '2014-06-15 02:23:01'),
(62, 4, 61, 64, 0, '', '0000-00-00', '', '2014-06-15 02:23:01'),
(63, 4, 61, 65, 0, '', '0000-00-00', '', '2014-06-15 02:23:01'),
(64, 4, 61, 66, 0, '', '0000-00-00', '', '2014-06-15 02:23:01'),
(65, 4, 62, 67, 0, '', '0000-00-00', '', '2014-06-15 02:23:21'),
(66, 4, 62, 68, 0, '', '0000-00-00', '', '2014-06-15 02:23:21'),
(67, 4, 62, 69, 0, '', '0000-00-00', '', '2014-06-15 02:23:21'),
(68, 4, 62, 70, 0, '', '0000-00-00', '', '2014-06-15 02:23:21'),
(69, 4, 62, 71, 0, '', '0000-00-00', '', '2014-06-15 02:23:21'),
(70, 4, 62, 72, 0, '', '0000-00-00', '', '2014-06-15 02:23:21'),
(71, 4, 62, 73, 0, '', '0000-00-00', '', '2014-06-15 02:23:21'),
(72, 4, 62, 74, 0, '', '0000-00-00', '', '2014-06-15 02:23:21'),
(73, 4, 63, 75, 0, '', '0000-00-00', '', '2014-06-15 02:23:41'),
(74, 4, 63, 76, 0, '', '0000-00-00', '', '2014-06-15 02:23:41'),
(75, 4, 63, 77, 0, '', '0000-00-00', '', '2014-06-15 02:23:41'),
(76, 4, 63, 78, 0, '', '0000-00-00', '', '2014-06-15 02:23:41'),
(77, 4, 63, 79, 0, '', '0000-00-00', '', '2014-06-15 02:23:41'),
(78, 4, 63, 80, 0, '', '0000-00-00', '', '2014-06-15 02:23:41'),
(79, 4, 63, 81, 0, '', '0000-00-00', '', '2014-06-15 02:23:41'),
(80, 4, 63, 82, 0, '', '0000-00-00', '', '2014-06-15 02:23:41'),
(81, 5, 59, 83, 0, '', '0000-00-00', '', '2014-06-15 02:24:03'),
(82, 5, 59, 84, 0, '', '0000-00-00', '', '2014-06-15 02:24:03'),
(83, 5, 59, 85, 0, '', '0000-00-00', '', '2014-06-15 02:24:03'),
(84, 5, 59, 86, 0, '', '0000-00-00', '', '2014-06-15 02:24:03'),
(85, 5, 59, 87, 0, '', '0000-00-00', '', '2014-06-15 02:24:03'),
(86, 5, 59, 88, 0, '', '0000-00-00', '', '2014-06-15 02:24:03'),
(87, 5, 59, 89, 0, '', '0000-00-00', '', '2014-06-15 02:24:03'),
(88, 5, 59, 90, 0, '', '0000-00-00', '', '2014-06-15 02:24:03'),
(89, 5, 60, 91, 0, '', '0000-00-00', '', '2014-06-15 02:25:24'),
(90, 5, 60, 92, 0, '', '0000-00-00', '', '2014-06-15 02:25:24'),
(91, 5, 60, 93, 0, '', '0000-00-00', '', '2014-06-15 02:25:24'),
(92, 5, 60, 94, 0, '', '0000-00-00', '', '2014-06-15 02:25:24'),
(93, 5, 60, 95, 0, '', '0000-00-00', '', '2014-06-15 02:25:24'),
(94, 5, 60, 96, 0, '', '0000-00-00', '', '2014-06-15 02:25:24'),
(95, 5, 60, 97, 0, '', '0000-00-00', '', '2014-06-15 02:25:24'),
(96, 5, 60, 98, 0, '', '0000-00-00', '', '2014-06-15 02:25:24'),
(97, 5, 61, 99, 0, '', '0000-00-00', '', '2014-06-15 02:25:48'),
(98, 5, 61, 100, 0, '', '0000-00-00', '', '2014-06-15 02:25:48'),
(99, 5, 61, 101, 0, '', '0000-00-00', '', '2014-06-15 02:25:48'),
(100, 5, 61, 102, 0, '', '0000-00-00', '', '2014-06-15 02:25:48'),
(101, 5, 61, 103, 0, '', '0000-00-00', '', '2014-06-15 02:25:48'),
(102, 5, 61, 104, 0, '', '0000-00-00', '', '2014-06-15 02:25:48'),
(103, 5, 61, 105, 0, '', '0000-00-00', '', '2014-06-15 02:25:48'),
(104, 5, 61, 106, 0, '', '0000-00-00', '', '2014-06-15 02:25:48'),
(105, 5, 62, 107, 0, '', '0000-00-00', '', '2014-06-15 02:26:13'),
(106, 5, 62, 108, 0, '', '0000-00-00', '', '2014-06-15 02:26:13'),
(107, 5, 62, 109, 0, '', '0000-00-00', '', '2014-06-15 02:26:13'),
(108, 5, 62, 110, 0, '', '0000-00-00', '', '2014-06-15 02:26:13'),
(109, 5, 62, 111, 0, '', '0000-00-00', '', '2014-06-15 02:26:13'),
(110, 5, 62, 112, 0, '', '0000-00-00', '', '2014-06-15 02:26:13'),
(111, 5, 62, 113, 0, '', '0000-00-00', '', '2014-06-15 02:26:13'),
(112, 5, 62, 114, 0, '', '0000-00-00', '', '2014-06-15 02:26:13'),
(113, 5, 63, 115, 0, '', '0000-00-00', '', '2014-06-15 02:26:46'),
(114, 5, 63, 116, 0, '', '0000-00-00', '', '2014-06-15 02:26:46'),
(115, 5, 63, 117, 0, '', '0000-00-00', '', '2014-06-15 02:26:46'),
(116, 5, 63, 118, 0, '', '0000-00-00', '', '2014-06-15 02:26:46'),
(117, 5, 63, 119, 0, '', '0000-00-00', '', '2014-06-15 02:26:46'),
(118, 5, 63, 120, 0, '', '0000-00-00', '', '2014-06-15 02:26:46'),
(119, 5, 63, 121, 0, '', '0000-00-00', '', '2014-06-15 02:26:46'),
(120, 5, 63, 122, 0, '', '0000-00-00', '', '2014-06-15 02:26:46'),
(121, 6, 59, 123, 0, '', '0000-00-00', '', '2014-06-15 02:27:05'),
(122, 6, 59, 124, 0, '', '0000-00-00', '', '2014-06-15 02:27:05'),
(123, 6, 59, 125, 0, '', '0000-00-00', '', '2014-06-15 02:27:05'),
(124, 6, 59, 126, 0, '', '0000-00-00', '', '2014-06-15 02:27:05'),
(125, 6, 59, 127, 0, '', '0000-00-00', '', '2014-06-15 02:27:05'),
(126, 6, 59, 128, 0, '', '0000-00-00', '', '2014-06-15 02:27:05'),
(127, 6, 59, 129, 0, '', '0000-00-00', '', '2014-06-15 02:27:05'),
(128, 6, 59, 130, 0, '', '0000-00-00', '', '2014-06-15 02:27:05'),
(129, 6, 60, 131, 0, '', '0000-00-00', '', '2014-06-15 02:27:39'),
(130, 6, 60, 132, 0, '', '0000-00-00', '', '2014-06-15 02:27:39'),
(131, 6, 60, 133, 0, '', '0000-00-00', '', '2014-06-15 02:27:39'),
(132, 6, 60, 134, 0, '', '0000-00-00', '', '2014-06-15 02:27:39'),
(133, 6, 60, 135, 0, '', '0000-00-00', '', '2014-06-15 02:27:39'),
(134, 6, 60, 136, 0, '', '0000-00-00', '', '2014-06-15 02:27:39'),
(135, 6, 60, 137, 0, '', '0000-00-00', '', '2014-06-15 02:27:39'),
(136, 6, 60, 138, 0, '', '0000-00-00', '', '2014-06-15 02:27:39'),
(137, 6, 61, 139, 0, '', '0000-00-00', '', '2014-06-15 02:28:16'),
(138, 6, 61, 140, 0, '', '0000-00-00', '', '2014-06-15 02:28:16'),
(139, 6, 61, 141, 0, '', '0000-00-00', '', '2014-06-15 02:28:16'),
(140, 6, 61, 142, 0, '', '0000-00-00', '', '2014-06-15 02:28:16'),
(141, 6, 61, 143, 0, '', '0000-00-00', '', '2014-06-15 02:28:16'),
(142, 6, 61, 144, 0, '', '0000-00-00', '', '2014-06-15 02:28:16'),
(143, 6, 61, 145, 0, '', '0000-00-00', '', '2014-06-15 02:28:16'),
(144, 6, 61, 146, 0, '', '0000-00-00', '', '2014-06-15 02:28:16'),
(145, 6, 62, 147, 0, '', '0000-00-00', '', '2014-06-15 02:29:09'),
(146, 6, 62, 148, 0, '', '0000-00-00', '', '2014-06-15 02:29:09'),
(147, 6, 62, 149, 0, '', '0000-00-00', '', '2014-06-15 02:29:09'),
(148, 6, 62, 150, 0, '', '0000-00-00', '', '2014-06-15 02:29:09'),
(149, 6, 62, 151, 0, '', '0000-00-00', '', '2014-06-15 02:29:09'),
(150, 6, 62, 152, 0, '', '0000-00-00', '', '2014-06-15 02:29:09'),
(151, 6, 62, 153, 0, '', '0000-00-00', '', '2014-06-15 02:29:09'),
(152, 6, 62, 154, 0, '', '0000-00-00', '', '2014-06-15 02:29:09'),
(153, 6, 63, 155, 0, '', '0000-00-00', '', '2014-06-15 02:29:55'),
(154, 6, 63, 156, 0, '', '0000-00-00', '', '2014-06-15 02:29:55'),
(155, 6, 63, 157, 0, '', '0000-00-00', '', '2014-06-15 02:29:55'),
(156, 6, 63, 158, 0, '', '0000-00-00', '', '2014-06-15 02:29:55'),
(157, 6, 63, 159, 0, '', '0000-00-00', '', '2014-06-15 02:29:55'),
(158, 6, 63, 160, 0, '', '0000-00-00', '', '2014-06-15 02:29:55'),
(159, 6, 63, 161, 0, '', '0000-00-00', '', '2014-06-15 02:29:55'),
(160, 6, 63, 162, 0, '', '0000-00-00', '', '2014-06-15 02:29:55'),
(161, 7, 59, 163, 0, '', '0000-00-00', '', '2014-06-15 02:30:14'),
(162, 7, 59, 164, 0, '', '0000-00-00', '', '2014-06-15 02:30:14'),
(163, 7, 59, 165, 0, '', '0000-00-00', '', '2014-06-15 02:30:14'),
(164, 7, 59, 166, 0, '', '0000-00-00', '', '2014-06-15 02:30:14'),
(165, 7, 59, 167, 0, '', '0000-00-00', '', '2014-06-15 02:30:14'),
(166, 7, 59, 168, 0, '', '0000-00-00', '', '2014-06-15 02:30:14'),
(167, 7, 59, 169, 0, '', '0000-00-00', '', '2014-06-15 02:30:14'),
(168, 7, 59, 170, 0, '', '0000-00-00', '', '2014-06-15 02:30:14'),
(169, 7, 60, 171, 0, '', '0000-00-00', '', '2014-06-15 02:30:56'),
(170, 7, 60, 172, 0, '', '0000-00-00', '', '2014-06-15 02:30:56'),
(171, 7, 60, 173, 0, '', '0000-00-00', '', '2014-06-15 02:30:56'),
(172, 7, 60, 174, 0, '', '0000-00-00', '', '2014-06-15 02:30:56'),
(173, 7, 60, 175, 0, '', '0000-00-00', '', '2014-06-15 02:30:56'),
(174, 7, 60, 176, 0, '', '0000-00-00', '', '2014-06-15 02:30:56'),
(175, 7, 60, 177, 0, '', '0000-00-00', '', '2014-06-15 02:30:56'),
(176, 7, 60, 178, 0, '', '0000-00-00', '', '2014-06-15 02:30:56'),
(177, 7, 61, 179, 0, '', '0000-00-00', '', '2014-06-15 02:31:31'),
(178, 7, 61, 180, 0, '', '0000-00-00', '', '2014-06-15 02:31:31'),
(179, 7, 61, 181, 0, '', '0000-00-00', '', '2014-06-15 02:31:31'),
(180, 7, 61, 182, 0, '', '0000-00-00', '', '2014-06-15 02:31:31'),
(181, 7, 61, 183, 0, '', '0000-00-00', '', '2014-06-15 02:31:31'),
(182, 7, 61, 184, 0, '', '0000-00-00', '', '2014-06-15 02:31:31'),
(183, 7, 61, 185, 0, '', '0000-00-00', '', '2014-06-15 02:31:31'),
(184, 7, 61, 186, 0, '', '0000-00-00', '', '2014-06-15 02:31:31'),
(185, 7, 62, 187, 0, '', '0000-00-00', '', '2014-06-15 02:32:05'),
(186, 7, 62, 188, 0, '', '0000-00-00', '', '2014-06-15 02:32:05'),
(187, 7, 62, 189, 0, '', '0000-00-00', '', '2014-06-15 02:32:06'),
(188, 7, 62, 190, 0, '', '0000-00-00', '', '2014-06-15 02:32:06'),
(189, 7, 62, 191, 0, '', '0000-00-00', '', '2014-06-15 02:32:06'),
(190, 7, 62, 192, 0, '', '0000-00-00', '', '2014-06-15 02:32:06'),
(191, 7, 62, 193, 0, '', '0000-00-00', '', '2014-06-15 02:32:06'),
(192, 7, 62, 194, 0, '', '0000-00-00', '', '2014-06-15 02:32:06'),
(193, 7, 63, 195, 0, '', '0000-00-00', '', '2014-06-15 02:32:56'),
(194, 7, 63, 196, 0, '', '0000-00-00', '', '2014-06-15 02:32:56'),
(195, 7, 63, 197, 0, '', '0000-00-00', '', '2014-06-15 02:32:56'),
(196, 7, 63, 198, 0, '', '0000-00-00', '', '2014-06-15 02:32:56'),
(197, 7, 63, 199, 0, '', '0000-00-00', '', '2014-06-15 02:32:56'),
(198, 7, 63, 200, 0, '', '0000-00-00', '', '2014-06-15 02:32:56'),
(199, 7, 63, 201, 0, '', '0000-00-00', '', '2014-06-15 02:32:56'),
(200, 7, 63, 202, 0, '', '0000-00-00', '', '2014-06-15 02:32:56'),
(201, 8, 59, 203, 0, '', '0000-00-00', '', '2014-06-15 02:34:17'),
(202, 8, 59, 204, 0, '', '0000-00-00', '', '2014-06-15 02:34:17'),
(203, 8, 59, 205, 0, '', '0000-00-00', '', '2014-06-15 02:34:17'),
(204, 8, 59, 206, 0, '', '0000-00-00', '', '2014-06-15 02:34:17'),
(205, 8, 59, 207, 0, '', '0000-00-00', '', '2014-06-15 02:34:17'),
(206, 8, 59, 208, 0, '', '0000-00-00', '', '2014-06-15 02:34:17'),
(207, 8, 59, 209, 0, '', '0000-00-00', '', '2014-06-15 02:34:17'),
(208, 8, 59, 210, 0, '', '0000-00-00', '', '2014-06-15 02:34:17'),
(209, 8, 60, 211, 0, '', '0000-00-00', '', '2014-06-15 02:34:43'),
(210, 8, 60, 212, 0, '', '0000-00-00', '', '2014-06-15 02:34:44'),
(211, 8, 60, 213, 0, '', '0000-00-00', '', '2014-06-15 02:34:44'),
(212, 8, 60, 214, 0, '', '0000-00-00', '', '2014-06-15 02:34:44'),
(213, 8, 60, 215, 0, '', '0000-00-00', '', '2014-06-15 02:34:44'),
(214, 8, 60, 216, 0, '', '0000-00-00', '', '2014-06-15 02:34:44'),
(215, 8, 60, 217, 0, '', '0000-00-00', '', '2014-06-15 02:34:44'),
(216, 8, 60, 218, 0, '', '0000-00-00', '', '2014-06-15 02:34:44'),
(217, 8, 61, 219, 0, '', '0000-00-00', '', '2014-06-15 02:35:31'),
(218, 8, 61, 220, 0, '', '0000-00-00', '', '2014-06-15 02:35:31'),
(219, 8, 61, 221, 0, '', '0000-00-00', '', '2014-06-15 02:35:31'),
(220, 8, 61, 222, 0, '', '0000-00-00', '', '2014-06-15 02:35:31'),
(221, 8, 61, 223, 0, '', '0000-00-00', '', '2014-06-15 02:35:31'),
(222, 8, 61, 224, 0, '', '0000-00-00', '', '2014-06-15 02:35:31'),
(223, 8, 61, 225, 0, '', '0000-00-00', '', '2014-06-15 02:35:31'),
(224, 8, 61, 226, 0, '', '0000-00-00', '', '2014-06-15 02:35:31'),
(225, 8, 62, 227, 0, '', '0000-00-00', '', '2014-06-15 02:35:59'),
(226, 8, 62, 228, 0, '', '0000-00-00', '', '2014-06-15 02:35:59'),
(227, 8, 62, 229, 0, '', '0000-00-00', '', '2014-06-15 02:35:59'),
(228, 8, 62, 230, 0, '', '0000-00-00', '', '2014-06-15 02:35:59'),
(229, 8, 62, 231, 0, '', '0000-00-00', '', '2014-06-15 02:35:59'),
(230, 8, 62, 232, 0, '', '0000-00-00', '', '2014-06-15 02:35:59'),
(231, 8, 62, 233, 0, '', '0000-00-00', '', '2014-06-15 02:35:59'),
(232, 8, 62, 234, 0, '', '0000-00-00', '', '2014-06-15 02:35:59'),
(233, 8, 63, 235, 0, '', '0000-00-00', '', '2014-06-15 02:36:36'),
(234, 8, 63, 236, 0, '', '0000-00-00', '', '2014-06-15 02:36:36'),
(235, 8, 63, 237, 0, '', '0000-00-00', '', '2014-06-15 02:36:36'),
(236, 8, 63, 238, 0, '', '0000-00-00', '', '2014-06-15 02:36:36'),
(237, 8, 63, 239, 0, '', '0000-00-00', '', '2014-06-15 02:36:36'),
(238, 8, 63, 240, 0, '', '0000-00-00', '', '2014-06-15 02:36:36'),
(239, 8, 63, 241, 0, '', '0000-00-00', '', '2014-06-15 02:36:36'),
(240, 8, 63, 242, 0, '', '0000-00-00', '', '2014-06-15 02:36:36'),
(241, 9, 59, 243, 0, '', '0000-00-00', '', '2014-06-15 02:37:57'),
(242, 9, 59, 244, 0, '', '0000-00-00', '', '2014-06-15 02:37:57'),
(243, 9, 59, 245, 0, '', '0000-00-00', '', '2014-06-15 02:37:57'),
(244, 9, 59, 246, 0, '', '0000-00-00', '', '2014-06-15 02:37:57'),
(245, 9, 59, 247, 0, '', '0000-00-00', '', '2014-06-15 02:37:57'),
(246, 9, 59, 248, 0, '', '0000-00-00', '', '2014-06-15 02:37:57'),
(247, 9, 59, 249, 0, '', '0000-00-00', '', '2014-06-15 02:37:57'),
(248, 9, 59, 250, 0, '', '0000-00-00', '', '2014-06-15 02:37:57'),
(249, 9, 60, 251, 0, '', '0000-00-00', '', '2014-06-15 02:38:24'),
(250, 9, 60, 252, 0, '', '0000-00-00', '', '2014-06-15 02:38:24'),
(251, 9, 60, 253, 0, '', '0000-00-00', '', '2014-06-15 02:38:24'),
(252, 9, 60, 254, 0, '', '0000-00-00', '', '2014-06-15 02:38:24'),
(253, 9, 60, 255, 0, '', '0000-00-00', '', '2014-06-15 02:38:24'),
(254, 9, 60, 256, 0, '', '0000-00-00', '', '2014-06-15 02:38:24'),
(255, 9, 60, 257, 0, '', '0000-00-00', '', '2014-06-15 02:38:24'),
(256, 9, 60, 258, 0, '', '0000-00-00', '', '2014-06-15 02:38:24'),
(257, 9, 61, 259, 0, '', '0000-00-00', '', '2014-06-15 02:38:51'),
(258, 9, 61, 260, 0, '', '0000-00-00', '', '2014-06-15 02:38:51'),
(259, 9, 61, 261, 0, '', '0000-00-00', '', '2014-06-15 02:38:51'),
(260, 9, 61, 262, 0, '', '0000-00-00', '', '2014-06-15 02:38:51'),
(261, 9, 61, 263, 0, '', '0000-00-00', '', '2014-06-15 02:38:51'),
(262, 9, 61, 264, 0, '', '0000-00-00', '', '2014-06-15 02:38:51'),
(263, 9, 61, 265, 0, '', '0000-00-00', '', '2014-06-15 02:38:51'),
(264, 9, 61, 266, 0, '', '0000-00-00', '', '2014-06-15 02:38:51'),
(265, 9, 62, 267, 0, '', '0000-00-00', '', '2014-06-15 02:39:12'),
(266, 9, 62, 268, 0, '', '0000-00-00', '', '2014-06-15 02:39:13'),
(267, 9, 62, 269, 0, '', '0000-00-00', '', '2014-06-15 02:39:13'),
(268, 9, 62, 270, 0, '', '0000-00-00', '', '2014-06-15 02:39:13'),
(269, 9, 62, 271, 0, '', '0000-00-00', '', '2014-06-15 02:39:13'),
(270, 9, 62, 272, 0, '', '0000-00-00', '', '2014-06-15 02:39:13'),
(271, 9, 62, 273, 0, '', '0000-00-00', '', '2014-06-15 02:39:13'),
(272, 9, 62, 274, 0, '', '0000-00-00', '', '2014-06-15 02:39:13'),
(273, 9, 63, 275, 0, '', '0000-00-00', '', '2014-06-15 02:39:47'),
(274, 9, 63, 276, 0, '', '0000-00-00', '', '2014-06-15 02:39:48'),
(275, 9, 63, 277, 0, '', '0000-00-00', '', '2014-06-15 02:39:48'),
(276, 9, 63, 278, 0, '', '0000-00-00', '', '2014-06-15 02:39:48'),
(277, 9, 63, 279, 0, '', '0000-00-00', '', '2014-06-15 02:39:48'),
(278, 9, 63, 280, 0, '', '0000-00-00', '', '2014-06-15 02:39:48'),
(279, 9, 63, 281, 0, '', '0000-00-00', '', '2014-06-15 02:39:48'),
(280, 9, 63, 282, 0, '', '0000-00-00', '', '2014-06-15 02:39:48'),
(281, 10, 59, 283, 0, '', '0000-00-00', '', '2014-06-15 02:44:02'),
(282, 10, 59, 284, 0, '', '0000-00-00', '', '2014-06-15 02:44:02'),
(283, 10, 59, 285, 0, '', '0000-00-00', '', '2014-06-15 02:44:02'),
(284, 10, 59, 286, 0, '', '0000-00-00', '', '2014-06-15 02:44:02'),
(285, 10, 59, 287, 0, '', '0000-00-00', '', '2014-06-15 02:44:02'),
(286, 10, 59, 288, 0, '', '0000-00-00', '', '2014-06-15 02:44:02'),
(287, 10, 59, 289, 0, '', '0000-00-00', '', '2014-06-15 02:44:02'),
(288, 10, 59, 290, 0, '', '0000-00-00', '', '2014-06-15 02:44:02'),
(289, 10, 60, 291, 0, '', '0000-00-00', '', '2014-06-15 02:44:20'),
(290, 10, 60, 292, 0, '', '0000-00-00', '', '2014-06-15 02:44:21'),
(291, 10, 60, 293, 0, '', '0000-00-00', '', '2014-06-15 02:44:22'),
(292, 10, 60, 294, 0, '', '0000-00-00', '', '2014-06-15 02:44:23'),
(293, 10, 60, 295, 0, '', '0000-00-00', '', '2014-06-15 02:44:24'),
(294, 10, 60, 296, 0, '', '0000-00-00', '', '2014-06-15 02:44:24'),
(295, 10, 60, 297, 0, '', '0000-00-00', '', '2014-06-15 02:44:24'),
(296, 10, 60, 298, 0, '', '0000-00-00', '', '2014-06-15 02:44:24'),
(297, 10, 61, 299, 0, '', '0000-00-00', '', '2014-06-15 02:47:55'),
(298, 10, 61, 300, 0, '', '0000-00-00', '', '2014-06-15 02:47:55'),
(299, 10, 61, 301, 0, '', '0000-00-00', '', '2014-06-15 02:47:55'),
(300, 10, 61, 302, 0, '', '0000-00-00', '', '2014-06-15 02:47:55'),
(301, 10, 61, 303, 0, '', '0000-00-00', '', '2014-06-15 02:47:55'),
(302, 10, 61, 304, 0, '', '0000-00-00', '', '2014-06-15 02:47:55'),
(303, 10, 61, 306, 0, '', '0000-00-00', '', '2014-06-15 02:47:55'),
(304, 10, 61, 307, 0, '', '0000-00-00', '', '2014-06-15 02:47:55'),
(305, 10, 62, 308, 0, '', '0000-00-00', '', '2014-06-15 02:48:18'),
(306, 10, 62, 309, 0, '', '0000-00-00', '', '2014-06-15 02:48:18'),
(307, 10, 62, 310, 0, '', '0000-00-00', '', '2014-06-15 02:48:18'),
(308, 10, 62, 311, 0, '', '0000-00-00', '', '2014-06-15 02:48:18'),
(309, 10, 62, 312, 0, '', '0000-00-00', '', '2014-06-15 02:48:18'),
(310, 10, 62, 313, 0, '', '0000-00-00', '', '2014-06-15 02:48:18'),
(311, 10, 62, 314, 0, '', '0000-00-00', '', '2014-06-15 02:48:18'),
(312, 10, 62, 315, 0, '', '0000-00-00', '', '2014-06-15 02:48:18'),
(313, 10, 63, 316, 0, '', '0000-00-00', '', '2014-06-15 02:48:36'),
(314, 10, 63, 317, 0, '', '0000-00-00', '', '2014-06-15 02:48:36'),
(315, 10, 63, 318, 0, '', '0000-00-00', '', '2014-06-15 02:48:36'),
(316, 10, 63, 319, 0, '', '0000-00-00', '', '2014-06-15 02:48:36'),
(317, 10, 63, 320, 0, '', '0000-00-00', '', '2014-06-15 02:48:36'),
(318, 10, 63, 321, 0, '', '0000-00-00', '', '2014-06-15 02:48:36'),
(319, 10, 63, 322, 0, '', '0000-00-00', '', '2014-06-15 02:48:36'),
(320, 10, 63, 323, 0, '', '0000-00-00', '', '2014-06-15 02:48:36'),
(321, 3, 69, 324, 0, '', '0000-00-00', '', '2014-06-15 05:48:53'),
(322, 3, 69, 325, 0, '', '0000-00-00', '', '2014-06-15 05:48:53'),
(323, 3, 69, 326, 0, '', '0000-00-00', '', '2014-06-15 05:48:53'),
(324, 3, 69, 327, 0, '', '0000-00-00', '', '2014-06-15 05:48:53'),
(325, 3, 69, 328, 0, '', '0000-00-00', '', '2014-06-15 05:48:53'),
(326, 3, 69, 329, 0, '', '0000-00-00', '', '2014-06-15 05:48:53'),
(327, 3, 69, 330, 0, '', '0000-00-00', '', '2014-06-15 05:48:53'),
(328, 3, 69, 331, 0, '', '0000-00-00', '', '2014-06-15 05:48:53'),
(329, 3, 69, 332, 0, '', '0000-00-00', '', '2014-06-15 05:48:53'),
(330, 3, 69, 333, 0, '', '0000-00-00', '', '2014-06-15 05:48:53'),
(331, 4, 69, 334, 0, '', '0000-00-00', '', '2014-06-15 06:01:10'),
(332, 4, 69, 335, 0, '', '0000-00-00', '', '2014-06-15 06:01:10'),
(333, 4, 69, 336, 0, '', '0000-00-00', '', '2014-06-15 06:01:10'),
(334, 4, 69, 337, 0, '', '0000-00-00', '', '2014-06-15 06:01:10'),
(335, 4, 69, 338, 0, '', '0000-00-00', '', '2014-06-15 06:01:10'),
(336, 4, 69, 339, 0, '', '0000-00-00', '', '2014-06-15 06:01:10'),
(337, 4, 69, 340, 0, '', '0000-00-00', '', '2014-06-15 06:01:10'),
(338, 4, 69, 341, 0, '', '0000-00-00', '', '2014-06-15 06:01:10'),
(339, 4, 69, 342, 0, '', '0000-00-00', '', '2014-06-15 06:01:10'),
(340, 4, 69, 343, 0, '', '0000-00-00', '', '2014-06-15 06:01:10'),
(341, 5, 69, 344, 0, '', '0000-00-00', '', '2014-06-15 06:09:38'),
(342, 5, 69, 345, 0, '', '0000-00-00', '', '2014-06-15 06:09:38'),
(343, 5, 69, 346, 0, '', '0000-00-00', '', '2014-06-15 06:09:38'),
(344, 5, 69, 347, 0, '', '0000-00-00', '', '2014-06-15 06:09:38'),
(345, 5, 69, 348, 0, '', '0000-00-00', '', '2014-06-15 06:09:38'),
(346, 5, 69, 349, 0, '', '0000-00-00', '', '2014-06-15 06:09:38'),
(347, 5, 69, 350, 0, '', '0000-00-00', '', '2014-06-15 06:09:38'),
(348, 5, 69, 351, 0, '', '0000-00-00', '', '2014-06-15 06:09:38'),
(349, 5, 69, 352, 0, '', '0000-00-00', '', '2014-06-15 06:09:38'),
(350, 5, 69, 353, 0, '', '0000-00-00', '', '2014-06-15 06:09:38'),
(351, 6, 69, 354, 0, '', '0000-00-00', '', '2014-06-15 06:17:42'),
(352, 6, 69, 355, 0, '', '0000-00-00', '', '2014-06-15 06:17:42'),
(353, 6, 69, 356, 0, '', '0000-00-00', '', '2014-06-15 06:17:42'),
(354, 6, 69, 357, 0, '', '0000-00-00', '', '2014-06-15 06:17:42'),
(355, 6, 69, 358, 0, '', '0000-00-00', '', '2014-06-15 06:17:42'),
(356, 6, 69, 359, 0, '', '0000-00-00', '', '2014-06-15 06:17:42'),
(357, 6, 69, 360, 0, '', '0000-00-00', '', '2014-06-15 06:17:42'),
(358, 6, 69, 361, 0, '', '0000-00-00', '', '2014-06-15 06:17:42'),
(359, 6, 69, 362, 0, '', '0000-00-00', '', '2014-06-15 06:17:42'),
(360, 6, 69, 363, 0, '', '0000-00-00', '', '2014-06-15 06:17:42'),
(361, 7, 69, 364, 0, '', '0000-00-00', '', '2014-06-15 06:28:53'),
(362, 7, 69, 365, 0, '', '0000-00-00', '', '2014-06-15 06:28:53'),
(363, 7, 69, 366, 0, '', '0000-00-00', '', '2014-06-15 06:28:53'),
(364, 7, 69, 367, 0, '', '0000-00-00', '', '2014-06-15 06:28:53'),
(365, 7, 69, 368, 0, '', '0000-00-00', '', '2014-06-15 06:28:53'),
(366, 7, 69, 369, 0, '', '0000-00-00', '', '2014-06-15 06:28:53'),
(367, 7, 69, 370, 0, '', '0000-00-00', '', '2014-06-15 06:28:53'),
(368, 7, 69, 371, 0, '', '0000-00-00', '', '2014-06-15 06:28:53'),
(369, 7, 69, 372, 0, '', '0000-00-00', '', '2014-06-15 06:28:53'),
(370, 7, 69, 373, 0, '', '0000-00-00', '', '2014-06-15 06:28:53'),
(371, 8, 69, 374, 0, '', '0000-00-00', '', '2014-06-15 06:34:56'),
(372, 8, 69, 375, 0, '', '0000-00-00', '', '2014-06-15 06:34:56'),
(373, 8, 69, 376, 0, '', '0000-00-00', '', '2014-06-15 06:34:56'),
(374, 8, 69, 377, 0, '', '0000-00-00', '', '2014-06-15 06:34:56'),
(375, 8, 69, 378, 0, '', '0000-00-00', '', '2014-06-15 06:34:56'),
(376, 8, 69, 379, 0, '', '0000-00-00', '', '2014-06-15 06:34:56'),
(377, 8, 69, 380, 0, '', '0000-00-00', '', '2014-06-15 06:34:56'),
(378, 8, 69, 381, 0, '', '0000-00-00', '', '2014-06-15 06:34:56'),
(379, 8, 69, 382, 0, '', '0000-00-00', '', '2014-06-15 06:34:56'),
(380, 8, 69, 383, 0, '', '0000-00-00', '', '2014-06-15 06:34:56'),
(381, 9, 69, 384, 0, '', '0000-00-00', '', '2014-06-15 06:55:14'),
(382, 9, 69, 385, 0, '', '0000-00-00', '', '2014-06-15 06:55:14'),
(383, 9, 69, 386, 0, '', '0000-00-00', '', '2014-06-15 06:55:14'),
(384, 9, 69, 387, 0, '', '0000-00-00', '', '2014-06-15 06:55:14'),
(385, 9, 69, 388, 0, '', '0000-00-00', '', '2014-06-15 06:55:14'),
(386, 9, 69, 389, 0, '', '0000-00-00', '', '2014-06-15 06:55:14'),
(387, 9, 69, 390, 0, '', '0000-00-00', '', '2014-06-15 06:55:14'),
(388, 9, 69, 391, 0, '', '0000-00-00', '', '2014-06-15 06:55:14'),
(389, 9, 69, 392, 0, '', '0000-00-00', '', '2014-06-15 06:55:14'),
(390, 9, 69, 393, 0, '', '0000-00-00', '', '2014-06-15 06:55:14'),
(391, 10, 69, 394, 0, '', '0000-00-00', '', '2014-06-15 07:16:15'),
(392, 10, 69, 395, 0, '', '0000-00-00', '', '2014-06-15 07:16:15'),
(393, 10, 69, 396, 0, '', '0000-00-00', '', '2014-06-15 07:16:15'),
(394, 10, 69, 397, 0, '', '0000-00-00', '', '2014-06-15 07:16:15'),
(395, 10, 69, 398, 0, '', '0000-00-00', '', '2014-06-15 07:16:15'),
(396, 10, 69, 399, 0, '', '0000-00-00', '', '2014-06-15 07:16:15'),
(397, 10, 69, 400, 0, '', '0000-00-00', '', '2014-06-15 07:16:15'),
(398, 10, 69, 401, 0, '', '0000-00-00', '', '2014-06-15 07:16:15'),
(399, 10, 69, 402, 0, '', '0000-00-00', '', '2014-06-15 07:16:15'),
(400, 10, 69, 403, 0, '', '0000-00-00', '', '2014-06-15 07:16:15'),
(401, 3, 70, 404, 0, '', '0000-00-00', '', '2014-06-18 02:07:25'),
(402, 3, 70, 405, 0, '', '0000-00-00', '', '2014-06-18 02:07:25'),
(403, 3, 70, 406, 0, '', '0000-00-00', '', '2014-06-18 02:07:25'),
(404, 3, 70, 407, 0, '', '0000-00-00', '', '2014-06-18 02:07:25'),
(405, 3, 70, 408, 0, '', '0000-00-00', '', '2014-06-18 02:07:25'),
(406, 3, 70, 409, 0, '', '0000-00-00', '', '2014-06-18 02:07:25'),
(407, 3, 70, 410, 0, '', '0000-00-00', '', '2014-06-18 02:07:25'),
(408, 3, 70, 411, 0, '', '0000-00-00', '', '2014-06-18 02:07:25'),
(409, 3, 70, 412, 0, '', '0000-00-00', '', '2014-06-18 02:07:25'),
(410, 3, 70, 413, 0, '', '0000-00-00', '', '2014-06-18 02:07:25'),
(411, 4, 70, 404, 0, '', '0000-00-00', '', '2014-06-18 02:07:33'),
(412, 4, 70, 405, 0, '', '0000-00-00', '', '2014-06-18 02:07:33'),
(413, 4, 70, 406, 0, '', '0000-00-00', '', '2014-06-18 02:07:33'),
(414, 4, 70, 407, 0, '', '0000-00-00', '', '2014-06-18 02:07:33'),
(415, 4, 70, 408, 0, '', '0000-00-00', '', '2014-06-18 02:07:33'),
(416, 4, 70, 409, 0, '', '0000-00-00', '', '2014-06-18 02:07:33'),
(417, 4, 70, 410, 0, '', '0000-00-00', '', '2014-06-18 02:07:33'),
(418, 4, 70, 411, 0, '', '0000-00-00', '', '2014-06-18 02:07:33'),
(419, 4, 70, 412, 0, '', '0000-00-00', '', '2014-06-18 02:07:33'),
(420, 4, 70, 413, 0, '', '0000-00-00', '', '2014-06-18 02:07:33'),
(421, 5, 70, 404, 0, '', '0000-00-00', '', '2014-06-18 02:07:42'),
(422, 5, 70, 405, 0, '', '0000-00-00', '', '2014-06-18 02:07:42'),
(423, 5, 70, 406, 0, '', '0000-00-00', '', '2014-06-18 02:07:42'),
(424, 5, 70, 407, 0, '', '0000-00-00', '', '2014-06-18 02:07:42'),
(425, 5, 70, 408, 0, '', '0000-00-00', '', '2014-06-18 02:07:42'),
(426, 5, 70, 409, 0, '', '0000-00-00', '', '2014-06-18 02:07:42'),
(427, 5, 70, 410, 0, '', '0000-00-00', '', '2014-06-18 02:07:42'),
(428, 5, 70, 411, 0, '', '0000-00-00', '', '2014-06-18 02:07:42'),
(429, 5, 70, 412, 0, '', '0000-00-00', '', '2014-06-18 02:07:42'),
(430, 5, 70, 413, 0, '', '0000-00-00', '', '2014-06-18 02:07:42'),
(431, 6, 70, 404, 0, '', '0000-00-00', '', '2014-06-18 02:07:52'),
(432, 6, 70, 405, 0, '', '0000-00-00', '', '2014-06-18 02:07:52'),
(433, 6, 70, 406, 0, '', '0000-00-00', '', '2014-06-18 02:07:52'),
(434, 6, 70, 407, 0, '', '0000-00-00', '', '2014-06-18 02:07:52'),
(435, 6, 70, 408, 0, '', '0000-00-00', '', '2014-06-18 02:07:52'),
(436, 6, 70, 409, 0, '', '0000-00-00', '', '2014-06-18 02:07:52'),
(437, 6, 70, 410, 0, '', '0000-00-00', '', '2014-06-18 02:07:52'),
(438, 6, 70, 411, 0, '', '0000-00-00', '', '2014-06-18 02:07:52'),
(439, 6, 70, 412, 0, '', '0000-00-00', '', '2014-06-18 02:07:52'),
(440, 6, 70, 413, 0, '', '0000-00-00', '', '2014-06-18 02:07:52'),
(441, 7, 70, 404, 0, '', '0000-00-00', '', '2014-06-18 02:08:00'),
(442, 7, 70, 405, 0, '', '0000-00-00', '', '2014-06-18 02:08:00'),
(443, 7, 70, 406, 0, '', '0000-00-00', '', '2014-06-18 02:08:00'),
(444, 7, 70, 407, 0, '', '0000-00-00', '', '2014-06-18 02:08:00'),
(445, 7, 70, 408, 0, '', '0000-00-00', '', '2014-06-18 02:08:00'),
(446, 7, 70, 409, 0, '', '0000-00-00', '', '2014-06-18 02:08:00'),
(447, 7, 70, 410, 0, '', '0000-00-00', '', '2014-06-18 02:08:00'),
(448, 7, 70, 411, 0, '', '0000-00-00', '', '2014-06-18 02:08:00'),
(449, 7, 70, 412, 0, '', '0000-00-00', '', '2014-06-18 02:08:00'),
(450, 7, 70, 413, 0, '', '0000-00-00', '', '2014-06-18 02:08:00'),
(451, 8, 70, 404, 0, '', '0000-00-00', '', '2014-06-18 02:08:39'),
(452, 8, 70, 405, 0, '', '0000-00-00', '', '2014-06-18 02:08:39'),
(453, 8, 70, 406, 0, '', '0000-00-00', '', '2014-06-18 02:08:39'),
(454, 8, 70, 407, 0, '', '0000-00-00', '', '2014-06-18 02:08:39'),
(455, 8, 70, 408, 0, '', '0000-00-00', '', '2014-06-18 02:08:39'),
(456, 8, 70, 409, 0, '', '0000-00-00', '', '2014-06-18 02:08:39'),
(457, 8, 70, 410, 0, '', '0000-00-00', '', '2014-06-18 02:08:39'),
(458, 8, 70, 411, 0, '', '0000-00-00', '', '2014-06-18 02:08:39'),
(459, 8, 70, 412, 0, '', '0000-00-00', '', '2014-06-18 02:08:39'),
(460, 8, 70, 413, 0, '', '0000-00-00', '', '2014-06-18 02:08:39'),
(461, 9, 70, 404, 0, '', '0000-00-00', '', '2014-06-18 02:08:53'),
(462, 9, 70, 405, 0, '', '0000-00-00', '', '2014-06-18 02:08:53'),
(463, 9, 70, 406, 0, '', '0000-00-00', '', '2014-06-18 02:08:53'),
(464, 9, 70, 407, 0, '', '0000-00-00', '', '2014-06-18 02:08:53'),
(465, 9, 70, 408, 0, '', '0000-00-00', '', '2014-06-18 02:08:53'),
(466, 9, 70, 409, 0, '', '0000-00-00', '', '2014-06-18 02:08:53'),
(467, 9, 70, 410, 0, '', '0000-00-00', '', '2014-06-18 02:08:53'),
(468, 9, 70, 411, 0, '', '0000-00-00', '', '2014-06-18 02:08:53'),
(469, 9, 70, 412, 0, '', '0000-00-00', '', '2014-06-18 02:08:53'),
(470, 9, 70, 413, 0, '', '0000-00-00', '', '2014-06-18 02:08:53'),
(471, 10, 70, 404, 0, '', '0000-00-00', '', '2014-06-18 02:09:01'),
(472, 10, 70, 405, 0, '', '0000-00-00', '', '2014-06-18 02:09:01'),
(473, 10, 70, 406, 0, '', '0000-00-00', '', '2014-06-18 02:09:01'),
(474, 10, 70, 407, 0, '', '0000-00-00', '', '2014-06-18 02:09:01'),
(475, 10, 70, 408, 0, '', '0000-00-00', '', '2014-06-18 02:09:01'),
(476, 10, 70, 409, 0, '', '0000-00-00', '', '2014-06-18 02:09:01'),
(477, 10, 70, 410, 0, '', '0000-00-00', '', '2014-06-18 02:09:01'),
(478, 10, 70, 411, 0, '', '0000-00-00', '', '2014-06-18 02:09:01'),
(479, 10, 70, 412, 0, '', '0000-00-00', '', '2014-06-18 02:09:01'),
(480, 10, 70, 413, 0, '', '0000-00-00', '', '2014-06-18 02:09:01'),
(481, 1, 59, 414, 0, '', '0000-00-00', '', '2014-06-23 16:29:11'),
(482, 1, 59, 415, 0, '', '0000-00-00', '', '2014-06-23 16:29:11'),
(483, 1, 59, 416, 0, '', '0000-00-00', '', '2014-06-23 16:29:11'),
(484, 1, 59, 417, 0, '', '0000-00-00', '', '2014-06-23 16:29:11'),
(485, 1, 59, 418, 0, '', '0000-00-00', '', '2014-06-23 16:29:11'),
(486, 1, 59, 419, 0, '', '0000-00-00', '', '2014-06-23 16:29:11'),
(487, 1, 59, 420, 0, '', '0000-00-00', '', '2014-06-23 16:29:11'),
(488, 1, 59, 421, 0, '', '0000-00-00', '', '2014-06-23 16:29:11'),
(489, 1, 60, 422, 0, '', '0000-00-00', '', '2014-06-23 16:29:26'),
(490, 1, 60, 423, 0, '', '0000-00-00', '', '2014-06-23 16:29:26'),
(491, 1, 60, 424, 0, '', '0000-00-00', '', '2014-06-23 16:29:26'),
(492, 1, 60, 425, 0, '', '0000-00-00', '', '2014-06-23 16:29:26'),
(493, 1, 60, 426, 0, '', '0000-00-00', '', '2014-06-23 16:29:26'),
(494, 1, 60, 427, 0, '', '0000-00-00', '', '2014-06-23 16:29:26'),
(495, 1, 60, 428, 0, '', '0000-00-00', '', '2014-06-23 16:29:26'),
(496, 1, 60, 429, 0, '', '0000-00-00', '', '2014-06-23 16:29:26'),
(497, 1, 61, 430, 0, '', '0000-00-00', '', '2014-06-23 16:51:13'),
(498, 1, 61, 431, 0, '', '0000-00-00', '', '2014-06-23 16:51:14'),
(499, 1, 61, 432, 0, '', '0000-00-00', '', '2014-06-23 16:51:14'),
(500, 1, 61, 433, 0, '', '0000-00-00', '', '2014-06-23 16:51:14'),
(501, 1, 61, 434, 0, '', '0000-00-00', '', '2014-06-23 16:51:14'),
(502, 1, 61, 435, 0, '', '0000-00-00', '', '2014-06-23 16:51:14'),
(503, 1, 61, 436, 0, '', '0000-00-00', '', '2014-06-23 16:51:14'),
(504, 1, 61, 437, 0, '', '0000-00-00', '', '2014-06-23 16:51:14'),
(505, 1, 62, 438, 0, '', '0000-00-00', '', '2014-06-23 16:51:31'),
(506, 1, 62, 439, 0, '', '0000-00-00', '', '2014-06-23 16:51:31'),
(507, 1, 62, 440, 0, '', '0000-00-00', '', '2014-06-23 16:51:31'),
(508, 1, 62, 441, 0, '', '0000-00-00', '', '2014-06-23 16:51:31'),
(509, 1, 62, 442, 0, '', '0000-00-00', '', '2014-06-23 16:51:31'),
(510, 1, 62, 443, 0, '', '0000-00-00', '', '2014-06-23 16:51:31'),
(511, 1, 62, 444, 0, '', '0000-00-00', '', '2014-06-23 16:51:31'),
(512, 1, 62, 445, 0, '', '0000-00-00', '', '2014-06-23 16:51:31'),
(513, 1, 63, 446, 0, '', '0000-00-00', '', '2014-06-23 16:51:43'),
(514, 1, 63, 447, 0, '', '0000-00-00', '', '2014-06-23 16:51:43'),
(515, 1, 63, 448, 0, '', '0000-00-00', '', '2014-06-23 16:51:43'),
(516, 1, 63, 449, 0, '', '0000-00-00', '', '2014-06-23 16:51:43'),
(517, 1, 63, 450, 0, '', '0000-00-00', '', '2014-06-23 16:51:43'),
(518, 1, 63, 451, 0, '', '0000-00-00', '', '2014-06-23 16:51:43'),
(519, 1, 63, 452, 0, '', '0000-00-00', '', '2014-06-23 16:51:43'),
(520, 1, 63, 453, 0, '', '0000-00-00', '', '2014-06-23 16:51:43'),
(521, 1, 70, 404, 0, '', '0000-00-00', '', '2014-06-23 16:51:52'),
(522, 1, 70, 405, 0, '', '0000-00-00', '', '2014-06-23 16:51:52'),
(523, 1, 70, 406, 0, '', '0000-00-00', '', '2014-06-23 16:51:52'),
(524, 1, 70, 407, 0, '', '0000-00-00', '', '2014-06-23 16:51:52'),
(525, 1, 70, 408, 0, '', '0000-00-00', '', '2014-06-23 16:51:52'),
(526, 1, 70, 409, 0, '', '0000-00-00', '', '2014-06-23 16:51:52'),
(527, 1, 70, 410, 0, '', '0000-00-00', '', '2014-06-23 16:51:52'),
(528, 1, 70, 411, 0, '', '0000-00-00', '', '2014-06-23 16:51:52'),
(529, 1, 70, 412, 0, '', '0000-00-00', '', '2014-06-23 16:51:52'),
(530, 1, 70, 413, 0, '', '0000-00-00', '', '2014-06-23 16:51:52'),
(531, 1, 69, 454, 0, '', '0000-00-00', '', '2014-06-23 17:12:31'),
(532, 1, 69, 455, 0, '', '0000-00-00', '', '2014-06-23 17:12:32'),
(533, 1, 69, 456, 0, '', '0000-00-00', '', '2014-06-23 17:12:32'),
(534, 1, 69, 457, 0, '', '0000-00-00', '', '2014-06-23 17:12:32'),
(535, 1, 69, 458, 0, '', '0000-00-00', '', '2014-06-23 17:12:32'),
(536, 1, 69, 459, 0, '', '0000-00-00', '', '2014-06-23 17:12:32'),
(537, 1, 69, 460, 0, '', '0000-00-00', '', '2014-06-23 17:12:32'),
(538, 1, 69, 461, 0, '', '0000-00-00', '', '2014-06-23 17:12:32'),
(539, 1, 69, 462, 0, '', '0000-00-00', '', '2014-06-23 17:12:32'),
(540, 1, 69, 463, 0, '', '0000-00-00', '', '2014-06-23 17:12:32'),
(541, 2, 59, 464, 0, '', '0000-00-00', '', '2014-06-23 17:36:36'),
(542, 2, 59, 465, 0, '', '0000-00-00', '', '2014-06-23 17:36:37'),
(543, 2, 59, 466, 0, '', '0000-00-00', '', '2014-06-23 17:36:37'),
(544, 2, 59, 467, 0, '', '0000-00-00', '', '2014-06-23 17:36:37'),
(545, 2, 59, 468, 0, '', '0000-00-00', '', '2014-06-23 17:36:37'),
(546, 2, 59, 469, 0, '', '0000-00-00', '', '2014-06-23 17:36:37'),
(547, 2, 59, 470, 0, '', '0000-00-00', '', '2014-06-23 17:36:37'),
(548, 2, 59, 471, 0, '', '0000-00-00', '', '2014-06-23 17:36:37'),
(549, 2, 60, 472, 0, '', '0000-00-00', '', '2014-06-23 17:36:56'),
(550, 2, 60, 473, 0, '', '0000-00-00', '', '2014-06-23 17:36:56'),
(551, 2, 60, 474, 0, '', '0000-00-00', '', '2014-06-23 17:36:56'),
(552, 2, 60, 475, 0, '', '0000-00-00', '', '2014-06-23 17:36:56'),
(553, 2, 60, 476, 0, '', '0000-00-00', '', '2014-06-23 17:36:56'),
(554, 2, 60, 477, 0, '', '0000-00-00', '', '2014-06-23 17:36:56'),
(555, 2, 60, 478, 0, '', '0000-00-00', '', '2014-06-23 17:36:56'),
(556, 2, 60, 479, 0, '', '0000-00-00', '', '2014-06-23 17:36:56'),
(557, 2, 61, 480, 0, '', '0000-00-00', '', '2014-06-23 17:38:49'),
(558, 2, 61, 481, 0, '', '0000-00-00', '', '2014-06-23 17:38:49'),
(559, 2, 61, 482, 0, '', '0000-00-00', '', '2014-06-23 17:38:49'),
(560, 2, 61, 483, 0, '', '0000-00-00', '', '2014-06-23 17:38:49'),
(561, 2, 61, 484, 0, '', '0000-00-00', '', '2014-06-23 17:38:49'),
(562, 2, 61, 485, 0, '', '0000-00-00', '', '2014-06-23 17:38:49'),
(563, 2, 61, 486, 0, '', '0000-00-00', '', '2014-06-23 17:38:49'),
(564, 2, 61, 487, 0, '', '0000-00-00', '', '2014-06-23 17:38:49'),
(565, 2, 62, 488, 0, '', '0000-00-00', '', '2014-06-23 17:39:00'),
(566, 2, 62, 489, 0, '', '0000-00-00', '', '2014-06-23 17:39:00'),
(567, 2, 62, 490, 0, '', '0000-00-00', '', '2014-06-23 17:39:00'),
(568, 2, 62, 491, 0, '', '0000-00-00', '', '2014-06-23 17:39:00'),
(569, 2, 62, 492, 0, '', '0000-00-00', '', '2014-06-23 17:39:00'),
(570, 2, 62, 493, 0, '', '0000-00-00', '', '2014-06-23 17:39:00'),
(571, 2, 62, 494, 0, '', '0000-00-00', '', '2014-06-23 17:39:00'),
(572, 2, 62, 495, 0, '', '0000-00-00', '', '2014-06-23 17:39:00'),
(581, 2, 63, 496, 0, '', '0000-00-00', '', '2014-06-23 17:53:37'),
(582, 2, 63, 497, 0, '', '0000-00-00', '', '2014-06-23 17:53:37'),
(583, 2, 63, 498, 0, '', '0000-00-00', '', '2014-06-23 17:53:37'),
(584, 2, 63, 499, 0, '', '0000-00-00', '', '2014-06-23 17:53:37'),
(585, 2, 63, 500, 0, '', '0000-00-00', '', '2014-06-23 17:53:37'),
(586, 2, 63, 501, 0, '', '0000-00-00', '', '2014-06-23 17:53:37'),
(587, 2, 63, 502, 0, '', '0000-00-00', '', '2014-06-23 17:53:37'),
(588, 2, 63, 503, 0, '', '0000-00-00', '', '2014-06-23 17:53:37'),
(589, 2, 69, 504, 0, '', '0000-00-00', '', '2014-06-23 18:00:25'),
(590, 2, 69, 505, 0, '', '0000-00-00', '', '2014-06-23 18:00:25'),
(591, 2, 69, 506, 0, '', '0000-00-00', '', '2014-06-23 18:00:25'),
(592, 2, 69, 507, 0, '', '0000-00-00', '', '2014-06-23 18:00:25'),
(593, 2, 69, 508, 0, '', '0000-00-00', '', '2014-06-23 18:00:25'),
(594, 2, 69, 509, 0, '', '0000-00-00', '', '2014-06-23 18:00:25'),
(595, 2, 69, 510, 0, '', '0000-00-00', '', '2014-06-23 18:00:25'),
(596, 2, 69, 511, 0, '', '0000-00-00', '', '2014-06-23 18:00:25'),
(597, 2, 69, 512, 0, '', '0000-00-00', '', '2014-06-23 18:00:25'),
(598, 2, 69, 513, 0, '', '0000-00-00', '', '2014-06-23 18:00:25'),
(599, 2, 70, 404, 0, '', '0000-00-00', '', '2014-06-23 18:00:34'),
(600, 2, 70, 405, 0, '', '0000-00-00', '', '2014-06-23 18:00:34'),
(601, 2, 70, 406, 0, '', '0000-00-00', '', '2014-06-23 18:00:34'),
(602, 2, 70, 407, 0, '', '0000-00-00', '', '2014-06-23 18:00:34'),
(603, 2, 70, 408, 0, '', '0000-00-00', '', '2014-06-23 18:00:34'),
(604, 2, 70, 409, 0, '', '0000-00-00', '', '2014-06-23 18:00:34'),
(605, 2, 70, 410, 0, '', '0000-00-00', '', '2014-06-23 18:00:34'),
(606, 2, 70, 411, 0, '', '0000-00-00', '', '2014-06-23 18:00:34'),
(607, 2, 70, 412, 0, '', '0000-00-00', '', '2014-06-23 18:00:34'),
(608, 2, 70, 413, 0, '', '0000-00-00', '', '2014-06-23 18:00:34'),
(609, 3, 59, 514, 0, '', '0000-00-00', '', '2014-06-23 18:00:34'),
(610, 11, 59, 521, 0, '', '2017-09-25', '', '2017-12-10 04:09:50'),
(611, 11, 59, 522, 0, '', '2017-09-25', '', '2017-12-10 04:09:50'),
(612, 11, 59, 523, 0, '', '2017-09-25', '', '2017-12-10 04:09:50'),
(613, 11, 59, 524, 0, '', '2017-09-25', '', '2017-12-10 04:09:50'),
(614, 11, 59, 525, 0, '', '2017-09-25', '', '2017-12-10 04:09:50'),
(615, 11, 59, 526, 0, '', '2017-09-25', '', '2017-12-10 04:09:50'),
(616, 11, 59, 527, 0, '', '2017-09-25', '', '2017-12-10 04:09:50'),
(617, 11, 59, 528, 0, '', '2017-09-25', '', '2017-12-10 04:09:50'),
(618, 11, 60, 529, 0, '', '2017-09-25', '', '2017-12-10 04:09:50'),
(619, 11, 60, 530, 0, '', '2017-09-25', '', '2017-12-10 04:09:50'),
(620, 11, 60, 531, 0, '', '2017-09-25', '', '2017-12-10 04:09:50'),
(621, 11, 60, 532, 0, '', '2017-09-25', '', '2017-12-10 04:09:50'),
(622, 11, 60, 533, 0, '', '2017-09-25', '', '2017-12-10 04:09:50'),
(623, 11, 60, 534, 0, '', '2017-09-25', '', '2017-12-10 04:09:50'),
(624, 11, 60, 535, 0, '', '2017-09-25', '', '2017-12-10 04:09:50'),
(625, 11, 60, 536, 0, '', '2017-09-25', '', '2017-12-10 04:09:50'),
(626, 11, 61, 537, 0, '', '2017-09-25', '', '2017-12-10 04:09:50'),
(627, 11, 61, 538, 0, '', '2017-09-25', '', '2017-12-10 04:09:50'),
(628, 11, 61, 539, 0, '', '2017-09-25', '', '2017-12-10 04:09:50'),
(629, 11, 61, 540, 0, '', '2017-09-25', '', '2017-12-10 04:09:50'),
(630, 11, 61, 541, 0, '', '2017-09-25', '', '2017-12-10 04:09:50'),
(631, 11, 61, 542, 0, '', '2017-09-25', '', '2017-12-10 04:09:50'),
(632, 11, 61, 543, 0, '', '2017-09-25', '', '2017-12-10 04:09:50'),
(633, 11, 61, 544, 0, '', '2017-09-25', '', '2017-12-10 04:09:50'),
(634, 11, 62, 545, 0, '', '2017-09-25', '', '2017-12-10 04:09:50'),
(635, 11, 62, 546, 0, '', '2017-09-25', '', '2017-12-10 04:09:50'),
(636, 11, 62, 547, 0, '', '2017-09-25', '', '2017-12-10 04:09:50'),
(637, 11, 62, 548, 0, '', '2017-09-25', '', '2017-12-10 04:09:50'),
(638, 11, 62, 549, 0, '', '2017-09-25', '', '2017-12-10 04:09:50'),
(639, 11, 62, 550, 0, '', '2017-09-25', '', '2017-12-10 04:09:50'),
(640, 11, 62, 551, 0, '', '2017-09-25', '', '2017-12-10 04:09:50'),
(641, 11, 62, 552, 0, '', '2017-09-25', '', '2017-12-10 04:09:50'),
(642, 11, 63, 553, 0, '', '2017-09-25', '', '2017-12-10 04:09:50'),
(643, 11, 63, 554, 0, '', '2017-09-25', '', '2017-12-10 04:09:50'),
(644, 11, 63, 555, 0, '', '2017-09-25', '', '2017-12-10 04:09:50'),
(645, 11, 63, 556, 0, '', '2017-09-25', '', '2017-12-10 04:09:50'),
(646, 11, 63, 557, 0, '', '2017-09-25', '', '2017-12-10 04:09:50'),
(647, 11, 63, 558, 0, '', '2017-09-25', '', '2017-12-10 04:09:50'),
(648, 11, 63, 559, 0, '', '2017-09-25', '', '2017-12-10 04:09:50'),
(649, 11, 63, 560, 0, '', '2017-09-25', '', '2017-12-10 04:09:50'),
(650, 1, 59, 561, 0, '', '2017-09-25', '', '2017-12-10 04:09:50'),
(651, 1, 59, 562, 0, '', '2017-09-25', '', '2017-12-10 04:09:50'),
(652, 1, 59, 563, 0, '', '2017-09-25', '', '2017-12-10 04:09:50'),
(653, 1, 59, 564, 0, '', '2017-09-25', '', '2017-12-10 04:09:50'),
(654, 1, 59, 565, 0, '', '2017-09-25', '', '2017-12-10 04:09:50'),
(655, 1, 59, 566, 0, '', '2017-09-25', '', '2017-12-10 04:09:50'),
(656, 1, 59, 567, 0, '', '2017-09-25', '', '2017-12-10 04:09:50'),
(657, 1, 59, 568, 0, '', '2017-09-25', '', '2017-12-10 04:09:50'),
(658, 1, 60, 569, 0, '', '2017-09-25', '', '2017-12-10 04:09:50'),
(659, 1, 60, 570, 0, '', '2017-09-25', '', '2017-12-10 04:09:50'),
(660, 1, 60, 571, 0, '', '2017-09-25', '', '2017-12-10 04:09:50'),
(661, 1, 60, 572, 0, '', '2017-09-25', '', '2017-12-10 04:09:50'),
(662, 1, 60, 573, 0, '', '2017-09-25', '', '2017-12-10 04:09:50'),
(663, 1, 60, 574, 0, '', '2017-09-25', '', '2017-12-10 04:09:50'),
(664, 1, 60, 575, 0, '', '2017-09-25', '', '2017-12-10 04:09:50'),
(665, 1, 60, 576, 0, '', '2017-09-25', '', '2017-12-10 04:09:50'),
(666, 1, 61, 577, 0, '', '2017-09-25', '', '2017-12-10 04:09:50'),
(667, 1, 61, 578, 0, '', '2017-09-25', '', '2017-12-10 04:09:50'),
(668, 1, 61, 579, 0, '', '2017-09-25', '', '2017-12-10 04:09:50'),
(669, 1, 61, 580, 0, '', '2017-09-25', '', '2017-12-10 04:09:50'),
(670, 1, 61, 581, 0, '', '2017-09-25', '', '2017-12-10 04:09:50'),
(671, 1, 61, 582, 0, '', '2017-09-25', '', '2017-12-10 04:09:50'),
(672, 1, 61, 583, 0, '', '2017-09-25', '', '2017-12-10 04:09:50'),
(673, 1, 61, 584, 0, '', '2017-09-25', '', '2017-12-10 04:09:50'),
(674, 1, 62, 585, 0, '', '2017-09-25', '', '2017-12-10 04:09:50'),
(675, 1, 62, 586, 0, '', '2017-09-25', '', '2017-12-10 04:09:50'),
(676, 1, 62, 587, 0, '', '2017-09-25', '', '2017-12-10 04:09:50'),
(677, 1, 62, 588, 0, '', '2017-09-25', '', '2017-12-10 04:09:50'),
(678, 1, 62, 589, 0, '', '2017-09-25', '', '2017-12-10 04:09:50'),
(679, 1, 62, 590, 0, '', '2017-09-25', '', '2017-12-10 04:09:50'),
(680, 1, 62, 591, 0, '', '2017-09-25', '', '2017-12-10 04:09:50'),
(681, 1, 62, 592, 0, '', '2017-09-25', '', '2017-12-10 04:09:50'),
(682, 1, 63, 593, 0, '', '2017-09-25', '', '2017-12-10 04:09:50'),
(683, 1, 63, 594, 0, '', '2017-09-25', '', '2017-12-10 04:09:50'),
(684, 1, 63, 595, 0, '', '2017-09-25', '', '2017-12-10 04:09:50'),
(685, 1, 63, 596, 0, '', '2017-09-25', '', '2017-12-10 04:09:50'),
(686, 1, 63, 597, 0, '', '2017-09-25', '', '2017-12-10 04:09:50'),
(687, 1, 63, 598, 0, '', '2017-09-25', '', '2017-12-10 04:09:50'),
(688, 1, 63, 599, 0, '', '2017-09-25', '', '2017-12-10 04:09:50'),
(689, 1, 63, 600, 0, '', '2017-09-25', '', '2017-12-10 04:09:50'),
(690, 2, 59, 601, 0, '', '2017-09-25', '', '2017-12-10 04:09:50'),
(691, 2, 59, 602, 0, '', '2017-09-25', '', '2017-12-10 04:09:50'),
(692, 2, 59, 603, 0, '', '2017-09-25', '', '2017-12-10 04:09:50'),
(693, 2, 59, 604, 0, '', '2017-09-25', '', '2017-12-10 04:09:50'),
(694, 2, 59, 605, 0, '', '2017-09-25', '', '2017-12-10 04:09:50'),
(695, 2, 59, 606, 0, '', '2017-09-25', '', '2017-12-10 04:09:50'),
(696, 2, 59, 607, 0, '', '2017-09-25', '', '2017-12-10 04:09:50'),
(697, 2, 59, 608, 0, '', '2017-09-25', '', '2017-12-10 04:09:50'),
(698, 2, 60, 609, 0, '', '2017-09-25', '', '2017-12-10 04:09:50'),
(699, 2, 60, 610, 0, '', '2017-09-25', '', '2017-12-10 04:09:50'),
(700, 2, 60, 611, 0, '', '2017-09-25', '', '2017-12-10 04:09:50'),
(701, 2, 60, 612, 0, '', '2017-09-25', '', '2017-12-10 04:09:50'),
(702, 2, 60, 613, 0, '', '2017-09-25', '', '2017-12-10 04:09:50'),
(703, 2, 60, 614, 0, '', '2017-09-25', '', '2017-12-10 04:09:50'),
(704, 2, 60, 615, 0, '', '2017-09-25', '', '2017-12-10 04:09:50'),
(705, 2, 60, 616, 0, '', '2017-09-25', '', '2017-12-10 04:09:50'),
(706, 2, 61, 617, 0, '', '2017-09-25', '', '2017-12-10 04:09:50'),
(707, 2, 61, 618, 0, '', '2017-09-25', '', '2017-12-10 04:09:50'),
(708, 2, 61, 619, 0, '', '2017-09-25', '', '2017-12-10 04:09:50'),
(709, 2, 61, 620, 0, '', '2017-09-25', '', '2017-12-10 04:09:50'),
(710, 2, 61, 621, 0, '', '2017-09-25', '', '2017-12-10 04:09:50'),
(711, 2, 61, 622, 0, '', '2017-09-25', '', '2017-12-10 04:09:50'),
(712, 2, 61, 623, 0, '', '2017-09-25', '', '2017-12-10 04:09:50'),
(713, 2, 61, 624, 0, '', '2017-09-25', '', '2017-12-10 04:09:50'),
(714, 2, 62, 625, 0, '', '2017-09-25', '', '2017-12-10 04:09:50'),
(715, 2, 62, 626, 0, '', '2017-09-25', '', '2017-12-10 04:09:50'),
(716, 2, 62, 627, 0, '', '2017-09-25', '', '2017-12-10 04:09:50'),
(717, 2, 62, 628, 0, '', '2017-09-25', '', '2017-12-10 04:09:50'),
(718, 2, 62, 629, 0, '', '2017-09-25', '', '2017-12-10 04:09:50'),
(719, 2, 62, 630, 0, '', '2017-09-25', '', '2017-12-10 04:09:50'),
(720, 2, 62, 631, 0, '', '2017-09-25', '', '2017-12-10 04:09:50'),
(721, 2, 62, 632, 0, '', '2017-09-25', '', '2017-12-10 04:09:50'),
(722, 2, 63, 633, 0, '', '2017-09-25', '', '2017-12-10 04:09:50'),
(723, 2, 63, 634, 0, '', '2017-09-25', '', '2017-12-10 04:09:50'),
(724, 2, 63, 635, 0, '', '2017-09-25', '', '2017-12-10 04:09:50'),
(725, 2, 63, 636, 0, '', '2017-09-25', '', '2017-12-10 04:09:50'),
(726, 2, 63, 637, 0, '', '2017-09-25', '', '2017-12-10 04:09:50'),
(727, 2, 63, 638, 0, '', '2017-09-25', '', '2017-12-10 04:09:50'),
(728, 2, 63, 639, 0, '', '2017-09-25', '', '2017-12-10 04:09:50'),
(729, 2, 63, 640, 0, '', '2017-09-25', '', '2017-12-10 04:09:50');

-- --------------------------------------------------------

--
-- Table structure for table `client_approved_license`
--

CREATE TABLE `client_approved_license` (
  `id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `noofcoupon` int(11) NOT NULL,
  `status` enum('Y','N') NOT NULL,
  `approved_by` int(11) NOT NULL,
  `approved_on` datetime NOT NULL,
  `created_on` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `client_approved_license`
--

INSERT INTO `client_approved_license` (`id`, `product_id`, `noofcoupon`, `status`, `approved_by`, `approved_on`, `created_on`) VALUES
(1, 1, 500, 'Y', 1, '2018-04-25 00:00:00', '2018-04-25 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `config_master`
--

CREATE TABLE `config_master` (
  `id` int(11) NOT NULL,
  `code` varchar(40) NOT NULL,
  `value` varchar(55) NOT NULL,
  `status` varchar(40) NOT NULL,
  `type` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `config_master`
--

INSERT INTO `config_master` (`id`, `code`, `value`, `status`, `type`) VALUES
(1, 'VALIDDAYS', '365', 'Y', 1),
(2, 'PRICE', '1', 'Y', 1),
(3, 'MAXTIMEOFPLAY', '1200', 'Y', 1);

-- --------------------------------------------------------

--
-- Table structure for table `couponmaster`
--

CREATE TABLE `couponmaster` (
  `id` int(11) NOT NULL,
  `organization_id` int(11) NOT NULL,
  `couponcode` varchar(55) NOT NULL,
  `coupon_prefix` varchar(55) NOT NULL,
  `valid_from` date NOT NULL,
  `valid_to` date NOT NULL,
  `coupon_valid_times` int(11) NOT NULL,
  `discount_percentage` varchar(55) NOT NULL,
  `coupon_used_times` int(11) NOT NULL,
  `status` int(11) NOT NULL COMMENT '0=> InActive, 1 => Active',
  `created_on` datetime NOT NULL,
  `modified_on` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `couponmaster`
--

INSERT INTO `couponmaster` (`id`, `organization_id`, `couponcode`, `coupon_prefix`, `valid_from`, `valid_to`, `coupon_valid_times`, `discount_percentage`, `coupon_used_times`, `status`, `created_on`, `modified_on`) VALUES
(1, 1, 'edsix001', 'ED', '2018-03-01', '2018-06-30', 10, '100', 10, 1, '2018-03-12 00:00:00', '0000-00-00 00:00:00'),
(2, 1, 'edsix002', 'ED', '2018-03-01', '2018-07-31', 20, '100', 19, 1, '2018-03-12 00:00:00', '0000-00-00 00:00:00'),
(3, 2, 'edsix003', 'ED', '2018-03-01', '2018-08-31', 10, '50', 0, 1, '2018-03-12 00:00:00', '0000-00-00 00:00:00'),
(4, 2, 'edsix004', 'RO', '2018-03-01', '2018-04-30', 10, '50', 1, 1, '2018-03-12 00:00:00', '0000-00-00 00:00:00'),
(5, 1, 'edsix005', 'ED', '2018-03-01', '2018-03-11', 0, '100', 23, 1, '2018-03-12 00:00:00', '0000-00-00 00:00:00'),
(6, 3, 'edsix007', 'ED', '2018-03-01', '2018-03-11', 0, '100', 0, 1, '2018-03-12 00:00:00', '0000-00-00 00:00:00'),
(7, 5, 'IC5U7DX4', 'IC', '2018-05-05', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(8, 5, 'ICN44STS', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(9, 5, 'ICR8C4XN', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(10, 5, 'ICV3VFUT', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(11, 5, 'IC9EXT89', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(12, 5, 'ICDFM3Q8', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(13, 5, 'ICG87N6J', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(14, 5, 'ICKUAVQM', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(15, 5, 'IC8DJ4MQ', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(16, 5, 'ICP5VQRK', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(17, 5, 'ICWKQBWQ', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(18, 5, 'IC6SMCXX', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(19, 5, 'ICDFG78D', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(20, 5, 'ICQPZEA6', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(21, 5, 'ICQ69EDV', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(22, 5, 'IC4X34F3', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(23, 5, 'ICVZRQKP', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(24, 5, 'ICFT29QQ', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(25, 5, 'IC3Z22XQ', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(26, 5, 'IC2PJXMK', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(27, 5, 'ICMB9APG', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(28, 5, 'ICVA7TKM', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(29, 5, 'IC7ZW2VW', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(30, 5, 'ICRUH6RJ', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(31, 5, 'ICGMVB6J', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(32, 5, 'ICWECSR9', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(33, 5, 'ICAA5DZT', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(34, 5, 'ICQMYFVB', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(35, 5, 'ICXWKDD2', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(36, 5, 'ICG4E7AP', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(37, 5, 'ICRU3Q93', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(38, 5, 'IC772YEC', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(39, 5, 'ICF9HH4F', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(40, 5, 'ICBUNUJZ', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(41, 5, 'ICHPSPAC', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(42, 5, 'ICXY5Z8F', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(43, 5, 'ICUEWJMG', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(44, 5, 'ICWAGXBN', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(45, 5, 'ICGHUQS9', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(46, 5, 'ICB7W8DQ', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(47, 5, 'IC9GH2BM', 'IC', '2018-05-07', '2018-06-30', 1, '100', 1, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(48, 5, 'ICMJP5Y8', 'IC', '2018-05-07', '2018-06-30', 1, '100', 1, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(49, 5, 'IC2QFJMP', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(50, 5, 'IC9AHXYE', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(51, 5, 'ICWAPMUE', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(52, 5, 'ICJWCJ3G', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(53, 5, 'ICW594RX', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(54, 5, 'ICS3VYU5', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(55, 5, 'ICSQSAZN', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(56, 5, 'ICCMB7BM', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(57, 5, 'IC6ZZXPM', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(58, 5, 'IC4GBZKU', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(59, 5, 'ICUU43YH', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(60, 5, 'ICJ9BGUG', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(61, 5, 'ICWJXA58', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(62, 5, 'ICN5YBZE', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(63, 5, 'ICS7SCNP', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(64, 5, 'ICPH9VFK', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(65, 5, 'ICAABBUM', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(66, 5, 'IC4PR6SQ', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(67, 5, 'ICQBQVP3', 'IC', '2018-05-07', '2018-06-30', 1, '100', 1, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(68, 5, 'ICTJPT2G', 'IC', '2018-05-07', '2018-06-30', 1, '100', 1, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(69, 5, 'ICWS7R6P', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(70, 5, 'ICMXMSXF', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(71, 5, 'ICBH8VZG', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(72, 5, 'ICETS3SH', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(73, 5, 'ICTVHWJA', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(74, 5, 'ICDMDTNC', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(75, 5, 'ICXRUBNX', 'IC', '2018-05-07', '2018-06-30', 1, '100', 1, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(76, 5, 'ICZA22NR', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(77, 5, 'IC3BYWRF', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(78, 5, 'IC3CYP5N', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(79, 5, 'ICQ3WXEV', 'IC', '2018-05-07', '2018-06-30', 1, '100', 1, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(80, 5, 'ICQVJAR5', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(81, 5, 'IC92QN39', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(82, 5, 'ICHKD4UG', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(83, 5, 'ICXGRMTK', 'IC', '2018-05-07', '2018-06-30', 1, '100', 1, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(84, 5, 'ICUYWWMG', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(85, 5, 'ICC2ZZTJ', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(86, 5, 'IC6GZ5F3', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(87, 5, 'IC6AE4P2', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(88, 5, 'ICCFR362', 'IC', '2018-05-07', '2018-06-30', 1, '100', 1, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(89, 5, 'ICTVPVDQ', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(90, 5, 'ICSZS8GM', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(91, 5, 'ICMEGME8', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(92, 5, 'ICGQKV9N', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(93, 5, 'ICB3R68P', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(94, 5, 'ICP93K6H', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(95, 5, 'ICJVF9KG', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(96, 5, 'IC67KS29', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(97, 5, 'ICPH32SY', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(98, 5, 'ICESVJGX', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(99, 5, 'ICC36YAU', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(100, 5, 'IC3TRR3C', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(101, 5, 'ICHBE8R2', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(102, 5, 'ICZMAHSM', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(103, 5, 'IC8PF84H', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(104, 5, 'IC3FC9US', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(105, 5, 'ICMF3YXB', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(106, 5, 'ICPRGQ66', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(107, 5, 'IC5ADTF5', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(108, 5, 'ICUHCPK7', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(109, 5, 'ICU7CWBG', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(110, 5, 'ICF6A4Z4', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(111, 5, 'IC3F7HS9', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(112, 5, 'ICRUFPK6', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(113, 5, 'IC8SSX7B', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(114, 5, 'IC32XFQM', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(115, 5, 'ICYT34ZN', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(116, 5, 'ICKU9KZB', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(117, 5, 'IC85PVP4', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(118, 5, 'IC4YZJK9', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(119, 5, 'ICJNCPY3', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(120, 5, 'ICW3CPD9', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(121, 5, 'IC7HZUFC', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(122, 5, 'ICAFCJDB', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(123, 5, 'IC5ZZB58', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(124, 5, 'ICMXECC8', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(125, 5, 'IC84XXQK', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(126, 5, 'ICCKKY9W', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(127, 5, 'IC2J3B29', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(128, 5, 'ICJEB558', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(129, 5, 'IC4CBVS2', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(130, 5, 'ICKWWPH6', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(131, 5, 'ICZGQUPG', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(132, 5, 'IC78RFNC', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(133, 5, 'ICXZR2YE', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(134, 5, 'IC67XXS7', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(135, 5, 'ICREUFPP', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(136, 5, 'ICP4XGXM', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(137, 5, 'ICWYZYBU', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(138, 5, 'ICT8NPME', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(139, 5, 'ICV9KVUM', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(140, 5, 'ICDM9D5E', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(141, 5, 'IC9NMC8Q', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(142, 5, 'ICP8RXZV', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(143, 5, 'ICJXCQNV', 'IC', '2018-05-07', '2018-06-30', 1, '100', 1, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(144, 5, 'IC2EWGTB', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(145, 5, 'ICA78S3U', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(146, 5, 'IC9FKPD6', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(147, 5, 'ICXRWB57', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(148, 5, 'ICXUMJCS', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(149, 5, 'ICRBRBRX', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(150, 5, 'ICQXMG2B', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(151, 5, 'ICGB2DGJ', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(152, 5, 'IC4VEAVZ', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(153, 5, 'IC5K89HB', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(154, 5, 'IC6J7G2H', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(155, 5, 'ICGKFWTC', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(156, 5, 'ICVVRQT8', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(157, 5, 'ICGWXH65', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(158, 5, 'IC7ZNHAE', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(159, 5, 'ICWPK7J9', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(160, 5, 'ICFR23UW', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(161, 5, 'ICKHRY38', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(162, 5, 'IC6NYG6T', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(163, 5, 'IC6FW6CE', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(164, 5, 'IC6NE7VZ', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(165, 5, 'IC7HQSZ5', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(166, 5, 'IC4JYJBA', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(167, 5, 'ICMK23FW', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(168, 5, 'ICHJ9PFN', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(169, 5, 'ICFU6MY3', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(170, 5, 'IC82HNQQ', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(171, 5, 'ICQMZESQ', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(172, 5, 'ICCHA46M', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(173, 5, 'ICD7CA8D', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(174, 5, 'ICAK8HJS', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(175, 5, 'ICWB5SBA', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(176, 5, 'ICYNTKRZ', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(177, 5, 'ICBWBMZ4', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(178, 5, 'ICX6ZZG5', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(179, 5, 'ICCH6JAA', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(180, 5, 'ICJNU2C2', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(181, 5, 'ICF5APN4', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(182, 5, 'ICHUP2GA', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(183, 5, 'ICMQZ67P', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(184, 5, 'ICJBVD3T', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(185, 5, 'IC74XC38', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(186, 5, 'ICC6HRMP', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(187, 5, 'IC5S8D7X', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(188, 5, 'IC6CE7T2', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(189, 5, 'ICV7ARB4', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(190, 5, 'ICF3Q4WK', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(191, 5, 'ICUZ7AV3', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(192, 5, 'ICP42KAT', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(193, 5, 'ICU4R5VY', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(194, 5, 'ICJBJS7F', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(195, 5, 'ICUJ9ZQG', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(196, 5, 'ICXZA8GM', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(197, 5, 'IC4N9M8T', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(198, 5, 'ICNKWJGR', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(199, 5, 'ICB9Y8KN', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(200, 5, 'ICC882XE', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(201, 5, 'IC73ECBX', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(202, 5, 'ICNEY5ZF', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(203, 5, 'ICP2YMBM', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(204, 5, 'ICG7QKN8', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(205, 5, 'ICQY3ZUG', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(206, 5, 'ICFUZTQK', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(207, 5, 'ICJQDT69', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(208, 5, 'ICZCRCJ5', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(209, 5, 'ICRSUQ24', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(210, 5, 'ICK8FEWR', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(211, 5, 'IC72R9KU', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(212, 5, 'IC74AEAK', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(213, 5, 'ICRCFTWB', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(214, 5, 'IC2PQH3X', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(215, 5, 'ICP7WM9Q', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(216, 5, 'ICDC5HN8', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(217, 5, 'IC55B4NG', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(218, 5, 'ICNP3ZZN', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(219, 5, 'ICS9QE6P', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(220, 5, 'ICU8X8K3', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(221, 5, 'ICMHUXZ9', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(222, 5, 'ICXR4J6G', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(223, 5, 'ICCW6XZ4', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(224, 5, 'ICZYWEUV', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(225, 5, 'ICAZSJWV', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(226, 5, 'IC9JVJ9X', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(227, 5, 'IC3ZX6GU', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(228, 5, 'ICKRF6ES', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(229, 5, 'IC7WFR55', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(230, 5, 'ICT9UNZD', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(231, 5, 'ICF4FXUE', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(232, 5, 'ICAZZ26K', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(233, 5, 'ICUTTGBU', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(234, 5, 'ICDVMZR4', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(235, 5, 'ICEDMR4T', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(236, 5, 'ICTGP4NJ', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(237, 5, 'ICSRUB3W', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(238, 5, 'ICG2Y6SU', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(239, 5, 'ICA9YKYK', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(240, 5, 'ICZ3EN62', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(241, 5, 'ICWC5UZ2', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(242, 5, 'ICYDUSJW', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(243, 5, 'IC79G5YN', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(244, 5, 'ICX2TNTZ', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(245, 5, 'IC85KWR9', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(246, 5, 'IC7R74SK', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(247, 5, 'ICKR4QAB', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(248, 5, 'ICX37YZK', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(249, 5, 'ICXBE3GD', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(250, 5, 'ICGBHEHA', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(251, 5, 'ICU7XHGA', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(252, 5, 'ICQNZ4R2', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(253, 5, 'ICZED7BP', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(254, 5, 'IC4ABZKE', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(255, 5, 'ICQ24KX4', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(256, 5, 'IC9VQS78', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(257, 5, 'ICFEJV6R', 'IC', '2018-05-07', '2018-06-30', 1, '100', 1, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(258, 5, 'ICRVZ5A4', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(259, 5, 'ICA2AKCA', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(260, 5, 'ICYXH23K', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(261, 5, 'ICC5PH7C', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(262, 5, 'IC9UFQRK', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(263, 5, 'ICFVVT5T', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(264, 5, 'ICGKQZPP', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(265, 5, 'ICCW7WJT', 'IC', '2018-05-07', '2018-06-30', 1, '100', 1, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(266, 5, 'ICJRFGSB', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(267, 5, 'ICH2ZEDY', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(268, 5, 'ICJ5U9KZ', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(269, 5, 'ICA86H6F', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(270, 5, 'ICP5YRAZ', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(271, 5, 'ICQJP7H6', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(272, 5, 'ICPC9X9Y', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(273, 5, 'ICXKURKR', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(274, 5, 'ICZ34DQC', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(275, 5, 'ICX9QPK4', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(276, 5, 'ICUPRCBD', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(277, 5, 'IC872GPG', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(278, 5, 'ICXUZKZ5', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(279, 5, 'ICV7HFZ5', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(280, 5, 'IC4EMT2N', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(281, 5, 'ICMADZME', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(282, 5, 'ICFBYGCJ', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(283, 5, 'ICQ8G8ED', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(284, 5, 'IC3WXPXH', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(285, 5, 'ICZ752BF', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(286, 5, 'ICVQ4Y7M', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(287, 5, 'ICW6WZ2F', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(288, 5, 'ICYDSBSW', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(289, 5, 'ICHRV756', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(290, 5, 'ICBSBAY8', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(291, 5, 'ICP4MBS7', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(292, 5, 'ICDWWKPS', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(293, 5, 'ICXQ38VQ', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(294, 5, 'IC8QE3FX', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(295, 5, 'ICXQHE5H', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(296, 5, 'ICPTS87H', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(297, 5, 'ICKXHKM9', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(298, 5, 'ICU32YNA', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(299, 5, 'ICCDCJF5', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(300, 5, 'ICEWUT6T', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(301, 5, 'ICFNU54C', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(302, 5, 'ICRSPX6Z', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(303, 5, 'IC3WUVYA', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(304, 5, 'ICX4KH27', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(305, 5, 'ICMFEWGR', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(306, 5, 'IC3CZUZ5', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(307, 5, 'IC7JC9NZ', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(308, 5, 'ICF4DEZV', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(309, 5, 'ICDHQP35', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(310, 5, 'ICDZ5MCU', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(311, 5, 'ICBTJP7P', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(312, 5, 'ICQ3A6SB', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(313, 5, 'ICCJPAGY', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(314, 5, 'ICMCH82B', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(315, 5, 'IC66JA68', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(316, 5, 'ICHXMXZH', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(317, 5, 'ICUBESTR', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(318, 5, 'IC5P5XZC', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(319, 5, 'ICWFYKGA', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(320, 5, 'ICD8H2M6', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(321, 5, 'ICM7U395', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(322, 5, 'ICTHSAE8', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(323, 5, 'ICT3X2KM', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(324, 5, 'IC7JGSYS', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(325, 5, 'ICQJZX67', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(326, 5, 'IC36C4PR', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(327, 5, 'ICZD65VC', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(328, 5, 'ICVDQNSY', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(329, 5, 'ICJSR6KV', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(330, 5, 'ICFG2DUH', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(331, 5, 'IC3EGRKQ', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(332, 5, 'ICBE7Z8M', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(333, 5, 'IC3FA63H', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(334, 5, 'IC8C2G8U', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(335, 5, 'ICHNK6HN', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(336, 5, 'IC2CHUND', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(337, 5, 'IC5AUQV6', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(338, 5, 'ICEN7E2A', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(339, 5, 'ICMA8KBE', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(340, 5, 'ICFKUPYK', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(341, 5, 'IC9SBV3R', 'IC', '2018-05-07', '2018-06-30', 1, '100', 1, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(342, 5, 'ICEY4MS6', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(343, 5, 'IC624R66', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(344, 5, 'ICXWR74H', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(345, 5, 'ICQGZJJ4', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(346, 5, 'ICRSM5V8', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(347, 5, 'ICCRZ338', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(348, 5, 'ICXD5BYF', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(349, 5, 'ICU95ZN5', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(350, 5, 'IC3STETE', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(351, 5, 'ICNMG3BY', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(352, 5, 'ICVXVA9M', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(353, 5, 'ICAZ6BQS', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(354, 5, 'ICAZMB9R', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(355, 5, 'ICKTYR5Y', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(356, 5, 'ICM3BFWS', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(357, 5, 'IC5KJSJ7', 'IC', '2018-05-07', '2018-06-30', 1, '100', 1, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(358, 5, 'ICNJD54G', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(359, 5, 'ICSPYHQ7', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(360, 5, 'ICEK85HV', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(361, 5, 'IC6MSCXA', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(362, 5, 'ICKBHBXN', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(363, 5, 'ICGUFREN', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(364, 5, 'ICZXUT46', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(365, 5, 'ICN6F8XT', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(366, 5, 'IC3HAD2Q', 'IC', '2018-05-07', '2018-06-30', 1, '100', 1, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(367, 5, 'ICVFERC9', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(368, 5, 'ICTQ5SR6', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(369, 5, 'ICK9VSEN', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(370, 5, 'ICY8WSUX', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(371, 5, 'ICA3PY8C', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(372, 5, 'ICZX7GW2', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(373, 5, 'ICT3Q6H5', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(374, 5, 'ICXFYW2E', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(375, 5, 'ICAZPSBA', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(376, 5, 'ICCEEDUY', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(377, 5, 'ICPUGMHM', 'IC', '2018-05-07', '2018-06-30', 1, '100', 1, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(378, 5, 'ICM7E34E', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(379, 5, 'ICGY4VXA', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(380, 5, 'ICU66ZUU', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(381, 5, 'IC2HVYSR', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(382, 5, 'ICYS7FQU', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(383, 5, 'ICNF35MJ', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(384, 5, 'ICBQHH6W', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(385, 5, 'ICKJHEBB', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(386, 5, 'ICR24NBT', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(387, 5, 'ICQ2Q2SK', 'IC', '2018-05-07', '2018-06-30', 1, '100', 1, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(388, 5, 'IC5CZ7FT', 'IC', '2018-05-07', '2018-06-30', 1, '100', 1, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(389, 5, 'IC5J6T8Y', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(390, 5, 'ICSTNFSB', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(391, 5, 'IC2Y8RQM', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(392, 5, 'IC8NY938', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(393, 5, 'ICVCVYMJ', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(394, 5, 'ICRWGCN4', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(395, 5, 'IC7TWUBQ', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(396, 5, 'ICBP9XMA', 'IC', '2018-05-07', '2018-06-30', 1, '100', 1, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(397, 5, 'ICG5W2X3', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(398, 5, 'ICRQ2H84', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(399, 5, 'ICVQ3XTM', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(400, 5, 'ICKA9PA3', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(401, 5, 'ICTGQ8AK', 'IC', '2018-05-07', '2018-06-30', 1, '100', 1, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(402, 5, 'IC2MQHSN', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(403, 5, 'ICT5DWMZ', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(404, 5, 'IC6UN5QN', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(405, 5, 'ICBK3HHR', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(406, 5, 'ICVC5AX2', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(407, 5, 'IC37TAN4', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(408, 5, 'ICKXYASJ', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(409, 5, 'ICS9A2Y9', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(410, 5, 'ICDJXP7A', 'IC', '2018-05-07', '2018-06-30', 1, '100', 1, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(411, 5, 'ICF8KRFR', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(412, 5, 'IC9SP4N9', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(413, 5, 'ICVW37GX', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(414, 5, 'ICYHAYXJ', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(415, 5, 'IC73M5JR', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(416, 5, 'ICVNDZFX', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(417, 5, 'ICZDFY2X', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(418, 5, 'ICUVT9WK', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(419, 5, 'ICG9CRDM', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(420, 5, 'ICTRD5MY', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(421, 5, 'IC8K6UU3', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(422, 5, 'IC77Q487', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(423, 5, 'ICURQHJZ', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(424, 5, 'IC2X6ZW9', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(425, 5, 'ICGDXTSM', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(426, 5, 'ICNVCGTH', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(427, 5, 'ICG3X7P5', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(428, 5, 'IC97HKRY', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(429, 5, 'IC4FAVUP', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(430, 5, 'ICRQKGWN', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00');
INSERT INTO `couponmaster` (`id`, `organization_id`, `couponcode`, `coupon_prefix`, `valid_from`, `valid_to`, `coupon_valid_times`, `discount_percentage`, `coupon_used_times`, `status`, `created_on`, `modified_on`) VALUES
(431, 5, 'ICF38RE9', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(432, 5, 'ICUX7UQ3', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(433, 5, 'ICB44RSG', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(434, 5, 'ICMEH2EB', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(435, 5, 'ICY4W5DM', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(436, 5, 'ICGNYKKU', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(437, 5, 'ICKWRRSP', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(438, 5, 'ICGWDBPC', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(439, 5, 'ICQC32KG', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(440, 5, 'ICC75JG7', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(441, 5, 'ICA8953F', 'IC', '2018-05-07', '2018-06-30', 1, '100', 1, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(442, 5, 'ICZX3Z5N', 'IC', '2018-05-07', '2018-06-30', 1, '100', 1, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(443, 5, 'ICJFUHM7', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(444, 5, 'ICMUTFTU', 'IC', '2018-05-07', '2018-06-30', 1, '100', 1, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(445, 5, 'ICA77K2M', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(446, 5, 'ICV7HFKG', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(447, 5, 'ICCC22MC', 'IC', '2018-05-07', '2018-06-30', 1, '100', 1, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(448, 5, 'ICAM7438', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(449, 5, 'ICGCZKBQ', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(450, 5, 'IC2TKW26', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(451, 5, 'IC7FQJ7N', 'IC', '2018-05-07', '2018-06-30', 1, '100', 1, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(452, 5, 'IC5FPQDR', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(453, 5, 'ICM7J2PY', 'IC', '2018-05-07', '2018-06-30', 1, '100', 1, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(454, 5, 'ICB765DQ', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(455, 5, 'ICRYKY4J', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(456, 5, 'ICVFNTR3', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(457, 5, 'ICV7SVYK', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(458, 5, 'ICDDNEPB', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(459, 5, 'ICX73KRJ', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(460, 5, 'ICTTZXBZ', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(461, 5, 'IC6REQEG', 'IC', '2018-05-07', '2018-06-30', 1, '100', 1, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(462, 5, 'ICPM2QGX', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(463, 5, 'ICUKZKXH', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(464, 5, 'ICDKQ7WP', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(465, 5, 'ICT2WKNB', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(466, 5, 'ICW9A92D', 'IC', '2018-05-07', '2018-06-30', 1, '100', 1, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(467, 5, 'ICKNTH3T', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(468, 5, 'ICAC9ZKK', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(469, 5, 'ICEMNCYF', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(470, 5, 'ICJRD5GH', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(471, 5, 'ICMVARMW', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(472, 5, 'ICW76T3C', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(473, 5, 'ICUAH2MX', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(474, 5, 'IC3CCXMD', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(475, 5, 'ICW79MXN', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(476, 5, 'ICW8WDVJ', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(477, 5, 'ICCZVXQ5', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(478, 5, 'ICZ8ZNVY', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(479, 5, 'IC6T2WGK', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(480, 5, 'IC6N4UA3', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(481, 5, 'ICJVV7RM', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(482, 5, 'ICYJTT8B', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(483, 5, 'ICSBB6QS', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(484, 5, 'ICCBJX9N', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(485, 5, 'ICCRQ74R', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(486, 5, 'ICWUCAU4', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(487, 5, 'IC7CYWS2', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(488, 5, 'ICB96FJS', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(489, 5, 'ICKKHDAZ', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(490, 5, 'ICG3H8DG', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(491, 5, 'ICU8DRJV', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(492, 5, 'ICKDE5G7', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(493, 5, 'ICUP2B3S', 'IC', '2018-05-07', '2018-06-30', 1, '100', 1, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(494, 5, 'ICUQ746F', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(495, 5, 'ICJKVC4P', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(496, 5, 'ICH9E2HZ', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(497, 5, 'ICPC8JEN', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(498, 5, 'ICSA2KRC', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(499, 5, 'ICTWFKRG', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(500, 5, 'ICGHXXHJ', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(501, 5, 'ICX45TXQ', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(502, 5, 'IC62JASZ', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(503, 5, 'IC4HTZQ8', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(504, 5, 'IC8V7BQE', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(505, 5, 'IC8AE4U8', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(506, 5, 'IC7TDVPV', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(507, 5, 'ICBKX3HK', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(508, 5, 'IC8CNV4A', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(509, 5, 'ICFWPM46', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(510, 5, 'ICWVMMF3', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(511, 5, 'ICCDNFRY', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(512, 5, 'ICVSWVJF', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(513, 5, 'ICVUCJ9N', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(514, 5, 'ICQE4U22', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(515, 5, 'IC8R5YTT', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(516, 5, 'ICS45U5E', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(517, 5, 'ICUDS4U5', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(518, 5, 'ICHD4AR4', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(519, 5, 'ICJG5DY7', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(520, 5, 'ICG82JKA', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(521, 5, 'ICEACB4H', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(522, 5, 'ICG7ZNJ5', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(523, 5, 'IC3XS7VV', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(524, 5, 'IC9Z6RYQ', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(525, 5, 'ICDGTJD5', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(526, 5, 'ICH9M594', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(527, 5, 'IC3BFYWJ', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(528, 5, 'ICP3AD6N', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(529, 5, 'ICNZ4MKJ', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(530, 5, 'ICGTYRXE', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(531, 5, 'ICY3RWJ6', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(532, 5, 'ICYYFNPH', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(533, 5, 'ICATK77G', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(534, 5, 'ICT3QP2A', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(535, 5, 'ICKSAFH9', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(536, 5, 'ICTEFV7X', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(537, 5, 'ICV3T5R7', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(538, 5, 'ICQVSMEE', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(539, 5, 'ICQYNSV4', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(540, 5, 'ICT9RPR5', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(541, 5, 'IC95V7YW', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(542, 5, 'IC8KPZCW', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(543, 5, 'ICZGC33R', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(544, 5, 'ICF3R7XA', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(545, 5, 'ICKC84D8', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(546, 5, 'IC3M577H', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(547, 5, 'IC9RE9QW', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(548, 5, 'IC3V5E3W', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(549, 5, 'ICPAJAEJ', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(550, 5, 'ICEP3QG6', 'IC', '2018-05-07', '2018-06-30', 1, '100', 1, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(551, 5, 'IC3H6EJE', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(552, 5, 'ICHU6HTG', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(553, 5, 'IC6JAJ48', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(554, 5, 'ICMTYJ6G', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(555, 5, 'ICJQE2TE', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(556, 5, 'ICVEUMBE', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(557, 5, 'ICS89KNH', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(558, 5, 'ICXXQBGT', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(559, 5, 'ICS8U4K8', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(560, 5, 'ICSQ2C73', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(561, 5, 'IC29529Y', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(562, 5, 'IC5SR7YS', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(563, 5, 'IC775SPF', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(564, 5, 'ICPMSXNY', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(565, 5, 'ICD3R4MR', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(566, 5, 'ICNWPBJ7', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(567, 5, 'ICKB6JCP', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(568, 5, 'ICJQ55Q9', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(569, 5, 'ICQGJ3QU', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(570, 5, 'ICS7W7S5', 'IC', '2018-05-07', '2018-06-30', 1, '100', 1, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(571, 5, 'ICD6QZVS', 'IC', '2018-05-07', '2018-06-30', 1, '100', 1, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(572, 5, 'IC6G6XUK', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(573, 5, 'ICUWTW2D', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(574, 5, 'ICSH9GBH', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(575, 5, 'IC8JU7ER', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(576, 5, 'ICHSK7EU', 'IC', '2018-05-07', '2018-06-30', 1, '100', 1, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(577, 5, 'IC24D8CZ', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(578, 5, 'ICZ3MCT4', 'IC', '2018-05-07', '2018-06-30', 1, '100', 1, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(579, 5, 'ICVYDDA6', 'IC', '2018-05-07', '2018-06-30', 1, '100', 1, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(580, 5, 'IC5S9XBQ', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(581, 5, 'ICMD2XM5', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(582, 5, 'ICJ4F63C', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(583, 5, 'ICVZJX8Y', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(584, 5, 'ICMAETC6', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(585, 5, 'ICZ65XSK', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(586, 5, 'ICV97AH8', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(587, 5, 'IC8UA68P', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(588, 5, 'ICG3KSFH', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(589, 5, 'IC6X2S9D', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(590, 5, 'IC3ZUW9V', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(591, 5, 'IC55VDHA', 'IC', '2018-05-07', '2018-06-30', 1, '100', 1, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(592, 5, 'ICPHPYVW', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(593, 5, 'ICP96BMW', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(594, 5, 'ICW9FCXQ', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(595, 5, 'ICYC8U6K', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(596, 5, 'ICFKET22', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(597, 5, 'ICNZK8KW', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(598, 5, 'ICBAH5CU', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(599, 5, 'IC3CXZC3', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(600, 5, 'ICVCSB88', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(601, 5, 'ICT48Y6Q', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(602, 5, 'ICRYJHK7', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(603, 5, 'ICTDMQYU', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(604, 5, 'ICW7VK4F', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(605, 5, 'ICVHSYFH', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(606, 5, 'ICQMZJMX', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(607, 5, 'IC4SRT5X', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(608, 5, 'IC5SRBPT', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(609, 5, 'ICSE5HDJ', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(610, 5, 'IC2D3YDA', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(611, 5, 'ICNKVHDQ', 'IC', '2018-05-07', '2018-06-30', 1, '100', 1, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(612, 5, 'ICK5348Y', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(613, 5, 'ICBMWDP9', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(614, 5, 'ICUWKGPP', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(615, 5, 'ICRXB9YM', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(616, 5, 'ICHNEQ5U', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(617, 5, 'IC4N4ZFE', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(618, 5, 'ICWEDZ7N', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(619, 5, 'ICVE9QTS', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(620, 5, 'ICTGJUAT', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(621, 5, 'ICYH7BHE', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(622, 5, 'ICD3DHNG', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(623, 5, 'ICUG8SV6', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(624, 5, 'IC2HF6RE', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(625, 5, 'ICJ2W59D', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(626, 5, 'IC8NC2PY', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(627, 5, 'ICHKSCQG', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(628, 5, 'ICA8TPPV', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(629, 5, 'ICRQV35M', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(630, 5, 'ICJ84YH9', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(631, 5, 'IC8PG5Z4', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(632, 5, 'IC8ZYH94', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(633, 5, 'ICQT2XVV', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(634, 5, 'ICRMAGAD', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(635, 5, 'IC2ATSAK', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(636, 5, 'IC8JCYMB', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(637, 5, 'IC8TED3J', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(638, 5, 'IC3YHNR9', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(639, 5, 'ICHYEPYW', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(640, 5, 'IC9E4U23', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(641, 5, 'ICA3S8X5', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(642, 5, 'ICDHUXAA', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(643, 5, 'ICKS2PGW', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(644, 5, 'ICQMQNG8', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(645, 5, 'IC45QY3W', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(646, 5, 'IC9H32R5', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(647, 5, 'ICJU6SHK', 'IC', '2018-05-07', '2018-06-30', 1, '100', 1, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(648, 5, 'ICUPDG8G', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(649, 5, 'IC82VB4H', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(650, 5, 'ICUUN69V', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(651, 5, 'ICWEZFYP', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(652, 5, 'ICRG2RFP', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(653, 5, 'IC9DQCH2', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(654, 5, 'IC749AEN', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(655, 5, 'ICMAD3M7', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(656, 5, 'ICU482YU', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(657, 5, 'ICZCTA3Q', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(658, 5, 'ICBPCVC3', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(659, 5, 'ICQDYZWW', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(660, 5, 'ICC23PUD', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(661, 5, 'ICZZPZRC', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(662, 5, 'ICHTC67U', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(663, 5, 'IC529GU4', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(664, 5, 'IC9WMJ7Y', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(665, 5, 'ICVAJK8H', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(666, 5, 'ICVW8HQ3', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(667, 5, 'ICBWB73N', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(668, 5, 'ICUZJSEW', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(669, 5, 'ICZK9Z8P', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(670, 5, 'ICUPNU9S', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(671, 5, 'ICGASUNM', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(672, 5, 'ICQV9ZQ7', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(673, 5, 'IC73VZNT', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(674, 5, 'ICTF49WK', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(675, 5, 'ICWA2NHW', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(676, 5, 'IC9PRKCD', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(677, 5, 'ICN47KJ6', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(678, 5, 'ICDRW5J6', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(679, 5, 'ICPHMQ68', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(680, 5, 'ICEQEBG9', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(681, 5, 'ICSAPT9E', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(682, 5, 'IC9RBVSX', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(683, 5, 'ICYTKQ58', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(684, 5, 'ICEWG97G', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(685, 5, 'ICX8SSFU', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(686, 5, 'IC83GH5N', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(687, 5, 'ICY2WZW7', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(688, 5, 'ICCEZRST', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(689, 5, 'IC85UH7N', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(690, 5, 'IC6TB67S', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(691, 5, 'ICZNN3HS', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(692, 5, 'ICRWJUQE', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(693, 5, 'ICZSKNNE', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(694, 5, 'ICASNWFC', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(695, 5, 'ICWJ7UEF', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(696, 5, 'ICXZRNPH', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(697, 5, 'IC7MQGCZ', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(698, 5, 'ICA3H8X9', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(699, 5, 'ICP9A63J', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(700, 5, 'ICCXNVX2', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(701, 5, 'IC48BJHR', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(702, 5, 'ICEN3YVB', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(703, 5, 'ICX9GBXK', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(704, 5, 'IC5F9AF3', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(705, 5, 'ICRP8FSP', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(706, 5, 'IC99J6NQ', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(707, 5, 'IC2N65GD', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(708, 5, 'IC6HSHRC', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(709, 5, 'ICDSFMYA', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(710, 5, 'ICMW8NEM', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(711, 5, 'IC9539CQ', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(712, 5, 'ICNKXCAP', 'IC', '2018-05-07', '2018-06-30', 1, '100', 1, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(713, 5, 'IC9CFJ5K', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(714, 5, 'ICMSTVEQ', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(715, 5, 'ICQ449P9', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(716, 5, 'ICNRQTVT', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(717, 5, 'ICXYQUAJ', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(718, 5, 'IC684NR4', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(719, 5, 'ICHSD4NX', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(720, 5, 'ICTMNKTM', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(721, 5, 'IC862BUD', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(722, 5, 'ICDNU6VY', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(723, 5, 'ICXJURYE', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(724, 5, 'ICX3HCSG', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(725, 5, 'IC89HWWA', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(726, 5, 'ICKW984H', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(727, 5, 'ICUZUM6C', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(728, 5, 'ICWSVQ56', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(729, 5, 'IC9ZP28Q', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(730, 5, 'ICXHGCF3', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(731, 5, 'ICK537GD', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(732, 5, 'IC9N85UB', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(733, 5, 'IC63M678', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(734, 5, 'IC7ZPYYJ', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(735, 5, 'ICKZNXPT', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(736, 5, 'ICCP25R7', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(737, 5, 'ICHS7YVW', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(738, 5, 'ICND6TW4', 'IC', '2018-05-07', '2018-06-30', 1, '100', 1, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(739, 5, 'IC6PEYVU', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(740, 5, 'IC3U7782', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(741, 5, 'IC4Q37BA', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(742, 5, 'ICMGEEJS', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(743, 5, 'IC5HKM36', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(744, 5, 'ICA6VRDG', 'IC', '2018-05-07', '2018-06-30', 1, '100', 1, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(745, 5, 'ICBD8BH5', 'IC', '2018-05-07', '2018-06-30', 1, '100', 1, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(746, 5, 'IC4QS547', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(747, 5, 'ICG24MJF', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(748, 5, 'IC5ZD8X4', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(749, 5, 'ICC9XGEH', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(750, 5, 'ICPFAFKP', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(751, 5, 'ICYGFUS7', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(752, 5, 'IC4QPNUH', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(753, 5, 'ICUFFH4A', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(754, 5, 'ICCG4B8B', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(755, 5, 'ICSF3UQM', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(756, 5, 'IC9M83X2', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(757, 5, 'ICVHC6XK', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(758, 5, 'ICVJBA5N', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(759, 5, 'ICYNXGJV', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(760, 5, 'ICFKFREN', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(761, 5, 'ICFDEA6P', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(762, 5, 'ICSR93N6', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(763, 5, 'ICN733DS', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(764, 5, 'ICUKB5N3', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(765, 5, 'ICFXHQXC', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(766, 5, 'IC4446DC', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(767, 5, 'IC747YMQ', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(768, 5, 'ICQCTH2X', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(769, 5, 'ICETMSSU', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(770, 5, 'IC6SMUET', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(771, 5, 'ICNNJ3SD', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(772, 5, 'ICWWCBG8', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(773, 5, 'ICDQDE4Q', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(774, 5, 'IC8K9E27', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(775, 5, 'ICFH3ZQG', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(776, 5, 'ICGWUEHJ', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(777, 5, 'ICZXGYRX', 'IC', '2018-05-07', '2018-06-30', 1, '100', 1, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(778, 5, 'ICEUPC5Y', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(779, 5, 'ICX23HV4', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(780, 5, 'ICWBC98T', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(781, 5, 'ICCDNF47', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(782, 5, 'ICNQTSFA', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(783, 5, 'ICB75683', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(784, 5, 'ICCCZUB9', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(785, 5, 'ICQWYRVR', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(786, 5, 'IC2K4PDE', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(787, 5, 'ICYCS9NX', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(788, 5, 'IC3575Z2', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(789, 5, 'ICPZBU9G', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(790, 5, 'IC7XDRKH', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(791, 5, 'ICKPV63P', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(792, 5, 'ICDJWZ8T', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(793, 5, 'ICSSQMRC', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(794, 5, 'IC4TVCEX', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(795, 5, 'ICPXQGAX', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(796, 5, 'ICRYND4X', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(797, 5, 'IC8Q3C8S', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(798, 5, 'ICBDFZQE', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(799, 5, 'IC83RGQK', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(800, 5, 'ICZUBFB7', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(801, 5, 'ICH427PP', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(802, 5, 'ICVAYP4D', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(803, 5, 'ICTUQNVA', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(804, 5, 'ICV7VARW', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(805, 5, 'ICFPD4GF', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(806, 5, 'ICDXBBZX', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(807, 5, 'ICXXGVUW', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(808, 5, 'ICZEGE87', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(809, 5, 'ICQDAND5', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(810, 5, 'ICHM3UXH', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(811, 5, 'ICYXHVU7', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(812, 5, 'ICB6NHAS', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(813, 5, 'ICGA77NV', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(814, 5, 'ICWDERF5', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(815, 5, 'ICW7T33H', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(816, 5, 'ICHK4BRQ', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(817, 5, 'ICPJKUSR', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(818, 5, 'ICPY6CQJ', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(819, 5, 'ICTZ527J', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(820, 5, 'IC27GHF4', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(821, 5, 'IC559D7Z', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(822, 5, 'ICQQWY5Q', 'IC', '2018-05-07', '2018-06-30', 1, '100', 1, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(823, 5, 'ICXCFE7Y', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(824, 5, 'ICGZGD87', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(825, 5, 'IC349K2R', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(826, 5, 'ICE7CNK6', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(827, 5, 'ICSAG9ZS', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(828, 5, 'IC3XZKXH', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(829, 5, 'IC8NJVQZ', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(830, 5, 'ICCUQ9KR', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(831, 5, 'IC8KXYZ9', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(832, 5, 'ICQFRDJG', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(833, 5, 'ICZ6VSA7', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(834, 5, 'ICP28N2Z', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(835, 5, 'IC8SBJMT', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(836, 5, 'ICNEWDKG', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(837, 5, 'ICGCBJ8P', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(838, 5, 'ICHUUSQD', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(839, 5, 'ICGGRJAC', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(840, 5, 'ICZURT9B', 'IC', '2018-05-07', '2018-06-30', 1, '100', 1, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(841, 5, 'ICHP2YMK', 'IC', '2018-05-07', '2018-06-30', 1, '100', 1, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(842, 5, 'ICNHX7P9', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(843, 5, 'ICQVNQHN', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(844, 5, 'ICNEVUQK', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(845, 5, 'ICEPUXWF', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(846, 5, 'ICNBQPGH', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(847, 5, 'ICSDYCWA', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(848, 5, 'ICYAZ673', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(849, 5, 'IC8AE67P', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(850, 5, 'IC4GFUTF', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(851, 5, 'ICRA7HHV', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(852, 5, 'ICRAJVJ8', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(853, 5, 'IC7XFW8F', 'IC', '2018-05-07', '2018-06-30', 1, '100', 1, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(854, 5, 'IC7BM47H', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(855, 5, 'ICG734K2', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(856, 5, 'ICNTWA7G', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(857, 5, 'ICCHY2SX', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(858, 5, 'ICWXV7NJ', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(859, 5, 'ICYAEJC5', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00');
INSERT INTO `couponmaster` (`id`, `organization_id`, `couponcode`, `coupon_prefix`, `valid_from`, `valid_to`, `coupon_valid_times`, `discount_percentage`, `coupon_used_times`, `status`, `created_on`, `modified_on`) VALUES
(860, 5, 'ICKFYG46', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(861, 5, 'IC4F3SNE', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(862, 5, 'ICBFFA2D', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(863, 5, 'ICUV3CEA', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(864, 5, 'ICQFRT3D', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(865, 5, 'IC2K2MRG', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(866, 5, 'ICX4SW8F', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(867, 5, 'ICCKC6JK', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(868, 5, 'ICE236PX', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(869, 5, 'IC9TXWNH', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(870, 5, 'ICCW748M', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(871, 5, 'ICGBXKZZ', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(872, 5, 'ICTMWR3H', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(873, 5, 'ICYDW3KV', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(874, 5, 'ICADZ75G', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(875, 5, 'ICTPK37Q', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(876, 5, 'IC475F8K', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(877, 5, 'ICEZKXMD', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(878, 5, 'ICZX4BGT', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(879, 5, 'ICBJDKFS', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(880, 5, 'ICHRGWR5', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(881, 5, 'IC6MNQ4W', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(882, 5, 'ICEUJNZP', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(883, 5, 'ICV8WZ9T', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(884, 5, 'ICKNF746', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(885, 5, 'ICHNHBEN', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(886, 5, 'IC22UCK3', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(887, 5, 'ICCHB7HD', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(888, 5, 'ICVEANBA', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(889, 5, 'ICN44S2J', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(890, 5, 'ICWWZC8M', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(891, 5, 'IC45YNMH', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(892, 5, 'IC9R5RNY', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(893, 5, 'ICY649YB', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(894, 5, 'ICUKM7D8', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(895, 5, 'ICBMVRWC', 'IC', '2018-05-07', '2018-06-30', 1, '100', 1, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(896, 5, 'ICU5AB6V', 'IC', '2018-05-07', '2018-06-30', 1, '100', 1, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(897, 5, 'ICNEUA8P', 'IC', '2018-05-07', '2018-06-30', 1, '100', 1, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(898, 5, 'IC5KTBXG', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(899, 5, 'ICA3SHDW', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(900, 5, 'ICUP4SDN', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(901, 5, 'IC92Y3BU', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(902, 5, 'ICYKENUW', 'IC', '2018-05-07', '2018-06-30', 1, '100', 1, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(903, 5, 'IC8AVGDD', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(904, 5, 'ICCBWH4K', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(905, 5, 'ICUC7GZM', 'IC', '2018-05-07', '2018-06-30', 1, '100', 1, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(906, 5, 'ICN7MZRV', 'IC', '2018-05-07', '2018-06-30', 1, '100', 2, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(907, 5, 'ICYYQMGF', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(908, 5, 'ICD8JA4G', 'IC', '2018-05-07', '2018-06-30', 1, '100', 1, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(909, 5, 'ICQKD6VB', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(910, 5, 'ICP35CP5', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(911, 5, 'ICECY8P4', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(912, 5, 'ICEMNMM5', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(913, 5, 'ICH8RHUP', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(914, 5, 'ICYMPXCA', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(915, 5, 'IC3RUXJX', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(916, 5, 'IC4YNBFV', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(917, 5, 'IC52QNZW', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(918, 5, 'ICMTM7ZJ', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(919, 5, 'ICRZDK2A', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(920, 5, 'ICDA5FZ6', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(921, 5, 'ICK33F7W', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(922, 5, 'ICUP2WWH', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(923, 5, 'IC3P7XYD', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(924, 5, 'ICTAS3JY', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(925, 5, 'IC9JFDG8', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(926, 5, 'ICXTMY2A', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(927, 5, 'IC57UQ85', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(928, 5, 'ICCUJECZ', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(929, 5, 'ICGAAXVW', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(930, 5, 'ICU4QGVN', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(931, 5, 'ICK2WX77', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(932, 5, 'ICJ5HCS9', 'IC', '2018-05-07', '2018-06-30', 1, '100', 1, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(933, 5, 'ICX2Z2Z4', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(934, 5, 'ICCEX8W9', 'IC', '2018-05-07', '2018-06-30', 1, '100', 1, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(935, 5, 'ICWWQD5T', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(936, 5, 'IC24PFMG', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(937, 5, 'IC5DXDAB', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(938, 5, 'ICZDYHT8', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(939, 5, 'IC5FWWAK', 'IC', '2018-05-07', '2018-06-30', 1, '100', 1, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(940, 5, 'ICGTKPED', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(941, 5, 'ICBX5HZD', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(942, 5, 'ICBDE8QH', 'IC', '2018-05-07', '2018-06-30', 1, '100', 1, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(943, 5, 'IC3UCAAS', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(944, 5, 'ICWDJ23A', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(945, 5, 'ICMFRTK8', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(946, 5, 'ICZFGJAH', 'IC', '2018-05-07', '2018-06-30', 1, '100', 1, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(947, 5, 'ICSJFTCV', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(948, 5, 'ICHA99E7', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(949, 5, 'IC5XYBHC', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(950, 5, 'ICFC7UGT', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(951, 5, 'ICDTS5EA', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(952, 5, 'ICKW4DVB', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(953, 5, 'ICP2UWJT', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(954, 5, 'ICP3PCQ8', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(955, 5, 'ICYMTC9T', 'IC', '2018-05-07', '2018-06-30', 1, '100', 1, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(956, 5, 'ICJQQ7KF', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(957, 5, 'ICPUDENC', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(958, 5, 'ICQBA5T5', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(959, 5, 'ICKVHHQP', 'IC', '2018-05-07', '2018-06-30', 1, '100', 1, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(960, 5, 'ICUJDBAT', 'IC', '2018-05-07', '2018-06-30', 1, '100', 1, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(961, 5, 'IC2ZBYUM', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(962, 5, 'IC3NPD9J', 'IC', '2018-05-07', '2018-06-30', 1, '100', 1, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(963, 5, 'ICWNWNH2', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(964, 5, 'ICMJ3MCS', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(965, 5, 'ICSUSZBZ', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(966, 5, 'ICZEK3SX', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(967, 5, 'ICW2C279', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(968, 5, 'ICUQQQMJ', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(969, 5, 'ICDUNR4K', 'IC', '2018-05-07', '2018-06-30', 1, '100', 1, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(970, 5, 'IC7ASW2D', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(971, 5, 'ICTJGQ86', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(972, 5, 'IC4T6BG7', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(973, 5, 'ICMV3B6D', 'IC', '2018-05-07', '2018-06-30', 1, '100', 1, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(974, 5, 'IC9XFE7T', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(975, 5, 'ICDGMRH3', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(976, 5, 'ICTF9EZJ', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(977, 5, 'ICMCHP5H', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(978, 5, 'IC3Z3TYS', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(979, 5, 'ICY3CWXZ', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(980, 5, 'ICPFVPAS', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(981, 5, 'ICH7D7YX', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(982, 5, 'ICA59N9D', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(983, 5, 'ICSVKP2Q', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(984, 5, 'ICXFQGVF', 'IC', '2018-05-07', '2018-06-30', 1, '100', 1, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(985, 5, 'IC6NC69E', 'IC', '2018-05-07', '2018-06-30', 1, '100', 1, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(986, 5, 'ICAHKBKC', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(987, 5, 'ICXVBWWD', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(988, 5, 'ICM53XWS', 'IC', '2018-05-07', '2018-06-30', 1, '100', 1, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(989, 5, 'ICVJGXB4', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(990, 5, 'ICKP3GGN', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(991, 5, 'ICXG9CQP', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(992, 5, 'ICTSQVPW', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(993, 5, 'ICFDVZ8U', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(994, 5, 'ICCYFXK4', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(995, 5, 'ICT4DRDX', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(996, 5, 'IC5VV26H', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(997, 5, 'ICPUAFBT', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(998, 5, 'IC45EGUM', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(999, 5, 'ICKSTWBF', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(1000, 5, 'ICJ6YCBR', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(1001, 5, 'ICUYVDR3', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(1002, 5, 'ICDCFZ4T', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(1003, 5, 'IC4MTCXZ', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(1004, 5, 'ICHP2FJN', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(1005, 5, 'ICXVVJKU', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(1006, 5, 'ICMRQYGG', 'IC', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(1007, 5, 'HIN001', 'HI', '2018-05-07', '2018-06-30', 1, '100', 1, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(1008, 5, 'HIN002', 'HI', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(1009, 5, 'HIN003', 'HI', '2018-05-07', '2018-06-30', 1, '100', 1, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(1010, 5, 'HIN004', 'HI', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(1011, 5, 'HIN005', 'HI', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(1012, 5, 'HIN006', 'HI', '2018-05-07', '2018-06-30', 1, '100', 1, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(1013, 5, 'HIN007', 'HI', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(1014, 5, 'HIN008', 'HI', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(1015, 5, 'HIN009', 'HI', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00'),
(1016, 5, 'HIN010', 'HI', '2018-05-07', '2018-06-30', 1, '100', 0, 1, '2018-05-04 00:00:00', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `daywisebadgetopper`
--

CREATE TABLE `daywisebadgetopper` (
  `id` int(11) NOT NULL,
  `userid` varchar(110) NOT NULL,
  `org_id` int(11) NOT NULL,
  `grade_id` int(11) NOT NULL,
  `type` enum('SBB','SGB','SAB') NOT NULL COMMENT 'SAB => Super Angel Badge,SBB=> Super Brain Badge,SGB => Super Goer Badge',
  `value` varchar(55) NOT NULL,
  `dateontopper` date NOT NULL,
  `created_on` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `doctormaster`
--

CREATE TABLE `doctormaster` (
  `id` int(11) NOT NULL,
  `doctorname` varchar(110) NOT NULL,
  `lastname` varchar(255) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `dateofbirth` varchar(100) NOT NULL,
  `email` varchar(800) NOT NULL,
  `secondaryemail` varchar(800) NOT NULL,
  `state` int(11) NOT NULL,
  `city` varchar(400) NOT NULL,
  `mobilenumber` varchar(20) NOT NULL,
  `secondarymobilenumber` varchar(20) NOT NULL,
  `address` text NOT NULL,
  `profileimage` varchar(800) NOT NULL,
  `hospitalid` int(11) NOT NULL,
  `status` int(11) NOT NULL COMMENT '0=> InActive,1 => Active',
  `created_on` datetime NOT NULL,
  `modifed_on` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `doctormaster`
--

INSERT INTO `doctormaster` (`id`, `doctorname`, `lastname`, `username`, `password`, `gender`, `dateofbirth`, `email`, `secondaryemail`, `state`, `city`, `mobilenumber`, `secondarymobilenumber`, `address`, `profileimage`, `hospitalid`, `status`, `created_on`, `modifed_on`) VALUES
(1, 'Sundar', 'R', 'sundar', 'ca9139d33a0a27a6bcf77910a32514be', 'M', '20-02-1990', 'sundar@gmail.com', 'sandy@gmail.com', 1823, 'chennai', '1234567890', '9876543210', 'No.15, kattapomman streettharamani', 'assets/images/doctor/logos.png', 1, 1, '2018-01-03 00:00:00', '2018-01-12 11:01:11'),
(2, 'Hari', 's', 'hari', 'ca9139d33a0a27a6bcf77910a32514be', 'M', '15-08-1991', 'hari@gmail.com', 'har1@gmail.com', 1823, 'chennai', '1234567890', '9876543210', 'No.15kattapomman streettharamani', '', 2, 1, '2018-01-04 00:00:00', '0000-00-00 00:00:00'),
(3, 'Damu', 'M', 'damu', 'ca9139d33a0a27a6bcf77910a32514be', 'M', '20-08-1991', 'ravi@gmail.com', 'ravi@inq.com', 1817, 'Banglore', '9962452676', '9884584861', 'Vadapalni', '', 11, 1, '2018-01-04 12:09:30', '2018-01-04 12:47:53'),
(4, 'Gopi', 'Nath', 'gopi', 'ca9139d33a0a27a6bcf77910a32514be', 'M', '02-01-2018', 'gopi@gmail.com', 'go@gmail.com', 1823, 'chennai', '1234567890', '0987654321', 'Karur', '', 10, 1, '2018-01-04 12:49:22', '2018-01-04 12:50:32'),
(5, 'Udai Kumaresh', 'S', '', '', 'M', '01-01-2018', 'udai@gmail.com', 'kumaresh@gmail.com', 1823, 'Madurai', '1234567890', '9876543210', 'Velacherry', '', 3, 0, '2018-01-05 10:31:40', '2018-01-06 11:05:19');

-- --------------------------------------------------------

--
-- Table structure for table `edsix_issued_coupon`
--

CREATE TABLE `edsix_issued_coupon` (
  `id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `noofcoupon` int(11) NOT NULL,
  `status` enum('Y','N') NOT NULL,
  `issued_by` int(11) NOT NULL,
  `issued_on` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `edsix_issued_coupon`
--

INSERT INTO `edsix_issued_coupon` (`id`, `product_id`, `noofcoupon`, `status`, `issued_by`, `issued_on`) VALUES
(1, 1, 1000, 'Y', 1, '2018-01-22 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `edsix_issued_license`
--

CREATE TABLE `edsix_issued_license` (
  `id` int(11) NOT NULL,
  `noofcoupon` int(11) NOT NULL,
  `status` enum('Y','N') NOT NULL,
  `issued_by` int(11) NOT NULL,
  `issued_on` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `edsix_issued_license`
--

INSERT INTO `edsix_issued_license` (`id`, `noofcoupon`, `status`, `issued_by`, `issued_on`) VALUES
(1, 500, 'Y', 1, '2018-01-22 00:00:00'),
(2, 100, 'Y', 1, '2018-04-10 18:57:01'),
(3, 20, 'Y', 1, '2018-04-10 19:02:55'),
(4, 30, 'Y', 1, '2018-04-11 09:31:07');

-- --------------------------------------------------------

--
-- Table structure for table `eom_report`
--

CREATE TABLE `eom_report` (
  `ID` int(11) NOT NULL,
  `School_id` int(11) NOT NULL,
  `Month_no` varchar(55) NOT NULL,
  `RCode` varchar(55) NOT NULL,
  `Message` text NOT NULL,
  `Status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `gamedata`
--

CREATE TABLE `gamedata` (
  `id` int(11) NOT NULL,
  `gu_id` int(10) NOT NULL,
  `gc_id` int(10) NOT NULL,
  `gs_id` int(10) NOT NULL,
  `gp_id` varchar(100) NOT NULL,
  `g_id` int(30) NOT NULL,
  `gamename` varchar(255) NOT NULL,
  `total_question` varchar(15) NOT NULL,
  `attempt_question` varchar(20) NOT NULL,
  `answer` varchar(20) NOT NULL,
  `game_score` varchar(50) NOT NULL,
  `gtime` varchar(100) NOT NULL,
  `rtime` varchar(100) NOT NULL,
  `crtime` varchar(100) NOT NULL,
  `wrtime` varchar(100) NOT NULL,
  `lastupdate` date NOT NULL,
  `createdby` varchar(100) NOT NULL,
  `creation_date` date NOT NULL,
  `modifiedby` varchar(100) NOT NULL,
  `modified_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `star` int(11) NOT NULL,
  `puzzle_cycle` int(11) NOT NULL,
  `site_type` enum('APP','WEB') NOT NULL DEFAULT 'APP',
  `assign_id` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `App_randomid` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `gamedata_cq`
--

CREATE TABLE `gamedata_cq` (
  `id` int(11) NOT NULL,
  `gu_id` int(10) NOT NULL,
  `gc_id` int(11) NOT NULL,
  `gs_id` int(10) NOT NULL,
  `gp_id` varchar(100) NOT NULL,
  `g_id` int(30) NOT NULL,
  `total_question` varchar(15) NOT NULL,
  `attempt_question` varchar(20) NOT NULL,
  `answer` varchar(20) NOT NULL,
  `game_score` varchar(50) NOT NULL,
  `gtime` varchar(100) NOT NULL,
  `rtime` varchar(100) NOT NULL,
  `crtime` varchar(100) NOT NULL,
  `wrtime` varchar(100) NOT NULL,
  `lastupdate` date NOT NULL,
  `createdby` varchar(100) NOT NULL,
  `creation_date` date NOT NULL,
  `modifiedby` varchar(100) NOT NULL,
  `modified_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `Is_schedule` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Stand-in structure for view `gamedata_updated`
-- (See below for the actual view)
--
CREATE TABLE `gamedata_updated` (
`id` int(11)
,`gu_id` int(11)
,`gp_id` int(11)
,`gc_id` int(11)
,`gs_id` int(11)
,`g_id` int(11)
,`total_question` int(2)
,`attempt_question` bigint(21)
,`answer` decimal(23,0)
,`game_score` decimal(32,0)
,`gtime` int(11)
,`rtime` decimal(32,0)
,`crtime` decimal(32,0)
,`wrtime` decimal(32,0)
,`lastupdate` date
,`iteration` int(11)
);

-- --------------------------------------------------------

--
-- Table structure for table `games`
--

CREATE TABLE `games` (
  `gid` int(100) NOT NULL,
  `gc_id` int(100) NOT NULL,
  `gs_id` int(100) NOT NULL,
  `gname` varchar(100) NOT NULL,
  `path` varchar(500) NOT NULL,
  `descs` varchar(500) NOT NULL,
  `img_path` varchar(100) NOT NULL,
  `appimg_path` varchar(110) NOT NULL,
  `gstatus` int(1) NOT NULL,
  `gplans` varchar(100) NOT NULL,
  `createdby` varchar(100) NOT NULL,
  `creation_date` date NOT NULL,
  `modifiedby` varchar(100) NOT NULL,
  `modified_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `game_html` varchar(500) NOT NULL,
  `game_name_html` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `games`
--

INSERT INTO `games` (`gid`, `gc_id`, `gs_id`, `gname`, `path`, `descs`, `img_path`, `appimg_path`, `gstatus`, `gplans`, `createdby`, `creation_date`, `modifiedby`, `modified_date`, `game_html`, `game_name_html`) VALUES
(1, 1, 59, 'SameToSame-KG', '', 'Memory', 'uploads/DoWeDiffer.png', 'uploads/DoWeDiffer.png', 1, '', '', '2014-06-17', '', '2019-02-08 00:37:38', 'DoWeDiffer-KG', 'DoWeDiffer-KG'),
(2, 1, 59, 'StarLight-KG', '', 'Memory', 'uploads/StarLight.png', 'uploads/StarLight.png', 1, '', '', '2014-06-17', '', '2018-07-19 18:15:02', 'StarLight-KG', 'StarLight-KG'),
(3, 1, 59, 'OddShape-KG', '', 'Memory', 'uploads/OddShape.png', 'uploads/OddShape.png', 1, '', '', '2014-06-17', '', '2018-07-19 18:15:29', 'OddShape-KG', 'OddShape-KG'),
(4, 1, 59, 'GroupIt-KG', '', 'Memory', 'uploads/GroupIt.png', 'uploads/GroupIt.png', 1, '', '', '2014-06-17', '', '2018-07-19 18:16:40', 'GroupIt-KG', 'GroupIt-KG'),
(5, 1, 59, 'WhatComesHere-KG', '', 'Memory', 'uploads/WhatComesHere.png', 'uploads/WhatComesHere.png', 1, '', '', '2014-06-17', '', '2018-07-19 18:20:47', 'WhatComesHere-KG', 'WhatComesHere-KG'),
(6, 1, 59, 'StrangerGrid-KG', '', 'Memory', 'uploads/StrangerGrid.png', 'uploads/StrangerGrid.png', 1, '', '', '2014-06-17', '', '2018-07-19 18:23:08', 'StrangerGrid-KG', 'StrangerGrid-KG'),
(7, 1, 59, 'DoWeDiffer-Level1', '', 'Memory', 'uploads/DoWeDiffer.png', 'uploads/DoWeDiffer.png', 1, '', '', '2014-06-17', '', '2018-07-19 18:24:36', 'DoWeDiffer-Level1', 'DoWeDiffer-Level1'),
(8, 1, 59, 'StarLight-Level1', '', 'Memory', 'uploads/StarLight.png', 'uploads/StarLight.png', 1, '', '', '2014-06-17', '', '2018-07-19 18:25:18', 'StarLight-Level1', 'StarLight-Level1'),
(9, 1, 59, 'OddShape-Level1', '', 'Memory', 'uploads/OddShape.png', 'uploads/OddShape.png', 1, '', '', '2014-06-17', '', '2018-07-19 18:25:57', 'OddShape-Level1', 'OddShape-Level1'),
(10, 1, 59, 'GroupIt-Level1', '', 'Memory', 'uploads/GroupIt.png', 'uploads/GroupIt.png', 1, '', '', '2014-06-17', '', '2018-07-19 18:35:56', 'GroupIt-Level1', 'GroupIt-Level1'),
(11, 1, 59, 'WhatComesNext-Level1', '', 'Memory', 'uploads/WhatComesNext.png', 'uploads/WhatComesNext.png', 1, '', '', '2014-06-17', '', '2018-07-19 18:37:27', 'WhatComesNext-Level1', 'WhatComesNext-Level1'),
(12, 1, 59, 'StrangerGrid-Level1', '', 'Memory', 'uploads/StrangerGrid.png', 'uploads/StrangerGrid.png', 1, '', '', '2014-06-17', '', '2018-07-19 18:38:32', 'StrangerGrid-Level1', 'StrangerGrid-Level1'),
(13, 1, 59, 'DoWeDiffer-Level2', '', 'Memory', 'uploads/DoWeDiffer.png', 'uploads/DoWeDiffer.png', 1, '', '', '2014-06-17', '', '2018-07-19 18:39:18', 'DoWeDiffer-Level2', 'DoWeDiffer-Level2'),
(14, 1, 59, 'StarLight-Level2', '', 'Memory', 'uploads/StarLight.png', 'uploads/StarLight.png', 1, '', '', '2014-06-17', '', '2018-07-19 18:41:54', 'StarLight-Level2', 'StarLight-Level2'),
(15, 1, 59, 'OddShape-Level2', '', 'Memory', 'uploads/OddShape.png', 'uploads/OddShape.png', 1, '', '', '2014-06-17', '', '2018-07-19 18:42:35', 'OddShape-Level2', 'OddShape-Level2'),
(16, 1, 59, 'GroupIt-Level2', '', 'Memory', 'uploads/GroupIt.png', 'uploads/GroupIt.png', 1, '', '', '2014-06-17', '', '2018-07-19 18:43:16', 'GroupIt-Level2', 'GroupIt-Level2'),
(17, 1, 59, 'WhoJoinsTheGroup', '', 'Memory', 'uploads/WhoJoinsTheGroup.png', 'uploads/WhoJoinsTheGroup.png', 1, '', '', '2014-06-17', '', '2018-07-19 18:44:28', 'WhoJoinsTheGroup', 'WhoJoinsTheGroup'),
(18, 1, 59, 'StrangerGrid-Level2', '', 'Memory', 'uploads/StrangerGrid.png', 'uploads/StrangerGrid.png', 1, '', '', '2014-06-17', '', '2018-07-19 18:47:29', 'StrangerGrid-Level2', 'StrangerGrid-Level2'),
(19, 1, 59, 'IconMatch-KG', '', 'Memory', 'uploads/IconMatch.png', 'uploads/IconMatch.png', 1, '', '', '2014-06-17', '', '2018-07-19 18:47:22', 'IconMatch-KG', 'IconMatch-KG'),
(20, 1, 59, 'SmileySeries-KG', '', 'Memory', 'uploads/SmileySeries.png', 'uploads/SmileySeries.png', 1, '', '', '2014-06-17', '', '2018-07-19 18:48:23', 'SmileySeries-KG', 'SmileySeries-KG'),
(21, 1, 59, 'BuddySpot-KG', '', 'Memory', 'uploads/BuddySpot.png', 'uploads/BuddySpot.png', 1, '', '', '2014-06-17', '', '2018-07-19 18:49:16', 'BuddySpot-KG', 'BuddySpot-KG'),
(22, 1, 59, 'AnimalRecall-KG', '', 'Memory', 'uploads/AnimalRecall.png', 'uploads/AnimalRecall.png', 1, '', '', '2014-06-17', '', '2018-07-19 18:50:12', 'AnimalRecall-KG', 'AnimalRecall-KG'),
(23, 1, 59, 'FruitDrop-KG', '', 'Memory', 'uploads/FruitDrop.png', 'uploads/FruitDrop.png', 1, '', '', '2014-06-17', '', '2018-07-19 18:51:25', 'FruitDrop-KG', 'FruitDrop-KG'),
(24, 1, 59, 'ShadowMatch-KG', '', 'Memory', 'uploads/ShadowMatch.png', 'uploads/ShadowMatch.png', 1, '', '', '2014-06-17', '', '2018-07-19 18:52:49', 'ShadowMatch-KG', 'ShadowMatch-KG'),
(25, 1, 59, 'FaceCut-KG', '', 'Memory', 'uploads/FaceCut.png', 'uploads/FaceCut.png', 1, '', '', '2014-06-17', '', '2018-07-19 18:54:03', 'FaceCut-KG', 'FaceCut-KG'),
(26, 1, 59, 'MatchMeObjects-KG', '', 'Memory', 'uploads/MatchMeObjects.png', 'uploads/MatchMeObjects.png', 1, '', '', '2014-06-17', '', '2018-07-19 18:55:33', 'MatchMeObjects-KG', 'MatchMeObjects-KG'),
(27, 1, 59, 'MysteryShape-KG', '', 'Memory', 'uploads/MysteryShape.png', 'uploads/MysteryShape.png', 1, '', '', '2014-06-17', '', '2018-07-22 14:27:17', 'MysteryShape-KG', 'MysteryShape-KG'),
(28, 1, 59, 'BestFit-KG', '', 'Memory', 'uploads/BestFit.png', 'uploads/BestFit.png', 1, '', '', '2014-06-17', '', '2018-07-19 18:56:49', 'BestFit-KG', 'BestFit-KG'),
(29, 1, 59, 'ShapeFocus-KG', '', 'Memory', 'uploads/ShapeFocus.png', 'uploads/ShapeFocus.png', 1, '', '', '2014-06-17', '', '2018-07-22 13:08:56', 'ShapeFocus-KG', 'ShapeFocus-KG'),
(30, 1, 59, 'ArrowHit-KG', '', 'Memory', 'uploads/ArrowHit.png', 'uploads/ArrowHit.png', 1, '', '', '2014-06-17', '', '2018-07-22 13:10:06', 'ArrowHit-KG', 'ArrowHit-KG'),
(31, 1, 59, 'ObjectMatch-KG', '', 'Memory', 'uploads/ObjectMatch.png', 'uploads/ObjectMatch.png', 1, '', '', '2014-06-17', '', '2018-07-22 13:11:42', 'ObjectMatch-KG', 'ObjectMatch-KG'),
(32, 1, 59, 'IconMatch-Level1', '', 'Memory', 'uploads/IconMatch.png', 'uploads/IconMatch.png', 1, '', '', '2014-06-17', '', '2018-07-22 13:12:30', 'IconMatch-Level1', 'IconMatch-Level1'),
(33, 1, 59, 'SmileySeries-Level1', '', 'Memory', 'uploads/SmileySeries.png', 'uploads/SmileySeries.png', 1, '', '', '2014-06-17', '', '2018-07-22 13:13:16', 'SmileySeries-Level1', 'SmileySeries-Level1'),
(34, 1, 59, 'BuddySpot-Level1', '', 'Memory', 'uploads/BuddySpot.png', 'uploads/BuddySpot.png', 1, '', '', '2014-06-17', '', '2018-07-22 13:14:13', 'BuddySpot-Level1', 'BuddySpot-Level1'),
(35, 1, 59, 'TransPortRecall-Level1', '', 'Memory', 'uploads/TransportRecall.png', 'uploads/TransportRecall.png', 1, '', '', '2014-06-17', '', '2018-08-31 00:33:42', 'TransPortRecall-Level1', 'TransportRecall-Level1'),
(36, 1, 59, 'BallDrop-Level1', '', 'Memory', 'uploads/BallDrop.png', 'uploads/BallDrop.png', 1, '', '', '2014-06-17', '', '2018-07-22 13:15:59', 'BallDrop-Level1', 'BallDrop-Level1'),
(37, 1, 59, 'ShadowMatch-Level1', '', 'Memory', 'uploads/ShadowMatch.png', 'uploads/ShadowMatch.png', 1, '', '', '2014-06-17', '', '2018-07-22 13:17:02', 'ShadowMatch-Level1', 'ShadowMatch-Level1'),
(38, 1, 59, 'FaceCut-Level1', '', 'Memory', 'uploads/FaceCut.png', 'uploads/FaceCut.png', 1, '', '', '2014-06-17', '', '2018-07-22 13:17:50', 'FaceCut-Level1', 'FaceCut-Level1'),
(39, 1, 59, 'MatchMeObjects-Level1', '', 'Memory', 'uploads/MatchMeObjects.png', 'uploads/MatchMeObjects.png', 1, '', '', '2014-06-17', '', '2018-07-22 13:20:03', 'MatchMeObjects-Level1', 'MatchMeObjects-Level1'),
(40, 1, 59, 'MysteryShape-Level1', '', 'Memory', 'uploads/MysteryShape.png', 'uploads/MysteryShape.png', 1, '', '', '2014-06-17', '', '2018-07-22 13:20:51', 'MysteryShape-Level1', 'MysteryShape-Level1'),
(41, 1, 59, 'BestFit-Level1', '', 'Memory', 'uploads/BestFit.png', 'uploads/BestFit.png', 1, '', '', '2014-06-17', '', '2018-07-22 13:21:51', 'BestFit-Level1', 'BestFit-Level1'),
(42, 1, 59, 'ShapeFocus-Level1', '', 'Memory', 'uploads/ShapeFocus.png', 'uploads/ShapeFocus.png', 1, '', '', '2014-06-17', '', '2018-07-22 13:22:43', 'ShapeFocus-Level1', 'ShapeFocus-Level1'),
(43, 1, 59, 'ArrowHit-Level1', '', 'Memory', 'uploads/ArrowHit.png', 'uploads/ArrowHit.png', 1, '', '', '2014-06-17', '', '2018-07-22 13:24:38', 'ArrowHit-Level1', 'ArrowHit-Level1'),
(44, 1, 59, 'ObjectMatch-Level1', '', 'Memory', 'uploads/ObjectMatch.png', 'uploads/ObjectMatch.png', 1, '', '', '2014-06-17', '', '2018-07-22 13:25:37', 'ObjectMatch-Level1', 'ObjectMatch-Level1'),
(45, 1, 59, 'IconMatch-Level2', '', 'Memory', 'uploads/IconMatch.png', 'uploads/IconMatch.png', 1, '', '', '2014-06-17', '', '2018-07-22 13:26:54', 'IconMatch-Level2', 'IconMatch-Level2'),
(46, 1, 59, 'SmileySeries-Level2', '', 'Memory', 'uploads/SmileySeries.png', 'uploads/SmileySeries.png', 1, '', '', '2014-06-17', '', '2018-07-22 13:27:51', 'SmileySeries-Level2', 'SmileySeries-Level2'),
(47, 1, 59, 'BuddySpot-Level2', '', 'Memory', 'uploads/BuddySpot.png', 'uploads/BuddySpot.png', 1, '', '', '2014-06-17', '', '2018-07-22 13:29:00', 'BuddySpot-Level2', 'BuddySpot-Level2'),
(48, 1, 59, 'BirdRecall-Level2', '', 'Memory', 'uploads/BirdRecall.png', 'uploads/BirdRecall.png', 1, '', '', '2014-06-17', '', '2018-07-22 13:31:07', 'BirdRecall-Level2', 'BirdRecall-Level2'),
(49, 1, 59, 'ShapeDrop-Level2', '', 'Memory', 'uploads/ShapeDrop.png', 'uploads/ShapeDrop.png', 1, '', '', '2014-06-17', '', '2018-07-22 13:31:55', 'ShapeDrop-Level2', 'ShapeDrop-Level2'),
(50, 1, 59, 'FaceCut-Level2', '', 'Memory', 'uploads/FaceCut.png', 'uploads/FaceCut.png', 1, '', '', '2014-06-17', '', '2018-07-22 13:33:45', 'FaceCut-Level2', 'FaceCut-Level2'),
(51, 1, 59, 'MatchMeObjects-Level2', '', 'Memory', 'uploads/MatchMeObjects.png', 'uploads/MatchMeObjects.png', 1, '', '', '2014-06-17', '', '2018-07-22 13:35:55', 'MatchMeObjects-Level2', 'MatchMeObjects-Level2'),
(52, 1, 59, 'MysteryShape-Level2', '', 'Memory', 'uploads/MysteryShape.png', 'uploads/MysteryShape.png', 1, '', '', '2014-06-17', '', '2018-07-22 13:36:39', 'MysteryShape-Level2', 'MysteryShape-Level2'),
(53, 1, 59, 'BestFit-Level2', '', 'Memory', 'uploads/BestFit.png', 'uploads/BestFit.png', 1, '', '', '2014-06-17', '', '2018-07-22 13:37:55', 'BestFit-Level2', 'BestFit-Level2'),
(54, 1, 59, 'ShapeFocus-Level2', '', 'Memory', 'uploads/ShapeFocus.png', 'uploads/ShapeFocus.png', 1, '', '', '2014-06-17', '', '2018-07-22 13:38:46', 'ShapeFocus-Level2', 'ShapeFocus-Level2'),
(55, 1, 59, 'ArrowHit-Level2', '', 'Memory', 'uploads/ArrowHit.png', 'uploads/ArrowHit.png', 1, '', '', '2014-06-17', '', '2018-07-22 13:39:37', 'ArrowHit-Level2', 'ArrowHit-Level2'),
(56, 1, 59, 'ObjectMatch-Level2', '', 'Memory', 'uploads/ObjectMatch.png', 'uploads/ObjectMatch.png', 1, '', '', '2014-06-17', '', '2018-07-22 13:40:52', 'ObjectMatch-Level2', 'ObjectMatch-Level2'),
(57, 1, 59, 'BigSmall-KG', '', 'Memory', 'uploads/BigSmall.png', 'uploads/BigSmall.png', 1, '', '', '2014-06-17', '', '2018-07-22 13:41:51', 'BigSmall-KG', 'BigSmall-KG'),
(58, 1, 59, 'BigSmall-Level1', '', 'Memory', 'uploads/BigSmall.png', 'uploads/BigSmall.png', 1, '', '', '2014-06-17', '', '2018-07-22 13:42:25', 'BigSmall-Level1', 'BigSmall-Level1'),
(59, 1, 59, 'BigSmall-Level2', '', 'Memory', 'uploads/BigSmall.png', 'uploads/BigSmall.png', 1, '', '', '2014-06-17', '', '2018-07-22 13:43:04', 'BigSmall-Level2', 'BigSmall-Level2'),
(60, 1, 59, 'ImageSequence-KG', '', 'Memory', 'uploads/ImageSequence.png', 'uploads/ImageSequence.png', 1, '', '', '2014-06-17', '', '2018-07-22 13:50:16', 'ImageSequence-KG', 'ImageSequence-KG'),
(61, 1, 59, 'GroupRepresentation-KG', '', 'Memory', 'uploads/GroupRepresentation.png', 'uploads/GroupRepresentation.png', 1, '', '', '2014-06-17', '', '2018-07-22 13:51:10', 'GroupRepresentation-KG', 'GroupRepresentation-KG'),
(62, 1, 59, 'ImageSequence-Level1', '', 'Memory', 'uploads/ImageSequence.png', 'uploads/ImageSequence.png', 1, '', '', '2014-06-17', '', '2018-07-22 13:51:53', 'ImageSequence-Level1', 'ImageSequence-Level1'),
(63, 1, 59, ' GroupRepresentation-Level1', '', 'Memory', 'uploads/GroupRepresentation.png', 'uploads/GroupRepresentation.png', 1, '', '', '2014-06-17', '', '2018-10-25 02:03:10', 'GroupRepresentation-Level1', 'GroupRepresentation-Level1'),
(64, 1, 59, 'ImageSequence-Level2', '', 'Memory', 'uploads/ImageSequence.png', 'uploads/ImageSequence.png', 1, '', '', '2014-06-17', '', '2018-07-22 13:53:42', 'ImageSequence-Level2', 'ImageSequence-Level2'),
(65, 1, 59, 'PatternRepresentation-Level2', '', 'Memory', 'uploads/PatternRepresentation.png', 'uploads/PatternRepresentation.png', 1, '', '', '2014-06-17', '', '2018-07-22 13:54:47', 'PatternRepresentation-Level2', 'PatternRepresentation-Level2'),
(66, 1, 59, 'WhoHits-KG', '', 'Memory', 'uploads/WhoHits.png', 'uploads/WhoHits.png', 1, '', '', '2014-06-17', '', '2018-07-22 13:56:19', 'WhoHits-KG', 'WhoHits-KG'),
(67, 1, 59, 'TheFinishLine-KG', '', 'Memory', 'uploads/TheFinishLine.png', 'uploads/TheFinishLine.png', 1, '', '', '2014-06-17', '', '2018-07-22 13:57:29', 'TheFinishLine-KG', 'TheFinishLine-KG'),
(68, 1, 59, 'PathTrace-KG', '', 'Memory', 'uploads/PathTrace.png', 'uploads/PathTrace.png', 1, '', '', '2014-06-17', '', '2018-07-22 13:58:35', 'PathTrace-KG', 'PathTrace-KG'),
(69, 1, 59, 'LostLastPart-KG', '', 'Memory', 'uploads/LostLastPart.png', 'uploads/LostLastPart.png', 1, '', '', '2014-06-17', '', '2018-07-22 13:59:28', 'LostLastPart-KG', 'LostLastPart-KG'),
(70, 1, 59, 'ShapeGrid-KG', '', 'Memory', 'uploads/ShapeGrid.png', 'uploads/ShapeGrid.png', 1, '', '', '2014-06-17', '', '2018-07-22 14:00:23', 'ShapeGrid-KG', 'ShapeGrid-KG'),
(71, 1, 59, 'WhoHits-Level1', '', 'Memory', 'uploads/WhoHits.png', 'uploads/WhoHits.png', 1, '', '', '2014-06-17', '', '2018-07-22 14:01:26', 'WhoHits-Level1', 'WhoHits-Level1'),
(72, 1, 59, 'TheFinishLine-Level1', '', 'Memory', 'uploads/TheFinishLine.png', 'uploads/TheFinishLine.png', 1, '', '', '2014-06-17', '', '2018-07-22 14:02:24', 'TheFinishLine-Level1', 'TheFinishLine-Level1'),
(73, 1, 59, 'PathTrace-Level1', '', 'Memory', 'uploads/PathTrace.png', 'uploads/PathTrace.png', 1, '', '', '2014-06-17', '', '2018-07-22 14:03:14', 'PathTrace-Level1', 'PathTrace-Level1'),
(74, 1, 59, 'LostLastPart-Level1', '', 'Memory', 'uploads/LostLastPart.png', 'uploads/LostLastPart.png', 1, '', '', '2014-06-17', '', '2018-07-22 14:04:06', 'LostLastPart-Level1', 'LostLastPart-Level1'),
(75, 1, 59, 'ShapeGrid-Level1', '', 'Memory', 'uploads/ShapeGrid.png', 'uploads/ShapeGrid.png', 1, '', '', '2014-06-17', '', '2018-07-22 14:05:13', 'ShapeGrid-Level1', 'ShapeGrid-Level1'),
(76, 1, 59, 'WhoHits-Level2', '', 'Memory', 'uploads/WhoHits.png', 'uploads/WhoHits.png', 1, '', '', '2014-06-17', '', '2018-07-22 14:06:19', 'WhoHits-Level2', 'WhoHits-Level2'),
(77, 1, 59, 'TheFinishLine-Level2', '', 'Memory', 'uploads/TheFinishLine.png', 'uploads/TheFinishLine.png', 1, '', '', '2014-06-17', '', '2018-07-22 14:07:26', 'TheFinishLine-Level2', 'TheFinishLine-Level2'),
(78, 1, 59, 'PathTrace-Level2', '', 'Memory', 'uploads/PathTrace.png', 'uploads/PathTrace.png', 1, '', '', '2014-06-17', '', '2018-07-22 14:08:15', 'PathTrace-Level2', 'PathTrace-Level2'),
(79, 1, 59, 'LostLastPart-Level2', '', 'Memory', 'uploads/LostLastPart.png', 'uploads/LostLastPart.png', 1, '', '', '2014-06-17', '', '2018-07-22 14:09:17', 'LostLastPart-Level2', 'LostLastPart-Level2'),
(80, 1, 59, 'ShapeGrid-Level2', '', 'Memory', 'uploads/ShapeGrid.png', 'uploads/ShapeGrid.png', 1, '', '', '2014-06-17', '', '2018-07-22 14:10:04', 'ShapeGrid-Level2', 'ShapeGrid-Level2'),
(81, 1, 59, 'LocateTheParts-KG', '', 'Memory', 'uploads/LocateTheParts.png', 'uploads/LocateTheParts.png', 1, '', '', '2014-06-17', '', '2018-07-22 14:12:16', 'LocateTheParts-KG', 'LocateTheParts-KG'),
(82, 1, 59, 'JackInTheBox-KG', '', 'Memory', 'uploads/JackInTheBox.png', 'uploads/JackInTheBox.png', 1, '', '', '2014-06-17', '', '2018-07-22 14:13:27', 'JackInTheBox-KG', 'JackInTheBox-KG'),
(83, 1, 59, 'AddOn-KG', '', 'Memory', 'uploads/AddOn.png', 'uploads/AddOn.png', 1, '', '', '2014-06-17', '', '2018-07-22 14:14:17', 'AddOn-KG', 'AddOn-KG'),
(84, 1, 59, 'LocateTheParts-Level1', '', 'Memory', 'uploads/LocateTheParts.png', 'uploads/LocateTheParts.png', 1, '', '', '2014-06-17', '', '2018-07-22 14:15:07', 'LocateTheParts-Level1', 'LocateTheParts-Level1'),
(85, 1, 59, 'JackInTheBox-Level1', '', 'Memory', 'uploads/JackInTheBox.png', 'uploads/JackInTheBox.png', 1, '', '', '2014-06-17', '', '2018-07-22 14:15:49', 'JackInTheBox-Level1', 'JackInTheBox-Level1'),
(86, 1, 59, 'AddOn-Level1', '', 'Memory', 'uploads/AddOn.png', 'uploads/AddOn.png', 1, '', '', '2014-06-17', '', '2018-07-22 14:17:05', 'AddOn-Level1', 'AddOn-Level1'),
(87, 1, 59, 'LocateTheParts-Level2', '', 'Memory', 'uploads/LocateTheParts.png', 'uploads/LocateTheParts.png', 1, '', '', '2014-06-17', '', '2018-07-22 14:18:09', 'LocateTheParts-Level2', 'LocateTheParts-Level2'),
(88, 1, 59, 'JackInTheBox-Level2', '', 'Memory', 'uploads/JackInTheBox.png', 'uploads/JackInTheBox.png', 1, '', '', '2014-06-17', '', '2018-07-22 14:19:06', 'JackInTheBox-Level2', 'JackInTheBox-Level2'),
(89, 1, 59, 'AddOn-Level2', '', 'Memory', 'uploads/AddOn.png', 'uploads/AddOn.png', 1, '', '', '2014-06-17', '', '2018-07-22 14:19:59', 'AddOn-Level2', 'AddOn-Level2'),
(90, 1, 59, 'ShadowMatch-Level2', '', 'Memory', 'uploads/ShadowMatch.png', 'uploads/ShadowMatch.png', 1, '', '', '2014-06-17', '', '2018-07-22 14:37:34', 'ShadowMatch-Level2', 'ShadowMatch-Level2');

-- --------------------------------------------------------

--
-- Table structure for table `gamescore`
--

CREATE TABLE `gamescore` (
  `id` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `gameid` int(11) NOT NULL,
  `skillid` int(11) NOT NULL,
  `gc_id` int(11) NOT NULL,
  `gp_id` int(11) NOT NULL,
  `iteration` int(11) NOT NULL,
  `quesionid` int(11) NOT NULL,
  `timervalue` int(11) NOT NULL,
  `responsetime` int(11) NOT NULL,
  `answerstatus` enum('C','W','U') NOT NULL,
  `correctanswer` varchar(100) NOT NULL,
  `useranswer` varchar(100) NOT NULL,
  `score` int(11) NOT NULL,
  `updateddate` datetime NOT NULL,
  `status` enum('0','1') NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `games_cq`
--

CREATE TABLE `games_cq` (
  `gid` int(100) NOT NULL,
  `grade_id` int(11) NOT NULL,
  `gp_id` int(11) NOT NULL,
  `gname` varchar(100) NOT NULL,
  `path` varchar(500) NOT NULL,
  `descs` varchar(500) NOT NULL,
  `img_path` varchar(100) NOT NULL,
  `gstatus` int(1) NOT NULL,
  `game_html` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `games_cq`
--

INSERT INTO `games_cq` (`gid`, `grade_id`, `gp_id`, `gname`, `path`, `descs`, `img_path`, `gstatus`, `game_html`) VALUES
(1, 5, 3, 'AlphaNumericEncode-Level1', '', 'CHQ1', 'uploads/AlphaNumericEncode-Level1_4518458847.png', 1, 'AlphaNumericEncode-Level1'),
(2, 5, 3, 'CycleRace-Level1', '', 'CHQ2', 'uploads/CycleRace-Level1_2532993447.png', 1, 'CycleRace-Level1'),
(3, 11, 91, 'BestFit-Level3', '', 'CHQ2', 'uploads/BestFit-Level2_6896948479.png', 1, 'BestFit-Level3');

-- --------------------------------------------------------

--
-- Table structure for table `game_groupmaster`
--

CREATE TABLE `game_groupmaster` (
  `id` int(11) NOT NULL,
  `groupname` varchar(110) NOT NULL,
  `code` varchar(55) NOT NULL,
  `status` int(11) NOT NULL,
  `created_on` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `game_groupmaster`
--

INSERT INTO `game_groupmaster` (`id`, `groupname`, `code`, `status`, `created_on`) VALUES
(1, 'Classification', 'CE', 1, '2018-07-18 00:00:00'),
(2, 'Matching', 'CE', 1, '2018-07-18 00:00:00'),
(3, 'Seriation', 'CE', 1, '2018-07-18 00:00:00'),
(4, 'Pattern', 'CE', 1, '2018-07-18 00:00:00'),
(5, 'Analytical', 'CE', 1, '2018-07-18 00:00:00'),
(6, 'Memory', 'CE', 1, '2018-07-18 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `game_group_mapping`
--

CREATE TABLE `game_group_mapping` (
  `id` int(11) NOT NULL,
  `org_id` int(11) NOT NULL COMMENT 'organization id',
  `grade_id` int(11) NOT NULL,
  `groupid` int(11) NOT NULL COMMENT 'Group ID',
  `gid` int(11) NOT NULL COMMENT 'Game ID',
  `status` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `game_group_mapping`
--

INSERT INTO `game_group_mapping` (`id`, `org_id`, `grade_id`, `groupid`, `gid`, `status`) VALUES
(1, 1, 11, 1, 1, 1),
(2, 1, 11, 1, 2, 1),
(3, 1, 11, 1, 3, 1),
(4, 1, 11, 1, 4, 1),
(5, 1, 11, 1, 5, 1),
(6, 1, 11, 1, 6, 1),
(7, 1, 1, 1, 7, 1),
(8, 1, 1, 1, 8, 1),
(9, 1, 1, 1, 9, 1),
(10, 1, 1, 1, 10, 1),
(11, 1, 1, 1, 11, 1),
(12, 1, 1, 1, 12, 1),
(13, 1, 2, 1, 13, 1),
(14, 1, 2, 1, 14, 1),
(15, 1, 2, 1, 15, 1),
(16, 1, 2, 1, 16, 1),
(17, 1, 2, 1, 17, 1),
(18, 1, 2, 1, 18, 1),
(19, 1, 11, 2, 19, 1),
(20, 1, 11, 2, 20, 1),
(21, 1, 11, 2, 21, 1),
(22, 1, 11, 2, 22, 1),
(23, 1, 11, 2, 23, 1),
(24, 1, 11, 2, 24, 1),
(25, 1, 11, 2, 25, 1),
(26, 1, 11, 2, 26, 1),
(27, 1, 11, 2, 27, 1),
(28, 1, 11, 2, 28, 1),
(29, 1, 11, 2, 29, 1),
(30, 1, 11, 2, 30, 1),
(31, 1, 11, 2, 31, 1),
(32, 1, 1, 2, 32, 1),
(33, 1, 1, 2, 33, 1),
(34, 1, 1, 2, 34, 1),
(35, 1, 1, 2, 35, 1),
(36, 1, 1, 2, 36, 1),
(37, 1, 1, 2, 37, 1),
(38, 1, 1, 2, 38, 1),
(39, 1, 1, 2, 39, 1),
(40, 1, 1, 2, 40, 1),
(41, 1, 1, 2, 41, 1),
(42, 1, 1, 2, 42, 1),
(43, 1, 1, 2, 43, 1),
(44, 1, 1, 2, 44, 1),
(45, 1, 2, 2, 45, 1),
(46, 1, 2, 2, 46, 1),
(47, 1, 2, 2, 47, 1),
(48, 1, 2, 2, 48, 1),
(49, 1, 2, 2, 49, 1),
(50, 1, 2, 2, 90, 1),
(51, 1, 2, 2, 50, 1),
(52, 1, 2, 2, 51, 1),
(53, 1, 2, 2, 52, 1),
(54, 1, 2, 2, 53, 1),
(55, 1, 2, 2, 54, 1),
(56, 1, 2, 2, 55, 1),
(57, 1, 2, 2, 56, 1),
(58, 1, 11, 3, 57, 1),
(59, 1, 1, 3, 58, 1),
(60, 1, 2, 3, 59, 1),
(61, 1, 11, 4, 60, 1),
(62, 1, 11, 4, 61, 1),
(63, 1, 1, 4, 62, 1),
(64, 1, 1, 4, 63, 1),
(65, 1, 2, 4, 64, 1),
(66, 1, 2, 4, 65, 1),
(67, 1, 11, 5, 66, 1),
(68, 1, 11, 5, 67, 1),
(69, 1, 11, 5, 68, 1),
(70, 1, 11, 5, 69, 1),
(71, 1, 11, 5, 70, 1),
(72, 1, 1, 5, 71, 1),
(73, 1, 1, 5, 72, 1),
(74, 1, 1, 5, 73, 1),
(75, 1, 1, 5, 74, 1),
(76, 1, 1, 5, 75, 1),
(77, 1, 2, 5, 76, 1),
(78, 1, 2, 5, 77, 1),
(79, 1, 2, 5, 78, 1),
(80, 1, 2, 5, 79, 1),
(81, 1, 2, 5, 80, 1),
(82, 1, 11, 6, 81, 1),
(83, 1, 11, 6, 82, 1),
(84, 1, 11, 6, 83, 1),
(85, 1, 1, 6, 84, 1),
(86, 1, 1, 6, 85, 1),
(87, 1, 1, 6, 86, 1),
(88, 1, 2, 6, 87, 1),
(89, 1, 2, 6, 88, 1),
(90, 1, 2, 6, 89, 1);

-- --------------------------------------------------------

--
-- Table structure for table `game_language_track`
--

CREATE TABLE `game_language_track` (
  `ID` int(11) NOT NULL,
  `gameID` int(11) NOT NULL,
  `userID` int(11) NOT NULL,
  `languageID` int(11) NOT NULL,
  `skillkit` int(11) NOT NULL,
  `createddatetime` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `game_levels`
--

CREATE TABLE `game_levels` (
  `id` int(11) NOT NULL,
  `level` varchar(30) NOT NULL,
  `status` int(1) NOT NULL,
  `createdby` varchar(100) NOT NULL,
  `creation_date` date NOT NULL,
  `modifiedby` varchar(100) NOT NULL,
  `modified_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `game_limit`
--

CREATE TABLE `game_limit` (
  `id` int(11) NOT NULL,
  `gc_id` int(11) NOT NULL,
  `gs_id` int(11) NOT NULL,
  `g_id` int(11) NOT NULL,
  `gp_id` int(11) NOT NULL,
  `ntimes` int(11) NOT NULL,
  `createdby` varchar(100) NOT NULL,
  `creation_date` date NOT NULL,
  `modifiedby` varchar(100) NOT NULL,
  `modified_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Stand-in structure for view `game_reports`
-- (See below for the actual view)
--
CREATE TABLE `game_reports` (
`id` int(11)
,`gu_id` int(10)
,`gp_id` varchar(100)
,`gc_id` int(10)
,`gs_id` int(10)
,`groupid` bigint(11)
,`g_id` int(30)
,`total_question` varchar(15)
,`attempt_question` varchar(20)
,`answer` varchar(20)
,`game_score` varchar(50)
,`gtime` varchar(100)
,`rtime` varchar(100)
,`crtime` varchar(100)
,`wrtime` varchar(100)
,`lastupdate` date
,`star` int(11)
,`puzzle_cycle` int(11)
,`site_type` enum('APP','WEB')
);

-- --------------------------------------------------------

--
-- Table structure for table `g_category`
--

CREATE TABLE `g_category` (
  `id` int(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `description` varchar(100) NOT NULL,
  `status` int(1) NOT NULL,
  `createdby` varchar(100) NOT NULL,
  `creation_date` date NOT NULL,
  `modifiedby` varchar(100) NOT NULL,
  `modified_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `g_category`
--

INSERT INTO `g_category` (`id`, `name`, `description`, `status`, `createdby`, `creation_date`, `modifiedby`, `modified_date`) VALUES
(1, 'Brain Skills', 'Cognitive Development', 1, '', '0000-00-00', '', '2014-06-01 03:57:11'),
(5, 'Curriculum', 'Academic Subjects', 1, '', '0000-00-00', '', '2014-06-01 03:57:33'),
(6, 'Life Skills', 'Life Skill Development', 1, '', '0000-00-00', '', '2014-05-31 08:03:42');

-- --------------------------------------------------------

--
-- Table structure for table `g_plans`
--

CREATE TABLE `g_plans` (
  `id` int(100) NOT NULL,
  `grade_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `validity` int(100) NOT NULL,
  `pricewaos` int(100) NOT NULL,
  `pricewoaos` int(100) NOT NULL,
  `ngames` int(100) NOT NULL,
  `bprof` int(1) NOT NULL,
  `gwpt` int(1) NOT NULL,
  `lspc` int(1) NOT NULL,
  `mpc` int(1) NOT NULL,
  `eepc` int(1) NOT NULL,
  `cspt` int(1) NOT NULL,
  `obspi` int(1) NOT NULL,
  `ioapt` int(1) NOT NULL,
  `oacr` int(1) NOT NULL,
  `oagcr` int(1) NOT NULL,
  `oascr` int(1) NOT NULL,
  `status` int(1) NOT NULL,
  `createdby` varchar(100) NOT NULL,
  `creation_date` date NOT NULL,
  `modifiedby` varchar(100) NOT NULL,
  `modified_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `g_plans`
--

INSERT INTO `g_plans` (`id`, `grade_id`, `name`, `validity`, `pricewaos`, `pricewoaos`, `ngames`, `bprof`, `gwpt`, `lspc`, `mpc`, `eepc`, `cspt`, `obspi`, `ioapt`, `oacr`, `oagcr`, `oascr`, `status`, `createdby`, `creation_date`, `modifiedby`, `modified_date`) VALUES
(1, 3, 'PerformancePowerPack-I', 365, 1550, 1250, 40, 1, 1, 1, 1, 0, 1, 1, 0, 0, 0, 0, 1, '', '0000-00-00', '', '2014-06-15 05:48:03'),
(2, 4, 'PerformancePowerPack-II', 365, 1550, 1250, 40, 1, 1, 1, 1, 0, 1, 1, 0, 0, 0, 0, 1, '', '0000-00-00', '', '2014-06-15 05:48:41'),
(3, 5, 'PerformancePowerPack-III', 365, 1550, 1250, 40, 1, 1, 1, 1, 0, 1, 1, 0, 0, 0, 0, 1, '', '0000-00-00', '', '2014-06-15 05:50:37'),
(4, 6, 'PerformancePowerPack-IV', 365, 1550, 1250, 40, 1, 1, 1, 1, 0, 1, 1, 0, 0, 0, 0, 1, '', '0000-00-00', '', '2014-06-15 05:51:16'),
(5, 7, 'PerformancePowerPack-V', 365, 1550, 1250, 40, 1, 1, 1, 1, 0, 1, 1, 0, 0, 0, 0, 1, '', '0000-00-00', '', '2014-06-15 05:51:45'),
(6, 8, 'PerformancePowerPack-VI', 365, 1550, 1250, 40, 1, 1, 1, 1, 0, 1, 1, 0, 0, 0, 0, 1, '', '0000-00-00', '', '2014-06-15 05:52:15'),
(7, 9, 'PerformancePowerPack-VII', 365, 1550, 1250, 40, 1, 1, 1, 1, 0, 1, 1, 0, 0, 0, 0, 1, '', '0000-00-00', '', '2014-06-15 05:52:50'),
(8, 10, 'PerformancePowerPack-VIII', 365, 1550, 1250, 40, 1, 1, 1, 1, 0, 1, 1, 0, 0, 0, 0, 1, '', '0000-00-00', '', '2014-06-15 05:53:58'),
(9, 110, 'CSSPlanL0', 180, 1550, 1250, 40, 1, 1, 1, 1, 0, 1, 1, 0, 0, 0, 0, 1, '', '0000-00-00', '', '2018-06-18 07:31:02'),
(10, 1, 'PerformancePowerPack-LKG', 365, 1550, 1250, 40, 1, 1, 1, 1, 0, 1, 1, 0, 0, 0, 0, 1, '', '0000-00-00', '', '2014-06-24 03:17:10'),
(11, 2, 'PerformancePowerPack-UKG', 365, 1550, 1250, 40, 1, 1, 1, 1, 0, 1, 1, 0, 0, 0, 0, 1, '', '0000-00-00', '', '2014-06-24 03:17:54'),
(12, 1, 'PerformancePack-LKG', 365, 1100, 800, 30, 1, 1, 0, 0, 0, 1, 1, 0, 0, 0, 0, 1, '', '0000-00-00', '', '2014-07-07 05:18:25'),
(13, 2, 'PerformancePack-UKG', 365, 1100, 800, 30, 1, 1, 0, 0, 0, 1, 1, 0, 0, 0, 0, 1, '', '0000-00-00', '', '2014-07-07 05:19:06'),
(14, 3, 'PerformancePack-I', 365, 1100, 800, 30, 1, 1, 0, 0, 0, 1, 1, 0, 0, 0, 0, 1, '', '0000-00-00', '', '2014-07-07 05:19:43'),
(15, 4, 'PerformancePack-II', 365, 1100, 800, 30, 1, 1, 0, 0, 0, 1, 1, 0, 0, 0, 0, 1, '', '0000-00-00', '', '2014-07-07 05:25:15'),
(16, 5, 'PerformancePack-III', 365, 1100, 800, 30, 1, 1, 0, 0, 0, 1, 1, 0, 0, 0, 0, 1, '', '0000-00-00', '', '2014-07-07 05:28:06'),
(17, 6, 'PerformancePack-IV', 365, 1100, 800, 30, 1, 1, 0, 0, 0, 1, 1, 0, 0, 0, 0, 1, '', '0000-00-00', '', '2014-07-07 05:28:46'),
(18, 7, 'PerformancePack-V', 365, 1100, 800, 30, 1, 1, 0, 0, 0, 1, 1, 0, 0, 0, 0, 1, '', '0000-00-00', '', '2014-07-07 05:30:38'),
(19, 8, 'PerformancePack-VI', 365, 1100, 800, 30, 1, 1, 0, 0, 0, 1, 1, 0, 0, 0, 0, 1, '', '0000-00-00', '', '2014-07-07 05:31:33'),
(20, 9, 'PerformancePack-VII', 365, 1100, 800, 30, 1, 1, 0, 0, 0, 1, 1, 0, 0, 0, 0, 1, '', '0000-00-00', '', '2014-07-07 05:33:36'),
(21, 10, 'PerformancePack-VIII', 365, 1100, 800, 30, 1, 1, 0, 0, 0, 1, 1, 0, 0, 0, 0, 1, '', '0000-00-00', '', '2014-07-07 05:34:39'),
(22, 1, 'PerformancePPE-LKG', 365, 1550, 1250, 40, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, '', '0000-00-00', '', '2014-07-15 00:56:32'),
(23, 2, 'PerformancePPE-UKG', 365, 1550, 1250, 40, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, '', '0000-00-00', '', '2014-07-15 00:57:04'),
(24, 3, 'PerformancePPE-I', 365, 1550, 1250, 40, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, '', '0000-00-00', '', '2014-07-15 00:57:39'),
(25, 4, 'PerformancePPE-II', 365, 1550, 1250, 40, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, '', '0000-00-00', '', '2014-07-15 00:58:07'),
(26, 5, 'PerformancePPE-III', 365, 1550, 1250, 40, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, '', '0000-00-00', '', '2014-07-15 00:58:38'),
(27, 6, 'PerformancePPE-IV', 365, 1550, 1250, 40, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, '', '0000-00-00', '', '2014-07-15 00:59:31'),
(28, 7, 'PerformancePPE-V', 365, 1550, 1250, 40, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, '', '0000-00-00', '', '2014-07-15 01:00:29'),
(29, 8, 'PerformancePPE-VI', 365, 1550, 1250, 40, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, '', '0000-00-00', '', '2014-07-15 01:02:07'),
(30, 9, 'PerformancePPE-VII', 365, 1550, 1250, 40, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, '', '0000-00-00', '', '2014-07-15 01:02:36'),
(31, 10, 'PerformancePPE-VIII', 365, 1550, 1250, 40, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, '', '0000-00-00', '', '2014-07-15 01:03:06'),
(32, 5, 'Summer Champ - Ashram III', 62, 0, 300, 30, 1, 1, 0, 0, 0, 0, 1, 1, 0, 0, 0, 1, '', '0000-00-00', '', '2015-04-28 07:26:33'),
(33, 6, 'Summer Champ - Ashram IV', 62, 0, 300, 30, 1, 1, 0, 0, 0, 0, 1, 1, 0, 0, 0, 1, '', '0000-00-00', '', '2015-04-28 07:27:20'),
(34, 7, 'Summer Champ - Ashram V', 62, 0, 300, 30, 1, 1, 0, 0, 0, 0, 1, 1, 0, 0, 0, 1, '', '0000-00-00', '', '2015-04-28 07:28:12'),
(35, 8, 'Summer Champ - Ashram VI', 62, 0, 300, 30, 1, 1, 0, 0, 0, 0, 1, 1, 0, 0, 0, 1, '', '0000-00-00', '', '2015-04-28 07:30:42'),
(36, 9, 'Summer Champ - Ashram VII', 62, 0, 300, 30, 1, 1, 0, 0, 0, 0, 1, 1, 0, 0, 0, 1, '', '0000-00-00', '', '2015-04-28 07:33:21'),
(37, 10, 'Summer Champ - Ashram VIII', 62, 0, 300, 30, 1, 1, 0, 0, 0, 0, 1, 1, 0, 0, 0, 1, '', '0000-00-00', '', '2015-04-28 07:34:14'),
(38, 2, 'Summer Champ - Ashram UKG', 62, 0, 300, 30, 1, 1, 0, 0, 0, 0, 1, 1, 0, 0, 0, 1, '', '0000-00-00', '', '2015-04-28 07:34:53'),
(39, 3, 'Summer Champ - Ashram I', 62, 0, 300, 30, 1, 1, 0, 0, 0, 0, 1, 1, 0, 0, 0, 1, '', '0000-00-00', '', '2015-04-28 07:35:51'),
(40, 4, 'Summer Champ - Ashram II', 62, 0, 300, 30, 1, 1, 0, 0, 0, 0, 1, 1, 0, 0, 0, 1, '', '0000-00-00', '', '2015-04-28 07:36:21'),
(41, 1, 'SASC-LKG', 31, 0, 300, 30, 1, 1, 0, 0, 0, 1, 1, 0, 0, 0, 0, 1, '', '0000-00-00', '', '2015-05-12 21:18:40'),
(42, 2, 'SASC-UKG', 31, 0, 300, 30, 1, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, '', '0000-00-00', '', '2015-05-12 21:21:02'),
(43, 3, 'SASC-I', 31, 0, 300, 30, 1, 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, '', '0000-00-00', '', '2015-05-12 21:21:34'),
(44, 4, 'SASC-II', 31, 0, 300, 30, 1, 1, 0, 0, 0, 1, 1, 0, 0, 0, 0, 1, '', '0000-00-00', '', '2015-05-12 21:22:24'),
(45, 5, 'SASC-III', 31, 0, 300, 30, 1, 1, 0, 0, 0, 1, 1, 0, 0, 0, 0, 1, '', '0000-00-00', '', '2015-05-12 21:23:01'),
(46, 6, 'SASC-IV', 31, 0, 300, 30, 1, 1, 0, 0, 0, 1, 1, 0, 0, 0, 0, 1, '', '0000-00-00', '', '2015-05-12 21:23:53'),
(47, 7, 'SASC-V', 31, 0, 300, 30, 1, 1, 0, 0, 0, 1, 1, 0, 0, 0, 0, 1, '', '0000-00-00', '', '2015-05-12 21:26:58'),
(48, 8, 'SASC-VI', 31, 0, 300, 30, 1, 1, 0, 0, 0, 1, 1, 0, 0, 0, 0, 1, '', '0000-00-00', '', '2015-05-12 21:27:38'),
(49, 9, 'SASC-VII', 31, 0, 300, 30, 1, 1, 0, 0, 0, 1, 1, 0, 0, 0, 0, 1, '', '0000-00-00', '', '2015-05-12 21:28:09'),
(50, 10, 'SASC-VIII', 31, 0, 300, 30, 1, 1, 0, 0, 0, 1, 1, 0, 0, 0, 0, 1, '', '0000-00-00', '', '2015-05-12 21:28:41'),
(51, 1, 'SASK-LKG', 365, 0, 1500, 40, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 1, '', '0000-00-00', '', '2015-05-13 04:41:38'),
(52, 2, 'SASK-UKG', 365, 0, 1500, 40, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, '', '0000-00-00', '', '2015-05-13 04:42:09'),
(53, 3, 'SASK-I', 365, 0, 1500, 40, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 1, '', '0000-00-00', '', '2015-05-13 04:43:20'),
(54, 4, 'SASK-II', 365, 0, 365, 40, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 1, '', '0000-00-00', '', '2015-05-13 04:44:06'),
(55, 5, 'SASK-III', 365, 0, 1500, 40, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 1, '', '0000-00-00', '', '2015-05-13 04:45:12'),
(56, 6, 'SASK-IV', 365, 0, 1500, 40, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 1, '', '0000-00-00', '', '2015-05-13 04:47:14'),
(57, 7, 'SASK-V', 365, 0, 1500, 40, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 1, '', '0000-00-00', '', '2015-05-13 04:47:45'),
(58, 8, 'SASK-VI', 1500, 0, 1500, 40, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 1, '', '0000-00-00', '', '2015-05-13 04:48:42'),
(59, 9, 'SASK-VII', 365, 0, 1500, 40, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 1, '', '0000-00-00', '', '2015-05-13 04:49:22'),
(60, 10, 'SASK-VIII', 365, 0, 1500, 40, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 1, '', '0000-00-00', '', '2015-05-13 04:50:15'),
(61, 7, 'OFAP-V', 30, 0, 0, 30, 1, 1, 1, 1, 0, 1, 1, 0, 0, 0, 0, 1, '', '0000-00-00', '', '2015-08-02 21:50:26'),
(62, 8, 'OFAP-VI', 30, 0, 0, 30, 1, 1, 1, 1, 0, 1, 1, 0, 0, 0, 0, 1, '', '0000-00-00', '', '2015-08-02 21:50:50'),
(63, 9, 'OFAP-VII', 30, 0, 0, 30, 1, 1, 1, 1, 0, 1, 1, 0, 0, 0, 0, 1, '', '0000-00-00', '', '2015-08-02 21:51:12'),
(64, 10, 'OFAP-VIII', 30, 0, 0, 30, 1, 1, 1, 1, 0, 1, 1, 0, 0, 0, 0, 1, '', '0000-00-00', '', '2015-08-02 21:51:35'),
(65, 6, 'SC2016-IV', 35, 3000, 3000, 30, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, '', '0000-00-00', '', '2016-05-09 03:30:38'),
(66, 7, 'SC2016-V', 35, 3000, 3000, 30, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, '', '0000-00-00', '', '2016-05-09 03:30:58'),
(67, 8, 'SC2016-VI', 35, 3000, 3000, 30, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, '', '0000-00-00', '', '2016-05-09 03:31:17'),
(68, 9, 'SC2016-VII', 35, 3000, 3000, 30, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, '', '0000-00-00', '', '2016-05-09 03:31:41'),
(69, 10, 'SC2016-VIII', 35, 3000, 3000, 30, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, '', '0000-00-00', '', '2016-05-09 03:32:04'),
(70, 3, 'DemoGrade1', 60, 1000, 1000, 5, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, '', '0000-00-00', '', '2016-07-17 04:33:01'),
(71, 1, 'DemoLKG', 60, 1000, 1000, 5, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, '', '0000-00-00', '', '2016-07-17 04:42:54'),
(72, 2, 'DemoUKG', 60, 1000, 1100, 5, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, '', '0000-00-00', '', '2016-07-17 04:43:14'),
(73, 4, 'DemoGrade2', 60, 1000, 1000, 5, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, '', '0000-00-00', '', '2016-07-17 04:54:00'),
(74, 5, 'DemoGrade3', 60, 1000, 1000, 5, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, '', '0000-00-00', '', '2016-07-17 04:54:13'),
(75, 6, 'DemoGrade4', 60, 1000, 1000, 5, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, '', '0000-00-00', '', '2016-07-17 04:54:28'),
(76, 7, 'DemoGrade5', 60, 1000, 1000, 5, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, '', '0000-00-00', '', '2016-07-17 04:54:47'),
(77, 8, 'DemoGrade6', 60, 1000, 1000, 5, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, '', '0000-00-00', '', '2016-07-17 04:55:03'),
(78, 9, 'DemoGrade7', 60, 1000, 1000, 5, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, '', '0000-00-00', '', '2016-07-17 04:55:16'),
(79, 10, 'DemoGrade8', 60, 1000, 1000, 5, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, '', '0000-00-00', '', '2016-07-17 04:55:29'),
(80, 1, 'MKT-LKG', 90, 1500, 1500, 5, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, '', '0000-00-00', '', '2016-07-20 06:11:54'),
(82, 2, 'MKT-UKG', 90, 1500, 1500, 5, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, '', '0000-00-00', '', '2016-07-20 06:12:55'),
(83, 3, 'MKT-GradeI', 90, 1500, 1500, 5, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, '', '0000-00-00', '', '2016-07-20 06:13:18'),
(84, 4, 'MKT-GradeII', 90, 1500, 1500, 5, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, '', '0000-00-00', '', '2016-07-20 06:13:42'),
(85, 5, 'MKT-GradeIII', 90, 1500, 1500, 5, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, '', '0000-00-00', '', '2016-07-20 06:14:27'),
(86, 6, 'MKT-GradeIV', 90, 1500, 1500, 5, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, '', '0000-00-00', '', '2016-07-20 06:14:57'),
(87, 7, 'MKT-GradeV', 90, 1500, 1500, 5, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, '', '0000-00-00', '', '2016-07-20 06:19:22'),
(88, 8, 'MKT-GradeVI', 90, 1500, 1500, 5, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, '', '0000-00-00', '', '2016-07-20 06:19:01'),
(89, 9, 'MKT-GradeVII', 90, 1500, 1500, 5, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, '', '0000-00-00', '', '2016-07-20 06:20:30'),
(90, 10, 'MKT-GradeVIII', 90, 1500, 1500, 5, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, '', '0000-00-00', '', '2016-07-20 06:21:51'),
(91, 11, 'PerformancePowerPack-PreKG', 365, 1550, 1250, 40, 1, 1, 1, 1, 0, 1, 1, 0, 0, 0, 0, 1, '', '0000-00-00', '', '2014-06-23 16:17:10');

-- --------------------------------------------------------

--
-- Table structure for table `g_skills`
--

CREATE TABLE `g_skills` (
  `id` int(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `gc_id` int(100) NOT NULL,
  `img_path` text NOT NULL,
  `code` varchar(100) NOT NULL,
  `timages` varchar(100) NOT NULL,
  `status` int(1) NOT NULL,
  `createdby` varchar(100) NOT NULL,
  `creation_date` date NOT NULL,
  `modifiedby` varchar(100) NOT NULL,
  `modified_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `hospitalmaster`
--

CREATE TABLE `hospitalmaster` (
  `id` int(11) NOT NULL,
  `hospitalname` varchar(400) NOT NULL,
  `code` varchar(10) NOT NULL,
  `phonenumber_1` varchar(20) NOT NULL,
  `phonenumber_2` varchar(20) NOT NULL,
  `emailid_1` varchar(800) NOT NULL,
  `emailid_2` varchar(800) NOT NULL,
  `address` text NOT NULL,
  `city` varchar(400) NOT NULL,
  `state` int(11) NOT NULL,
  `contact_person` varchar(200) NOT NULL,
  `status` int(11) NOT NULL,
  `createddate` datetime NOT NULL,
  `modifieddate` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `hospitalmaster`
--

INSERT INTO `hospitalmaster` (`id`, `hospitalname`, `code`, `phonenumber_1`, `phonenumber_2`, `emailid_1`, `emailid_2`, `address`, `city`, `state`, `contact_person`, `status`, `createddate`, `modifieddate`) VALUES
(1, 'Appollo', 'APL', '044-265875', '044-268562', 'admin@apl.com', 'head@apl.com', 'No. 645, TH Road,Tondiarpet,Chennai-600 081', 'Chennai', 1823, 'Hariharan', 1, '2018-01-03 00:00:00', '2018-01-04 10:28:47'),
(2, 'Ramachandra', 'SRMC', '044-265844', '044-268585', 'srmadmin@apl.com', 'srmhead@apl.com', 'No. 645, Porur Road,\r\nPorur,\r\nChennai-600 081', 'Chennai', 1823, 'Sundarmoorthy', 1, '2018-01-03 00:00:00', '2018-01-04 09:59:04'),
(3, 'Sooriya', 'dd', '9884584861', '9962452676', 'hari@gmail.com', 'hari@skillangels.com', 'Velacherry', 'Vadapalani', 1821, 'Hariharan', 1, '2018-01-04 09:56:25', '2018-01-05 10:28:33'),
(4, 'Global Health', 'dd', '1234567890', '1234567890', '123@gmail.com', 'sasa@ff.ll', 'Kilpauk', 'chennai', 1823, 'damu', 1, '2018-01-03 19:03:55', '2018-01-05 10:29:39'),
(5, 'GHM', 'GG', '1234567890', '1234567890', '123@gmail.com', '321@qq.ll', 'Rajaji Salai', 'chennai', 1823, 'Sasi', 1, '2018-01-03 19:05:33', '2018-01-05 10:30:06'),
(6, 'dsdsd', 'ddd', '1234567890', '1234567890', '123@gmail.com', 'dsds@kk.kk', '1823', '1823', 0, 'sdsds', 1, '2018-01-03 19:09:01', '0000-00-00 00:00:00'),
(7, 'dsdsd', 'eee', '1234567890', '1234567890', '123@gmail.com', 'dsds@gg.kk', 'ffdfd', '1823', 1823, 'dfdfdf', 1, '2018-01-03 19:10:56', '0000-00-00 00:00:00'),
(8, 'dsds', 'sdsd', '1234567890', '1234567890', '123@gmail.com', 'asasa@ff.kk', 'dfdfdf', 'chennai', 1823, 'Sasi', 1, '2018-01-03 19:12:14', '0000-00-00 00:00:00'),
(9, 'SRM', 'SR', '1234567890', '9876543210', 'hari@gmail.com', '123@gmail.com', 'chennai', 'chennai', 1823, 'Sasikumar', 1, '2018-01-04 08:56:47', '0000-00-00 00:00:00'),
(10, 'Guest', 'GS', '1234567890', '1234567890', '123@gmail.com', 'ww@dd.ll', 'Chennai', 'chennai', 1823, 'kumaran', 1, '2018-01-04 08:58:08', '2018-01-04 10:13:05'),
(11, 'Vijaya', 'APL', '044-265875', '044-268562', 'admin@apl.com', 'head@apl.com', 'No. 645, TH Road,\r\nTondiarpet,\r\nChennai-600 081', 'Chennai', 1823, 'Sasikumar', 1, '2018-01-04 09:33:07', '0000-00-00 00:00:00'),
(12, 'CMC', 'cmc', '1234567890', '1234567890', 'edsix@gmail.jj', '123@ff.kk', 'Vellore', 'chennai', 1823, 'udaikumar', 1, '2018-01-04 10:11:38', '2018-01-04 10:12:04'),
(14, 'Stanley', 'stn', '1234567890', '1234567890', 'stanley@gmail.com', 'stan@yahoo.com', 'Washermenpet', 'chennai', 1823, 'George', 1, '2018-01-04 12:52:21', '2018-01-06 11:05:01');

-- --------------------------------------------------------

--
-- Table structure for table `isuser_log`
--

CREATE TABLE `isuser_log` (
  `ID` int(11) NOT NULL,
  `User_id` int(11) NOT NULL,
  `Login_type` int(11) NOT NULL COMMENT '1=> FTL, 2=>NSTL',
  `Confirmation_type` int(11) NOT NULL COMMENT '1=> Yes, 0 => NO',
  `Logged_datetime` datetime NOT NULL,
  `Org_userid` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `language_master`
--

CREATE TABLE `language_master` (
  `ID` int(11) NOT NULL,
  `name` varchar(400) NOT NULL,
  `status` enum('Y','N') NOT NULL,
  `language_key` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `language_master`
--

INSERT INTO `language_master` (`ID`, `name`, `status`, `language_key`) VALUES
(1, 'English', 'Y', 'english'),
(2, 'Tamil', 'Y', 'tamil'),
(3, 'Kannada', 'Y', 'kannada');

-- --------------------------------------------------------

--
-- Table structure for table `leaderboard`
--

CREATE TABLE `leaderboard` (
  `id` int(11) NOT NULL,
  `sid` int(11) NOT NULL,
  `gradeid` int(11) NOT NULL,
  `year` varchar(55) NOT NULL,
  `monthname` varchar(55) NOT NULL,
  `monthnumber` varchar(55) NOT NULL,
  `userid` text NOT NULL,
  `value` varchar(55) NOT NULL,
  `type` enum('CB','SAB','SBB','SGB') NOT NULL COMMENT 'CB => Crowney Badge,SAB => Super Angel Badge,SBB=> Super Brain Badge,SGB => Super Goer Badge',
  `Created_on` datetime NOT NULL,
  `academic_id` int(11) NOT NULL DEFAULT '20'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `lgames`
--

CREATE TABLE `lgames` (
  `id` int(100) NOT NULL,
  `gname` varchar(100) NOT NULL,
  `img_path` varchar(100) NOT NULL,
  `gpath` varchar(100) NOT NULL,
  `des` varchar(200) NOT NULL,
  `status` int(1) NOT NULL,
  `createdby` varchar(100) NOT NULL,
  `creation_date` date NOT NULL,
  `modifiedby` varchar(100) NOT NULL,
  `modified_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `license_count`
--

CREATE TABLE `license_count` (
  `id` int(11) NOT NULL,
  `centerid` int(11) NOT NULL,
  `adminid` int(11) NOT NULL,
  `licensecount` int(11) NOT NULL,
  `givendatetime` datetime NOT NULL,
  `status` int(11) NOT NULL,
  `created_on` datetime NOT NULL,
  `product_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `license_count`
--

INSERT INTO `license_count` (`id`, `centerid`, `adminid`, `licensecount`, `givendatetime`, `status`, `created_on`, `product_id`) VALUES
(1, 1, 1, 100, '2018-04-25 00:00:00', 1, '2018-04-25 11:46:09', 1),
(2, 5, 1, 1500, '2018-04-25 00:00:00', 1, '2018-04-25 11:46:09', 1);

-- --------------------------------------------------------

--
-- Table structure for table `newsfeedmaster`
--

CREATE TABLE `newsfeedmaster` (
  `ID` int(11) NOT NULL,
  `Scenario` text NOT NULL,
  `Code` varchar(55) NOT NULL,
  `Status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `newsfeedmaster`
--

INSERT INTO `newsfeedmaster` (`ID`, `Scenario`, `Code`, `Status`) VALUES
(1, 'Congratulations - #NAME# completed #GN# #NTH# attempt', '1GAME_COMPLETE', 1),
(2, 'New #THEME# unlocked for #NAME# ', 'THEME_ACTIVATION', 1),
(3, '#NAME# crossed crowny point by #POINTVAL#', 'SPARKEY_LIMIT', 1),
(4, '#NAME# got #B# for #MONTH#', 'BADGES', 1),
(5, 'Congratulations - #NAME# completed all attempts in  #SKILLNAME#', '1SKILL_COMPLETE', 1);

-- --------------------------------------------------------

--
-- Table structure for table `newsfeed_config`
--

CREATE TABLE `newsfeed_config` (
  `ID` int(11) NOT NULL,
  `Type` enum('1','2') NOT NULL COMMENT '1=> School, 2=> Grad',
  `Status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `newsfeed_config`
--

INSERT INTO `newsfeed_config` (`ID`, `Type`, `Status`) VALUES
(1, '2', 1);

-- --------------------------------------------------------

--
-- Table structure for table `newsfeed_data_status`
--

CREATE TABLE `newsfeed_data_status` (
  `ID` int(11) NOT NULL,
  `S_ID` int(11) NOT NULL,
  `G_ID` int(11) NOT NULL,
  `U_ID` int(11) NOT NULL,
  `Value` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `order_number` varchar(15) COLLATE latin1_general_ci NOT NULL,
  `gu_id` int(11) NOT NULL,
  `gp_id` int(10) NOT NULL,
  `date` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `status` int(2) NOT NULL,
  `discount` int(1) NOT NULL,
  `price` varchar(10) COLLATE latin1_general_ci NOT NULL,
  `createdby` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `creation_date` date NOT NULL,
  `modifiedby` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `modified_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `order_details`
--

CREATE TABLE `order_details` (
  `id` int(11) NOT NULL,
  `order_number` varchar(15) COLLATE latin1_general_ci NOT NULL,
  `payment_status` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `createdby` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `creation_date` date NOT NULL,
  `modifiedby` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `modified_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `organization_master`
--

CREATE TABLE `organization_master` (
  `id` int(11) NOT NULL,
  `organizationname` varchar(110) NOT NULL,
  `org_prefix` varchar(55) NOT NULL,
  `validity` int(11) NOT NULL,
  `price` varchar(55) NOT NULL,
  `status` int(11) NOT NULL,
  `username` varchar(110) NOT NULL,
  `password` varchar(110) NOT NULL,
  `email` varchar(255) NOT NULL,
  `mobilenumber` varchar(16) NOT NULL,
  `secondaryemail` varchar(255) NOT NULL,
  `state` int(11) NOT NULL,
  `city` varchar(255) NOT NULL,
  `secondarymobilenumber` varchar(16) NOT NULL,
  `address` text NOT NULL,
  `orgpwd` varchar(55) NOT NULL,
  `created_on` datetime NOT NULL,
  `modified_date` datetime NOT NULL,
  `isdemo` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `organization_master`
--

INSERT INTO `organization_master` (`id`, `organizationname`, `org_prefix`, `validity`, `price`, `status`, `username`, `password`, `email`, `mobilenumber`, `secondaryemail`, `state`, `city`, `secondarymobilenumber`, `address`, `orgpwd`, `created_on`, `modified_date`, `isdemo`) VALUES
(1, 'Edsix', 'ED', 365, '600', 1, '', '', '', '', '', 0, '', '', '', '', '2018-03-19 00:00:00', '0000-00-00 00:00:00', 0),
(2, 'B2C', 'B2C', 365, '600', 1, '', '', '', '', '', 0, '', '', '', '', '2018-03-19 00:00:00', '0000-00-00 00:00:00', 0);

-- --------------------------------------------------------

--
-- Table structure for table `parent_change_password_history`
--

CREATE TABLE `parent_change_password_history` (
  `id` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `randid` int(11) NOT NULL,
  `requestdate` datetime NOT NULL,
  `updatedate` datetime NOT NULL,
  `newpwd` varchar(255) NOT NULL,
  `status` int(11) NOT NULL,
  `device` enum('WEB','APP') NOT NULL DEFAULT 'WEB'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `parent_change_password_history`
--

INSERT INTO `parent_change_password_history` (`id`, `userid`, `randid`, `requestdate`, `updatedate`, `newpwd`, `status`, `device`) VALUES
(1, 2, 142815, '2018-06-14 13:23:38', '2018-06-14 13:33:37', 'skillangels', 1, 'APP');

-- --------------------------------------------------------

--
-- Table structure for table `parent_login_log`
--

CREATE TABLE `parent_login_log` (
  `ID` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `sessionid` varchar(255) NOT NULL,
  `created_date` datetime NOT NULL,
  `lastupdate` datetime NOT NULL,
  `logout_date` datetime NOT NULL,
  `ip` varchar(50) NOT NULL,
  `country` varchar(800) NOT NULL,
  `region` varchar(800) NOT NULL,
  `city` varchar(800) NOT NULL,
  `browser` text NOT NULL,
  `isp` text NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `parent_login_log`
--

INSERT INTO `parent_login_log` (`ID`, `userid`, `sessionid`, `created_date`, `lastupdate`, `logout_date`, `ip`, `country`, `region`, `city`, `browser`, `isp`, `status`) VALUES
(1, 242, '2422019021317210415500586648', '2019-02-13 17:21:04', '2019-02-13 17:21:04', '2019-02-13 17:21:04', '27.5.100.249', '', '', '', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.96 Safari/537.36', '', 1),
(2, 242, '2422019022016420315506611231', '2019-02-20 16:42:03', '2019-02-20 16:42:03', '2019-02-20 16:42:03', '210.18.157.146', '', '', '', 'Dart/2.1 (dart:io)', '', 1),
(3, 242, '2422019022019142115506702616', '2019-02-20 19:14:21', '2019-02-21 17:02:17', '2019-02-21 17:02:17', '210.18.157.146', '', '', '', 'Dart/2.1 (dart:io)', '', 1),
(4, 242, '2422019022515302115510888213', '2019-02-25 15:30:21', '2019-02-25 15:31:21', '2019-02-25 15:31:21', '210.18.157.146', '', '', '', 'Dart/2.1 (dart:io)', '', 1),
(5, 242, '2422019022515432815510896083', '2019-02-25 15:43:28', '2019-02-25 15:55:56', '2019-02-25 15:55:56', '210.18.157.146', '', '', '', 'Dart/2.1 (dart:io)', '', 1),
(6, 242, '2422019022515565615510904166', '2019-02-25 15:56:56', '2019-02-25 15:57:34', '2019-02-25 15:57:34', '210.18.157.146', '', '', '', 'Dart/2.1 (dart:io)', '', 1),
(7, 242, '2422019022515582415510905040', '2019-02-25 15:58:24', '2019-02-25 16:13:41', '2019-02-25 16:13:41', '210.18.157.146', '', '', '', 'Dart/2.1 (dart:io)', '', 1),
(8, 242, '2422019022516231115510919913', '2019-02-25 16:23:11', '2019-02-25 16:26:28', '2019-02-25 16:26:28', '210.18.157.146', '', '', '', 'Dart/2.1 (dart:io)', '', 1),
(9, 242, '2422019022516264315510922035', '2019-02-25 16:26:43', '2019-02-25 17:06:11', '2019-02-25 17:06:11', '210.18.157.146', '', '', '', 'Dart/2.1 (dart:io)', '', 1),
(10, 242, '2422019022517135015510950302', '2019-02-25 17:13:50', '2019-02-25 17:13:50', '2019-02-25 17:13:50', '210.18.157.146', '', '', '', 'Dart/2.1 (dart:io)', '', 1),
(11, 242, '2422019022517141915510950597', '2019-02-25 17:14:19', '2019-02-25 17:24:09', '2019-02-25 17:24:09', '210.18.157.146', '', '', '', 'Dart/2.1 (dart:io)', '', 1),
(12, 242, '2422019022517254115510957420', '2019-02-25 17:25:41', '2019-02-25 17:25:41', '2019-02-25 17:25:41', '210.18.157.146', '', '', '', 'Dart/2.1 (dart:io)', '', 1),
(13, 242, '2422019022610281615511570965', '2019-02-26 10:28:16', '2019-02-26 11:36:08', '2019-02-26 11:36:08', '210.18.157.146', '', '', '', 'Dart/2.1 (dart:io)', '', 1),
(14, 242, '2422019022611372215511612426', '2019-02-26 11:37:22', '2019-02-26 11:37:22', '2019-02-26 11:37:22', '210.18.157.146', '', '', '', 'Dart/2.1 (dart:io)', '', 1),
(15, 242, '2422019022612360315511647638', '2019-02-26 12:36:03', '2019-02-26 12:36:03', '2019-02-26 12:36:03', '210.18.157.146', '', '', '', 'Dart/2.1 (dart:io)', '', 1),
(16, 242, '2422019022612374515511648658', '2019-02-26 12:37:45', '2019-02-26 12:37:56', '2019-02-26 12:37:56', '210.18.157.146', '', '', '', 'Dart/2.1 (dart:io)', '', 1),
(17, 242, '2422019022612530815511657888', '2019-02-26 12:53:08', '2019-02-26 12:53:08', '2019-02-26 12:53:08', '210.18.157.146', '', '', '', 'Dart/2.1 (dart:io)', '', 1),
(18, 242, '2422019022613014815511663085', '2019-02-26 13:01:48', '2019-02-26 13:01:48', '2019-02-26 13:01:48', '210.18.157.146', '', '', '', 'Dart/2.1 (dart:io)', '', 1),
(19, 242, '2422019022613020815511663283', '2019-02-26 13:02:08', '2019-02-26 13:02:08', '2019-02-26 13:02:08', '210.18.157.146', '', '', '', 'Dart/2.1 (dart:io)', '', 1),
(20, 242, '2422019022613080715511666873', '2019-02-26 13:08:07', '2019-02-26 13:08:58', '2019-02-26 13:08:58', '210.18.157.146', '', '', '', 'Dart/2.1 (dart:io)', '', 1),
(21, 242, '2422019022613125815511669790', '2019-02-26 13:12:58', '2019-02-26 13:12:58', '2019-02-26 13:12:58', '210.18.157.146', '', '', '', 'Dart/2.1 (dart:io)', '', 1),
(22, 242, '2422019022613130715511669878', '2019-02-26 13:13:07', '2019-02-26 13:31:38', '2019-02-26 13:31:38', '210.18.157.146', '', '', '', 'Dart/2.1 (dart:io)', '', 1),
(23, 242, '2422019022613130715511669878', '2019-02-26 13:13:07', '2019-02-26 13:31:38', '2019-02-26 13:31:38', '210.18.157.146', '', '', '', 'Dart/2.1 (dart:io)', '', 1),
(24, 242, '2422019022613422515511687456', '2019-02-26 13:42:25', '2019-02-26 13:44:13', '2019-02-26 13:44:13', '210.18.157.146', '', '', '', 'Dart/2.1 (dart:io)', '', 1),
(25, 242, '2422019022613442815511688685', '2019-02-26 13:44:28', '2019-02-26 13:44:28', '2019-02-26 13:44:28', '210.18.157.146', '', '', '', 'Dart/2.1 (dart:io)', '', 1),
(26, 242, '2422019022615172115511744414', '2019-02-26 15:17:21', '2019-02-26 15:38:26', '2019-02-26 15:38:26', '210.18.157.146', '', '', '', 'Dart/2.1 (dart:io)', '', 1),
(27, 242, '2422019022615384115511757217', '2019-02-26 15:38:41', '2019-02-26 15:38:41', '2019-02-26 15:38:41', '210.18.157.146', '', '', '', 'Dart/2.1 (dart:io)', '', 1),
(28, 242, '2422019022616461715511797775', '2019-02-26 16:46:17', '2019-02-26 16:47:07', '2019-02-26 16:47:07', '210.18.157.146', '', '', '', 'Dart/2.1 (dart:io)', '', 1),
(29, 242, '2422019022616472315511798440', '2019-02-26 16:47:23', '2019-02-26 16:47:50', '2019-02-26 16:47:50', '210.18.157.146', '', '', '', 'Dart/2.1 (dart:io)', '', 1),
(30, 242, '2422019022616490515511799455', '2019-02-26 16:49:05', '2019-02-26 16:49:22', '2019-02-26 16:49:22', '210.18.157.146', '', '', '', 'Dart/2.1 (dart:io)', '', 1),
(31, 242, '2422019022616503215511800325', '2019-02-26 16:50:32', '2019-02-26 16:50:40', '2019-02-26 16:50:40', '210.18.157.146', '', '', '', 'Dart/2.1 (dart:io)', '', 1),
(32, 242, '2422019022616530315511801837', '2019-02-26 16:53:03', '2019-02-26 16:53:35', '2019-02-26 16:53:35', '210.18.157.146', '', '', '', 'Dart/2.1 (dart:io)', '', 1),
(33, 242, '2422019022616543115511802712', '2019-02-26 16:54:31', '2019-02-26 16:54:43', '2019-02-26 16:54:43', '210.18.157.146', '', '', '', 'Dart/2.1 (dart:io)', '', 1),
(34, 242, '2422019022617394115511829818', '2019-02-26 17:39:41', '2019-02-26 17:45:13', '2019-02-26 17:45:13', '210.18.157.146', '', '', '', 'Dart/2.1 (dart:io)', '', 1),
(35, 242, '2422019022617453415511833345', '2019-02-26 17:45:34', '2019-02-26 17:45:40', '2019-02-26 17:45:40', '210.18.157.146', '', '', '', 'Dart/2.1 (dart:io)', '', 1),
(36, 242, '2422019022617462015511833802', '2019-02-26 17:46:20', '2019-02-26 17:46:36', '2019-02-26 17:46:36', '210.18.157.146', '', '', '', 'Dart/2.1 (dart:io)', '', 1),
(37, 242, '2422019022617501915511836193', '2019-02-26 17:50:19', '2019-02-26 17:50:19', '2019-02-26 17:50:19', '210.18.157.146', '', '', '', 'Dart/2.1 (dart:io)', '', 1),
(38, 242, '2422019022714554515512595454', '2019-02-27 14:55:45', '2019-02-27 14:55:45', '2019-02-27 14:55:45', '210.18.157.146', '', '', '', 'Dart/2.1 (dart:io)', '', 1),
(39, 242, '2422019022715062415512601847', '2019-02-27 15:06:24', '2019-02-27 15:29:02', '2019-02-27 15:29:02', '210.18.157.146', '', '', '', 'Dart/2.1 (dart:io)', '', 1),
(40, 242, '2422019022715354515512619459', '2019-02-27 15:35:45', '2019-02-27 15:40:17', '2019-02-27 15:40:17', '210.18.157.146', '', '', '', 'Dart/2.1 (dart:io)', '', 1),
(41, 242, '2422019022715411615512622763', '2019-02-27 15:41:16', '2019-02-27 15:48:28', '2019-02-27 15:48:28', '210.18.157.146', '', '', '', 'Dart/2.1 (dart:io)', '', 1),
(42, 242, '2422019022715501315512628139', '2019-02-27 15:50:13', '2019-02-27 15:51:17', '2019-02-27 15:51:17', '210.18.157.146', '', '', '', 'Dart/2.1 (dart:io)', '', 1),
(43, 242, '2422019022715520015512629204', '2019-02-27 15:52:00', '2019-02-27 15:52:08', '2019-02-27 15:52:08', '210.18.157.146', '', '', '', 'Dart/2.1 (dart:io)', '', 1),
(44, 242, '2422019022715523015512629500', '2019-02-27 15:52:30', '2019-02-27 15:52:51', '2019-02-27 15:52:51', '210.18.157.146', '', '', '', 'Dart/2.1 (dart:io)', '', 1),
(45, 242, '2422019022715532415512630042', '2019-02-27 15:53:24', '2019-02-27 15:53:34', '2019-02-27 15:53:34', '210.18.157.146', '', '', '', 'Dart/2.1 (dart:io)', '', 1),
(46, 242, '2422019022715535315512630336', '2019-02-27 15:53:53', '2019-02-27 15:54:01', '2019-02-27 15:54:01', '210.18.157.146', '', '', '', 'Dart/2.1 (dart:io)', '', 1),
(47, 242, '2422019022715554415512631449', '2019-02-27 15:55:44', '2019-02-27 15:56:11', '2019-02-27 15:56:11', '210.18.157.146', '', '', '', 'Dart/2.1 (dart:io)', '', 1),
(48, 242, '2422019022715562615512631864', '2019-02-27 15:56:26', '2019-02-27 15:56:55', '2019-02-27 15:56:55', '210.18.157.146', '', '', '', 'Dart/2.1 (dart:io)', '', 1),
(49, 242, '2422019022715573415512632540', '2019-02-27 15:57:34', '2019-02-27 15:58:52', '2019-02-27 15:58:52', '210.18.157.146', '', '', '', 'Dart/2.1 (dart:io)', '', 1),
(50, 242, '2422019022716003715512634376', '2019-02-27 16:00:37', '2019-02-27 16:00:51', '2019-02-27 16:00:51', '210.18.157.146', '', '', '', 'Dart/2.1 (dart:io)', '', 1),
(51, 242, '2422019022716024615512635669', '2019-02-27 16:02:46', '2019-02-27 16:14:27', '2019-02-27 16:14:27', '210.18.157.146', '', '', '', 'Dart/2.1 (dart:io)', '', 1),
(52, 242, '2422019022716151515512643156', '2019-02-27 16:15:15', '2019-02-27 16:23:17', '2019-02-27 16:23:17', '210.18.157.146', '', '', '', 'Dart/2.1 (dart:io)', '', 1),
(53, 242, '2422019022716531515512665957', '2019-02-27 16:53:15', '2019-02-27 16:55:10', '2019-02-27 16:55:10', '210.18.157.146', '', '', '', 'Dart/2.1 (dart:io)', '', 1),
(54, 242, '2422019022716565115512668119', '2019-02-27 16:56:51', '2019-02-27 16:57:15', '2019-02-27 16:57:15', '210.18.157.146', '', '', '', 'Dart/2.1 (dart:io)', '', 1),
(55, 242, '2422019022717025815512671787', '2019-02-27 17:02:58', '2019-02-27 17:03:27', '2019-02-27 17:03:27', '210.18.157.146', '', '', '', 'Dart/2.1 (dart:io)', '', 1),
(56, 242, '2422019022717035915512672395', '2019-02-27 17:03:59', '2019-02-27 17:03:59', '2019-02-27 17:03:59', '210.18.157.146', '', '', '', 'Dart/2.1 (dart:io)', '', 1),
(57, 242, '2422019022717043415512672747', '2019-02-27 17:04:34', '2019-02-27 17:04:34', '2019-02-27 17:04:34', '210.18.157.146', '', '', '', 'Dart/2.1 (dart:io)', '', 1),
(58, 242, '2422019022717050515512673053', '2019-02-27 17:05:05', '2019-02-27 17:05:05', '2019-02-27 17:05:05', '210.18.157.146', '', '', '', 'Dart/2.1 (dart:io)', '', 1),
(59, 242, '2422019022717060015512673602', '2019-02-27 17:06:00', '2019-02-27 17:13:22', '2019-02-27 17:13:22', '210.18.157.146', '', '', '', 'Dart/2.1 (dart:io)', '', 1),
(60, 242, '2422019022717261015512685703', '2019-02-27 17:26:10', '2019-03-15 19:12:52', '2019-03-15 19:12:52', '210.18.157.146', '', '', '', 'Dart/2.1 (dart:io)', '', 1),
(61, 242, '2422019032511124315534925635', '2019-03-25 11:12:43', '2019-03-25 12:42:34', '2019-03-25 12:42:34', '210.18.157.146', '', '', '', 'Dart/2.1 (dart:io)', '', 1),
(62, 242, '2422019032512545215534986928', '2019-03-25 12:54:52', '2019-03-25 15:44:05', '2019-03-25 15:44:05', '210.18.157.146', '', '', '', 'Dart/2.1 (dart:io)', '', 1),
(63, 243, '2432019032513364015535012004', '2019-03-25 13:36:40', '2019-03-25 13:40:52', '2019-03-25 13:40:52', '210.18.157.146', '', '', '', 'Dart/2.1 (dart:io)', '', 1),
(64, 242, '2422019032616350515535983057', '2019-03-26 16:35:05', '2019-03-26 16:35:05', '2019-03-26 16:35:05', '210.18.157.146', '', '', '', 'Dart/2.1 (dart:io)', '', 1),
(65, 242, '2422019032912325015538429703', '2019-03-29 12:32:50', '2019-03-29 12:33:40', '2019-03-29 12:33:40', '210.18.157.146', '', '', '', 'Dart/2.1 (dart:io)', '', 1),
(66, 242, '2422019032912354215538431427', '2019-03-29 12:35:42', '2019-03-29 12:36:25', '2019-03-29 12:36:25', '210.18.157.146', '', '', '', 'Dart/2.1 (dart:io)', '', 1),
(67, 242, '2422019032916364115538576015', '2019-03-29 16:36:41', '2019-03-29 16:37:17', '2019-03-29 16:37:17', '210.18.157.146', '', '', '', 'Dart/2.1 (dart:io)', '', 1),
(68, 242, '2422019040115200715541122078', '2019-04-01 15:20:07', '2019-04-01 15:21:25', '2019-04-01 15:21:25', '210.18.157.146', '', '', '', 'Dart/2.1 (dart:io)', '', 1),
(69, 242, '2422019040215414115541999012', '2019-04-02 15:41:41', '2019-04-02 15:42:03', '2019-04-02 15:42:03', '210.18.157.146', '', '', '', 'Dart/2.1 (dart:io)', '', 1),
(70, 242, '2422019040216145515542018958', '2019-04-02 16:14:55', '2019-04-02 16:15:14', '2019-04-02 16:15:14', '210.18.157.146', '', '', '', 'Dart/2.1 (dart:io)', '', 1),
(71, 242, '2422019040217175015542056709', '2019-04-02 17:17:50', '2019-04-02 17:18:02', '2019-04-02 17:18:02', '210.18.157.146', '', '', '', 'Dart/2.1 (dart:io)', '', 1),
(72, 242, '2422019040217300015542064008', '2019-04-02 17:30:00', '2019-04-02 17:32:46', '2019-04-02 17:32:46', '210.18.157.146', '', '', '', 'Dart/2.1 (dart:io)', '', 1),
(73, 6428, '64282019051019453515574977351', '2019-05-10 19:45:35', '2019-05-10 19:46:23', '2019-05-10 19:46:23', '210.18.157.146', '', '', '', 'Dart/2.1 (dart:io)', '', 1),
(74, 242, '2422019070212420815620515281', '2019-07-02 12:42:08', '2019-07-02 12:42:08', '2019-07-02 12:42:08', '210.18.157.146', '', '', '', 'Dart/2.1 (dart:io)', '', 1);

-- --------------------------------------------------------

--
-- Table structure for table `password_history`
--

CREATE TABLE `password_history` (
  `id` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `changed_on` datetime NOT NULL,
  `newpwd` varchar(110) NOT NULL,
  `ip` varchar(110) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `password_history`
--

INSERT INTO `password_history` (`id`, `userid`, `changed_on`, `newpwd`, `ip`) VALUES
(1, 75, '2018-03-01 16:58:23', '1', 'THROUGH_APP'),
(2, 75, '2018-03-01 17:03:10', '2', 'THROUGH_APP'),
(3, 75, '2018-03-01 17:08:26', '1', 'THROUGH_APP'),
(4, 75, '2018-03-01 18:10:14', '123456', 'THROUGH_APP'),
(5, 75, '2018-03-01 18:56:59', '12', 'THROUGH_APP'),
(6, 75, '2018-03-02 12:45:57', '1', 'THROUGH_APP'),
(7, 75, '2018-03-07 16:18:54', '123', 'THROUGH_APP'),
(8, 75, '2018-03-12 15:44:46', '12', 'THROUGH_APP'),
(9, 80, '2018-03-20 13:04:54', '12345', 'THROUGH_APP');

-- --------------------------------------------------------

--
-- Stand-in structure for view `playedques`
-- (See below for the actual view)
--
CREATE TABLE `playedques` (
`userid` int(11)
,`quesPlayed` text
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `popupstar`
-- (See below for the actual view)
--
CREATE TABLE `popupstar` (
`gu_id` int(10)
,`lastupdate` date
,`cat_id` int(11)
,`name` varchar(50)
,`ct` double(17,0)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `popupstargreaterthanninty`
-- (See below for the actual view)
--
CREATE TABLE `popupstargreaterthanninty` (
`gu_id` int(10)
,`lastupdate` date
,`cat_id` int(11)
,`name` varchar(50)
,`ct` double(17,0)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `popupstarlessequalninty`
-- (See below for the actual view)
--
CREATE TABLE `popupstarlessequalninty` (
`gu_id` int(10)
,`lastupdate` date
,`cat_id` int(11)
,`name` varchar(50)
,`ct` double(17,0)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `popupstars`
-- (See below for the actual view)
--
CREATE TABLE `popupstars` (
`lastupdate` date
,`name` varchar(50)
,`ct` double(17,0)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `popuptrophys`
-- (See below for the actual view)
--
CREATE TABLE `popuptrophys` (
`gu_id` int(10)
,`catid` int(11)
,`name` varchar(50)
,`month` int(2)
,`diamond` double(17,0)
,`gold` double(17,0)
,`silver` double(17,0)
);

-- --------------------------------------------------------

--
-- Table structure for table `product_master`
--

CREATE TABLE `product_master` (
  `id` int(11) NOT NULL,
  `product_name` varchar(255) NOT NULL,
  `product_code` varchar(10) NOT NULL,
  `status` int(11) NOT NULL,
  `creation_date` datetime NOT NULL,
  `isdemo` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product_master`
--

INSERT INTO `product_master` (`id`, `product_name`, `product_code`, `status`, `creation_date`, `isdemo`) VALUES
(1, 'Summer Champs', 'SC', 1, '2018-04-25 00:00:00', 0);

-- --------------------------------------------------------

--
-- Table structure for table `pullrequest_gamedata`
--

CREATE TABLE `pullrequest_gamedata` (
  `id` int(11) NOT NULL,
  `ChildId` int(11) NOT NULL,
  `data` text NOT NULL,
  `status` enum('S','F') NOT NULL DEFAULT 'F',
  `request_on` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `pullrequest_gamelist`
--

CREATE TABLE `pullrequest_gamelist` (
  `id` int(11) NOT NULL,
  `ChildId` int(11) NOT NULL,
  `data` text NOT NULL,
  `status` enum('S','F') NOT NULL DEFAULT 'F',
  `request_on` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `rand_selection`
--

CREATE TABLE `rand_selection` (
  `id` int(11) NOT NULL,
  `gc_id` int(11) DEFAULT NULL,
  `gs_id` int(11) DEFAULT NULL,
  `gid` int(11) DEFAULT NULL,
  `gp_id` int(11) DEFAULT NULL,
  `grade_id` int(11) DEFAULT NULL,
  `section` varchar(10) DEFAULT NULL,
  `school_id` int(11) DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  `created_date` datetime DEFAULT NULL,
  `played` enum('Y','N') NOT NULL DEFAULT 'N',
  `puzzle_cycle` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `rand_selection_cq`
--

CREATE TABLE `rand_selection_cq` (
  `id` int(11) NOT NULL,
  `gid` int(11) DEFAULT NULL,
  `gp_id` int(11) DEFAULT NULL,
  `grade_id` int(11) DEFAULT NULL,
  `school_id` int(11) DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  `playedstatus` int(11) NOT NULL,
  `created_date` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `rand_selection_cq`
--

INSERT INTO `rand_selection_cq` (`id`, `gid`, `gp_id`, `grade_id`, `school_id`, `user_id`, `playedstatus`, `created_date`) VALUES
(1, 0, 6, 8, 2, 25, 0, '2018-03-07 12:39:37'),
(2, 0, 6, 8, 2, 25, 0, '2018-03-08 11:50:16'),
(3, 0, 6, 8, 2, 25, 0, '2018-03-09 09:30:36'),
(4, 0, 8, 10, 2, 77, 0, '2018-03-09 14:23:14'),
(5, 0, 7, 9, 2, 78, 0, '2018-03-13 11:14:07');

-- --------------------------------------------------------

--
-- Table structure for table `range_values`
--

CREATE TABLE `range_values` (
  `ID` int(11) NOT NULL,
  `startRange` int(11) NOT NULL,
  `endRange` int(11) NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `range_values`
--

INSERT INTO `range_values` (`ID`, `startRange`, `endRange`, `status`) VALUES
(1, 0, 5, 1),
(2, 5, 10, 1),
(3, 10, 15, 1),
(4, 15, 20, 1),
(5, 10, 15, 1),
(6, 15, 20, 1),
(7, 20, 25, 1),
(8, 25, 30, 1),
(9, 30, 35, 1),
(10, 35, 40, 1),
(11, 40, 45, 1),
(12, 45, 50, 1),
(13, 50, 55, 1),
(14, 55, 60, 1),
(15, 60, 65, 1),
(16, 65, 70, 1),
(17, 70, 75, 1),
(18, 75, 80, 1),
(19, 80, 85, 1),
(20, 85, 90, 1),
(21, 90, 95, 1),
(22, 95, 100, 1);

-- --------------------------------------------------------

--
-- Table structure for table `registration`
--

CREATE TABLE `registration` (
  `id` int(11) NOT NULL,
  `firstname` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `dateofbirth` varchar(100) NOT NULL,
  `email` varchar(400) NOT NULL,
  `salt1` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `salt2` varchar(100) NOT NULL,
  `mobilenumber` varchar(11) NOT NULL,
  `gradeid` int(11) NOT NULL,
  `gp_id` int(11) NOT NULL,
  `country` int(11) NOT NULL,
  `state` int(11) NOT NULL,
  `city` varchar(100) NOT NULL,
  `pincode` int(11) NOT NULL,
  `profileimage` varchar(100) NOT NULL,
  `address` varchar(800) NOT NULL,
  `orgpwd` varchar(255) NOT NULL,
  `status` enum('N','P','C') NOT NULL COMMENT 'N=> Pending ,    P => In-Process,   C=> Completed',
  `couponcode` varchar(40) NOT NULL,
  `originalamount` varchar(110) NOT NULL,
  `paidamount` varchar(110) NOT NULL,
  `paymentstatus` enum('Y','N') NOT NULL COMMENT 'Y=> Done, N => No',
  `createddate` date NOT NULL,
  `processdate` datetime NOT NULL,
  `completeddate` datetime NOT NULL,
  `avatarimage` text,
  `otp` varchar(16) NOT NULL,
  `otp_datetime` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `schools`
--

CREATE TABLE `schools` (
  `id` int(100) NOT NULL,
  `school_name` varchar(100) NOT NULL,
  `school_address` varchar(100) NOT NULL,
  `phone` int(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `school_code` varchar(100) NOT NULL,
  `zone` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `district` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `state` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `country` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `city` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `logo` longblob NOT NULL,
  `active` varchar(100) NOT NULL,
  `type` varchar(100) NOT NULL,
  `flag` tinyint(1) NOT NULL,
  `status` int(1) NOT NULL,
  `academic_id` int(11) NOT NULL,
  `createdby` varchar(100) NOT NULL,
  `creation_date` date NOT NULL,
  `modifiedby` varchar(100) NOT NULL,
  `modified_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `visible` int(11) NOT NULL DEFAULT '1',
  `start_date` varchar(20) NOT NULL,
  `emailcc` varchar(220) NOT NULL,
  `emailcc1` varchar(220) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `schools`
--

INSERT INTO `schools` (`id`, `school_name`, `school_address`, `phone`, `email`, `school_code`, `zone`, `district`, `state`, `country`, `city`, `logo`, `active`, `type`, `flag`, `status`, `academic_id`, `createdby`, `creation_date`, `modifiedby`, `modified_date`, `visible`, `start_date`, `emailcc`, `emailcc1`) VALUES
(1, 'Samartha Pre School', '', 1234567890, 'sps@kinderangels.com', 'sps', 'south', 'south', 'Tamil Nadu', 'India', 'Chennai', '', '0', 'CBSE', 0, 0, 20, '', '2018-06-26', '', '2019-06-20 09:50:14', 0, '2018-06-26', '', ''),
(2, 'Rotary Virtual School', 'Chennai', 1234567890, 'kalp@skillangels.com', '100', 'Chennai', 'Chennai', 'Tamil Nadu', 'India', 'Chennai', 0x41544d2e706e67, '1', 'CBSE', 0, 1, 20, '', '0000-00-00', '', '2018-02-04 18:56:39', 1, '2018-02-05', '', ''),
(40, 'Pine View School', '', 1234567890, 'pvs@kinderangels.com', 'pvs', 'NORTH', 'NORTH', '', 'India', 'BALLUPUR', '', '0', 'CBSE', 0, 0, 20, '', '2018-06-27', '', '2019-04-29 04:54:16', 0, '2018-06-28', '', ''),
(48, 'GRN School', '', 1234567890, 'grn@kinderangels.com', 'grn', 'south', 'south', 'Tamil Nadu', 'India', 'Chennai', '', '0', 'CBSE', 0, 0, 20, '', '2018-06-20', '', '2019-06-20 09:50:14', 0, '2018-06-21', '', ''),
(50, 'Sri Lathangi Vidhya Mandir Matric. Hr. Sec. School', '', 1234567890, 'slvm@kinderangels.com', 'slvm', 'south', 'south', 'Tamil Nadu', 'India', 'Chennai', '', '0', 'CBSE', 0, 0, 20, '', '2018-06-21', '', '2019-06-20 09:50:14', 0, '2018-06-26', '', ''),
(52, 'Born Scholars Matriculation Higher Secondary School', 'Medavakkam', 1234567890, 'bs@kinderangels.com', 'bs', 'south', 'south', 'Tamil Nadu', 'India', 'Chennai', '', '0', 'CBSE', 0, 0, 20, '', '2018-06-28', '', '2019-06-20 09:50:15', 0, '2018-08-14', '', ''),
(59, 'Akara International school - CAIE', '', 1234567890, 'akca@kinderangels.com', 'mbm', 'south', 'south', 'Tamil Nadu', 'India', 'Chennai', '', '0', 'CBSE', 0, 0, 20, '', '2018-08-28', '', '2019-06-20 09:50:15', 0, '2018-08-30', '', ''),
(66, 'Shri Maharishi Bala Mandir', 'Dindigul', 1234567890, 'mbm@kinderangels.com', 'mbm', 'south', 'south', 'Tamil Nadu', 'India', 'Chennai', '', '0', 'CBSE', 0, 0, 20, '', '2018-08-16', '', '2019-07-02 07:47:25', 0, '2018-08-16', '', ''),
(108, 'Amity School - Dubai', 'DUBAI', 1234567890, 'as@kinderangels.com', 'as', 'south', 'south', 'Tamil Nadu', 'India', 'Chennai', '', '1', 'CBSE', 1, 1, 20, '', '2019-02-07', '', '2019-06-20 10:14:14', 1, '2019-02-11', '', ''),
(117, 'DELHI PRIVATE SCHOOL - DUBAI', 'DUBAI', 1234567890, 'dpsd1819@kinderangels.com', 'dpsd1819', 'south', 'south', 'Tamil Nadu', 'India', 'Chennai', '', '0', 'CBSE', 0, 0, 20, '', '2019-01-29', '', '2019-06-20 09:55:04', 0, '2019-01-29', '', ''),
(118, 'THE WINCHESTER SCHOOL', 'Jebel Ali, Dubai , United Arab Emirates', 2147483647, 'tws@kinderangels.com', 'tws', '', '', 'Dubai', 'United Arab Emirates', 'Jebel Ali', '', '1', 'Dubai', 1, 1, 20, '', '2019-03-11', '', '2019-06-20 10:14:14', 1, '2019-03-11', '', ''),
(119, 'The Kindergarten Starters', 'DUBAI', 2147483647, 'kgs@kinderangels.com', 'kgs', '', '', 'Dubai', 'United Arab Emirates', 'Jebel Ali', 0x3f, '1', 'Dubai', 1, 1, 20, '', '2019-04-09', '', '2019-04-09 07:11:15', 1, '2019-04-09', '', ''),
(120, 'DELHI PRIVATE SCHOOL - DUBAI', 'DUBAI', 1234567890, 'dpsd@kinderangels.com', 'dpsd', '', '', 'Dubai', 'United Arab Emirates', 'Dubai', 0x3f, '1', 'CBSE', 1, 1, 20, '', '2019-04-16', '', '2019-04-16 11:15:57', 1, '2019-04-16', '', ''),
(121, 'Pine View School', '', 1234567890, 'pvs@kinderangels.com', 'pvs', 'NORTH', 'NORTH', '', 'India', 'BALLUPUR', 0x3f, '1', 'CBSE', 1, 1, 20, '', '2019-04-29', '', '2019-07-15 12:06:56', 1, '2019-04-29', 'schoolpineview@gmail.com', ''),
(122, 'NARBHAVI VIDYALAYA NURSERY & PRIMARY SCHOOL', '', 1234567890, 'nv@kinderangels.com', 'nv', 'NORTH', 'Neyveli', '', 'India', 'Cuddalore', 0x3f, '1', 'CBSE', 1, 1, 20, '', '2019-06-17', '', '2019-07-15 12:06:56', 1, '2019-06-17', 'narbhavividyalaya@gmail.com', ''),
(123, 'Born Scholars Matriculation Higher Secondary School', '', 1234567890, 'bs@kinderangels.com', 'bs', 'NORTH', 'Medavakkam', '', 'India', 'Chennai', 0x3f, '1', 'CBSE', 1, 1, 20, '', '2019-06-20', '', '2019-07-15 12:06:56', 1, '2019-06-20', 'bsschool865@gmail.com', ''),
(124, 'Sri Lathangi Vidhya Mandir Matric. Hr. Sec. School', '', 1234567890, 'slvm@kinderangels.com', 'slvm', 'SOUTH', 'SOUTH', 'Tamilnadu', 'India', 'Chennai', 0x3f, '1', 'CBSE', 1, 1, 20, '', '2019-06-24', '', '2019-07-15 13:12:53', 1, '2019-06-24', 'skillcreators17@gmail.com', ''),
(125, 'SASSI GNANODAYA ACADEMY', '', 1234567890, 'sga@kinderangels.com', 'sga', 'SOUTH', 'SOUTH', 'Tamilnadu', 'India', 'Dharamapuri', 0x3f, '1', 'CBSE', 1, 1, 20, '', '2019-07-31', '', '2019-07-15 13:12:53', 1, '2019-06-24', '', ''),
(172, 'VK Demo', '', 1234567890, 'vk@kinderangels.com', 'vk', 'Chennai', 'Chennai', 'Tamil Nadu', 'India', 'Chennai', '', '1', 'CBSE', 1, 0, 20, '', '2019-08-22', '', '2019-08-23 04:56:40', 0, '2019-08-22', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `schools_language`
--

CREATE TABLE `schools_language` (
  `ID` int(11) NOT NULL,
  `schoolID` int(11) NOT NULL,
  `languageID` int(11) NOT NULL,
  `status` enum('Y','N') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `schools_language`
--

INSERT INTO `schools_language` (`ID`, `schoolID`, `languageID`, `status`) VALUES
(11, 2, 1, 'Y'),
(12, 2, 3, 'Y');

-- --------------------------------------------------------

--
-- Table structure for table `schools_leave_list`
--

CREATE TABLE `schools_leave_list` (
  `id` int(11) NOT NULL,
  `school_id` int(11) NOT NULL,
  `leave_date` varchar(20) CHARACTER SET utf8 NOT NULL,
  `reason` varchar(100) NOT NULL,
  `academic_id` int(11) NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `schools_period_schedule`
--

CREATE TABLE `schools_period_schedule` (
  `schedule_id` int(11) NOT NULL,
  `school_id` int(11) NOT NULL,
  `period` int(11) NOT NULL,
  `start_time` varchar(20) NOT NULL,
  `end_time` varchar(20) NOT NULL,
  `monday_grade` varchar(10) NOT NULL,
  `tuesday_grade` varchar(10) NOT NULL,
  `wednesday_grade` varchar(10) NOT NULL,
  `thursday_grade` varchar(10) NOT NULL,
  `friday_grade` varchar(10) NOT NULL,
  `saturday_grade` varchar(10) NOT NULL,
  `sunday_grade` varchar(10) NOT NULL,
  `monday_section` varchar(10) NOT NULL,
  `tuesday_section` varchar(10) NOT NULL,
  `wednesday_section` varchar(10) NOT NULL,
  `thursday_section` varchar(10) NOT NULL,
  `friday_section` varchar(10) NOT NULL,
  `saturday_section` varchar(10) NOT NULL,
  `sunday_section` varchar(10) NOT NULL,
  `academic_id` int(11) NOT NULL,
  `status` enum('Y','N','D') NOT NULL,
  `remarks` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `schools_period_schedule`
--

INSERT INTO `schools_period_schedule` (`schedule_id`, `school_id`, `period`, `start_time`, `end_time`, `monday_grade`, `tuesday_grade`, `wednesday_grade`, `thursday_grade`, `friday_grade`, `saturday_grade`, `sunday_grade`, `monday_section`, `tuesday_section`, `wednesday_section`, `thursday_section`, `friday_section`, `saturday_section`, `sunday_section`, `academic_id`, `status`, `remarks`) VALUES
(1, 2, 1, '', '', 'III', 'VII', '', 'V', 'IV', '', '', 'C', 'C', '', 'C', 'C', '', '', 19, 'Y', ''),
(2, 2, 2, '', '', '', 'II', 'IV', 'VII', 'V', '', '', '', 'B', 'A', 'B', 'A', '', '', 19, 'Y', ''),
(3, 2, 3, '', '', 'VII', '', '', '', '', '', '', 'A', '', '', '', '', '', '', 19, 'Y', ''),
(4, 2, 4, '', '', 'VI', '', '', 'VII', '', '', '', 'B', '', '', 'D', '', '', '', 19, 'Y', ''),
(5, 2, 5, '', '', 'I', 'I', 'VI', 'VIII', 'II', '', '', 'A', 'C', 'A', 'D', 'A', '', '', 19, 'Y', ''),
(6, 2, 6, '', '', 'VIII', '', 'V', 'VIII', 'I', '', '', 'A', '', 'B', 'C', 'B', '', '', 19, 'Y', ''),
(7, 2, 7, '', '', 'III', 'II', '', '', 'VIII', '', '', 'B', 'C', '', '', 'B', '', '', 19, 'Y', ''),
(8, 2, 8, '', '', 'III', 'VI', '', '', 'IV', '', '', 'A', 'C', '', '', 'B', '', '', 19, 'Y', ''),
(58, 2, 1, '9:30', '10:15', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 20, 'Y', ''),
(59, 2, 2, '10:15', '11:00', '', '', 'IV', '', 'V', '', '', '', '', 'A', '', 'A', '', '', 20, 'Y', ''),
(60, 2, 3, '11:10', '11:50', 'VII', '', '', '', '', '', '', 'A', '', '', '', '', '', '', 20, 'Y', ''),
(61, 2, 4, '11:50', '12:30', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 20, 'Y', ''),
(62, 2, 5, '13:15', '14:05', 'I', '', 'VI', '', 'II', '', '', 'A', '', 'A', '', 'A', '', '', 20, 'Y', ''),
(63, 2, 6, '14:05', '14:50', 'VIII', '', '', '', '', '', '', 'A', '', '', '', '', '', '', 20, 'Y', ''),
(64, 2, 7, '15:00', '15:45', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 20, 'Y', ''),
(65, 2, 8, '15:45', '16:30', 'III', '', '', '', '', '', '', 'A', '', '', '', '', '', '', 20, 'Y', '');

-- --------------------------------------------------------

--
-- Table structure for table `schools_period_schedule_days`
--

CREATE TABLE `schools_period_schedule_days` (
  `ID` int(11) NOT NULL,
  `period_no` int(11) NOT NULL,
  `period_date` date NOT NULL,
  `period_day` varchar(20) NOT NULL,
  `grade_id` int(11) NOT NULL,
  `grade_name` varchar(20) NOT NULL,
  `section` varchar(10) NOT NULL,
  `starttime` time NOT NULL,
  `endtime` time NOT NULL,
  `sid` int(11) NOT NULL,
  `academic_id` int(11) NOT NULL,
  `expected_user` int(11) NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `school_academic_mapping`
--

CREATE TABLE `school_academic_mapping` (
  `ID` int(11) NOT NULL,
  `SID` int(11) NOT NULL COMMENT 'SID => School ID',
  `AID` int(11) NOT NULL COMMENT 'AID => Academic ID',
  `Status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `school_academic_mapping`
--

INSERT INTO `school_academic_mapping` (`ID`, `SID`, `AID`, `Status`) VALUES
(2, 2, 19, 1),
(19, 2, 20, 1),
(20, 3, 20, 1),
(21, 172, 20, 1);

-- --------------------------------------------------------

--
-- Table structure for table `school_admin`
--

CREATE TABLE `school_admin` (
  `id` int(11) NOT NULL,
  `email` varchar(250) NOT NULL,
  `password` varchar(100) NOT NULL,
  `fname` varchar(50) NOT NULL,
  `lname` varchar(50) DEFAULT NULL,
  `initial` varchar(5) DEFAULT NULL,
  `mobile` int(15) NOT NULL,
  `dob` date DEFAULT NULL,
  `address` varchar(300) NOT NULL,
  `School_Name` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `school_id` int(11) NOT NULL,
  `active` int(1) NOT NULL,
  `status` int(1) NOT NULL,
  `session_id` varchar(255) NOT NULL,
  `createdby` varchar(100) NOT NULL,
  `creation_date` datetime NOT NULL,
  `modifiedby` varchar(100) NOT NULL,
  `modified_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `school_admin`
--

INSERT INTO `school_admin` (`id`, `email`, `password`, `fname`, `lname`, `initial`, `mobile`, `dob`, `address`, `School_Name`, `school_id`, `active`, `status`, `session_id`, `createdby`, `creation_date`, `modifiedby`, `modified_date`) VALUES
(3, 'adminskillangels', 'ca9139d33a0a27a6bcf77910a32514be', 'EdSix', 'Admin', NULL, 994049481, NULL, 'Chennai', '', 2, 1, 0, '', '', '0000-00-00 00:00:00', '', '2014-06-24 06:43:37'),
(38, 'grn@kinderangels.com', 'bb0a5ad40a9484988be58b9ce6202723', 'GRN School', 'Admin', NULL, 994049481, NULL, 'Chennai', '', 48, 1, 1, '', '', '2018-06-20 00:00:00', '', '2014-06-25 19:43:37'),
(39, 'saravarabic', 'ca9139d33a0a27a6bcf77910a32514be', 'Sri Lathangi Vidhya Mandir Matric. Hr. Sec. School', 'Admin', NULL, 994049481, NULL, 'Chennai', '', 50, 1, 1, '39201905102057091557502029418', '', '2018-06-21 00:00:00', '', '2014-06-25 19:43:37'),
(40, 'sps@kinderangels.com', 'bb0a5ad40a9484988be58b9ce6202723', 'Samartha Pre School', 'Admin', NULL, 994049481, NULL, 'Chennai', '', 1, 1, 1, '', '', '2018-06-26 00:00:00', '', '2014-06-25 19:43:37'),
(41, 'pvs@kinderangels.com', 'bb0a5ad40a9484988be58b9ce6202723', 'Pine View School', 'Admin', NULL, 994049481, NULL, 'BALLUPUR', '', 40, 0, 0, '', '', '2018-06-27 00:00:00', '', '2014-06-25 19:43:37'),
(42, 'bs@kinderangels.com', 'bb0a5ad40a9484988be58b9ce6202723', 'B.S.MATRIC.HR SEC SCHOOL', 'Admin', NULL, 994049481, NULL, 'Medavakkam', '', 52, 1, 1, '', '', '2018-06-28 00:00:00', '', '2014-06-25 19:43:37'),
(43, 'mbm@kinderangels.com', 'bb0a5ad40a9484988be58b9ce6202723', 'Shri Maharishi Bala Mandir', 'Admin', NULL, 994049481, NULL, 'Dindigul', '', 66, 1, 1, '43201907021315271562053527950', '', '2018-08-16 00:00:00', '', '2014-06-25 19:43:37'),
(44, 'akca@kinderangels.com', 'bb0a5ad40a9484988be58b9ce6202723', 'Akara International school - CAIE', 'Admin', NULL, 994049481, NULL, '', '', 59, 1, 1, '', '', '2018-08-16 00:00:00', '', '2014-06-25 19:43:37'),
(45, 'dpsd1819@kinderangels.com', 'bb0a5ad40a9484988be58b9ce6202723', 'DELHI PRIVATE SCHOOL - DUBAI', 'Admin', NULL, 994049481, NULL, '', '', 117, 1, 1, '', '', '2019-01-29 00:00:00', '', '2014-06-25 19:43:37'),
(46, 'as@kinderangels.com', 'bb0a5ad40a9484988be58b9ce6202723', 'Amity School - Dubai', 'Admin', NULL, 994049481, NULL, '', '', 108, 1, 1, '', '', '2019-02-07 00:00:00', '', '2014-06-25 19:43:37'),
(47, 'tws@kinderangels.com', 'bb0a5ad40a9484988be58b9ce6202723', 'THE WINCHESTER SCHOOL', 'Admin', NULL, 994049481, NULL, '', '', 118, 1, 1, '', '', '2019-03-11 00:00:00', '', '2014-06-25 19:43:37'),
(48, 'kgs@kinderangels.com', 'bb0a5ad40a9484988be58b9ce6202723', 'The Kindergarten Starters', 'Admin', NULL, 994049481, NULL, '', '', 119, 1, 1, '48201907021316171562053577516', '', '2019-04-09 00:00:00', '', '2014-06-25 19:43:37'),
(49, 'dpsd@kinderangels.com', 'bb0a5ad40a9484988be58b9ce6202723', 'DELHI PRIVATE SCHOOL - DUBAI', 'Admin', NULL, 994049481, NULL, '', '', 120, 1, 1, '', '', '2019-04-16 00:00:00', '', '2014-06-25 19:43:37'),
(50, 'pvs@kinderangels.com', 'bb0a5ad40a9484988be58b9ce6202723', 'Pine View School', 'Admin', NULL, 994049481, NULL, 'BALLUPUR', '', 121, 1, 1, '', '', '2019-04-29 00:00:00', '', '2014-06-25 19:43:37'),
(51, 'nv@kinderangels.com', 'bb0a5ad40a9484988be58b9ce6202723', 'NARBHAVI VIDYALAYA NURSERY & PRIMARY SCHOOL', 'Admin', NULL, 994049481, NULL, 'Neyveli', '', 122, 1, 1, '', '', '2019-06-17 00:00:00', '', '2014-06-25 19:43:37'),
(52, 'bs@kinderangels.com', 'bb0a5ad40a9484988be58b9ce6202723', 'Born Scholars Matriculation Higher Secondary Schoo', 'Admin', NULL, 994049481, NULL, 'Medavakkam', '', 123, 1, 1, '', '', '2019-06-20 00:00:00', '', '2014-06-25 19:43:37'),
(53, 'slvm@kinderangels.com', 'bb0a5ad40a9484988be58b9ce6202723', 'Sri Lathangi Vidhya Mandir Matric. Hr. Sec. School', 'Admin', NULL, 994049481, NULL, 'Pollachi', '', 124, 1, 1, '53201907021313521562053432933', '', '2019-06-20 00:00:00', '', '2014-06-25 19:43:37'),
(54, 'sga@kinderangels.com', 'bb0a5ad40a9484988be58b9ce6202723', 'SASSI GNANODAYA ACADEMY', 'Admin', NULL, 994049481, NULL, 'Dharmapuri', '', 125, 1, 1, '', '', '2019-06-20 00:00:00', '', '2014-06-25 19:43:37');

-- --------------------------------------------------------

--
-- Table structure for table `school_master`
--

CREATE TABLE `school_master` (
  `id` int(100) NOT NULL,
  `school_name` varchar(100) NOT NULL,
  `school_address` varchar(100) NOT NULL,
  `phone` int(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `school_code` varchar(100) NOT NULL,
  `zone` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `district` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `state` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `country` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `city` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `logo` longblob NOT NULL,
  `active` varchar(100) NOT NULL,
  `type` varchar(100) NOT NULL,
  `flag` tinyint(1) NOT NULL,
  `status` int(1) NOT NULL,
  `academic_id` int(11) NOT NULL,
  `createdby` varchar(100) NOT NULL,
  `creation_date` date NOT NULL,
  `modifiedby` varchar(100) NOT NULL,
  `modified_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `visible` int(11) NOT NULL DEFAULT '1',
  `start_date` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `school_master`
--

INSERT INTO `school_master` (`id`, `school_name`, `school_address`, `phone`, `email`, `school_code`, `zone`, `district`, `state`, `country`, `city`, `logo`, `active`, `type`, `flag`, `status`, `academic_id`, `createdby`, `creation_date`, `modifiedby`, `modified_date`, `visible`, `start_date`) VALUES
(2, 'Rotary Virtual School', 'Chennai', 1234567890, 'kalp@skillangels.com', '100', 'Chennai', 'Chennai', '31', '113', 'Chennai', 0x41544d2e706e67, '1', 'CBSE', 0, 1, 20, '', '0000-00-00', '', '2018-06-13 18:54:11', 1, '2018-02-05'),
(3, 'Jain Vidyalaya', '', 0, '', '', '', '', '31', '', '', '', '', '', 0, 0, 0, '', '0000-00-00', '', '2018-06-21 15:09:49', 1, ''),
(4, 'CK School of Practical Knowledge', '', 0, '', '', '', '', '31', '', '', '', '', '', 0, 0, 0, '', '0000-00-00', '', '2018-06-21 15:09:49', 1, ''),
(5, 'Bala Vidya Mandir Senior Secondary School', '', 0, '', '', '', '', '31', '', '', '', '', '', 0, 0, 0, '', '0000-00-00', '', '2018-06-21 15:09:49', 1, ''),
(6, 'GRG Matriculation Higher Secondary School', '', 0, '', '', '', '', '31', '', '', '', '', '', 0, 0, 0, '', '0000-00-00', '', '2018-06-21 15:09:49', 1, ''),
(7, 'Chandra Matriculation Higher Secondary School', '', 0, '', '', '', '', '31', '', '', '', '', '', 0, 0, 0, '', '0000-00-00', '', '2018-06-21 15:09:49', 1, ''),
(8, 'Velammal Vidyalaya Annexure', '', 0, '', '', '', '', '31', '', '', '', '', '', 0, 0, 0, '', '0000-00-00', '', '2018-06-21 15:09:49', 1, ''),
(9, 'Sri sathyasai matriculation school', '', 0, '', '', '', '', '31', '', '', '', '', '', 0, 0, 0, '', '0000-00-00', '', '2018-06-21 15:09:49', 1, ''),
(10, 'Shree Chhotubhai A Patel Learning Institute - English &Gujarathi Medium', '', 0, '', '', '', '', '31', '', '', '', '', '', 0, 0, 0, '', '0000-00-00', '', '2018-06-21 15:09:49', 1, ''),
(11, 'Global Matricualtion Higher Secondary School', '', 0, '', '', '', '', '31', '', '', '', '', '', 0, 0, 0, '', '0000-00-00', '', '2018-06-21 15:09:49', 1, ''),
(12, 'Sri Lathangi Vidhya Mandir Matriculation School', '', 0, '', '', '', '', '31', '', '', '', '', '', 0, 0, 0, '', '0000-00-00', '', '2018-06-21 15:09:49', 1, ''),
(13, 'Samartha Pre School', '', 0, '', '', '', '', '31', '', '', '', '', '', 0, 0, 0, '', '0000-00-00', '', '2018-06-21 15:09:49', 1, ''),
(14, 'GRD-CPF Matriculation', '', 0, '', '', '', '', '31', '', '', '', '', '', 0, 0, 0, '', '0000-00-00', '', '2018-06-21 15:09:49', 1, ''),
(15, 'GRN - Gopal Ramaswamy Naidu Matriculation Higher Secondary School', '', 0, '', '', '', '', '31', '', '', '', '', '', 0, 0, 0, '', '0000-00-00', '', '2018-06-21 15:09:49', 1, ''),
(16, 'Vidya Vanam', '', 0, '', '', '', '', '31', '', '', '', '', '', 0, 0, 0, '', '0000-00-00', '', '2018-06-21 15:09:49', 1, ''),
(17, 'Stella Mary\'s', '', 0, '', '', '', '', '31', '', '', '', '', '', 0, 0, 0, '', '0000-00-00', '', '2018-06-21 15:09:49', 1, ''),
(18, 'The Pine view school', '', 0, '', '', '', '', '31', '', '', '', '', '', 0, 0, 0, '', '0000-00-00', '', '2018-06-21 15:09:49', 1, ''),
(19, 'Jaihindh International school', '', 0, '', '', '', '', '31', '', '', '', '', '', 0, 0, 0, '', '0000-00-00', '', '2018-06-21 15:09:49', 1, ''),
(20, 'B S Matriculation Higher Secondary School', '', 0, '', '', '', '', '31', '', '', '', '', '', 0, 0, 0, '', '0000-00-00', '', '2018-06-21 15:09:49', 1, ''),
(21, 'Alpha Matric School', '', 0, '', '', '', '', '31', '', '', '', '', '', 0, 0, 0, '', '0000-00-00', '', '2018-06-21 15:09:49', 1, ''),
(22, 'Alpha International', '', 0, '', '', '', '', '31', '', '', '', '', '', 0, 0, 0, '', '0000-00-00', '', '2018-06-21 15:09:49', 1, '');

-- --------------------------------------------------------

--
-- Table structure for table `school_parent_master`
--

CREATE TABLE `school_parent_master` (
  `id` int(11) NOT NULL,
  `deviceid` varchar(40) NOT NULL,
  `mtoken` text NOT NULL,
  `name` varchar(110) NOT NULL,
  `username` varchar(255) NOT NULL,
  `salt1` varchar(110) NOT NULL,
  `password` varchar(255) NOT NULL,
  `salt2` varchar(110) NOT NULL,
  `mobileno` varchar(16) NOT NULL,
  `state` int(11) NOT NULL,
  `city` int(11) NOT NULL,
  `pincode` int(10) NOT NULL,
  `address` text NOT NULL,
  `portal_type` enum('B2B','B2C') NOT NULL,
  `orgpwd` varchar(255) NOT NULL,
  `status` int(11) NOT NULL,
  `createddate` datetime NOT NULL,
  `session_id` varchar(255) NOT NULL,
  `pre_logindate` date NOT NULL,
  `login_date` date NOT NULL,
  `login_count` int(11) NOT NULL,
  `islogin` int(11) NOT NULL,
  `last_active_datetime` datetime NOT NULL,
  `otp` int(11) NOT NULL,
  `otp_datetime` datetime NOT NULL,
  `site_type` enum('APP','WEB') NOT NULL DEFAULT 'APP'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `school_parent_master`
--

INSERT INTO `school_parent_master` (`id`, `deviceid`, `mtoken`, `name`, `username`, `salt1`, `password`, `salt2`, `mobileno`, `state`, `city`, `pincode`, `address`, `portal_type`, `orgpwd`, `status`, `createddate`, `session_id`, `pre_logindate`, `login_date`, `login_count`, `islogin`, `last_active_datetime`, `otp`, `otp_datetime`, `site_type`) VALUES
(1, '', '', 'Samartha Pre School', 'sps@kinderangels.com', '9830440821', '11e5b1e415fb0514daca4a4f56c17b12bfb76d2f', '833065157', '9789120543', 0, 0, 0, '', 'B2C', '12345678', 1, '2018-07-24 06:09:10', '12018072613385815325925386', '2018-07-25', '2018-07-26', 0, 0, '2018-07-26 08:09:34', 0, '0000-00-00 00:00:00', 'WEB'),
(2, '', '', 'Demo', 'hari.skillangels@gmail.com', '3578900936', '0258282ebc77176b9de001e04f00f89e0c98ab45', '691346553', '9884584861', 0, 0, 0, '', 'B2C', '12345678', 1, '2018-07-24 07:07:01', '2.2018072412400614e27', '0000-00-00', '2018-07-24', 1, 0, '2018-07-24 07:10:06', 0, '0000-00-00 00:00:00', 'WEB'),
(3, '', '', 'Satya Special School', 'ss@skillangels.com', '8154147172', '8492ca469bc34182d6f6ec3d7cd5f3e3060e2900', '350483740', '9500964163', 0, 0, 0, '', 'B2C', 'Password@123', 1, '2018-07-25 05:50:17', '3.201807251126351e27', '0000-00-00', '2018-07-25', 1, 0, '2018-07-26 05:39:17', 0, '0000-00-00 00:00:00', 'WEB'),
(40, '', '', 'Pine View School', 'pvs@kinderangels.com', '9830440821', '11e5b1e415fb0514daca4a4f56c17b12bfb76d2f', '833065157', '9789120543', 0, 0, 0, '', 'B2C', '12345678', 1, '2018-07-24 06:09:10', '12018072613385815325925386', '2018-07-25', '2018-07-26', 0, 0, '2018-07-26 08:09:34', 0, '0000-00-00 00:00:00', 'WEB'),
(48, '', '', 'GRN School', 'grn@kinderangels.com', '9830440821', '11e5b1e415fb0514daca4a4f56c17b12bfb76d2f', '833065157', '9789120543', 0, 0, 0, '', 'B2C', '12345678', 1, '2018-07-24 06:09:10', '12018072613385815325925386', '2018-07-25', '2018-07-26', 0, 0, '2018-07-26 08:09:34', 0, '0000-00-00 00:00:00', 'WEB'),
(50, '', '', 'Sri Lathangi Vidhya Mandir Matric. Hr. Sec. School', 'slvm@kinderangels.com', '9830440821', '11e5b1e415fb0514daca4a4f56c17b12bfb76d2f', '833065157', '9789120543', 0, 0, 0, '', 'B2C', '12345678', 1, '2018-07-24 06:09:10', '12018072613385815325925386', '2018-07-25', '2018-07-26', 0, 0, '2018-07-26 08:09:34', 0, '0000-00-00 00:00:00', 'WEB'),
(52, '', '', 'Born Scholars Matriculation Higher Secondary School', 'bs@kinderangels.com', '9830440821', '11e5b1e415fb0514daca4a4f56c17b12bfb76d2f', '833065157', '9789120543', 0, 0, 0, '', 'B2C', '12345678', 1, '2018-07-24 06:09:10', '12018072613385815325925386', '2018-07-25', '2018-07-26', 0, 0, '2018-07-26 08:09:34', 0, '0000-00-00 00:00:00', 'WEB'),
(59, '', '', 'Akara International school - CAIE', 'akca@kinderangels.com', '9830440821', '11e5b1e415fb0514daca4a4f56c17b12bfb76d2f', '833065157', '9789120543', 0, 0, 0, '', 'B2C', '12345678', 1, '2018-07-24 06:09:10', '12018072613385815325925386', '2018-07-25', '2018-07-26', 0, 0, '2018-07-26 08:09:34', 0, '0000-00-00 00:00:00', 'WEB'),
(66, '', '', 'Shri Maharishi Bala Mandir', 'mbm@kinderangels.com', '9830440821', '11e5b1e415fb0514daca4a4f56c17b12bfb76d2f', '833065157', '9789120543', 0, 0, 0, '', 'B2C', '12345678', 1, '2018-07-24 06:09:10', '12018072613385815325925386', '2018-07-25', '2018-07-26', 0, 0, '2018-07-26 08:09:34', 0, '0000-00-00 00:00:00', 'WEB'),
(67, '', '', 'Agathiya', 'ramagathiya6@gmail.com', '8968486046', 'b075101acd6ef94decc7dffe450c0c6f68a195bf', '585025388', '9750086198', 0, 0, 0, '', 'B2C', 'agathiya2008', 0, '2018-10-14 13:58:19', '', '0000-00-00', '0000-00-00', 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 'WEB'),
(68, '', '', 'R Agathiya', 'revathiramesha@gmail.com', '1820263348', '14927cf412cf31ad5a9cb84275051ba2043fbc5d', '62534825', '6381226784', 0, 0, 0, '', 'B2C', 'Agathiya2008', 1, '2018-10-14 14:03:53', '', '0000-00-00', '0000-00-00', 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 'WEB');

-- --------------------------------------------------------

--
-- Stand-in structure for view `sc_daywisemaxpuzzlesattempted`
-- (See below for the actual view)
--
CREATE TABLE `sc_daywisemaxpuzzlesattempted` (
`gu_id` int(10)
,`grade_id` int(10)
,`gp_id` int(10)
,`sid` varchar(100)
,`section` varchar(10)
,`username` varchar(255)
,`fname` varchar(100)
,`org_id` int(11)
,`PuzzlesAttempted` double
,`lastupdate` date
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `sc_daywisemaxpuzzlessolved`
-- (See below for the actual view)
--
CREATE TABLE `sc_daywisemaxpuzzlessolved` (
`gu_id` int(10)
,`grade_id` int(10)
,`gp_id` int(10)
,`sid` varchar(100)
,`section` varchar(10)
,`username` varchar(255)
,`fname` varchar(100)
,`org_id` int(11)
,`PuzzlesSolved` double
,`lastupdate` date
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `sc_daywisetopscorer`
-- (See below for the actual view)
--
CREATE TABLE `sc_daywisetopscorer` (
`gu_id` int(10)
,`grade_id` int(10)
,`gp_id` int(10)
,`sid` varchar(100)
,`section` varchar(10)
,`username` varchar(255)
,`fname` varchar(100)
,`org_id` int(11)
,`score` double
,`lastupdate` date
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `sc_maxpuzzlesattempted`
-- (See below for the actual view)
--
CREATE TABLE `sc_maxpuzzlesattempted` (
`gu_id` int(10)
,`grade_id` int(10)
,`gp_id` int(10)
,`sid` varchar(100)
,`section` varchar(10)
,`username` varchar(255)
,`fname` varchar(100)
,`org_id` int(11)
,`PuzzlesAttempted` double
,`lastupdate` date
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `sc_maxpuzzlessolved`
-- (See below for the actual view)
--
CREATE TABLE `sc_maxpuzzlessolved` (
`gu_id` int(10)
,`grade_id` int(10)
,`gp_id` int(10)
,`sid` varchar(100)
,`section` varchar(10)
,`username` varchar(255)
,`fname` varchar(100)
,`org_id` int(11)
,`PuzzlesSolved` double
,`lastupdate` date
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `sc_topscorer`
-- (See below for the actual view)
--
CREATE TABLE `sc_topscorer` (
`gu_id` int(10)
,`grade_id` int(10)
,`gp_id` int(10)
,`sid` varchar(100)
,`section` varchar(10)
,`username` varchar(255)
,`fname` varchar(100)
,`org_id` int(11)
,`score` double
,`lastupdate` date
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `sc_usertotgamescore`
-- (See below for the actual view)
--
CREATE TABLE `sc_usertotgamescore` (
`gu_id` int(10)
,`grade_id` int(10)
,`gp_id` int(10)
,`sid` varchar(100)
,`section` varchar(10)
,`username` varchar(255)
,`fname` varchar(100)
,`org_id` int(11)
,`score` double
);

-- --------------------------------------------------------

--
-- Table structure for table `section`
--

CREATE TABLE `section` (
  `id` int(11) NOT NULL,
  `section` int(11) NOT NULL,
  `status` int(1) NOT NULL,
  `createdby` varchar(100) NOT NULL,
  `creation_date` date NOT NULL,
  `modifiedby` varchar(100) NOT NULL,
  `modified_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `skillkit_configuration`
--

CREATE TABLE `skillkit_configuration` (
  `Recid` int(11) NOT NULL,
  `GamesNos` int(11) NOT NULL,
  `PlayTimes` int(11) NOT NULL,
  `EffectiveFrom` date NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `skillkit_configuration`
--

INSERT INTO `skillkit_configuration` (`Recid`, `GamesNos`, `PlayTimes`, `EffectiveFrom`) VALUES
(3, 3, 1, '2015-02-01');

-- --------------------------------------------------------

--
-- Table structure for table `skillkit_game_reports`
--

CREATE TABLE `skillkit_game_reports` (
  `id` int(11) NOT NULL,
  `gu_id` int(10) NOT NULL,
  `gc_id` int(10) NOT NULL,
  `gs_id` int(10) NOT NULL,
  `gp_id` varchar(100) NOT NULL,
  `g_id` int(30) NOT NULL,
  `total_question` varchar(15) NOT NULL,
  `attempt_question` varchar(20) NOT NULL,
  `answer` varchar(20) NOT NULL,
  `game_score` varchar(50) NOT NULL,
  `gtime` varchar(100) NOT NULL,
  `rtime` varchar(100) NOT NULL,
  `crtime` varchar(100) NOT NULL,
  `wrtime` varchar(100) NOT NULL,
  `GameTypeFlg` varchar(25) NOT NULL,
  `lastupdate` date NOT NULL,
  `createdby` varchar(100) NOT NULL,
  `creation_date` date NOT NULL,
  `modifiedby` varchar(100) NOT NULL,
  `modified_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `skillkit_random_game`
--

CREATE TABLE `skillkit_random_game` (
  `id` int(5) NOT NULL,
  `userid` varchar(50) NOT NULL,
  `gameid` varchar(50) NOT NULL,
  `datecreated` date NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `skillkit_random_game`
--

INSERT INTO `skillkit_random_game` (`id`, `userid`, `gameid`, `datecreated`) VALUES
(1, '7433', '188', '2017-01-02'),
(2, '7433', '72', '2017-01-02'),
(3, '7433', '488', '2017-01-02'),
(4, '7433', '312', '2017-01-03'),
(5, '7433', '147', '2017-01-03'),
(6, '7433', '71', '2017-01-03'),
(7, '7433', '147', '2017-01-06'),
(8, '7433', '69', '2017-01-06'),
(9, '7433', '153', '2017-01-06'),
(10, '7433', '150', '2017-01-07'),
(11, '7433', '34', '2017-01-07'),
(12, '7433', '308', '2017-01-07'),
(13, '7441', '320', '2017-01-07'),
(14, '7441', '162', '2017-01-07'),
(15, '7441', '321', '2017-01-07');

-- --------------------------------------------------------

--
-- Table structure for table `skl_class`
--

CREATE TABLE `skl_class` (
  `id` int(11) NOT NULL,
  `school_id` int(11) NOT NULL,
  `class_id` int(11) NOT NULL,
  `status` int(1) NOT NULL,
  `createdby` varchar(100) NOT NULL,
  `creation_date` date NOT NULL,
  `modifiedby` varchar(100) NOT NULL,
  `modified_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `skl_class_plan`
--

CREATE TABLE `skl_class_plan` (
  `id` int(11) NOT NULL,
  `school_id` int(11) NOT NULL,
  `class_id` int(11) NOT NULL,
  `plan_id` int(11) NOT NULL,
  `status` int(1) NOT NULL,
  `createdby` varchar(100) NOT NULL,
  `creation_date` date NOT NULL,
  `modifiedby` varchar(100) NOT NULL,
  `modified_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `skl_class_plan`
--

INSERT INTO `skl_class_plan` (`id`, `school_id`, `class_id`, `plan_id`, `status`, `createdby`, `creation_date`, `modifiedby`, `modified_date`) VALUES
(2, 2, 3, 1, 0, '', '0000-00-00', '', '2017-05-31 17:09:53'),
(3, 2, 4, 2, 0, '', '0000-00-00', '', '2017-05-31 17:09:57'),
(4, 2, 5, 3, 0, '', '0000-00-00', '', '2017-05-31 17:10:01'),
(5, 2, 6, 4, 0, '', '0000-00-00', '', '2017-05-31 17:10:08'),
(6, 2, 7, 5, 0, '', '0000-00-00', '', '2017-05-31 17:10:13'),
(7, 2, 8, 6, 0, '', '0000-00-00', '', '2017-05-31 17:10:21'),
(8, 2, 9, 7, 0, '', '0000-00-00', '', '2017-05-31 17:10:25'),
(9, 2, 10, 8, 0, '', '0000-00-00', '', '2017-05-31 17:10:28'),
(156, 2, 1, 10, 0, '', '0000-00-00', '', '2017-05-31 17:10:28'),
(157, 2, 2, 11, 0, '', '0000-00-00', '', '2017-05-31 17:10:28'),
(158, 2, 11, 91, 0, '', '0000-00-00', '', '2017-05-31 17:10:28'),
(159, 3, 11, 91, 0, '', '0000-00-00', '', '2017-05-31 17:10:28');

-- --------------------------------------------------------

--
-- Table structure for table `skl_class_section`
--

CREATE TABLE `skl_class_section` (
  `id` int(11) NOT NULL,
  `school_id` int(11) NOT NULL,
  `class_id` int(11) NOT NULL,
  `section` varchar(10) NOT NULL,
  `status` int(1) NOT NULL,
  `createdby` varchar(100) NOT NULL,
  `creation_date` date NOT NULL,
  `modifiedby` text NOT NULL,
  `modified_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `skl_class_section`
--

INSERT INTO `skl_class_section` (`id`, `school_id`, `class_id`, `section`, `status`, `createdby`, `creation_date`, `modifiedby`, `modified_date`) VALUES
(34, 2, 3, 'A', 0, '', '0000-00-00', '', '2014-06-23 14:22:26'),
(35, 2, 4, 'A', 0, '', '0000-00-00', '', '2014-06-23 14:22:30'),
(36, 2, 5, 'A', 0, '', '0000-00-00', '', '2014-06-23 14:22:37'),
(37, 2, 6, 'A', 0, '', '0000-00-00', '', '2014-06-23 14:22:41'),
(38, 2, 7, 'A', 0, '', '0000-00-00', '', '2014-06-23 14:22:46'),
(39, 2, 8, 'A', 0, '', '0000-00-00', '', '2014-06-23 14:22:51'),
(40, 2, 9, 'A', 0, '', '0000-00-00', '', '2014-06-23 14:22:58'),
(41, 2, 10, 'A', 0, '', '0000-00-00', '', '2014-06-23 14:23:04'),
(402, 2, 1, 'A', 0, '', '0000-00-00', '', '2014-06-23 14:23:04'),
(403, 2, 2, 'A', 0, '', '0000-00-00', '', '2014-06-23 14:23:04'),
(404, 2, 11, 'A', 0, '', '0000-00-00', '', '2014-06-23 14:23:04'),
(405, 3, 11, 'A', 0, '', '0000-00-00', '', '2014-06-23 14:23:04');

-- --------------------------------------------------------

--
-- Table structure for table `skl_dcnt_coupon`
--

CREATE TABLE `skl_dcnt_coupon` (
  `id` int(11) NOT NULL,
  `dcnt_name` varchar(70) NOT NULL,
  `dcnt_code` varchar(25) NOT NULL,
  `percentage` varchar(11) NOT NULL,
  `timecreated` int(11) NOT NULL,
  `timemodified` int(11) NOT NULL,
  `startdate` int(11) NOT NULL,
  `enddate` int(11) NOT NULL,
  `status` int(1) NOT NULL,
  `createdby` varchar(100) NOT NULL,
  `creation_date` date NOT NULL,
  `modifiedby` varchar(100) NOT NULL,
  `modified_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `skl_grade`
--

CREATE TABLE `skl_grade` (
  `id` int(11) NOT NULL,
  `grdname` varchar(45) NOT NULL,
  `status` int(1) NOT NULL,
  `createdby` varchar(100) NOT NULL,
  `creation_date` date NOT NULL,
  `modifiedby` varchar(100) NOT NULL,
  `modified_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `skl_grade_game_map`
--

CREATE TABLE `skl_grade_game_map` (
  `id` int(11) NOT NULL,
  `school_id` int(11) NOT NULL,
  `game_id` int(11) NOT NULL,
  `grade_id` int(11) NOT NULL,
  `status` int(1) NOT NULL,
  `createdby` varchar(100) NOT NULL,
  `creation_date` date NOT NULL,
  `modifiedby` varchar(100) NOT NULL,
  `modified_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `skl_prepaid_coupon`
--

CREATE TABLE `skl_prepaid_coupon` (
  `id` int(100) NOT NULL,
  `prepaid_name` varchar(100) NOT NULL,
  `prepaid_code` varchar(100) NOT NULL,
  `plan_id` int(100) NOT NULL,
  `timecreated` int(100) NOT NULL,
  `expirytime` int(100) NOT NULL,
  `used` int(5) NOT NULL DEFAULT '0',
  `userid` int(100) NOT NULL,
  `timeenrolled` int(100) NOT NULL,
  `createdby` varchar(100) NOT NULL,
  `creation_date` date NOT NULL,
  `modifiedby` varchar(100) NOT NULL,
  `modified_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `skl_prepaid_coupon`
--

INSERT INTO `skl_prepaid_coupon` (`id`, `prepaid_name`, `prepaid_code`, `plan_id`, `timecreated`, `expirytime`, `used`, `userid`, `timeenrolled`, `createdby`, `creation_date`, `modifiedby`, `modified_date`) VALUES
(1, '', '62168145352', 52, 1400415621, 1398882600, 0, 0, 0, '', '0000-00-00', '', '2014-05-16 06:50:21'),
(2, '', '63579785352', 52, 1400415621, 1398882600, 0, 0, 0, '', '0000-00-00', '', '2014-05-16 06:50:21'),
(3, '', '68148375352', 52, 1400415621, 1398882600, 0, 0, 0, '', '0000-00-00', '', '2014-05-16 06:50:21'),
(4, '', '75349695352', 52, 1400415621, 1398882600, 0, 0, 0, '', '0000-00-00', '', '2014-05-16 06:50:21'),
(5, '', '81925175352', 52, 1400415621, 1398882600, 0, 0, 0, '', '0000-00-00', '', '2014-05-16 06:50:21'),
(6, '', '17813485352', 52, 1400415621, 1398882600, 0, 0, 0, '', '0000-00-00', '', '2014-05-16 06:50:21'),
(7, '', '48575475352', 52, 1400415621, 1398882600, 0, 0, 0, '', '0000-00-00', '', '2014-05-16 06:50:21'),
(8, '', '12952595352', 52, 1400415621, 1398882600, 0, 0, 0, '', '0000-00-00', '', '2014-05-16 06:50:21'),
(9, '', '38638545352', 52, 1400415621, 1398882600, 0, 0, 0, '', '0000-00-00', '', '2014-05-16 06:50:21'),
(10, '', '15738965352', 52, 1400415621, 1398882600, 0, 0, 0, '', '0000-00-00', '', '2014-05-16 06:50:21'),
(11, '', '39321965352', 52, 1400415621, 1398882600, 0, 0, 0, '', '0000-00-00', '', '2014-05-16 06:50:21'),
(12, '', '95387545352', 52, 1400415621, 1398882600, 0, 0, 0, '', '0000-00-00', '', '2014-05-16 06:50:21'),
(13, '', '42971255352', 52, 1400415621, 1398882600, 0, 0, 0, '', '0000-00-00', '', '2014-05-16 06:50:21'),
(14, '', '91253725352', 52, 1400415621, 1398882600, 0, 0, 0, '', '0000-00-00', '', '2014-05-16 06:50:21'),
(15, '', '67231615352', 52, 1400415621, 1398882600, 0, 0, 0, '', '0000-00-00', '', '2014-05-16 06:50:21'),
(16, '', '15852635352', 52, 1400415621, 1398882600, 0, 0, 0, '', '0000-00-00', '', '2014-05-16 06:50:21'),
(17, '', '95674745352', 52, 1400415621, 1398882600, 0, 0, 0, '', '0000-00-00', '', '2014-05-16 06:50:21'),
(18, '', '29645745352', 52, 1400415621, 1398882600, 0, 0, 0, '', '0000-00-00', '', '2014-05-16 06:50:21'),
(19, '', '54159795352', 52, 1400415621, 1398882600, 0, 0, 0, '', '0000-00-00', '', '2014-05-16 06:50:21'),
(20, '', '83652835352', 52, 1400415621, 1398882600, 0, 0, 0, '', '0000-00-00', '', '2014-05-16 06:50:21'),
(21, '', '24259385352', 52, 1400415621, 1398882600, 0, 0, 0, '', '0000-00-00', '', '2014-05-16 06:50:21'),
(22, '', '72917975352', 52, 1400415621, 1398882600, 0, 0, 0, '', '0000-00-00', '', '2014-05-16 06:50:21'),
(23, '', '58616935352', 52, 1400415621, 1398882600, 0, 0, 0, '', '0000-00-00', '', '2014-05-16 06:50:21');

-- --------------------------------------------------------

--
-- Table structure for table `sk_gamedata`
--

CREATE TABLE `sk_gamedata` (
  `id` int(11) NOT NULL,
  `gu_id` int(10) NOT NULL,
  `gc_id` int(10) NOT NULL,
  `gs_id` int(10) NOT NULL,
  `gp_id` int(100) NOT NULL,
  `g_id` int(30) NOT NULL,
  `total_question` varchar(15) NOT NULL,
  `attempt_question` varchar(20) NOT NULL,
  `answer` varchar(20) NOT NULL,
  `game_score` varchar(50) NOT NULL,
  `gtime` varchar(100) NOT NULL,
  `rtime` varchar(100) NOT NULL,
  `crtime` varchar(100) NOT NULL,
  `wrtime` varchar(100) NOT NULL,
  `lastupdate` date NOT NULL,
  `createdby` varchar(100) NOT NULL,
  `creation_date` date NOT NULL,
  `modifiedby` varchar(100) NOT NULL,
  `modified_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sk_gamedata`
--

INSERT INTO `sk_gamedata` (`id`, `gu_id`, `gc_id`, `gs_id`, `gp_id`, `g_id`, `total_question`, `attempt_question`, `answer`, `game_score`, `gtime`, `rtime`, `crtime`, `wrtime`, `lastupdate`, `createdby`, `creation_date`, `modifiedby`, `modified_date`) VALUES
(12, 35987, 1, 62, 3, 31, '10', '10', '6', '60', '163', '12', '4', '0', '2017-08-10', '', '0000-00-00', '', '2017-08-08 03:51:01'),
(13, 35987, 1, 62, 3, 30, '10', '10', '10', '100', '150', '12', '12', '0', '2017-08-10', '', '0000-00-00', '', '2017-08-08 07:11:55'),
(14, 35987, 1, 62, 3, 30, '10', '10', '10', '100', '150', '13', '13', '0', '2017-08-10', '', '0000-00-00', '', '2017-08-08 07:46:58'),
(15, 35987, 1, 62, 3, 30, '10', '10', '10', '100', '150', '12', '12', '0', '2017-08-10', '', '0000-00-00', '', '2017-08-08 07:47:40'),
(16, 35987, 1, 62, 3, 30, '10', '10', '10', '100', '153', '11', '10', '0', '2017-08-10', '', '0000-00-00', '', '2017-08-08 07:48:27'),
(17, 35987, 1, 62, 3, 30, '10', '10', '10', '100', '149', '14', '14', '0', '2017-08-10', '', '0000-00-00', '', '2017-08-08 07:49:10'),
(18, 35987, 1, 59, 3, 3, '10', '10', '9', '90', '57', '21', '18', '3', '2017-08-11', '', '0000-00-00', '', '2017-08-08 22:38:47'),
(19, 35987, 1, 59, 3, 3, '10', '10', '10', '100', '48', '20', '20', '0', '2017-08-11', '', '0000-00-00', '', '2017-08-08 22:41:14'),
(20, 35987, 1, 59, 3, 3, '10', '10', '10', '84', '16', '51', '51', '0', '2017-08-11', '', '0000-00-00', '', '2017-08-08 22:48:46'),
(21, 35987, 1, 59, 3, 3, '10', '8', '8', '76', '180', '21', '21', '0', '2017-08-11', '', '0000-00-00', '', '2017-08-08 22:52:09'),
(22, 35987, 1, 59, 3, 3, '10', '10', '9', '89', '44', '25', '20', '5', '2017-08-11', '', '0000-00-00', '', '2017-08-08 22:54:46'),
(23, 35987, 1, 61, 3, 26, '10', '10', '6', '53', '139', '27', '20', '5', '2017-08-11', '', '0000-00-00', '', '2017-08-09 06:27:29'),
(24, 35987, 1, 61, 3, 26, '10', '10', '5', '50', '151', '14', '7', '6', '2017-08-11', '', '0000-00-00', '', '2017-08-09 06:29:05'),
(25, 35987, 1, 61, 3, 26, '10', '10', '10', '87', '107', '56', '56', '0', '2017-08-11', '', '0000-00-00', '', '2017-08-09 06:31:33'),
(26, 35987, 1, 61, 3, 26, '10', '10', '7', '59', '126', '37', '29', '8', '2017-08-11', '', '0000-00-00', '', '2017-08-09 06:33:01'),
(27, 35987, 1, 61, 3, 26, '10', '10', '10', '91', '135', '28', '28', '0', '2017-08-11', '', '0000-00-00', '', '2017-08-09 06:34:06'),
(664, 35987, 1, 0, 3, 0, '10', '10', '2', '20', '135', '12', '1', '4', '2017-11-21', '', '0000-00-00', '', '2017-11-19 08:17:07'),
(665, 35987, 1, 62, 3, 28, '10', '10', '4', '40', '140', '11', '2', '1', '2017-11-21', '', '0000-00-00', '', '2017-11-19 08:26:38'),
(666, 35987, 1, 59, 3, 5, '10', '10', '7', '70', '102', '11', '8', '3', '2017-11-21', '', '0000-00-00', '', '2017-11-19 08:29:07'),
(667, 35987, 1, 62, 3, 28, '10', '10', '7', '64', '117', '25', '14', '8', '2017-11-21', '', '0000-00-00', '', '2017-11-19 08:30:36'),
(668, 1, 1, 63, 3, 36, '10', '10', '8', '79', '137', '27', '19', '8', '2017-11-21', '', '0000-00-00', '', '2017-11-19 08:49:01'),
(669, 1, 1, 60, 3, 55, '10', '10', '8', '77', '114', '20', '17', '3', '2017-11-21', '', '0000-00-00', '', '2017-11-19 08:50:21'),
(670, 37422, 1, 60, 4, 52, '10', '10', '9', '62', '94', '70', '55', '15', '2017-11-24', '', '0000-00-00', '', '2017-11-22 05:57:05'),
(671, 37422, 1, 60, 4, 51, '10', '10', '10', '85', '121', '43', '43', '0', '2017-11-26', '', '0000-00-00', '', '2017-11-24 05:39:50'),
(672, 37422, 1, 60, 4, 51, '10', '10', '10', '92', '126', '38', '38', '0', '2017-11-26', '', '0000-00-00', '', '2017-11-24 05:53:44'),
(673, 37422, 1, 60, 4, 51, '10', '10', '10', '80', '112', '50', '50', '0', '2017-11-26', '', '0000-00-00', '', '2017-11-24 05:55:10');

-- --------------------------------------------------------

--
-- Stand-in structure for view `sk_gamedata_updated`
-- (See below for the actual view)
--
CREATE TABLE `sk_gamedata_updated` (
`id` int(11)
,`gu_id` int(11)
,`gp_id` int(11)
,`gc_id` int(11)
,`gs_id` int(11)
,`g_id` int(11)
,`total_question` int(2)
,`attempt_question` bigint(21)
,`answer` decimal(23,0)
,`game_score` decimal(32,0)
,`gtime` int(11)
,`rtime` decimal(32,0)
,`crtime` decimal(32,0)
,`wrtime` decimal(32,0)
,`lastupdate` date
,`iteration` int(11)
);

-- --------------------------------------------------------

--
-- Table structure for table `sk_games`
--

CREATE TABLE `sk_games` (
  `ID` int(11) NOT NULL,
  `skill_ID` int(11) NOT NULL,
  `game_masterID` int(11) NOT NULL,
  `name` varchar(400) NOT NULL,
  `swf_path` varchar(800) NOT NULL,
  `image_path` varchar(800) NOT NULL,
  `description` varchar(400) NOT NULL,
  `status` enum('Y','N') NOT NULL,
  `created_by` int(11) NOT NULL,
  `created_date` datetime NOT NULL,
  `modified_by` int(11) NOT NULL,
  `modified_date` datetime NOT NULL,
  `game_html` varchar(800) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sk_games`
--

INSERT INTO `sk_games` (`ID`, `skill_ID`, `game_masterID`, `name`, `swf_path`, `image_path`, `description`, `status`, `created_by`, `created_date`, `modified_by`, `modified_date`, `game_html`) VALUES
(1, 59, 1, 'AlphaNumericEncode-Level1', 'uploads/AlphaNumericEncode-Level1_4518458847.swf', 'uploads/AlphaNumericEncode-Level1_4518458847.png', 'Memory', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'AlphaNumericEncode-Level1'),
(2, 59, 3, 'BusRide-Level1', 'uploads/BusRide-Level1_9721776302.swf', 'uploads/BusRide-Level1_9721776302.png', 'Memory', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'BusRide-Level1'),
(3, 59, 4, 'CycleRace-Level1', 'uploads/CycleRace-Level1_2532993447.swf', 'uploads/CycleRace-Level1_2532993447.png', 'Memory', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'CycleRace-Level1'),
(4, 59, 5, 'MemoryCheck-Level1', 'uploads/MemoryCheck-Level1_1938757994.swf', 'uploads/MemoryCheck-Level1_1938757994.png', 'Memory', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'MemoryCheck-Level1'),
(5, 59, 6, 'MindCapture-Level1', 'uploads/MindCapture-Level1_9870321140.swf', 'uploads/MindCapture-Level1_9870321140.png', 'Memory', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'MindCapture-Level1'),
(6, 59, 7, 'MomAndMe', 'uploads/MomAndMe_6942562656.swf', 'uploads/MomAndMe_6942562656.png', 'Memory', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'MomAndMe'),
(7, 59, 8, 'SequenceMemory-Level1', 'uploads/SequenceMemory-Level1_903124888.swf', 'uploads/SequenceMemory-Level1_903124888.png', 'Memory', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'SequenceMemory-Level1'),
(8, 60, 9, 'BestFit-Level3', 'uploads/BestFit-Level2_6896948479.swf', 'uploads/BestFit-Level2_6896948479.png', 'VP', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-22 09:53:45', 'BestFit-Level3'),
(9, 60, 10, 'CharacterShade-Level1', 'uploads/CharacterShade-Level1_3409011624.swf', 'uploads/CharacterShade-Level1_3409011624.png', 'VP', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'CharacterShade-Level1'),
(10, 60, 11, 'EdCells-Level1', 'uploads/EdCells-Level1_376414950.swf', 'uploads/EdCells-Level1_376414950.png', 'VP', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'EdCells-Level1'),
(11, 60, 12, 'EyeCells-Level1', 'uploads/EyeCells-Level1_7996039153.swf', 'uploads/EyeCells-Level1_7996039153.png', 'VP', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'EyeCells-Level1'),
(12, 60, 15, 'Face2Face-Level1', 'uploads/Face2Face-Level1_5178543743.swf', 'uploads/Face2Face-Level1_5178543743.png', 'VP', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'Face2Face-Level1'),
(13, 60, 16, 'MatchMe-Level1', 'uploads/MatchMe-Level1_3344377102.swf', 'uploads/MatchMe-Level1_3344377102.png', 'VP', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'MatchMe-Level1'),
(14, 60, 17, 'ObjectShade', 'uploads/ObjectShade_7239343100.swf', 'uploads/ObjectShade_7239343100.png', 'VP', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'ObjectShade'),
(15, 60, 18, 'WordWipe-Level1', 'uploads/WordWipe-Level1_7054595984.swf', 'uploads/WordWipe-Level1_7054595984.png', 'VP', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'WordWipe-Level1'),
(16, 61, 19, 'LetterJigsaw-Level1', 'uploads/AlphabetJigsaw-Level1_6780601199.swf', 'uploads/AlphabetJigsaw-Level1_6780601199.png', 'FA', 'Y', 0, '2014-06-17 00:00:00', 0, '2017-06-12 09:52:20', 'LetterJigsaw-Level1'),
(17, 61, 20, 'DownUnder-Level1', 'uploads/DownUnder-Level1_9248090591.swf', 'uploads/DownUnder-Level1_9248090591.png', 'FA', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'DownUnder-Level1'),
(18, 61, 21, 'LastLegend-Level1', 'uploads/LastLegend-Level1_3132143379.swf', 'uploads/LastLegend-Level1_3132143379.png', 'FA', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'LastLegend-Level1'),
(19, 61, 22, 'NumberJigsaw-Level1', 'uploads/NumberJigsaw-Level1_3981064627.swf', 'uploads/NumberJigsaw-Level1_3981064627.png', 'FA', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'NumberJigsaw-Level1'),
(20, 61, 23, 'SpotMe-Level1', 'uploads/SpotMe-Level1_2213080883.swf', 'uploads/SpotMe-Level1_2213080883.png', 'FA', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'SpotMe-Level1'),
(21, 61, 24, 'StarLight-Level3', 'uploads/StarLight-Level1_9186881147.swf', 'uploads/StarLight-Level1_9186881147.png', 'FA', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-22 09:53:34', 'StarLight-Level3'),
(22, 61, 25, 'StrangerGrid-Level3', 'uploads/StrangerGrid_9728514011.swf', 'uploads/StrangerGrid_9728514011.png', 'FA', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-22 09:54:28', 'StrangerGrid-Level3'),
(23, 61, 26, 'WordSpell-Level1', 'uploads/WordSpell-Level1_4793716236.swf', 'uploads/WordSpell-Level1_4793716236.png', 'FA', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'WordSpell-Level1'),
(24, 62, 27, 'AddMaster-Level1', 'uploads/AddMaster-Level1_5437691258.swf', 'uploads/AddMaster-Level1_5437691258.png', 'PS', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'AddMaster-Level1'),
(25, 62, 28, 'HeavyOrLight-Level1', 'uploads/HeavyOrLight-Level1_9671432706.swf', 'uploads/HeavyOrLight-Level1_9671432706.png', 'PS', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'HeavyOrLight-Level1'),
(26, 62, 29, 'NumberDecode-Level1', 'uploads/NumberDecode-Level1_5552706075.swf', 'uploads/NumberDecode-Level1_5552706075.png', 'PS', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'NumberDecode-Level1'),
(27, 62, 30, 'NumbersOnTheWheel-Level1', 'uploads/NumbersOnTheWheel-Level1_5239142207.swf', 'uploads/NumbersOnTheWheel-Level1_5239142207.png', 'PS', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'NumbersOnTheWheel-Level1'),
(28, 62, 31, 'ParaMaster-Level1', 'uploads/ParaMaster-Level1_8246283596.swf', 'uploads/ParaMaster-Level1_8246283596.png', 'PS', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'ParaMaster-Level1'),
(29, 62, 32, 'Reshuffle-Level1', 'uploads/Reshuffle-Level1_9448890620.swf', 'uploads/Reshuffle-Level1_9448890620.png', 'PS', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'Reshuffle-Level1'),
(30, 62, 33, 'WhatComesNext', 'uploads/WhatComesNext_8895443235.swf', 'uploads/WhatComesNext_8895443235.png', 'PS', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'WhatComesNext'),
(31, 62, 34, 'WordShapes-Level1', 'uploads/WordShapes-Level1_5870673032.swf', 'uploads/WordShapes-Level1_5870673032.png', 'PS', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'WordShapes-Level1'),
(32, 63, 35, 'CompoundWords', 'uploads/CompoundWords_12777526.swf', 'uploads/CompoundWords_12777526.png', 'L', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'CompoundWords'),
(33, 63, 36, 'WhoAmI_Birds', 'uploads/WhoAmI-Birds_7869069152.swf', 'uploads/WhoAmI-Birds_7869069152.png', 'L', 'Y', 0, '2014-06-17 00:00:00', 0, '2017-06-12 09:55:12', 'WhoAmI_Birds'),
(34, 63, 37, 'WhoAmI-Colors', 'uploads/WhoAmI-Colors_1446446431.swf', 'uploads/WhoAmI-Colors_1446446431.png', 'L', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'WhoAmI-Colors'),
(35, 63, 38, 'WhoAmI-DomesticAnimals', 'uploads/WhoAmI-DomesticAnimals_818332880.swf', 'uploads/WhoAmI-DomesticAnimals_818332880.png', 'L', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'WhoAmI-DomesticAnimals'),
(36, 63, 39, 'WhoAmI-Fruits', 'uploads/WhoAmI-Fruits_91387722.swf', 'uploads/WhoAmI-Fruits_91387722.png', 'L', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'WhoAmI-Fruits'),
(37, 63, 40, 'WhoAmI_HouseHoldThings', 'uploads/WhoAmI-HouseHoldThings_8783441544.swf', 'uploads/WhoAmI-HouseHoldThings_8783441544.png', 'L', 'Y', 0, '2014-06-17 00:00:00', 0, '2017-06-12 09:54:42', 'WhoAmI_HouseHoldThings'),
(38, 63, 41, 'WhoAmI-Shapes', 'uploads/WhoAmI-Shapes_7515025790.swf', 'uploads/WhoAmI-Shapes_7515025790.png', 'L', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'WhoAmI-Shapes'),
(39, 63, 42, 'WhoAmI-Vegetables', 'uploads/WhoAmI-Vegetables_7871570191.swf', 'uploads/WhoAmI-Vegetables_7871570191.png', 'L', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'WhoAmI-Vegetables'),
(40, 59, 43, 'AlphaNumericEncode-Level2', 'uploads/AlphaNumericEncode-Level2_546242767.swf', 'uploads/AlphaNumericEncode-Level2_546242767.png', 'M', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'AlphaNumericEncode-Level2'),
(41, 59, 44, 'BalloonBurst-Level2', 'uploads/BalloonBurst-Level2_244336309.swf', 'uploads/BalloonBurst-Level2_244336309.png', 'M', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'BalloonBurst-Level2'),
(42, 59, 45, 'BusRide-Level2', 'uploads/BusRide-Level2_6232746895.swf', 'uploads/BusRide-Level2_6232746895.png', 'M', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'BusRide-Level2'),
(43, 59, 46, 'CycleRace-Level2', 'uploads/CycleRace-Level2_5460967603.swf', 'uploads/CycleRace-Level2_5460967603.png', 'M', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'CycleRace-Level2'),
(44, 59, 47, 'Fishing', 'uploads/Fishing_4694063616.swf', 'uploads/Fishing_4694063616.png', 'M', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'Fishing'),
(45, 59, 48, 'MemoryCheck-Level2', 'uploads/MemoryCheck-Level2_8882285202.swf', 'uploads/MemoryCheck-Level2_8882285202.png', 'M', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'MemoryCheck-Level2'),
(46, 59, 49, 'MindCapture-Level2', 'uploads/MindCapture-Level2_5165879982.swf', 'uploads/MindCapture-Level2_5165879982.png', 'M', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'MindCapture-Level2'),
(47, 59, 50, 'SequenceMemory-Level2', 'uploads/SequenceMemory-Level2_9874571016.swf', 'uploads/SequenceMemory-Level2_9874571016.png', 'M', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'SequenceMemory-Level2'),
(48, 60, 51, 'AlphaNumberRead', 'uploads/AlphaNumberRead_8101214673.swf', 'uploads/AlphaNumberRead_8101214673.png', 'VP', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'AlphaNumberRead'),
(49, 60, 52, 'BestFit-Level4', 'uploads/BestFit-Level3_8792649721.swf', 'uploads/BestFit-Level3_8792649721.png', 'VP', 'Y', 0, '2014-06-17 00:00:00', 0, '2017-06-12 10:19:36', 'BestFit-Level4'),
(50, 60, 53, 'CharacterShade-Level2', 'uploads/CharacterShade-Level2_8845140137.swf', 'uploads/CharacterShade-Level2_8845140137.png', 'VP', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'CharacterShade-Level2'),
(51, 60, 54, 'EdCells-Level2', 'uploads/EdCells-Level2_812620040.swf', 'uploads/EdCells-Level2_812620040.png', 'VP', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'EdCells-Level2'),
(52, 60, 55, 'EyeCells-Level2', 'uploads/EyeCells-Level2_5889739277.swf', 'uploads/EyeCells-Level2_5889739277.png', 'VP', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'EyeCells-Level2'),
(53, 60, 56, 'Face2Face-Level2', 'uploads/Face2Face-Level2_9013552083.swf', 'uploads/Face2Face-Level2_9013552083.png', 'VP', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'Face2Face-Level2'),
(54, 60, 57, 'MatchMe-Level2', 'uploads/MatchMe-Level2_5947240493.swf', 'uploads/MatchMe-Level2_5947240493.png', 'VP', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'MatchMe-Level2'),
(55, 60, 58, 'WordWipe-Level2', 'uploads/WordWipe-Level2_4875887525.swf', 'uploads/WordWipe-Level2_4875887525.png', 'VP', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'WordWipe-Level2'),
(56, 61, 59, 'LetterJigsaw-Level2', 'uploads/AlphabetJigsaw-Level2_439756815.swf', 'uploads/AlphabetJigsaw-Level2_439756815.png', 'FA', 'Y', 0, '2014-06-17 00:00:00', 0, '2017-06-12 10:22:54', 'LetterJigsaw-Level2'),
(57, 61, 60, 'AnimalSpell', 'uploads/AnimalSpell_5479293791.swf', 'uploads/AnimalSpell_5479293791.png', 'FA', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'AnimalSpell'),
(58, 61, 61, 'DownUnder-Level2', 'uploads/DownUnder-Level2_5347298909.swf', 'uploads/DownUnder-Level2_5347298909.png', 'FA', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'DownUnder-Level2'),
(59, 61, 62, 'LastLegend-Level2', 'uploads/LastLegend-Level2_5781244020.swf', 'uploads/LastLegend-Level2_5781244020.png', 'FA', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'LastLegend-Level2'),
(60, 61, 63, 'NumberJigsaw-Level2', 'uploads/NumberJigsaw-Level2_5454463027.swf', 'uploads/NumberJigsaw-Level2_5454463027.png', 'FA', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'NumberJigsaw-Level2'),
(61, 61, 64, 'ObjectSpell-Level1', 'uploads/ObjectSpell-Level1_6468444657.swf', 'uploads/ObjectSpell-Level1_6468444657.png', 'FA', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'ObjectSpell-Level1'),
(62, 61, 65, 'SpotMe-Level2', 'uploads/SpotMe-Level2_5270674000.swf', 'uploads/SpotMe-Level2_5270674000.png', 'FA', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'SpotMe-Level2'),
(63, 61, 66, 'StarLight-Level4', 'uploads/StarLight-Level2_988681958.swf', 'uploads/StarLight-Level2_988681958.png', 'FA', 'Y', 0, '2014-06-17 00:00:00', 0, '2017-06-12 10:25:58', 'StarLight-Level4'),
(64, 62, 67, 'AddMaster-Level2', 'uploads/AddMaster-Level2_6791430432.swf', 'uploads/AddMaster-Level2_6791430432.png', 'PS', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'AddMaster-Level2'),
(65, 62, 68, 'ClockArithmetic', 'uploads/ClockArithmetic_6831587473.swf', 'uploads/ClockArithmetic_6831587473.png', 'PS', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'ClockArithmetic'),
(66, 62, 69, 'HeavyOrLight-Level2', 'uploads/HeavyOrLight-Level2_607259180.swf', 'uploads/HeavyOrLight-Level2_607259180.png', 'PS', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'HeavyOrLight-Level2'),
(67, 62, 70, 'NumberDecode-Level2', 'uploads/NumberDecode-Level2_2425581049.swf', 'uploads/NumberDecode-Level2_2425581049.png', 'PS', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'NumberDecode-Level2'),
(68, 62, 71, 'NumbersOnTheWheel-Level2', 'uploads/NumbersOnTheWheel-Level2_5032758838.swf', 'uploads/NumbersOnTheWheel-Level2_5032758838.png', 'PS', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'NumbersOnTheWheel-Level2'),
(69, 62, 72, 'ParaMaster-Level2', 'uploads/ParaMaster-Level2_9887385293.swf', 'uploads/ParaMaster-Level2_9887385293.png', 'PS', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'ParaMaster-Level2'),
(70, 62, 73, 'Reshuffle-Level2', 'uploads/Reshuffle-Level2_5333331595.swf', 'uploads/Reshuffle-Level2_5333331595.png', 'PS', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'Reshuffle-Level2'),
(71, 62, 74, 'WordShapes-Level2', 'uploads/WordShapes-Level2_2368690557.swf', 'uploads/WordShapes-Level2_2368690557.png', 'PS', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'WordShapes-Level2'),
(72, 63, 75, 'ArrangeTheWords-Level1', 'uploads/ArrangeTheWords-Level1_350359375.swf', 'uploads/ArrangeTheWords-Level1_350359375.png', 'L', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'ArrangeTheWords-Level1'),
(73, 63, 76, 'VowelMagic', 'uploads/VowelMagic_9324571550.swf', 'uploads/VowelMagic_9324571550.png', 'L', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'VowelMagic'),
(74, 63, 77, 'WhoAmI_Clothes', 'uploads/WhoAmI-Clothes_236435011.swf', 'uploads/WhoAmI-Clothes_236435011.png', 'L', 'Y', 0, '2014-06-17 00:00:00', 0, '2017-06-15 20:56:43', 'WhoAmI_Clothes'),
(75, 63, 78, 'WhoAmI_Insects', 'uploads/WhoAmI-Insects_9486121060.swf', 'uploads/WhoAmI-Insects_9486121060.png', 'L', 'Y', 0, '2014-06-17 00:00:00', 0, '2017-06-12 10:28:17', 'WhoAmI_Insects'),
(76, 63, 79, 'WhoAmI_School', 'uploads/WhoAmI-School_1506193187.swf', 'uploads/WhoAmI-School_1506193187.png', 'L', 'Y', 0, '2014-06-17 00:00:00', 0, '2017-06-12 10:28:59', 'WhoAmI_School'),
(77, 63, 80, 'WhoAmI_SeaAnimals', 'uploads/WhoAmI-SeaAnimals_9400465255.swf', 'uploads/WhoAmI-SeaAnimals_9400465255.png', 'L', 'Y', 0, '2014-06-17 00:00:00', 0, '2017-06-12 10:27:15', 'WhoAmI_SeaAnimals'),
(78, 63, 81, 'WhoAmI_Transport', 'uploads/WhoAmI-Transport_156703181.swf', 'uploads/WhoAmI-Transport_156703181.png', 'L', 'Y', 0, '2014-06-17 00:00:00', 0, '2017-06-14 20:51:05', 'WhoAmI_Transport'),
(79, 63, 82, 'WhoAmI-WildAnimals', 'uploads/WhoAmI-WildAnimals_8843113635.swf', 'uploads/WhoAmI-WildAnimals_8843113635.png', 'L', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'WhoAmI-WildAnimals'),
(80, 59, 83, 'AlphaNumericEncode-Level3', 'uploads/AlphaNumericEncode-Level3_387589167.swf', 'uploads/AlphaNumericEncode-Level3_387589167.png', 'M', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'AlphaNumericEncode-Level3'),
(81, 59, 84, 'BalloonBurst-Level3', 'uploads/BalloonBurst-Level3_2492009233.swf', 'uploads/BalloonBurst-Level3_2492009233.png', 'M', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'BalloonBurst-Level3'),
(82, 59, 85, 'CycleRace-Level3', 'uploads/CycleRace-Level3_6173525671.swf', 'uploads/CycleRace-Level3_6173525671.png', 'M', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'CycleRace-Level3'),
(83, 59, 86, 'DialAnumber', 'uploads/DialANumber_8347820923.swf', 'uploads/DialANumber_8347820923.png', 'M', 'Y', 0, '2014-06-17 00:00:00', 0, '2017-06-12 10:37:35', 'DialAnumber'),
(84, 59, 87, 'MemoryCheck-Level3', 'uploads/MemoryCheck-Level3_7822075057.swf', 'uploads/MemoryCheck-Level3_7822075057.png', 'M', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'MemoryCheck-Level3'),
(85, 59, 88, 'MindCapture-Level3', 'uploads/MindCapture-Level3_3766070040.swf', 'uploads/MindCapture-Level3_3766070040.png', 'M', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'MindCapture-Level3'),
(86, 59, 89, 'SequenceMemory-Level3', 'uploads/SequenceMemory-Level3_9452287289.swf', 'uploads/SequenceMemory-Level3_9452287289.png', 'M', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'SequenceMemory-Level3'),
(87, 59, 90, 'WhatsInStore-Level1', 'uploads/WhatsInStore-Level1_99412277.swf', 'uploads/WhatsInStore-Level1_99412277.png', 'M', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'WhatsInStore-Level1'),
(88, 60, 91, 'CharacterShade-Level3', 'uploads/CharacterShade-Level3_3322312142.swf', 'uploads/CharacterShade-Level3_3322312142.png', 'VP', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'CharacterShade-Level3'),
(89, 60, 92, 'EdCells-Level3', 'uploads/EdCells-Level3_4655870916.swf', 'uploads/EdCells-Level3_4655870916.png', 'VP', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'EdCells-Level3'),
(90, 60, 93, 'EyeCells-Level3', 'uploads/EyeCells-Level3_8897464917.swf', 'uploads/EyeCells-Level3_8897464917.png', 'VP', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'EyeCells-Level3'),
(91, 60, 94, 'Hand2Hand', 'uploads/Hand2Hand_5783699043.swf', 'uploads/Hand2Hand_5783699043.png', 'VP', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'Hand2Hand'),
(92, 60, 95, 'JustNotHalf-Level1', 'uploads/JustNotHalf-Level1_6506787771.swf', 'uploads/JustNotHalf-Level1_6506787771.png', 'VP', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'JustNotHalf-Level1'),
(93, 60, 96, 'MatchMe-Level3', 'uploads/MatchMe-Level3_3926392993.swf', 'uploads/MatchMe-Level3_3926392993.png', 'VP', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'MatchMe-Level3'),
(94, 60, 97, 'MirrorMatch-Level1', 'uploads/MirrorMatch-Level1_3191918600.swf', 'uploads/MirrorMatch-Level1_3191918600.png', 'VP', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'MirrorMatch-Level1'),
(95, 60, 98, 'MissingPiece-Level1', 'uploads/MissingPiece-Level1_5453919009.swf', 'uploads/MissingPiece-Level1_5453919009.png', 'VP', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'MissingPiece-Level1'),
(96, 61, 99, 'LetterJigsaw-Level3', 'uploads/AlphabetJigsaw-Level3_1882078954.swf', 'uploads/AlphabetJigsaw-Level3_1882078954.png', 'FA', 'Y', 0, '2014-06-17 00:00:00', 0, '2017-06-12 10:39:08', 'LetterJigsaw-Level3'),
(97, 61, 100, 'BalloonWorks-Level1', 'uploads/BalloonWorks-Level1_1963271764.swf', 'uploads/BalloonWorks-Level1_1963271764.png', 'FA', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'BalloonWorks-Level1'),
(98, 61, 101, 'CarPark-Level1', 'uploads/CarPark-Level1_8054239703.swf', 'uploads/CarPark-Level1_8054239703.png', 'FA', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'CarPark-Level1'),
(99, 61, 102, 'DarkLight-Level1', 'uploads/DarkLight-Level1_1779258348.swf', 'uploads/DarkLight-Level1_1779258348.png', 'FA', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'DarkLight-Level1'),
(100, 61, 103, 'DeepUnder-Level1', 'uploads/DeepUnder-Level1_7213067221.swf', 'uploads/DeepUnder-Level1_7213067221.png', 'FA', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'DeepUnder-Level1'),
(101, 61, 104, 'LastLegend-Level3', 'uploads/LastLegend-Level3_5495434515.swf', 'uploads/LastLegend-Level3_5495434515.png', 'FA', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'LastLegend-Level3'),
(102, 61, 105, 'NumberJigsaw-Level3', 'uploads/NumberJigsaw-Level3_7143653305.swf', 'uploads/NumberJigsaw-Level3_7143653305.png', 'FA', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'NumberJigsaw-Level3'),
(103, 61, 106, 'ObjectSpell-Level2', 'uploads/ObjectSpell-Level2_9643486370.swf', 'uploads/ObjectSpell-Level2_9643486370.png', 'FA', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'ObjectSpell-Level2'),
(104, 62, 107, 'AddMaster-Level3', 'uploads/AddMaster-Level3_2056090440.swf', 'uploads/AddMaster-Level3_2056090440.png', 'PS', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'AddMaster-Level3'),
(105, 62, 108, 'ATeddyForATeddy-Level1', 'uploads/ATeddyForATeddy-Level1_5987485046.swf', 'uploads/ATeddyForATeddy-Level1_5987485046.png', 'PS', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'ATeddyForATeddy-Level1'),
(106, 62, 109, 'NumberSeries-Level1', 'uploads/NumberSeries-Level1_292791444.swf', 'uploads/NumberSeries-Level1_292791444.png', 'PS', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'NumberSeries-Level1'),
(107, 62, 110, 'NumbersOnTheWheel-Level3', 'uploads/NumbersOnTheWheel-Level3_7181768785.swf', 'uploads/NumbersOnTheWheel-Level3_7181768785.png', 'PS', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'NumbersOnTheWheel-Level3'),
(108, 62, 111, 'ParaMaster-Level3', 'uploads/ParaMaster-Level3_8316638404.swf', 'uploads/ParaMaster-Level3_8316638404.png', 'PS', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'ParaMaster-Level3'),
(109, 62, 112, 'Reshuffle-Level3', 'uploads/Reshuffle-Level3_2661516019.swf', 'uploads/Reshuffle-Level3_2661516019.png', 'PS', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'Reshuffle-Level3'),
(110, 62, 113, 'WordShapes-Level3', 'uploads/WordShapes-Level3_9543727268.swf', 'uploads/WordShapes-Level3_9543727268.png', 'PS', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'WordShapes-Level3'),
(111, 62, 114, 'WordWalls-Level1', 'uploads/WordWalls-Level1_1536627309.swf', 'uploads/WordWalls-Level1_1536627309.png', 'PS', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'WordWalls-Level1'),
(112, 63, 115, 'Anagrams-Animals', 'uploads/Anagrams-Animals_690025119.swf', 'uploads/Anagrams-Animals_690025119.png', 'L', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'Anagrams-Animals'),
(113, 63, 116, 'Anagrams-Body', 'uploads/Anagrams-Body_8010135167.swf', 'uploads/Anagrams-Body_8010135167.png', 'L', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'Anagrams-Body'),
(114, 63, 117, 'Anagrams-Clothes', 'uploads/Anagrams-Clothing_8464276143.swf', 'uploads/Anagrams-Clothing_8464276143.png', 'L', 'Y', 0, '2014-06-17 00:00:00', 0, '2017-06-12 10:42:52', 'Anagrams-Clothes'),
(115, 63, 118, 'Anagrams-Colors', 'uploads/Anagrams-Colors_4401654419.swf', 'uploads/Anagrams-Colors_4401654419.png', 'L', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'Anagrams-Colors'),
(116, 63, 119, 'ArrangeTheWords-Level2', 'uploads/ArrangeTheWords-Level2_2614120254.swf', 'uploads/ArrangeTheWords-Level2_2614120254.png', 'L', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'ArrangeTheWords-Level2'),
(117, 63, 120, 'MissingLetter-Level1', 'uploads/MissingLetter-Level1_4396478235.swf', 'uploads/MissingLetter-Level1_4396478235.png', 'L', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'MissingLetter-Level1'),
(118, 63, 121, 'NameLand-Level1', 'uploads/NameLand-Level1_3850891082.swf', 'uploads/NameLand-Level1_3850891082.png', 'L', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'NameLand-Level1'),
(119, 63, 122, 'WhoAmI-Birthday', 'uploads/WhoAmI-Birthday_9790617101.swf', 'uploads/WhoAmI-Birthday_9790617101.png', 'L', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'WhoAmI-Birthday'),
(120, 59, 123, 'AlphaNumericEncode-Level4', 'uploads/AlphaNumericEncode-Level4_2667365404.swf', 'uploads/AlphaNumericEncode-Level4_2667365404.png', 'M', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'AlphaNumericEncode-Level4'),
(121, 59, 124, 'BackTrack-Level1', 'uploads/BackTrack-Level1_257858377.swf', 'uploads/BackTrack-Level1_257858377.png', 'M', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'BackTrack-Level1'),
(122, 59, 125, 'BalloonBurst-Level4', 'uploads/BalloonBurst-Level4_2785141328.swf', 'uploads/BalloonBurst-Level4_2785141328.png', 'M', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'BalloonBurst-Level4'),
(123, 59, 126, 'CycleRace-Level4', 'uploads/CycleRace-Level4_4780295565.swf', 'uploads/CycleRace-Level4_4780295565.png', 'M', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'CycleRace-Level4'),
(124, 59, 127, 'MemoryCheck-Level4', 'uploads/MemoryCheck-Level4_3053050003.swf', 'uploads/MemoryCheck-Level4_3053050003.png', 'M', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'MemoryCheck-Level4'),
(125, 59, 128, 'MindCapture-Level4', 'uploads/MindCapture-Level4_95845567.swf', 'uploads/MindCapture-Level4_95845567.png', 'M', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'MindCapture-Level4'),
(126, 59, 129, 'SequenceMemory-Level4', 'uploads/SequenceMemory-Level4_9387351195.swf', 'uploads/SequenceMemory-Level4_9387351195.png', 'M', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'SequenceMemory-Level4'),
(127, 59, 130, 'WhatsInStore-Level2', 'uploads/WhatsInStore-Level2_3776093176.swf', 'uploads/WhatsInStore-Level2_3776093176.png', 'M', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'WhatsInStore-Level2'),
(128, 60, 131, 'AnimalWipe', 'uploads/AnimalWipe_6567529789.swf', 'uploads/AnimalWipe_6567529789.png', 'VP', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'AnimalWipe'),
(129, 60, 132, 'CharacterShade-Level4', 'uploads/CharacterShade-Level4_7572658732.swf', 'uploads/CharacterShade-Level4_7572658732.png', 'VP', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'CharacterShade-Level4'),
(130, 60, 133, 'FindTheTwins-Level1', 'uploads/FindTheTwins-Level1_7979904958.swf', 'uploads/FindTheTwins-Level1_7979904958.png', 'VP', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'FindTheTwins-Level1'),
(131, 60, 134, 'JustNotHalf-Level2', 'uploads/JustNotHalf-Level2_2203953666.swf', 'uploads/JustNotHalf-Level2_2203953666.png', 'VP', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'JustNotHalf-Level2'),
(132, 60, 135, 'MirrorMatch-Level2', 'uploads/MirrorMatch-Level2_4265700853.swf', 'uploads/MirrorMatch-Level2_4265700853.png', 'VP', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'MirrorMatch-Level2'),
(133, 60, 136, 'MissingPiece-Level2', 'uploads/MissingPiece-Level2_9361892873.swf', 'uploads/MissingPiece-Level2_9361892873.png', 'VP', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'MissingPiece-Level2'),
(134, 60, 137, 'ReflectionRead-Level1', 'uploads/ReflectionRead-Level1_7608671374.swf', 'uploads/ReflectionRead-Level1_7608671374.png', 'VP', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'ReflectionRead-Level1'),
(135, 60, 138, 'ReverseReading-Level1', 'uploads/ReverseReading-Level1_3469542353.swf', 'uploads/ReverseReading-Level1_3469542353.png', 'VP', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'ReverseReading-Level1'),
(136, 61, 139, 'LetterJigsaw-Level4', 'uploads/AlphabetJigsaw-Level4_5252252509.swf', 'uploads/AlphabetJigsaw-Level4_5252252509.png', 'FA', 'Y', 0, '2014-06-17 00:00:00', 0, '2017-06-12 10:47:39', 'LetterJigsaw-Level4'),
(137, 61, 140, 'BalloonWorks-Level2', 'uploads/BalloonWorks-Level2_3179936059.swf', 'uploads/BalloonWorks-Level2_3179936059.png', 'FA', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'BalloonWorks-Level2'),
(138, 61, 141, 'CarPark-Level2', 'uploads/CarPark-Level2_116904969.swf', 'uploads/CarPark-Level2_116904969.png', 'FA', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'CarPark-Level2'),
(139, 61, 142, 'DarkLight-Level2', 'uploads/DarkLight-Level2_7840619147.swf', 'uploads/DarkLight-Level2_7840619147.png', 'FA', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'DarkLight-Level2'),
(140, 61, 143, 'DeepUnder-Level2', 'uploads/DeepUnder-Level2_5933240540.swf', 'uploads/DeepUnder-Level2_5933240540.png', 'FA', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'DeepUnder-Level2'),
(141, 61, 144, 'LastLegend-Level4', 'uploads/LastLegend-Level4_3372493218.swf', 'uploads/LastLegend-Level4_3372493218.png', 'FA', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'LastLegend-Level4'),
(142, 61, 145, 'NumberJigsaw-Level4', 'uploads/NumberJigsaw-Level4_3807144016.swf', 'uploads/NumberJigsaw-Level4_3807144016.png', 'FA', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'NumberJigsaw-Level4'),
(143, 61, 146, 'SpotMe-Level3', 'uploads/SpotMe-Level3_4077972709.swf', 'uploads/SpotMe-Level3_4077972709.png', 'FA', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'SpotMe-Level3'),
(144, 62, 147, 'ATeddyForATeddy-Level2', 'uploads/ATeddyForATeddy-Level2_5931731625.swf', 'uploads/ATeddyForATeddy-Level2_5931731625.png', 'PS', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'ATeddyForATeddy-Level2'),
(145, 62, 148, 'FitMeRight-Level1', 'uploads/FitMeRight-Level1_9128276687.swf', 'uploads/FitMeRight-Level1_9128276687.png', 'PS', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'FitMeRight-Level1'),
(146, 62, 149, 'NumberSeries-Level2', 'uploads/NumberSeries-Level2_1761797624.swf', 'uploads/NumberSeries-Level2_1761797624.png', 'PS', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'NumberSeries-Level2'),
(147, 62, 150, 'NumbersOnTheWheel-Level4', 'uploads/NumbersOnTheWheel-Level4_1754132225.swf', 'uploads/NumbersOnTheWheel-Level4_1754132225.png', 'PS', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'NumbersOnTheWheel-Level4'),
(148, 62, 151, 'ParaMaster-Level4', 'uploads/ParaMaster-Level4_3163872654.swf', 'uploads/ParaMaster-Level4_3163872654.png', 'PS', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'ParaMaster-Level4'),
(149, 62, 152, 'Reshuffle-Level4', 'uploads/Reshuffle-Level4_4280022010.swf', 'uploads/Reshuffle-Level4_4280022010.png', 'PS', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'Reshuffle-Level4'),
(150, 62, 153, 'WordShapes-Level4', 'uploads/WordShapes-Level4_9880864322.swf', 'uploads/WordShapes-Level4_9880864322.png', 'PS', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'WordShapes-Level4'),
(151, 62, 154, 'WordWalls-Level2', 'uploads/WordWalls-Level2_7409162675.swf', 'uploads/WordWalls-Level2_7409162675.png', 'PS', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'WordWalls-Level2'),
(152, 63, 155, 'Anagrams-Food', 'uploads/Anagrams-Food_9358940329.swf', 'uploads/Anagrams-Food_9358940329.png', 'L', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'Anagrams-Food'),
(153, 63, 156, 'Anagrams-Math', 'uploads/Anagrams-Math_3996595479.swf', 'uploads/Anagrams-Math_3996595479.png', 'L', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'Anagrams-Math'),
(154, 63, 157, 'Anagrams-Plants', 'uploads/Anagrams-Plants_2974008941.swf', 'uploads/Anagrams-Plants_2974008941.png', 'L', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'Anagrams-Plants'),
(155, 63, 158, 'Anagrams-Vehicles', 'uploads/Anagrams-Vehicles_8503454732.swf', 'uploads/Anagrams-Vehicles_8503454732.png', 'L', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'Anagrams-Vehicles'),
(156, 63, 159, 'ArrangeTheWords-Level3', 'uploads/ArrangeTheWords-Level3_6521334904.swf', 'uploads/ArrangeTheWords-Level3_6521334904.png', 'L', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'ArrangeTheWords-Level3'),
(157, 63, 160, 'MissingLetter-Level2', 'uploads/MissingLetter-Level2_3469503405.swf', 'uploads/MissingLetter-Level2_3469503405.png', 'L', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'MissingLetter-Level2'),
(158, 63, 161, 'NameLand-Level2', 'uploads/NameLand-Level2_9281079615.swf', 'uploads/NameLand-Level2_9281079615.png', 'L', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'NameLand-Level2'),
(159, 63, 162, 'WhoAmI-Flowers', 'uploads/WhoAmI-Flowers_4361387616.swf', 'uploads/WhoAmI-Flowers_4361387616.png', 'L', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'WhoAmI-Flowers'),
(160, 59, 163, 'AlphaNumericEncode-Level5', 'uploads/AlphaNumericEncode-Level5_5666280859.swf', 'uploads/AlphaNumericEncode-Level5_5666280859.png', 'M', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'AlphaNumericEncode-Level5'),
(161, 59, 164, 'AnimalWatch-Level1', 'uploads/AnimalWatch-Level1_8736748136.swf', 'uploads/AnimalWatch-Level1_8736748136.png', 'M', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'AnimalWatch-Level1'),
(162, 59, 165, 'BackTrack-Level2', 'uploads/BackTrack-Level2_16276659.swf', 'uploads/BackTrack-Level2_16276659.png', 'M', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'BackTrack-Level2'),
(163, 59, 166, 'CycleRace-Level5', 'uploads/CycleRace-Level5_1506978459.swf', 'uploads/CycleRace-Level5_1506978459.png', 'M', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'CycleRace-Level5'),
(164, 59, 167, 'MemoryCheck-Level5', 'uploads/MemoryCheck-Level5_9116933126.swf', 'uploads/MemoryCheck-Level5_9116933126.png', 'M', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'MemoryCheck-Level5'),
(165, 59, 168, 'MindCapture-Level5', 'uploads/MindCapture-Level5_2807246898.swf', 'uploads/MindCapture-Level5_2807246898.png', 'M', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'MindCapture-Level5'),
(166, 59, 169, 'SequenceMemory-Level5', 'uploads/SequenceMemory-Level5_7487447718.swf', 'uploads/SequenceMemory-Level5_7487447718.png', 'M', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'SequenceMemory-Level5'),
(167, 59, 170, 'WhatsInStore-Level3', 'uploads/WhatsInStore-Level3_4075730568.swf', 'uploads/WhatsInStore-Level3_4075730568.png', 'M', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'WhatsInStore-Level3'),
(168, 60, 171, 'CubeSherlock-Level1', 'uploads/CubeSherlock-Level1_9494013660.swf', 'uploads/CubeSherlock-Level1_9494013660.png', 'VP', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'CubeSherlock-Level1'),
(169, 60, 172, 'FindTheTwins-Level2', 'uploads/FindTheTwins-Level2_3434965950.swf', 'uploads/FindTheTwins-Level2_3434965950.png', 'VP', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'FindTheTwins-Level2'),
(170, 60, 173, 'IAmCube-Level1', 'uploads/IAmCube-Level1_3901067436.swf', 'uploads/IAmCube-Level1_3901067436.png', 'VP', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'IAmCube-Level1'),
(171, 60, 174, 'JustNotHalf-Level3', 'uploads/JustNotHalf-Level3_486829234.swf', 'uploads/JustNotHalf-Level3_486829234.png', 'VP', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'JustNotHalf-Level3'),
(172, 60, 175, 'MirrorMatch-Level3', 'uploads/MirrorMatch-Level3_3233505128.swf', 'uploads/MirrorMatch-Level3_3233505128.png', 'VP', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'MirrorMatch-Level3'),
(173, 60, 176, 'MissingPiece-Level3', 'uploads/MissingPiece-Level3_1563094099.swf', 'uploads/MissingPiece-Level3_1563094099.png', 'VP', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'MissingPiece-Level3'),
(174, 60, 177, 'ReflectionRead-Level2', 'uploads/ReflectionRead-Level2_2878144294.swf', 'uploads/ReflectionRead-Level2_2878144294.png', 'VP', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'ReflectionRead-Level2'),
(175, 60, 178, 'ReverseReading-Level2', 'uploads/ReverseReading-Level2_7025720854.swf', 'uploads/ReverseReading-Level2_7025720854.png', 'VP', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'ReverseReading-Level2'),
(176, 61, 179, 'BalloonWorks-Level3', 'uploads/BalloonWorks-Level3_3529471680.swf', 'uploads/BalloonWorks-Level3_3529471680.png', 'FA', 'Y', 0, '2014-06-17 00:00:00', 0, '2017-06-12 11:34:20', 'BalloonWorks-Level3'),
(177, 61, 180, 'CarPark-Level3', 'uploads/CarPark-Level3_5003174929.swf', 'uploads/CarPark-Level3_5003174929.png', 'FA', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'CarPark-Level3'),
(178, 61, 181, 'DarkLight-Level3', 'uploads/DarkLight-Level3_6337577155.swf', 'uploads/DarkLight-Level3_6337577155.png', 'FA', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'DarkLight-Level3'),
(179, 61, 182, 'DeepUnder-Level3', 'uploads/DeepUnder-Level3_9918525810.swf', 'uploads/DeepUnder-Level3_9918525810.png', 'FA', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'DeepUnder-Level3'),
(180, 61, 183, 'LastLegend-Level5', 'uploads/LastLegend-Level5_7495082467.swf', 'uploads/LastLegend-Level5_7495082467.png', 'FA', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'LastLegend-Level5'),
(181, 61, 184, 'Rainbow-Level1', 'uploads/Rainbow-Level1_1321175633.swf', 'uploads/Rainbow-Level1_1321175633.png', 'FA', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'Rainbow-Level1'),
(182, 61, 185, 'ShapeRollers-Level1', 'uploads/ShapeRollers-Level1_1497070817.swf', 'uploads/ShapeRollers-Level1_1497070817.png', 'FA', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'ShapeRollers-Level1'),
(183, 61, 186, 'SpotMe-Level4', 'uploads/SpotMe-Level4_1111856144.swf', 'uploads/SpotMe-Level4_1111856144.png', 'FA', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'SpotMe-Level4'),
(184, 62, 187, 'ATeddyForATeddy-Level3', 'uploads/ATeddyForATeddy-Level3_1824636519.swf', 'uploads/ATeddyForATeddy-Level3_1824636519.png', 'PS', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'ATeddyForATeddy-Level3'),
(185, 62, 188, 'ColorGuess', 'uploads/ColorGuess_7757099242.swf', 'uploads/ColorGuess_7757099242.png', 'PS', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'ColorGuess'),
(186, 62, 189, 'FitMeRight-Level2', 'uploads/FitMeRight-Level2_340231573.swf', 'uploads/FitMeRight-Level2_340231573.png', 'PS', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'FitMeRight-Level2'),
(187, 62, 190, 'HueCram', 'uploads/HueCram_438871416.swf', 'uploads/HueCram_438871416.png', 'PS', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'HueCram'),
(188, 62, 191, 'NumbersOnTheWheel-Level5', 'uploads/NumbersOnTheWheel-Level5_1027476550.swf', 'uploads/NumbersOnTheWheel-Level5_1027476550.png', 'PS', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'NumbersOnTheWheel-Level5'),
(189, 62, 192, 'ParaMaster-Level5', 'uploads/ParaMaster-Level5_5265605337.swf', 'uploads/ParaMaster-Level5_5265605337.png', 'PS', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'ParaMaster-Level5'),
(190, 62, 193, 'Reshuffle-Level5', 'uploads/Reshuffle-Level5_1823949897.swf', 'uploads/Reshuffle-Level5_1823949897.png', 'PS', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'Reshuffle-Level5'),
(191, 62, 194, 'TakeTurns-Level1', 'uploads/TakeTurns-Level1_1136886626.swf', 'uploads/TakeTurns-Level1_1136886626.png', 'PS', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'TakeTurns-Level1'),
(192, 63, 195, 'Anagrams-CountryNames', 'uploads/Anagrams-CountryNames_9848174657.swf', 'uploads/Anagrams-CountryNames_9848174657.png', 'L', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'Anagrams-CountryNames'),
(193, 63, 196, 'Anagrams-HouseHold', 'uploads/Anagrams-Household_4300776333.swf', 'uploads/Anagrams-Household_4300776333.png', 'L', 'Y', 0, '2014-06-17 00:00:00', 0, '2017-06-12 11:00:31', 'Anagrams-HouseHold'),
(194, 63, 197, 'Anagrams-Schools', 'uploads/Anagrams-School_220320839.swf', 'uploads/Anagrams-School_220320839.png', 'L', 'Y', 0, '2014-06-17 00:00:00', 0, '2017-06-12 11:00:55', 'Anagrams-Schools'),
(195, 63, 198, 'Anagrams-Sports', 'uploads/Anagrams-Sports_9202636964.swf', 'uploads/Anagrams-Sports_9202636964.png', 'L', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'Anagrams-Sports'),
(196, 63, 199, 'Anagrams-Weather', 'uploads/Anagrams-Weather_3403326552.swf', 'uploads/Anagrams-Weather_3403326552.png', 'L', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'Anagrams-Weather'),
(197, 63, 200, 'ArrangeTheWords-Level4', 'uploads/ArrangeTheWords-Level4_1263861129.swf', 'uploads/ArrangeTheWords-Level4_1263861129.png', 'L', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'ArrangeTheWords-Level4'),
(198, 63, 201, 'MissingLetter-Level3', 'uploads/MissingLetter-Level3_7274801447.swf', 'uploads/MissingLetter-Level3_7274801447.png', 'L', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'MissingLetter-Level3'),
(199, 63, 202, 'WordStem', 'uploads/WordStem_1920470679.swf', 'uploads/WordStem_1920470679.png', 'L', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'WordStem'),
(200, 59, 203, 'AlphaNumericEncode-Level6', 'uploads/AlphaNumericEncode-Level6_7225111038.swf', 'uploads/AlphaNumericEncode-Level6_7225111038.png', 'M', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'AlphaNumericEncode-Level6'),
(201, 59, 204, 'AnimalWatch-Level2', 'uploads/AnimalWatch-Level2_2552103889.swf', 'uploads/AnimalWatch-Level2_2552103889.png', 'M', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'AnimalWatch-Level2'),
(202, 59, 205, 'BackTrack-Level3', 'uploads/BackTrack-Level3_4500490999.swf', 'uploads/BackTrack-Level3_4500490999.png', 'M', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'BackTrack-Level3'),
(203, 59, 206, 'CycleRace-Level6', 'uploads/CycleRace-Level6_5745665873.swf', 'uploads/CycleRace-Level6_5745665873.png', 'M', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'CycleRace-Level6'),
(204, 59, 207, 'GraphDecoder', 'uploads/GraphDecoder_6767004569.swf', 'uploads/GraphDecoder_6767004569.png', 'M', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'GraphDecoder'),
(205, 59, 208, 'MemoryCheck-Level6', 'uploads/MemoryCheck-Level6_2935850583.swf', 'uploads/MemoryCheck-Level6_2935850583.png', 'M', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'MemoryCheck-Level6'),
(206, 59, 209, 'MindCapture-Level6', 'uploads/MindCapture-Level6_6117593380.swf', 'uploads/MindCapture-Level6_6117593380.png', 'M', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'MindCapture-Level6'),
(207, 59, 210, 'SequenceMemory-Level6', 'uploads/SequenceMemory-Level6_9447641619.swf', 'uploads/SequenceMemory-Level6_9447641619.png', 'M', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'SequenceMemory-Level6'),
(208, 60, 211, 'CubeSherlock-Level2', 'uploads/CubeSherlock-Level2_2803261997.swf', 'uploads/CubeSherlock-Level2_2803261997.png', 'VP', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'CubeSherlock-Level2'),
(209, 60, 212, 'FindTheTwins-Level3', 'uploads/FindTheTwins-Level3_8413515225.swf', 'uploads/FindTheTwins-Level3_8413515225.png', 'VP', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'FindTheTwins-Level3'),
(210, 60, 213, 'IAmCube-Level2', 'uploads/IAmCube-Level2_7666559526.swf', 'uploads/IAmCube-Level2_7666559526.png', 'VP', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'IAmCube-Level2'),
(211, 60, 214, 'JustNotHalf-Level4', 'uploads/JustNotHalf-Level4_2555441330.swf', 'uploads/JustNotHalf-Level4_2555441330.png', 'VP', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'JustNotHalf-Level4'),
(212, 60, 215, 'MirrorMatch-Level4', 'uploads/MirrorMatch-Level4_9751465697.swf', 'uploads/MirrorMatch-Level4_9751465697.png', 'VP', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'MirrorMatch-Level4'),
(213, 60, 216, 'MissingPiece-Level4', 'uploads/MissingPiece-Level4_1507440302.swf', 'uploads/MissingPiece-Level4_1507440302.png', 'VP', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'MissingPiece-Level4'),
(214, 60, 217, 'ReflectionRead-Level3', 'uploads/ReflectionRead-Level3_7118542841.swf', 'uploads/ReflectionRead-Level3_7118542841.png', 'VP', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'ReflectionRead-Level3'),
(215, 60, 218, 'ReverseReading-Level3', 'uploads/ReverseReading-Level3_5393561688.swf', 'uploads/ReverseReading-Level3_5393561688.png', 'VP', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'ReverseReading-Level3'),
(216, 61, 219, 'CarPark-Level4', 'uploads/CarPark-Level4_5836739456.swf', 'uploads/CarPark-Level4_5836739456.png', 'FA', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'CarPark-Level4'),
(217, 61, 220, 'DarkLight-Level4', 'uploads/DarkLight-Level4_4173842570.swf', 'uploads/DarkLight-Level4_4173842570.png', 'FA', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'DarkLight-Level4'),
(218, 61, 221, 'DeepUnder-Level4', 'uploads/DeepUnder-Level4_8108292836.swf', 'uploads/DeepUnder-Level4_8108292836.png', 'FA', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'DeepUnder-Level4'),
(219, 61, 222, 'DiscretePadle-Level1', 'uploads/DiscretePadle-Level1_2005080394.swf', 'uploads/DiscretePadle-Level1_2005080394.png', 'FA', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'DiscretePadle-Level1'),
(220, 61, 223, 'Rainbow-Level2', 'uploads/Rainbow-Level2_2451191339.swf', 'uploads/Rainbow-Level2_2451191339.png', 'FA', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'Rainbow-Level2'),
(221, 61, 224, 'ShapeRollers-Level2', 'uploads/ShapeRollers-Level2_5863707675.swf', 'uploads/ShapeRollers-Level2_5863707675.png', 'FA', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'ShapeRollers-Level2'),
(222, 61, 225, 'ShapeVsColor', 'uploads/ShapeVsColor_5882827830.swf', 'uploads/ShapeVsColor_5882827830.png', 'FA', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'ShapeVsColor'),
(223, 61, 226, 'SpotMe-Level5', 'uploads/SpotMe-Level5_2089167693.swf', 'uploads/SpotMe-Level5_2089167693.png', 'FA', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'SpotMe-Level5'),
(224, 62, 227, 'AnalogyAction-Level1', 'uploads/AnalogyAction-Level1_6299363239.swf', 'uploads/AnalogyAction-Level1_6299363239.png', 'PS', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'AnalogyAction-Level1'),
(225, 62, 228, 'NumberPuzzle-Level1', 'uploads/NumberPuzzle-Level1_222259401.swf', 'uploads/NumberPuzzle-Level1_222259401.png', 'PS', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'NumberPuzzle-Level1'),
(226, 62, 229, 'NumbersOnTheWheel-Level6', 'uploads/NumbersOnTheWheel-Level6_2458961391.swf', 'uploads/NumbersOnTheWheel-Level6_2458961391.png', 'PS', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'NumbersOnTheWheel-Level6'),
(227, 62, 230, 'ParaMaster-Level6', 'uploads/ParaMaster-Level6_4617435368.swf', 'uploads/ParaMaster-Level6_4617435368.png', 'PS', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'ParaMaster-Level6'),
(228, 62, 231, 'Reshuffle-Level6', 'uploads/Reshuffle-Level6_4803005247.swf', 'uploads/Reshuffle-Level6_4803005247.png', 'PS', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'Reshuffle-Level6'),
(229, 62, 232, 'SequenceGrid', 'uploads/SequenceGrid_9023916260.swf', 'uploads/SequenceGrid_9023916260.png', 'PS', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'SequenceGrid'),
(230, 62, 233, 'SmartRider', 'uploads/SmartRider_1083469698.swf', 'uploads/SmartRider_1083469698.png', 'PS', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'SmartRider'),
(231, 62, 234, 'TakeTurns-Level2', 'uploads/TakeTurns-Level2_7725315545.swf', 'uploads/TakeTurns-Level2_7725315545.png', 'PS', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'TakeTurns-Level2'),
(232, 63, 235, 'Anagrams-DolchWords', 'uploads/Anagrams-DolchWords_4271674626.swf', 'uploads/Anagrams-DolchWords_4271674626.png', 'L', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'Anagrams-DolchWords'),
(233, 63, 236, 'Anagrams-FourLetterWord', 'uploads/Anagrams-FourLetterWords_96878870.swf', 'uploads/Anagrams-FourLetterWords_96878870.png', 'L', 'Y', 0, '2014-06-17 00:00:00', 0, '2017-06-16 15:58:08', 'Anagrams-FourLetterWord'),
(234, 63, 237, 'Anagrams-Geography', 'uploads/Anagrams-Geography_5710392687.swf', 'uploads/Anagrams-Geography_5710392687.png', 'L', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'Anagrams-Geography'),
(235, 63, 238, 'Anagrams-Jobs', 'uploads/Anagrams-Jobs_2256901105.swf', 'uploads/Anagrams-Jobs_2256901105.png', 'L', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'Anagrams-Jobs'),
(236, 63, 239, 'Anagrams-Military', 'uploads/Anagrams-Military_2205101763.swf', 'uploads/Anagrams-Military_2205101763.png', 'L', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'Anagrams-Military'),
(237, 63, 240, 'Anagrams-People', 'uploads/Anagrams-People_1156277623.swf', 'uploads/Anagrams-People_1156277623.png', 'L', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'Anagrams-People'),
(238, 63, 241, 'ArrangeTheWords-Level5', 'uploads/ArrangeTheWords-Level5_4423534446.swf', 'uploads/ArrangeTheWords-Level5_4423534446.png', 'L', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'ArrangeTheWords-Level5'),
(239, 63, 242, 'MissingLetter-Level4', 'uploads/MissingLetter-Level4_7994128023.swf', 'uploads/MissingLetter-Level4_7994128023.png', 'L', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'MissingLetter-Level4'),
(240, 59, 243, 'BallAndBox-Level1', 'uploads/BallAndBox-Level1_3074306286.swf', 'uploads/BallAndBox-Level1_3074306286.png', 'M', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'BallAndBox-Level1'),
(241, 59, 244, 'BugSpot-Level1', 'uploads/BugSpot-Level1_4068491952.swf', 'uploads/BugSpot-Level1_4068491952.png', 'M', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'BugSpot-Level1');
INSERT INTO `sk_games` (`ID`, `skill_ID`, `game_masterID`, `name`, `swf_path`, `image_path`, `description`, `status`, `created_by`, `created_date`, `modified_by`, `modified_date`, `game_html`) VALUES
(242, 59, 245, 'CoordinateGraph-Level1', 'uploads/CoordinateGraph-Level1_1309713018.swf', 'uploads/CoordinateGraph-Level1_1309713018.png', 'M', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'CoordinateGraph-Level1'),
(243, 59, 246, 'DropBox-Level1', 'uploads/DropBox-Level1_6700938204.swf', 'uploads/DropBox-Level1_6700938204.png', 'M', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'DropBox-Level1'),
(244, 59, 247, 'MisplacedBuddy-Level1', 'uploads/MisplacedBuddy-Level1_4661093535.swf', 'uploads/MisplacedBuddy-Level1_4661093535.png', 'M', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'MisplacedBuddy-Level1'),
(245, 59, 248, 'RouteMemory-Level1', 'uploads/RouteMemory-Level1_3141601332.swf', 'uploads/RouteMemory-Level1_3141601332.png', 'M', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'RouteMemory-Level1'),
(246, 59, 249, 'SequenceMemory-Level7', 'uploads/SequenceMemory-Level7_6659360751.swf', 'uploads/SequenceMemory-Level7_6659360751.png', 'M', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'SequenceMemory-Level7'),
(247, 59, 250, 'SpotMyPlace-Level1', 'uploads/SpotMyPlace-Level1_8555905618.swf', 'uploads/SpotMyPlace-Level1_8555905618.png', 'M', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'SpotMyPlace-Level1'),
(248, 60, 251, 'ChooseTwoToMakeOne', 'uploads/ChooseTwoToMakeOne_7422157558.swf', 'uploads/ChooseTwoToMakeOne_7422157558.png', 'VP', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'ChooseTwoToMakeOne'),
(249, 60, 252, 'FlipTrick-Level1', 'uploads/FlipTrick-Level1_6290403776.swf', 'uploads/FlipTrick-Level1_6290403776.png', 'VP', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'FlipTrick-Level1'),
(250, 60, 253, 'FormTheSquare-Level1', 'uploads/FormTheSquare-Level1_9003437426.swf', 'uploads/FormTheSquare-Level1_9003437426.png', 'VP', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'FormTheSquare-Level1'),
(251, 60, 254, 'MirrorImage-Level1', 'uploads/MirrorImage-Level1_4596876199.swf', 'uploads/MirrorImage-Level1_4596876199.png', 'VP', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'MirrorImage-Level1'),
(252, 60, 255, 'ReflectionRead-Level4', 'uploads/ReflectionRead-Level4_4669125583.swf', 'uploads/ReflectionRead-Level4_4669125583.png', 'VP', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'ReflectionRead-Level4'),
(253, 60, 256, 'ReverseReading-Level4', 'uploads/ReverseReading-Level4_3547282922.swf', 'uploads/ReverseReading-Level4_3547282922.png', 'VP', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'ReverseReading-Level4'),
(254, 60, 257, 'WaterImage-Level1', 'uploads/WaterImage-Level1_4578736186.swf', 'uploads/WaterImage-Level1_4578736186.png', 'VP', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'WaterImage-Level1'),
(255, 60, 258, 'WhoIsNotThere-Level1', 'uploads/WhoIsNotThere-Level1_3340305127.swf', 'uploads/WhoIsNotThere-Level1_3340305127.png', 'VP', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'WhoIsNotThere-Level1'),
(256, 61, 259, 'ColorInColor-Level1', 'uploads/ColorInColor-Level1_1204938488.swf', 'uploads/ColorInColor-Level1_1204938488.png', 'FA', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'ColorInColor-Level1'),
(257, 61, 260, 'DarkLight-Level5', 'uploads/DarkLight-Level5_4619532418.swf', 'uploads/DarkLight-Level5_4619532418.png', 'FA', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'DarkLight-Level5'),
(258, 61, 261, 'DiscretePaddle-Level2', 'uploads/DiscretePadle-Level2_4007870662.swf', 'uploads/DiscretePadle-Level2_4007870662.png', 'FA', 'Y', 0, '2014-06-17 00:00:00', 0, '2017-06-06 13:37:34', 'DiscretePaddle-Level2'),
(259, 61, 262, 'NumberMe-Level1', 'uploads/NumberMe-Level1_9366972525.swf', 'uploads/NumberMe-Level1_9366972525.png', 'FA', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'NumberMe-Level1'),
(260, 61, 263, 'OddBall-Level1', 'uploads/OddBall-Level1_1096781706.swf', 'uploads/OddBall-Level1_1096781706.png', 'FA', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'OddBall-Level1'),
(261, 61, 264, 'ShapeRollers-Level3', 'uploads/ShapeRollers-Level3_6991897872.swf', 'uploads/ShapeRollers-Level3_6991897872.png', 'FA', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'ShapeRollers-Level3'),
(262, 61, 265, 'ShapeVsColorVsPattern-Level1', 'uploads/ShapeVsColorVsPattern-Level1_9182052793.swf', 'uploads/ShapeVsColorVsPattern-Level1_9182052793.png', 'FA', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'ShapeVsColorVsPattern-Level1'),
(263, 61, 266, 'SpotMe-Level6', 'uploads/SpotMe-Level6_7799745416.swf', 'uploads/SpotMe-Level6_7799745416.png', 'FA', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'SpotMe-Level6'),
(264, 62, 267, 'AnalogyAction-Level2', 'uploads/AnalogyAction-Level2_5585269308.swf', 'uploads/AnalogyAction-Level2_5585269308.png', 'PS', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'AnalogyAction-Level2'),
(265, 62, 268, 'Equate-Level1', 'uploads/Equate-Level1_3846404044.swf', 'uploads/Equate-Level1_3846404044.png', 'PS', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'Equate-Level1'),
(266, 62, 269, 'MasterVenn-Level1', 'uploads/MasterVenn-Level1_7031834167.swf', 'uploads/MasterVenn-Level1_7031834167.png', 'PS', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'MasterVenn-Level1'),
(267, 62, 270, 'NittyGritty', 'uploads/NittyGritty_5187215218.swf', 'uploads/NittyGritty_5187215218.png', 'PS', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'NittyGritty'),
(268, 62, 271, 'NumberPuzzle-Level2', 'uploads/NumberPuzzle-Level2_6727183759.swf', 'uploads/NumberPuzzle-Level2_6727183759.png', 'PS', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'NumberPuzzle-Level2'),
(269, 62, 272, 'NumbersOnTheVertices-Level1', 'uploads/NumbersOnTheVertices-Level1_6839827257.swf', 'uploads/NumbersOnTheVertices-Level1_6839827257.png', 'PS', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'NumbersOnTheVertices-Level1'),
(270, 62, 273, 'Shopping-Level1', 'uploads/Shopping-Level1_6256451136.swf', 'uploads/Shopping-Level1_6256451136.png', 'PS', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'Shopping-Level1'),
(271, 62, 274, 'TakeTurns-Level3', 'uploads/TakeTurns-Level3_8987652403.swf', 'uploads/TakeTurns-Level3_8987652403.png', 'PS', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'TakeTurns-Level3'),
(272, 63, 275, 'ConfusionGalore-Level1', 'uploads/ConfusionGalore-Level1_4439043053.swf', 'uploads/ConfusionGalore-Level1_4439043053.png', 'L', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'ConfusionGalore-Level1'),
(273, 63, 276, 'DividedWords-Level1', 'uploads/DividedWords-Level1_9592156563.swf', 'uploads/DividedWords-Level1_9592156563.png', 'L', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'DividedWords-Level1'),
(274, 63, 277, 'GuessTheWord-Level1', 'uploads/GuessTheWord-Level1_8028972977.swf', 'uploads/GuessTheWord-Level1_8028972977.png', 'L', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'GuessTheWord-Level1'),
(275, 63, 278, 'HomoPhones-Level1', 'uploads/HomoPhones-Level1_1627698740.swf', 'uploads/HomoPhones-Level1_1627698740.png', 'L', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'HomoPhones-Level1'),
(276, 63, 279, 'JumbledLetters-Level1', 'uploads/JumbledLetters-Level1_7572877304.swf', 'uploads/JumbledLetters-Level1_7572877304.png', 'L', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'JumbledLetters-Level1'),
(277, 63, 280, 'KangarooWords', 'uploads/KangarooWords_1111639351.swf', 'uploads/KangarooWords_1111639351.png', 'L', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'KangarooWords'),
(278, 63, 281, 'Rebus-Level1', 'uploads/Rebus-Level1_8831456145.swf', 'uploads/Rebus-Level1_8831456145.png', 'L', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'Rebus-Level1'),
(279, 63, 282, 'RootWords-Level1', 'uploads/RootWords-Level1_8710642922.swf', 'uploads/RootWords-Level1_8710642922.png', 'L', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'RootWords-Level1'),
(280, 59, 283, 'BallAndBox-Level2', 'uploads/BallAndBox-Level2_5648189471.swf', 'uploads/BallAndBox-Level2_5648189471.png', 'M', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'BallAndBox-Level2'),
(281, 59, 284, 'BugSpot-Level2', 'uploads/BugSpot-Level2_807683826.swf', 'uploads/BugSpot-Level2_807683826.png', 'M', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'BugSpot-Level2'),
(282, 59, 285, 'CoordinateGraph-Level2', 'uploads/CoordinateGraph-Level2_2700936608.swf', 'uploads/CoordinateGraph-Level2_2700936608.png', 'M', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'CoordinateGraph-Level2'),
(283, 59, 286, 'DropBox-Level2', 'uploads/DropBox-Level2_6796904369.swf', 'uploads/DropBox-Level2_6796904369.png', 'M', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'DropBox-Level2'),
(284, 59, 287, 'MisplacedBuddy-Level2', 'uploads/MisplacedBuddy-Level2_2612883471.swf', 'uploads/MisplacedBuddy-Level2_2612883471.png', 'M', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'MisplacedBuddy-Level2'),
(285, 59, 288, 'RouteMemory-Level2', 'uploads/RouteMemory-Level2_3784374403.swf', 'uploads/RouteMemory-Level2_3784374403.png', 'M', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'RouteMemory-Level2'),
(286, 59, 289, 'SequenceMemory-Level8', 'uploads/SequenceMemory-Level8_6523781293.swf', 'uploads/SequenceMemory-Level8_6523781293.png', 'M', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'SequenceMemory-Level8'),
(287, 59, 290, 'SpotMyPlace-Level2', 'uploads/SpotMyPlace-Level2_128739713.swf', 'uploads/SpotMyPlace-Level2_128739713.png', 'M', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'SpotMyPlace-Level2'),
(288, 60, 291, 'ChooseThreeToMakeOne', 'uploads/ChooseThreeToMakeOne_6421778858.swf', 'uploads/ChooseThreeToMakeOne_6421778858.png', 'VP', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'ChooseThreeToMakeOne'),
(289, 60, 292, 'FlipTrick-Level2', 'uploads/FlipTrick-Level2_2970519540.swf', 'uploads/FlipTrick-Level2_2970519540.png', 'VP', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'FlipTrick-Level2'),
(290, 60, 293, 'FormTheSquare-Level2', 'uploads/FormTheSquare-Level2_925395623.swf', 'uploads/FormTheSquare-Level2_925395623.png', 'VP', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'FormTheSquare-Level2'),
(291, 60, 294, 'MirrorImage-Level2', 'uploads/MirrorImage-Level2_8513625911.swf', 'uploads/MirrorImage-Level2_8513625911.png', 'M', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'MirrorImage-Level2'),
(292, 60, 295, 'ReflectionRead-Level5', 'uploads/ReflectionRead-Level5_3237627618.swf', 'uploads/ReflectionRead-Level5_3237627618.png', 'M', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'ReflectionRead-Level5'),
(293, 60, 296, 'ReverseReading-Level5', 'uploads/ReverseReading-Level5_5669675888.swf', 'uploads/ReverseReading-Level5_5669675888.png', 'VP', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'ReverseReading-Level5'),
(294, 60, 297, 'WaterImage-Level2', 'uploads/WaterImage-Level2_3779711904.swf', 'uploads/WaterImage-Level2_3779711904.png', 'VP', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'WaterImage-Level2'),
(295, 60, 298, 'WhoIsNotThere-Level2', 'uploads/WhoIsNotThere-Level2_67013050.swf', 'uploads/WhoIsNotThere-Level2_67013050.png', 'VP', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'WhoIsNotThere-Level2'),
(296, 61, 299, 'ColorInColor-Level2', 'uploads/ColorInColor-Level2_4620457286.swf', 'uploads/ColorInColor-Level2_4620457286.png', 'FA', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'ColorInColor-Level2'),
(297, 61, 300, 'DarkLight-Level6', 'uploads/DarkLight-Level6_8921038703.swf', 'uploads/DarkLight-Level6_8921038703.png', 'FA', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'DarkLight-Level6'),
(298, 61, 301, 'DiscretePaddle-Level3', 'uploads/DiscretePadle-Level3_3544559371.swf', 'uploads/DiscretePadle-Level3_3544559371.png', 'FA', 'Y', 0, '2014-06-17 00:00:00', 0, '2017-06-12 11:14:43', 'DiscretePaddle-Level3'),
(299, 61, 302, 'NumberMe-Level2', 'uploads/NumberMe-Level2_1924527920.swf', 'uploads/NumberMe-Level2_1924527920.png', 'FA', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'NumberMe-Level2'),
(300, 61, 303, 'OddBall-Level2', 'uploads/OddBall-Level2_3363969377.swf', 'uploads/OddBall-Level2_3363969377.png', 'FA', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'OddBall-Level2'),
(301, 61, 304, 'ShapeRollers-Level4', 'uploads/ShapeRollers-Level4_452656652.swf', 'uploads/ShapeRollers-Level4_452656652.png', 'FA', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'ShapeRollers-Level4'),
(302, 61, 306, 'ShapeVsColorVsPattern-Level2', 'uploads/ShapeVsColorVsPattern-Level2_533262947.swf', 'uploads/ShapeVsColorVsPattern-Level2_533262947.png', 'FA', 'Y', 0, '2014-06-18 00:00:00', 0, '2016-12-08 06:39:20', 'ShapeVsColorVsPattern-Level2'),
(303, 61, 307, 'SpotMe-Level7', 'uploads/SpotMe-Level7_2691923594.swf', 'uploads/SpotMe-Level7_2691923594.png', 'FA', 'Y', 0, '2014-06-18 00:00:00', 0, '2016-12-08 06:39:20', 'SpotMe-Level7'),
(304, 62, 308, 'AnalogyAction-Level3', 'uploads/AnalogyAction-Level3_1947425035.swf', 'uploads/AnalogyAction-Level3_1947425035.png', 'PS', 'Y', 0, '2014-06-18 00:00:00', 0, '2017-06-13 19:19:12', 'AnalogyAction-Level3'),
(305, 62, 309, 'Equate-Level2', 'uploads/Equate-Level2_6867011720.swf', 'uploads/Equate-Level2_6867011720.png', 'PS', 'Y', 0, '2014-06-18 00:00:00', 0, '2016-12-08 06:39:20', 'Equate-Level2'),
(306, 62, 310, 'LogicalSequence', 'uploads/LogicalSequence_3583530234.swf', 'uploads/LogicalSequence_3583530234.png', 'PS', 'Y', 0, '2014-06-18 00:00:00', 0, '2016-12-08 06:39:20', 'LogicalSequence'),
(307, 62, 311, 'MasterVenn-Level2', 'uploads/MasterVenn-Level2_6223853942.swf', 'uploads/MasterVenn-Level2_6223853942.png', 'PS', 'Y', 0, '2014-06-18 00:00:00', 0, '2016-12-08 06:39:20', 'MasterVenn-Level2'),
(308, 62, 312, 'NumberPuzzle-Level3', 'uploads/NumberPuzzle-Level3_4147070031.swf', 'uploads/NumberPuzzle-Level3_4147070031.png', 'PS', 'Y', 0, '2014-06-18 00:00:00', 0, '2016-12-08 06:39:20', 'NumberPuzzle-Level3'),
(309, 62, 313, 'NumbersOnTheVertices-Level2', 'uploads/NumbersOnTheVertices-Level2_1932858121.swf', 'uploads/NumbersOnTheVertices-Level2.png', 'PS', 'Y', 0, '2014-06-18 00:00:00', 0, '2017-06-16 11:35:23', 'NumbersOnTheVertices-Level2'),
(310, 62, 314, 'Shopping-Level2', 'uploads/Shopping-Level2_4992981352.swf', 'uploads/Shopping-Level2_4992981352.png', 'PS', 'Y', 0, '2014-06-18 00:00:00', 0, '2016-12-08 06:39:20', 'Shopping-Level2'),
(311, 62, 315, 'TakeTurns-Level4', 'uploads/TakeTurns-Level4_4899050295.swf', 'uploads/TakeTurns-Level4_4899050295.png', 'PS', 'Y', 0, '2014-06-18 00:00:00', 0, '2016-12-08 06:39:20', 'TakeTurns-Level4'),
(312, 63, 316, 'ConfusionGalore-Level2', 'uploads/ConfusionGalore-Level2_9538272568.swf', 'uploads/ConfusionGalore-Level2_9538272568.png', 'L', 'Y', 0, '2014-06-18 00:00:00', 0, '2016-12-08 06:39:20', 'ConfusionGalore-Level2'),
(313, 63, 317, 'DividedWords-Level2', 'uploads/DividedWords-Level2_482863192.swf', 'uploads/DividedWords-Level2_482863192.png', 'L', 'Y', 0, '2014-06-18 00:00:00', 0, '2016-12-08 06:39:20', 'DividedWords-Level2'),
(314, 63, 318, 'GuessTheWord-Level2', 'uploads/GuessTheWord-Level2_718786111.swf', 'uploads/GuessTheWord-Level2_718786111.png', 'L', 'Y', 0, '2014-06-18 00:00:00', 0, '2016-12-08 06:39:20', 'GuessTheWord-Level2'),
(315, 63, 319, 'Homophones-Level2', 'uploads/HomoPhones-Level2_3726777150.swf', 'uploads/HomoPhones-Level2_3726777150.png', 'L', 'Y', 0, '2014-06-18 00:00:00', 0, '2017-06-12 11:19:56', 'Homophones-Level2'),
(316, 63, 320, 'JumbledLetters-Level2', 'uploads/JumbledLetters-Level2_497916364.swf', 'uploads/JumbledLetters-Level2_497916364.png', 'L', 'Y', 0, '2014-06-18 00:00:00', 0, '2016-12-08 06:39:20', 'JumbledLetters-Level2'),
(317, 63, 321, 'PrefixRootAndSuffix', 'uploads/PrefixRootAndSuffix_204385071.swf', 'uploads/PrefixRootAndSuffix_204385071.png', 'L', 'Y', 0, '2014-06-18 00:00:00', 0, '2016-12-08 06:39:20', 'PrefixRootAndSuffix'),
(318, 63, 322, 'Rebus-Level2', 'uploads/Rebus-Level2_2737128175.swf', 'uploads/Rebus-Level2_2737128175.png', 'L', 'Y', 0, '2014-06-18 00:00:00', 0, '2016-12-08 06:39:20', 'Rebus-Level2'),
(319, 63, 323, 'RootWords-Level2', 'uploads/RootWords-Level2_162112307.swf', 'uploads/RootWords-Level2_162112307.png', 'L', 'Y', 0, '2014-06-18 00:00:00', 0, '2016-12-08 06:39:20', 'RootWords-Level2'),
(410, 59, 414, 'AddOn-Level1', 'uploads/AddOn-Level1_29916255.swf', 'uploads/AddOn-Level1_29916255.png', 'M', 'Y', 0, '2014-06-26 00:00:00', 0, '2016-12-08 06:39:20', 'AddOn-Level1'),
(411, 59, 415, 'AnimalRecall-Level1', 'uploads/AnimalRecall-Level1_5902908118.swf', 'uploads/AnimalRecall-Level1_5902908118.png', 'M', 'Y', 0, '2014-06-26 00:00:00', 0, '2016-12-08 06:39:20', 'AnimalRecall-Level1'),
(412, 59, 416, 'BuddySpot-Level1', 'uploads/BuddySpot-Level1_4558774498.swf', 'uploads/BuddySpot-Level1_4558774498.png', 'BuddySpot-Level1', 'Y', 0, '2014-06-26 00:00:00', 0, '2016-12-08 06:39:20', 'BuddySpot-Level1'),
(413, 59, 417, 'FruitDrop-Level1', 'uploads/FruitDrop-Level1_5968954963.swf', 'uploads/FruitDrop-Level1_5968954963.png', 'M', 'Y', 0, '2014-06-26 00:00:00', 0, '2016-12-08 06:39:20', 'FruitDrop-Level1'),
(414, 59, 418, 'JackInTheBox-Level1', 'uploads/JackInTheBox-Level1_8967085247.swf', 'uploads/JackInTheBox-Level1_8967085247.png', 'M', 'Y', 0, '2014-06-26 00:00:00', 0, '2016-12-08 06:39:20', 'JackInTheBox-Level1'),
(415, 59, 419, 'LocateTheParts-Level1', 'uploads/LocateTheParts-Level1_9876082488.swf', 'uploads/LocateTheParts-Level1_9876082488.png', 'M', 'Y', 0, '2014-06-26 00:00:00', 0, '2016-12-08 06:39:20', 'LocateTheParts-Level1'),
(416, 59, 420, 'NumberScramble', 'uploads/NumberScramble_5994973969.swf', 'uploads/NumberScramble_5994973969.png', 'M', 'Y', 0, '2014-06-26 00:00:00', 0, '2016-12-08 06:39:20', 'NumberScramble'),
(417, 59, 421, 'SmileySeries-Level1', 'uploads/SmileySeries-Level1_3376116408.swf', 'uploads/SmileySeries-Level1_3376116408.png', 'M', 'Y', 0, '2014-06-26 00:00:00', 0, '2016-12-08 06:39:20', 'SmileySeries-Level1'),
(418, 60, 422, 'BestFit-Level1', 'uploads/BestFit-KG1_6883309637.swf', 'uploads/BestFit-KG1_6883309637.png', 'M', 'Y', 0, '2014-06-26 00:00:00', 0, '2017-01-03 09:46:24', 'BestFit-Level1'),
(419, 60, 423, 'EarringMatch-Level1', 'uploads/EarringMatch-Level1_9153384454.swf', 'uploads/EarringMatch-Level1_9153384454.png', 'VP', 'Y', 0, '2014-06-26 00:00:00', 0, '2016-12-08 06:39:20', 'EarringMatch-Level1'),
(420, 60, 424, 'FaceCut-Level1', 'uploads/FaceCut-Level1_7893398585.swf', 'uploads/FaceCut-Level1_7893398585.png', 'VP', 'Y', 0, '2014-06-26 00:00:00', 0, '2016-12-08 06:39:20', 'FaceCut-Level1'),
(421, 60, 425, 'IconMatch-Level1', 'uploads/IconMatch-Level1_4288190002.swf', 'uploads/IconMatch-Level1_4288190002.png', 'VP', 'Y', 0, '2014-06-26 00:00:00', 0, '2016-12-08 06:39:20', 'IconMatch-Level1'),
(422, 60, 426, 'LostLastPart-Level1', 'uploads/LostLastPart-Level1_6288307351.swf', 'uploads/LostLastPart-Level1_6288307351.png', 'VP', 'Y', 0, '2014-06-26 00:00:00', 0, '2016-12-08 06:39:20', 'LostLastPart-Level1'),
(423, 60, 427, 'MysteryWord-Level1', 'uploads/MysteryWord-Level1_4597698734.swf', 'uploads/MysteryWord-Level1_4597698734.png', 'VP', 'Y', 0, '2014-06-26 00:00:00', 0, '2016-12-08 06:39:20', 'MysteryWord-Level1'),
(424, 60, 428, 'TwinPiece-Level1', 'uploads/TwinPiece-Level1_277658514.swf', 'uploads/TwinPiece-Level1_277658514.png', 'VP', 'Y', 0, '2014-06-26 00:00:00', 0, '2016-12-08 06:39:20', 'TwinPiece-Level1'),
(425, 60, 429, 'WhoHits-Level1', 'uploads/WhoHits-Level1_1098579633.swf', 'uploads/WhoHits-Level1_1098579633.png', 'VP', 'Y', 0, '2014-06-26 00:00:00', 0, '2016-12-08 06:39:20', 'WhoHits-Level1'),
(426, 61, 430, 'AlphaFocus-Level1', 'uploads/AlphaFocus-Level1_7799442643.swf', 'uploads/AlphaFocus-Level1_7799442643.png', 'FA', 'Y', 0, '2014-06-26 00:00:00', 0, '2016-12-08 06:39:20', 'AlphaFocus-Level1'),
(427, 61, 431, 'ArrowHit-Level1', 'uploads/ArrowHit-Level1_2562350165.swf', 'uploads/ArrowHit-Level1_2562350165.png', 'FA', 'Y', 0, '2014-06-26 00:00:00', 0, '2016-12-08 06:39:20', 'ArrowHit-Level1'),
(428, 61, 432, 'DoWeDiffer-Level1', 'uploads/DoWeDiffer-Level1_9961162102.swf', 'uploads/DoWeDiffer-Level1_9961162102.png', 'FA', 'Y', 0, '2014-06-26 00:00:00', 0, '2016-12-08 06:39:20', 'DoWeDiffer-Level1'),
(429, 61, 433, 'PathTrace-Level1', 'uploads/PathTrace-Level1_9113778676.swf', 'uploads/PathTrace-Level1_9113778676.png', 'FA', 'Y', 0, '2014-06-26 00:00:00', 0, '2016-12-08 06:39:20', 'PathTrace-Level1'),
(430, 61, 434, 'StarLight-Level1', 'uploads/StarLight-KG1_6201227623.swf', 'uploads/StarLight-KG1_6201227623.png', 'FA', 'Y', 0, '2014-06-26 00:00:00', 0, '2017-06-12 09:09:36', 'StarLight-Level1'),
(431, 61, 435, 'StrangerGrid-Level1', 'uploads/StrangerGrid-KG1_7493638731.swf', 'uploads/StrangerGrid-KG1_7493638731.png', 'FA', 'Y', 0, '2014-06-26 00:00:00', 0, '2017-01-04 06:45:24', 'StrangerGrid-Level1'),
(432, 61, 436, 'OddAlphaNumber-Level1', 'uploads/WeirdAlphaNumber-Level1_4951013289.swf', 'uploads/WeirdAlphaNumber-Level1_4951013289.png', 'FA', 'Y', 0, '2014-06-26 00:00:00', 0, '2017-06-12 09:11:59', 'OddAlphaNumber-Level1'),
(433, 61, 437, 'WhoReachesOut-Level1', 'uploads/WhoReachesOut-Level1_8087662272.swf', 'uploads/WhoReachesOut-Level1_8087662272.png', 'FA', 'Y', 0, '2014-06-26 00:00:00', 0, '2016-12-08 06:39:20', 'WhoReachesOut-Level1'),
(434, 62, 438, 'CompareContest-Level1', 'uploads/CompareContest-Level1_1414912887.swf', 'uploads/CompareContest-Level1_1414912887.png', 'PS', 'Y', 0, '2014-06-26 00:00:00', 0, '2016-12-08 06:39:20', 'CompareContest-Level1'),
(435, 62, 439, 'GroupIt-Level1', 'uploads/GroupIt-Level1_2434460278.swf', 'uploads/GroupIt-Level1_2434460278.png', 'PS', 'Y', 0, '2014-06-26 00:00:00', 0, '2016-12-08 06:39:20', 'GroupIt-Level1'),
(436, 62, 440, 'ImageSequence-Level1', 'uploads/ImageSequence-Level1_1271936539.swf', 'uploads/ImageSequence-Level1_1271936539.png', 'PS', 'Y', 0, '2014-06-26 00:00:00', 0, '2016-12-08 06:39:20', 'ImageSequence-Level1'),
(437, 62, 441, 'MakeAPattern-Level1', 'uploads/MakeAPattern-Level1_374257480.swf', 'uploads/MakeAPattern-Level1_374257480.png', 'PS', 'Y', 0, '2014-06-26 00:00:00', 0, '2016-12-08 06:39:20', 'MakeAPattern-Level1'),
(438, 62, 442, 'PatternForAPattern-Level1', 'uploads/PatternForAPattern-Level1_5394952590.swf', 'uploads/PatternForAPattern-Level1_5394952590.png', 'PS', 'Y', 0, '2014-06-26 00:00:00', 0, '2016-12-08 06:39:20', 'PatternForAPattern-Level1'),
(439, 62, 443, 'PatternRepresentation-Level1', 'uploads/PatternRepresentation-Level1_7518243058.swf', 'uploads/PatternRepresentation-Level1_7518243058.png', 'PS', 'Y', 0, '2014-06-26 00:00:00', 0, '2016-12-08 06:39:20', 'PatternRepresentation-Level1'),
(440, 62, 444, 'SymmetryOrNot-Level1', 'uploads/SymmetryOrNot-Level1_535150892.swf', 'uploads/SymmetryOrNot-Level1_535150892.png', 'PS', 'Y', 0, '2014-06-26 00:00:00', 0, '2016-12-08 06:39:20', 'SymmetryOrNot-Level1'),
(441, 62, 445, 'WhatComesNext-Level1', 'uploads/WhatComesNext-Level1_3932243706.swf', 'uploads/WhatComesNext-Level1_3932243706.png', 'PS', 'Y', 0, '2014-06-26 00:00:00', 0, '2016-12-08 06:39:20', 'WhatComesNext-Level1'),
(442, 63, 446, 'AbsentInAlphabet', 'uploads/AbsentAlphabet_5964533849.swf', 'uploads/AbsentAlphabet_5964533849.png', 'L', 'Y', 0, '2014-06-26 00:00:00', 0, '2017-06-12 09:16:46', 'AbsentInAlphabet'),
(443, 63, 447, 'LetterPicturePair', 'uploads/AlphabetPicturePair_441006175.swf', 'uploads/AlphabetPicturePair_441006175.png', 'L', 'Y', 0, '2014-06-26 00:00:00', 0, '2017-06-12 09:19:10', 'LetterPicturePair'),
(444, 63, 448, 'LetterSearch', 'uploads/AlphabetSearch_1266466071.swf', 'uploads/AlphabetSearch_1266466071.png', 'L', 'Y', 0, '2014-06-26 00:00:00', 0, '2017-06-12 09:17:35', 'LetterSearch'),
(445, 63, 449, 'LetterStart', 'uploads/AlphabetStart_6351753645.swf', 'uploads/AlphabetStart_6351753645.png', 'L', 'Y', 0, '2014-06-26 00:00:00', 0, '2017-06-12 09:18:21', 'LetterStart'),
(446, 63, 450, 'LetterCases', 'uploads/LetterCases_8069400168.swf', 'uploads/LetterCases_8069400168.png', 'L', 'Y', 0, '2014-06-26 00:00:00', 0, '2016-12-08 06:39:20', 'LetterCases'),
(447, 63, 451, 'MissingInMiddle', 'uploads/MissingInMiddle_5156854209.swf', 'uploads/MissingInMiddle_5156854209.png', 'L', 'Y', 0, '2014-06-26 00:00:00', 0, '2016-12-08 06:39:20', 'MissingInMiddle'),
(448, 63, 452, 'SpellIt-Level1', 'uploads/SpellIt-Level1_4972556773.swf', 'uploads/SpellIt-Level1_4972556773.png', 'L', 'Y', 0, '2014-06-26 00:00:00', 0, '2016-12-08 06:39:20', 'SpellIt-Level1'),
(449, 63, 453, 'WhoStartsWithMe', 'uploads/WhoStartsWithMe_9145371927.swf', 'uploads/WhoStartsWithMe_9145371927.png', 'L', 'Y', 0, '2014-06-26 00:00:00', 0, '2016-12-08 06:39:20', 'WhoStartsWithMe'),
(460, 59, 464, 'AddOn-Level2', 'uploads/AddOn-Level2_2288141329.swf', 'uploads/AddOn-Level2_2288141329.png', 'M', 'Y', 0, '2014-06-26 00:00:00', 0, '2016-12-08 06:39:20', 'AddOn-Level2'),
(461, 59, 465, 'AlphaNumberScramble', 'uploads/AlphaNumberScramble_3375521898.swf', 'uploads/AlphaNumberScramble_3375521898.png', 'M', 'Y', 0, '2014-06-26 00:00:00', 0, '2016-12-08 06:39:20', 'AlphaNumberScramble'),
(462, 59, 466, 'AnimalRecall-Level2', 'uploads/AnimalRecall-Level2_6097432286.swf', 'uploads/AnimalRecall-Level2_6097432286.png', 'M', 'Y', 0, '2014-06-26 00:00:00', 0, '2016-12-08 06:39:20', 'AnimalRecall-Level2'),
(463, 59, 467, 'BuddySpot-Level2', 'uploads/BuddySpot-Level2_9439796507.swf', 'uploads/BuddySpot-Level2_9439796507.png', 'M', 'Y', 0, '2014-06-26 00:00:00', 0, '2016-12-08 06:39:20', 'BuddySpot-Level2'),
(464, 59, 468, 'FruitDrop-Level2', 'uploads/FruitDrop-Level2_321508771.swf', 'uploads/FruitDrop-Level2_321508771.png', 'M', 'Y', 0, '2014-06-26 00:00:00', 0, '2016-12-08 06:39:20', 'FruitDrop-Level2'),
(465, 59, 469, 'JackInTheBox-Level2', 'uploads/JackInTheBox-Level2_5127689531.swf', 'uploads/JackInTheBox-Level2_5127689531.png', 'M', 'Y', 0, '2014-06-26 00:00:00', 0, '2016-12-08 06:39:20', 'JackInTheBox-Level2'),
(466, 59, 470, 'LocateTheParts-Level2', 'uploads/LocateTheParts-Level2_4917782000.swf', 'uploads/LocateTheParts-Level2_4917782000.png', 'M', 'Y', 0, '2014-06-26 00:00:00', 0, '2016-12-08 06:39:20', 'LocateTheParts-Level2'),
(467, 59, 471, 'SmileySeries-Level2', 'uploads/SmileySeries-Level2_3532663313.swf', 'uploads/SmileySeries-Level2_3532663313.png', 'M', 'Y', 0, '2014-06-26 00:00:00', 0, '2016-12-08 06:39:20', 'SmileySeries-Level2'),
(468, 60, 472, 'BestFit-Level2', 'uploads/BestFit-KG2_8591418769.swf', 'uploads/BestFit-KG2_8591418769.png', 'VP', 'Y', 0, '2014-06-26 00:00:00', 0, '2017-06-12 09:25:09', 'BestFit-Level2'),
(469, 60, 473, 'EarringMatch-Level2', 'uploads/EarringMatch-Level2_9765920392.swf', 'uploads/EarringMatch-Level2_9765920392.png', 'VP', 'Y', 0, '2014-06-26 00:00:00', 0, '2016-12-08 06:39:20', 'EarringMatch-Level2'),
(470, 60, 474, 'FaceCut-Level2', 'uploads/FaceCut-Level2_8397557884.swf', 'uploads/FaceCut-Level2_8397557884.png', 'VP', 'Y', 0, '2014-06-26 00:00:00', 0, '2016-12-08 06:39:20', 'FaceCut-Level2'),
(471, 60, 475, 'IconMatch-Level2', 'uploads/IconMatch-Level2_191964996.swf', 'uploads/IconMatch-Level2_191964996.png', 'VP', 'Y', 0, '2014-06-26 00:00:00', 0, '2016-12-08 06:39:20', 'IconMatch-Level2'),
(472, 60, 476, 'LostLastPart-Level2', 'uploads/LostLastPart-Level2_6243226788.swf', 'uploads/LostLastPart-Level2_6243226788.png', 'VP', 'Y', 0, '2014-06-26 00:00:00', 0, '2016-12-08 06:39:20', 'LostLastPart-Level2'),
(473, 60, 477, 'MysteryWord-Level2', 'uploads/MysteryWord-Level2_8829181427.swf', 'uploads/MysteryWord-Level2_8829181427.png', 'VP', 'Y', 0, '2014-06-26 00:00:00', 0, '2016-12-08 06:39:20', 'MysteryWord-Level2'),
(474, 60, 478, 'TwinPiece-Level2', 'uploads/TwinPiece-Level2_4966554236.swf', 'uploads/TwinPiece-Level2_4966554236.png', 'VP', 'Y', 0, '2014-06-26 00:00:00', 0, '2016-12-08 06:39:20', 'TwinPiece-Level2'),
(475, 60, 479, 'WhoHits-Level2', 'uploads/WhoHits-Level2_3314637686.swf', 'uploads/WhoHits-Level2_3314637686.png', 'VP', 'Y', 0, '2014-06-26 00:00:00', 0, '2016-12-08 06:39:20', 'WhoHits-Level2'),
(476, 61, 480, 'AlphaFocus-Level2', 'uploads/AlphaFocus-Level2_9990389710.swf', 'uploads/AlphaFocus-Level2_9990389710.png', 'FA', 'Y', 0, '2014-06-26 00:00:00', 0, '2016-12-08 06:39:20', 'AlphaFocus-Level2'),
(477, 61, 481, 'ArrowHit-Level2', 'uploads/ArrowHit-Level2_7136968858.swf', 'uploads/ArrowHit-Level2_7136968858.png', 'FA', 'Y', 0, '2014-06-26 00:00:00', 0, '2016-12-08 06:39:20', 'ArrowHit-Level2'),
(478, 61, 482, 'DoWeDiffer-Level2', 'uploads/DoWeDiffer-Level2_7497774129.swf', 'uploads/DoWeDiffer-Level2_7497774129.png', 'FA', 'Y', 0, '2014-06-26 00:00:00', 0, '2016-12-08 06:39:20', 'DoWeDiffer-Level2'),
(479, 61, 483, 'PathTrace-Level2', 'uploads/PathTrace-Level2_9511187383.swf', 'uploads/PathTrace-Level2_9511187383.png', 'FA', 'Y', 0, '2014-06-26 00:00:00', 0, '2016-12-08 06:39:20', 'PathTrace-Level2'),
(480, 61, 484, 'StarLight-Level2', 'uploads/StarLight-KG2_7005840959.swf', 'uploads/StarLight-KG2_7005840959.png', 'FA', 'Y', 0, '2014-06-26 00:00:00', 0, '2017-06-12 09:26:46', 'StarLight-Level2'),
(481, 61, 485, 'StrangerGrid-Level2', 'uploads/StrangerGrid-KG2_1036263587.swf', 'uploads/StrangerGrid-KG2_1036263587.png', 'FA', 'Y', 0, '2014-06-26 00:00:00', 0, '2017-01-23 08:57:58', 'StrangerGrid-Level2'),
(482, 61, 486, 'OddAlphaNumber-Level2', 'uploads/WeirdAlphaNumber-Level2_4363326304.swf', 'uploads/WeirdAlphaNumber-Level2_4363326304.png', 'FA', 'Y', 0, '2014-06-26 00:00:00', 0, '2017-06-12 09:28:47', 'OddAlphaNumber-Level2'),
(483, 61, 487, 'WhoReachesOut-Level2', 'uploads/WhoReachesOut-Level2_9702787548.swf', 'uploads/WhoReachesOut-Level2_9702787548.png', 'FA', 'Y', 0, '2014-06-26 00:00:00', 0, '2016-12-08 06:39:20', 'WhoReachesOut-Level2'),
(484, 62, 488, 'CompareContest-Level2', 'uploads/CompareContest-Level2_1971407081.swf', 'uploads/CompareContest-Level2_1971407081.png', 'PS', 'Y', 0, '2014-06-26 00:00:00', 0, '2016-12-08 06:39:20', 'CompareContest-Level2'),
(485, 62, 489, 'GroupIt-Level2', 'uploads/GroupIt-Level2_8481714227.swf', 'uploads/GroupIt-Level2_8481714227.png', 'PS', 'Y', 0, '2014-06-26 00:00:00', 0, '2016-12-08 06:39:20', 'GroupIt-Level2'),
(486, 62, 490, 'ImageSequence-Level2', 'uploads/ImageSequence-Level2_3751685819.swf', 'uploads/ImageSequence-Level2_3751685819.png', 'PS', 'Y', 0, '2014-06-26 00:00:00', 0, '2016-12-08 06:39:20', 'ImageSequence-Level2'),
(487, 62, 491, 'MakeAPattern-Level2', 'uploads/MakeAPattern-Level2_4096280215.swf', 'uploads/MakeAPattern-Level2_4096280215.png', 'PS', 'Y', 0, '2014-06-26 00:00:00', 0, '2016-12-08 06:39:20', 'MakeAPattern-Level2'),
(488, 62, 492, 'PatternForAPattern-Level2', 'uploads/PatternForAPattern-Level2_7414737520.swf', 'uploads/PatternForAPattern-Level2_7414737520.png', 'PS', 'Y', 0, '2014-06-26 00:00:00', 0, '2016-12-08 06:39:20', 'PatternForAPattern-Level2'),
(489, 62, 493, 'PatternRepresentation-Level2', 'uploads/PatternRepresentation-Level2_1035452852.swf', 'uploads/PatternRepresentation-Level2_1035452852.png', 'PS', 'Y', 0, '2014-06-26 00:00:00', 0, '2016-12-08 06:39:20', 'PatternRepresentation-Level2'),
(490, 62, 494, 'SymmetryOrNot-Level2', 'uploads/SymmetryOrNot-Level2_4635163354.swf', 'uploads/SymmetryOrNot-Level2_4635163354.png', 'PS', 'Y', 0, '2014-06-26 00:00:00', 0, '2016-12-08 06:39:20', 'SymmetryOrNot-Level2'),
(491, 62, 495, 'WhoJoinsTheGroup', 'uploads/WhoJoinsTheGroup_9253409225.swf', 'uploads/WhoJoinsTheGroup_9253409225.png', 'PS', 'Y', 0, '2014-06-26 00:00:00', 0, '2017-06-12 09:29:47', 'WhoJoinsTheGroup'),
(492, 63, 496, 'LetterOrder', 'uploads/AlphabetOrder_1804643566.swf', 'uploads/AlphabetOrder_1804643566.png', 'L', 'Y', 0, '2014-06-26 00:00:00', 0, '2017-06-12 09:31:30', 'LetterOrder'),
(493, 63, 497, 'Articles', 'uploads/Articles_6478719203.swf', 'uploads/Articles_6478719203.png', 'L', 'Y', 0, '2014-06-26 00:00:00', 0, '2016-12-08 06:39:20', 'Articles'),
(494, 63, 498, 'FormTheWord', 'uploads/FormTheWord_5906901671.swf', 'uploads/FormTheWord_5906901671.png', 'L', 'Y', 0, '2014-06-26 00:00:00', 0, '2016-12-08 06:39:20', 'FormTheWord'),
(495, 63, 499, 'InAndOn', 'uploads/InAndOn_9388019754.swf', 'uploads/InAndOn_9388019754.png', 'L', 'Y', 0, '2014-06-26 00:00:00', 0, '2016-12-08 06:39:20', 'InAndOn'),
(496, 63, 500, 'MissingVowel', 'uploads/MissingVowel_7264694026.swf', 'uploads/MissingVowel_7264694026.png', 'L', 'Y', 0, '2014-06-26 00:00:00', 0, '2016-12-08 06:39:20', 'MissingVowel'),
(497, 63, 501, 'RhymingWords', 'uploads/RhymingWords_5765644419.swf', 'uploads/RhymingWords_5765644419.png', 'L', 'Y', 0, '2014-06-26 00:00:00', 0, '2016-12-08 06:39:20', 'RhymingWords'),
(498, 63, 502, 'SpellIt-Level2', 'uploads/SpellIt-Level2_2642293530.swf', 'uploads/SpellIt-Level2_2642293530.png', 'L', 'Y', 0, '2014-06-26 00:00:00', 0, '2016-12-08 06:39:20', 'SpellIt-Level2'),
(499, 63, 503, 'WordBuilding', 'uploads/WordBuilding_9514361643.swf', 'uploads/WordBuilding_9514361643.png', 'L', 'Y', 0, '2014-06-26 00:00:00', 0, '2016-12-08 06:39:20', 'WordBuilding'),
(510, 59, 514, 'BalloonBurst-Level1', 'uploads/BalloonBurst-Level1_8117342898.swf', 'uploads/BalloonBurst-Level1_8117342898.png', 'Memory', 'Y', 0, '2014-06-17 00:00:00', 0, '2016-12-08 06:39:20', 'BalloonBurst-Level1'),
(511, 59, 521, 'Fruit Drop', '', 'uploads/FruitDrop-Level1_5968954963.png', 'Memory', 'Y', 0, '2017-09-25 00:00:00', 0, '2017-09-25 05:02:34', 'FruitDrop-KG'),
(512, 59, 522, 'Animal Recall', '', 'uploads/AnimalRecall-Level1_5902908118.png', 'Memory', 'Y', 0, '2017-09-25 00:00:00', 0, '2017-09-25 05:02:34', 'AnimalRecall-KG'),
(513, 59, 523, 'Smiley Series', '', 'uploads/SmileySeries-Level1_3376116408.png', 'Memory', 'Y', 0, '2017-09-25 00:00:00', 0, '2017-09-25 05:02:34', 'SmileySeries-KG'),
(514, 59, 524, 'Jack In The Box', '', 'uploads/JackInTheBox-Level1_8967085247.png', 'Memory', 'Y', 0, '2017-09-25 00:00:00', 0, '2017-09-25 05:02:34', 'JackInTheBox-KG'),
(515, 59, 525, 'Number Scramble', '', 'uploads/NumberScramble_5994973969.png', 'Memory', 'Y', 0, '2017-09-25 00:00:00', 0, '2017-09-25 05:02:34', 'NumberScramble-KG'),
(516, 59, 526, 'Locate The Parts', '', 'uploads/LocateTheParts-Level1_9876082488.png', 'Memory', 'Y', 0, '2017-09-25 00:00:00', 0, '2017-09-25 05:02:34', 'LocateTheParts-KG'),
(517, 59, 527, 'Buddy Spot', '', 'uploads/BuddySpot-Level1_4558774498.png', 'Memory', 'Y', 0, '2017-09-25 00:00:00', 0, '2017-09-25 05:02:34', 'BuddySpot-KG'),
(518, 59, 528, 'Add On', '', 'uploads/AddOn-Level1_29916255.png', 'Memory', 'Y', 0, '2017-09-25 00:00:00', 0, '2017-09-25 05:02:34', 'AddOn-KG'),
(519, 60, 529, 'Icon Match', '', 'uploads/IconMatch-Level1_4288190002.png', 'VP', 'Y', 0, '2017-09-25 00:00:00', 0, '2017-09-25 05:02:34', 'IconMatch-KG'),
(520, 60, 530, 'Who Hits', '', 'uploads/WhoHits-Level1_1098579633.png', 'VP', 'Y', 0, '2017-09-25 00:00:00', 0, '2017-09-25 05:02:34', 'WhoHits-KG'),
(521, 60, 531, 'Best Fit', '', 'uploads/BestFit-KG1_6883309637.png', 'VP', 'Y', 0, '2017-09-25 00:00:00', 0, '2017-09-25 05:02:34', 'BestFit-KG'),
(522, 60, 532, 'Earring Match', '', 'uploads/EarringMatch-Level1_9153384454.png', 'VP', 'Y', 0, '2017-09-25 00:00:00', 0, '2017-09-25 05:02:34', 'EarringMatch-KG'),
(523, 60, 533, 'Face Cut', '', 'uploads/FaceCut-Level1_7893398585.png', 'VP', 'Y', 0, '2017-09-25 00:00:00', 0, '2017-09-25 05:02:34', 'FaceCut-KG'),
(524, 60, 534, 'Lost Last Part', '', 'uploads/LostLastPart-Level1_6288307351.png', 'VP', 'Y', 0, '2017-09-25 00:00:00', 0, '2017-09-25 05:02:34', 'LostLastPart-KG'),
(525, 60, 535, 'Mystery Word', '', 'uploads/MysteryWord-Level1_4597698734.png', 'VP', 'Y', 0, '2017-09-25 00:00:00', 0, '2017-09-25 05:02:34', 'MysteryWord-KG'),
(526, 60, 536, 'Twin Piece', '', 'uploads/TwinPiece-Level1_277658514.png', 'VP', 'Y', 0, '2017-09-25 00:00:00', 0, '2017-09-25 05:02:34', 'TwinPiece-KG'),
(527, 61, 537, 'Star Light', '', 'uploads/StarLight-KG1_6201227623.png', 'FA', 'Y', 0, '2017-09-25 00:00:00', 0, '2017-09-25 05:02:34', 'StarLight-KG'),
(528, 61, 538, 'Stranger Grid', '', 'uploads/StrangerGrid_9728514011.png.png', 'FA', 'Y', 0, '2017-09-25 00:00:00', 0, '2017-09-25 05:02:34', 'StrangerGrid-KG'),
(529, 61, 539, 'Who Reaches Out', '', 'uploads/WhoReachesOut-Level1_8087662272.png', 'FA', 'Y', 0, '2017-09-25 00:00:00', 0, '2017-09-25 05:02:34', 'WhoReachesOut-KG'),
(530, 61, 540, 'Alpha Focus', '', 'uploads/AlphaFocus-Level1_7799442643.png', 'FA', 'Y', 0, '2017-09-25 00:00:00', 0, '2017-09-25 05:02:34', 'AlphaFocus-KG'),
(531, 61, 541, 'Arrow Hit', '', 'uploads/ArrowHit-Level1_2562350165.png', 'FA', 'Y', 0, '2017-09-25 00:00:00', 0, '2017-09-25 05:02:34', 'ArrowHit-KG'),
(532, 61, 542, 'Do We Differ', '', 'uploads/DoWeDiffer-Level1_9961162102.png', 'FA', 'Y', 0, '2017-09-25 00:00:00', 0, '2017-09-25 05:02:34', 'DoWeDiffer-KG'),
(533, 61, 543, 'Path Trace', '', 'uploads/PathTrace-Level1_9113778676.png', 'FA', 'Y', 0, '2017-09-25 00:00:00', 0, '2017-09-25 05:02:34', 'PathTrace-KG'),
(534, 61, 544, 'Odd Alpha Number', '', 'uploads/WeirdAlphaNumber-Level1_4951013289.png', 'FA', 'Y', 0, '2017-09-25 00:00:00', 0, '2017-09-25 05:02:34', 'OddAlphaNumber-KG'),
(535, 62, 545, 'Symmetry Or Not', '', 'uploads/SymmetryOrNot-Level1_535150892.png', 'PS', 'Y', 0, '2017-09-25 00:00:00', 0, '2017-09-25 05:02:34', 'SymmetryOrNot-KG'),
(536, 62, 546, 'What Comes Next', '', 'uploads/WhatComesNext-Level1_3932243706.png', 'PS', 'Y', 0, '2017-09-25 00:00:00', 0, '2017-09-25 05:02:34', 'WhatComesNext-KG'),
(537, 62, 547, 'Compare Contest', '', 'uploads/CompareContest-Level1_1414912887.png', 'PS', 'Y', 0, '2017-09-25 00:00:00', 0, '2017-09-25 05:02:34', 'CompareContest-KG'),
(538, 62, 548, 'Make A Pattern', '', 'uploads/MakeAPattern-Level1_374257480.png', 'PS', 'Y', 0, '2017-09-25 00:00:00', 0, '2017-09-25 05:02:34', 'MakeAPattern-KG'),
(539, 62, 549, 'Image Sequence', '', 'uploads/ImageSequence-Level1_1271936539.png', 'PS', 'Y', 0, '2017-09-25 00:00:00', 0, '2017-09-25 05:02:34', 'ImageSequence-KG'),
(540, 62, 550, 'Pattern Representation', '', 'uploads/PatternRepresentation-Level1_7518243058.png', 'PS', 'Y', 0, '2017-09-25 00:00:00', 0, '2017-09-25 05:02:34', 'PatternRepresentation-KG'),
(541, 62, 551, 'Pattern For A Pattern', '', 'uploads/PatternForAPattern-Level1_5394952590.png', 'PS', 'Y', 0, '2017-09-25 00:00:00', 0, '2017-09-25 05:02:34', 'PatternForAPattern-KG'),
(542, 62, 552, 'Group It', '', 'uploads/GroupIt-Level1_2434460278.png', 'PS', 'Y', 0, '2017-09-25 00:00:00', 0, '2017-09-25 05:02:34', 'GroupIt-KG'),
(543, 63, 553, 'Missing in Middle', '', 'uploads/MissingInMiddle_5156854209.png', 'L', 'Y', 0, '2017-09-25 00:00:00', 0, '2017-09-25 05:02:34', 'MissingInMiddle-KG'),
(544, 63, 554, 'Absent In Alphabet', '', 'uploads/AbsentAlphabet_5964533849.png', 'L', 'Y', 0, '2017-09-25 00:00:00', 0, '2017-09-25 05:02:34', 'AbsentInAlphabet-KG'),
(545, 63, 555, 'Letter Picture Pair', '', 'uploads/AlphabetPicturePair_441006175.png', 'L', 'Y', 0, '2017-09-25 00:00:00', 0, '2017-09-25 05:02:34', 'LetterPicturePair-KG'),
(546, 63, 556, 'Who Starts With Me', '', 'uploads/WhoStartsWithMe_9145371927.png', 'L', 'Y', 0, '2017-09-25 00:00:00', 0, '2017-09-25 05:02:34', 'WhoStartsWithMe-KG'),
(547, 63, 557, 'Spell It', '', 'uploads/SpellIt-Level1_4972556773.png', 'L', 'Y', 0, '2017-09-25 00:00:00', 0, '2017-09-25 05:02:34', 'SpellIt-KG'),
(548, 63, 558, 'Letter Search', '', 'uploads/AlphabetSearch_1266466071.png', 'L', 'Y', 0, '2017-09-25 00:00:00', 0, '2017-09-25 05:02:34', 'LetterSearch-KG'),
(549, 63, 559, 'Letter Start', '', 'uploads/AlphabetStart_6351753645.png', 'L', 'Y', 0, '2017-09-25 00:00:00', 0, '2017-09-25 05:02:34', 'LetterStart-KG'),
(550, 63, 560, 'Letter Cases', '', 'uploads/LetterCases_8069400168.png', 'L', 'Y', 0, '2017-09-25 00:00:00', 0, '2017-09-25 05:02:34', 'LetterCases-KG'),
(551, 59, 561, 'Fruit Drop', '', 'uploads/FruitDrop-Level1_5968954963.png', 'M', 'Y', 0, '2017-09-25 00:00:00', 0, '2017-09-25 05:02:34', 'FruitDrop-Level1'),
(552, 59, 562, 'Animal Recall', '', 'uploads/AnimalRecall-Level1_5902908118.png', 'M', 'Y', 0, '2017-09-25 00:00:00', 0, '2017-09-25 05:02:34', 'AnimalRecall-Level1'),
(553, 59, 563, 'Smiley Series', '', 'uploads/SmileySeries-Level1_3376116408.png', 'M', 'Y', 0, '2017-09-25 00:00:00', 0, '2017-09-25 05:02:34', 'SmileySeries-Level1'),
(554, 59, 564, 'Jack In The Box', '', 'uploads/JackInTheBox-Level1_8967085247.png', 'M', 'Y', 0, '2017-09-25 00:00:00', 0, '2017-09-25 05:02:34', 'JackInTheBox-Level1'),
(555, 59, 565, 'Number Scramble', '', 'uploads/NumberScramble_5994973969.png', 'M', 'Y', 0, '2017-09-25 00:00:00', 0, '2017-09-25 05:02:34', 'NumberScramble'),
(556, 59, 566, 'Locate The Parts', '', 'uploads/LocateTheParts-Level1_9876082488.png', 'M', 'Y', 0, '2017-09-25 00:00:00', 0, '2017-09-25 05:02:34', 'LocateTheParts-Level1'),
(557, 59, 567, 'Buddy Spot', '', 'uploads/BuddySpot-Level1_4558774498.png', 'M', 'Y', 0, '2017-09-25 00:00:00', 0, '2017-09-25 05:02:34', 'BuddySpot-Level1'),
(558, 59, 568, 'Add On', '', 'uploads/AddOn-Level1_29916255.png', 'M', 'Y', 0, '2017-09-25 00:00:00', 0, '2017-09-25 05:02:34', 'AddOn-Level1'),
(559, 60, 569, 'Icon Match', '', 'uploads/IconMatch-Level1_4288190002.png', 'VP', 'Y', 0, '2017-09-25 00:00:00', 0, '2017-09-25 05:02:34', 'IconMatch-Level1'),
(560, 60, 570, 'Who Hits', '', 'uploads/WhoHits-Level1_1098579633.png', 'VP', 'Y', 0, '2017-09-25 00:00:00', 0, '2017-09-25 05:02:34', 'WhoHits-Level1'),
(561, 60, 571, 'Best Fit', '', 'uploads/BestFit-KG1_6883309637.png', 'VP', 'Y', 0, '2017-09-25 00:00:00', 0, '2017-09-25 05:02:34', 'BestFit-Level1'),
(562, 60, 572, 'Earring Match', '', 'uploads/EarringMatch-Level1_9153384454.png', 'VP', 'Y', 0, '2017-09-25 00:00:00', 0, '2017-09-25 05:02:34', 'EarringMatch-Level1'),
(563, 60, 573, 'Face Cut', '', 'uploads/FaceCut-Level1_7893398585.png', 'VP', 'Y', 0, '2017-09-25 00:00:00', 0, '2017-09-25 05:02:34', 'FaceCut-Level1'),
(564, 60, 574, 'Lost Last Part', '', 'uploads/LostLastPart-Level1_6288307351.png', 'VP', 'Y', 0, '2017-09-25 00:00:00', 0, '2017-09-25 05:02:34', 'LostLastPart-Level1'),
(565, 60, 575, 'Mystery Word', '', 'uploads/MysteryWord-Level1_4597698734.png', 'VP', 'Y', 0, '2017-09-25 00:00:00', 0, '2017-09-25 05:02:34', 'MysteryWord-Level1'),
(566, 60, 576, 'Twin Piece', '', 'uploads/TwinPiece-Level1_277658514.png', 'VP', 'Y', 0, '2017-09-25 00:00:00', 0, '2017-09-25 05:02:34', 'TwinPiece-Level1'),
(567, 61, 577, 'Star Light', '', 'uploads/StarLight-KG1_6201227623.png', 'FA', 'Y', 0, '2017-09-25 00:00:00', 0, '2017-09-25 05:02:34', 'StarLight-Level1'),
(568, 61, 578, 'Stranger Grid', '', 'uploads/StrangerGrid_9728514011.png.png', 'FA', 'Y', 0, '2017-09-25 00:00:00', 0, '2017-09-25 05:02:34', 'StrangerGrid-Level1'),
(569, 61, 579, 'Who Reaches Out', '', 'uploads/WhoReachesOut-Level1_8087662272.png', 'FA', 'Y', 0, '2017-09-25 00:00:00', 0, '2017-09-25 05:02:34', 'WhoReachesOut-Level1'),
(570, 61, 580, 'Alpha Focus', '', 'uploads/AlphaFocus-Level1_7799442643.png', 'FA', 'Y', 0, '2017-09-25 00:00:00', 0, '2017-09-25 05:02:34', 'AlphaFocus-Level1'),
(571, 61, 581, 'Arrow Hit', '', 'uploads/ArrowHit-Level1_2562350165.png', 'FA', 'Y', 0, '2017-09-25 00:00:00', 0, '2017-09-25 05:02:34', 'ArrowHit-Level1'),
(572, 61, 582, 'Do We Differ', '', 'uploads/DoWeDiffer-Level1_9961162102.png', 'FA', 'Y', 0, '2017-09-25 00:00:00', 0, '2017-09-25 05:02:34', 'DoWeDiffer-Level1'),
(573, 61, 583, 'Path Trace', '', 'uploads/PathTrace-Level1_9113778676.png', 'FA', 'Y', 0, '2017-09-25 00:00:00', 0, '2017-09-25 05:02:34', 'PathTrace-Level1'),
(574, 61, 584, 'Odd Alpha Number', '', 'uploads/WeirdAlphaNumber-Level1_4951013289.png', 'FA', 'Y', 0, '2017-09-25 00:00:00', 0, '2017-09-25 05:02:34', 'OddAlphaNumber-Level1'),
(575, 62, 585, 'Symmetry Or Not', '', 'uploads/SymmetryOrNot-Level1_535150892.png', 'PS', 'Y', 0, '2017-09-25 00:00:00', 0, '2017-09-25 05:02:34', 'SymmetryOrNot-Level1'),
(576, 62, 586, 'What Comes Next', '', 'uploads/WhatComesNext-Level1_3932243706.png', 'PS', 'Y', 0, '2017-09-25 00:00:00', 0, '2017-09-25 05:02:34', 'WhatComesNext-Level1'),
(577, 62, 587, 'Compare Contest', '', 'uploads/CompareContest-Level1_1414912887.png', 'PS', 'Y', 0, '2017-09-25 00:00:00', 0, '2017-09-25 05:02:34', 'CompareContest-Level1'),
(578, 62, 588, 'Make A Pattern', '', 'uploads/MakeAPattern-Level1_374257480.png', 'PS', 'Y', 0, '2017-09-25 00:00:00', 0, '2017-09-25 05:02:34', 'MakeAPattern-Level1'),
(579, 62, 589, 'Image Sequence', '', 'uploads/ImageSequence-Level1_1271936539.png', 'PS', 'Y', 0, '2017-09-25 00:00:00', 0, '2017-09-25 05:02:34', 'ImageSequence-Level1'),
(580, 62, 590, 'Pattern Representation', '', 'uploads/PatternRepresentation-Level1_7518243058.png', 'PS', 'Y', 0, '2017-09-25 00:00:00', 0, '2017-09-25 05:02:34', 'PatternRepresentation-Level1'),
(581, 62, 591, 'Pattern For A Pattern', '', 'uploads/PatternForAPattern-Level1_5394952590.png', 'PS', 'Y', 0, '2017-09-25 00:00:00', 0, '2017-09-25 05:02:34', 'PatternForAPattern-Level1'),
(582, 62, 592, 'Group It', '', 'uploads/GroupIt-Level1_2434460278.png', 'PS', 'Y', 0, '2017-09-25 00:00:00', 0, '2017-09-25 05:02:34', 'GroupIt-Level1'),
(583, 63, 593, 'Missing in Middle', '', 'uploads/MissingInMiddle_5156854209.png', 'L', 'Y', 0, '2017-09-25 00:00:00', 0, '2017-09-25 05:02:34', 'MissingInMiddle'),
(584, 63, 594, 'Absent In Alphabet', '', 'uploads/AbsentAlphabet_5964533849.png', 'L', 'Y', 0, '2017-09-25 00:00:00', 0, '2017-09-25 05:02:34', 'AbsentInAlphabet'),
(585, 63, 595, 'Letter Picture Pair', '', 'uploads/AlphabetPicturePair_441006175.png', 'L', 'Y', 0, '2017-09-25 00:00:00', 0, '2017-09-25 05:02:34', 'LetterPicturePair'),
(586, 63, 596, 'Who Starts With Me', '', 'uploads/WhoStartsWithMe_9145371927.png', 'L', 'Y', 0, '2017-09-25 00:00:00', 0, '2017-09-25 05:02:34', 'WhoStartsWithMe'),
(587, 63, 597, 'Spell It', '', 'uploads/SpellIt-Level1_4972556773.png', 'L', 'Y', 0, '2017-09-25 00:00:00', 0, '2017-09-25 05:02:34', 'SpellIt-Level1'),
(588, 63, 598, 'Letter Search', '', 'uploads/AlphabetSearch_1266466071.png', 'L', 'Y', 0, '2017-09-25 00:00:00', 0, '2017-09-25 05:02:34', 'LetterSearch'),
(589, 63, 599, 'Letter Start', '', 'uploads/AlphabetStart_6351753645.png', 'L', 'Y', 0, '2017-09-25 00:00:00', 0, '2017-09-25 05:02:34', 'LetterStart'),
(590, 63, 600, 'Letter Cases', '', 'uploads/LetterCases_8069400168.png', 'L', 'Y', 0, '2017-09-25 00:00:00', 0, '2017-09-25 05:02:34', 'LetterCases'),
(591, 59, 601, 'Smiley Series', '', 'uploads/SmileySeries-Level2.png', 'M', 'Y', 0, '2017-09-25 00:00:00', 0, '2017-09-25 05:02:34', 'SmileySeries-Level2'),
(592, 59, 602, 'Add On', '', 'uploads/AddOn-Level2.png', 'M', 'Y', 0, '2017-09-25 00:00:00', 0, '2017-09-25 05:02:34', 'AddOn-Level2'),
(593, 59, 603, 'Fruit Drop', '', 'uploads/FruitDrop-Level2.png', 'M', 'Y', 0, '2017-09-25 00:00:00', 0, '2017-09-25 05:02:34', 'FruitDrop-Level2'),
(594, 59, 604, 'Locate the Parts', '', 'uploads/LocateTheParts-Level2.png', 'M', 'Y', 0, '2017-09-25 00:00:00', 0, '2017-09-25 05:02:34', 'LocateTheParts-Level2'),
(595, 59, 605, 'Buddy Spot', '', 'uploads/BuddySpot-Level2.png', 'M', 'Y', 0, '2017-09-25 00:00:00', 0, '2017-09-25 05:02:34', 'BuddySpot-Level2'),
(596, 59, 606, 'Alpha Number Scramble', '', 'uploads/AlphaNumberScramble.png', 'M', 'Y', 0, '2017-09-25 00:00:00', 0, '2017-09-25 05:02:34', 'AlphaNumberScramble'),
(597, 59, 607, 'Animal Recall', '', 'uploads/AnimalRecall-Level2.png', 'M', 'Y', 0, '2017-09-25 00:00:00', 0, '2017-09-25 05:02:34', 'AnimalRecall-Level2'),
(598, 59, 608, 'Jack in the Box', '', 'uploads/JackInTheBox-Level2.png', 'M', 'Y', 0, '2017-09-25 00:00:00', 0, '2017-09-25 05:02:34', 'JackInTheBox-Level2'),
(599, 60, 609, 'Who Hits', '', 'uploads/WhoHits-Level2.png', 'VP', 'Y', 0, '2017-09-25 00:00:00', 0, '2017-09-25 05:02:34', 'WhoHits-Level2'),
(600, 60, 610, 'Twin Piece', '', 'uploads/TwinPiece-Level2.png', 'VP', 'Y', 0, '2017-09-25 00:00:00', 0, '2017-09-25 05:02:34', 'TwinPiece-Level2'),
(601, 60, 611, 'EarRing Match', '', 'uploads/EarringMatch-Level2.png', 'VP', 'Y', 0, '2017-09-25 00:00:00', 0, '2017-09-25 05:02:34', 'EarringMatch-Level2'),
(602, 60, 612, 'Best Fit', '', 'uploads/BestFit-Level2.png', 'VP', 'Y', 0, '2017-09-25 00:00:00', 0, '2017-09-25 05:02:34', 'BestFit-Level2'),
(603, 60, 613, 'Icon Match', '', 'uploads/IconMatch-Level2.png', 'VP', 'Y', 0, '2017-09-25 00:00:00', 0, '2017-09-25 05:02:34', 'IconMatch-Level2'),
(604, 60, 614, 'Lost Last Part', '', 'uploads/LostLastPart-Level2.png', 'VP', 'Y', 0, '2017-09-25 00:00:00', 0, '2017-09-25 05:02:34', 'LostLastPart-Level2'),
(605, 60, 615, 'Face Cut', '', 'uploads/FaceCut-Level2.png', 'VP', 'Y', 0, '2017-09-25 00:00:00', 0, '2017-09-25 05:02:34', 'FaceCut-Level2'),
(606, 60, 616, 'Mystery Word', '', 'uploads/MysteryWord-Level2.png', 'VP', 'Y', 0, '2017-09-25 00:00:00', 0, '2017-09-25 05:02:34', 'MysteryWord-Level2'),
(607, 61, 617, 'Star Light', '', 'uploads/StarLight-Level2.png', 'FA', 'Y', 0, '2017-09-25 00:00:00', 0, '2017-09-25 05:02:34', 'StarLight-Level2'),
(608, 61, 618, 'Do We Differ', '', 'uploads/DoWeDiffer-Level2.png', 'FA', 'Y', 0, '2017-09-25 00:00:00', 0, '2017-09-25 05:02:34', 'DoWeDiffer-Level2'),
(609, 61, 619, 'Stranger Grid', '', 'uploads/StrangerGrid-Level2.png', 'FA', 'Y', 0, '2017-09-25 00:00:00', 0, '2017-09-25 05:02:34', 'StrangerGrid-Level2'),
(610, 61, 620, 'Path Trace', '', 'uploads/PathTrace-Level2.png', 'FA', 'Y', 0, '2017-09-25 00:00:00', 0, '2017-09-25 05:02:34', 'PathTrace-Level2'),
(611, 61, 621, 'Who Reaches Out', '', 'uploads/WhoReachesOut-Level2.png', 'FA', 'Y', 0, '2017-09-25 00:00:00', 0, '2017-09-25 05:02:34', 'WhoReachesOut-Level2'),
(612, 61, 622, 'Alpha Focus', '', 'uploads/AlphaFocus-Level2.png', 'FA', 'Y', 0, '2017-09-25 00:00:00', 0, '2017-09-25 05:02:34', 'AlphaFocus-Level2'),
(613, 61, 623, 'Arrow Hit', '', 'uploads/ArrowHit-Level2.png', 'FA', 'Y', 0, '2017-09-25 00:00:00', 0, '2017-09-25 05:02:34', 'ArrowHit-Level2'),
(614, 61, 624, 'Odd Alpha Number', '', 'uploads/WeirdAlphaNumber-Level2.png', 'FA', 'Y', 0, '2017-09-25 00:00:00', 0, '2017-09-25 05:02:34', 'OddAlphaNumber-Level2');
INSERT INTO `sk_games` (`ID`, `skill_ID`, `game_masterID`, `name`, `swf_path`, `image_path`, `description`, `status`, `created_by`, `created_date`, `modified_by`, `modified_date`, `game_html`) VALUES
(615, 62, 625, 'Who Joins the Group', '', 'uploads/WhoJoinsTheGroup.png', 'PS', 'Y', 0, '2017-09-25 00:00:00', 0, '2017-09-25 05:02:34', 'WhoJoinsTheGroup'),
(616, 62, 626, 'Image Sequence', '', 'uploads/ImageSequence-Level2.png', 'PS', 'Y', 0, '2017-09-25 00:00:00', 0, '2017-09-25 05:02:34', 'ImageSequence-Level2'),
(617, 62, 627, 'Pattern For A Pattern', '', 'uploads/PatternForAPattern-Level2.png', 'PS', 'Y', 0, '2017-09-25 00:00:00', 0, '2017-09-25 05:02:34', 'PatternForAPattern-Level2'),
(618, 62, 628, 'Pattern Representation', '', 'uploads/PatternRepresentation-Level2.png', 'PS', 'Y', 0, '2017-09-25 00:00:00', 0, '2017-09-25 05:02:34', 'PatternRepresentation-Level2'),
(619, 62, 629, 'Group It', '', 'uploads/GroupIt-Level2.png', 'PS', 'Y', 0, '2017-09-25 00:00:00', 0, '2017-09-25 05:02:34', 'GroupIt-Level2'),
(620, 62, 630, 'Make a Pattern', '', 'uploads/MakeAPattern-Level2.png', 'PS', 'Y', 0, '2017-09-25 00:00:00', 0, '2017-09-25 05:02:34', 'MakeAPattern-Level2'),
(621, 62, 631, 'Symmetry or Not', '', 'uploads/SymmetryOrNot-Level2.png', 'PS', 'Y', 0, '2017-09-25 00:00:00', 0, '2017-09-25 05:02:34', 'SymmetryOrNot-Level2'),
(622, 62, 632, 'Compare Contest', '', 'uploads/CompareContest-Level2.png', 'PS', 'Y', 0, '2017-09-25 00:00:00', 0, '2017-09-25 05:02:34', 'CompareContest-Level2'),
(623, 63, 633, 'Letter Order', '', 'uploads/AlphabetOrder.png', 'L', 'Y', 0, '2017-09-25 00:00:00', 0, '2017-09-25 05:02:34', 'LetterOrder'),
(624, 63, 634, 'Articles', '', 'uploads/Articles.png', 'L', 'Y', 0, '2017-09-25 00:00:00', 0, '2017-09-25 05:02:34', 'Articles'),
(625, 63, 635, 'Missing Vowel', '', 'uploads/MissingVowel.png', 'L', 'Y', 0, '2017-09-25 00:00:00', 0, '2017-09-25 05:02:34', 'MissingVowel'),
(626, 63, 636, 'In and On', '', 'uploads/InAndOn.png', 'L', 'Y', 0, '2017-09-25 00:00:00', 0, '2017-09-25 05:02:34', 'InAndOn'),
(627, 63, 637, 'Form the Word', '', 'uploads/FormTheWord.png', 'L', 'Y', 0, '2017-09-25 00:00:00', 0, '2017-09-25 05:02:34', 'FormTheWord'),
(628, 63, 638, 'Spell It', '', 'uploads/SpellIt-Level2.png', 'L', 'Y', 0, '2017-09-25 00:00:00', 0, '2017-09-25 05:02:34', 'SpellIt-Level2'),
(629, 63, 639, 'Rhyming Words', '', 'uploads/RhymingWords.png', 'L', 'Y', 0, '2017-09-25 00:00:00', 0, '2017-09-25 05:02:34', 'RhymingWords'),
(630, 63, 640, 'Word Building', '', 'uploads/WordBuilding.png', 'L', 'Y', 0, '2017-09-25 00:00:00', 0, '2017-09-25 05:02:34', 'WordBuilding');

-- --------------------------------------------------------

--
-- Table structure for table `sk_gamescore`
--

CREATE TABLE `sk_gamescore` (
  `id` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `gameid` int(11) NOT NULL,
  `skillid` int(11) NOT NULL,
  `gc_id` int(11) NOT NULL,
  `gp_id` int(11) NOT NULL,
  `iteration` int(11) NOT NULL,
  `quesionid` int(11) NOT NULL,
  `timervalue` int(11) NOT NULL,
  `responsetime` int(11) NOT NULL,
  `answerstatus` enum('C','W','U') NOT NULL,
  `correctanswer` varchar(100) NOT NULL,
  `useranswer` varchar(100) NOT NULL,
  `score` int(11) NOT NULL,
  `updateddate` datetime NOT NULL,
  `status` enum('0','1') NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `sk_games_plan`
--

CREATE TABLE `sk_games_plan` (
  `ID` int(11) NOT NULL,
  `school_ID` int(11) NOT NULL,
  `plan_ID` int(11) NOT NULL,
  `sk_game_ID` int(11) NOT NULL,
  `times_count` int(11) NOT NULL COMMENT 'Number of times a game can be played'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sk_games_plan`
--

INSERT INTO `sk_games_plan` (`ID`, `school_ID`, `plan_ID`, `sk_game_ID`, `times_count`) VALUES
(1, 2, 1, 1, 5),
(2, 2, 1, 2, 5),
(3, 2, 1, 3, 5),
(4, 2, 1, 4, 5),
(5, 2, 1, 5, 5),
(6, 2, 1, 6, 5),
(7, 2, 1, 7, 5),
(8, 2, 1, 8, 5),
(9, 2, 1, 9, 5),
(10, 2, 1, 10, 5),
(11, 2, 1, 11, 5),
(12, 2, 1, 12, 5),
(13, 2, 1, 13, 5),
(14, 2, 1, 14, 5),
(15, 2, 1, 15, 5),
(16, 2, 1, 16, 5),
(17, 2, 1, 17, 5),
(18, 2, 1, 18, 5),
(19, 2, 1, 19, 5),
(20, 2, 1, 20, 5),
(21, 2, 1, 21, 5),
(22, 2, 1, 22, 5),
(23, 2, 1, 23, 5),
(24, 2, 1, 24, 5),
(25, 2, 1, 25, 5),
(26, 2, 1, 26, 5),
(27, 2, 1, 27, 5),
(28, 2, 1, 28, 5),
(29, 2, 1, 29, 5),
(30, 2, 1, 30, 5),
(31, 2, 1, 31, 5),
(32, 2, 1, 32, 5),
(33, 2, 1, 33, 5),
(34, 2, 1, 34, 5),
(35, 2, 1, 35, 5),
(36, 2, 1, 36, 5),
(37, 2, 1, 37, 5),
(38, 2, 1, 38, 5),
(39, 2, 1, 39, 5),
(40, 2, 2, 40, 5),
(41, 2, 2, 41, 5),
(42, 2, 2, 42, 5),
(43, 2, 2, 43, 5),
(44, 2, 2, 44, 5),
(45, 2, 2, 45, 5),
(46, 2, 2, 46, 5),
(47, 2, 2, 47, 5),
(48, 2, 2, 48, 5),
(49, 2, 2, 49, 5),
(50, 2, 2, 50, 5),
(51, 2, 2, 51, 5),
(52, 2, 2, 52, 5),
(53, 2, 2, 53, 5),
(54, 2, 2, 54, 5),
(55, 2, 2, 55, 5),
(56, 2, 2, 56, 5),
(57, 2, 2, 57, 5),
(58, 2, 2, 58, 5),
(59, 2, 2, 59, 5),
(60, 2, 2, 60, 5),
(61, 2, 2, 61, 5),
(62, 2, 2, 62, 5),
(63, 2, 2, 63, 5),
(64, 2, 2, 64, 5),
(65, 2, 2, 65, 5),
(66, 2, 2, 66, 5),
(67, 2, 2, 67, 5),
(68, 2, 2, 68, 5),
(69, 2, 2, 69, 5),
(70, 2, 2, 70, 5),
(71, 2, 2, 71, 5),
(72, 2, 2, 72, 5),
(73, 2, 2, 73, 5),
(74, 2, 2, 74, 5),
(75, 2, 2, 75, 5),
(76, 2, 2, 76, 5),
(77, 2, 2, 77, 5),
(78, 2, 2, 78, 5),
(79, 2, 2, 79, 5),
(80, 2, 3, 80, 5),
(81, 2, 3, 81, 5),
(82, 2, 3, 82, 5),
(83, 2, 3, 83, 5),
(84, 2, 3, 84, 5),
(85, 2, 3, 85, 5),
(86, 2, 3, 86, 5),
(87, 2, 3, 87, 5),
(88, 2, 3, 88, 5),
(89, 2, 3, 89, 5),
(90, 2, 3, 90, 5),
(91, 2, 3, 91, 5),
(92, 2, 3, 92, 5),
(93, 2, 3, 93, 5),
(94, 2, 3, 94, 5),
(95, 2, 3, 95, 5),
(96, 2, 3, 96, 5),
(97, 2, 3, 97, 5),
(98, 2, 3, 98, 5),
(99, 2, 3, 99, 5),
(100, 2, 3, 100, 5),
(101, 2, 3, 101, 5),
(102, 2, 3, 102, 5),
(103, 2, 3, 103, 5),
(104, 2, 3, 104, 5),
(105, 2, 3, 105, 5),
(106, 2, 3, 106, 5),
(107, 2, 3, 107, 5),
(108, 2, 3, 108, 5),
(109, 2, 3, 109, 5),
(110, 2, 3, 110, 5),
(111, 2, 3, 111, 5),
(112, 2, 3, 112, 5),
(113, 2, 3, 113, 5),
(114, 2, 3, 114, 5),
(115, 2, 3, 115, 5),
(116, 2, 3, 116, 5),
(117, 2, 3, 117, 5),
(118, 2, 3, 118, 5),
(119, 2, 3, 119, 5),
(120, 2, 4, 120, 5),
(121, 2, 4, 121, 5),
(122, 2, 4, 122, 5),
(123, 2, 4, 123, 5),
(124, 2, 4, 124, 5),
(125, 2, 4, 125, 5),
(126, 2, 4, 126, 5),
(127, 2, 4, 127, 5),
(128, 2, 4, 128, 5),
(129, 2, 4, 129, 5),
(130, 2, 4, 130, 5),
(131, 2, 4, 131, 5),
(132, 2, 4, 132, 5),
(133, 2, 4, 133, 5),
(134, 2, 4, 134, 5),
(135, 2, 4, 135, 5),
(136, 2, 4, 136, 5),
(137, 2, 4, 137, 5),
(138, 2, 4, 138, 5),
(139, 2, 4, 139, 5),
(140, 2, 4, 140, 5),
(141, 2, 4, 141, 5),
(142, 2, 4, 142, 5),
(143, 2, 4, 143, 5),
(144, 2, 4, 144, 5),
(145, 2, 4, 145, 5),
(146, 2, 4, 146, 5),
(147, 2, 4, 147, 5),
(148, 2, 4, 148, 5),
(149, 2, 4, 149, 5),
(150, 2, 4, 150, 5),
(151, 2, 4, 151, 5),
(152, 2, 4, 152, 5),
(153, 2, 4, 153, 5),
(154, 2, 4, 154, 5),
(155, 2, 4, 155, 5),
(156, 2, 4, 156, 5),
(157, 2, 4, 157, 5),
(158, 2, 4, 158, 5),
(159, 2, 4, 159, 5),
(160, 2, 5, 160, 5),
(161, 2, 5, 161, 5),
(162, 2, 5, 162, 5),
(163, 2, 5, 163, 5),
(164, 2, 5, 164, 5),
(165, 2, 5, 165, 5),
(166, 2, 5, 166, 5),
(167, 2, 5, 167, 5),
(168, 2, 5, 168, 5),
(169, 2, 5, 169, 5),
(170, 2, 5, 170, 5),
(171, 2, 5, 171, 5),
(172, 2, 5, 172, 5),
(173, 2, 5, 173, 5),
(174, 2, 5, 174, 5),
(175, 2, 5, 175, 5),
(176, 2, 5, 176, 5),
(177, 2, 5, 177, 5),
(178, 2, 5, 178, 5),
(179, 2, 5, 179, 5),
(180, 2, 5, 180, 5),
(181, 2, 5, 181, 5),
(182, 2, 5, 182, 5),
(183, 2, 5, 183, 5),
(184, 2, 5, 184, 5),
(185, 2, 5, 185, 5),
(186, 2, 5, 186, 5),
(187, 2, 5, 187, 5),
(188, 2, 5, 188, 5),
(189, 2, 5, 189, 5),
(190, 2, 5, 190, 5),
(191, 2, 5, 191, 5),
(192, 2, 5, 192, 5),
(193, 2, 5, 193, 5),
(194, 2, 5, 194, 5),
(195, 2, 5, 195, 5),
(196, 2, 5, 196, 5),
(197, 2, 5, 197, 5),
(198, 2, 5, 198, 5),
(199, 2, 5, 199, 5),
(200, 2, 6, 200, 5),
(201, 2, 6, 201, 5),
(202, 2, 6, 202, 5),
(203, 2, 6, 203, 5),
(204, 2, 6, 204, 5),
(205, 2, 6, 205, 5),
(206, 2, 6, 206, 5),
(207, 2, 6, 207, 5),
(208, 2, 6, 208, 5),
(209, 2, 6, 209, 5),
(210, 2, 6, 210, 5),
(211, 2, 6, 211, 5),
(212, 2, 6, 212, 5),
(213, 2, 6, 213, 5),
(214, 2, 6, 214, 5),
(215, 2, 6, 215, 5),
(216, 2, 6, 216, 5),
(217, 2, 6, 217, 5),
(218, 2, 6, 218, 5),
(219, 2, 6, 219, 5),
(220, 2, 6, 220, 5),
(221, 2, 6, 221, 5),
(222, 2, 6, 222, 5),
(223, 2, 6, 223, 5),
(224, 2, 6, 224, 5),
(225, 2, 6, 225, 5),
(226, 2, 6, 226, 5),
(227, 2, 6, 227, 5),
(228, 2, 6, 228, 5),
(229, 2, 6, 229, 5),
(230, 2, 6, 230, 5),
(231, 2, 6, 231, 5),
(232, 2, 6, 232, 5),
(233, 2, 6, 233, 5),
(234, 2, 6, 234, 5),
(235, 2, 6, 235, 5),
(236, 2, 6, 236, 5),
(237, 2, 6, 237, 5),
(238, 2, 6, 238, 5),
(239, 2, 6, 239, 5),
(240, 2, 7, 240, 5),
(241, 2, 7, 241, 5),
(242, 2, 7, 242, 5),
(243, 2, 7, 243, 5),
(244, 2, 7, 244, 5),
(245, 2, 7, 245, 5),
(246, 2, 7, 246, 5),
(247, 2, 7, 247, 5),
(248, 2, 7, 248, 5),
(249, 2, 7, 249, 5),
(250, 2, 7, 250, 5),
(251, 2, 7, 251, 5),
(252, 2, 7, 252, 5),
(253, 2, 7, 253, 5),
(254, 2, 7, 254, 5),
(255, 2, 7, 255, 5),
(256, 2, 7, 256, 5),
(257, 2, 7, 257, 5),
(258, 2, 7, 258, 5),
(259, 2, 7, 259, 5),
(260, 2, 7, 260, 5),
(261, 2, 7, 261, 5),
(262, 2, 7, 262, 5),
(263, 2, 7, 263, 5),
(264, 2, 7, 264, 5),
(265, 2, 7, 265, 5),
(266, 2, 7, 266, 5),
(267, 2, 7, 267, 5),
(268, 2, 7, 268, 5),
(269, 2, 7, 269, 5),
(270, 2, 7, 270, 5),
(271, 2, 7, 271, 5),
(272, 2, 7, 272, 5),
(273, 2, 7, 273, 5),
(274, 2, 7, 274, 5),
(275, 2, 7, 275, 5),
(276, 2, 7, 276, 5),
(277, 2, 7, 277, 5),
(278, 2, 7, 278, 5),
(279, 2, 7, 279, 5),
(280, 2, 8, 280, 5),
(281, 2, 8, 281, 5),
(282, 2, 8, 282, 5),
(283, 2, 8, 283, 5),
(284, 2, 8, 284, 5),
(285, 2, 8, 285, 5),
(286, 2, 8, 286, 5),
(287, 2, 8, 287, 5),
(288, 2, 8, 288, 5),
(289, 2, 8, 289, 5),
(290, 2, 8, 290, 5),
(291, 2, 8, 291, 5),
(292, 2, 8, 292, 5),
(293, 2, 8, 293, 5),
(294, 2, 8, 294, 5),
(295, 2, 8, 295, 5),
(296, 2, 8, 296, 5),
(297, 2, 8, 297, 5),
(298, 2, 8, 298, 5),
(299, 2, 8, 299, 5),
(300, 2, 8, 300, 5),
(301, 2, 8, 301, 5),
(302, 2, 8, 302, 5),
(303, 2, 8, 303, 5),
(304, 2, 8, 304, 5),
(305, 2, 8, 305, 5),
(306, 2, 8, 306, 5),
(307, 2, 8, 307, 5),
(308, 2, 8, 308, 5),
(309, 2, 8, 309, 5),
(310, 2, 8, 310, 5),
(311, 2, 8, 311, 5),
(312, 2, 8, 312, 5),
(313, 2, 8, 313, 5),
(314, 2, 8, 314, 5),
(315, 2, 8, 315, 5),
(316, 2, 8, 316, 5),
(317, 2, 8, 317, 5),
(318, 2, 8, 318, 5),
(319, 2, 8, 319, 5),
(2369, 2, 1, 510, 5),
(2370, 2, 91, 511, 5),
(2371, 2, 91, 512, 5),
(2372, 2, 91, 513, 5),
(2373, 2, 91, 514, 5),
(2374, 2, 91, 515, 5),
(2375, 2, 91, 516, 5),
(2376, 2, 91, 517, 5),
(2377, 2, 91, 518, 5),
(2378, 2, 91, 519, 5),
(2379, 2, 91, 520, 5),
(2380, 2, 91, 521, 5),
(2381, 2, 91, 522, 5),
(2382, 2, 91, 523, 5),
(2383, 2, 91, 524, 5),
(2384, 2, 91, 525, 5),
(2385, 2, 91, 526, 5),
(2386, 2, 91, 527, 5),
(2387, 2, 91, 528, 5),
(2388, 2, 91, 529, 5),
(2389, 2, 91, 530, 5),
(2390, 2, 91, 531, 5),
(2391, 2, 91, 532, 5),
(2392, 2, 91, 533, 5),
(2393, 2, 91, 534, 5),
(2394, 2, 91, 535, 5),
(2395, 2, 91, 536, 5),
(2396, 2, 91, 537, 5),
(2397, 2, 91, 538, 5),
(2398, 2, 91, 539, 5),
(2399, 2, 91, 540, 5),
(2400, 2, 91, 541, 5),
(2401, 2, 91, 542, 5),
(2402, 2, 91, 543, 5),
(2403, 2, 91, 544, 5),
(2404, 2, 91, 545, 5),
(2405, 2, 91, 546, 5),
(2406, 2, 91, 547, 5),
(2407, 2, 91, 548, 5),
(2408, 2, 91, 549, 5),
(2409, 2, 91, 550, 5),
(2410, 2, 10, 551, 5),
(2411, 2, 10, 552, 5),
(2412, 2, 10, 553, 5),
(2413, 2, 10, 554, 5),
(2414, 2, 10, 555, 5),
(2415, 2, 10, 556, 5),
(2416, 2, 10, 557, 5),
(2417, 2, 10, 558, 5),
(2418, 2, 10, 559, 5),
(2419, 2, 10, 560, 5),
(2420, 2, 10, 561, 5),
(2421, 2, 10, 562, 5),
(2422, 2, 10, 563, 5),
(2423, 2, 10, 564, 5),
(2424, 2, 10, 565, 5),
(2425, 2, 10, 566, 5),
(2426, 2, 10, 567, 5),
(2427, 2, 10, 568, 5),
(2428, 2, 10, 569, 5),
(2429, 2, 10, 570, 5),
(2430, 2, 10, 571, 5),
(2431, 2, 10, 572, 5),
(2432, 2, 10, 573, 5),
(2433, 2, 10, 574, 5),
(2434, 2, 10, 575, 5),
(2435, 2, 10, 576, 5),
(2436, 2, 10, 577, 5),
(2437, 2, 10, 578, 5),
(2438, 2, 10, 579, 5),
(2439, 2, 10, 580, 5),
(2440, 2, 10, 581, 5),
(2441, 2, 10, 582, 5),
(2442, 2, 10, 583, 5),
(2443, 2, 10, 584, 5),
(2444, 2, 10, 585, 5),
(2445, 2, 10, 586, 5),
(2446, 2, 10, 587, 5),
(2447, 2, 10, 588, 5),
(2448, 2, 10, 589, 5),
(2449, 2, 10, 590, 5),
(2450, 2, 11, 591, 5),
(2451, 2, 11, 592, 5),
(2452, 2, 11, 593, 5),
(2453, 2, 11, 594, 5),
(2454, 2, 11, 595, 5),
(2455, 2, 11, 596, 5),
(2456, 2, 11, 597, 5),
(2457, 2, 11, 598, 5),
(2458, 2, 11, 599, 5),
(2459, 2, 11, 600, 5),
(2460, 2, 11, 601, 5),
(2461, 2, 11, 602, 5),
(2462, 2, 11, 603, 5),
(2463, 2, 11, 604, 5),
(2464, 2, 11, 605, 5),
(2465, 2, 11, 606, 5),
(2466, 2, 11, 607, 5),
(2467, 2, 11, 608, 5),
(2468, 2, 11, 609, 5),
(2469, 2, 11, 610, 5),
(2470, 2, 11, 611, 5),
(2471, 2, 11, 612, 5),
(2472, 2, 11, 613, 5),
(2473, 2, 11, 614, 5),
(2474, 2, 11, 615, 5),
(2475, 2, 11, 616, 5),
(2476, 2, 11, 617, 5),
(2477, 2, 11, 618, 5),
(2478, 2, 11, 619, 5),
(2479, 2, 11, 620, 5),
(2480, 2, 11, 621, 5),
(2481, 2, 11, 622, 5),
(2482, 2, 11, 623, 5),
(2483, 2, 11, 624, 5),
(2484, 2, 11, 625, 5),
(2485, 2, 11, 626, 5),
(2486, 2, 11, 627, 5),
(2487, 2, 11, 628, 5),
(2488, 2, 11, 629, 5),
(2489, 2, 11, 630, 5);

-- --------------------------------------------------------

--
-- Stand-in structure for view `sk_game_reports`
-- (See below for the actual view)
--
CREATE TABLE `sk_game_reports` (
`id` int(11)
,`gu_id` int(10)
,`gp_id` int(100)
,`gc_id` int(10)
,`gs_id` int(10)
,`g_id` int(30)
,`total_question` varchar(15)
,`attempt_question` varchar(20)
,`answer` varchar(20)
,`game_score` varchar(50)
,`gtime` varchar(100)
,`rtime` varchar(100)
,`crtime` varchar(100)
,`wrtime` varchar(100)
,`lastupdate` date
);

-- --------------------------------------------------------

--
-- Table structure for table `sk_personalized_game`
--

CREATE TABLE `sk_personalized_game` (
  `ID` int(11) NOT NULL,
  `sk_planSkillCountID` int(11) NOT NULL,
  `skillID` int(11) NOT NULL,
  `from_GradeID` int(11) NOT NULL COMMENT 'from plan_id',
  `level` int(11) NOT NULL,
  `gameCount` int(11) NOT NULL COMMENT 'Number of games per skill'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sk_personalized_game`
--

INSERT INTO `sk_personalized_game` (`ID`, `sk_planSkillCountID`, `skillID`, `from_GradeID`, `level`, `gameCount`) VALUES
(1, 1, 59, 11, 1, 1),
(2, 2, 59, 1, 1, 1),
(3, 3, 59, 2, 1, 1),
(4, 4, 59, 3, 1, 1),
(5, 5, 59, 4, 1, 1),
(6, 6, 59, 5, 1, 1),
(7, 7, 59, 6, 1, 1),
(8, 8, 59, 7, 1, 1),
(9, 9, 59, 91, 1, 1),
(10, 10, 59, 10, 1, 1),
(11, 11, 59, 91, 1, 1),
(12, 1, 59, 10, 2, 1),
(13, 2, 59, 11, 2, 1),
(14, 3, 59, 1, 2, 1),
(15, 4, 59, 2, 2, 1),
(16, 5, 59, 3, 2, 1),
(17, 6, 59, 4, 2, 1),
(18, 7, 59, 5, 2, 1),
(19, 8, 59, 6, 2, 1),
(20, 9, 59, 91, 2, 1),
(21, 10, 59, 91, 2, 1),
(22, 11, 59, 91, 2, 1),
(27, 1, 60, 11, 1, 1),
(28, 2, 60, 1, 1, 1),
(29, 3, 60, 2, 1, 1),
(30, 4, 60, 3, 1, 1),
(31, 5, 60, 4, 1, 1),
(32, 6, 60, 5, 1, 1),
(33, 7, 60, 6, 1, 1),
(34, 8, 60, 7, 1, 1),
(35, 9, 60, 91, 1, 1),
(36, 10, 60, 10, 1, 1),
(37, 11, 60, 91, 1, 1),
(38, 1, 60, 10, 2, 1),
(39, 2, 60, 11, 2, 1),
(40, 3, 60, 1, 2, 1),
(41, 4, 60, 2, 2, 1),
(42, 5, 60, 3, 2, 1),
(43, 6, 60, 4, 2, 1),
(44, 7, 60, 5, 2, 1),
(45, 8, 60, 6, 2, 1),
(46, 9, 60, 91, 2, 1),
(47, 10, 60, 91, 2, 1),
(48, 11, 60, 91, 2, 1),
(58, 1, 61, 11, 1, 1),
(59, 2, 61, 1, 1, 1),
(60, 3, 61, 2, 1, 1),
(61, 4, 61, 3, 1, 1),
(62, 5, 61, 4, 1, 1),
(63, 6, 61, 5, 1, 1),
(64, 7, 61, 6, 1, 1),
(65, 8, 61, 7, 1, 1),
(66, 9, 61, 91, 1, 1),
(67, 10, 61, 10, 1, 1),
(68, 11, 61, 91, 1, 1),
(69, 1, 61, 10, 2, 1),
(70, 2, 61, 11, 2, 1),
(71, 3, 61, 1, 2, 1),
(72, 4, 61, 2, 2, 1),
(73, 5, 61, 3, 2, 1),
(74, 6, 61, 4, 2, 1),
(75, 7, 61, 5, 2, 1),
(76, 8, 61, 6, 2, 1),
(77, 9, 61, 91, 2, 1),
(78, 10, 61, 91, 2, 1),
(79, 11, 61, 91, 2, 1),
(89, 1, 62, 11, 1, 1),
(90, 2, 62, 1, 1, 1),
(91, 3, 62, 2, 1, 1),
(92, 4, 62, 3, 1, 1),
(93, 5, 62, 4, 1, 1),
(94, 6, 62, 5, 1, 1),
(95, 7, 62, 6, 1, 1),
(96, 8, 62, 7, 1, 1),
(97, 9, 62, 91, 1, 1),
(98, 10, 62, 10, 1, 1),
(99, 11, 62, 91, 1, 1),
(100, 1, 62, 10, 2, 1),
(101, 2, 62, 11, 2, 1),
(102, 3, 62, 1, 2, 1),
(103, 4, 62, 2, 2, 1),
(104, 5, 62, 3, 2, 1),
(105, 6, 62, 4, 2, 1),
(106, 7, 62, 5, 2, 1),
(107, 8, 62, 6, 2, 1),
(108, 9, 62, 91, 2, 1),
(109, 10, 62, 91, 2, 1),
(110, 11, 62, 91, 2, 1),
(120, 1, 63, 11, 1, 1),
(121, 2, 63, 1, 1, 1),
(122, 3, 63, 2, 1, 1),
(123, 4, 63, 3, 1, 1),
(124, 5, 63, 4, 1, 1),
(125, 6, 63, 5, 1, 1),
(126, 7, 63, 6, 1, 1),
(127, 8, 63, 7, 1, 1),
(128, 9, 63, 91, 1, 1),
(129, 10, 63, 10, 1, 1),
(130, 11, 63, 91, 1, 1),
(131, 1, 63, 10, 2, 1),
(132, 2, 63, 11, 2, 1),
(133, 3, 63, 1, 2, 1),
(134, 4, 63, 2, 2, 1),
(135, 5, 63, 3, 2, 1),
(136, 6, 63, 4, 2, 1),
(137, 7, 63, 5, 2, 1),
(138, 8, 63, 6, 2, 1),
(139, 9, 63, 91, 2, 1),
(140, 10, 63, 91, 2, 1),
(141, 11, 63, 91, 2, 1);

-- --------------------------------------------------------

--
-- Table structure for table `sk_plan_skillcount`
--

CREATE TABLE `sk_plan_skillcount` (
  `ID` int(11) NOT NULL,
  `school_ID` int(11) NOT NULL,
  `plan_ID` int(11) NOT NULL,
  `skill_count` int(11) NOT NULL COMMENT 'Number of skills taken for Personalized games'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sk_plan_skillcount`
--

INSERT INTO `sk_plan_skillcount` (`ID`, `school_ID`, `plan_ID`, `skill_count`) VALUES
(1, 2, 1, 1),
(2, 2, 2, 1),
(3, 2, 3, 1),
(4, 2, 4, 1),
(5, 2, 5, 1),
(6, 2, 6, 1),
(7, 2, 7, 1),
(8, 2, 8, 1),
(9, 2, 10, 1),
(10, 2, 11, 1),
(11, 2, 91, 1);

-- --------------------------------------------------------

--
-- Table structure for table `sk_rand_selection`
--

CREATE TABLE `sk_rand_selection` (
  `id` int(11) NOT NULL,
  `gc_id` int(11) DEFAULT NULL,
  `gs_id` int(11) DEFAULT NULL,
  `gid` int(11) DEFAULT NULL,
  `gp_id` int(11) DEFAULT NULL,
  `grade_id` int(11) DEFAULT NULL,
  `section` varchar(10) DEFAULT NULL,
  `school_id` int(11) DEFAULT NULL,
  `userID` int(11) NOT NULL,
  `created_date` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `sk_user_game_list`
--

CREATE TABLE `sk_user_game_list` (
  `ID` int(11) NOT NULL,
  `userID` int(11) NOT NULL,
  `planID` int(11) NOT NULL,
  `SessionID` int(11) NOT NULL COMMENT 'represents game play iteration',
  `weakSkills` varchar(100) NOT NULL COMMENT 'list of weak games of iteration delimited by comma',
  `levelid` varchar(55) NOT NULL DEFAULT '0',
  `status` int(11) NOT NULL,
  `created_date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sk_user_game_list`
--

INSERT INTO `sk_user_game_list` (`ID`, `userID`, `planID`, `SessionID`, `weakSkills`, `levelid`, `status`, `created_date`) VALUES
(1, 1, 91, 7, '61', '2', 0, '2018-01-06 00:00:00'),
(2, 59, 1, 1, '', '', 1, '2018-02-13 00:00:00'),
(3, 67, 6, 1, '', '', 1, '2018-02-13 00:00:00'),
(4, 58, 8, 1, '63', '2', 1, '2018-02-13 00:00:00'),
(5, 57, 3, 1, '', '', 1, '2018-02-13 00:00:00'),
(6, 41, 8, 1, '', '', 1, '2018-02-13 00:00:00'),
(7, 42, 4, 1, '', '', 1, '2018-02-13 00:00:00'),
(8, 68, 2, 1, '', '', 1, '2018-02-14 00:00:00'),
(9, 40, 1, 1, '60', '1', 0, '2018-02-14 00:00:00'),
(10, 67, 6, 1, '', '', 1, '2018-02-14 00:00:00'),
(11, 39, 8, 1, '', '', 0, '2018-02-14 00:00:00'),
(12, 56, 8, 1, '', '', 1, '2018-02-15 00:00:00'),
(13, 69, 8, 1, '63', '1', 0, '2018-02-19 00:00:00'),
(14, 58, 8, 2, '', '', 1, '2018-02-20 00:00:00'),
(15, 58, 8, 2, '', '', 0, '2018-02-21 00:00:00'),
(16, 59, 1, 2, '62', '2', 0, '2018-02-21 00:00:00'),
(17, 67, 6, 2, '62', '2', 1, '2018-02-21 00:00:00'),
(18, 42, 4, 2, '61', '2', 0, '2018-02-21 00:00:00'),
(19, 67, 6, 2, '62', '2', 0, '2018-02-22 00:00:00'),
(20, 68, 2, 2, '', '', 0, '2018-02-22 00:00:00'),
(21, 57, 3, 2, '', '', 0, '2018-02-22 00:00:00'),
(22, 41, 8, 2, '', '', 0, '2018-02-22 00:00:00'),
(23, 56, 8, 2, '', '', 0, '2018-02-25 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `sparkiesmaster`
--

CREATE TABLE `sparkiesmaster` (
  `ID` int(11) NOT NULL,
  `Scenario` varchar(255) NOT NULL,
  `Code` varchar(55) NOT NULL,
  `Type` enum('REGULAR','BONUS') NOT NULL,
  `Points` int(11) NOT NULL,
  `Status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sparkiesmaster`
--

INSERT INTO `sparkiesmaster` (`ID`, `Scenario`, `Code`, `Type`, `Points`, `Status`) VALUES
(1, 'Attempting one question', 'ONE_Q', 'REGULAR', 1, 1),
(2, 'Completion of all questions', 'ALL_Q', 'REGULAR', 1, 1),
(3, 'Number of times of play of a game', 'NOTPOAG', 'REGULAR', 5, 1),
(4, 'First login of scheduled school days', 'FLOSSD', 'REGULAR', 1, 1),
(5, 'First login from Home', 'FLFH', 'REGULAR', 5, 1),
(6, 'If completed game score got score above 60 out of 100', 'ABOVE_60', 'REGULAR', 5, 1),
(7, 'Attempting one question correct', '1QC', 'BONUS', 2, 1),
(8, 'Completion of all 10 questions correct', '10QC', 'BONUS', 10, 1),
(9, 'If all five times gets played', 'ALL5TGP', 'BONUS', 10, 1),
(10, 'First login of scheduled school days between 6 PM to 6 AM', '6T6', 'BONUS', 5, 1),
(11, 'First login of weekends (Saturday and sunday)', 'WEEKEND', 'BONUS', 10, 1),
(12, 'All days played on current month', 'ALLDAY', 'BONUS', 10, 1);

-- --------------------------------------------------------

--
-- Table structure for table `state`
--

CREATE TABLE `state` (
  `id` int(11) NOT NULL,
  `state_name` varchar(255) NOT NULL,
  `countryid` int(11) NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `state`
--

INSERT INTO `state` (`id`, `state_name`, `countryid`, `status`) VALUES
(1, 'Andaman & Nicobar Islands', 113, 1),
(2, 'Andhra Pradesh', 113, 1),
(3, 'Arunachal Pradesh', 113, 1),
(4, 'Assam', 113, 1),
(5, 'Bihar', 113, 1),
(6, 'Chandigarh', 113, 1),
(7, 'Chhattisgarh', 113, 1),
(8, 'Dadra & Nagar Haveli', 113, 1),
(9, 'Daman & Diu', 113, 1),
(10, 'Delhi', 113, 1),
(11, 'Goa', 113, 1),
(12, 'Gujarat', 113, 1),
(13, 'Haryana', 113, 1),
(14, 'Himachal Pradesh', 113, 1),
(15, 'Jammu & Kashmir', 113, 1),
(16, 'Jharkhand', 113, 1),
(17, 'Karnataka', 113, 1),
(18, 'Kerala', 113, 1),
(19, 'Lakshadweep', 113, 1),
(20, 'Madhya Pradesh', 113, 1),
(21, 'Maharashtra', 113, 1),
(22, 'Manipur', 113, 1),
(23, 'Meghalaya', 113, 1),
(24, 'Mizoram', 113, 1),
(25, 'Nagaland', 113, 1),
(26, 'Odisha', 113, 1),
(27, 'Puducherry', 113, 1),
(28, 'Punjab', 113, 1),
(29, 'Rajasthan', 113, 1),
(30, 'Sikkim', 113, 1),
(31, 'Tamil Nadu', 113, 1),
(32, 'Tripura', 113, 1),
(34, 'Uttar Pradesh', 113, 1),
(35, 'Uttarakhand', 113, 1),
(36, 'West Bengal', 113, 1);

-- --------------------------------------------------------

--
-- Stand-in structure for view `superangel`
-- (See below for the actual view)
--
CREATE TABLE `superangel` (
`ans` double
,`gu_id` int(10)
,`monthName` varchar(32)
,`monthNumber` varchar(2)
,`monofyear` int(4)
,`gs_ID` varchar(100)
,`grad_ID` bigint(11)
);

-- --------------------------------------------------------

--
-- Table structure for table `table 107`
--

CREATE TABLE `table 107` (
  `COL 1` varchar(6) DEFAULT NULL,
  `COL 2` varchar(5) DEFAULT NULL,
  `COL 3` varchar(5) DEFAULT NULL,
  `COL 4` varchar(5) DEFAULT NULL,
  `COL 5` varchar(5) DEFAULT NULL,
  `COL 6` varchar(4) DEFAULT NULL,
  `COL 7` varchar(14) DEFAULT NULL,
  `COL 8` varchar(16) DEFAULT NULL,
  `COL 9` varchar(6) DEFAULT NULL,
  `COL 10` varchar(10) DEFAULT NULL,
  `COL 11` varchar(5) DEFAULT NULL,
  `COL 12` varchar(5) DEFAULT NULL,
  `COL 13` varchar(6) DEFAULT NULL,
  `COL 14` varchar(6) DEFAULT NULL,
  `COL 15` varchar(10) DEFAULT NULL,
  `COL 16` varchar(9) DEFAULT NULL,
  `COL 17` varchar(13) DEFAULT NULL,
  `COL 18` varchar(10) DEFAULT NULL,
  `COL 19` varchar(13) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `table 107`
--

INSERT INTO `table 107` (`COL 1`, `COL 2`, `COL 3`, `COL 4`, `COL 5`, `COL 6`, `COL 7`, `COL 8`, `COL 9`, `COL 10`, `COL 11`, `COL 12`, `COL 13`, `COL 14`, `COL 15`, `COL 16`, `COL 17`, `COL 18`, `COL 19`) VALUES
('id', 'gu_id', 'gc_id', 'gs_id', 'gp_id', 'g_id', 'total_question', 'attempt_question', 'answer', 'game_score', 'gtime', 'rtime', 'crtime', 'wrtime', 'Lastupdate', 'createdby', 'creation_date', 'modifiedby', 'modified_date'),
('191941', '363', '1', '59', '1', '1', '10', '10', '8', '45', '150', '26', '0', '0', '2017-03-08', '', '0000-00-00', '', '2016-06-08'),
('191942', '363', '1', '59', '1', '2', '10', '10', '6', '54', '153', '26', '0', '0', '2017-03-15', '', '0000-00-00', '', '2016-06-15'),
('191943', '363', '1', '59', '1', '3', '10', '10', '8', '50', '169', '52', '0', '0', '2017-03-22', '', '0000-00-00', '', '2016-06-22'),
('191944', '363', '1', '59', '1', '4', '10', '10', '8', '55', '160', '38', '0', '0', '2017-03-29', '', '0000-00-00', '', '2016-06-29'),
('191945', '363', '1', '59', '1', '5', '10', '10', '8', '23', '160', '38', '0', '0', '2017-03-06', '', '0000-00-00', '', '2016-07-06'),
('191946', '363', '1', '59', '1', '6', '10', '10', '10', '55', '45', '25', '25', '0', '2017-03-13', '', '0000-00-00', '', '2016-07-13'),
('191947', '363', '1', '59', '1', '7', '10', '10', '9', '47', '46', '27', '24', '3', '2017-03-20', '', '0000-00-00', '', '2016-07-20'),
('191948', '363', '1', '59', '1', '8', '10', '10', '8', '29', '40', '21', '16', '5', '2017-03-27', '', '0000-00-00', '', '2016-07-27'),
('191949', '363', '1', '60', '1', '9', '10', '10', '8', '56', '42', '22', '17', '5', '2017-03-08', '', '0000-00-00', '', '2016-06-08'),
('191950', '363', '1', '60', '1', '10', '10', '10', '10', '40', '40', '22', '22', '0', '2017-03-15', '', '0000-00-00', '', '2016-06-15'),
('191951', '363', '1', '60', '1', '11', '10', '10', '0', '29', '225', '58', '0', '58', '2017-03-22', '', '0000-00-00', '', '2016-06-22'),
('191952', '363', '1', '60', '1', '12', '10', '10', '6', '40', '86', '41', '27', '14', '2017-03-29', '', '0000-00-00', '', '2016-06-29'),
('191953', '363', '1', '60', '1', '15', '10', '10', '9', '39', '127', '110', '0', '0', '2017-03-06', '', '0000-00-00', '', '2016-07-06'),
('191954', '363', '1', '60', '1', '16', '10', '10', '10', '48', '140', '41', '41', '0', '2017-03-13', '', '0000-00-00', '', '2016-07-13'),
('191955', '363', '1', '60', '1', '17', '10', '10', '10', '43', '132', '36', '36', '0', '2017-03-20', '', '0000-00-00', '', '2016-07-20'),
('191956', '363', '1', '60', '1', '18', '10', '10', '10', '67', '147', '50', '50', '0', '2017-03-27', '', '0000-00-00', '', '2016-07-27'),
('191957', '363', '1', '61', '1', '19', '10', '10', '10', '37', '147', '50', '50', '0', '2017-03-08', '', '0000-00-00', '', '2016-06-08'),
('191958', '363', '1', '61', '1', '20', '10', '10', '10', '40', '147', '50', '50', '0', '2017-03-15', '', '0000-00-00', '', '2016-06-15'),
('191959', '363', '1', '61', '1', '21', '10', '10', '10', '50', '35', '14', '14', '0', '2017-03-22', '', '0000-00-00', '', '2016-06-22'),
('191960', '363', '1', '61', '1', '22', '10', '10', '10', '36', '35', '14', '14', '0', '2017-03-29', '', '0000-00-00', '', '2016-06-29'),
('191961', '363', '1', '61', '1', '23', '10', '10', '10', '55', '35', '14', '14', '0', '2017-03-06', '', '0000-00-00', '', '2016-07-06'),
('191962', '363', '1', '61', '1', '24', '10', '10', '10', '34', '35', '14', '14', '0', '2017-03-13', '', '0000-00-00', '', '2016-07-13'),
('191963', '363', '1', '61', '1', '25', '10', '10', '10', '40', '35', '14', '14', '0', '2017-03-20', '', '0000-00-00', '', '2016-07-20'),
('191964', '363', '1', '61', '1', '26', '10', '10', '8', '54', '125', '111', '0', '0', '2017-03-27', '', '0000-00-00', '', '2016-07-27'),
('191965', '363', '1', '62', '1', '27', '10', '10', '9', '40', '141', '125', '0', '0', '2017-03-08', '', '0000-00-00', '', '2016-06-08'),
('191966', '363', '1', '62', '1', '28', '10', '10', '9', '34', '141', '125', '0', '0', '2017-03-15', '', '0000-00-00', '', '2016-06-15'),
('191967', '363', '1', '62', '1', '29', '10', '10', '9', '39', '118', '104', '0', '0', '2017-03-22', '', '0000-00-00', '', '2016-06-22'),
('191968', '363', '1', '62', '1', '30', '10', '10', '9', '50', '118', '104', '0', '0', '2017-03-29', '', '0000-00-00', '', '2016-06-29'),
('191969', '363', '1', '62', '1', '31', '10', '10', '10', '42', '92', '76', '76', '0', '2017-03-06', '', '0000-00-00', '', '2016-07-06'),
('191970', '363', '1', '62', '1', '32', '10', '10', '10', '39', '92', '76', '76', '0', '2017-03-13', '', '0000-00-00', '', '2016-07-13'),
('191971', '363', '1', '62', '1', '33', '10', '10', '10', '54', '89', '74', '74', '0', '2017-03-20', '', '0000-00-00', '', '2016-07-20'),
('191972', '363', '1', '62', '1', '34', '10', '10', '10', '63', '72', '56', '56', '0', '2017-03-27', '', '0000-00-00', '', '2016-07-27'),
('191973', '363', '1', '63', '1', '35', '10', '10', '10', '39', '80', '64', '64', '0', '2017-03-08', '', '0000-00-00', '', '2016-06-08'),
('191974', '363', '1', '63', '1', '36', '10', '10', '5', '35', '108', '93', '0', '0', '2017-03-15', '', '0000-00-00', '', '2016-06-15'),
('191975', '363', '1', '63', '1', '37', '10', '10', '5', '23', '108', '93', '0', '0', '2017-03-22', '', '0000-00-00', '', '2016-06-22'),
('191976', '363', '1', '63', '1', '38', '10', '10', '5', '40', '108', '93', '0', '0', '2017-03-29', '', '0000-00-00', '', '2016-06-29'),
('191977', '363', '1', '63', '1', '39', '10', '10', '5', '50', '106', '88', '0', '0', '2017-03-06', '', '0000-00-00', '', '2016-07-06'),
('191978', '363', '1', '63', '1', '40', '10', '10', '5', '47', '106', '88', '0', '0', '2017-03-13', '', '0000-00-00', '', '2016-07-13'),
('191979', '363', '1', '63', '1', '41', '10', '10', '8', '23', '60', '29', '0', '0', '2017-03-20', '', '0000-00-00', '', '2016-07-20'),
('191980', '363', '1', '63', '1', '42', '10', '9', '3', '12', '180', '153', '0', '0', '2017-03-27', '', '0000-00-00', '', '2016-07-27');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_feedback`
--

CREATE TABLE `tbl_feedback` (
  `feedbackid` int(10) NOT NULL,
  `uid` int(11) NOT NULL,
  `gid` int(11) NOT NULL,
  `rating` int(11) NOT NULL,
  `modifieddate` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_payment`
--

CREATE TABLE `tbl_payment` (
  `ID` int(11) NOT NULL,
  `Subscribed_userid` varchar(255) NOT NULL,
  `Tracking_id` varchar(255) NOT NULL,
  `Amount` decimal(10,2) NOT NULL,
  `Billing_name` varchar(255) NOT NULL,
  `Billing_tel` varchar(16) NOT NULL,
  `Billing_email` varchar(255) NOT NULL,
  `Billing_address` text NOT NULL,
  `Billing_country` varchar(110) NOT NULL,
  `Billing_state` varchar(110) NOT NULL,
  `Billing_city` varchar(110) NOT NULL,
  `Billing_zip` varchar(16) NOT NULL,
  `Payment_response` mediumtext NOT NULL,
  `AuthDesc` varchar(255) NOT NULL,
  `Check_sum` varchar(255) NOT NULL,
  `Merchant_Param` varchar(255) NOT NULL,
  `Bank_refrence_no` varchar(255) NOT NULL,
  `Nb_order_no` varchar(255) NOT NULL,
  `Card_category` varchar(255) NOT NULL,
  `Bank_name` varchar(255) NOT NULL,
  `BankRespCode` varchar(255) NOT NULL,
  `BankRespMsg` varchar(255) NOT NULL,
  `Payment_status` enum('RS','P','S','F') NOT NULL,
  `Payment_mode` enum('LIVE','TEST') NOT NULL,
  `Created_on` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_payment`
--

INSERT INTO `tbl_payment` (`ID`, `Subscribed_userid`, `Tracking_id`, `Amount`, `Billing_name`, `Billing_tel`, `Billing_email`, `Billing_address`, `Billing_country`, `Billing_state`, `Billing_city`, `Billing_zip`, `Payment_response`, `AuthDesc`, `Check_sum`, `Merchant_Param`, `Bank_refrence_no`, `Nb_order_no`, `Card_category`, `Bank_name`, `BankRespCode`, `BankRespMsg`, `Payment_status`, `Payment_mode`, `Created_on`) VALUES
(1, '2', '', '1.00', '', '', '', '', '', '', '', '', 'S', 'Y', 'true', 'M_sar34980_34980', 'CCAFC1DDT219', 'NETBANKING', 'ICICI Bank', 'scdev_1', 'null', 'null', 'S', 'TEST', '2018-03-13 11:19:47'),
(2, '3', '', '1.00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'RS', 'TEST', '2018-03-13 12:18:23'),
(3, '4', '', '1.00', '', '', '', '', '', '', '', '', 'S', 'Y', 'true', 'M_sar34980_34980', 'scdev_3', 'CCAFC1DDT406', 'NETBANKING', 'ICICI Bank', 'null', 'null', 'S', 'TEST', '2018-03-13 12:33:38'),
(4, '4', '', '1.00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'RS', 'TEST', '2018-03-13 12:51:31'),
(5, '4', '', '1.00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'RS', 'TEST', '2018-03-13 12:52:24'),
(6, '', '', '0.00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'RS', 'TEST', '2018-03-13 12:56:22'),
(7, '', '', '0.00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'RS', 'TEST', '2018-03-13 12:56:33'),
(8, '4', '', '1.00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'RS', 'TEST', '2018-03-13 12:57:58'),
(9, '5', '', '1.00', '', '', '', '', '', '', '', '', 'S', 'Y', 'true', 'M_sar34980_34980', 'scdev_9', 'CCAFC1DDT494', 'NETBANKING', 'ICICI Bank', 'null', 'null', 'S', 'TEST', '2018-03-13 13:04:01'),
(10, '6', '', '1.00', 'Sundar', '9789120543', 'sundarcse2k11@gmail.com', 'Testing', '', 'Tamil', '', '637501', 'S', 'Y', 'true', 'M_sar34980_34980', 'scdev_10', 'CCAFC2DDT613', 'NETBANKING', 'ICICI Bank', 'null', 'null', 'S', 'TEST', '2018-03-13 13:45:05'),
(11, '7', '', '1.00', 'Sundar', '9789120543', 'sundarcse2k11@gmail.com', 'Testing', 'india', 'Tamil', 'Salem', '637501', 'S', 'Y', 'true', 'M_sar34980_34980', 'scdev_11', 'CCAFC1DDT648', 'NETBANKING', 'ICICI Bank', 'null', 'null', 'S', 'TEST', '2018-03-13 13:56:33'),
(12, '20', '', '1.00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'RS', 'TEST', '2018-03-30 10:57:15'),
(13, '21', '', '1.00', 'testing', '9789120543', 'jayapradha@skillangels.com', 'Test', 'india', 'Tamil', 'Salem', '637501', 'S', 'Y', 'true', 'M_sar34980_34980', 'scdev_13', 'CCAFD1DGA467', 'NETBANKING', 'ICICI Bank', 'null', 'null', 'S', 'TEST', '2018-04-02 13:25:16'),
(14, '118', '', '100.00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'RS', 'TEST', '2018-05-08 13:21:56'),
(15, '118', '', '100.00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'RS', 'TEST', '2018-05-08 13:50:14'),
(16, '118', '', '100.00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'RS', 'TEST', '2018-05-08 13:50:37'),
(17, '118', '', '100.00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'RS', 'TEST', '2018-05-08 13:54:34'),
(18, '118', '', '600.00', 'Sundar', '9789120543', 'sundarcse2k14@gmail.com', 'Testing', 'india', 'Tamil', 'Salem', '637501', 'S', 'Y', 'true', 'M_sar34980_34980', 'sc_18', 'CCAFE1EEZ131', 'NETBANKING', 'ICICI Bank', 'null', 'null', 'S', 'TEST', '2018-05-08 14:59:29');

-- --------------------------------------------------------

--
-- Table structure for table `teachers`
--

CREATE TABLE `teachers` (
  `id` int(11) NOT NULL,
  `email` varchar(250) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `fname` varchar(100) NOT NULL,
  `lname` varchar(100) NOT NULL,
  `initial` varchar(5) DEFAULT NULL,
  `dob` date DEFAULT NULL,
  `address` varchar(300) NOT NULL,
  `designation` varchar(100) NOT NULL,
  `qualification` varchar(100) DEFAULT NULL,
  `phoneno` varchar(12) NOT NULL,
  `school_id` int(11) NOT NULL,
  `class_id` int(11) NOT NULL,
  `active` int(11) NOT NULL,
  `status` int(1) NOT NULL,
  `createdby` varchar(100) NOT NULL,
  `creation_date` date NOT NULL,
  `modifiedby` varchar(100) NOT NULL,
  `modified_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `teachers`
--

INSERT INTO `teachers` (`id`, `email`, `username`, `password`, `fname`, `lname`, `initial`, `dob`, `address`, `designation`, `qualification`, `phoneno`, `school_id`, `class_id`, `active`, `status`, `createdby`, `creation_date`, `modifiedby`, `modified_date`) VALUES
(8, 'varun.k@123.com', '', 'e54fd19aeca91a2ef6c1cc5590898a68', 'varun', 'krishnan', NULL, NULL, '', 'B.E', NULL, '99999999999', 7, 0, 1, 0, '', '0000-00-00', '', '2014-08-26 08:16:40'),
(10, 'a@b.com', '', '357a20e8c56e69d6f9734d23ef9517e8', 'Grade6Staff1', 'SecA', NULL, NULL, '', 'XX', NULL, '1234567890', 4, 0, 1, 0, '', '0000-00-00', '', '2014-08-27 22:12:49'),
(11, 'b@c.com', '', 'c9edf70098f8c270a022a29f0a2c876f', 'Grade6Staff2', 'SecD', NULL, NULL, '', 'XXX', NULL, '1234567890', 4, 0, 1, 0, '', '0000-00-00', '', '2014-08-27 22:13:22'),
(12, 'g@g.com', '', 'a5d502e66f116d4bd040613df88e074b', 'Grade3staff1', 'SecC', NULL, NULL, '', 'XXX', NULL, '1234567890', 0, 0, 1, 0, '', '0000-00-00', '', '2014-08-30 04:31:44'),
(14, 'grgstaff1@grg.com', '', '5fcf2b70d342536ef1a6b71c084b59f7', 'staff1', 'grg', NULL, NULL, '', 'a', NULL, '1234567890', 1, 0, 1, 0, '', '0000-00-00', '', '2014-09-12 21:48:10'),
(15, 'grgstaff2@grg.com', '', '57b7ddb4af7c4e19f477d763d79fa748', 'staff2', 'grg', NULL, NULL, '', 'a', NULL, '1234567890', 1, 0, 1, 0, '', '0000-00-00', '', '2014-09-12 21:53:18'),
(16, 'grgstaff3@grg.com', '', 'ebb7c32eb8837690ea62e5b3c799631d', 'staff3', 'grg', NULL, NULL, '', 'aaa', NULL, '1234567890', 1, 0, 1, 0, '', '0000-00-00', '', '2014-09-12 22:13:35');

-- --------------------------------------------------------

--
-- Table structure for table `teacher_class`
--

CREATE TABLE `teacher_class` (
  `id` int(11) NOT NULL,
  `teacher_id` int(11) NOT NULL,
  `school_id` int(11) NOT NULL,
  `class_id` int(11) NOT NULL,
  `section` varchar(100) NOT NULL,
  `status` int(1) NOT NULL,
  `createdby` varchar(100) NOT NULL,
  `creation_date` date NOT NULL,
  `modifiedby` varchar(100) NOT NULL,
  `modified_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `teacher_class`
--

INSERT INTO `teacher_class` (`id`, `teacher_id`, `school_id`, `class_id`, `section`, `status`, `createdby`, `creation_date`, `modifiedby`, `modified_date`) VALUES
(12, 10, 4, 8, 'A', 0, '', '0000-00-00', '', '2014-08-27 22:13:36'),
(13, 11, 4, 8, 'D', 0, '', '0000-00-00', '', '2014-08-27 22:14:28'),
(19, 14, 1, 3, 'A', 0, '', '0000-00-00', '', '2014-09-12 21:48:53'),
(20, 14, 1, 4, 'A', 0, '', '0000-00-00', '', '2014-09-12 21:48:59'),
(21, 14, 1, 5, 'A', 0, '', '0000-00-00', '', '2014-09-12 21:49:05'),
(22, 14, 1, 6, 'A', 0, '', '0000-00-00', '', '2014-09-12 21:49:22'),
(23, 14, 1, 7, 'A', 0, '', '0000-00-00', '', '2014-09-12 21:49:29'),
(24, 14, 1, 8, 'A', 0, '', '0000-00-00', '', '2014-09-12 21:49:37'),
(25, 14, 1, 9, 'A', 0, '', '0000-00-00', '', '2014-09-12 21:49:45'),
(26, 14, 1, 10, 'A', 0, '', '0000-00-00', '', '2014-09-12 21:49:53'),
(27, 15, 1, 3, 'B', 0, '', '0000-00-00', '', '2014-09-12 21:53:47'),
(28, 15, 1, 4, 'B', 0, '', '0000-00-00', '', '2014-09-12 21:53:57'),
(29, 15, 1, 5, 'B', 0, '', '0000-00-00', '', '2014-09-12 21:54:09'),
(30, 15, 1, 6, 'B', 0, '', '0000-00-00', '', '2014-09-12 21:54:29'),
(31, 15, 1, 7, 'B', 0, '', '0000-00-00', '', '2014-09-12 21:54:57'),
(32, 15, 1, 8, 'B', 0, '', '0000-00-00', '', '2014-09-12 21:55:12'),
(33, 15, 1, 9, 'B', 0, '', '0000-00-00', '', '2014-09-12 21:55:24'),
(34, 15, 1, 10, 'B', 0, '', '0000-00-00', '', '2014-09-12 21:55:36'),
(35, 16, 1, 3, 'C', 0, '', '0000-00-00', '', '2014-09-12 22:13:51'),
(36, 16, 1, 4, 'C', 0, '', '0000-00-00', '', '2014-09-12 22:14:01'),
(37, 16, 1, 5, 'C', 0, '', '0000-00-00', '', '2014-09-12 22:14:15'),
(38, 16, 1, 6, 'C', 0, '', '0000-00-00', '', '2014-09-12 22:14:33'),
(39, 16, 1, 7, 'C', 0, '', '0000-00-00', '', '2014-09-12 22:14:43'),
(40, 16, 1, 8, 'C', 0, '', '0000-00-00', '', '2014-09-12 22:14:52'),
(41, 16, 1, 9, 'C', 0, '', '0000-00-00', '', '2014-09-12 22:15:03'),
(42, 16, 1, 10, 'C', 0, '', '0000-00-00', '', '2014-09-12 22:15:13');

-- --------------------------------------------------------

--
-- Table structure for table `thememaster`
--

CREATE TABLE `thememaster` (
  `id` int(11) NOT NULL,
  `theme_name` varchar(40) NOT NULL,
  `theme_file_name` varchar(40) NOT NULL,
  `image_name` varchar(255) NOT NULL,
  `description` varchar(100) NOT NULL,
  `sparky_range` int(11) NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `thememaster`
--

INSERT INTO `thememaster` (`id`, `theme_name`, `theme_file_name`, `image_name`, `description`, `sparky_range`, `status`) VALUES
(1, 'Default Theme', 'styleinner.css', 'default.png', 'Default Theme', 0, 1),
(2, 'Super Theme', 'styleinner_super.css', 'theme1.png', 'Earn 1000 sparkie points to activate theme', 1000, 1),
(3, 'Mega Theme', 'styleinner_super1.css', 'theme2.png', 'Earn 2000 sparkie points to activate theme', 2000, 1),
(4, 'Super Skillangels Theme', 'styleinner_super2.css', 'theme3.png', 'Earn 3000 sparkie points to activate theme', 3000, 1),
(5, 'Super Skillangels Theme', 'styleinner_super3.css', 'theme4.png', 'Earn 4000 sparkie points to activate theme', 4000, 1);

-- --------------------------------------------------------

--
-- Table structure for table `trial`
--

CREATE TABLE `trial` (
  `id` int(100) DEFAULT NULL,
  `fname` varchar(100) DEFAULT NULL,
  `gp_id` int(10) DEFAULT NULL,
  `grade_id` int(10) DEFAULT NULL,
  `username` varchar(100) DEFAULT NULL,
  `sid` varchar(100) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Stand-in structure for view `trophystar`
-- (See below for the actual view)
--
CREATE TABLE `trophystar` (
`gu_id` int(10)
,`id` int(11)
,`name` varchar(50)
,`lastupdate` date
,`ct` double(17,0)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `trophystargreaterthanninty`
-- (See below for the actual view)
--
CREATE TABLE `trophystargreaterthanninty` (
`gu_id` int(10)
,`id` int(11)
,`name` varchar(50)
,`lastupdate` date
,`ct` double(17,0)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `trophystarlessequalninty`
-- (See below for the actual view)
--
CREATE TABLE `trophystarlessequalninty` (
`gu_id` int(10)
,`id` int(11)
,`name` varchar(50)
,`lastupdate` date
,`ct` double(17,0)
);

-- --------------------------------------------------------

--
-- Table structure for table `t_allbspi`
--

CREATE TABLE `t_allbspi` (
  `RowID` int(11) NOT NULL,
  `avgscore` varchar(400) NOT NULL,
  `gs_id` int(11) NOT NULL,
  `gu_id` int(11) NOT NULL,
  `lastupdate` date NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `t_sumbbspi`
--

CREATE TABLE `t_sumbbspi` (
  `RowID` int(11) NOT NULL,
  `avgscore` varchar(400) NOT NULL,
  `gs_id` int(11) NOT NULL,
  `gu_id` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `userbadge_data`
--

CREATE TABLE `userbadge_data` (
  `ID` int(11) NOT NULL,
  `S_ID` int(11) NOT NULL,
  `G_ID` int(11) NOT NULL,
  `MonthNumber` int(11) NOT NULL,
  `Sparkies` text NOT NULL,
  `SuperBrian` text NOT NULL,
  `SuperGoer` text NOT NULL,
  `SuperAngel` text NOT NULL,
  `isexist` int(11) NOT NULL DEFAULT '1',
  `Datetime` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `userbadge_data`
--

INSERT INTO `userbadge_data` (`ID`, `S_ID`, `G_ID`, `MonthNumber`, `Sparkies`, `SuperBrian`, `SuperGoer`, `SuperAngel`, `isexist`, `Datetime`) VALUES
(1, 50, 1, 8, '', '', '', '', 0, '2018-09-14 09:49:47');

-- --------------------------------------------------------

--
-- Table structure for table `userplaytime`
--

CREATE TABLE `userplaytime` (
  `id` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `expiredon` date NOT NULL,
  `expireddatetime` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(100) NOT NULL,
  `subscriberid` int(11) NOT NULL,
  `deviceid` varchar(40) NOT NULL,
  `mtoken` text NOT NULL,
  `rollno` varchar(100) CHARACTER SET latin1 NOT NULL,
  `email` varchar(255) CHARACTER SET latin1 NOT NULL,
  `salt1` varchar(20) CHARACTER SET utf8 NOT NULL,
  `password` varchar(100) CHARACTER SET utf8 NOT NULL,
  `salt2` varchar(20) CHARACTER SET utf8 NOT NULL,
  `fname` varchar(100) CHARACTER SET latin1 NOT NULL,
  `lname` varchar(100) CHARACTER SET latin1 NOT NULL,
  `gender` varchar(100) CHARACTER SET latin1 NOT NULL,
  `mobile` varchar(15) CHARACTER SET latin1 NOT NULL,
  `dob` varchar(100) CHARACTER SET latin1 NOT NULL,
  `status` int(1) DEFAULT NULL,
  `visible` int(1) NOT NULL,
  `gp_id` int(10) NOT NULL,
  `glevel` varchar(100) CHARACTER SET latin1 NOT NULL,
  `grade_id` int(10) NOT NULL,
  `username` varchar(255) CHARACTER SET utf8 NOT NULL,
  `sid` varchar(100) CHARACTER SET latin1 NOT NULL,
  `section` varchar(10) CHARACTER SET latin1 NOT NULL,
  `academicyear` varchar(20) CHARACTER SET latin1 DEFAULT NULL,
  `createdby` varchar(100) CHARACTER SET latin1 NOT NULL,
  `login_count` int(11) NOT NULL DEFAULT '0',
  `login_date` date NOT NULL,
  `pre_logindate` date NOT NULL,
  `creation_date` date NOT NULL,
  `modifiedby` varchar(100) CHARACTER SET latin1 NOT NULL,
  `modified_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `avatarimage` varchar(800) CHARACTER SET latin1 NOT NULL,
  `agreetermsandservice` int(11) NOT NULL,
  `creationkey` varchar(20) NOT NULL,
  `session_id` varchar(255) CHARACTER SET latin1 NOT NULL,
  `parent_session_id` varchar(255) NOT NULL,
  `islogin` int(11) NOT NULL,
  `last_active_datetime` datetime NOT NULL,
  `school_name` varchar(255) NOT NULL,
  `state` int(11) NOT NULL,
  `city` int(11) NOT NULL,
  `pincode` int(11) NOT NULL,
  `org_pwd` varchar(255) NOT NULL,
  `portal_type` enum('B2B','B2C') NOT NULL,
  `startdate` date NOT NULL,
  `enddate` date NOT NULL,
  `org_id` int(11) NOT NULL,
  `otp` varchar(16) NOT NULL,
  `otp_datetime` datetime NOT NULL,
  `sbb_position` enum('0','1') NOT NULL DEFAULT '0' COMMENT '0=> No badge,1 => Have badge',
  `sgb_position` enum('0','1') NOT NULL DEFAULT '0' COMMENT '0=> No badge,1 => Have badge',
  `sab_position` enum('0','1') NOT NULL DEFAULT '0' COMMENT '0=> No badge,1 => Have badge',
  `isdemo` int(11) NOT NULL COMMENT '1=>demouser, 0=>originaluser',
  `parent_id` int(11) NOT NULL,
  `time_limit` int(11) NOT NULL,
  `couponcode` varchar(110) NOT NULL,
  `isbookneed` enum('Y','N') NOT NULL,
  `paymentstatus` enum('P','UP') NOT NULL DEFAULT 'UP',
  `payment_id` varchar(255) NOT NULL,
  `isspecialchild` enum('Y','N') NOT NULL,
  `site_type` enum('APP','WEB') NOT NULL DEFAULT 'APP',
  `puzzle_cycle` int(11) NOT NULL,
  `appversion` varchar(55) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `subscriberid`, `deviceid`, `mtoken`, `rollno`, `email`, `salt1`, `password`, `salt2`, `fname`, `lname`, `gender`, `mobile`, `dob`, `status`, `visible`, `gp_id`, `glevel`, `grade_id`, `username`, `sid`, `section`, `academicyear`, `createdby`, `login_count`, `login_date`, `pre_logindate`, `creation_date`, `modifiedby`, `modified_date`, `avatarimage`, `agreetermsandservice`, `creationkey`, `session_id`, `parent_session_id`, `islogin`, `last_active_datetime`, `school_name`, `state`, `city`, `pincode`, `org_pwd`, `portal_type`, `startdate`, `enddate`, `org_id`, `otp`, `otp_datetime`, `sbb_position`, `sgb_position`, `sab_position`, `isdemo`, `parent_id`, `time_limit`, `couponcode`, `isbookneed`, `paymentstatus`, `payment_id`, `isspecialchild`, `site_type`, `puzzle_cycle`, `appversion`) VALUES
(6864, 0, '', '', '', 'sundar@skillangels.com', '197002447', 'c11b310ced1f5d3faa328e8364df5ac8fcd9f63c', '797797361', 'sandy', '', 'M', '', '', 1, 1, 10, '', 1, 'sandy', '2', 'A', '20', '', 23, '2019-08-07', '2019-08-07', '2018-08-30', '', '2019-08-07 09:56:44', '', 1, '', '68642019080715263615651717964', '', 0, '2019-08-07 09:56:36', '2', 17, 245, 600116, '', 'B2B', '2018-08-30', '2019-08-29', 1, '', '0000-00-00 00:00:00', '0', '0', '0', 0, 2, 1800, 'edsix002', 'N', 'P', '', 'Y', 'WEB', 1, ''),
(6865, 0, '', '', '', 'k1ukg', '197002447', 'c11b310ced1f5d3faa328e8364df5ac8fcd9f63c', '797797361', 'k1 ukg', '', 'M', '', '', 1, 1, 11, '', 2, 'nk1ukg', '2', 'A', '20', '', 7, '2019-08-13', '2019-08-13', '2019-08-07', '', '2019-08-13 06:19:01', '', 1, '', '68652019081311461115656769712', '', 0, '2019-08-13 06:18:13', '2', 17, 245, 600116, '', 'B2B', '2019-08-07', '2020-08-06', 1, '', '0000-00-00 00:00:00', '0', '0', '0', 0, 2, 3599, 'edsix002', 'N', 'P', '', 'Y', 'WEB', 1, ''),
(6866, 0, '', '', '', 'k2ukg', '197002447', 'c11b310ced1f5d3faa328e8364df5ac8fcd9f63c', '797797361', 'k2 ukg', '', 'M', '', '', 1, 1, 11, '', 2, 'nk2ukg', '2', 'A', '20', '', 2, '2019-08-09', '2019-08-09', '2019-08-07', '', '2019-08-09 10:35:18', '', 1, '', '68662019080915543515653462751', '', 1, '2019-08-09 10:26:38', '2', 17, 245, 600116, '', 'B2B', '2019-08-07', '2020-08-06', 1, '', '0000-00-00 00:00:00', '0', '0', '0', 0, 2, 3599, 'edsix002', 'N', 'P', '', 'Y', 'WEB', 1, ''),
(6867, 0, '', '', '', 'k3ukg', '197002447', 'c11b310ced1f5d3faa328e8364df5ac8fcd9f63c', '797797361', 'k3 ukg', '', 'M', '', '', 1, 1, 11, '', 2, 'nk3ukg', '2', 'A', '20', '', 6, '2019-08-19', '2019-08-09', '2019-08-07', '', '2019-08-19 10:19:37', '', 1, '', '68672019081915485715662099370', '', 0, '2019-08-19 10:18:57', '2', 17, 245, 600116, '', 'B2B', '2019-08-07', '2020-08-06', 1, '', '0000-00-00 00:00:00', '0', '0', '0', 0, 2, 3599, 'edsix002', 'N', 'P', '', 'Y', 'WEB', 1, ''),
(6868, 0, '', '', '', 'k4ukg', '197002447', 'c11b310ced1f5d3faa328e8364df5ac8fcd9f63c', '797797361', 'k4 ukg', '', 'M', '', '', 1, 1, 11, '', 2, 'nk4ukg', '2', 'A', '20', '', 1, '2019-08-09', '0000-00-00', '2019-08-07', '', '2019-08-09 10:35:18', '', 1, '', '68682019080913070015653362200', '', 0, '2019-08-09 08:07:04', '2', 17, 245, 600116, '', 'B2B', '2019-08-07', '2020-08-06', 1, '', '0000-00-00 00:00:00', '0', '0', '0', 0, 2, 3599, 'edsix002', 'N', 'P', '', 'Y', 'WEB', 1, ''),
(6869, 0, '', '', '', 'k1lkg', '197002447', 'c11b310ced1f5d3faa328e8364df5ac8fcd9f63c', '797797361', 'k1 lkg', '', 'M', '', '', 1, 1, 10, '', 1, 'nk1lkg', '2', 'A', '20', '', 19, '2019-08-19', '2019-08-14', '2019-08-07', '', '2019-08-19 10:05:04', '', 1, '', '68692019081915342715662090680', '', 0, '2019-08-19 10:04:27', '2', 17, 245, 600116, '', 'B2B', '2019-08-07', '2020-08-06', 1, '', '0000-00-00 00:00:00', '0', '0', '0', 0, 2, 3599, 'edsix002', 'N', 'P', '', 'Y', 'WEB', 1, ''),
(6870, 0, '', '', '', 'k2lkg', '197002447', 'c11b310ced1f5d3faa328e8364df5ac8fcd9f63c', '797797361', 'k2 lkg', '', 'M', '', '', 1, 1, 10, '', 1, 'nk2lkg', '2', 'A', '20', '', 0, '0000-00-00', '0000-00-00', '2019-08-07', '', '2019-08-09 10:35:18', '', 1, '', '', '', 0, '0000-00-00 00:00:00', '2', 17, 245, 600116, '', 'B2B', '2019-08-07', '2020-08-06', 1, '', '0000-00-00 00:00:00', '0', '0', '0', 0, 2, 3599, 'edsix002', 'N', 'P', '', 'Y', 'WEB', 1, ''),
(6871, 0, '', '', '', 'k3lkg', '197002447', 'c11b310ced1f5d3faa328e8364df5ac8fcd9f63c', '797797361', 'k3 lkg', '', 'M', '', '', 1, 1, 10, '', 1, 'nk3lkg', '2', 'A', '20', '', 0, '0000-00-00', '0000-00-00', '2019-08-07', '', '2019-08-09 10:35:18', '', 1, '', '', '', 0, '0000-00-00 00:00:00', '2', 17, 245, 600116, '', 'B2B', '2019-08-07', '2020-08-06', 1, '', '0000-00-00 00:00:00', '0', '0', '0', 0, 2, 3599, 'edsix002', 'N', 'P', '', 'Y', 'WEB', 1, ''),
(6872, 0, '', '', '', 'k4lkg', '197002447', 'c11b310ced1f5d3faa328e8364df5ac8fcd9f63c', '797797361', 'k4 lkg', '', 'M', '', '', 1, 1, 10, '', 1, 'nk4lkg', '2', 'A', '20', '', 0, '0000-00-00', '0000-00-00', '2019-08-07', '', '2019-08-09 10:35:18', '', 1, '', '', '', 0, '0000-00-00 00:00:00', '2', 17, 245, 600116, '', 'B2B', '2019-08-07', '2020-08-06', 1, '', '0000-00-00 00:00:00', '0', '0', '0', 0, 2, 3599, 'edsix002', 'N', 'P', '', 'Y', 'WEB', 1, ''),
(6873, 0, '', '', '', 'k1prekg', '197002447', 'c11b310ced1f5d3faa328e8364df5ac8fcd9f63c', '797797361', 'K1 Prekg', '', 'M', '', '', 1, 1, 91, '', 11, 'nk1prekg', '2', 'A', '20', '', 12, '2019-08-19', '2019-08-13', '2019-08-07', '', '2019-08-19 10:17:26', '', 1, '', '68732019081915471115662098316', '', 0, '2019-08-19 10:17:11', '2', 17, 245, 600116, '', 'B2B', '2019-08-07', '2020-08-06', 1, '', '0000-00-00 00:00:00', '0', '0', '0', 0, 2, 3599, 'edsix002', 'N', 'P', '', 'Y', 'WEB', 1, '1'),
(6874, 0, '', '', '', 'k2prekg', '197002447', 'c11b310ced1f5d3faa328e8364df5ac8fcd9f63c', '797797361', 'K2 Prekg', '', 'M', '', '', 1, 1, 91, '', 11, 'nk2prekg', '2', 'A', '20', '', 0, '0000-00-00', '0000-00-00', '2019-08-07', '', '2019-08-09 10:35:18', '', 1, '', '', '', 0, '0000-00-00 00:00:00', '2', 17, 245, 600116, '', 'B2B', '2019-08-07', '2020-08-06', 1, '', '0000-00-00 00:00:00', '0', '0', '0', 0, 2, 3599, 'edsix002', 'N', 'P', '', 'Y', 'WEB', 1, '1'),
(6875, 0, '', '', '', 'k3prekg', '197002447', 'c11b310ced1f5d3faa328e8364df5ac8fcd9f63c', '797797361', 'K3 Prekg', '', 'M', '', '', 1, 1, 91, '', 11, 'nk3prekg', '2', 'A', '20', '', 0, '0000-00-00', '0000-00-00', '2019-08-07', '', '2019-08-09 10:35:18', '', 1, '', '', '', 0, '0000-00-00 00:00:00', '2', 17, 245, 600116, '', 'B2B', '2019-08-07', '2020-08-06', 1, '', '0000-00-00 00:00:00', '0', '0', '0', 0, 2, 3599, 'edsix002', 'N', 'P', '', 'Y', 'WEB', 1, '1'),
(6876, 0, '', '', '', 'k4prekg', '197002447', 'c11b310ced1f5d3faa328e8364df5ac8fcd9f63c', '797797361', 'K4 Prekg', '', 'M', '', '', 1, 1, 91, '', 11, 'nk4prekg', '2', 'A', '20', '', 0, '0000-00-00', '0000-00-00', '2019-08-07', '', '2019-08-09 10:35:18', '', 1, '', '', '', 0, '0000-00-00 00:00:00', '2', 17, 245, 600116, '', 'B2B', '2019-08-07', '2020-08-06', 1, '', '0000-00-00 00:00:00', '0', '0', '0', 0, 2, 3599, 'edsix002', 'N', 'P', '', 'Y', 'WEB', 1, '1'),
(6877, 0, '', '', '', 'k5prekg', '197002447', 'c11b310ced1f5d3faa328e8364df5ac8fcd9f63c', '797797361', 'K5 Prekg', '', 'M', '', '', 1, 1, 91, '', 11, 'nk5prekg', '2', 'A', '20', '', 0, '0000-00-00', '0000-00-00', '2019-08-07', '', '2019-08-09 10:35:18', '', 1, '', '', '', 0, '0000-00-00 00:00:00', '2', 17, 245, 600116, '', 'B2B', '2019-08-07', '2020-08-06', 1, '', '0000-00-00 00:00:00', '0', '0', '0', 0, 2, 3599, 'edsix002', 'N', 'P', '', 'Y', 'WEB', 1, '1');

-- --------------------------------------------------------

--
-- Table structure for table `userscreenaccess`
--

CREATE TABLE `userscreenaccess` (
  `id` int(11) NOT NULL,
  `menu` varchar(100) NOT NULL,
  `page` varchar(250) NOT NULL,
  `master` varchar(5) NOT NULL,
  `userid` int(11) NOT NULL,
  `createdby` varchar(100) NOT NULL,
  `creation_date` datetime NOT NULL,
  `modifiedby` varchar(100) NOT NULL,
  `modified_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `users_bkp`
--

CREATE TABLE `users_bkp` (
  `id` int(100) NOT NULL,
  `subscriberid` int(11) NOT NULL,
  `deviceid` varchar(40) NOT NULL,
  `mtoken` text NOT NULL,
  `rollno` varchar(100) CHARACTER SET latin1 NOT NULL,
  `email` varchar(255) CHARACTER SET latin1 NOT NULL,
  `salt1` varchar(20) CHARACTER SET utf8 NOT NULL,
  `password` varchar(100) NOT NULL,
  `salt2` varchar(20) CHARACTER SET utf8 NOT NULL,
  `fname` varchar(100) CHARACTER SET latin1 NOT NULL,
  `lname` varchar(100) CHARACTER SET latin1 NOT NULL,
  `gender` varchar(100) CHARACTER SET latin1 NOT NULL,
  `mobile` varchar(15) CHARACTER SET latin1 NOT NULL,
  `dob` varchar(100) CHARACTER SET latin1 NOT NULL,
  `status` int(1) DEFAULT NULL,
  `visible` int(1) NOT NULL,
  `gp_id` int(10) NOT NULL,
  `glevel` varchar(100) CHARACTER SET latin1 NOT NULL,
  `grade_id` int(10) NOT NULL,
  `username` varchar(255) CHARACTER SET latin1 NOT NULL,
  `sid` varchar(100) CHARACTER SET latin1 NOT NULL,
  `section` varchar(10) CHARACTER SET latin1 NOT NULL,
  `academicyear` varchar(20) CHARACTER SET latin1 DEFAULT NULL,
  `createdby` varchar(100) CHARACTER SET latin1 NOT NULL,
  `login_count` int(11) NOT NULL DEFAULT '0',
  `login_date` date NOT NULL,
  `pre_logindate` date NOT NULL,
  `creation_date` date NOT NULL,
  `modifiedby` varchar(100) CHARACTER SET latin1 NOT NULL,
  `modified_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `avatarimage` varchar(800) CHARACTER SET latin1 NOT NULL,
  `agreetermsandservice` int(11) NOT NULL,
  `creationkey` varchar(20) NOT NULL,
  `session_id` varchar(255) CHARACTER SET latin1 NOT NULL,
  `islogin` int(11) NOT NULL,
  `last_active_datetime` datetime NOT NULL,
  `school_name` varchar(255) NOT NULL,
  `state` int(11) NOT NULL,
  `city` int(11) NOT NULL,
  `pincode` int(11) NOT NULL,
  `org_pwd` varchar(255) NOT NULL,
  `portal_type` enum('B2B','B2C') NOT NULL,
  `startdate` date NOT NULL,
  `enddate` date NOT NULL,
  `org_id` int(11) NOT NULL,
  `otp` varchar(16) NOT NULL,
  `otp_datetime` datetime NOT NULL,
  `sbb_position` enum('0','1') NOT NULL DEFAULT '0' COMMENT '0=> No badge,1 => Have badge',
  `sgb_position` enum('0','1') NOT NULL DEFAULT '0' COMMENT '0=> No badge,1 => Have badge',
  `sab_position` enum('0','1') NOT NULL DEFAULT '0' COMMENT '0=> No badge,1 => Have badge',
  `isdemo` int(11) NOT NULL COMMENT '1=>demouser, 0=>originaluser',
  `parent_id` int(11) NOT NULL,
  `time_limit` int(11) NOT NULL,
  `couponcode` varchar(110) NOT NULL,
  `isbookneed` enum('Y','N') NOT NULL,
  `paymentstatus` enum('P','UP') NOT NULL DEFAULT 'UP',
  `payment_id` varchar(255) NOT NULL,
  `isspecialchild` enum('Y','N') NOT NULL,
  `site_type` enum('APP','WEB') NOT NULL DEFAULT 'APP',
  `puzzle_cycle` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `users_check`
--

CREATE TABLE `users_check` (
  `id` int(100) NOT NULL,
  `subscriberid` int(11) NOT NULL,
  `deviceid` varchar(40) NOT NULL,
  `mtoken` text NOT NULL,
  `rollno` varchar(100) CHARACTER SET latin1 NOT NULL,
  `email` varchar(255) CHARACTER SET latin1 NOT NULL,
  `salt1` varchar(20) CHARACTER SET utf8 NOT NULL,
  `password` varchar(100) NOT NULL,
  `salt2` varchar(20) CHARACTER SET utf8 NOT NULL,
  `fname` varchar(100) CHARACTER SET latin1 NOT NULL,
  `lname` varchar(100) CHARACTER SET latin1 NOT NULL,
  `gender` varchar(100) CHARACTER SET latin1 NOT NULL,
  `mobile` varchar(15) CHARACTER SET latin1 NOT NULL,
  `dob` varchar(100) CHARACTER SET latin1 NOT NULL,
  `status` int(1) DEFAULT NULL,
  `visible` int(1) NOT NULL,
  `gp_id` int(10) NOT NULL,
  `glevel` varchar(100) CHARACTER SET latin1 NOT NULL,
  `grade_id` int(10) NOT NULL,
  `username` varchar(255) CHARACTER SET latin1 NOT NULL,
  `sid` varchar(100) CHARACTER SET latin1 NOT NULL,
  `section` varchar(10) CHARACTER SET latin1 NOT NULL,
  `academicyear` varchar(20) CHARACTER SET latin1 DEFAULT NULL,
  `createdby` varchar(100) CHARACTER SET latin1 NOT NULL,
  `login_count` int(11) NOT NULL DEFAULT '0',
  `login_date` date NOT NULL,
  `pre_logindate` date NOT NULL,
  `creation_date` date NOT NULL,
  `modifiedby` varchar(100) CHARACTER SET latin1 NOT NULL,
  `modified_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `avatarimage` varchar(800) CHARACTER SET latin1 NOT NULL,
  `agreetermsandservice` int(11) NOT NULL,
  `creationkey` varchar(20) NOT NULL,
  `session_id` varchar(255) CHARACTER SET latin1 NOT NULL,
  `parent_session_id` varchar(255) NOT NULL,
  `islogin` int(11) NOT NULL,
  `last_active_datetime` datetime NOT NULL,
  `school_name` varchar(255) NOT NULL,
  `state` int(11) NOT NULL,
  `city` int(11) NOT NULL,
  `pincode` int(11) NOT NULL,
  `org_pwd` varchar(255) NOT NULL,
  `portal_type` enum('B2B','B2C') NOT NULL,
  `startdate` date NOT NULL,
  `enddate` date NOT NULL,
  `org_id` int(11) NOT NULL,
  `otp` varchar(16) NOT NULL,
  `otp_datetime` datetime NOT NULL,
  `sbb_position` enum('0','1') NOT NULL DEFAULT '0' COMMENT '0=> No badge,1 => Have badge',
  `sgb_position` enum('0','1') NOT NULL DEFAULT '0' COMMENT '0=> No badge,1 => Have badge',
  `sab_position` enum('0','1') NOT NULL DEFAULT '0' COMMENT '0=> No badge,1 => Have badge',
  `isdemo` int(11) NOT NULL COMMENT '1=>demouser, 0=>originaluser',
  `parent_id` int(11) NOT NULL,
  `time_limit` int(11) NOT NULL,
  `couponcode` varchar(110) NOT NULL,
  `isbookneed` enum('Y','N') NOT NULL,
  `paymentstatus` enum('P','UP') NOT NULL DEFAULT 'UP',
  `payment_id` varchar(255) NOT NULL,
  `isspecialchild` enum('Y','N') NOT NULL,
  `site_type` enum('APP','WEB') NOT NULL DEFAULT 'APP',
  `puzzle_cycle` int(11) NOT NULL,
  `appversion` varchar(55) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `users_check_1`
--

CREATE TABLE `users_check_1` (
  `id` int(100) NOT NULL,
  `subscriberid` int(11) NOT NULL,
  `deviceid` varchar(40) NOT NULL,
  `mtoken` text NOT NULL,
  `rollno` varchar(100) CHARACTER SET latin1 NOT NULL,
  `email` varchar(255) CHARACTER SET latin1 NOT NULL,
  `salt1` varchar(20) CHARACTER SET utf8 NOT NULL,
  `password` varchar(100) NOT NULL,
  `salt2` varchar(20) CHARACTER SET utf8 NOT NULL,
  `fname` varchar(100) CHARACTER SET latin1 NOT NULL,
  `lname` varchar(100) CHARACTER SET latin1 NOT NULL,
  `gender` varchar(100) CHARACTER SET latin1 NOT NULL,
  `mobile` varchar(15) CHARACTER SET latin1 NOT NULL,
  `dob` varchar(100) CHARACTER SET latin1 NOT NULL,
  `status` int(1) DEFAULT NULL,
  `visible` int(1) NOT NULL,
  `gp_id` int(10) NOT NULL,
  `glevel` varchar(100) CHARACTER SET latin1 NOT NULL,
  `grade_id` int(10) NOT NULL,
  `username` varchar(255) CHARACTER SET latin1 NOT NULL,
  `sid` varchar(100) CHARACTER SET latin1 NOT NULL,
  `section` varchar(10) CHARACTER SET latin1 NOT NULL,
  `academicyear` varchar(20) CHARACTER SET latin1 DEFAULT NULL,
  `createdby` varchar(100) CHARACTER SET latin1 NOT NULL,
  `login_count` int(11) NOT NULL DEFAULT '0',
  `login_date` date NOT NULL,
  `pre_logindate` date NOT NULL,
  `creation_date` date NOT NULL,
  `modifiedby` varchar(100) CHARACTER SET latin1 NOT NULL,
  `modified_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `avatarimage` varchar(800) CHARACTER SET latin1 NOT NULL,
  `agreetermsandservice` int(11) NOT NULL,
  `creationkey` varchar(20) NOT NULL,
  `session_id` varchar(255) CHARACTER SET latin1 NOT NULL,
  `parent_session_id` varchar(255) NOT NULL,
  `islogin` int(11) NOT NULL,
  `last_active_datetime` datetime NOT NULL,
  `school_name` varchar(255) NOT NULL,
  `state` int(11) NOT NULL,
  `city` int(11) NOT NULL,
  `pincode` int(11) NOT NULL,
  `org_pwd` varchar(255) NOT NULL,
  `portal_type` enum('B2B','B2C') NOT NULL,
  `startdate` date NOT NULL,
  `enddate` date NOT NULL,
  `org_id` int(11) NOT NULL,
  `otp` varchar(16) NOT NULL,
  `otp_datetime` datetime NOT NULL,
  `sbb_position` enum('0','1') NOT NULL DEFAULT '0' COMMENT '0=> No badge,1 => Have badge',
  `sgb_position` enum('0','1') NOT NULL DEFAULT '0' COMMENT '0=> No badge,1 => Have badge',
  `sab_position` enum('0','1') NOT NULL DEFAULT '0' COMMENT '0=> No badge,1 => Have badge',
  `isdemo` int(11) NOT NULL COMMENT '1=>demouser, 0=>originaluser',
  `parent_id` int(11) NOT NULL,
  `time_limit` int(11) NOT NULL,
  `couponcode` varchar(110) NOT NULL,
  `isbookneed` enum('Y','N') NOT NULL,
  `paymentstatus` enum('P','UP') NOT NULL DEFAULT 'UP',
  `payment_id` varchar(255) NOT NULL,
  `isspecialchild` enum('Y','N') NOT NULL,
  `site_type` enum('APP','WEB') NOT NULL DEFAULT 'APP',
  `puzzle_cycle` int(11) NOT NULL,
  `appversion` varchar(55) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `users_new`
--

CREATE TABLE `users_new` (
  `id` int(100) NOT NULL,
  `subscriberid` int(11) NOT NULL,
  `deviceid` varchar(40) NOT NULL,
  `rollno` varchar(100) CHARACTER SET latin1 NOT NULL,
  `email` varchar(255) CHARACTER SET latin1 NOT NULL,
  `salt1` varchar(20) CHARACTER SET utf8 NOT NULL,
  `password` varchar(100) NOT NULL,
  `salt2` varchar(20) CHARACTER SET utf8 NOT NULL,
  `fname` varchar(100) CHARACTER SET latin1 NOT NULL,
  `lname` varchar(100) CHARACTER SET latin1 NOT NULL,
  `gender` varchar(100) CHARACTER SET latin1 NOT NULL,
  `mobile` varchar(15) CHARACTER SET latin1 NOT NULL,
  `dob` varchar(100) CHARACTER SET latin1 NOT NULL,
  `status` int(1) DEFAULT NULL,
  `visible` int(1) NOT NULL,
  `gp_id` int(10) NOT NULL,
  `glevel` varchar(100) CHARACTER SET latin1 NOT NULL,
  `grade_id` int(10) NOT NULL,
  `sname` varchar(100) CHARACTER SET latin1 NOT NULL,
  `father` varchar(100) CHARACTER SET latin1 NOT NULL,
  `mother` varchar(100) CHARACTER SET latin1 NOT NULL,
  `address` varchar(500) CHARACTER SET latin1 NOT NULL,
  `username` varchar(255) CHARACTER SET latin1 NOT NULL,
  `initial` varchar(100) CHARACTER SET latin1 NOT NULL,
  `sid` varchar(100) CHARACTER SET latin1 NOT NULL,
  `section` varchar(10) CHARACTER SET latin1 NOT NULL,
  `academicyear` varchar(20) CHARACTER SET latin1 DEFAULT NULL,
  `createdby` varchar(100) CHARACTER SET latin1 NOT NULL,
  `login_count` int(11) NOT NULL DEFAULT '0',
  `login_date` date NOT NULL,
  `pre_logindate` date NOT NULL,
  `creation_date` date NOT NULL,
  `modifiedby` varchar(100) CHARACTER SET latin1 NOT NULL,
  `modified_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `avatarimage` varchar(800) CHARACTER SET latin1 NOT NULL,
  `agreetermsandservice` int(11) NOT NULL,
  `creationkey` varchar(20) NOT NULL,
  `usertheme` varchar(55) CHARACTER SET latin1 NOT NULL,
  `session_id` varchar(255) CHARACTER SET latin1 NOT NULL,
  `islogin` int(11) NOT NULL,
  `last_active_datetime` datetime NOT NULL,
  `school_name` varchar(255) NOT NULL,
  `referedby` varchar(55) NOT NULL,
  `org_pwd` varchar(255) NOT NULL,
  `stateid` int(11) NOT NULL,
  `city` varchar(110) NOT NULL,
  `pincode` int(11) NOT NULL,
  `parentname` varchar(110) NOT NULL,
  `hospitalid` int(11) NOT NULL,
  `doctorid` int(11) NOT NULL,
  `couponcode` varchar(55) NOT NULL,
  `portal_type` enum('ASAP','CLP') NOT NULL DEFAULT 'ASAP',
  `startdate` date NOT NULL,
  `enddate` date NOT NULL,
  `otp` varchar(16) NOT NULL,
  `otp_datetime` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `user_academic_mapping`
--

CREATE TABLE `user_academic_mapping` (
  `masterid` int(11) NOT NULL,
  `id` int(11) NOT NULL,
  `grade_id` int(11) NOT NULL,
  `gp_id` int(11) NOT NULL,
  `sid` int(11) NOT NULL,
  `section` varchar(10) NOT NULL,
  `academicid` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `visible` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `user_academic_mapping_new`
--

CREATE TABLE `user_academic_mapping_new` (
  `masterid` int(11) NOT NULL,
  `id` int(11) NOT NULL,
  `grade_id` int(11) NOT NULL,
  `gp_id` int(11) NOT NULL,
  `sid` int(11) NOT NULL,
  `section` varchar(10) NOT NULL,
  `academicid` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `visible` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `user_badgestatus`
--

CREATE TABLE `user_badgestatus` (
  `id` int(11) NOT NULL,
  `userid` varchar(510) NOT NULL,
  `badge_type` varchar(55) NOT NULL,
  `score` varchar(110) NOT NULL,
  `status` int(11) NOT NULL,
  `dateontopper` date NOT NULL,
  `created_on` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `user_challenge_table`
--

CREATE TABLE `user_challenge_table` (
  `ugid` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `challengeid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_challenge_table`
--

INSERT INTO `user_challenge_table` (`ugid`, `userid`, `challengeid`) VALUES
(1, 77, 155),
(2, 78, 77),
(3, 78, 63),
(4, 77, 6),
(5, 77, 24),
(6, 77, 133),
(7, 86, 164),
(8, 78, 43),
(9, 78, 163),
(10, 86, 137),
(11, 86, 48),
(12, 86, 148),
(13, 77, 13),
(14, 79, 160),
(15, 77, 33),
(16, 77, 123),
(17, 79, 154),
(18, 77, 28),
(19, 97, 18),
(20, 95, 70),
(21, 180, 22),
(22, 180, 19),
(23, 225, 30),
(24, 245, 163),
(25, 238, 64),
(26, 244, 144),
(27, 245, 80),
(28, 245, 117),
(29, 245, 17),
(30, 244, 166),
(31, 245, 99),
(32, 267, 16),
(33, 276, 113),
(34, 267, 20),
(35, 244, 83),
(36, 245, 6),
(37, 245, 84),
(38, 276, 116),
(39, 276, 39),
(40, 276, 66),
(41, 276, 98),
(42, 245, 46),
(43, 276, 79),
(44, 276, 85),
(45, 276, 132),
(46, 276, 174),
(47, 244, 19),
(48, 276, 156);

-- --------------------------------------------------------

--
-- Table structure for table `user_class_limit`
--

CREATE TABLE `user_class_limit` (
  `id` int(11) NOT NULL,
  `school_id` int(11) NOT NULL,
  `class_id` int(11) NOT NULL,
  `userlimit` int(11) NOT NULL,
  `status` int(1) NOT NULL,
  `createdby` varchar(100) NOT NULL,
  `creation_date` date NOT NULL,
  `modifiedby` varchar(100) NOT NULL,
  `modified_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_class_limit`
--

INSERT INTO `user_class_limit` (`id`, `school_id`, `class_id`, `userlimit`, `status`, `createdby`, `creation_date`, `modifiedby`, `modified_date`) VALUES
(1, 1, 3, 145, 0, '', '0000-00-00', '', '2014-06-15 06:02:14'),
(2, 1, 4, 160, 0, '', '0000-00-00', '', '2014-06-15 06:02:28'),
(3, 1, 5, 135, 0, '', '0000-00-00', '', '2014-06-15 06:02:39'),
(4, 1, 6, 150, 0, '', '0000-00-00', '', '2014-06-15 06:02:51'),
(5, 1, 7, 140, 0, '', '0000-00-00', '', '2014-06-15 06:03:04'),
(6, 1, 8, 150, 0, '', '0000-00-00', '', '2014-06-15 06:03:19'),
(7, 1, 9, 170, 0, '', '0000-00-00', '', '2014-06-15 06:03:35'),
(8, 1, 10, 170, 0, '', '0000-00-00', '', '2014-06-15 06:03:49'),
(9, 2, 1, 1000, 0, '', '0000-00-00', '', '2014-12-23 22:00:52'),
(10, 3, 5, 100, 0, '', '0000-00-00', '', '2014-06-23 23:12:44'),
(11, 3, 6, 100, 0, '', '0000-00-00', '', '2014-06-23 23:12:59'),
(12, 3, 7, 100, 0, '', '0000-00-00', '', '2014-06-23 23:13:10'),
(13, 3, 8, 100, 0, '', '0000-00-00', '', '2014-06-23 23:59:43'),
(15, 2, 2, 1000, 0, '', '0000-00-00', '', '2014-12-23 22:00:40'),
(16, 2, 3, 1000, 0, '', '0000-00-00', '', '2014-12-23 22:01:05'),
(17, 2, 4, 1000, 0, '', '0000-00-00', '', '2014-12-23 22:01:15'),
(18, 2, 5, 1000, 0, '', '0000-00-00', '', '2014-12-23 22:01:27'),
(19, 2, 6, 1000, 0, '', '0000-00-00', '', '2014-12-23 22:02:11'),
(20, 2, 7, 1000, 0, '', '0000-00-00', '', '2014-12-23 22:02:28'),
(21, 2, 8, 1000, 0, '', '0000-00-00', '', '2014-12-23 22:02:45'),
(22, 2, 9, 1000, 0, '', '0000-00-00', '', '2014-12-23 22:03:00'),
(23, 2, 10, 1000, 0, '', '0000-00-00', '', '2014-12-23 22:03:13'),
(24, 4, 3, 231, 0, '', '0000-00-00', '', '2014-07-14 09:12:11'),
(25, 4, 4, 197, 0, '', '0000-00-00', '', '2014-07-14 09:12:32'),
(26, 4, 5, 261, 0, '', '0000-00-00', '', '2014-07-14 09:12:49'),
(27, 4, 6, 4, 0, '', '0000-00-00', '', '2014-08-26 07:54:02'),
(28, 4, 7, 198, 0, '', '0000-00-00', '', '2014-07-14 09:13:28'),
(29, 4, 8, 195, 0, '', '0000-00-00', '', '2014-07-14 09:13:47'),
(30, 4, 9, 5, 0, '', '0000-00-00', '', '2014-08-26 07:57:40'),
(31, 4, 10, 5, 0, '', '0000-00-00', '', '2014-08-26 07:58:16'),
(32, 5, 3, 162, 0, '', '0000-00-00', '', '2014-07-17 05:06:05'),
(33, 5, 4, 169, 0, '', '0000-00-00', '', '2014-07-17 05:06:23'),
(34, 5, 5, 110, 0, '', '0000-00-00', '', '2014-07-17 05:06:44'),
(35, 5, 6, 110, 0, '', '0000-00-00', '', '2014-07-17 05:07:20'),
(36, 5, 7, 106, 0, '', '0000-00-00', '', '2014-07-17 05:07:48'),
(37, 5, 8, 101, 0, '', '0000-00-00', '', '2014-07-17 05:08:11'),
(38, 5, 9, 88, 0, '', '0000-00-00', '', '2014-07-17 05:08:33'),
(39, 5, 10, 100, 0, '', '0000-00-00', '', '2014-07-17 05:08:51'),
(40, 6, 1, 50, 0, '', '0000-00-00', '', '2014-08-25 00:04:27'),
(41, 6, 2, 50, 0, '', '0000-00-00', '', '2014-08-25 00:04:36'),
(42, 6, 3, 50, 0, '', '0000-00-00', '', '2014-08-25 00:04:46'),
(43, 6, 4, 50, 0, '', '0000-00-00', '', '2014-08-25 00:04:57'),
(44, 6, 5, 50, 0, '', '0000-00-00', '', '2014-08-25 00:05:08'),
(45, 6, 6, 50, 0, '', '0000-00-00', '', '2014-08-25 00:05:20'),
(46, 6, 7, 50, 0, '', '0000-00-00', '', '2014-08-25 00:05:33'),
(47, 6, 8, 50, 0, '', '0000-00-00', '', '2014-08-25 00:05:42'),
(48, 6, 9, 50, 0, '', '0000-00-00', '', '2014-08-25 00:05:53'),
(49, 6, 10, 50, 0, '', '0000-00-00', '', '2014-08-25 00:06:05'),
(52, 8, 8, 50, 0, '', '0000-00-00', '', '2015-02-02 23:31:24'),
(53, 8, 9, 50, 0, '', '0000-00-00', '', '2015-02-02 23:31:34'),
(54, 8, 10, 50, 0, '', '0000-00-00', '', '2015-02-02 23:31:44'),
(55, 9, 2, 30, 0, '', '0000-00-00', '', '2015-04-28 21:53:27'),
(56, 9, 3, 30, 0, '', '0000-00-00', '', '2015-04-28 21:53:46'),
(57, 9, 4, 30, 0, '', '0000-00-00', '', '2015-04-28 21:54:01'),
(58, 9, 5, 30, 0, '', '0000-00-00', '', '2015-04-28 21:54:24'),
(59, 9, 6, 30, 0, '', '0000-00-00', '', '2015-04-28 21:54:46'),
(60, 9, 7, 30, 0, '', '0000-00-00', '', '2015-04-28 21:55:10'),
(61, 9, 8, 30, 0, '', '0000-00-00', '', '2015-04-28 21:55:38'),
(62, 9, 9, 30, 0, '', '0000-00-00', '', '2015-04-28 21:55:55'),
(63, 9, 10, 30, 0, '', '0000-00-00', '', '2015-04-28 21:56:21'),
(64, 10, 1, 100, 0, '', '0000-00-00', '', '2015-05-12 21:34:13'),
(65, 10, 2, 100, 0, '', '0000-00-00', '', '2015-05-12 21:34:21'),
(66, 10, 3, 100, 0, '', '0000-00-00', '', '2015-05-12 21:34:29'),
(67, 10, 4, 100, 0, '', '0000-00-00', '', '2015-05-12 21:34:48'),
(68, 10, 5, 100, 0, '', '0000-00-00', '', '2015-05-12 21:34:55'),
(69, 10, 6, 100, 0, '', '0000-00-00', '', '2015-05-12 21:35:03'),
(70, 10, 7, 100, 0, '', '0000-00-00', '', '2015-05-12 21:35:11'),
(71, 10, 8, 100, 0, '', '0000-00-00', '', '2015-05-12 21:35:18'),
(72, 10, 9, 100, 0, '', '0000-00-00', '', '2015-05-12 21:35:27'),
(73, 10, 10, 100, 0, '', '0000-00-00', '', '2015-05-12 21:35:35'),
(74, 11, 1, 100, 0, '', '0000-00-00', '', '2015-05-13 06:50:50'),
(75, 11, 2, 100, 0, '', '0000-00-00', '', '2015-05-13 06:51:00'),
(76, 11, 3, 100, 0, '', '0000-00-00', '', '2015-05-13 06:51:08'),
(77, 11, 4, 100, 0, '', '0000-00-00', '', '2015-05-13 06:51:17'),
(78, 11, 5, 100, 0, '', '0000-00-00', '', '2015-05-13 06:51:27'),
(79, 11, 6, 100, 0, '', '0000-00-00', '', '2015-05-13 06:51:36'),
(80, 11, 7, 100, 0, '', '0000-00-00', '', '2015-05-13 06:51:46'),
(81, 11, 8, 100, 0, '', '0000-00-00', '', '2015-05-13 06:51:56'),
(82, 11, 9, 100, 0, '', '0000-00-00', '', '2015-05-13 06:52:13'),
(83, 11, 10, 100, 0, '', '0000-00-00', '', '2015-05-13 06:52:22'),
(84, 12, 7, 300, 0, '', '0000-00-00', '', '2015-08-02 23:58:39'),
(85, 12, 8, 300, 0, '', '0000-00-00', '', '2015-08-02 23:58:47'),
(86, 12, 9, 300, 0, '', '0000-00-00', '', '2015-08-02 23:59:17'),
(87, 12, 10, 300, 0, '', '0000-00-00', '', '2015-08-02 23:59:25'),
(88, 14, 6, 100, 0, '', '0000-00-00', '', '2016-05-09 23:33:37'),
(89, 14, 7, 100, 0, '', '0000-00-00', '', '2016-05-09 23:33:46'),
(90, 14, 8, 100, 0, '', '0000-00-00', '', '2016-05-09 23:33:54'),
(91, 14, 9, 100, 0, '', '0000-00-00', '', '2016-05-09 23:34:18'),
(92, 14, 10, 100, 0, '', '0000-00-00', '', '2016-05-09 23:34:29'),
(93, 13, 3, 150, 0, '', '0000-00-00', '', '2016-06-13 03:37:44'),
(94, 13, 4, 150, 0, '', '0000-00-00', '', '2016-06-13 03:38:05'),
(97, 15, 3, 40, 0, '', '0000-00-00', '', '2016-07-18 07:05:04'),
(98, 15, 4, 40, 0, '', '0000-00-00', '', '2016-07-18 07:05:13'),
(99, 15, 5, 40, 0, '', '0000-00-00', '', '2016-07-18 07:05:22'),
(100, 15, 6, 40, 0, '', '0000-00-00', '', '2016-07-18 07:05:30'),
(101, 15, 7, 40, 0, '', '0000-00-00', '', '2016-07-18 07:05:40'),
(102, 15, 8, 40, 0, '', '0000-00-00', '', '2016-07-18 07:05:50'),
(103, 15, 9, 40, 0, '', '0000-00-00', '', '2016-07-18 07:06:00'),
(104, 15, 10, 40, 0, '', '0000-00-00', '', '2016-07-18 07:06:38'),
(105, 16, 1, 100, 0, '', '0000-00-00', '', '2016-07-20 06:24:51'),
(106, 16, 2, 100, 0, '', '0000-00-00', '', '2016-07-20 06:25:01'),
(107, 16, 3, 100, 0, '', '0000-00-00', '', '2016-07-20 06:25:10'),
(108, 16, 4, 100, 0, '', '0000-00-00', '', '2016-07-20 06:25:19'),
(109, 16, 5, 100, 0, '', '0000-00-00', '', '2016-07-20 06:25:29'),
(110, 16, 6, 100, 0, '', '0000-00-00', '', '2016-07-20 06:25:41'),
(111, 16, 7, 100, 0, '', '0000-00-00', '', '2016-07-20 06:25:57'),
(112, 16, 8, 100, 0, '', '0000-00-00', '', '2016-07-20 06:26:10'),
(113, 16, 9, 100, 0, '', '0000-00-00', '', '2016-07-20 06:26:22'),
(114, 16, 10, 100, 0, '', '0000-00-00', '', '2016-07-20 06:26:39');

-- --------------------------------------------------------

--
-- Table structure for table `user_games`
--

CREATE TABLE `user_games` (
  `id` int(11) NOT NULL,
  `gu_id` int(11) NOT NULL,
  `played_game` text NOT NULL,
  `last_update` varchar(100) NOT NULL,
  `date` varchar(100) NOT NULL,
  `status` int(1) NOT NULL,
  `academicyear` varchar(20) DEFAULT NULL,
  `createdby` varchar(100) NOT NULL,
  `creation_date` date NOT NULL,
  `modifiedby` varchar(100) NOT NULL,
  `modified_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `user_games_history`
--

CREATE TABLE `user_games_history` (
  `id` int(11) NOT NULL,
  `gu_id` int(11) NOT NULL,
  `played_game` text NOT NULL,
  `last_update` varchar(100) NOT NULL,
  `date` varchar(100) NOT NULL,
  `status` int(2) NOT NULL,
  `academicyear` varchar(20) DEFAULT NULL,
  `createdby` varchar(100) NOT NULL,
  `creation_date` date NOT NULL,
  `modifiedby` varchar(100) NOT NULL,
  `modified_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `user_games_plans`
--

CREATE TABLE `user_games_plans` (
  `id` int(100) NOT NULL,
  `gu_id` int(100) NOT NULL,
  `gp_id` int(100) NOT NULL,
  `startdate` varchar(100) NOT NULL,
  `expirytime` varchar(100) NOT NULL,
  `academicyear` varchar(20) DEFAULT NULL,
  `status` int(1) NOT NULL,
  `createdby` varchar(100) NOT NULL,
  `creation_date` date NOT NULL,
  `modifiedby` varchar(100) NOT NULL,
  `modified_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `user_game_feedback`
--

CREATE TABLE `user_game_feedback` (
  `id` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `gameid` int(11) NOT NULL,
  `ui_rating` int(11) NOT NULL,
  `ux_rating` int(11) NOT NULL,
  `puzzle_concept` int(11) NOT NULL,
  `feedback` text,
  `date_time` datetime DEFAULT NULL,
  `status` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `user_limit`
--

CREATE TABLE `user_limit` (
  `id` int(50) NOT NULL,
  `gu_id` int(50) NOT NULL,
  `gs_id` int(50) NOT NULL,
  `g_id` int(50) NOT NULL,
  `ntimes` int(50) NOT NULL,
  `lastupdate` varchar(100) NOT NULL,
  `academicyear` varchar(20) DEFAULT NULL,
  `createdby` varchar(100) NOT NULL,
  `creation_date` date NOT NULL,
  `modifiedby` varchar(100) NOT NULL,
  `modified_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_limit`
--

INSERT INTO `user_limit` (`id`, `gu_id`, `gs_id`, `g_id`, `ntimes`, `lastupdate`, `academicyear`, `createdby`, `creation_date`, `modifiedby`, `modified_date`) VALUES
(1, 7433, 59, 8, 4, '2016-12-21', NULL, '', '0000-00-00', '', '2016-12-19 08:46:28'),
(2, 7433, 59, 8, 2, '2016-12-22', NULL, '', '0000-00-00', '', '2016-12-20 06:23:29'),
(3, 7433, 60, 9, 1, '2016-12-22', NULL, '', '0000-00-00', '', '2016-12-20 04:39:49'),
(4, 7433, 61, 25, 1, '2016-12-22', NULL, '', '0000-00-00', '', '2016-12-20 04:41:35'),
(5, 7433, 62, 31, 2, '2016-12-22', NULL, '', '0000-00-00', '', '2016-12-20 04:48:03'),
(6, 7433, 63, 35, 1, '2016-12-22', NULL, '', '0000-00-00', '', '2016-12-20 04:46:24'),
(7, 7433, 59, 8, 1, '2016-12-23', NULL, '', '0000-00-00', '', '2016-12-21 02:56:43'),
(8, 7433, 60, 9, 1, '2016-12-23', NULL, '', '0000-00-00', '', '2016-12-21 02:58:14'),
(9, 7433, 61, 25, 1, '2016-12-23', NULL, '', '0000-00-00', '', '2016-12-21 02:59:47'),
(10, 7433, 59, 8, 4, '2016-12-29', NULL, '', '0000-00-00', '', '2016-12-27 05:42:55'),
(11, 7433, 60, 9, 3, '2016-12-29', NULL, '', '0000-00-00', '', '2016-12-27 05:59:54'),
(12, 7433, 61, 25, 2, '2016-12-29', NULL, '', '0000-00-00', '', '2016-12-27 05:47:08'),
(13, 7433, 62, 31, 3, '2016-12-29', NULL, '', '0000-00-00', '', '2016-12-27 05:57:41'),
(14, 7433, 63, 35, 2, '2016-12-29', NULL, '', '0000-00-00', '', '2016-12-27 05:56:08'),
(15, 7433, 59, 8, 1, '2016-12-30', NULL, '', '0000-00-00', '', '2016-12-28 01:24:04'),
(16, 7441, 59, 8, 1, '2016-12-30', NULL, '', '0000-00-00', '', '2016-12-28 02:07:45'),
(17, 7441, 60, 9, 1, '2016-12-30', NULL, '', '0000-00-00', '', '2016-12-28 04:30:00'),
(18, 7433, 59, 7, 2, '2016-12-30', NULL, '', '0000-00-00', '', '2016-12-28 06:31:03'),
(19, 7433, 60, 9, 1, '2016-12-30', NULL, '', '0000-00-00', '', '2016-12-28 05:32:05'),
(20, 7433, 61, 21, 1, '2016-12-30', NULL, '', '0000-00-00', '', '2016-12-28 05:34:46'),
(21, 7441, 62, 30, 1, '2016-12-30', NULL, '', '0000-00-00', '', '2016-12-28 05:37:11'),
(22, 7433, 62, 30, 1, '2016-12-30', NULL, '', '0000-00-00', '', '2016-12-28 05:38:46'),
(23, 7441, 63, 38, 1, '2016-12-30', NULL, '', '0000-00-00', '', '2016-12-28 05:59:22'),
(24, 7441, 61, 21, 1, '2016-12-30', NULL, '', '0000-00-00', '', '2016-12-28 05:59:56'),
(25, 7433, 59, 5, 3, '2017-01-02', NULL, '', '0000-00-00', '', '2016-12-31 06:30:43'),
(26, 7433, 60, 12, 2, '2017-01-02', NULL, '', '0000-00-00', '', '2016-12-31 06:49:46'),
(27, 7433, 61, 24, 1, '2017-01-02', NULL, '', '0000-00-00', '', '2016-12-31 06:33:48'),
(28, 7433, 62, 27, 2, '2017-01-02', NULL, '', '0000-00-00', '', '2016-12-31 06:49:06'),
(29, 7433, 63, 42, 2, '2017-01-02', NULL, '', '0000-00-00', '', '2016-12-31 06:47:00'),
(30, 7433, 59, 2, 2, '2017-01-02', NULL, '', '0000-00-00', '', '2016-12-31 07:13:25'),
(31, 7433, 60, 17, 3, '2017-01-02', NULL, '', '0000-00-00', '', '2016-12-31 07:00:53'),
(32, 7433, 61, 19, 1, '2017-01-02', NULL, '', '0000-00-00', '', '2016-12-31 07:02:43'),
(33, 7433, 62, 28, 2, '2017-01-02', NULL, '', '0000-00-00', '', '2016-12-31 07:05:27'),
(34, 7433, 63, 35, 1, '2017-01-02', NULL, '', '0000-00-00', '', '2016-12-31 07:09:48'),
(35, 7433, 59, 1, 3, '2017-01-02', NULL, '', '0000-00-00', '', '2016-12-31 07:19:53'),
(36, 7433, 60, 10, 2, '2017-01-02', NULL, '', '0000-00-00', '', '2016-12-31 07:21:45'),
(37, 7442, 59, 415, 2, '2017-01-03', NULL, '', '0000-00-00', '', '2017-01-01 04:59:48'),
(38, 7442, 60, 429, 1, '2017-01-03', NULL, '', '0000-00-00', '', '2017-01-01 05:00:44'),
(39, 7442, 59, 416, 1, '2017-01-04', NULL, '', '0000-00-00', '', '2017-01-02 00:44:15'),
(40, 7442, 60, 425, 2, '2017-01-04', NULL, '', '0000-00-00', '', '2017-01-02 00:58:37'),
(41, 7442, 62, 441, 1, '2017-01-04', NULL, '', '0000-00-00', '', '2017-01-02 01:06:58'),
(42, 7442, 63, 453, 1, '2017-01-04', NULL, '', '0000-00-00', '', '2017-01-02 01:13:30'),
(43, 7442, 59, 417, 1, '2017-01-05', NULL, '', '0000-00-00', '', '2017-01-03 09:33:16'),
(44, 7442, 60, 428, 1, '2017-01-05', NULL, '', '0000-00-00', '', '2017-01-03 09:35:08'),
(45, 7441, 60, 18, 4, '2017-01-07', NULL, '', '0000-00-00', '', '2017-01-05 03:49:17'),
(46, 7441, 61, 19, 1, '2017-01-07', NULL, '', '0000-00-00', '', '2017-01-05 04:01:02'),
(47, 7441, 62, 27, 1, '2017-01-07', NULL, '', '0000-00-00', '', '2017-01-05 04:09:40'),
(48, 7441, 59, 3, 2, '2017-01-07', NULL, '', '0000-00-00', '', '2017-01-05 04:57:02'),
(49, 7441, 60, 10, 3, '2017-01-07', NULL, '', '0000-00-00', '', '2017-01-05 05:16:26'),
(50, 7441, 61, 20, 2, '2017-01-07', NULL, '', '0000-00-00', '', '2017-01-05 05:39:36'),
(51, 7443, 59, 1, 10, '2017-01-09', NULL, '', '0000-00-00', '', '2017-01-07 05:17:25'),
(52, 7445, 59, 1, 11, '2017-01-09', NULL, '', '0000-00-00', '', '2017-01-07 04:58:56'),
(53, 7444, 59, 1, 9, '2017-01-09', NULL, '', '0000-00-00', '', '2017-01-07 05:25:05'),
(54, 7443, 60, 15, 5, '2017-01-09', NULL, '', '0000-00-00', '', '2017-01-07 06:06:10'),
(55, 7444, 60, 15, 10, '2017-01-09', NULL, '', '0000-00-00', '', '2017-01-07 06:07:32'),
(56, 7445, 60, 15, 10, '2017-01-09', NULL, '', '0000-00-00', '', '2017-01-07 05:49:07'),
(57, 7444, 63, 35, 5, '2017-01-09', NULL, '', '0000-00-00', '', '2017-01-07 07:06:43'),
(58, 7443, 62, 32, 8, '2017-01-09', NULL, '', '0000-00-00', '', '2017-01-07 06:50:46'),
(59, 7445, 62, 32, 8, '2017-01-09', NULL, '', '0000-00-00', '', '2017-01-07 06:52:46'),
(60, 7444, 62, 32, 9, '2017-01-09', NULL, '', '0000-00-00', '', '2017-01-07 06:48:28'),
(61, 7445, 63, 35, 8, '2017-01-09', NULL, '', '0000-00-00', '', '2017-01-07 07:16:47'),
(62, 7443, 63, 35, 4, '2017-01-09', NULL, '', '0000-00-00', '', '2017-01-07 07:15:37'),
(63, 7445, 59, 4, 5, '2017-01-10', NULL, '', '0000-00-00', '', '2017-01-07 23:24:21'),
(64, 7444, 60, 17, 5, '2017-01-10', NULL, '', '0000-00-00', '', '2017-01-07 22:50:42'),
(65, 7443, 59, 4, 3, '2017-01-10', NULL, '', '0000-00-00', '', '2017-01-07 22:44:50'),
(66, 7443, 60, 17, 2, '2017-01-10', NULL, '', '0000-00-00', '', '2017-01-07 23:10:28'),
(67, 7444, 59, 4, 3, '2017-01-10', NULL, '', '0000-00-00', '', '2017-01-07 23:22:33'),
(68, 7443, 61, 24, 6, '2017-01-10', NULL, '', '0000-00-00', '', '2017-01-08 01:31:01'),
(69, 7444, 61, 24, 5, '2017-01-10', NULL, '', '0000-00-00', '', '2017-01-08 00:18:53'),
(70, 7446, 59, 4, 3, '2017-01-10', NULL, '', '0000-00-00', '', '2017-01-08 01:35:36'),
(71, 7445, 60, 17, 4, '2017-01-10', NULL, '', '0000-00-00', '', '2017-01-08 01:44:35'),
(72, 7446, 60, 17, 1, '2017-01-10', NULL, '', '0000-00-00', '', '2017-01-08 00:21:08'),
(73, 7446, 61, 24, 1, '2017-01-10', NULL, '', '0000-00-00', '', '2017-01-08 00:22:27'),
(74, 7443, 62, 34, 3, '2017-01-10', NULL, '', '0000-00-00', '', '2017-01-08 01:19:43'),
(75, 7444, 62, 34, 3, '2017-01-10', NULL, '', '0000-00-00', '', '2017-01-08 00:33:44'),
(76, 7446, 62, 34, 1, '2017-01-10', NULL, '', '0000-00-00', '', '2017-01-08 00:24:20'),
(77, 7443, 63, 42, 3, '2017-01-10', NULL, '', '0000-00-00', '', '2017-01-08 01:17:38'),
(78, 7444, 63, 42, 4, '2017-01-10', NULL, '', '0000-00-00', '', '2017-01-08 01:35:25'),
(79, 7445, 61, 24, 1, '2017-01-10', NULL, '', '0000-00-00', '', '2017-01-08 00:47:32'),
(80, 7445, 62, 34, 1, '2017-01-10', NULL, '', '0000-00-00', '', '2017-01-08 01:02:53'),
(81, 7445, 63, 42, 1, '2017-01-10', NULL, '', '0000-00-00', '', '2017-01-08 01:21:14'),
(82, 7445, 59, 5, 3, '2017-01-10', NULL, '', '0000-00-00', '', '2017-01-08 03:25:46'),
(83, 7443, 59, 5, 1, '2017-01-10', NULL, '', '0000-00-00', '', '2017-01-08 03:08:47'),
(84, 7444, 59, 5, 2, '2017-01-10', NULL, '', '0000-00-00', '', '2017-01-08 03:24:52'),
(85, 7447, 59, 419, 4, '2017-01-10', NULL, '', '0000-00-00', '', '2017-01-08 03:56:17'),
(86, 7445, 60, 12, 2, '2017-01-10', NULL, '', '0000-00-00', '', '2017-01-08 03:38:24'),
(87, 7443, 60, 12, 2, '2017-01-10', NULL, '', '0000-00-00', '', '2017-01-08 03:32:53'),
(88, 7444, 60, 12, 2, '2017-01-10', NULL, '', '0000-00-00', '', '2017-01-08 03:42:44'),
(89, 7447, 60, 426, 3, '2017-01-10', NULL, '', '0000-00-00', '', '2017-01-08 04:08:32'),
(90, 7443, 61, 25, 2, '2017-01-10', NULL, '', '0000-00-00', '', '2017-01-08 03:45:26'),
(91, 7444, 61, 25, 4, '2017-01-10', NULL, '', '0000-00-00', '', '2017-01-08 03:59:39'),
(92, 7447, 61, 436, 3, '2017-01-10', NULL, '', '0000-00-00', '', '2017-01-08 04:08:10'),
(93, 7445, 61, 25, 1, '2017-01-10', NULL, '', '0000-00-00', '', '2017-01-08 03:47:01'),
(94, 7443, 62, 31, 2, '2017-01-10', NULL, '', '0000-00-00', '', '2017-01-08 03:56:44'),
(95, 7447, 62, 443, 1, '2017-01-10', NULL, '', '0000-00-00', '', '2017-01-08 04:00:26'),
(96, 7443, 63, 41, 2, '2017-01-10', NULL, '', '0000-00-00', '', '2017-01-08 04:07:00'),
(97, 7444, 62, 31, 2, '2017-01-10', NULL, '', '0000-00-00', '', '2017-01-08 04:11:43'),
(98, 7445, 62, 31, 1, '2017-01-10', NULL, '', '0000-00-00', '', '2017-01-08 04:05:06'),
(99, 7447, 63, 446, 2, '2017-01-10', NULL, '', '0000-00-00', '', '2017-01-08 04:12:04'),
(100, 7444, 63, 41, 2, '2017-01-10', NULL, '', '0000-00-00', '', '2017-01-08 04:23:47'),
(101, 7447, 59, 414, 3, '2017-01-10', NULL, '', '0000-00-00', '', '2017-01-08 04:30:35'),
(102, 7445, 63, 41, 2, '2017-01-10', NULL, '', '0000-00-00', '', '2017-01-08 04:43:47'),
(103, 7447, 60, 424, 1, '2017-01-10', NULL, '', '0000-00-00', '', '2017-01-08 04:46:55'),
(104, 7445, 59, 7, 2, '2017-01-10', NULL, '', '0000-00-00', '', '2017-01-08 04:57:39'),
(105, 7443, 59, 7, 2, '2017-01-10', NULL, '', '0000-00-00', '', '2017-01-08 04:52:54'),
(106, 7444, 59, 7, 2, '2017-01-10', NULL, '', '0000-00-00', '', '2017-01-08 04:57:22'),
(107, 7447, 61, 433, 1, '2017-01-10', NULL, '', '0000-00-00', '', '2017-01-08 04:54:17'),
(108, 7445, 60, 9, 1, '2017-01-10', NULL, '', '0000-00-00', '', '2017-01-08 05:01:26'),
(109, 7443, 60, 9, 2, '2017-01-10', NULL, '', '0000-00-00', '', '2017-01-08 05:06:44'),
(110, 7444, 60, 9, 3, '2017-01-10', NULL, '', '0000-00-00', '', '2017-01-08 05:12:27'),
(111, 7447, 62, 442, 2, '2017-01-10', NULL, '', '0000-00-00', '', '2017-01-08 05:09:04'),
(112, 7447, 63, 448, 2, '2017-01-10', NULL, '', '0000-00-00', '', '2017-01-08 05:16:13'),
(113, 7443, 61, 22, 2, '2017-01-10', NULL, '', '0000-00-00', '', '2017-01-08 05:19:47'),
(114, 7444, 61, 22, 3, '2017-01-10', NULL, '', '0000-00-00', '', '2017-01-08 05:51:58'),
(115, 7445, 62, 28, 1, '2017-01-10', NULL, '', '0000-00-00', '', '2017-01-08 05:20:22'),
(116, 7444, 62, 28, 4, '2017-01-10', NULL, '', '0000-00-00', '', '2017-01-08 05:43:05'),
(117, 7443, 62, 28, 2, '2017-01-10', NULL, '', '0000-00-00', '', '2017-01-08 05:37:01'),
(118, 7447, 59, 421, 1, '2017-01-10', NULL, '', '0000-00-00', '', '2017-01-08 05:37:29'),
(119, 7447, 60, 423, 1, '2017-01-10', NULL, '', '0000-00-00', '', '2017-01-08 05:43:40'),
(120, 7445, 63, 36, 1, '2017-01-10', NULL, '', '0000-00-00', '', '2017-01-08 05:54:35'),
(121, 7443, 63, 36, 2, '2017-01-10', NULL, '', '0000-00-00', '', '2017-01-08 05:59:15'),
(122, 7444, 63, 36, 2, '2017-01-10', NULL, '', '0000-00-00', '', '2017-01-08 06:04:26'),
(123, 7447, 62, 445, 2, '2017-01-10', NULL, '', '0000-00-00', '', '2017-01-08 05:59:54'),
(124, 7447, 63, 447, 2, '2017-01-10', NULL, '', '0000-00-00', '', '2017-01-08 06:07:55'),
(125, 7444, 59, 6, 2, '2017-01-10', NULL, '', '0000-00-00', '', '2017-01-08 06:17:42'),
(126, 7443, 59, 6, 2, '2017-01-10', NULL, '', '0000-00-00', '', '2017-01-08 06:13:28'),
(127, 7447, 59, 420, 2, '2017-01-10', NULL, '', '0000-00-00', '', '2017-01-08 06:20:30'),
(128, 7445, 59, 6, 1, '2017-01-10', NULL, '', '0000-00-00', '', '2017-01-08 06:15:40'),
(129, 7443, 60, 16, 2, '2017-01-10', NULL, '', '0000-00-00', '', '2017-01-08 06:24:30'),
(130, 7445, 60, 16, 1, '2017-01-10', NULL, '', '0000-00-00', '', '2017-01-08 06:24:53'),
(131, 7444, 60, 16, 2, '2017-01-10', NULL, '', '0000-00-00', '', '2017-01-08 06:32:58'),
(132, 7447, 60, 422, 3, '2017-01-10', NULL, '', '0000-00-00', '', '2017-01-08 06:53:43'),
(133, 7443, 61, 26, 4, '2017-01-10', NULL, '', '0000-00-00', '', '2017-01-08 06:39:49'),
(134, 7447, 61, 434, 5, '2017-01-10', NULL, '', '0000-00-00', '', '2017-01-08 07:06:08'),
(135, 7447, 62, 440, 2, '2017-01-10', NULL, '', '0000-00-00', '', '2017-01-08 06:36:46'),
(136, 7444, 61, 26, 2, '2017-01-10', NULL, '', '0000-00-00', '', '2017-01-08 06:42:34'),
(137, 7445, 61, 26, 1, '2017-01-10', NULL, '', '0000-00-00', '', '2017-01-08 06:37:25'),
(138, 7447, 63, 451, 2, '2017-01-10', NULL, '', '0000-00-00', '', '2017-01-08 06:46:19'),
(139, 7443, 62, 30, 2, '2017-01-10', NULL, '', '0000-00-00', '', '2017-01-08 06:46:33'),
(140, 7445, 62, 30, 1, '2017-01-10', NULL, '', '0000-00-00', '', '2017-01-08 06:47:15'),
(141, 7444, 62, 30, 3, '2017-01-10', NULL, '', '0000-00-00', '', '2017-01-08 06:59:30'),
(142, 7445, 63, 40, 2, '2017-01-10', NULL, '', '0000-00-00', '', '2017-01-08 07:11:21'),
(143, 7444, 63, 40, 2, '2017-01-10', NULL, '', '0000-00-00', '', '2017-01-08 07:06:54'),
(144, 7443, 63, 40, 2, '2017-01-10', NULL, '', '0000-00-00', '', '2017-01-08 07:08:49'),
(145, 7444, 59, 2, 3, '2017-01-11', NULL, '', '0000-00-00', '', '2017-01-08 22:39:52'),
(146, 7443, 59, 2, 4, '2017-01-11', NULL, '', '0000-00-00', '', '2017-01-09 03:50:11'),
(147, 7445, 59, 2, 3, '2017-01-11', NULL, '', '0000-00-00', '', '2017-01-08 22:39:56'),
(148, 7447, 59, 416, 3, '2017-01-11', NULL, '', '0000-00-00', '', '2017-01-08 22:38:03'),
(149, 7447, 60, 425, 2, '2017-01-11', NULL, '', '0000-00-00', '', '2017-01-08 22:45:46'),
(150, 7445, 60, 11, 3, '2017-01-11', NULL, '', '0000-00-00', '', '2017-01-08 22:55:04'),
(151, 7444, 60, 11, 2, '2017-01-11', NULL, '', '0000-00-00', '', '2017-01-08 22:52:52'),
(152, 7443, 60, 11, 2, '2017-01-11', NULL, '', '0000-00-00', '', '2017-01-08 22:56:57'),
(153, 7447, 61, 437, 1, '2017-01-11', NULL, '', '0000-00-00', '', '2017-01-08 22:54:20'),
(154, 7444, 61, 21, 4, '2017-01-11', NULL, '', '0000-00-00', '', '2017-01-08 23:12:19'),
(155, 7445, 61, 21, 5, '2017-01-11', NULL, '', '0000-00-00', '', '2017-01-08 23:51:43'),
(156, 7447, 62, 444, 3, '2017-01-11', NULL, '', '0000-00-00', '', '2017-01-08 23:15:57'),
(157, 7443, 61, 21, 2, '2017-01-11', NULL, '', '0000-00-00', '', '2017-01-08 23:12:51'),
(158, 7444, 62, 33, 2, '2017-01-11', NULL, '', '0000-00-00', '', '2017-01-08 23:24:02'),
(159, 7443, 62, 33, 2, '2017-01-11', NULL, '', '0000-00-00', '', '2017-01-08 23:27:33'),
(160, 7447, 63, 451, 1, '2017-01-11', NULL, '', '0000-00-00', '', '2017-01-08 23:23:38'),
(161, 7444, 63, 39, 3, '2017-01-11', NULL, '', '0000-00-00', '', '2017-01-08 23:32:47'),
(162, 7445, 62, 33, 1, '2017-01-11', NULL, '', '0000-00-00', '', '2017-01-08 23:28:23'),
(163, 7445, 63, 39, 1, '2017-01-11', NULL, '', '0000-00-00', '', '2017-01-08 23:37:48'),
(164, 7443, 63, 39, 2, '2017-01-11', NULL, '', '0000-00-00', '', '2017-01-08 23:44:33'),
(165, 7447, 59, 419, 1, '2017-01-11', NULL, '', '0000-00-00', '', '2017-01-08 23:56:59'),
(166, 7447, 63, 453, 5, '2017-01-11', NULL, '', '0000-00-00', '', '2017-01-09 03:33:24'),
(167, 7445, 61, 20, 3, '2017-01-11', NULL, '', '0000-00-00', '', '2017-01-09 00:22:29'),
(168, 7444, 61, 20, 3, '2017-01-11', NULL, '', '0000-00-00', '', '2017-01-09 01:25:31'),
(169, 7443, 61, 20, 4, '2017-01-11', NULL, '', '0000-00-00', '', '2017-01-09 03:36:00'),
(170, 7447, 60, 422, 1, '2017-01-11', NULL, '', '0000-00-00', '', '2017-01-09 03:29:18'),
(171, 7447, 61, 433, 1, '2017-01-11', NULL, '', '0000-00-00', '', '2017-01-09 03:30:53'),
(172, 7447, 62, 440, 1, '2017-01-11', NULL, '', '0000-00-00', '', '2017-01-09 03:32:01'),
(173, 7444, 62, 30, 2, '2017-01-11', NULL, '', '0000-00-00', '', '2017-01-09 03:38:12'),
(174, 7445, 61, 19, 3, '2017-01-11', NULL, '', '0000-00-00', '', '2017-01-09 04:24:01'),
(175, 7443, 61, 19, 2, '2017-01-11', NULL, '', '0000-00-00', '', '2017-01-09 04:16:17'),
(176, 7444, 61, 19, 3, '2017-01-11', NULL, '', '0000-00-00', '', '2017-01-09 04:22:33'),
(177, 7443, 62, 29, 3, '2017-01-11', NULL, '', '0000-00-00', '', '2017-01-09 04:33:51'),
(178, 7433, 62, 34, 1, '2017-01-11', NULL, '', '0000-00-00', '', '2017-01-09 04:29:33'),
(179, 7441, 59, 7, 1, '2017-01-11', NULL, '', '0000-00-00', '', '2017-01-09 04:40:05'),
(180, 7444, 59, 7, 4, '2017-01-11', NULL, '', '0000-00-00', '', '2017-01-09 05:33:52'),
(181, 7444, 61, 24, 5, '2017-01-11', NULL, '', '0000-00-00', '', '2017-01-09 05:49:59'),
(182, 7444, 62, 34, 3, '2017-01-11', NULL, '', '0000-00-00', '', '2017-01-09 05:53:51'),
(183, 7444, 60, 15, 2, '2017-01-11', NULL, '', '0000-00-00', '', '2017-01-09 05:39:02'),
(184, 7444, 63, 35, 3, '2017-01-11', NULL, '', '0000-00-00', '', '2017-01-09 05:46:05'),
(185, 7445, 59, 8, 3, '2017-01-11', NULL, '', '0000-00-00', '', '2017-01-09 06:07:43'),
(186, 7443, 59, 8, 2, '2017-01-11', NULL, '', '0000-00-00', '', '2017-01-09 06:13:27'),
(187, 7444, 62, 27, 2, '2017-01-11', NULL, '', '0000-00-00', '', '2017-01-09 06:17:33'),
(188, 7447, 60, 428, 2, '2017-01-11', NULL, '', '0000-00-00', '', '2017-01-09 06:15:49'),
(189, 7445, 62, 27, 5, '2017-01-11', NULL, '', '0000-00-00', '', '2017-01-09 06:39:29'),
(190, 7447, 61, 435, 2, '2017-01-11', NULL, '', '0000-00-00', '', '2017-01-09 06:25:52'),
(191, 7444, 59, 8, 2, '2017-01-11', NULL, '', '0000-00-00', '', '2017-01-09 06:30:47'),
(192, 7443, 62, 27, 3, '2017-01-11', NULL, '', '0000-00-00', '', '2017-01-09 06:36:55'),
(193, 7445, 60, 18, 3, '2017-01-11', NULL, '', '0000-00-00', '', '2017-01-09 06:58:09'),
(194, 7444, 60, 18, 2, '2017-01-11', NULL, '', '0000-00-00', '', '2017-01-09 06:52:54'),
(195, 7443, 60, 18, 2, '2017-01-11', NULL, '', '0000-00-00', '', '2017-01-09 06:53:53'),
(196, 7444, 63, 37, 3, '2017-01-11', NULL, '', '0000-00-00', '', '2017-01-09 07:09:04'),
(197, 7443, 63, 37, 2, '2017-01-11', NULL, '', '0000-00-00', '', '2017-01-09 07:02:28'),
(198, 7445, 63, 37, 2, '2017-01-11', NULL, '', '0000-00-00', '', '2017-01-09 07:09:42'),
(199, 7447, 59, 418, 1, '2017-01-11', NULL, '', '0000-00-00', '', '2017-01-09 07:08:27'),
(200, 7447, 63, 450, 1, '2017-01-11', NULL, '', '0000-00-00', '', '2017-01-09 07:29:26'),
(201, 7447, 61, 430, 2, '2017-01-12', NULL, '', '0000-00-00', '', '2017-01-09 22:17:17'),
(202, 7447, 62, 439, 1, '2017-01-12', NULL, '', '0000-00-00', '', '2017-01-09 22:29:15'),
(203, 7443, 63, 38, 4, '2017-01-12', NULL, '', '0000-00-00', '', '2017-01-09 22:43:26'),
(204, 7445, 59, 6, 3, '2017-01-12', NULL, '', '0000-00-00', '', '2017-01-09 22:42:54'),
(205, 7444, 63, 38, 3, '2017-01-12', NULL, '', '0000-00-00', '', '2017-01-09 22:39:47'),
(206, 7447, 63, 452, 4, '2017-01-12', NULL, '', '0000-00-00', '', '2017-01-09 23:01:14'),
(207, 7444, 59, 3, 1, '2017-01-12', NULL, '', '0000-00-00', '', '2017-01-09 22:46:18'),
(208, 7443, 59, 3, 1, '2017-01-12', NULL, '', '0000-00-00', '', '2017-01-09 22:51:39'),
(209, 7444, 60, 10, 2, '2017-01-12', NULL, '', '0000-00-00', '', '2017-01-09 22:59:18'),
(210, 7445, 59, 3, 1, '2017-01-12', NULL, '', '0000-00-00', '', '2017-01-09 22:58:29'),
(211, 7444, 62, 29, 3, '2017-01-12', NULL, '', '0000-00-00', '', '2017-01-09 23:08:12'),
(212, 7443, 60, 10, 2, '2017-01-12', NULL, '', '0000-00-00', '', '2017-01-09 23:09:33'),
(213, 7445, 60, 10, 2, '2017-01-12', NULL, '', '0000-00-00', '', '2017-01-09 23:17:13'),
(214, 7445, 62, 29, 2, '2017-01-12', NULL, '', '0000-00-00', '', '2017-01-09 23:30:11'),
(215, 7447, 59, 417, 2, '2017-01-12', NULL, '', '0000-00-00', '', '2017-01-09 23:41:06'),
(216, 7445, 63, 38, 2, '2017-01-12', NULL, '', '0000-00-00', '', '2017-01-09 23:48:36'),
(217, 7447, 60, 429, 2, '2017-01-12', NULL, '', '0000-00-00', '', '2017-01-09 23:48:45'),
(218, 7450, 59, 417, 2, '2017-01-12', NULL, '', '0000-00-00', '', '2017-01-10 00:09:21'),
(219, 7448, 59, 417, 4, '2017-01-12', NULL, '', '0000-00-00', '', '2017-01-10 00:14:37'),
(220, 7447, 61, 431, 1, '2017-01-12', NULL, '', '0000-00-00', '', '2017-01-10 00:06:53'),
(221, 7449, 59, 417, 1, '2017-01-12', NULL, '', '0000-00-00', '', '2017-01-10 00:11:52'),
(222, 7450, 60, 429, 2, '2017-01-12', NULL, '', '0000-00-00', '', '2017-01-10 00:18:08'),
(223, 7449, 60, 429, 1, '2017-01-12', NULL, '', '0000-00-00', '', '2017-01-10 00:17:07'),
(224, 7448, 60, 429, 2, '2017-01-12', NULL, '', '0000-00-00', '', '2017-01-10 00:26:44'),
(225, 7449, 61, 431, 1, '2017-01-12', NULL, '', '0000-00-00', '', '2017-01-10 00:19:57'),
(226, 7450, 61, 431, 5, '2017-01-12', NULL, '', '0000-00-00', '', '2017-01-10 02:44:26'),
(227, 7447, 63, 449, 1, '2017-01-12', NULL, '', '0000-00-00', '', '2017-01-10 00:24:46'),
(228, 7448, 62, 441, 5, '2017-01-12', NULL, '', '0000-00-00', '', '2017-01-10 04:52:56'),
(229, 7447, 62, 441, 2, '2017-01-12', NULL, '', '0000-00-00', '', '2017-01-10 00:33:59'),
(230, 7450, 62, 441, 2, '2017-01-12', NULL, '', '0000-00-00', '', '2017-01-10 00:37:00'),
(231, 7448, 61, 431, 4, '2017-01-12', NULL, '', '0000-00-00', '', '2017-01-10 02:13:09'),
(232, 7449, 62, 441, 1, '2017-01-12', NULL, '', '0000-00-00', '', '2017-01-10 00:40:28'),
(233, 7450, 63, 449, 3, '2017-01-12', NULL, '', '0000-00-00', '', '2017-01-10 06:56:41'),
(234, 7449, 63, 449, 3, '2017-01-12', NULL, '', '0000-00-00', '', '2017-01-10 00:51:35'),
(235, 7448, 63, 449, 6, '2017-01-12', NULL, '', '0000-00-00', '', '2017-01-10 02:58:05'),
(236, 7448, 59, 415, 3, '2017-01-12', NULL, '', '0000-00-00', '', '2017-01-10 01:06:59'),
(237, 7447, 59, 415, 1, '2017-01-12', NULL, '', '0000-00-00', '', '2017-01-10 01:01:55'),
(238, 7450, 59, 415, 5, '2017-01-12', NULL, '', '0000-00-00', '', '2017-01-10 02:37:21'),
(239, 7449, 59, 415, 3, '2017-01-12', NULL, '', '0000-00-00', '', '2017-01-10 01:09:53'),
(240, 7447, 60, 427, 3, '2017-01-12', NULL, '', '0000-00-00', '', '2017-01-10 01:12:05'),
(241, 7450, 60, 427, 5, '2017-01-12', NULL, '', '0000-00-00', '', '2017-01-10 02:41:21'),
(242, 7448, 60, 427, 5, '2017-01-12', NULL, '', '0000-00-00', '', '2017-01-10 02:11:47'),
(243, 7449, 62, 438, 4, '2017-01-12', NULL, '', '0000-00-00', '', '2017-01-10 01:57:57'),
(244, 7448, 62, 438, 4, '2017-01-12', NULL, '', '0000-00-00', '', '2017-01-10 02:33:26'),
(245, 7447, 62, 438, 4, '2017-01-12', NULL, '', '0000-00-00', '', '2017-01-10 02:49:25'),
(246, 7450, 62, 438, 4, '2017-01-12', NULL, '', '0000-00-00', '', '2017-01-10 02:49:16'),
(247, 7449, 60, 427, 2, '2017-01-12', NULL, '', '0000-00-00', '', '2017-01-10 01:25:34'),
(248, 7450, 59, 414, 3, '2017-01-12', NULL, '', '0000-00-00', '', '2017-01-10 04:54:00'),
(249, 7448, 59, 414, 2, '2017-01-12', NULL, '', '0000-00-00', '', '2017-01-10 02:59:44'),
(250, 7446, 59, 3, 3, '2017-01-12', NULL, '', '0000-00-00', '', '2017-01-10 02:59:58'),
(251, 7449, 59, 414, 1, '2017-01-12', NULL, '', '0000-00-00', '', '2017-01-10 02:59:37'),
(252, 7450, 60, 424, 3, '2017-01-12', NULL, '', '0000-00-00', '', '2017-01-10 03:10:00'),
(253, 7448, 60, 424, 4, '2017-01-12', NULL, '', '0000-00-00', '', '2017-01-10 03:08:20'),
(254, 7449, 60, 424, 1, '2017-01-12', NULL, '', '0000-00-00', '', '2017-01-10 03:06:05'),
(255, 7446, 60, 10, 1, '2017-01-12', NULL, '', '0000-00-00', '', '2017-01-10 03:08:32'),
(256, 7450, 63, 452, 3, '2017-01-12', NULL, '', '0000-00-00', '', '2017-01-10 04:50:58'),
(257, 7448, 63, 452, 3, '2017-01-12', NULL, '', '0000-00-00', '', '2017-01-10 04:51:27'),
(258, 7446, 61, 19, 2, '2017-01-12', NULL, '', '0000-00-00', '', '2017-01-10 04:45:50'),
(259, 7449, 63, 452, 2, '2017-01-12', NULL, '', '0000-00-00', '', '2017-01-10 04:54:39'),
(260, 7446, 62, 29, 4, '2017-01-12', NULL, '', '0000-00-00', '', '2017-01-10 05:04:19'),
(261, 7448, 59, 420, 2, '2017-01-12', NULL, '', '0000-00-00', '', '2017-01-10 05:10:23'),
(262, 7449, 59, 420, 3, '2017-01-12', NULL, '', '0000-00-00', '', '2017-01-10 05:16:25'),
(263, 7450, 59, 420, 2, '2017-01-12', NULL, '', '0000-00-00', '', '2017-01-10 05:14:50'),
(264, 7446, 63, 38, 3, '2017-01-12', NULL, '', '0000-00-00', '', '2017-01-10 05:18:19'),
(265, 7448, 61, 434, 2, '2017-01-12', NULL, '', '0000-00-00', '', '2017-01-10 05:18:05'),
(266, 7450, 61, 434, 3, '2017-01-12', NULL, '', '0000-00-00', '', '2017-01-10 05:24:05'),
(267, 7449, 61, 434, 3, '2017-01-12', NULL, '', '0000-00-00', '', '2017-01-10 05:30:42'),
(268, 7448, 62, 439, 2, '2017-01-12', NULL, '', '0000-00-00', '', '2017-01-10 05:27:58'),
(269, 7450, 62, 439, 2, '2017-01-12', NULL, '', '0000-00-00', '', '2017-01-10 05:34:06'),
(270, 7448, 63, 447, 2, '2017-01-12', NULL, '', '0000-00-00', '', '2017-01-10 05:35:51'),
(271, 7449, 62, 439, 2, '2017-01-12', NULL, '', '0000-00-00', '', '2017-01-10 05:42:08'),
(272, 7450, 63, 447, 2, '2017-01-12', NULL, '', '0000-00-00', '', '2017-01-10 05:45:34'),
(273, 7449, 63, 447, 1, '2017-01-12', NULL, '', '0000-00-00', '', '2017-01-10 05:51:15'),
(274, 7449, 60, 423, 2, '2017-01-12', NULL, '', '0000-00-00', '', '2017-01-10 06:13:26'),
(275, 7450, 60, 423, 3, '2017-01-12', NULL, '', '0000-00-00', '', '2017-01-10 06:55:40'),
(276, 7446, 59, 1, 4, '2017-01-12', NULL, '', '0000-00-00', '', '2017-01-10 06:16:17'),
(277, 7448, 60, 423, 3, '2017-01-12', NULL, '', '0000-00-00', '', '2017-01-10 06:57:11'),
(278, 7450, 61, 430, 3, '2017-01-12', NULL, '', '0000-00-00', '', '2017-01-10 06:21:48'),
(279, 7449, 61, 430, 2, '2017-01-12', NULL, '', '0000-00-00', '', '2017-01-10 06:48:41'),
(280, 7448, 61, 430, 2, '2017-01-12', NULL, '', '0000-00-00', '', '2017-01-10 06:25:04'),
(281, 7449, 62, 445, 2, '2017-01-12', NULL, '', '0000-00-00', '', '2017-01-10 06:28:22'),
(282, 7446, 60, 17, 3, '2017-01-12', NULL, '', '0000-00-00', '', '2017-01-10 06:26:06'),
(283, 7450, 62, 445, 3, '2017-01-12', NULL, '', '0000-00-00', '', '2017-01-10 06:37:15'),
(284, 7448, 62, 445, 2, '2017-01-12', NULL, '', '0000-00-00', '', '2017-01-10 06:33:13'),
(285, 7448, 63, 446, 3, '2017-01-12', NULL, '', '0000-00-00', '', '2017-01-10 06:43:12'),
(286, 7450, 63, 446, 3, '2017-01-12', NULL, '', '0000-00-00', '', '2017-01-10 06:49:54'),
(287, 7449, 63, 446, 2, '2017-01-12', NULL, '', '0000-00-00', '', '2017-01-10 06:41:06'),
(288, 7446, 62, 28, 2, '2017-01-12', NULL, '', '0000-00-00', '', '2017-01-10 06:46:04'),
(289, 7446, 63, 41, 2, '2017-01-12', NULL, '', '0000-00-00', '', '2017-01-10 06:52:54'),
(290, 7450, 61, 436, 2, '2017-01-12', NULL, '', '0000-00-00', '', '2017-01-10 07:05:16'),
(291, 7448, 61, 436, 2, '2017-01-12', NULL, '', '0000-00-00', '', '2017-01-10 07:06:30'),
(292, 7449, 61, 436, 1, '2017-01-12', NULL, '', '0000-00-00', '', '2017-01-10 07:02:09'),
(293, 7446, 59, 6, 2, '2017-01-12', NULL, '', '0000-00-00', '', '2017-01-10 07:07:01'),
(294, 7446, 60, 9, 1, '2017-01-12', NULL, '', '0000-00-00', '', '2017-01-10 07:11:36'),
(295, 7450, 61, 433, 2, '2017-01-12', NULL, '', '0000-00-00', '', '2017-01-10 07:17:26'),
(296, 7448, 61, 433, 2, '2017-01-12', NULL, '', '0000-00-00', '', '2017-01-10 07:16:42'),
(297, 7449, 61, 433, 1, '2017-01-12', NULL, '', '0000-00-00', '', '2017-01-10 07:14:52'),
(298, 7446, 61, 21, 1, '2017-01-12', NULL, '', '0000-00-00', '', '2017-01-10 07:18:20'),
(299, 7448, 62, 440, 2, '2017-01-12', NULL, '', '0000-00-00', '', '2017-01-10 07:24:18'),
(300, 7450, 62, 440, 2, '2017-01-12', NULL, '', '0000-00-00', '', '2017-01-10 07:25:57'),
(301, 7449, 62, 440, 1, '2017-01-12', NULL, '', '0000-00-00', '', '2017-01-10 07:22:26'),
(302, 7446, 62, 33, 1, '2017-01-12', NULL, '', '0000-00-00', '', '2017-01-10 07:24:32'),
(303, 7448, 63, 450, 2, '2017-01-12', NULL, '', '0000-00-00', '', '2017-01-10 07:30:20'),
(304, 7446, 63, 36, 2, '2017-01-12', NULL, '', '0000-00-00', '', '2017-01-10 07:29:43'),
(305, 7450, 63, 450, 2, '2017-01-12', NULL, '', '0000-00-00', '', '2017-01-10 07:32:41'),
(306, 7449, 63, 450, 1, '2017-01-12', NULL, '', '0000-00-00', '', '2017-01-10 07:32:34'),
(307, 7446, 59, 8, 1, '2017-01-13', NULL, '', '0000-00-00', '', '2017-01-10 22:15:35'),
(308, 7448, 60, 425, 2, '2017-01-13', NULL, '', '0000-00-00', '', '2017-01-10 22:19:39'),
(309, 7450, 60, 425, 2, '2017-01-13', NULL, '', '0000-00-00', '', '2017-01-10 22:23:09'),
(310, 7449, 60, 425, 1, '2017-01-13', NULL, '', '0000-00-00', '', '2017-01-10 22:21:58'),
(311, 7448, 62, 443, 3, '2017-01-13', NULL, '', '0000-00-00', '', '2017-01-10 22:33:32'),
(312, 7450, 62, 443, 2, '2017-01-13', NULL, '', '0000-00-00', '', '2017-01-10 22:34:10'),
(313, 7446, 61, 26, 3, '2017-01-13', NULL, '', '0000-00-00', '', '2017-01-10 22:32:09'),
(314, 7449, 62, 443, 2, '2017-01-13', NULL, '', '0000-00-00', '', '2017-01-10 22:38:17'),
(315, 7446, 63, 40, 1, '2017-01-13', NULL, '', '0000-00-00', '', '2017-01-10 22:38:11'),
(316, 7448, 61, 430, 1, '2017-01-13', NULL, '', '0000-00-00', '', '2017-01-10 22:44:43'),
(317, 7446, 60, 18, 2, '2017-01-13', NULL, '', '0000-00-00', '', '2017-01-10 22:52:17'),
(318, 7448, 59, 419, 3, '2017-01-13', NULL, '', '0000-00-00', '', '2017-01-10 22:56:35'),
(319, 7449, 59, 419, 1, '2017-01-13', NULL, '', '0000-00-00', '', '2017-01-10 22:52:19'),
(320, 7450, 59, 419, 2, '2017-01-13', NULL, '', '0000-00-00', '', '2017-01-11 04:33:49'),
(321, 7446, 63, 37, 1, '2017-01-13', NULL, '', '0000-00-00', '', '2017-01-10 22:58:10'),
(322, 7450, 63, 448, 2, '2017-01-13', NULL, '', '0000-00-00', '', '2017-01-10 23:03:52'),
(323, 7449, 63, 448, 3, '2017-01-13', NULL, '', '0000-00-00', '', '2017-01-10 23:09:39'),
(324, 7448, 63, 448, 2, '2017-01-13', NULL, '', '0000-00-00', '', '2017-01-10 23:03:33'),
(325, 7441, 59, 3, 4, '2017-01-13', NULL, '', '0000-00-00', '', '2017-01-11 04:21:07'),
(326, 7441, 60, 9, 4, '2017-01-13', NULL, '', '0000-00-00', '', '2017-01-11 07:13:03'),
(327, 7441, 61, 23, 1, '2017-01-13', NULL, '', '0000-00-00', '', '2017-01-11 01:49:30'),
(328, 7441, 62, 28, 2, '2017-01-13', NULL, '', '0000-00-00', '', '2017-01-11 05:51:18'),
(329, 7441, 63, 38, 2, '2017-01-13', NULL, '', '0000-00-00', '', '2017-01-11 06:04:38'),
(330, 7446, 62, 28, 1, '2017-01-13', NULL, '', '0000-00-00', '', '2017-01-11 04:50:28'),
(331, 7448, 60, 427, 1, '2017-01-13', NULL, '', '0000-00-00', '', '2017-01-11 06:52:01'),
(332, 7448, 61, 435, 1, '2017-01-13', NULL, '', '0000-00-00', '', '2017-01-11 06:53:05'),
(333, 7448, 62, 441, 1, '2017-01-13', NULL, '', '0000-00-00', '', '2017-01-11 06:54:08'),
(334, 7446, 59, 2, 4, '2017-01-16', NULL, '', '0000-00-00', '', '2017-01-13 23:08:47'),
(335, 7441, 59, 2, 1, '2017-01-16', NULL, '', '0000-00-00', '', '2017-01-13 22:57:08'),
(336, 7441, 60, 11, 2, '2017-01-16', NULL, '', '0000-00-00', '', '2017-01-14 02:01:58'),
(337, 7446, 60, 11, 1, '2017-01-16', NULL, '', '0000-00-00', '', '2017-01-13 23:19:42'),
(338, 7441, 61, 21, 2, '2017-01-16', NULL, '', '0000-00-00', '', '2017-01-14 02:13:00'),
(339, 7441, 62, 31, 2, '2017-01-16', NULL, '', '0000-00-00', '', '2017-01-13 23:49:53'),
(340, 7446, 62, 31, 1, '2017-01-16', NULL, '', '0000-00-00', '', '2017-01-14 00:04:18'),
(341, 7441, 63, 39, 1, '2017-01-16', NULL, '', '0000-00-00', '', '2017-01-14 00:09:46'),
(342, 7446, 63, 39, 2, '2017-01-16', NULL, '', '0000-00-00', '', '2017-01-14 00:14:05'),
(343, 7441, 59, 5, 2, '2017-01-17', NULL, '', '0000-00-00', '', '2017-01-14 22:33:04'),
(344, 7441, 60, 15, 2, '2017-01-17', NULL, '', '0000-00-00', '', '2017-01-14 22:44:52'),
(345, 7441, 61, 24, 1, '2017-01-17', NULL, '', '0000-00-00', '', '2017-01-14 22:53:19'),
(346, 7441, 62, 32, 2, '2017-01-17', NULL, '', '0000-00-00', '', '2017-01-14 23:17:19'),
(347, 7441, 63, 41, 2, '2017-01-17', NULL, '', '0000-00-00', '', '2017-01-14 23:32:25'),
(348, 7441, 59, 7, 2, '2017-01-17', NULL, '', '0000-00-00', '', '2017-01-15 05:07:00'),
(349, 7448, 60, 422, 4, '2017-01-17', NULL, '', '0000-00-00', '', '2017-01-15 00:11:40'),
(350, 7441, 60, 16, 2, '2017-01-17', NULL, '', '0000-00-00', '', '2017-01-15 00:02:59'),
(351, 7450, 60, 422, 2, '2017-01-17', NULL, '', '0000-00-00', '', '2017-01-15 00:10:09'),
(352, 7441, 61, 19, 2, '2017-01-17', NULL, '', '0000-00-00', '', '2017-01-15 00:11:57'),
(353, 7446, 59, 7, 1, '2017-01-17', NULL, '', '0000-00-00', '', '2017-01-15 00:12:23'),
(354, 7441, 62, 27, 2, '2017-01-17', NULL, '', '0000-00-00', '', '2017-01-15 05:11:49'),
(355, 7449, 60, 422, 1, '2017-01-17', NULL, '', '0000-00-00', '', '2017-01-15 00:23:22'),
(356, 7446, 60, 16, 1, '2017-01-17', NULL, '', '0000-00-00', '', '2017-01-15 00:32:26'),
(357, 7448, 62, 33, 1, '2017-01-17', NULL, '', '0000-00-00', '', '2017-01-15 00:42:45'),
(358, 7448, 60, 423, 1, '2017-01-17', NULL, '', '0000-00-00', '', '2017-01-15 01:13:40'),
(359, 7448, 60, 425, 1, '2017-01-17', NULL, '', '0000-00-00', '', '2017-01-15 01:19:14'),
(360, 7441, 63, 36, 1, '2017-01-17', NULL, '', '0000-00-00', '', '2017-01-15 01:45:19'),
(361, 7448, 63, 452, 1, '2017-01-17', NULL, '', '0000-00-00', '', '2017-01-15 01:50:08'),
(362, 7448, 59, 419, 2, '2017-01-17', NULL, '', '0000-00-00', '', '2017-01-15 05:29:02'),
(363, 7441, 59, 4, 1, '2017-01-17', NULL, '', '0000-00-00', '', '2017-01-15 06:05:56'),
(364, 7441, 60, 12, 2, '2017-01-17', NULL, '', '0000-00-00', '', '2017-01-15 06:21:24'),
(365, 7448, 59, 4, 2, '2017-01-17', NULL, '', '0000-00-00', '', '2017-01-15 06:44:16'),
(366, 7441, 61, 20, 3, '2017-01-17', NULL, '', '0000-00-00', '', '2017-01-15 08:02:07'),
(367, 7441, 62, 30, 2, '2017-01-17', NULL, '', '0000-00-00', '', '2017-01-15 07:00:37'),
(368, 7441, 63, 42, 3, '2017-01-17', NULL, '', '0000-00-00', '', '2017-01-15 08:25:22'),
(369, 7451, 63, 499, 1, '2017-01-18', NULL, '', '0000-00-00', '', '2017-01-16 04:20:42'),
(370, 7441, 59, 6, 2, '2017-01-18', NULL, '', '0000-00-00', '', '2017-01-16 05:21:23'),
(371, 7441, 60, 10, 2, '2017-01-18', NULL, '', '0000-00-00', '', '2017-01-16 05:44:18'),
(372, 7441, 61, 22, 1, '2017-01-18', NULL, '', '0000-00-00', '', '2017-01-16 06:27:25'),
(373, 7441, 62, 34, 1, '2017-01-18', NULL, '', '0000-00-00', '', '2017-01-16 06:39:33'),
(374, 7446, 61, 22, 2, '2017-01-18', NULL, '', '0000-00-00', '', '2017-01-16 06:48:23'),
(375, 7446, 62, 34, 1, '2017-01-18', NULL, '', '0000-00-00', '', '2017-01-16 06:51:03'),
(376, 7441, 59, 8, 1, '2017-01-24', NULL, '', '0000-00-00', '', '2017-01-22 07:34:41'),
(377, 7441, 60, 9, 1, '2017-01-24', NULL, '', '0000-00-00', '', '2017-01-22 07:36:26'),
(378, 7441, 62, 33, 1, '2017-01-24', NULL, '', '0000-00-00', '', '2017-01-22 07:39:14'),
(379, 7450, 63, 449, 1, '2017-01-30', NULL, '', '0000-00-00', '', '2017-01-28 06:12:36');

-- --------------------------------------------------------

--
-- Table structure for table `user_login_log`
--

CREATE TABLE `user_login_log` (
  `ID` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `sessionid` varchar(255) NOT NULL,
  `created_date` datetime NOT NULL,
  `lastupdate` datetime NOT NULL,
  `logout_date` datetime NOT NULL,
  `ip` varchar(50) NOT NULL,
  `country` varchar(800) NOT NULL,
  `region` varchar(800) NOT NULL,
  `city` varchar(800) NOT NULL,
  `browser` text NOT NULL,
  `isp` text NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `user_newsfeed_history`
--

CREATE TABLE `user_newsfeed_history` (
  `ID` int(11) NOT NULL,
  `S_ID` int(11) NOT NULL COMMENT 'School ID',
  `G_ID` int(11) NOT NULL COMMENT 'Grad ID',
  `U_ID` int(11) NOT NULL COMMENT 'User ID',
  `Scenario` varchar(510) NOT NULL,
  `Datetime` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `user_parent_login_log`
--

CREATE TABLE `user_parent_login_log` (
  `ID` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `sessionid` varchar(255) NOT NULL,
  `created_date` datetime NOT NULL,
  `lastupdate` datetime NOT NULL,
  `logout_date` datetime NOT NULL,
  `ip` varchar(50) NOT NULL,
  `country` varchar(800) NOT NULL,
  `region` varchar(800) NOT NULL,
  `city` varchar(800) NOT NULL,
  `browser` text NOT NULL,
  `isp` text NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `user_referral`
--

CREATE TABLE `user_referral` (
  `rid` int(11) NOT NULL,
  `userID` int(11) NOT NULL,
  `name` varchar(110) NOT NULL,
  `pname` varchar(110) NOT NULL,
  `emailid` varchar(255) NOT NULL,
  `mobile` varchar(16) NOT NULL,
  `referred_on` datetime NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_referral`
--

INSERT INTO `user_referral` (`rid`, `userID`, `name`, `pname`, `emailid`, `mobile`, `referred_on`, `status`) VALUES
(1, 78, 'Sundar', 'Jeeva', 'sundarcse2k11@gmail.com', '9789120543', '2018-05-28 09:51:43', 0),
(2, 193, 'damu', 'mohan', 'damu.skillangels@gmail.com', '8807541983', '2018-05-28 09:53:44', 0),
(3, 199, 'Aruna', '', '', '9500964163', '2018-05-28 11:07:38', 0),
(4, 199, 'Aruna', '', '', '9443222251', '2018-05-28 11:08:27', 0),
(5, 259, 'Titiksha', 'Hema', 'Hematiti@gmail.com', '9840530691', '2018-05-28 22:43:56', 0),
(6, 259, 'Jitesh', 'Indumathi', 'Indhu@gmail.com', '9840447064', '2018-05-28 22:46:12', 0),
(7, 298, 'Titiksha', 'Hema', 'Hematiti18@gmail.com', '9840530691', '2018-05-28 23:54:05', 0),
(8, 298, 'Jitesh', 'Indu', 'Indian@gmail.com', '9840447064', '2018-05-28 23:57:36', 0);

-- --------------------------------------------------------

--
-- Table structure for table `user_section_limit`
--

CREATE TABLE `user_section_limit` (
  `id` int(11) NOT NULL,
  `class_id` int(11) NOT NULL,
  `school_admin_id` int(11) NOT NULL,
  `section` varchar(10) NOT NULL,
  `userlimit` int(11) NOT NULL,
  `status` int(1) NOT NULL,
  `createdby` varchar(100) NOT NULL,
  `creation_date` date NOT NULL,
  `modifiedby` varchar(100) NOT NULL,
  `modified_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_section_limit`
--

INSERT INTO `user_section_limit` (`id`, `class_id`, `school_admin_id`, `section`, `userlimit`, `status`, `createdby`, `creation_date`, `modifiedby`, `modified_date`) VALUES
(1, 3, 1, '1', 47, 0, '', '0000-00-00', '', '2014-06-23 23:53:45'),
(2, 3, 1, '2', 47, 0, '', '0000-00-00', '', '2014-06-23 23:53:45'),
(3, 3, 1, '3', 51, 0, '', '0000-00-00', '', '2014-06-23 23:53:45'),
(4, 4, 1, '4', 55, 0, '', '0000-00-00', '', '2014-06-23 23:53:45'),
(5, 4, 1, '5', 51, 0, '', '0000-00-00', '', '2014-06-23 23:53:45'),
(6, 4, 1, '6', 54, 0, '', '0000-00-00', '', '2014-06-23 23:53:45'),
(7, 5, 1, '7', 46, 0, '', '0000-00-00', '', '2014-06-23 23:53:45'),
(8, 5, 1, '8', 43, 0, '', '0000-00-00', '', '2014-06-23 23:53:45'),
(9, 5, 1, '9', 46, 0, '', '0000-00-00', '', '2014-06-23 23:53:45'),
(10, 6, 1, '10', 50, 0, '', '0000-00-00', '', '2014-06-23 23:53:45'),
(11, 6, 1, '11', 47, 0, '', '0000-00-00', '', '2014-06-23 23:53:45'),
(12, 6, 1, '12', 53, 0, '', '0000-00-00', '', '2014-06-23 23:53:45'),
(13, 7, 1, '13', 33, 0, '', '0000-00-00', '', '2014-06-23 23:53:45'),
(14, 7, 1, '14', 34, 0, '', '0000-00-00', '', '2014-06-23 23:53:45'),
(15, 7, 1, '15', 34, 0, '', '0000-00-00', '', '2014-06-23 23:53:45'),
(16, 7, 1, '16', 39, 0, '', '0000-00-00', '', '2014-06-23 23:53:45'),
(17, 8, 1, '17', 37, 0, '', '0000-00-00', '', '2014-06-23 23:53:45'),
(18, 8, 1, '18', 37, 0, '', '0000-00-00', '', '2014-06-23 23:53:45'),
(19, 8, 1, '19', 37, 0, '', '0000-00-00', '', '2014-06-23 23:53:45'),
(20, 8, 1, '20', 39, 0, '', '0000-00-00', '', '2014-06-23 23:53:45'),
(21, 9, 1, '21', 41, 0, '', '0000-00-00', '', '2014-06-23 23:53:45'),
(22, 9, 1, '22', 41, 0, '', '0000-00-00', '', '2014-06-23 23:53:45'),
(23, 9, 1, '23', 41, 0, '', '0000-00-00', '', '2014-06-23 23:53:45'),
(24, 9, 1, '24', 47, 0, '', '0000-00-00', '', '2014-06-23 23:53:45'),
(25, 10, 1, '25', 43, 0, '', '0000-00-00', '', '2014-06-23 23:53:45'),
(26, 10, 1, '26', 42, 0, '', '0000-00-00', '', '2014-06-23 23:53:45'),
(27, 10, 1, '27', 41, 0, '', '0000-00-00', '', '2014-06-23 23:53:45'),
(28, 10, 1, '28', 44, 0, '', '0000-00-00', '', '2014-06-23 23:53:45'),
(29, 5, 3, '7', 100, 0, '', '0000-00-00', '', '2014-06-24 00:01:18'),
(30, 6, 3, '10', 100, 0, '', '0000-00-00', '', '2014-06-24 00:01:27'),
(31, 7, 3, '13', 100, 0, '', '0000-00-00', '', '2014-06-24 00:01:33'),
(32, 5, 3, '29', 100, 0, '', '0000-00-00', '', '2014-06-24 00:03:31'),
(33, 6, 3, '30', 100, 0, '', '0000-00-00', '', '2014-06-24 00:06:25'),
(34, 7, 3, '31', 100, 0, '', '0000-00-00', '', '2014-06-24 00:06:47'),
(35, 1, 2, '32', 1000, 0, '', '0000-00-00', '', '2014-12-23 22:13:45'),
(36, 2, 2, '33', 1000, 0, '', '0000-00-00', '', '2014-12-23 22:13:01'),
(37, 3, 2, '34', 1000, 0, '', '0000-00-00', '', '2014-12-23 22:13:53'),
(38, 4, 2, '35', 1000, 0, '', '0000-00-00', '', '2014-12-23 22:14:01'),
(39, 5, 2, '7', 1000, 0, '', '0000-00-00', '', '2014-12-23 23:02:54'),
(40, 6, 2, '37', 1000, 0, '', '0000-00-00', '', '2014-12-23 22:14:14'),
(41, 7, 2, '38', 1000, 0, '', '0000-00-00', '', '2014-12-23 23:03:02'),
(42, 8, 2, '39', 1000, 0, '', '0000-00-00', '', '2014-12-23 22:14:28'),
(43, 9, 2, '40', 1000, 0, '', '0000-00-00', '', '2014-12-23 22:14:35'),
(44, 10, 2, '41', 1000, 0, '', '0000-00-00', '', '2014-12-23 22:14:42'),
(45, 5, 2, '36', 1000, 0, '', '0000-00-00', '', '2014-12-23 23:03:07'),
(46, 7, 2, '31', 1000, 0, '', '0000-00-00', '', '2014-12-23 23:03:11'),
(47, 5, 2, '29', 1000, 0, '', '0000-00-00', '', '2014-12-23 23:03:14'),
(48, 3, 5, '79', 29, 0, '', '0000-00-00', '', '2014-07-17 05:09:40'),
(49, 3, 5, '80', 28, 0, '', '0000-00-00', '', '2014-07-17 05:09:58'),
(50, 3, 5, '81', 26, 0, '', '0000-00-00', '', '2014-07-17 05:10:15'),
(51, 3, 5, '82', 27, 0, '', '0000-00-00', '', '2014-07-17 05:10:45'),
(52, 3, 5, '83', 26, 0, '', '0000-00-00', '', '2014-07-17 05:11:02'),
(53, 3, 5, '84', 26, 0, '', '0000-00-00', '', '2014-07-17 05:11:13'),
(54, 4, 5, '86', 28, 0, '', '0000-00-00', '', '2014-07-17 05:12:51'),
(55, 4, 5, '87', 28, 0, '', '0000-00-00', '', '2014-07-17 05:13:09'),
(56, 4, 5, '88', 29, 0, '', '0000-00-00', '', '2014-07-17 05:13:29'),
(57, 4, 5, '89', 27, 0, '', '0000-00-00', '', '2014-07-17 05:13:45'),
(58, 4, 5, '90', 28, 0, '', '0000-00-00', '', '2014-07-17 05:14:04'),
(59, 4, 5, '91', 29, 0, '', '0000-00-00', '', '2014-07-17 05:14:41'),
(60, 5, 5, '92', 27, 0, '', '0000-00-00', '', '2014-07-17 05:15:09'),
(61, 5, 5, '93', 27, 0, '', '0000-00-00', '', '2014-07-17 05:15:28'),
(62, 5, 5, '94', 28, 0, '', '0000-00-00', '', '2014-07-17 05:15:45'),
(63, 5, 5, '95', 28, 0, '', '0000-00-00', '', '2014-07-17 05:16:06'),
(64, 6, 5, '98', 28, 0, '', '0000-00-00', '', '2014-07-17 05:20:53'),
(65, 6, 5, '99', 29, 0, '', '0000-00-00', '', '2014-07-17 05:21:08'),
(66, 6, 5, '100', 25, 0, '', '0000-00-00', '', '2014-07-17 05:21:25'),
(67, 6, 5, '101', 28, 0, '', '0000-00-00', '', '2014-07-17 05:21:57'),
(68, 7, 5, '102', 28, 0, '', '0000-00-00', '', '2014-07-17 05:22:28'),
(69, 7, 5, '103', 29, 0, '', '0000-00-00', '', '2014-07-17 05:22:45'),
(70, 7, 5, '104', 28, 0, '', '0000-00-00', '', '2014-07-17 05:23:02'),
(71, 7, 5, '105', 21, 0, '', '0000-00-00', '', '2014-07-17 05:23:14'),
(72, 8, 5, '106', 23, 0, '', '0000-00-00', '', '2014-07-17 05:23:36'),
(73, 8, 5, '107', 26, 0, '', '0000-00-00', '', '2014-07-17 05:23:51'),
(74, 8, 5, '108', 27, 0, '', '0000-00-00', '', '2014-07-17 05:24:06'),
(75, 8, 5, '109', 25, 0, '', '0000-00-00', '', '2014-07-17 05:24:28'),
(76, 9, 5, '110', 31, 0, '', '0000-00-00', '', '2014-07-17 05:24:42'),
(77, 9, 5, '111', 28, 0, '', '0000-00-00', '', '2014-07-17 05:24:56'),
(78, 9, 5, '112', 29, 0, '', '0000-00-00', '', '2014-07-17 05:25:13'),
(79, 10, 5, '113', 34, 0, '', '0000-00-00', '', '2014-07-17 05:25:31'),
(80, 10, 5, '114', 32, 0, '', '0000-00-00', '', '2014-07-17 05:25:44'),
(81, 10, 5, '115', 34, 0, '', '0000-00-00', '', '2014-07-17 05:25:59'),
(82, 1, 6, '124', 50, 0, '', '0000-00-00', '', '2014-08-25 00:09:09'),
(83, 2, 6, '125', 50, 0, '', '0000-00-00', '', '2014-08-25 00:09:20'),
(84, 3, 6, '126', 50, 0, '', '0000-00-00', '', '2014-08-25 00:09:28'),
(85, 4, 6, '127', 50, 0, '', '0000-00-00', '', '2014-08-25 00:09:35'),
(86, 5, 6, '128', 50, 0, '', '0000-00-00', '', '2014-08-25 00:09:42'),
(87, 6, 6, '129', 50, 0, '', '0000-00-00', '', '2014-08-25 00:09:49'),
(88, 7, 6, '130', 50, 0, '', '0000-00-00', '', '2014-08-25 00:09:55'),
(89, 8, 6, '131', 50, 0, '', '0000-00-00', '', '2014-08-25 00:10:02'),
(90, 9, 6, '132', 50, 0, '', '0000-00-00', '', '2014-08-25 00:10:12'),
(91, 10, 6, '133', 50, 0, '', '0000-00-00', '', '2014-08-25 00:10:18'),
(92, 8, 8, '137', 50, 0, '', '0000-00-00', '', '2015-02-02 23:50:24'),
(93, 9, 8, '138', 50, 0, '', '0000-00-00', '', '2015-02-02 23:50:36'),
(94, 10, 8, '139', 50, 0, '', '0000-00-00', '', '2015-02-02 23:50:50'),
(95, 2, 9, '148', 5, 0, '', '0000-00-00', '', '2015-04-28 21:42:20'),
(96, 3, 9, '140', 5, 0, '', '0000-00-00', '', '2015-04-28 21:42:28'),
(97, 5, 9, '142', 5, 0, '', '0000-00-00', '', '2015-04-28 21:42:50'),
(98, 6, 9, '143', 30, 0, '', '0000-00-00', '', '2015-04-28 22:59:34'),
(99, 7, 9, '144', 8, 0, '', '0000-00-00', '', '2015-04-28 21:43:06'),
(100, 8, 9, '145', 8, 0, '', '0000-00-00', '', '2015-04-28 21:43:12'),
(101, 9, 9, '146', 8, 0, '', '0000-00-00', '', '2015-04-28 21:43:18'),
(102, 10, 9, '147', 8, 0, '', '0000-00-00', '', '2015-04-28 21:43:24'),
(103, 4, 9, '141', 30, 0, '', '0000-00-00', '', '2015-04-28 22:03:38'),
(104, 1, 10, '149', 100, 0, '', '0000-00-00', '', '2015-05-12 23:22:12'),
(105, 2, 10, '150', 100, 0, '', '0000-00-00', '', '2015-05-12 23:22:20'),
(106, 3, 10, '151', 100, 0, '', '0000-00-00', '', '2015-05-12 23:22:27'),
(107, 4, 10, '152', 100, 0, '', '0000-00-00', '', '2015-05-12 23:22:35'),
(108, 5, 10, '153', 100, 0, '', '0000-00-00', '', '2015-05-12 23:22:42'),
(109, 6, 10, '154', 100, 0, '', '0000-00-00', '', '2015-05-12 23:22:48'),
(110, 7, 10, '155', 100, 0, '', '0000-00-00', '', '2015-05-12 23:22:54'),
(111, 8, 10, '156', 100, 0, '', '0000-00-00', '', '2015-05-12 23:23:00'),
(112, 9, 10, '157', 100, 0, '', '0000-00-00', '', '2015-05-12 23:23:08'),
(113, 10, 10, '158', 100, 0, '', '0000-00-00', '', '2015-05-12 23:23:15'),
(114, 1, 11, '159', 100, 0, '', '0000-00-00', '', '2015-05-13 11:42:09'),
(115, 2, 11, '160', 100, 0, '', '0000-00-00', '', '2015-05-13 11:42:15'),
(116, 3, 11, '161', 100, 0, '', '0000-00-00', '', '2015-05-13 11:42:21'),
(117, 4, 11, '162', 100, 0, '', '0000-00-00', '', '2015-05-13 11:42:27'),
(118, 5, 11, '163', 100, 0, '', '0000-00-00', '', '2015-05-13 11:42:32'),
(119, 6, 11, '164', 100, 0, '', '0000-00-00', '', '2015-05-13 11:42:38'),
(120, 7, 11, '165', 100, 0, '', '0000-00-00', '', '2015-05-13 11:42:44'),
(121, 8, 11, '166', 100, 0, '', '0000-00-00', '', '2015-05-13 11:42:50'),
(122, 9, 11, '167', 100, 0, '', '0000-00-00', '', '2015-05-13 11:42:56'),
(123, 10, 11, '168', 100, 0, '', '0000-00-00', '', '2015-05-13 11:43:01'),
(124, 7, 12, '169', 60, 0, '', '0000-00-00', '', '2015-08-03 00:10:35'),
(125, 7, 12, '170', 60, 0, '', '0000-00-00', '', '2015-08-03 00:10:44'),
(126, 7, 12, '171', 60, 0, '', '0000-00-00', '', '2015-08-03 00:10:49'),
(127, 7, 12, '172', 60, 0, '', '0000-00-00', '', '2015-08-03 00:11:00'),
(128, 7, 12, '173', 60, 0, '', '0000-00-00', '', '2015-08-03 00:11:06'),
(129, 8, 12, '174', 60, 0, '', '0000-00-00', '', '2015-08-03 00:11:14'),
(130, 8, 12, '175', 60, 0, '', '0000-00-00', '', '2015-08-03 00:11:20'),
(131, 8, 12, '176', 60, 0, '', '0000-00-00', '', '2015-08-03 00:11:27'),
(132, 8, 12, '177', 60, 0, '', '0000-00-00', '', '2015-08-03 00:11:33'),
(133, 8, 12, '178', 60, 0, '', '0000-00-00', '', '2015-08-03 00:11:40'),
(134, 9, 12, '179', 60, 0, '', '0000-00-00', '', '2015-08-03 00:11:46'),
(135, 9, 12, '180', 60, 0, '', '0000-00-00', '', '2015-08-03 00:11:52'),
(136, 9, 12, '181', 60, 0, '', '0000-00-00', '', '2015-08-03 00:11:58'),
(137, 9, 12, '182', 60, 0, '', '0000-00-00', '', '2015-08-03 00:12:05'),
(138, 10, 12, '183', 60, 0, '', '0000-00-00', '', '2015-08-03 00:12:13'),
(139, 10, 12, '184', 60, 0, '', '0000-00-00', '', '2015-08-03 00:12:19'),
(140, 10, 12, '185', 60, 0, '', '0000-00-00', '', '2015-08-03 00:12:25'),
(141, 10, 12, '186', 60, 0, '', '0000-00-00', '', '2015-08-03 00:12:31'),
(142, 6, 14, '187', 100, 0, '', '0000-00-00', '', '2016-05-09 23:40:59'),
(143, 7, 14, '188', 100, 0, '', '0000-00-00', '', '2016-05-09 23:41:07'),
(144, 8, 14, '189', 100, 0, '', '0000-00-00', '', '2016-05-09 23:41:14'),
(145, 9, 14, '190', 100, 0, '', '0000-00-00', '', '2016-05-09 23:41:25'),
(146, 10, 14, '191', 100, 0, '', '0000-00-00', '', '2016-05-09 23:41:31'),
(147, 1, 16, '192', 100, 0, '', '0000-00-00', '', '2016-07-20 07:46:49'),
(148, 2, 16, '193', 100, 0, '', '0000-00-00', '', '2016-07-20 07:46:56'),
(149, 3, 16, '194', 100, 0, '', '0000-00-00', '', '2016-07-20 07:47:01'),
(150, 4, 16, '195', 100, 0, '', '0000-00-00', '', '2016-07-20 07:47:08'),
(151, 5, 16, '196', 100, 0, '', '0000-00-00', '', '2016-07-20 07:47:14'),
(152, 6, 16, '197', 100, 0, '', '0000-00-00', '', '2016-07-20 07:47:30'),
(153, 7, 16, '198', 100, 0, '', '0000-00-00', '', '2016-07-20 07:47:36'),
(154, 8, 16, '199', 100, 0, '', '0000-00-00', '', '2016-07-20 07:47:43'),
(155, 9, 16, '200', 100, 0, '', '0000-00-00', '', '2016-07-20 07:47:50'),
(156, 10, 16, '201', 100, 0, '', '0000-00-00', '', '2016-07-20 07:47:56');

-- --------------------------------------------------------

--
-- Table structure for table `user_sparkies_history`
--

CREATE TABLE `user_sparkies_history` (
  `ID` int(11) NOT NULL,
  `S_ID` int(11) NOT NULL COMMENT 'School_id',
  `G_ID` int(11) NOT NULL COMMENT 'Grade_ID',
  `U_ID` int(11) NOT NULL COMMENT 'User_id',
  `Scenario_ID` varchar(255) NOT NULL,
  `Type` enum('REGULAR','BONUS') NOT NULL,
  `Points` int(11) NOT NULL,
  `Datetime` datetime NOT NULL,
  `Gameid` int(11) NOT NULL,
  `ScenarioCode` varchar(55) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `utilizationreport`
--

CREATE TABLE `utilizationreport` (
  `id` int(11) NOT NULL,
  `weekval` int(11) NOT NULL,
  `weekvaldate` varchar(110) NOT NULL,
  `period_date` date NOT NULL,
  `period_no` varchar(55) NOT NULL,
  `starttime` varchar(55) NOT NULL,
  `endtime` varchar(55) NOT NULL,
  `gradeid` int(11) NOT NULL,
  `section` varchar(55) NOT NULL,
  `totalusers` int(11) NOT NULL COMMENT 'expected_user',
  `attenusers` int(11) NOT NULL,
  `completeduser` int(11) NOT NULL,
  `avgbspi` varchar(55) NOT NULL,
  `monthno` varchar(55) NOT NULL,
  `year` int(11) NOT NULL,
  `sid` int(11) NOT NULL,
  `academicid` int(11) NOT NULL,
  `total_user` int(11) NOT NULL,
  `sessiondivision` varchar(55) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Stand-in structure for view `vii_1dayskillcorebymon`
-- (See below for the actual view)
--
CREATE TABLE `vii_1dayskillcorebymon` (
`score` double(19,2)
,`gu_id` int(10)
,`gs_id` int(10)
,`sid` varchar(100)
,`grade_id` int(10)
,`section` varchar(10)
,`monthNumber` varchar(2)
,`monofyear` int(4)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `vii_1dayskillscore`
-- (See below for the actual view)
--
CREATE TABLE `vii_1dayskillscore` (
`score` double
,`gs_id` int(10)
,`gu_id` int(10)
,`sid` varchar(100)
,`grade_id` int(10)
,`section` varchar(10)
,`lastupdate` date
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `vii_1dayuserscore`
-- (See below for the actual view)
--
CREATE TABLE `vii_1dayuserscore` (
`score` double
,`gu_id` int(10)
,`gs_id` int(10)
,`sid` varchar(100)
,`grade_id` int(10)
,`section` varchar(10)
,`lastupdate` date
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `vii_avguserbspiscore`
-- (See below for the actual view)
--
CREATE TABLE `vii_avguserbspiscore` (
`finalscore` double(19,2)
,`gu_id` int(10)
,`sid` varchar(100)
,`grade_id` int(10)
,`section` varchar(10)
,`username` varchar(255)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `vii_avguserbspiscorebymon`
-- (See below for the actual view)
--
CREATE TABLE `vii_avguserbspiscorebymon` (
`finalscore` double(19,2)
,`gu_id` int(10)
,`sid` varchar(100)
,`grade_id` int(10)
,`section` varchar(10)
,`username` varchar(255)
,`monthNumber` varchar(2)
,`monofyear` int(4)
,`monthName` varchar(9)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `vii_bspigradetoppersbysec`
-- (See below for the actual view)
--
CREATE TABLE `vii_bspigradetoppersbysec` (
`bspi` double(19,2)
,`gu_id` int(10)
,`monthNumber` varchar(2)
,`monofyear` int(4)
,`sid` varchar(100)
,`grade_id` int(10)
,`section` varchar(10)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `vii_daywiseuserbspiscore`
-- (See below for the actual view)
--
CREATE TABLE `vii_daywiseuserbspiscore` (
`finalscore` double(19,2)
,`gu_id` int(10)
,`sid` varchar(100)
,`grade_id` int(10)
,`section` varchar(10)
,`username` varchar(255)
,`lastupdate` date
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `vii_overallbspitoppers`
-- (See below for the actual view)
--
CREATE TABLE `vii_overallbspitoppers` (
`bspi` double(19,2)
,`gu_id` int(10)
,`sid` varchar(100)
,`grade_id` int(10)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `vii_topbspiscore`
-- (See below for the actual view)
--
CREATE TABLE `vii_topbspiscore` (
`bspi` double(19,2)
,`gu_id` int(10)
,`monthNumber` varchar(2)
,`monofyear` int(4)
,`sid` varchar(100)
,`grade_id` int(10)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `vii_topsuperangels`
-- (See below for the actual view)
--
CREATE TABLE `vii_topsuperangels` (
`ans` double
,`gu_id` int(10)
,`monthName` varchar(32)
,`monthNumber` varchar(2)
,`monofyear` int(4)
,`gs_ID` varchar(100)
,`grad_ID` bigint(11)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `vii_user1dayskillscore`
-- (See below for the actual view)
--
CREATE TABLE `vii_user1dayskillscore` (
`score` double
,`gs_id` int(10)
,`gu_id` int(10)
,`lastupdate` date
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `vii_usercurrentbspi`
-- (See below for the actual view)
--
CREATE TABLE `vii_usercurrentbspi` (
`gu_id` int(10)
,`score` double(19,2)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `vii_userskillscorebydate`
-- (See below for the actual view)
--
CREATE TABLE `vii_userskillscorebydate` (
`score` double(19,2)
,`gu_id` int(10)
,`gs_id` int(10)
,`sid` varchar(100)
,`grade_id` int(10)
,`section` varchar(10)
,`lastupdate` date
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `vi_1dayskillscore`
-- (See below for the actual view)
--
CREATE TABLE `vi_1dayskillscore` (
`score` double(19,2)
,`gu_id` int(10)
,`gs_id` int(10)
,`lastupdate` date
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `vi_1dayuserscore`
-- (See below for the actual view)
--
CREATE TABLE `vi_1dayuserscore` (
`score` double(19,2)
,`gu_id` int(10)
,`lastupdate` date
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `vi_avgofbspi`
-- (See below for the actual view)
--
CREATE TABLE `vi_avgofbspi` (
`score` double(19,2)
,`gu_id` int(10)
,`lastupdate` date
,`sid` varchar(100)
,`grade_id` int(10)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `vi_avguserbspiscore`
-- (See below for the actual view)
--
CREATE TABLE `vi_avguserbspiscore` (
`bspi` double(19,2)
,`gu_id` int(10)
,`monthNumber` int(2)
,`monthName` varchar(32)
,`sid` varchar(100)
,`grade_id` int(10)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `vi_diamond`
-- (See below for the actual view)
--
CREATE TABLE `vi_diamond` (
`userid` int(100)
,`UserName` varchar(201)
,`school_id` varchar(100)
,`Grade` varchar(100)
,`MONTH` int(2)
,`DMEMORY` double(17,0)
,`DVP` double(17,0)
,`DFA` double(17,0)
,`DPS` double(17,0)
,`DLG` double(17,0)
,`dtotal` double(17,0)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `vi_focusandattention`
-- (See below for the actual view)
--
CREATE TABLE `vi_focusandattention` (
`Grade` varchar(100)
,`user_section` varchar(10)
,`UserID` int(100)
,`school_id` varchar(100)
,`UserName` varchar(201)
,`Date` date
,`Memory` binary(0)
,`Visual Processing` binary(0)
,`FocusAndAttention` varchar(50)
,`ProblemSolving` binary(0)
,`Lingustics` binary(0)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `vi_focusandattentionstar`
-- (See below for the actual view)
--
CREATE TABLE `vi_focusandattentionstar` (
`Grade` varchar(100)
,`user_section` varchar(10)
,`UserID` int(100)
,`school_id` varchar(100)
,`UserName` varchar(201)
,`Date` date
,`Memory` binary(0)
,`Visual Processing` binary(0)
,`FocusAndAttention` double(17,0)
,`ProblemSolving` binary(0)
,`Lingustics` binary(0)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `vi_gameplayed`
-- (See below for the actual view)
--
CREATE TABLE `vi_gameplayed` (
`countofval` bigint(21)
,`monthName` varchar(32)
,`monofyear` int(4)
,`monthNumber` varchar(2)
,`school_id` varchar(100)
,`grad_id` bigint(11)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `vi_gold`
-- (See below for the actual view)
--
CREATE TABLE `vi_gold` (
`userid` int(100)
,`UserName` varchar(201)
,`school_id` varchar(100)
,`Grade` varchar(100)
,`MONTH` int(2)
,`GMEMORY` double(17,0)
,`GVP` double(17,0)
,`GFA` double(17,0)
,`GPS` double(17,0)
,`GLG` double(17,0)
,`gtotal` double(17,0)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `vi_gradeskillpivot`
-- (See below for the actual view)
--
CREATE TABLE `vi_gradeskillpivot` (
`Grade` varchar(100)
,`user_section` varchar(10)
,`UserID` int(100)
,`UserName` varchar(201)
,`date` date
,`school_id` varchar(100)
,`Memory` double
,`Visual Processing` double
,`Focus And Attention` double
,`Problem Solving` double
,`Linguistics` double
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `vi_gradeskillpivotsource`
-- (See below for the actual view)
--
CREATE TABLE `vi_gradeskillpivotsource` (
`Grade` varchar(100)
,`user_section` varchar(10)
,`UserID` int(100)
,`UserName` varchar(201)
,`date` date
,`school_id` varchar(100)
,`Memory` varchar(50)
,`vp` varchar(50)
,`FocusAndAttention` varchar(50)
,`ProblemSolving` varchar(50)
,`Lingustics` varchar(50)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `vi_lingustics`
-- (See below for the actual view)
--
CREATE TABLE `vi_lingustics` (
`Grade` varchar(100)
,`user_section` varchar(10)
,`UserID` int(100)
,`school_id` varchar(100)
,`UserName` varchar(201)
,`Date` date
,`Memory` binary(0)
,`Visual Processing` binary(0)
,`FocusAndAttention` binary(0)
,`ProblemSolving` binary(0)
,`Lingustics` varchar(50)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `vi_lingusticsstar`
-- (See below for the actual view)
--
CREATE TABLE `vi_lingusticsstar` (
`Grade` varchar(100)
,`user_section` varchar(10)
,`UserID` int(100)
,`school_id` varchar(100)
,`UserName` varchar(201)
,`Date` date
,`Memory` binary(0)
,`Visual Processing` binary(0)
,`FocusAndAttention` binary(0)
,`ProblemSolving` binary(0)
,`Lingustics` double(17,0)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `vi_maxbspibymsg`
-- (See below for the actual view)
--
CREATE TABLE `vi_maxbspibymsg` (
`bspi` double(19,2)
,`gu_id` int(10)
,`monthNumber` int(2)
,`sid` varchar(100)
,`grade_id` int(10)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `vi_maxfcrownypoints`
-- (See below for the actual view)
--
CREATE TABLE `vi_maxfcrownypoints` (
`points` decimal(32,0)
,`S_ID` int(11)
,`G_ID` int(11)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `vi_memory`
-- (See below for the actual view)
--
CREATE TABLE `vi_memory` (
`Grade` varchar(100)
,`user_section` varchar(10)
,`UserID` int(100)
,`school_id` varchar(100)
,`UserName` varchar(201)
,`Date` date
,`Memory` varchar(50)
,`VP` binary(0)
,`FocusAndAttention` binary(0)
,`ProblemSolving` binary(0)
,`Lingustics` binary(0)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `vi_memorystar`
-- (See below for the actual view)
--
CREATE TABLE `vi_memorystar` (
`Grade` varchar(100)
,`user_section` varchar(10)
,`UserID` int(100)
,`school_id` varchar(100)
,`UserName` varchar(201)
,`Date` date
,`Memory` double(17,0)
,`VP` binary(0)
,`FocusAndAttention` binary(0)
,`ProblemSolving` binary(0)
,`Lingustics` binary(0)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `vi_monthwisebspi`
-- (See below for the actual view)
--
CREATE TABLE `vi_monthwisebspi` (
`bspi` double(19,2)
,`monthNumber` int(2)
,`monthName` varchar(32)
,`sid` varchar(100)
,`grade_id` int(10)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `vi_overallbspitoppers`
-- (See below for the actual view)
--
CREATE TABLE `vi_overallbspitoppers` (
`bspi` double(19,2)
,`gu_id` int(10)
,`lastupdate` date
,`sid` varchar(100)
,`grade_id` int(10)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `vi_overallcrownytoppers`
-- (See below for the actual view)
--
CREATE TABLE `vi_overallcrownytoppers` (
`points` decimal(32,0)
,`G_ID` int(11)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `vi_overallsparkytopper`
-- (See below for the actual view)
--
CREATE TABLE `vi_overallsparkytopper` (
`points` decimal(32,0)
,`monthName` varchar(32)
,`monthNumber` varchar(2)
,`G_ID` int(11)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `vi_problemsolving`
-- (See below for the actual view)
--
CREATE TABLE `vi_problemsolving` (
`Grade` varchar(100)
,`user_section` varchar(10)
,`UserID` int(100)
,`school_id` varchar(100)
,`UserName` varchar(201)
,`Date` date
,`Memory` binary(0)
,`Visual Processing` binary(0)
,`FocusAndAttention` binary(0)
,`ProblemSolving` varchar(50)
,`Lingustics` binary(0)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `vi_problemsolvingstar`
-- (See below for the actual view)
--
CREATE TABLE `vi_problemsolvingstar` (
`Grade` varchar(100)
,`user_section` varchar(10)
,`UserID` int(100)
,`school_id` varchar(100)
,`UserName` varchar(201)
,`Date` date
,`Memory` binary(0)
,`Visual Processing` binary(0)
,`FocusAndAttention` binary(0)
,`ProblemSolving` double(17,0)
,`Lingustics` binary(0)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `vi_silver`
-- (See below for the actual view)
--
CREATE TABLE `vi_silver` (
`userid` int(100)
,`UserName` varchar(201)
,`school_id` varchar(100)
,`Grade` varchar(100)
,`MONTH` int(2)
,`SMEMORY` double(17,0)
,`SVP` double(17,0)
,`SFA` double(17,0)
,`SPS` double(17,0)
,`SLG` double(17,0)
,`stotal` double(17,0)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `vi_star`
-- (See below for the actual view)
--
CREATE TABLE `vi_star` (
`userid` int(100)
,`UserName` varchar(201)
,`school_id` varchar(100)
,`Grade` varchar(100)
,`date` date
,`MEMORYSTAR` double(17,0)
,`VPSTAR` double(17,0)
,`FASTAR` double(17,0)
,`PSSTAR` double(17,0)
,`LGSTAR` double(17,0)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `vi_sumofcrownypoints`
-- (See below for the actual view)
--
CREATE TABLE `vi_sumofcrownypoints` (
`U_ID` int(11)
,`S_ID` int(11)
,`G_ID` int(11)
,`points` decimal(32,0)
,`section` varchar(10)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `vi_sumofcrownypoints1`
-- (See below for the actual view)
--
CREATE TABLE `vi_sumofcrownypoints1` (
`U_ID` int(11)
,`S_ID` int(11)
,`G_ID` int(11)
,`points` decimal(32,0)
,`section` varchar(10)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `vi_toppersbspi`
-- (See below for the actual view)
--
CREATE TABLE `vi_toppersbspi` (
`bspi` double(19,2)
,`monthNumber` int(2)
,`monthName` varchar(32)
,`sid` varchar(100)
,`grade_id` int(10)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `vi_totgamesplayed`
-- (See below for the actual view)
--
CREATE TABLE `vi_totgamesplayed` (
`countofplayed` bigint(21)
,`gu_id` int(10)
,`monthName` varchar(32)
,`monthNumber` varchar(2)
,`monofyear` int(4)
,`gs_ID` varchar(100)
,`grad_ID` bigint(11)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `vi_trophies`
-- (See below for the actual view)
--
CREATE TABLE `vi_trophies` (
`userid` int(100)
,`UserName` varchar(201)
,`school_id` varchar(100)
,`Grade` varchar(100)
,`MONTH` int(2)
,`DIAMOND` double(17,0)
,`GOLD` double(17,0)
,`SILVER` double(17,0)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `vi_vp`
-- (See below for the actual view)
--
CREATE TABLE `vi_vp` (
`Grade` varchar(100)
,`user_section` varchar(10)
,`UserID` int(100)
,`school_id` varchar(100)
,`UserName` varchar(201)
,`Date` date
,`Memory` binary(0)
,`Visual Processing` varchar(50)
,`FocusAndAttention` binary(0)
,`ProblemSolving` binary(0)
,`Lingustics` binary(0)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `vi_vpstar`
-- (See below for the actual view)
--
CREATE TABLE `vi_vpstar` (
`Grade` varchar(100)
,`user_section` varchar(10)
,`UserID` int(100)
,`school_id` varchar(100)
,`UserName` varchar(201)
,`Date` date
,`Memory` binary(0)
,`Visual Processing` double(17,0)
,`FocusAndAttention` binary(0)
,`ProblemSolving` binary(0)
,`Lingustics` binary(0)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `vv1`
-- (See below for the actual view)
--
CREATE TABLE `vv1` (
`U_ID` int(11)
,`S_ID` int(11)
,`G_ID` int(11)
,`points` decimal(32,0)
,`monthName` varchar(32)
,`monthNumber` varchar(2)
,`monofyear` int(4)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `vv2`
-- (See below for the actual view)
--
CREATE TABLE `vv2` (
`points` decimal(32,0)
,`monthName` varchar(32)
,`monthNumber` varchar(2)
,`S_ID` int(11)
,`G_ID` int(11)
,`monofyear` int(4)
);

-- --------------------------------------------------------

--
-- Structure for view `gamedata_updated`
--
DROP TABLE IF EXISTS `gamedata_updated`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `gamedata_updated`  AS  select `gamescore`.`id` AS `id`,`gamescore`.`userid` AS `gu_id`,`gamescore`.`gp_id` AS `gp_id`,`gamescore`.`gc_id` AS `gc_id`,`gamescore`.`skillid` AS `gs_id`,`gamescore`.`gameid` AS `g_id`,10 AS `total_question`,count(0) AS `attempt_question`,sum(if((`gamescore`.`answerstatus` = 'C'),1,0)) AS `answer`,sum(`gamescore`.`score`) AS `game_score`,min(`gamescore`.`timervalue`) AS `gtime`,sum(`gamescore`.`responsetime`) AS `rtime`,sum(if((`gamescore`.`answerstatus` = 'C'),`gamescore`.`responsetime`,0)) AS `crtime`,sum(if((`gamescore`.`answerstatus` = 'W'),`gamescore`.`responsetime`,0)) AS `wrtime`,cast(`gamescore`.`updateddate` as date) AS `lastupdate`,`gamescore`.`iteration` AS `iteration` from `gamescore` group by `gamescore`.`iteration`,`gamescore`.`gameid`,`gamescore`.`skillid`,`gamescore`.`userid`,`gamescore`.`gc_id`,`gamescore`.`gp_id`,cast(`gamescore`.`updateddate` as date) ;

-- --------------------------------------------------------

--
-- Structure for view `game_reports`
--
DROP TABLE IF EXISTS `game_reports`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `game_reports`  AS  select `gamedata`.`id` AS `id`,`gamedata`.`gu_id` AS `gu_id`,`gamedata`.`gp_id` AS `gp_id`,`gamedata`.`gc_id` AS `gc_id`,`gamedata`.`gs_id` AS `gs_id`,(select `game_group_mapping`.`groupid` from `game_group_mapping` where ((`game_group_mapping`.`gid` = `gamedata`.`g_id`) and (`game_group_mapping`.`org_id` = 1)) limit 1) AS `groupid`,`gamedata`.`g_id` AS `g_id`,`gamedata`.`total_question` AS `total_question`,`gamedata`.`attempt_question` AS `attempt_question`,`gamedata`.`answer` AS `answer`,`gamedata`.`game_score` AS `game_score`,`gamedata`.`gtime` AS `gtime`,`gamedata`.`rtime` AS `rtime`,`gamedata`.`crtime` AS `crtime`,`gamedata`.`wrtime` AS `wrtime`,`gamedata`.`lastupdate` AS `lastupdate`,`gamedata`.`star` AS `star`,`gamedata`.`puzzle_cycle` AS `puzzle_cycle`,`gamedata`.`site_type` AS `site_type` from `gamedata` ;

-- --------------------------------------------------------

--
-- Structure for view `playedques`
--
DROP TABLE IF EXISTS `playedques`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `playedques`  AS  select `user_challenge_table`.`userid` AS `userid`,group_concat(`user_challenge_table`.`challengeid` separator ',') AS `quesPlayed` from `user_challenge_table` group by `user_challenge_table`.`userid` ;

-- --------------------------------------------------------

--
-- Structure for view `popupstar`
--
DROP TABLE IF EXISTS `popupstar`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `popupstar`  AS  select `gr`.`gu_id` AS `gu_id`,`gr`.`lastupdate` AS `lastupdate`,`cs`.`id` AS `cat_id`,`cs`.`name` AS `name`,round((avg(`gr`.`game_score`) / 20),0) AS `ct` from (`game_reports` `gr` join `category_skills` `cs`) where ((extract(month from `gr`.`lastupdate`) = extract(month from curdate())) and (extract(year from `gr`.`lastupdate`) = extract(year from curdate())) and (`cs`.`id` = `gr`.`gs_id`)) group by `gr`.`lastupdate`,`cs`.`id`,`cs`.`name`,`gr`.`gu_id` ;

-- --------------------------------------------------------

--
-- Structure for view `popupstargreaterthanninty`
--
DROP TABLE IF EXISTS `popupstargreaterthanninty`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `popupstargreaterthanninty`  AS  select `gr`.`gu_id` AS `gu_id`,`gr`.`lastupdate` AS `lastupdate`,`cs`.`id` AS `cat_id`,`cs`.`name` AS `name`,round((avg(`gr`.`game_score`) / 20),0) AS `ct` from (`game_reports` `gr` join `category_skills` `cs`) where ((extract(month from `gr`.`lastupdate`) = extract(month from curdate())) and (extract(year from `gr`.`lastupdate`) = extract(year from curdate())) and (`cs`.`id` = `gr`.`gs_id`)) group by `gr`.`lastupdate`,`cs`.`id`,`cs`.`name`,`gr`.`gu_id` having (avg(`gr`.`game_score`) > 90) ;

-- --------------------------------------------------------

--
-- Structure for view `popupstarlessequalninty`
--
DROP TABLE IF EXISTS `popupstarlessequalninty`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `popupstarlessequalninty`  AS  select `gr`.`gu_id` AS `gu_id`,`gr`.`lastupdate` AS `lastupdate`,`cs`.`id` AS `cat_id`,`cs`.`name` AS `name`,ceiling((avg(`gr`.`game_score`) / 20)) AS `ct` from (`game_reports` `gr` join `category_skills` `cs`) where ((extract(month from `gr`.`lastupdate`) = extract(month from curdate())) and (extract(year from `gr`.`lastupdate`) = extract(year from curdate())) and (`cs`.`id` = `gr`.`gs_id`)) group by `gr`.`lastupdate`,`cs`.`id`,`cs`.`name`,`gr`.`gu_id` having (avg(`gr`.`game_score`) <= 90) ;

-- --------------------------------------------------------

--
-- Structure for view `popupstars`
--
DROP TABLE IF EXISTS `popupstars`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `popupstars`  AS  select `gr`.`lastupdate` AS `lastupdate`,`cs`.`name` AS `name`,ceiling((avg(`gr`.`game_score`) / 20)) AS `ct` from (`game_reports` `gr` join `category_skills` `cs`) where ((extract(month from `gr`.`lastupdate`) = extract(month from curdate())) and (extract(year from `gr`.`lastupdate`) = extract(year from curdate())) and (`cs`.`id` = `gr`.`gc_id`)) group by `gr`.`lastupdate`,`cs`.`name` ;

-- --------------------------------------------------------

--
-- Structure for view `popuptrophys`
--
DROP TABLE IF EXISTS `popuptrophys`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `popuptrophys`  AS  select `popupstar`.`gu_id` AS `gu_id`,`popupstar`.`cat_id` AS `catid`,`popupstar`.`name` AS `name`,extract(month from `popupstar`.`lastupdate`) AS `month`,floor((sum(`popupstar`.`ct`) / 60)) AS `diamond`,floor(((sum(`popupstar`.`ct`) % 60) / 30)) AS `gold`,floor((((sum(`popupstar`.`ct`) % 60) % 30) / 15)) AS `silver` from `popupstar` where ((extract(month from `popupstar`.`lastupdate`) = extract(month from curdate())) and (extract(year from `popupstar`.`lastupdate`) = extract(year from curdate()))) group by `popupstar`.`name`,`popupstar`.`gu_id`,extract(month from `popupstar`.`lastupdate`) ;

-- --------------------------------------------------------

--
-- Structure for view `sc_daywisemaxpuzzlesattempted`
--
DROP TABLE IF EXISTS `sc_daywisemaxpuzzlesattempted`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `sc_daywisemaxpuzzlesattempted`  AS  select `gr`.`gu_id` AS `gu_id`,`u`.`grade_id` AS `grade_id`,`u`.`gp_id` AS `gp_id`,`u`.`sid` AS `sid`,`u`.`section` AS `section`,`u`.`username` AS `username`,`u`.`fname` AS `fname`,`u`.`org_id` AS `org_id`,sum(`gr`.`attempt_question`) AS `PuzzlesAttempted`,`gr`.`lastupdate` AS `lastupdate` from (`game_reports` `gr` join `users` `u` on((`gr`.`gu_id` = `u`.`id`))) where ((`u`.`status` = 1) and (`u`.`visible` = 1) and (`gr`.`gs_id` in (59,60,61,62,63)) and (`gr`.`gtime` is not null) and (`gr`.`attempt_question` is not null) and (`gr`.`lastupdate` between `u`.`startdate` and `u`.`enddate`)) group by `gr`.`gu_id`,`gr`.`lastupdate` order by sum(`gr`.`attempt_question`) desc ;

-- --------------------------------------------------------

--
-- Structure for view `sc_daywisemaxpuzzlessolved`
--
DROP TABLE IF EXISTS `sc_daywisemaxpuzzlessolved`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `sc_daywisemaxpuzzlessolved`  AS  select `gr`.`gu_id` AS `gu_id`,`u`.`grade_id` AS `grade_id`,`u`.`gp_id` AS `gp_id`,`u`.`sid` AS `sid`,`u`.`section` AS `section`,`u`.`username` AS `username`,`u`.`fname` AS `fname`,`u`.`org_id` AS `org_id`,sum(`gr`.`answer`) AS `PuzzlesSolved`,`gr`.`lastupdate` AS `lastupdate` from (`game_reports` `gr` join `users` `u` on((`gr`.`gu_id` = `u`.`id`))) where ((`u`.`status` = 1) and (`u`.`visible` = 1) and (`gr`.`gs_id` in (59,60,61,62,63)) and (`gr`.`gtime` is not null) and (`gr`.`answer` is not null) and (`gr`.`lastupdate` between `u`.`startdate` and `u`.`enddate`)) group by `gr`.`gu_id`,`gr`.`lastupdate` order by sum(`gr`.`answer`) desc ;

-- --------------------------------------------------------

--
-- Structure for view `sc_daywisetopscorer`
--
DROP TABLE IF EXISTS `sc_daywisetopscorer`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `sc_daywisetopscorer`  AS  select `gr`.`gu_id` AS `gu_id`,`u`.`grade_id` AS `grade_id`,`u`.`gp_id` AS `gp_id`,`u`.`sid` AS `sid`,`u`.`section` AS `section`,`u`.`username` AS `username`,`u`.`fname` AS `fname`,`u`.`org_id` AS `org_id`,sum(`gr`.`game_score`) AS `score`,`gr`.`lastupdate` AS `lastupdate` from (`game_reports` `gr` join `users` `u` on((`u`.`id` = `gr`.`gu_id`))) where ((`u`.`status` = 1) and (`u`.`visible` = 1) and (`gr`.`gs_id` in (59,60,61,62,63)) and (`gr`.`lastupdate` between `u`.`startdate` and `u`.`enddate`)) group by `gr`.`gu_id`,`gr`.`lastupdate` order by sum(`gr`.`game_score`) desc ;

-- --------------------------------------------------------

--
-- Structure for view `sc_maxpuzzlesattempted`
--
DROP TABLE IF EXISTS `sc_maxpuzzlesattempted`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `sc_maxpuzzlesattempted`  AS  select `gr`.`gu_id` AS `gu_id`,`u`.`grade_id` AS `grade_id`,`u`.`gp_id` AS `gp_id`,`u`.`sid` AS `sid`,`u`.`section` AS `section`,`u`.`username` AS `username`,`u`.`fname` AS `fname`,`u`.`org_id` AS `org_id`,sum(`gr`.`attempt_question`) AS `PuzzlesAttempted`,`gr`.`lastupdate` AS `lastupdate` from (`game_reports` `gr` join `users` `u` on((`gr`.`gu_id` = `u`.`id`))) where ((`u`.`status` = 1) and (`u`.`visible` = 1) and (`gr`.`gs_id` in (59,60,61,62,63)) and (`gr`.`gtime` is not null) and (`gr`.`attempt_question` is not null) and (`gr`.`lastupdate` between `u`.`startdate` and `u`.`enddate`)) group by `gr`.`gu_id` order by sum(`gr`.`attempt_question`) desc ;

-- --------------------------------------------------------

--
-- Structure for view `sc_maxpuzzlessolved`
--
DROP TABLE IF EXISTS `sc_maxpuzzlessolved`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `sc_maxpuzzlessolved`  AS  select `gr`.`gu_id` AS `gu_id`,`u`.`grade_id` AS `grade_id`,`u`.`gp_id` AS `gp_id`,`u`.`sid` AS `sid`,`u`.`section` AS `section`,`u`.`username` AS `username`,`u`.`fname` AS `fname`,`u`.`org_id` AS `org_id`,sum(`gr`.`answer`) AS `PuzzlesSolved`,`gr`.`lastupdate` AS `lastupdate` from (`game_reports` `gr` join `users` `u` on((`gr`.`gu_id` = `u`.`id`))) where ((`u`.`status` = 1) and (`u`.`visible` = 1) and (`gr`.`gs_id` in (59,60,61,62,63)) and (`gr`.`gtime` is not null) and (`gr`.`answer` is not null) and (`gr`.`lastupdate` between `u`.`startdate` and `u`.`enddate`)) group by `gr`.`gu_id` order by sum(`gr`.`answer`) desc ;

-- --------------------------------------------------------

--
-- Structure for view `sc_topscorer`
--
DROP TABLE IF EXISTS `sc_topscorer`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `sc_topscorer`  AS  select `gr`.`gu_id` AS `gu_id`,`u`.`grade_id` AS `grade_id`,`u`.`gp_id` AS `gp_id`,`u`.`sid` AS `sid`,`u`.`section` AS `section`,`u`.`username` AS `username`,`u`.`fname` AS `fname`,`u`.`org_id` AS `org_id`,sum(`gr`.`game_score`) AS `score`,`gr`.`lastupdate` AS `lastupdate` from (`game_reports` `gr` join `users` `u` on((`u`.`id` = `gr`.`gu_id`))) where ((`u`.`status` = 1) and (`u`.`visible` = 1) and (`gr`.`gs_id` in (59,60,61,62,63)) and (`gr`.`lastupdate` between `u`.`startdate` and `u`.`enddate`)) group by `gr`.`gu_id` order by sum(`gr`.`game_score`) desc ;

-- --------------------------------------------------------

--
-- Structure for view `sc_usertotgamescore`
--
DROP TABLE IF EXISTS `sc_usertotgamescore`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `sc_usertotgamescore`  AS  select `gr`.`gu_id` AS `gu_id`,`u`.`grade_id` AS `grade_id`,`u`.`gp_id` AS `gp_id`,`u`.`sid` AS `sid`,`u`.`section` AS `section`,`u`.`username` AS `username`,`u`.`fname` AS `fname`,`u`.`org_id` AS `org_id`,(sum(`gr`.`game_score`) + (select coalesce(sum(`gamedata_cq`.`game_score`),0) AS `score` from `gamedata_cq` where ((`gamedata_cq`.`gu_id` = `u`.`id`) and (`gamedata_cq`.`lastupdate` between `u`.`startdate` and `u`.`enddate`)))) AS `score` from (`game_reports` `gr` join `users` `u` on((`u`.`id` = `gr`.`gu_id`))) where ((`u`.`status` = 1) and (`u`.`visible` = 1) and (`gr`.`gs_id` in (59,60,61,62,63)) and (`gr`.`lastupdate` between `u`.`startdate` and `u`.`enddate`)) group by `gr`.`gu_id` order by sum(`gr`.`game_score`) desc ;

-- --------------------------------------------------------

--
-- Structure for view `sk_gamedata_updated`
--
DROP TABLE IF EXISTS `sk_gamedata_updated`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `sk_gamedata_updated`  AS  select `sk_gamescore`.`id` AS `id`,`sk_gamescore`.`userid` AS `gu_id`,`sk_gamescore`.`gp_id` AS `gp_id`,`sk_gamescore`.`gc_id` AS `gc_id`,`sk_gamescore`.`skillid` AS `gs_id`,`sk_gamescore`.`gameid` AS `g_id`,10 AS `total_question`,count(0) AS `attempt_question`,sum(if((`sk_gamescore`.`answerstatus` = 'C'),1,0)) AS `answer`,sum(`sk_gamescore`.`score`) AS `game_score`,min(`sk_gamescore`.`timervalue`) AS `gtime`,sum(`sk_gamescore`.`responsetime`) AS `rtime`,sum(if((`sk_gamescore`.`answerstatus` = 'C'),`sk_gamescore`.`responsetime`,0)) AS `crtime`,sum(if((`sk_gamescore`.`answerstatus` = 'W'),`sk_gamescore`.`responsetime`,0)) AS `wrtime`,cast(`sk_gamescore`.`updateddate` as date) AS `lastupdate`,`sk_gamescore`.`iteration` AS `iteration` from `sk_gamescore` group by `sk_gamescore`.`iteration`,`sk_gamescore`.`gameid`,`sk_gamescore`.`skillid`,`sk_gamescore`.`userid`,`sk_gamescore`.`gc_id`,`sk_gamescore`.`gp_id`,cast(`sk_gamescore`.`updateddate` as date) ;

-- --------------------------------------------------------

--
-- Structure for view `sk_game_reports`
--
DROP TABLE IF EXISTS `sk_game_reports`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `sk_game_reports`  AS  select `sk_gamedata`.`id` AS `id`,`sk_gamedata`.`gu_id` AS `gu_id`,`sk_gamedata`.`gp_id` AS `gp_id`,`sk_gamedata`.`gc_id` AS `gc_id`,`sk_gamedata`.`gs_id` AS `gs_id`,`sk_gamedata`.`g_id` AS `g_id`,`sk_gamedata`.`total_question` AS `total_question`,`sk_gamedata`.`attempt_question` AS `attempt_question`,`sk_gamedata`.`answer` AS `answer`,`sk_gamedata`.`game_score` AS `game_score`,`sk_gamedata`.`gtime` AS `gtime`,`sk_gamedata`.`rtime` AS `rtime`,`sk_gamedata`.`crtime` AS `crtime`,`sk_gamedata`.`wrtime` AS `wrtime`,`sk_gamedata`.`lastupdate` AS `lastupdate` from `sk_gamedata` ;

-- --------------------------------------------------------

--
-- Structure for view `superangel`
--
DROP TABLE IF EXISTS `superangel`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `superangel`  AS  select sum(`game_reports`.`answer`) AS `ans`,`game_reports`.`gu_id` AS `gu_id`,date_format(`game_reports`.`lastupdate`,'%b') AS `monthName`,date_format(`game_reports`.`lastupdate`,'%m') AS `monthNumber`,year(`game_reports`.`lastupdate`) AS `monofyear`,(select `users`.`sid` from `users` where (`users`.`id` = `game_reports`.`gu_id`)) AS `gs_ID`,(select `users`.`grade_id` from `users` where (`users`.`id` = `game_reports`.`gu_id`)) AS `grad_ID` from `game_reports` where ((convert(date_format(`game_reports`.`lastupdate`,'%Y-%m-%d') using latin1) between (select `users`.`startdate` from `users` where (`users`.`id` = `game_reports`.`gu_id`)) and (select `users`.`enddate` from `users` where (`users`.`id` = `game_reports`.`gu_id`))) and `game_reports`.`gu_id` in (select `users`.`id` from `users` where ((`users`.`status` = 1) and (`users`.`visible` = 1)))) group by date_format(`game_reports`.`lastupdate`,'%m'),year(`game_reports`.`lastupdate`),`game_reports`.`gu_id` ;

-- --------------------------------------------------------

--
-- Structure for view `trophystar`
--
DROP TABLE IF EXISTS `trophystar`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `trophystar`  AS  select `gr`.`gu_id` AS `gu_id`,`cs`.`id` AS `id`,`cs`.`name` AS `name`,`gr`.`lastupdate` AS `lastupdate`,round((avg(`gr`.`game_score`) / 20),0) AS `ct` from (`game_reports` `gr` join `category_skills` `cs`) where (`cs`.`id` = `gr`.`gs_id`) group by `gr`.`lastupdate`,`cs`.`id`,`cs`.`name`,`gr`.`gu_id` ;

-- --------------------------------------------------------

--
-- Structure for view `trophystargreaterthanninty`
--
DROP TABLE IF EXISTS `trophystargreaterthanninty`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `trophystargreaterthanninty`  AS  select `gr`.`gu_id` AS `gu_id`,`cs`.`id` AS `id`,`cs`.`name` AS `name`,`gr`.`lastupdate` AS `lastupdate`,round((avg(`gr`.`game_score`) / 20),0) AS `ct` from (`game_reports` `gr` join `category_skills` `cs`) where (`cs`.`id` = `gr`.`gs_id`) group by `gr`.`lastupdate`,`cs`.`id`,`cs`.`name`,`gr`.`gu_id` having (avg(`gr`.`game_score`) > 90) ;

-- --------------------------------------------------------

--
-- Structure for view `trophystarlessequalninty`
--
DROP TABLE IF EXISTS `trophystarlessequalninty`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `trophystarlessequalninty`  AS  select `gr`.`gu_id` AS `gu_id`,`cs`.`id` AS `id`,`cs`.`name` AS `name`,`gr`.`lastupdate` AS `lastupdate`,ceiling((avg(`gr`.`game_score`) / 20)) AS `ct` from (`game_reports` `gr` join `category_skills` `cs`) where (`cs`.`id` = `gr`.`gs_id`) group by `gr`.`lastupdate`,`cs`.`id`,`cs`.`name`,`gr`.`gu_id` having (avg(`gr`.`game_score`) <= 90) ;

-- --------------------------------------------------------

--
-- Structure for view `vii_1dayskillcorebymon`
--
DROP TABLE IF EXISTS `vii_1dayskillcorebymon`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vii_1dayskillcorebymon`  AS  select round(avg(`vii_1dayskillscore`.`score`),2) AS `score`,`vii_1dayskillscore`.`gu_id` AS `gu_id`,`vii_1dayskillscore`.`gs_id` AS `gs_id`,`vii_1dayskillscore`.`sid` AS `sid`,`vii_1dayskillscore`.`grade_id` AS `grade_id`,`vii_1dayskillscore`.`section` AS `section`,date_format(`vii_1dayskillscore`.`lastupdate`,'%m') AS `monthNumber`,year(`vii_1dayskillscore`.`lastupdate`) AS `monofyear` from `vii_1dayskillscore` group by `vii_1dayskillscore`.`gs_id`,`vii_1dayskillscore`.`gu_id`,concat(date_format(`vii_1dayskillscore`.`lastupdate`,'%m'),'-',year(`vii_1dayskillscore`.`lastupdate`)) ;

-- --------------------------------------------------------

--
-- Structure for view `vii_1dayskillscore`
--
DROP TABLE IF EXISTS `vii_1dayskillscore`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vii_1dayskillscore`  AS  select avg(`gr`.`game_score`) AS `score`,`gr`.`gs_id` AS `gs_id`,`gr`.`gu_id` AS `gu_id`,`u`.`sid` AS `sid`,`u`.`grade_id` AS `grade_id`,`u`.`section` AS `section`,`gr`.`lastupdate` AS `lastupdate` from (`game_reports` `gr` join `users` `u` on((`u`.`id` = `gr`.`gu_id`))) where ((`u`.`status` = 1) and (`u`.`visible` = 1) and `u`.`sid` in (select `schools`.`id` from `schools` where ((`schools`.`visible` = 1) and (`schools`.`status` = 1))) and (`gr`.`gs_id` in (59,60,61,62,63)) and (`gr`.`lastupdate` between (select `users`.`startdate` from `users` where (`users`.`id` = `gr`.`gu_id`)) and (select `users`.`enddate` from `users` where (`users`.`id` = `gr`.`gu_id`)))) group by `gr`.`gs_id`,`gr`.`gu_id`,`gr`.`lastupdate` ;

-- --------------------------------------------------------

--
-- Structure for view `vii_1dayuserscore`
--
DROP TABLE IF EXISTS `vii_1dayuserscore`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vii_1dayuserscore`  AS  select avg(`vii_1dayskillscore`.`score`) AS `score`,`vii_1dayskillscore`.`gu_id` AS `gu_id`,`vii_1dayskillscore`.`gs_id` AS `gs_id`,`vii_1dayskillscore`.`sid` AS `sid`,`vii_1dayskillscore`.`grade_id` AS `grade_id`,`vii_1dayskillscore`.`section` AS `section`,`vii_1dayskillscore`.`lastupdate` AS `lastupdate` from `vii_1dayskillscore` group by `vii_1dayskillscore`.`gs_id`,`vii_1dayskillscore`.`gu_id` ;

-- --------------------------------------------------------

--
-- Structure for view `vii_avguserbspiscore`
--
DROP TABLE IF EXISTS `vii_avguserbspiscore`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vii_avguserbspiscore`  AS  select round((sum(`vii_1dayuserscore`.`score`) / 5),2) AS `finalscore`,`vii_1dayuserscore`.`gu_id` AS `gu_id`,`vii_1dayuserscore`.`sid` AS `sid`,`vii_1dayuserscore`.`grade_id` AS `grade_id`,`vii_1dayuserscore`.`section` AS `section`,(select `users`.`username` from `users` where (`users`.`id` = `vii_1dayuserscore`.`gu_id`)) AS `username` from `vii_1dayuserscore` group by `vii_1dayuserscore`.`gu_id` ;

-- --------------------------------------------------------

--
-- Structure for view `vii_avguserbspiscorebymon`
--
DROP TABLE IF EXISTS `vii_avguserbspiscorebymon`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vii_avguserbspiscorebymon`  AS  select round((sum(`vii2`.`score`) / 5),2) AS `finalscore`,`vii2`.`gu_id` AS `gu_id`,`vii2`.`sid` AS `sid`,`vii2`.`grade_id` AS `grade_id`,`vii2`.`section` AS `section`,(select `users`.`username` from `users` where (`users`.`id` = `vii2`.`gu_id`)) AS `username`,`vii2`.`monthNumber` AS `monthNumber`,`vii2`.`monofyear` AS `monofyear`,monthname(str_to_date(`vii2`.`monthNumber`,'%m')) AS `monthName` from `vii_1dayskillcorebymon` `vii2` group by `vii2`.`gu_id`,concat(`vii2`.`monthNumber`,'-',`vii2`.`monofyear`) ;

-- --------------------------------------------------------

--
-- Structure for view `vii_bspigradetoppersbysec`
--
DROP TABLE IF EXISTS `vii_bspigradetoppersbysec`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vii_bspigradetoppersbysec`  AS  select max(`bspi4`.`finalscore`) AS `bspi`,`bspi4`.`gu_id` AS `gu_id`,`bspi4`.`monthNumber` AS `monthNumber`,`bspi4`.`monofyear` AS `monofyear`,`bspi4`.`sid` AS `sid`,`bspi4`.`grade_id` AS `grade_id`,`bspi4`.`section` AS `section` from `vii_avguserbspiscorebymon` `bspi4` where `bspi4`.`gu_id` in (select `u`.`id` from `users` `u` where ((`u`.`status` = 1) and (`u`.`visible` = 1))) group by concat(`bspi4`.`monthNumber`,'-',`bspi4`.`monofyear`),`bspi4`.`sid`,`bspi4`.`grade_id`,`bspi4`.`section` ;

-- --------------------------------------------------------

--
-- Structure for view `vii_daywiseuserbspiscore`
--
DROP TABLE IF EXISTS `vii_daywiseuserbspiscore`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vii_daywiseuserbspiscore`  AS  select round((sum(`vii_1dayskillscore`.`score`) / 5),2) AS `finalscore`,`vii_1dayskillscore`.`gu_id` AS `gu_id`,`vii_1dayskillscore`.`sid` AS `sid`,`vii_1dayskillscore`.`grade_id` AS `grade_id`,`vii_1dayskillscore`.`section` AS `section`,(select `users`.`username` from `users` where (`users`.`id` = `vii_1dayskillscore`.`gu_id`)) AS `username`,`vii_1dayskillscore`.`lastupdate` AS `lastupdate` from `vii_1dayskillscore` group by `vii_1dayskillscore`.`gu_id`,`vii_1dayskillscore`.`lastupdate` ;

-- --------------------------------------------------------

--
-- Structure for view `vii_overallbspitoppers`
--
DROP TABLE IF EXISTS `vii_overallbspitoppers`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vii_overallbspitoppers`  AS  select max(`vii_avguserbspiscore`.`finalscore`) AS `bspi`,`vii_avguserbspiscore`.`gu_id` AS `gu_id`,`vii_avguserbspiscore`.`sid` AS `sid`,`vii_avguserbspiscore`.`grade_id` AS `grade_id` from `vii_avguserbspiscore` group by `vii_avguserbspiscore`.`grade_id` ;

-- --------------------------------------------------------

--
-- Structure for view `vii_topbspiscore`
--
DROP TABLE IF EXISTS `vii_topbspiscore`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vii_topbspiscore`  AS  select max(`bspi4`.`finalscore`) AS `bspi`,`bspi4`.`gu_id` AS `gu_id`,`bspi4`.`monthNumber` AS `monthNumber`,`bspi4`.`monofyear` AS `monofyear`,`bspi4`.`sid` AS `sid`,`bspi4`.`grade_id` AS `grade_id` from `vii_avguserbspiscorebymon` `bspi4` where `bspi4`.`gu_id` in (select `u`.`id` from `users` `u` where ((`u`.`status` = 1) and (`u`.`visible` = 1))) group by concat(`bspi4`.`monthNumber`,'-',`bspi4`.`monofyear`),`bspi4`.`sid`,`bspi4`.`grade_id` ;

-- --------------------------------------------------------

--
-- Structure for view `vii_topsuperangels`
--
DROP TABLE IF EXISTS `vii_topsuperangels`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vii_topsuperangels`  AS  select max(`superangel`.`ans`) AS `ans`,`superangel`.`gu_id` AS `gu_id`,`superangel`.`monthName` AS `monthName`,`superangel`.`monthNumber` AS `monthNumber`,`superangel`.`monofyear` AS `monofyear`,`superangel`.`gs_ID` AS `gs_ID`,`superangel`.`grad_ID` AS `grad_ID` from `superangel` group by concat(`superangel`.`monthNumber`,'-',`superangel`.`monofyear`),`superangel`.`gs_ID`,`superangel`.`grad_ID` ;

-- --------------------------------------------------------

--
-- Structure for view `vii_user1dayskillscore`
--
DROP TABLE IF EXISTS `vii_user1dayskillscore`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vii_user1dayskillscore`  AS  select avg(`game_reports`.`game_score`) AS `score`,`game_reports`.`gs_id` AS `gs_id`,`game_reports`.`gu_id` AS `gu_id`,`game_reports`.`lastupdate` AS `lastupdate` from (`game_reports` join `users` `u` on((`u`.`id` = `game_reports`.`gu_id`))) where ((`game_reports`.`gs_id` in (59,60,61,62,63)) and (`game_reports`.`lastupdate` between `u`.`startdate` and `u`.`enddate`)) group by `game_reports`.`gu_id`,`game_reports`.`gs_id`,`game_reports`.`lastupdate` ;

-- --------------------------------------------------------

--
-- Structure for view `vii_usercurrentbspi`
--
DROP TABLE IF EXISTS `vii_usercurrentbspi`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vii_usercurrentbspi`  AS  select `a1`.`gu_id` AS `gu_id`,round(avg(`a1`.`score`),2) AS `score` from `vii_user1dayskillscore` `a1` group by `a1`.`gu_id` ;

-- --------------------------------------------------------

--
-- Structure for view `vii_userskillscorebydate`
--
DROP TABLE IF EXISTS `vii_userskillscorebydate`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vii_userskillscorebydate`  AS  select round(avg(`vii_1dayskillscore`.`score`),2) AS `score`,`vii_1dayskillscore`.`gu_id` AS `gu_id`,`vii_1dayskillscore`.`gs_id` AS `gs_id`,`vii_1dayskillscore`.`sid` AS `sid`,`vii_1dayskillscore`.`grade_id` AS `grade_id`,`vii_1dayskillscore`.`section` AS `section`,`vii_1dayskillscore`.`lastupdate` AS `lastupdate` from `vii_1dayskillscore` group by `vii_1dayskillscore`.`gs_id`,`vii_1dayskillscore`.`gu_id`,`vii_1dayskillscore`.`lastupdate` ;

-- --------------------------------------------------------

--
-- Structure for view `vi_1dayskillscore`
--
DROP TABLE IF EXISTS `vi_1dayskillscore`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vi_1dayskillscore`  AS  select round(avg(`game_reports`.`game_score`),2) AS `score`,`game_reports`.`gu_id` AS `gu_id`,`game_reports`.`gs_id` AS `gs_id`,`game_reports`.`lastupdate` AS `lastupdate` from `game_reports` group by `game_reports`.`gu_id`,`game_reports`.`gs_id`,`game_reports`.`lastupdate` ;

-- --------------------------------------------------------

--
-- Structure for view `vi_1dayuserscore`
--
DROP TABLE IF EXISTS `vi_1dayuserscore`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vi_1dayuserscore`  AS  select round((sum(`bspi1`.`score`) / 5),2) AS `score`,`bspi1`.`gu_id` AS `gu_id`,`bspi1`.`lastupdate` AS `lastupdate` from `vi_1dayskillscore` `bspi1` group by `bspi1`.`gu_id`,`bspi1`.`lastupdate` ;

-- --------------------------------------------------------

--
-- Structure for view `vi_avgofbspi`
--
DROP TABLE IF EXISTS `vi_avgofbspi`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vi_avgofbspi`  AS  select round(avg(`bspi1`.`score`),2) AS `score`,`bspi1`.`gu_id` AS `gu_id`,`bspi1`.`lastupdate` AS `lastupdate`,`u`.`sid` AS `sid`,`u`.`grade_id` AS `grade_id` from (`vi_1dayuserscore` `bspi1` join `users` `u` on((`u`.`id` = `bspi1`.`gu_id`))) where ((`u`.`status` = 1) and (`u`.`visible` = 1) and (`bspi1`.`lastupdate` between (select `ay`.`startdate` from (`academic_year` `ay` join `schools` `s2` on((`s2`.`academic_id` = `ay`.`id`))) where (`s2`.`id` = `u`.`sid`)) and (select `ay`.`enddate` from (`academic_year` `ay` join `schools` `s2` on((`s2`.`academic_id` = `ay`.`id`))) where (`s2`.`id` = `u`.`sid`)))) group by `bspi1`.`gu_id` ;

-- --------------------------------------------------------

--
-- Structure for view `vi_avguserbspiscore`
--
DROP TABLE IF EXISTS `vi_avguserbspiscore`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vi_avguserbspiscore`  AS  select round(avg(`bspi2`.`score`),2) AS `bspi`,`bspi2`.`gu_id` AS `gu_id`,month(`bspi2`.`lastupdate`) AS `monthNumber`,date_format(`bspi2`.`lastupdate`,'%b') AS `monthName`,`u`.`sid` AS `sid`,`u`.`grade_id` AS `grade_id` from (`vi_1dayuserscore` `bspi2` join `users` `u` on((`u`.`id` = `bspi2`.`gu_id`))) where `bspi2`.`gu_id` in (select `users`.`id` from `users` where ((`users`.`status` = 1) and (`users`.`visible` = 1))) group by `bspi2`.`gu_id`,month(`bspi2`.`lastupdate`) ;

-- --------------------------------------------------------

--
-- Structure for view `vi_diamond`
--
DROP TABLE IF EXISTS `vi_diamond`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vi_diamond`  AS  select `vi_star`.`userid` AS `userid`,`vi_star`.`UserName` AS `UserName`,`vi_star`.`school_id` AS `school_id`,`vi_star`.`Grade` AS `Grade`,extract(month from `vi_star`.`date`) AS `MONTH`,floor((sum(`vi_star`.`MEMORYSTAR`) / 60)) AS `DMEMORY`,floor((sum(`vi_star`.`VPSTAR`) / 60)) AS `DVP`,floor((sum(`vi_star`.`FASTAR`) / 60)) AS `DFA`,floor((sum(`vi_star`.`PSSTAR`) / 60)) AS `DPS`,floor((sum(`vi_star`.`LGSTAR`) / 60)) AS `DLG`,((((floor((sum(`vi_star`.`MEMORYSTAR`) / 60)) + floor((sum(`vi_star`.`VPSTAR`) / 60))) + floor((sum(`vi_star`.`FASTAR`) / 60))) + floor((sum(`vi_star`.`PSSTAR`) / 60))) + floor((sum(`vi_star`.`LGSTAR`) / 60))) AS `dtotal` from `vi_star` group by `vi_star`.`userid`,`vi_star`.`UserName`,`vi_star`.`school_id`,`vi_star`.`Grade`,extract(month from `vi_star`.`date`) ;

-- --------------------------------------------------------

--
-- Structure for view `vi_focusandattention`
--
DROP TABLE IF EXISTS `vi_focusandattention`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vi_focusandattention`  AS  select `cls`.`classname` AS `Grade`,`sec`.`section` AS `user_section`,`usr`.`id` AS `UserID`,`usr`.`sid` AS `school_id`,concat(`usr`.`fname`,' ',`usr`.`lname`) AS `UserName`,`gr`.`lastupdate` AS `Date`,NULL AS `Memory`,NULL AS `Visual Processing`,`gr`.`game_score` AS `FocusAndAttention`,NULL AS `ProblemSolving`,NULL AS `Lingustics` from ((((`game_reports` `gr` join `users` `usr` on((`usr`.`id` = `gr`.`gu_id`))) join `class` `cls` on((`cls`.`id` = `usr`.`grade_id`))) join `skl_class_section` `sec` on((`sec`.`section` = `usr`.`section`))) join `category_skills` `cs` on((`cs`.`id` = `gr`.`gs_id`))) ;

-- --------------------------------------------------------

--
-- Structure for view `vi_focusandattentionstar`
--
DROP TABLE IF EXISTS `vi_focusandattentionstar`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vi_focusandattentionstar`  AS  select `cls`.`classname` AS `Grade`,`sec`.`section` AS `user_section`,`usr`.`id` AS `UserID`,`usr`.`sid` AS `school_id`,concat(`usr`.`fname`,' ',`usr`.`lname`) AS `UserName`,`gr`.`lastupdate` AS `Date`,NULL AS `Memory`,NULL AS `Visual Processing`,ifnull(floor(avg((`gr`.`game_score` / 20))),0) AS `FocusAndAttention`,NULL AS `ProblemSolving`,NULL AS `Lingustics` from ((((`game_reports` `gr` join `users` `usr` on((`usr`.`id` = `gr`.`gu_id`))) join `class` `cls` on((`cls`.`id` = `usr`.`grade_id`))) join `skl_class_section` `sec` on((`sec`.`section` = `usr`.`section`))) join `category_skills` `cs` on((`cs`.`id` = `gr`.`gs_id`))) where (`cs`.`name` = 'Focus And Attention') ;

-- --------------------------------------------------------

--
-- Structure for view `vi_gameplayed`
--
DROP TABLE IF EXISTS `vi_gameplayed`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vi_gameplayed`  AS  select max(`vi_totgamesplayed`.`countofplayed`) AS `countofval`,`vi_totgamesplayed`.`monthName` AS `monthName`,`vi_totgamesplayed`.`monofyear` AS `monofyear`,`vi_totgamesplayed`.`monthNumber` AS `monthNumber`,`vi_totgamesplayed`.`gs_ID` AS `school_id`,`vi_totgamesplayed`.`grad_ID` AS `grad_id` from `vi_totgamesplayed` where `vi_totgamesplayed`.`gu_id` in (select `users`.`id` from `users` where ((`users`.`status` = 1) and (`users`.`visible` = 1))) group by concat(`vi_totgamesplayed`.`monthNumber`,'-',`vi_totgamesplayed`.`monofyear`),`vi_totgamesplayed`.`gs_ID`,`vi_totgamesplayed`.`grad_ID` ;

-- --------------------------------------------------------

--
-- Structure for view `vi_gold`
--
DROP TABLE IF EXISTS `vi_gold`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vi_gold`  AS  select `vi_star`.`userid` AS `userid`,`vi_star`.`UserName` AS `UserName`,`vi_star`.`school_id` AS `school_id`,`vi_star`.`Grade` AS `Grade`,extract(month from `vi_star`.`date`) AS `MONTH`,floor(((sum(`vi_star`.`MEMORYSTAR`) % 60) / 30)) AS `GMEMORY`,floor(((sum(`vi_star`.`VPSTAR`) % 60) / 30)) AS `GVP`,floor(((sum(`vi_star`.`FASTAR`) % 60) / 30)) AS `GFA`,floor(((sum(`vi_star`.`PSSTAR`) % 60) / 30)) AS `GPS`,floor(((sum(`vi_star`.`LGSTAR`) % 60) / 30)) AS `GLG`,((((floor(((sum(`vi_star`.`MEMORYSTAR`) % 60) / 30)) + floor(((sum(`vi_star`.`VPSTAR`) % 60) / 30))) + floor(((sum(`vi_star`.`FASTAR`) % 60) / 30))) + floor(((sum(`vi_star`.`PSSTAR`) % 60) / 30))) + floor(((sum(`vi_star`.`LGSTAR`) % 60) / 30))) AS `gtotal` from `vi_star` group by `vi_star`.`userid`,`vi_star`.`UserName`,`vi_star`.`school_id`,`vi_star`.`Grade`,extract(month from `vi_star`.`date`) ;

-- --------------------------------------------------------

--
-- Structure for view `vi_gradeskillpivot`
--
DROP TABLE IF EXISTS `vi_gradeskillpivot`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vi_gradeskillpivot`  AS  select `vi_gradeskillpivotsource`.`Grade` AS `Grade`,`vi_gradeskillpivotsource`.`user_section` AS `user_section`,`vi_gradeskillpivotsource`.`UserID` AS `UserID`,`vi_gradeskillpivotsource`.`UserName` AS `UserName`,`vi_gradeskillpivotsource`.`date` AS `date`,`vi_gradeskillpivotsource`.`school_id` AS `school_id`,avg(`vi_gradeskillpivotsource`.`Memory`) AS `Memory`,avg(`vi_gradeskillpivotsource`.`vp`) AS `Visual Processing`,avg(`vi_gradeskillpivotsource`.`FocusAndAttention`) AS `Focus And Attention`,avg(`vi_gradeskillpivotsource`.`ProblemSolving`) AS `Problem Solving`,avg(`vi_gradeskillpivotsource`.`Lingustics`) AS `Linguistics` from `vi_gradeskillpivotsource` group by `vi_gradeskillpivotsource`.`Grade`,`vi_gradeskillpivotsource`.`user_section`,`vi_gradeskillpivotsource`.`UserID`,`vi_gradeskillpivotsource`.`UserName`,`vi_gradeskillpivotsource`.`date` ;

-- --------------------------------------------------------

--
-- Structure for view `vi_gradeskillpivotsource`
--
DROP TABLE IF EXISTS `vi_gradeskillpivotsource`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vi_gradeskillpivotsource`  AS  select `vi_memory`.`Grade` AS `Grade`,`vi_memory`.`user_section` AS `user_section`,`vi_memory`.`UserID` AS `UserID`,`vi_memory`.`UserName` AS `UserName`,`vi_memory`.`Date` AS `date`,`vi_memory`.`school_id` AS `school_id`,`vi_memory`.`Memory` AS `Memory`,`vi_memory`.`VP` AS `vp`,`vi_memory`.`FocusAndAttention` AS `FocusAndAttention`,`vi_memory`.`ProblemSolving` AS `ProblemSolving`,`vi_memory`.`Lingustics` AS `Lingustics` from `vi_memory` union all select `vi_vp`.`Grade` AS `Grade`,`vi_vp`.`user_section` AS `user_section`,`vi_vp`.`UserID` AS `UserID`,`vi_vp`.`UserName` AS `UserName`,`vi_vp`.`Date` AS `date`,`vi_vp`.`school_id` AS `school_id`,`vi_vp`.`Memory` AS `Memory`,`vi_vp`.`Visual Processing` AS `Visual Processing`,`vi_vp`.`FocusAndAttention` AS `FocusAndAttention`,`vi_vp`.`ProblemSolving` AS `ProblemSolving`,`vi_vp`.`Lingustics` AS `Lingustics` from `vi_vp` union all select `vi_focusandattention`.`Grade` AS `Grade`,`vi_focusandattention`.`user_section` AS `user_section`,`vi_focusandattention`.`UserID` AS `UserID`,`vi_focusandattention`.`UserName` AS `UserName`,`vi_focusandattention`.`Date` AS `date`,`vi_focusandattention`.`school_id` AS `school_id`,`vi_focusandattention`.`Memory` AS `Memory`,`vi_focusandattention`.`Visual Processing` AS `Visual Processing`,`vi_focusandattention`.`FocusAndAttention` AS `FocusAndAttention`,`vi_focusandattention`.`ProblemSolving` AS `ProblemSolving`,`vi_focusandattention`.`Lingustics` AS `Lingustics` from `vi_focusandattention` union all select `vi_problemsolving`.`Grade` AS `Grade`,`vi_problemsolving`.`user_section` AS `user_section`,`vi_problemsolving`.`UserID` AS `UserID`,`vi_problemsolving`.`UserName` AS `UserName`,`vi_problemsolving`.`Date` AS `date`,`vi_problemsolving`.`school_id` AS `school_id`,`vi_problemsolving`.`Memory` AS `Memory`,`vi_problemsolving`.`Visual Processing` AS `Visual Processing`,`vi_problemsolving`.`FocusAndAttention` AS `FocusAndAttention`,`vi_problemsolving`.`ProblemSolving` AS `ProblemSolving`,`vi_problemsolving`.`Lingustics` AS `Lingustics` from `vi_problemsolving` union all select `vi_lingustics`.`Grade` AS `Grade`,`vi_lingustics`.`user_section` AS `user_section`,`vi_lingustics`.`UserID` AS `UserID`,`vi_lingustics`.`UserName` AS `UserName`,`vi_lingustics`.`Date` AS `date`,`vi_lingustics`.`school_id` AS `school_id`,`vi_lingustics`.`Memory` AS `Memory`,`vi_lingustics`.`Visual Processing` AS `Visual Processing`,`vi_lingustics`.`FocusAndAttention` AS `FocusAndAttention`,`vi_lingustics`.`ProblemSolving` AS `ProblemSolving`,`vi_lingustics`.`Lingustics` AS `Lingustics` from `vi_lingustics` ;

-- --------------------------------------------------------

--
-- Structure for view `vi_lingustics`
--
DROP TABLE IF EXISTS `vi_lingustics`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vi_lingustics`  AS  select `cls`.`classname` AS `Grade`,`sec`.`section` AS `user_section`,`usr`.`id` AS `UserID`,`usr`.`sid` AS `school_id`,concat(`usr`.`fname`,' ',`usr`.`lname`) AS `UserName`,`gr`.`lastupdate` AS `Date`,NULL AS `Memory`,NULL AS `Visual Processing`,NULL AS `FocusAndAttention`,NULL AS `ProblemSolving`,`gr`.`game_score` AS `Lingustics` from ((((`game_reports` `gr` join `users` `usr` on((`usr`.`id` = `gr`.`gu_id`))) join `class` `cls` on((`cls`.`id` = `usr`.`grade_id`))) join `skl_class_section` `sec` on((`sec`.`section` = `usr`.`section`))) join `category_skills` `cs` on((`cs`.`id` = `gr`.`gs_id`))) where (`cs`.`name` = 'Linguistics') ;

-- --------------------------------------------------------

--
-- Structure for view `vi_lingusticsstar`
--
DROP TABLE IF EXISTS `vi_lingusticsstar`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vi_lingusticsstar`  AS  select `cls`.`classname` AS `Grade`,`sec`.`section` AS `user_section`,`usr`.`id` AS `UserID`,`usr`.`sid` AS `school_id`,concat(`usr`.`fname`,' ',`usr`.`lname`) AS `UserName`,`gr`.`lastupdate` AS `Date`,NULL AS `Memory`,NULL AS `Visual Processing`,NULL AS `FocusAndAttention`,NULL AS `ProblemSolving`,ifnull(floor(avg((`gr`.`game_score` / 20))),0) AS `Lingustics` from ((((`game_reports` `gr` join `users` `usr` on((`usr`.`id` = `gr`.`gu_id`))) join `class` `cls` on((`cls`.`id` = `usr`.`grade_id`))) join `skl_class_section` `sec` on((`sec`.`section` = `usr`.`section`))) join `category_skills` `cs` on((`cs`.`id` = `gr`.`gs_id`))) where (`cs`.`name` = 'Linguistics') ;

-- --------------------------------------------------------

--
-- Structure for view `vi_maxbspibymsg`
--
DROP TABLE IF EXISTS `vi_maxbspibymsg`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vi_maxbspibymsg`  AS  select max(`bspi4`.`bspi`) AS `bspi`,`bspi4`.`gu_id` AS `gu_id`,`bspi4`.`monthNumber` AS `monthNumber`,`bspi4`.`sid` AS `sid`,`bspi4`.`grade_id` AS `grade_id` from `vi_avguserbspiscore` `bspi4` where `bspi4`.`gu_id` in (select `users`.`id` from `users` where ((`users`.`status` = 1) and (`users`.`visible` = 1))) group by `bspi4`.`monthNumber`,`bspi4`.`sid`,`bspi4`.`grade_id` ;

-- --------------------------------------------------------

--
-- Structure for view `vi_maxfcrownypoints`
--
DROP TABLE IF EXISTS `vi_maxfcrownypoints`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vi_maxfcrownypoints`  AS  select max(`vv1`.`points`) AS `points`,`vv1`.`S_ID` AS `S_ID`,`vv1`.`G_ID` AS `G_ID` from `vi_sumofcrownypoints` `vv1` group by `vv1`.`S_ID`,`vv1`.`G_ID` ;

-- --------------------------------------------------------

--
-- Structure for view `vi_memory`
--
DROP TABLE IF EXISTS `vi_memory`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vi_memory`  AS  select `cls`.`classname` AS `Grade`,`sec`.`section` AS `user_section`,`usr`.`id` AS `UserID`,`usr`.`sid` AS `school_id`,concat(`usr`.`fname`,' ',`usr`.`lname`) AS `UserName`,`gr`.`lastupdate` AS `Date`,`gr`.`game_score` AS `Memory`,NULL AS `VP`,NULL AS `FocusAndAttention`,NULL AS `ProblemSolving`,NULL AS `Lingustics` from ((((`game_reports` `gr` join `users` `usr` on((`usr`.`id` = `gr`.`gu_id`))) join `class` `cls` on((`cls`.`id` = `usr`.`grade_id`))) join `skl_class_section` `sec` on((`sec`.`section` = `usr`.`section`))) join `category_skills` `cs` on((`cs`.`id` = `gr`.`gs_id`))) where (`cs`.`name` = 'Memory') ;

-- --------------------------------------------------------

--
-- Structure for view `vi_memorystar`
--
DROP TABLE IF EXISTS `vi_memorystar`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vi_memorystar`  AS  select `cls`.`classname` AS `Grade`,`sec`.`section` AS `user_section`,`usr`.`id` AS `UserID`,`usr`.`sid` AS `school_id`,concat(`usr`.`fname`,' ',`usr`.`lname`) AS `UserName`,`gr`.`lastupdate` AS `Date`,ifnull(floor(avg((`gr`.`game_score` / 20))),0) AS `Memory`,NULL AS `VP`,NULL AS `FocusAndAttention`,NULL AS `ProblemSolving`,NULL AS `Lingustics` from ((((`game_reports` `gr` join `users` `usr` on((`usr`.`id` = `gr`.`gu_id`))) join `class` `cls` on((`cls`.`id` = `usr`.`grade_id`))) join `skl_class_section` `sec` on((`sec`.`section` = `usr`.`section`))) join `category_skills` `cs` on((`cs`.`id` = `gr`.`gs_id`))) where (`cs`.`name` = 'Memory') ;

-- --------------------------------------------------------

--
-- Structure for view `vi_monthwisebspi`
--
DROP TABLE IF EXISTS `vi_monthwisebspi`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vi_monthwisebspi`  AS  select max(`bspi3`.`bspi`) AS `bspi`,`bspi3`.`monthNumber` AS `monthNumber`,`bspi3`.`monthName` AS `monthName`,`bspi3`.`sid` AS `sid`,`bspi3`.`grade_id` AS `grade_id` from `vi_avguserbspiscore` `bspi3` group by `bspi3`.`monthNumber` ;

-- --------------------------------------------------------

--
-- Structure for view `vi_overallbspitoppers`
--
DROP TABLE IF EXISTS `vi_overallbspitoppers`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vi_overallbspitoppers`  AS  select max(`vi_avgofbspi`.`score`) AS `bspi`,`vi_avgofbspi`.`gu_id` AS `gu_id`,`vi_avgofbspi`.`lastupdate` AS `lastupdate`,`vi_avgofbspi`.`sid` AS `sid`,`vi_avgofbspi`.`grade_id` AS `grade_id` from `vi_avgofbspi` where `vi_avgofbspi`.`sid` in (select `schools`.`id` from `schools` where (`schools`.`visible` = 1)) group by `vi_avgofbspi`.`grade_id` ;

-- --------------------------------------------------------

--
-- Structure for view `vi_overallcrownytoppers`
--
DROP TABLE IF EXISTS `vi_overallcrownytoppers`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vi_overallcrownytoppers`  AS  select max(`vv2`.`points`) AS `points`,`vv2`.`G_ID` AS `G_ID` from `vi_maxfcrownypoints` `vv2` group by `vv2`.`G_ID` ;

-- --------------------------------------------------------

--
-- Structure for view `vi_overallsparkytopper`
--
DROP TABLE IF EXISTS `vi_overallsparkytopper`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vi_overallsparkytopper`  AS  select max(`vv2`.`points`) AS `points`,`vv2`.`monthName` AS `monthName`,`vv2`.`monthNumber` AS `monthNumber`,`vv2`.`G_ID` AS `G_ID` from `vv2` where `vv2`.`S_ID` in (select `schools`.`id` from `schools` where (`schools`.`visible` = 1)) group by `vv2`.`monthName`,`vv2`.`G_ID` ;

-- --------------------------------------------------------

--
-- Structure for view `vi_problemsolving`
--
DROP TABLE IF EXISTS `vi_problemsolving`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vi_problemsolving`  AS  select `cls`.`classname` AS `Grade`,`sec`.`section` AS `user_section`,`usr`.`id` AS `UserID`,`usr`.`sid` AS `school_id`,concat(`usr`.`fname`,' ',`usr`.`lname`) AS `UserName`,`gr`.`lastupdate` AS `Date`,NULL AS `Memory`,NULL AS `Visual Processing`,NULL AS `FocusAndAttention`,`gr`.`game_score` AS `ProblemSolving`,NULL AS `Lingustics` from ((((`game_reports` `gr` join `users` `usr` on((`usr`.`id` = `gr`.`gu_id`))) join `class` `cls` on((`cls`.`id` = `usr`.`grade_id`))) join `skl_class_section` `sec` on((`sec`.`section` = `usr`.`section`))) join `category_skills` `cs` on((`cs`.`id` = `gr`.`gs_id`))) where (`cs`.`name` = 'Problem Solving') ;

-- --------------------------------------------------------

--
-- Structure for view `vi_problemsolvingstar`
--
DROP TABLE IF EXISTS `vi_problemsolvingstar`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vi_problemsolvingstar`  AS  select `cls`.`classname` AS `Grade`,`sec`.`section` AS `user_section`,`usr`.`id` AS `UserID`,`usr`.`sid` AS `school_id`,concat(`usr`.`fname`,' ',`usr`.`lname`) AS `UserName`,`gr`.`lastupdate` AS `Date`,NULL AS `Memory`,NULL AS `Visual Processing`,NULL AS `FocusAndAttention`,ifnull(floor(avg((`gr`.`game_score` / 20))),0) AS `ProblemSolving`,NULL AS `Lingustics` from ((((`game_reports` `gr` join `users` `usr` on((`usr`.`id` = `gr`.`gu_id`))) join `class` `cls` on((`cls`.`id` = `usr`.`grade_id`))) join `skl_class_section` `sec` on((`sec`.`section` = `usr`.`section`))) join `category_skills` `cs` on((`cs`.`id` = `gr`.`gs_id`))) where (`cs`.`name` = 'Problem Solving') ;

-- --------------------------------------------------------

--
-- Structure for view `vi_silver`
--
DROP TABLE IF EXISTS `vi_silver`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vi_silver`  AS  select `vi_star`.`userid` AS `userid`,`vi_star`.`UserName` AS `UserName`,`vi_star`.`school_id` AS `school_id`,`vi_star`.`Grade` AS `Grade`,extract(month from `vi_star`.`date`) AS `MONTH`,floor((((sum(`vi_star`.`MEMORYSTAR`) % 60) % 30) / 15)) AS `SMEMORY`,floor((((sum(`vi_star`.`VPSTAR`) % 60) % 30) / 15)) AS `SVP`,floor((((sum(`vi_star`.`FASTAR`) % 60) % 30) / 15)) AS `SFA`,floor((((sum(`vi_star`.`PSSTAR`) % 60) % 30) / 15)) AS `SPS`,floor((((sum(`vi_star`.`LGSTAR`) % 60) % 30) / 15)) AS `SLG`,((((floor((((sum(`vi_star`.`MEMORYSTAR`) % 60) % 30) / 15)) + floor((((sum(`vi_star`.`VPSTAR`) % 60) % 30) / 15))) + floor((((sum(`vi_star`.`FASTAR`) % 60) % 30) / 15))) + floor((((sum(`vi_star`.`PSSTAR`) % 60) % 30) / 15))) + floor((((sum(`vi_star`.`LGSTAR`) % 60) % 30) / 15))) AS `stotal` from `vi_star` group by `vi_star`.`userid`,`vi_star`.`UserName`,`vi_star`.`school_id`,`vi_star`.`Grade`,extract(month from `vi_star`.`date`) ;

-- --------------------------------------------------------

--
-- Structure for view `vi_star`
--
DROP TABLE IF EXISTS `vi_star`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vi_star`  AS  select `vi_gradeskillpivotsource`.`UserID` AS `userid`,`vi_gradeskillpivotsource`.`UserName` AS `UserName`,`vi_gradeskillpivotsource`.`school_id` AS `school_id`,`vi_gradeskillpivotsource`.`Grade` AS `Grade`,`vi_gradeskillpivotsource`.`date` AS `date`,floor((avg(ifnull(`vi_gradeskillpivotsource`.`Memory`,0)) / 20)) AS `MEMORYSTAR`,floor((avg(ifnull(`vi_gradeskillpivotsource`.`vp`,0)) / 20)) AS `VPSTAR`,floor((avg(ifnull(`vi_gradeskillpivotsource`.`FocusAndAttention`,0)) / 20)) AS `FASTAR`,floor((avg(ifnull(`vi_gradeskillpivotsource`.`ProblemSolving`,0)) / 20)) AS `PSSTAR`,floor((avg(ifnull(`vi_gradeskillpivotsource`.`Lingustics`,0)) / 20)) AS `LGSTAR` from `vi_gradeskillpivotsource` group by `vi_gradeskillpivotsource`.`UserID`,`vi_gradeskillpivotsource`.`UserName`,`vi_gradeskillpivotsource`.`school_id`,`vi_gradeskillpivotsource`.`Grade`,`vi_gradeskillpivotsource`.`date` ;

-- --------------------------------------------------------

--
-- Structure for view `vi_sumofcrownypoints`
--
DROP TABLE IF EXISTS `vi_sumofcrownypoints`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vi_sumofcrownypoints`  AS  select `a2`.`U_ID` AS `U_ID`,`a2`.`S_ID` AS `S_ID`,`a2`.`G_ID` AS `G_ID`,sum(`a2`.`Points`) AS `points`,(select `users`.`section` from `users` where (`users`.`id` = `a2`.`U_ID`)) AS `section` from `user_sparkies_history` `a2` where ((convert(date_format(`a2`.`Datetime`,'%Y-%m-%d') using latin1) between (select `academic_year`.`startdate` from `academic_year` where (`academic_year`.`id` = 20)) and (select `academic_year`.`enddate` from `academic_year` where (`academic_year`.`id` = 20))) and `a2`.`U_ID` in (select `users`.`id` from `users` where ((`users`.`status` = 1) and (`users`.`visible` = 1)))) group by `a2`.`U_ID` ;

-- --------------------------------------------------------

--
-- Structure for view `vi_sumofcrownypoints1`
--
DROP TABLE IF EXISTS `vi_sumofcrownypoints1`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vi_sumofcrownypoints1`  AS  select `a2`.`U_ID` AS `U_ID`,`a2`.`S_ID` AS `S_ID`,`a2`.`G_ID` AS `G_ID`,sum(`a2`.`Points`) AS `points`,(select `users`.`section` from `users` where (`users`.`id` = `a2`.`U_ID`)) AS `section` from (`user_sparkies_history` `a2` join `users` `u` on((`u`.`id` = `a2`.`U_ID`))) where ((convert(date_format(`a2`.`Datetime`,'%Y-%m-%d') using latin1) between (select `academic_year`.`startdate` from `academic_year` where (`academic_year`.`id` = 20)) and (select `academic_year`.`enddate` from `academic_year` where (`academic_year`.`id` = 20))) and (`u`.`status` = 1) and (`u`.`visible` = 1)) group by `a2`.`U_ID` ;

-- --------------------------------------------------------

--
-- Structure for view `vi_toppersbspi`
--
DROP TABLE IF EXISTS `vi_toppersbspi`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vi_toppersbspi`  AS  select max(`bspi3`.`bspi`) AS `bspi`,`bspi3`.`monthNumber` AS `monthNumber`,`bspi3`.`monthName` AS `monthName`,`bspi3`.`sid` AS `sid`,`bspi3`.`grade_id` AS `grade_id` from `vi_avguserbspiscore` `bspi3` where `bspi3`.`sid` in (select `schools`.`id` from `schools` where (`schools`.`visible` = 1)) group by `bspi3`.`monthNumber`,`bspi3`.`grade_id` ;

-- --------------------------------------------------------

--
-- Structure for view `vi_totgamesplayed`
--
DROP TABLE IF EXISTS `vi_totgamesplayed`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vi_totgamesplayed`  AS  select count(`game_reports`.`gu_id`) AS `countofplayed`,`game_reports`.`gu_id` AS `gu_id`,date_format(`game_reports`.`lastupdate`,'%b') AS `monthName`,date_format(`game_reports`.`lastupdate`,'%m') AS `monthNumber`,year(`game_reports`.`lastupdate`) AS `monofyear`,(select `users`.`sid` from `users` where (`users`.`id` = `game_reports`.`gu_id`)) AS `gs_ID`,(select `users`.`grade_id` from `users` where (`users`.`id` = `game_reports`.`gu_id`)) AS `grad_ID` from `game_reports` where (convert(date_format(`game_reports`.`lastupdate`,'%Y-%m-%d') using latin1) between (select `users`.`startdate` from `users` where (`users`.`id` = `game_reports`.`gu_id`)) and (select `users`.`enddate` from `users` where (`users`.`id` = `game_reports`.`gu_id`))) group by concat(date_format(`game_reports`.`lastupdate`,'%m'),'-',year(`game_reports`.`lastupdate`)),`game_reports`.`gu_id` ;

-- --------------------------------------------------------

--
-- Structure for view `vi_trophies`
--
DROP TABLE IF EXISTS `vi_trophies`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vi_trophies`  AS  select `vi_star`.`userid` AS `userid`,`vi_star`.`UserName` AS `UserName`,`vi_star`.`school_id` AS `school_id`,`vi_star`.`Grade` AS `Grade`,extract(month from `vi_star`.`date`) AS `MONTH`,floor((((((sum(`vi_star`.`MEMORYSTAR`) + sum(`vi_star`.`VPSTAR`)) + sum(`vi_star`.`FASTAR`)) + sum(`vi_star`.`PSSTAR`)) + sum(`vi_star`.`LGSTAR`)) / 60)) AS `DIAMOND`,floor(((((((sum(`vi_star`.`MEMORYSTAR`) + sum(`vi_star`.`VPSTAR`)) + sum(`vi_star`.`FASTAR`)) + sum(`vi_star`.`PSSTAR`)) + sum(`vi_star`.`LGSTAR`)) % 60) / 30)) AS `GOLD`,floor((((((((sum(`vi_star`.`MEMORYSTAR`) + sum(`vi_star`.`VPSTAR`)) + sum(`vi_star`.`FASTAR`)) + sum(`vi_star`.`PSSTAR`)) + sum(`vi_star`.`LGSTAR`)) % 60) % 30) / 15)) AS `SILVER` from `vi_star` group by `vi_star`.`userid`,`vi_star`.`UserName`,`vi_star`.`school_id`,`vi_star`.`Grade`,extract(month from `vi_star`.`date`) ;

-- --------------------------------------------------------

--
-- Structure for view `vi_vp`
--
DROP TABLE IF EXISTS `vi_vp`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vi_vp`  AS  select `cls`.`classname` AS `Grade`,`sec`.`section` AS `user_section`,`usr`.`id` AS `UserID`,`usr`.`sid` AS `school_id`,concat(`usr`.`fname`,' ',`usr`.`lname`) AS `UserName`,`gr`.`lastupdate` AS `Date`,NULL AS `Memory`,`gr`.`game_score` AS `Visual Processing`,NULL AS `FocusAndAttention`,NULL AS `ProblemSolving`,NULL AS `Lingustics` from ((((`game_reports` `gr` join `users` `usr` on((`usr`.`id` = `gr`.`gu_id`))) join `class` `cls` on((`cls`.`id` = `usr`.`grade_id`))) join `skl_class_section` `sec` on((`sec`.`section` = `usr`.`section`))) join `category_skills` `cs` on((`cs`.`id` = `gr`.`gs_id`))) where (`cs`.`name` = 'Visual Processing') ;

-- --------------------------------------------------------

--
-- Structure for view `vi_vpstar`
--
DROP TABLE IF EXISTS `vi_vpstar`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vi_vpstar`  AS  select `cls`.`classname` AS `Grade`,`sec`.`section` AS `user_section`,`usr`.`id` AS `UserID`,`usr`.`sid` AS `school_id`,concat(`usr`.`fname`,' ',`usr`.`lname`) AS `UserName`,`gr`.`lastupdate` AS `Date`,NULL AS `Memory`,ifnull(floor(avg((`gr`.`game_score` / 20))),0) AS `Visual Processing`,NULL AS `FocusAndAttention`,NULL AS `ProblemSolving`,NULL AS `Lingustics` from ((((`game_reports` `gr` join `users` `usr` on((`usr`.`id` = `gr`.`gu_id`))) join `class` `cls` on((`cls`.`id` = `usr`.`grade_id`))) join `skl_class_section` `sec` on((`sec`.`section` = `usr`.`section`))) join `category_skills` `cs` on((`cs`.`id` = `gr`.`gs_id`))) where (`cs`.`name` = 'Visual Processing') ;

-- --------------------------------------------------------

--
-- Structure for view `vv1`
--
DROP TABLE IF EXISTS `vv1`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vv1`  AS  select `a2`.`U_ID` AS `U_ID`,`a2`.`S_ID` AS `S_ID`,`a2`.`G_ID` AS `G_ID`,sum(`a2`.`Points`) AS `points`,date_format(`a2`.`Datetime`,'%b') AS `monthName`,date_format(`a2`.`Datetime`,'%m') AS `monthNumber`,year(`a2`.`Datetime`) AS `monofyear` from `user_sparkies_history` `a2` where (convert(date_format(`a2`.`Datetime`,'%Y-%m-%d') using latin1) between (select `users`.`startdate` from `users` where (`users`.`id` = `a2`.`U_ID`)) and (select `users`.`enddate` from `users` where (`users`.`id` = `a2`.`U_ID`))) group by concat(date_format(`a2`.`Datetime`,'%m'),'-',year(`a2`.`Datetime`)),`a2`.`U_ID` ;

-- --------------------------------------------------------

--
-- Structure for view `vv2`
--
DROP TABLE IF EXISTS `vv2`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vv2`  AS  select max(`vv1`.`points`) AS `points`,`vv1`.`monthName` AS `monthName`,`vv1`.`monthNumber` AS `monthNumber`,`vv1`.`S_ID` AS `S_ID`,`vv1`.`G_ID` AS `G_ID`,`vv1`.`monofyear` AS `monofyear` from `vv1` where `vv1`.`U_ID` in (select `users`.`id` from `users` where ((`users`.`status` = 1) and (`users`.`visible` = 1))) group by concat(`vv1`.`monthName`,'-',`vv1`.`monofyear`),`vv1`.`S_ID`,`vv1`.`G_ID` ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `academic_year`
--
ALTER TABLE `academic_year`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `academy_admin_password_history`
--
ALTER TABLE `academy_admin_password_history`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `ID` (`ID`);

--
-- Indexes for table `accesslog`
--
ALTER TABLE `accesslog`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `admin_login_log`
--
ALTER TABLE `admin_login_log`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `userid` (`adminid`),
  ADD KEY `sessionid` (`sessionid`);

--
-- Indexes for table `admin_password_history`
--
ALTER TABLE `admin_password_history`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `android_games`
--
ALTER TABLE `android_games`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `app_remainingtime`
--
ALTER TABLE `app_remainingtime`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `asap_gamedata`
--
ALTER TABLE `asap_gamedata`
  ADD PRIMARY KEY (`id`),
  ADD KEY `gu_id` (`gu_id`),
  ADD KEY `gs_id` (`gs_id`),
  ADD KEY `gp_id` (`gp_id`),
  ADD KEY `lastupdate` (`lastupdate`);

--
-- Indexes for table `asap_gamescore`
--
ALTER TABLE `asap_gamescore`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `asap_game_mapping`
--
ALTER TABLE `asap_game_mapping`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `assignedgames`
--
ALTER TABLE `assignedgames`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `bandwidth_config`
--
ALTER TABLE `bandwidth_config`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `ID` (`ID`);

--
-- Indexes for table `bandwidth_log`
--
ALTER TABLE `bandwidth_log`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `ID` (`ID`);

--
-- Indexes for table `category_skills`
--
ALTER TABLE `category_skills`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `center_login_log`
--
ALTER TABLE `center_login_log`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `userid` (`centerid`),
  ADD KEY `sessionid` (`sessionid`);

--
-- Indexes for table `challenge`
--
ALTER TABLE `challenge`
  ADD PRIMARY KEY (`sno`);

--
-- Indexes for table `change_password_history`
--
ALTER TABLE `change_password_history`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id` (`id`);

--
-- Indexes for table `city`
--
ALTER TABLE `city`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `class`
--
ALTER TABLE `class`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `class_plan_game`
--
ALTER TABLE `class_plan_game`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `class_skill_game`
--
ALTER TABLE `class_skill_game`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `client_approved_license`
--
ALTER TABLE `client_approved_license`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `config_master`
--
ALTER TABLE `config_master`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `couponmaster`
--
ALTER TABLE `couponmaster`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `couponcode` (`couponcode`);

--
-- Indexes for table `daywisebadgetopper`
--
ALTER TABLE `daywisebadgetopper`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `doctormaster`
--
ALTER TABLE `doctormaster`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `edsix_issued_coupon`
--
ALTER TABLE `edsix_issued_coupon`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id` (`id`);

--
-- Indexes for table `edsix_issued_license`
--
ALTER TABLE `edsix_issued_license`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `eom_report`
--
ALTER TABLE `eom_report`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `gamedata`
--
ALTER TABLE `gamedata`
  ADD PRIMARY KEY (`id`),
  ADD KEY `gu_id` (`gu_id`),
  ADD KEY `gs_id` (`gs_id`),
  ADD KEY `gp_id` (`gp_id`),
  ADD KEY `lastupdate` (`lastupdate`);

--
-- Indexes for table `gamedata_cq`
--
ALTER TABLE `gamedata_cq`
  ADD PRIMARY KEY (`id`),
  ADD KEY `gu_id` (`gu_id`),
  ADD KEY `gs_id` (`gs_id`),
  ADD KEY `gp_id` (`gp_id`),
  ADD KEY `lastupdate` (`lastupdate`);

--
-- Indexes for table `games`
--
ALTER TABLE `games`
  ADD PRIMARY KEY (`gid`);

--
-- Indexes for table `gamescore`
--
ALTER TABLE `gamescore`
  ADD PRIMARY KEY (`id`),
  ADD KEY `userid` (`userid`),
  ADD KEY `gameid` (`gameid`),
  ADD KEY `skillid` (`skillid`),
  ADD KEY `answerstatus` (`answerstatus`),
  ADD KEY `updateddate` (`updateddate`),
  ADD KEY `userid_2` (`userid`),
  ADD KEY `gameid_2` (`gameid`),
  ADD KEY `skillid_2` (`skillid`),
  ADD KEY `gp_id` (`gp_id`),
  ADD KEY `iteration` (`iteration`),
  ADD KEY `updateddate_2` (`updateddate`);

--
-- Indexes for table `games_cq`
--
ALTER TABLE `games_cq`
  ADD PRIMARY KEY (`gid`);

--
-- Indexes for table `game_groupmaster`
--
ALTER TABLE `game_groupmaster`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `game_group_mapping`
--
ALTER TABLE `game_group_mapping`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `game_language_track`
--
ALTER TABLE `game_language_track`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `game_levels`
--
ALTER TABLE `game_levels`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `game_limit`
--
ALTER TABLE `game_limit`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `g_category`
--
ALTER TABLE `g_category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `g_plans`
--
ALTER TABLE `g_plans`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `g_skills`
--
ALTER TABLE `g_skills`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `hospitalmaster`
--
ALTER TABLE `hospitalmaster`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `isuser_log`
--
ALTER TABLE `isuser_log`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `language_master`
--
ALTER TABLE `language_master`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `leaderboard`
--
ALTER TABLE `leaderboard`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `lgames`
--
ALTER TABLE `lgames`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `license_count`
--
ALTER TABLE `license_count`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id` (`id`);

--
-- Indexes for table `newsfeedmaster`
--
ALTER TABLE `newsfeedmaster`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `newsfeed_config`
--
ALTER TABLE `newsfeed_config`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `newsfeed_data_status`
--
ALTER TABLE `newsfeed_data_status`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `order_details`
--
ALTER TABLE `order_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `organization_master`
--
ALTER TABLE `organization_master`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id` (`id`);

--
-- Indexes for table `parent_change_password_history`
--
ALTER TABLE `parent_change_password_history`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id` (`id`);

--
-- Indexes for table `parent_login_log`
--
ALTER TABLE `parent_login_log`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `password_history`
--
ALTER TABLE `password_history`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product_master`
--
ALTER TABLE `product_master`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pullrequest_gamedata`
--
ALTER TABLE `pullrequest_gamedata`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pullrequest_gamelist`
--
ALTER TABLE `pullrequest_gamelist`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `rand_selection`
--
ALTER TABLE `rand_selection`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `school_id` (`school_id`),
  ADD KEY `gid` (`gid`);

--
-- Indexes for table `rand_selection_cq`
--
ALTER TABLE `rand_selection_cq`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `school_id` (`school_id`),
  ADD KEY `gid` (`gid`);

--
-- Indexes for table `range_values`
--
ALTER TABLE `range_values`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `registration`
--
ALTER TABLE `registration`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `schools`
--
ALTER TABLE `schools`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `schools_language`
--
ALTER TABLE `schools_language`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `schools_leave_list`
--
ALTER TABLE `schools_leave_list`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `schools_period_schedule`
--
ALTER TABLE `schools_period_schedule`
  ADD PRIMARY KEY (`schedule_id`),
  ADD KEY `schedule_id` (`schedule_id`);

--
-- Indexes for table `schools_period_schedule_days`
--
ALTER TABLE `schools_period_schedule_days`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `school_academic_mapping`
--
ALTER TABLE `school_academic_mapping`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `school_admin`
--
ALTER TABLE `school_admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `school_master`
--
ALTER TABLE `school_master`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `school_parent_master`
--
ALTER TABLE `school_parent_master`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `section`
--
ALTER TABLE `section`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `skillkit_configuration`
--
ALTER TABLE `skillkit_configuration`
  ADD PRIMARY KEY (`Recid`);

--
-- Indexes for table `skillkit_game_reports`
--
ALTER TABLE `skillkit_game_reports`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `skillkit_random_game`
--
ALTER TABLE `skillkit_random_game`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `skl_class`
--
ALTER TABLE `skl_class`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `skl_class_plan`
--
ALTER TABLE `skl_class_plan`
  ADD PRIMARY KEY (`id`),
  ADD KEY `school_id` (`school_id`),
  ADD KEY `class_id` (`class_id`),
  ADD KEY `plan_id` (`plan_id`);

--
-- Indexes for table `skl_class_section`
--
ALTER TABLE `skl_class_section`
  ADD PRIMARY KEY (`id`),
  ADD KEY `school_id` (`school_id`),
  ADD KEY `class_id` (`class_id`),
  ADD KEY `section` (`section`);

--
-- Indexes for table `skl_dcnt_coupon`
--
ALTER TABLE `skl_dcnt_coupon`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `skl_grade`
--
ALTER TABLE `skl_grade`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `skl_grade_game_map`
--
ALTER TABLE `skl_grade_game_map`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `skl_prepaid_coupon`
--
ALTER TABLE `skl_prepaid_coupon`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sk_gamedata`
--
ALTER TABLE `sk_gamedata`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sk_games`
--
ALTER TABLE `sk_games`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `sk_gamescore`
--
ALTER TABLE `sk_gamescore`
  ADD PRIMARY KEY (`id`),
  ADD KEY `userid` (`userid`),
  ADD KEY `gameid` (`gameid`),
  ADD KEY `skillid` (`skillid`),
  ADD KEY `answerstatus` (`answerstatus`),
  ADD KEY `updateddate` (`updateddate`),
  ADD KEY `userid_2` (`userid`),
  ADD KEY `gameid_2` (`gameid`),
  ADD KEY `skillid_2` (`skillid`),
  ADD KEY `gp_id` (`gp_id`),
  ADD KEY `iteration` (`iteration`),
  ADD KEY `updateddate_2` (`updateddate`);

--
-- Indexes for table `sk_games_plan`
--
ALTER TABLE `sk_games_plan`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `sk_personalized_game`
--
ALTER TABLE `sk_personalized_game`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `sk_plan_skillcount`
--
ALTER TABLE `sk_plan_skillcount`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `sk_rand_selection`
--
ALTER TABLE `sk_rand_selection`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sk_user_game_list`
--
ALTER TABLE `sk_user_game_list`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `sparkiesmaster`
--
ALTER TABLE `sparkiesmaster`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `state`
--
ALTER TABLE `state`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_feedback`
--
ALTER TABLE `tbl_feedback`
  ADD PRIMARY KEY (`feedbackid`);

--
-- Indexes for table `tbl_payment`
--
ALTER TABLE `tbl_payment`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `teachers`
--
ALTER TABLE `teachers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `teacher_class`
--
ALTER TABLE `teacher_class`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `thememaster`
--
ALTER TABLE `thememaster`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `userbadge_data`
--
ALTER TABLE `userbadge_data`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `userplaytime`
--
ALTER TABLE `userplaytime`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD KEY `status` (`status`),
  ADD KEY `grade_id` (`grade_id`),
  ADD KEY `username` (`username`),
  ADD KEY `sid` (`sid`),
  ADD KEY `section` (`section`),
  ADD KEY `academicyear` (`academicyear`);

--
-- Indexes for table `userscreenaccess`
--
ALTER TABLE `userscreenaccess`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users_bkp`
--
ALTER TABLE `users_bkp`
  ADD PRIMARY KEY (`id`),
  ADD KEY `status` (`status`),
  ADD KEY `grade_id` (`grade_id`),
  ADD KEY `username` (`username`),
  ADD KEY `sid` (`sid`),
  ADD KEY `section` (`section`),
  ADD KEY `academicyear` (`academicyear`);

--
-- Indexes for table `users_check`
--
ALTER TABLE `users_check`
  ADD PRIMARY KEY (`id`),
  ADD KEY `status` (`status`),
  ADD KEY `grade_id` (`grade_id`),
  ADD KEY `username` (`username`),
  ADD KEY `sid` (`sid`),
  ADD KEY `section` (`section`),
  ADD KEY `academicyear` (`academicyear`);

--
-- Indexes for table `users_check_1`
--
ALTER TABLE `users_check_1`
  ADD PRIMARY KEY (`id`),
  ADD KEY `status` (`status`),
  ADD KEY `grade_id` (`grade_id`),
  ADD KEY `username` (`username`),
  ADD KEY `sid` (`sid`),
  ADD KEY `section` (`section`),
  ADD KEY `academicyear` (`academicyear`);

--
-- Indexes for table `users_new`
--
ALTER TABLE `users_new`
  ADD PRIMARY KEY (`id`),
  ADD KEY `status` (`status`),
  ADD KEY `grade_id` (`grade_id`),
  ADD KEY `username` (`username`),
  ADD KEY `sid` (`sid`),
  ADD KEY `section` (`section`),
  ADD KEY `academicyear` (`academicyear`);

--
-- Indexes for table `user_academic_mapping`
--
ALTER TABLE `user_academic_mapping`
  ADD PRIMARY KEY (`masterid`),
  ADD KEY `id` (`id`),
  ADD KEY `grade_id` (`grade_id`),
  ADD KEY `gp_id` (`gp_id`),
  ADD KEY `sid` (`sid`),
  ADD KEY `academicid` (`academicid`),
  ADD KEY `section` (`section`),
  ADD KEY `id_2` (`id`),
  ADD KEY `status` (`status`),
  ADD KEY `academicid_2` (`academicid`);

--
-- Indexes for table `user_academic_mapping_new`
--
ALTER TABLE `user_academic_mapping_new`
  ADD PRIMARY KEY (`masterid`),
  ADD KEY `id` (`id`),
  ADD KEY `grade_id` (`grade_id`),
  ADD KEY `gp_id` (`gp_id`),
  ADD KEY `sid` (`sid`),
  ADD KEY `academicid` (`academicid`),
  ADD KEY `section` (`section`),
  ADD KEY `id_2` (`id`),
  ADD KEY `status` (`status`),
  ADD KEY `academicid_2` (`academicid`);

--
-- Indexes for table `user_badgestatus`
--
ALTER TABLE `user_badgestatus`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id` (`id`),
  ADD KEY `id_2` (`id`);

--
-- Indexes for table `user_challenge_table`
--
ALTER TABLE `user_challenge_table`
  ADD PRIMARY KEY (`ugid`),
  ADD KEY `userid` (`userid`),
  ADD KEY `challengeid` (`challengeid`);

--
-- Indexes for table `user_class_limit`
--
ALTER TABLE `user_class_limit`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_games`
--
ALTER TABLE `user_games`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_games_history`
--
ALTER TABLE `user_games_history`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_games_plans`
--
ALTER TABLE `user_games_plans`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_game_feedback`
--
ALTER TABLE `user_game_feedback`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_limit`
--
ALTER TABLE `user_limit`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_login_log`
--
ALTER TABLE `user_login_log`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `userid` (`userid`),
  ADD KEY `sessionid` (`sessionid`);

--
-- Indexes for table `user_newsfeed_history`
--
ALTER TABLE `user_newsfeed_history`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `S_ID` (`S_ID`),
  ADD KEY `G_ID` (`G_ID`),
  ADD KEY `U_ID` (`U_ID`);

--
-- Indexes for table `user_parent_login_log`
--
ALTER TABLE `user_parent_login_log`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `userid` (`userid`),
  ADD KEY `sessionid` (`sessionid`);

--
-- Indexes for table `user_referral`
--
ALTER TABLE `user_referral`
  ADD PRIMARY KEY (`rid`);

--
-- Indexes for table `user_section_limit`
--
ALTER TABLE `user_section_limit`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_sparkies_history`
--
ALTER TABLE `user_sparkies_history`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `S_ID` (`S_ID`),
  ADD KEY `U_ID` (`U_ID`),
  ADD KEY `Scenario_ID` (`Scenario_ID`),
  ADD KEY `G_ID` (`G_ID`);

--
-- Indexes for table `utilizationreport`
--
ALTER TABLE `utilizationreport`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `academic_year`
--
ALTER TABLE `academic_year`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `academy_admin_password_history`
--
ALTER TABLE `academy_admin_password_history`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `accesslog`
--
ALTER TABLE `accesslog`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `admin_login_log`
--
ALTER TABLE `admin_login_log`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `admin_password_history`
--
ALTER TABLE `admin_password_history`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `android_games`
--
ALTER TABLE `android_games`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `app_remainingtime`
--
ALTER TABLE `app_remainingtime`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `asap_gamedata`
--
ALTER TABLE `asap_gamedata`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `asap_gamescore`
--
ALTER TABLE `asap_gamescore`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `asap_game_mapping`
--
ALTER TABLE `asap_game_mapping`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `assignedgames`
--
ALTER TABLE `assignedgames`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `bandwidth_config`
--
ALTER TABLE `bandwidth_config`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `bandwidth_log`
--
ALTER TABLE `bandwidth_log`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `category_skills`
--
ALTER TABLE `category_skills`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=71;

--
-- AUTO_INCREMENT for table `center_login_log`
--
ALTER TABLE `center_login_log`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `challenge`
--
ALTER TABLE `challenge`
  MODIFY `sno` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=181;

--
-- AUTO_INCREMENT for table `change_password_history`
--
ALTER TABLE `change_password_history`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `city`
--
ALTER TABLE `city`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=646;

--
-- AUTO_INCREMENT for table `class`
--
ALTER TABLE `class`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `class_plan_game`
--
ALTER TABLE `class_plan_game`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3394;

--
-- AUTO_INCREMENT for table `class_skill_game`
--
ALTER TABLE `class_skill_game`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=730;

--
-- AUTO_INCREMENT for table `client_approved_license`
--
ALTER TABLE `client_approved_license`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `config_master`
--
ALTER TABLE `config_master`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `couponmaster`
--
ALTER TABLE `couponmaster`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1017;

--
-- AUTO_INCREMENT for table `daywisebadgetopper`
--
ALTER TABLE `daywisebadgetopper`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `doctormaster`
--
ALTER TABLE `doctormaster`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `edsix_issued_coupon`
--
ALTER TABLE `edsix_issued_coupon`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `edsix_issued_license`
--
ALTER TABLE `edsix_issued_license`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `eom_report`
--
ALTER TABLE `eom_report`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `gamedata`
--
ALTER TABLE `gamedata`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `gamedata_cq`
--
ALTER TABLE `gamedata_cq`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `games`
--
ALTER TABLE `games`
  MODIFY `gid` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=91;

--
-- AUTO_INCREMENT for table `gamescore`
--
ALTER TABLE `gamescore`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `games_cq`
--
ALTER TABLE `games_cq`
  MODIFY `gid` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `game_groupmaster`
--
ALTER TABLE `game_groupmaster`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `game_group_mapping`
--
ALTER TABLE `game_group_mapping`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=91;

--
-- AUTO_INCREMENT for table `game_language_track`
--
ALTER TABLE `game_language_track`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `game_levels`
--
ALTER TABLE `game_levels`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `game_limit`
--
ALTER TABLE `game_limit`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `g_category`
--
ALTER TABLE `g_category`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `g_plans`
--
ALTER TABLE `g_plans`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=92;

--
-- AUTO_INCREMENT for table `g_skills`
--
ALTER TABLE `g_skills`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `hospitalmaster`
--
ALTER TABLE `hospitalmaster`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `isuser_log`
--
ALTER TABLE `isuser_log`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `language_master`
--
ALTER TABLE `language_master`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `leaderboard`
--
ALTER TABLE `leaderboard`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `lgames`
--
ALTER TABLE `lgames`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `license_count`
--
ALTER TABLE `license_count`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `newsfeedmaster`
--
ALTER TABLE `newsfeedmaster`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `newsfeed_config`
--
ALTER TABLE `newsfeed_config`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `newsfeed_data_status`
--
ALTER TABLE `newsfeed_data_status`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `order_details`
--
ALTER TABLE `order_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `organization_master`
--
ALTER TABLE `organization_master`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `parent_change_password_history`
--
ALTER TABLE `parent_change_password_history`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `parent_login_log`
--
ALTER TABLE `parent_login_log`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=75;

--
-- AUTO_INCREMENT for table `password_history`
--
ALTER TABLE `password_history`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `product_master`
--
ALTER TABLE `product_master`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `pullrequest_gamedata`
--
ALTER TABLE `pullrequest_gamedata`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pullrequest_gamelist`
--
ALTER TABLE `pullrequest_gamelist`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `rand_selection`
--
ALTER TABLE `rand_selection`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `rand_selection_cq`
--
ALTER TABLE `rand_selection_cq`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `range_values`
--
ALTER TABLE `range_values`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `registration`
--
ALTER TABLE `registration`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `schools`
--
ALTER TABLE `schools`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=173;

--
-- AUTO_INCREMENT for table `schools_language`
--
ALTER TABLE `schools_language`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `schools_leave_list`
--
ALTER TABLE `schools_leave_list`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `schools_period_schedule`
--
ALTER TABLE `schools_period_schedule`
  MODIFY `schedule_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=66;

--
-- AUTO_INCREMENT for table `schools_period_schedule_days`
--
ALTER TABLE `schools_period_schedule_days`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `school_academic_mapping`
--
ALTER TABLE `school_academic_mapping`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `school_admin`
--
ALTER TABLE `school_admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=55;

--
-- AUTO_INCREMENT for table `school_master`
--
ALTER TABLE `school_master`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `school_parent_master`
--
ALTER TABLE `school_parent_master`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=69;

--
-- AUTO_INCREMENT for table `section`
--
ALTER TABLE `section`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `skillkit_configuration`
--
ALTER TABLE `skillkit_configuration`
  MODIFY `Recid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `skillkit_game_reports`
--
ALTER TABLE `skillkit_game_reports`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `skillkit_random_game`
--
ALTER TABLE `skillkit_random_game`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `skl_class`
--
ALTER TABLE `skl_class`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `skl_class_plan`
--
ALTER TABLE `skl_class_plan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=160;

--
-- AUTO_INCREMENT for table `skl_class_section`
--
ALTER TABLE `skl_class_section`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=406;

--
-- AUTO_INCREMENT for table `skl_dcnt_coupon`
--
ALTER TABLE `skl_dcnt_coupon`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `skl_grade`
--
ALTER TABLE `skl_grade`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `skl_grade_game_map`
--
ALTER TABLE `skl_grade_game_map`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `skl_prepaid_coupon`
--
ALTER TABLE `skl_prepaid_coupon`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `sk_gamedata`
--
ALTER TABLE `sk_gamedata`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=674;

--
-- AUTO_INCREMENT for table `sk_games`
--
ALTER TABLE `sk_games`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=631;

--
-- AUTO_INCREMENT for table `sk_gamescore`
--
ALTER TABLE `sk_gamescore`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `sk_games_plan`
--
ALTER TABLE `sk_games_plan`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2490;

--
-- AUTO_INCREMENT for table `sk_personalized_game`
--
ALTER TABLE `sk_personalized_game`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=142;

--
-- AUTO_INCREMENT for table `sk_plan_skillcount`
--
ALTER TABLE `sk_plan_skillcount`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `sk_rand_selection`
--
ALTER TABLE `sk_rand_selection`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `sk_user_game_list`
--
ALTER TABLE `sk_user_game_list`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `sparkiesmaster`
--
ALTER TABLE `sparkiesmaster`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `tbl_feedback`
--
ALTER TABLE `tbl_feedback`
  MODIFY `feedbackid` int(10) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_payment`
--
ALTER TABLE `tbl_payment`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `teachers`
--
ALTER TABLE `teachers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `teacher_class`
--
ALTER TABLE `teacher_class`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=43;

--
-- AUTO_INCREMENT for table `thememaster`
--
ALTER TABLE `thememaster`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `userbadge_data`
--
ALTER TABLE `userbadge_data`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `userplaytime`
--
ALTER TABLE `userplaytime`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6878;

--
-- AUTO_INCREMENT for table `userscreenaccess`
--
ALTER TABLE `userscreenaccess`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users_bkp`
--
ALTER TABLE `users_bkp`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users_check`
--
ALTER TABLE `users_check`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users_check_1`
--
ALTER TABLE `users_check_1`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users_new`
--
ALTER TABLE `users_new`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `user_academic_mapping`
--
ALTER TABLE `user_academic_mapping`
  MODIFY `masterid` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `user_academic_mapping_new`
--
ALTER TABLE `user_academic_mapping_new`
  MODIFY `masterid` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `user_badgestatus`
--
ALTER TABLE `user_badgestatus`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `user_challenge_table`
--
ALTER TABLE `user_challenge_table`
  MODIFY `ugid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=49;

--
-- AUTO_INCREMENT for table `user_class_limit`
--
ALTER TABLE `user_class_limit`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=115;

--
-- AUTO_INCREMENT for table `user_games`
--
ALTER TABLE `user_games`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `user_games_history`
--
ALTER TABLE `user_games_history`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `user_games_plans`
--
ALTER TABLE `user_games_plans`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `user_game_feedback`
--
ALTER TABLE `user_game_feedback`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `user_limit`
--
ALTER TABLE `user_limit`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=380;

--
-- AUTO_INCREMENT for table `user_login_log`
--
ALTER TABLE `user_login_log`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `user_newsfeed_history`
--
ALTER TABLE `user_newsfeed_history`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `user_parent_login_log`
--
ALTER TABLE `user_parent_login_log`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `user_referral`
--
ALTER TABLE `user_referral`
  MODIFY `rid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `user_section_limit`
--
ALTER TABLE `user_section_limit`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=157;

--
-- AUTO_INCREMENT for table `user_sparkies_history`
--
ALTER TABLE `user_sparkies_history`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `utilizationreport`
--
ALTER TABLE `utilizationreport`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
