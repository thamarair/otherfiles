-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 27, 2019 at 12:42 PM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 7.3.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sk_blessedangels`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `checkbandwidthisexist` (IN `inschoolid` INT(11), IN `innow` DATETIME)  BEGIN

select count(ID) as isexist from bandwidth_log where school_id=inschoolid and TIMESTAMPDIFF(MINUTE,`updatedtime`,innow)<(select TimeInterval from bandwidth_config where ID=1 and status=1) and status=1;

END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `checkuserisactive` (IN `inuserid` VARCHAR(11), IN `inlogin_session_id` VARCHAR(255), IN `innow` DATETIME)  BEGIN

IF(inuserid!='')THEN

Update users SET last_active_datetime=innow where id=inuserid;

select count(id) as isalive FROM users a WHERE id=inuserid AND session_id=inlogin_session_id AND status=1 AND (SELECT school_id FROM school_admin WHERE school_id=a.sid AND active=1  AND flag=1);

END IF;

END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `daily_session_insert` (IN `instartdate` DATE, IN `inenddate` DATE)  BEGIN
 
DECLARE v_finished INTEGER DEFAULT 0;
DECLARE v_sid INT(11) DEFAULT "";
 
DEClARE sid_cursor CURSOR FOR  select id from schools where active=1 and visible=1 and status=1;
 
DECLARE CONTINUE HANDLER FOR NOT FOUND SET v_finished = 1;
 
 OPEN sid_cursor;
 
 get_id: LOOP
 
 FETCH sid_cursor INTO v_sid;
 
 IF v_finished = 1 THEN 
 LEAVE get_id;
 END IF;
 
Call  daily_session_insert_schoolwise (v_sid,instartdate,inenddate);
 
 END LOOP get_id;
 
 CLOSE sid_cursor;
 
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `daily_session_insert_schoolwise` (IN `inschoolid` INT(11), IN `instartdate` DATE, IN `inenddate` DATE)  BEGIN 
DECLARE outisexist INT(11);

SET outisexist=(select count(id) from schools_period_schedule_days where sid=inschoolid and period_date=instartdate);
IF(outisexist=0)THEN

INSERT INTO `schools_period_schedule_days`( `period_no`, `period_date`, `period_day`, `grade_id`, `grade_name`, `section`, `starttime`, `endtime`, `sid`, `academic_id`, `expected_user`, `status`)  

select period,selected_date,nameofday,(select id from class where REPLACE(classname,'Grade ','') = j1.monday_grade) as gradeid1,concat('Grade ','',monday_grade) as gradename,section,start_time,end_time,inschoolid as sid,20 as academicid,(select count(distinct(u.id)) as regusers from users u  where u.grade_id=(select id from class where REPLACE(classname,'Grade ','') = j1.monday_grade) and u.section=j1.section and u.sid=inschoolid and u.status = 1 and u.visible=1) as totalusers ,1

from (

select period,school_id,monday_grade,monday_section as section,'Monday' as dayname1,start_time,end_time from schools_period_schedule where school_id=inschoolid and academic_id=20 and monday_grade!=''

union select period,school_id,tuesday_grade,tuesday_section as section,'Tuesday' as dayname1,start_time,end_time from schools_period_schedule where school_id=inschoolid and academic_id=20 and tuesday_grade!=''

union select period,school_id,wednesday_grade,wednesday_section as section,'Wednesday' as dayname1,start_time,end_time  from schools_period_schedule where school_id=inschoolid and academic_id=20 and wednesday_grade!=''

union select period,school_id,thursday_grade,thursday_section as section,'Thursday' as dayname1,start_time,end_time from schools_period_schedule where school_id=inschoolid and academic_id=20 and thursday_grade!=''

union select period,school_id,friday_grade,friday_section as section,'Friday' as dayname1,start_time,end_time from schools_period_schedule where school_id=inschoolid and academic_id=20 and friday_grade!=''

union select period,school_id,saturday_grade,saturday_section as section,'Saturday' as dayname1,start_time,end_time from schools_period_schedule where school_id=inschoolid and academic_id=20 and saturday_grade!=''

union select period,school_id,sunday_grade,sunday_section as section,'Sunday' as dayname1,start_time,end_time from schools_period_schedule where school_id=inschoolid and academic_id=20 and sunday_grade!='')j1 cross join 

(select *,dayname(selected_date) as nameofday from 
(select adddate('1970-01-01',t4.i*10000 + t3.i*1000 + t2.i*100 + t1.i*10 + t0.i) selected_date from
 (select 0 i union select 1 union select 2 union select 3 union select 4 union select 5 union select 6 union select 7 union select 8 union select 9) t0,
 (select 0 i union select 1 union select 2 union select 3 union select 4 union select 5 union select 6 union select 7 union select 8 union select 9) t1,
 (select 0 i union select 1 union select 2 union select 3 union select 4 union select 5 union select 6 union select 7 union select 8 union select 9) t2,
 (select 0 i union select 1 union select 2 union select 3 union select 4 union select 5 union select 6 union select 7 union select 8 union select 9) t3,
 (select 0 i union select 1 union select 2 union select 3 union select 4 union select 5 union select 6 union select 7 union select 8 union select 9) t4) v
where selected_date between instartdate and inenddate and selected_date >= (select start_date from schools where id=inschoolid and status=1 and active=1 and visible=1) and selected_date NOT IN (select leave_date from schools_leave_list where school_id = inschoolid and status=1)) j2 on j1.dayname1=j2.nameofday order by selected_date asc;

INSERT INTO `schools_period_schedule_daysbeta`( `period_no`, `period_date`, `period_day`, `grade_id`, `grade_name`, `section`, `starttime`, `endtime`, `sid`, `academic_id`, `total_user`, `expected_user`, `session_division`, `status`)
SELECT  `period_no`, `period_date`, `period_day`, `grade_id`, `grade_name`, `section`, `starttime`, `endtime`, `sid`, `academic_id`, `expected_user`,`expected_user`, 1, `status` FROM `schools_period_schedule_days` WHERE sid=inschoolid and period_date BETWEEN instartdate and inenddate;

END IF;

END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `GameAssignLogic` (IN `inuserid` INT(11), IN `ingp_id` INT(11), IN `ingrade_id` INT(11), IN `insid` INT(11), IN `incurdate` DATE, IN `inuser_current_session` INT(11), IN `insection` VARCHAR(16), IN `incategoryid` INT(11))  BEGIN


DECLARE OUTrandomGames varchar(55);
DECLARE OUTrandomGamesCount INT(11);
DECLARE OUTassignGames INT(11);
DECLARE OUT1skill_id INT(11);
DECLARE OUT1rand_sel INT(11);
DECLARE OUT2rand_sel INT(11);
DECLARE v_done INT DEFAULT FALSE;
DECLARE cursorForProfile CURSOR FOR SELECT id FROM category_skills where category_id=incategoryid;
DECLARE CONTINUE HANDLER FOR NOT FOUND SET v_done = TRUE;
 
    SET FOREIGN_KEY_CHECKS = 1;
  
SET OUTrandomGames=(SELECT group_concat(gid) FROM rand_selection WHERE DATE(created_date)=incurdate AND gp_id = ingp_id AND grade_id = ingrade_id AND school_id = insid and user_id= inuserid ORDER BY gs_id ASC);

SET OUTassignGames=(select count(distinct skill_id) from class_plan_game where plan_id=ingp_id and class_id=ingrade_id and complexity_level=inuser_current_session);

SET OUTrandomGamesCount=(select COALESCE((CHAR_LENGTH(OUTrandomGames) - CHAR_LENGTH(REPLACE(OUTrandomGames, ',','')) + 1),0));

if(OUTrandomGamesCount!=OUTassignGames)THEN
	
OPEN cursorForProfile;

read_loop: LOOP
FETCH cursorForProfile INTO OUT1skill_id;
IF v_done THEN
LEAVE read_loop;
END IF;

SET OUT1rand_sel=(SELECT g.gid FROM class_plan_game AS d 
JOIN games AS g ON d.game_id = g.gid 
JOIN category_skills AS j ON g.gs_id = j.id 
WHERE d.class_id=ingrade_id AND d.plan_id = ingp_id   and j.id = OUT1skill_id 
and g.gid not in (SELECT gid FROM rand_selection WHERE gp_id = ingp_id AND grade_id = ingrade_id AND school_id = insid and user_id=inuserid and gs_id = OUT1skill_id) and complexity_level=inuser_current_session ORDER BY RAND() LIMIT 1);

SET OUT2rand_sel=(select count(OUT1rand_sel));

IF(OUT2rand_sel<=0)THEN

	delete from rand_selection where gs_id=OUT1skill_id and gp_id=ingp_id and grade_id=ingrade_id  and school_id = insid and user_id=inuserid ;
    
    SET OUT1rand_sel=(SELECT g.gid FROM class_plan_game AS d 
	JOIN games AS g ON d.game_id = g.gid 
	JOIN category_skills AS j ON g.gs_id = j.id 
	WHERE d.class_id=ingrade_id AND d.plan_id = ingp_id  and j.id = OUT1skill_id 
	and g.gid not in (SELECT gid FROM rand_selection WHERE gp_id = ingp_id AND grade_id = ingrade_id AND school_id = insid and 	user_id=inuserid and gs_id = OUT1skill_id) and complexity_level=inuser_current_session ORDER BY RAND() LIMIT 1);

	SET OUT2rand_sel=(select count(OUT1rand_sel));

END IF;
IF(OUT2rand_sel>0)THEN

INSERT INTO rand_selection SET gs_id = OUT1skill_id, gid = OUT1rand_sel, gp_id = ingp_id, grade_id = ingrade_id, section =insection,school_id = insid,user_id=inuserid,created_date = incurdate,complexity_level = inuser_current_session;

END IF;

END LOOP;

CLOSE cursorForProfile; 


SET OUTrandomGames=(SELECT group_concat(gid) FROM rand_selection WHERE DATE(created_date)=incurdate AND gp_id = ingp_id AND grade_id = ingrade_id AND school_id = insid and user_id= inuserid ORDER BY gs_id ASC);


END IF;


select j.id,rs.gs_id as skill_id,j.name AS skill_name, g.gid, g.gname, g.img_path,g.game_html, j.icon ,noofpuzzleplayed as tot_game_played,noofquestionplayed as tot_ques_attend,(select MAX(game_score) from game_reports where gu_id =  inuserid   AND gs_id = rs.gs_id AND gp_id = ingp_id AND lastupdate = incurdate) as tot_game_score,(select count(*) as tot_game_played from game_reports where gu_id=inuserid AND gs_id=rs.gs_id AND gp_id=ingp_id AND lastupdate =incurdate) as kg_tot_game_played from rand_selection as rs
join games as g on g.gid=rs.gid
JOIN category_skills AS j ON rs.gs_id = j.id 
WHERE rs.user_id=inuserid and date(rs.created_date)=incurdate and rs.grade_id=ingrade_id AND find_in_set(g.gid,OUTrandomGames) ;


 
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `GameDataInsert` (IN `inuid` INT(11), IN `inSID` INT(11), IN `inGID` INT(11), IN `inResponseTime` INT(11), IN `inBalaceTime` INT(11), IN `inCorrectAnswer` INT(11), IN `inUserAnswer` VARCHAR(16), IN `inAnswerStaus` VARCHAR(16), IN `inQNO` INT(11), IN `inSCORE` INT(11), IN `inTimeOverStatus` INT(11), IN `inpuzzle_cycle` INT(11), IN `incurdate` DATE, IN `incurdatetime` DATETIME, IN `ingtime` INT(11), IN `ingp_id` INT(11))  BEGIN

DECLARE outPlayedCount INT(11);
DECLARE outPlayedQusCount INT(11);
DECLARE Ototal_question INT(11);
DECLARE Oattempt_question INT(11);
DECLARE Oanswer INT(11);
DECLARE Ogame_score INT(11);
DECLARE Ogtime INT(11);
DECLARE Ortime INT(11);
DECLARE Ocrtime INT(11);
DECLARE Owrtime INT(11);
DECLARE OUTPUT Varchar(55);
DECLARE OTotPlayedGameCount INT(11);
DECLARE OTotPlayedQuesCount INT(11);
SET OUTPUT="SINGLEINSERT";


INSERT INTO gamescore(gu_id, gs_id, g_id, que_id, answer, useranswer, game_score, answer_status, timeoverstatus, responsetime, balancetime, lastupdate, creation_date, modified_date, puzzle_cycle)
VALUES(inuid,inSID,inGID,inQNO,inCorrectAnswer,inUserAnswer,inSCORE,inAnswerStaus,inTimeOverStatus,inResponseTime,inBalaceTime,incurdate,incurdatetime,incurdatetime,inpuzzle_cycle);

SET outPlayedQusCount=(SELECT count(gs_id) Completedquestion FROM gamescore as gs where g_id=inGID and gu_id=inuid and puzzle_cycle=inpuzzle_cycle and lastupdate=incurdate);

IF(inBalaceTime=0 and inAnswerStaus!='U' and outPlayedQusCount!=10)THEN

	INSERT INTO gamescore(gu_id, gs_id, g_id, que_id, answer, useranswer, game_score, answer_status, timeoverstatus, responsetime, balancetime, lastupdate, creation_date, modified_date, puzzle_cycle)
	VALUES(inuid,inSID,inGID,inQNO,inCorrectAnswer,'NotAnswered',0,'U',inTimeOverStatus,inResponseTime,inBalaceTime,incurdate,incurdatetime,incurdatetime,inpuzzle_cycle);
END IF;

SET OTotPlayedQuesCount=(select count(que_id) as noofquestionplayed from gamescore where g_id=inGID and gu_id=inuid and puzzle_cycle=inpuzzle_cycle and lastupdate=incurdate);

UPDATE rand_selection set noofquestionplayed=OTotPlayedQuesCount where user_id=inuid and gid=inGID and date(created_date)=incurdate;

SET outPlayedCount=(SELECT CASE when count(gs_id)>=10 THEN 1 WHEN FIND_IN_SET('U',group_concat(answer_status))>=1 THEN 1 ELSE 0 END CompletedSkill FROM gamescore as gs where g_id=inGID and gu_id=inuid and puzzle_cycle=inpuzzle_cycle and lastupdate=incurdate);

IF(outPlayedCount=1) 
THEN
	SET Ototal_question=10;
	
	SET Oattempt_question=(select count(gu_id)  from gamescore where g_id=inGID and gu_id=inuid and answer_status!='U' and puzzle_cycle=inpuzzle_cycle  and lastupdate=incurdate);
	
	SET Oanswer=(select count(answer_status) from gamescore where g_id=inGID and gu_id=inuid and answer_status='correct' and puzzle_cycle=inpuzzle_cycle  and lastupdate=incurdate);
	
	SET Ogame_score=(select coalesce(sum(game_score),0) from gamescore where g_id=inGID and gu_id=inuid and puzzle_cycle=inpuzzle_cycle and lastupdate=incurdate);
	
	SET Ortime=(select coalesce(sum(CAST(responsetime AS UNSIGNED)),0) from gamescore where g_id=inGID and gu_id=inuid and answer_status!='U' and puzzle_cycle=inpuzzle_cycle  and lastupdate=incurdate);
	
	SET Ocrtime=(select coalesce(sum(CAST(responsetime AS UNSIGNED)),0) from gamescore where g_id=inGID and gu_id=inuid and answer_status='correct' and puzzle_cycle=inpuzzle_cycle  and lastupdate=incurdate);
	
	SET Owrtime=(select coalesce(sum(CAST(responsetime AS UNSIGNED)),0) from gamescore where g_id=inGID and gu_id=inuid and answer_status='wrong' and puzzle_cycle=inpuzzle_cycle  and lastupdate=incurdate);
	
	insert into gamedata (gu_id,gc_id,gs_id,gp_id,g_id,total_question,attempt_question,answer,game_score,gtime,rtime,crtime,wrtime,lastupdate,puzzle_cycle)
	values(inuid,1,inSID,ingp_id,inGID,Ototal_question,Oattempt_question,Oanswer,Ogame_score,ingtime,Ortime,Ocrtime,Owrtime,incurdate,inpuzzle_cycle);
    
     SET OTotPlayedGameCount=(select count(gs_id) as noofgameplayed from gamedata where g_id=inGID and gu_id=inuid  and lastupdate=incurdate);

	UPDATE rand_selection set noofpuzzleplayed=OTotPlayedGameCount where user_id=inuid and gid=inGID and date(created_date)=incurdate;
   
   SET OUTPUT="GAMEINSERT";
   CALL UpdateTodaySession(inuid,incurdate);
END IF;

select OUTPUT;



END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `GameDataInsert_asap` (IN `inuid` INT(11), IN `inSID` INT(11), IN `inGID` INT(11), IN `inResponseTime` INT(11), IN `inBalaceTime` INT(11), IN `inCorrectAnswer` INT(11), IN `inUserAnswer` VARCHAR(16), IN `inAnswerStaus` VARCHAR(16), IN `inQNO` INT(11), IN `inSCORE` INT(11), IN `inTimeOverStatus` INT(11), IN `inpuzzle_cycle` INT(11), IN `incurdate` DATE, IN `incurdatetime` DATETIME, IN `ingtime` INT(11), IN `ingp_id` INT(11), IN `instageid` INT(11), IN `inportal_type` ENUM('ASAP1','ASAP2'))  BEGIN

DECLARE outPlayedCount INT(11);
DECLARE outPlayedQusCount INT(11);
DECLARE Ototal_question INT(11);
DECLARE Oattempt_question INT(11);
DECLARE Oanswer INT(11);
DECLARE Ogame_score INT(11);
DECLARE Ogtime INT(11);
DECLARE Ortime INT(11);
DECLARE Ocrtime INT(11);
DECLARE Owrtime INT(11);



INSERT INTO asap_gamescore(gu_id, gs_id, g_id, que_id, answer, useranswer, game_score, answer_status, timeoverstatus, responsetime, balancetime, lastupdate, creation_date, modified_date, puzzle_cycle,stage_id)
VALUES(inuid,inSID,inGID,inQNO,inCorrectAnswer,inUserAnswer,inSCORE,inAnswerStaus,inTimeOverStatus,inResponseTime,inBalaceTime,incurdate,incurdatetime,incurdatetime,inpuzzle_cycle,instageid);

SET outPlayedQusCount=(SELECT count(gs_id) Completedquestion FROM asap_gamescore as gs where g_id=inGID and gu_id=inuid);

IF(inBalaceTime=0 and inAnswerStaus!='U' and outPlayedQusCount!=10)THEN

	INSERT INTO asap_gamescore(gu_id, gs_id, g_id, que_id, answer, useranswer, game_score, answer_status, timeoverstatus, responsetime, balancetime, lastupdate, creation_date, modified_date, puzzle_cycle,stage_id)
	VALUES(inuid,inSID,inGID,inQNO,inCorrectAnswer,'NotAnswered',0,'U',inTimeOverStatus,inResponseTime,inBalaceTime,incurdate,incurdatetime,incurdatetime,inpuzzle_cycle,instageid);
END IF;

SET outPlayedCount=(SELECT CASE when count(gs_id)>=10 THEN 1 WHEN FIND_IN_SET('U',group_concat(answer_status))>=1 THEN 1 ELSE 0 END CompletedSkill FROM asap_gamescore as gs where g_id=inGID and gu_id=inuid);

IF(outPlayedCount=1) 
THEN
	SET Ototal_question=10;
	
	SET Oattempt_question=(select count(gu_id)  from asap_gamescore where g_id=inGID and gu_id=inuid and answer_status!='U');
	
	SET Oanswer=(select count(answer_status) from asap_gamescore where g_id=inGID and gu_id=inuid and answer_status='correct');
	
	SET Ogame_score=(select coalesce(sum(game_score),0) from asap_gamescore where g_id=inGID and gu_id=inuid);
	
	SET Ortime=(select coalesce(sum(CAST(responsetime AS UNSIGNED)),0) from asap_gamescore where g_id=inGID and gu_id=inuid and answer_status!='U');
	
	SET Ocrtime=(select coalesce(sum(CAST(responsetime AS UNSIGNED)),0) from asap_gamescore where g_id=inGID and gu_id=inuid and answer_status='correct');
	
	SET Owrtime=(select coalesce(sum(CAST(responsetime AS UNSIGNED)),0) from asap_gamescore where g_id=inGID and gu_id=inuid and answer_status='wrong');
	
	insert into asap_game_reports (gu_id,gs_id,stage_id,g_id,total_question,attempt_question,answer,game_score,gtime,rtime,crtime,wrtime,lastupdate,puzzle_cycle,portal_type)
	values(inuid,inSID,instageid,inGID,Ototal_question,Oattempt_question,Oanswer,Ogame_score,ingtime,Ortime,Ocrtime,Owrtime,incurdate,inpuzzle_cycle,inportal_type);
END IF;

select LAST_INSERT_ID();



END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `GetBadgeData` (IN `inSID` INT(11), IN `inGID` INT(11), IN `instartdate` DATE, IN `inenddate` DATE, IN `innow` DATETIME, IN `incurdate` DATE)  BEGIN

DECLARE OUTSPARKY TEXT;
DECLARE OUTSUPERBRAIN TEXT;
DECLARE OUTSUPERGOER TEXT;
DECLARE OUTSUPERANGEL TEXT;
DECLARE OUTISEXIST INT(11);

SET OUTISEXIST=(SELECT COUNT(ID) from userbadge_data where S_ID=inSID and G_ID=inGID and MonthNumber=date_format(incurdate-INTERVAL 1 MONTH,'%m'));

IF(OUTISEXIST=0)THEN

SET OUTSPARKY=(select group_concat(U_ID) as U_ID from (select U_ID,points,monthName,monthNumber,S_ID,G_ID from (select a2.U_ID AS U_ID,sum(a2.Points) AS points,date_format(a2.Datetime,'%b') AS monthName,date_format(a2.Datetime,'%m') AS monthNumber,a2.S_ID,a2.G_ID from user_sparkies_history a2 where (date_format(a2.Datetime,'%Y-%m-%d') between instartdate and inenddate) group by date_format(a2.Datetime,'%m'),a2.U_ID) a1 where a1.G_ID=inGID and a1.S_ID=inSID and a1.points=(select points from vv2 where vv2.monthNumber =a1.monthNumber and vv2.monthNumber=date_format(incurdate-INTERVAL 1 MONTH,'%m')  and vv2.G_ID=inGID and vv2.S_ID=inSID ) ) as a5 group by monthNumber);

SET OUTSUPERBRAIN=(select GROUP_CONCAT(gu_id) as gu_id from(select bspi,monthName,monthNumber,sid,gu_id,grade_id,(select username from users where id = gu_id) as username,(select classname from class where id = grade_id)as classname,(select school_name from schools where id = sid)as school_name from(select avg(bspi2.score) AS bspi,bspi2.gu_id AS gu_id,date_format(bspi2.lastupdate,'%m') AS monthNumber,date_format(bspi2.lastupdate,'%b') AS monthName,u.sid AS sid,u.grade_id AS grade_id from (vi_1dayuserscore bspi2 join users u on((u.id = bspi2.gu_id))) where (date_format(bspi2.lastupdate,'%Y-%m-%d') between instartdate and inenddate) group by bspi2.gu_id,month(bspi2.lastupdate)) as a1 where a1.grade_id=inGID and a1.sid=inSID and ROUND(a1.bspi,2)=(select bspi from vi_maxbspibymsg as vv3 where vv3.monthNumber =a1.monthNumber and vv3.monthNumber=date_format(incurdate-INTERVAL 1 MONTH,'%m') and vv3.grade_id=inGID and vv3.sid=inSID)) as a5 group by monthNumber);

SET OUTSUPERGOER=(select group_concat(gu_id) as gu_id from (select countofplayed,gu_id,monthName,monthNumber,grad_ID,gs_ID,(select username from users where id = gu_id) as username from (select count(gu_id) AS countofplayed,gu_id AS gu_id,date_format(lastupdate,'%b') AS monthName,date_format(lastupdate,'%m') AS monthNumber,(select sid from users where (id = gu_id)) AS gs_ID,(select grade_id from users where (id = gu_id)) AS grad_ID from game_reports where (convert(date_format(lastupdate,'%Y-%m-%d') using latin1) between instartdate and inenddate) group by date_format(lastupdate,'%m'),gu_id) a1 where a1.grad_ID=inGID and a1.gs_ID=inSID and a1.countofplayed in (select countofval from vi_gameplayed v where v.monthNumber=a1.monthNumber and v.monthNumber=date_format(incurdate-INTERVAL 1 MONTH,'%m')  and v.school_id=inSID and v.grad_id=inGID) ) as a5 group by monthNumber);

SET OUTSUPERANGEL=(select group_concat(gu_id) as gu_id from (select ans,gu_id,monthName,monthNumber,grad_ID,gs_ID,(select username from users where id = gu_id) as username from (select sum(answer) as ans,game_reports.gu_id AS gu_id,date_format(game_reports.lastupdate,'%b') AS monthName,date_format(game_reports.lastupdate,'%m') AS monthNumber,(select users.sid from users where (users.id = game_reports.gu_id)) AS gs_ID,(select users.grade_id from users where (users.id = game_reports.gu_id)) AS grad_ID from game_reports where (convert(date_format(game_reports.lastupdate,'%Y-%m-%d') using latin1) between instartdate and inenddate) group by date_format(game_reports.lastupdate,'%m'),game_reports.gu_id) a1 where a1.grad_ID=inGID and a1.gs_ID=inSID and a1.ans in (select ans from superangel v where v.monthNumber=a1.monthNumber and v.monthNumber=date_format(incurdate-INTERVAL 1 MONTH,'%m') and v.gs_ID=inSID and v.grad_ID=inGID)) as a5 group by monthNumber);


INSERT INTO userbadge_data(S_ID,G_ID,MonthNumber,Sparkies,SuperBrian,SuperGoer,SuperAngel,isexist,Datetime)SELECT inSID,inGID,date_format(incurdate-INTERVAL 1 MONTH,'%m'),OUTSPARKY,OUTSUPERBRAIN,OUTSUPERGOER,OUTSUPERANGEL,1,innow;

END IF;


END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getMyCurrentSparkies` (IN `inSID` INT(11), IN `inGID` INT(11), IN `inUID` INT(11), IN `instartdate` DATE, IN `inenddate` DATE)  BEGIN

Select sum(Points) as mysparkies from user_sparkies_history where S_ID=inSID and G_ID=inGID and U_ID=inUID AND DATE(Datetime) between instartdate and inenddate;

END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getMyCurrentSparkies~old` (IN `inSID` INT(11), IN `inGID` INT(11), IN `inUID` INT(11))  BEGIN

Select sum(Points) as mysparkies from user_sparkies_history where S_ID=inSID and G_ID=inGID and U_ID=inUID;

END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getNewsFeed` (IN `inSID` INT(11), IN `inGID` INT(11), IN `inUID` INT(11), IN `intype` VARCHAR(55), IN `instartdate` DATE, IN `inenddate` DATE)  BEGIN

DECLARE OUTTYPE INT(11);

IF(intype='ALL')THEN
	SET OUTTYPE=(select Type from newsfeed_config where status=1);
	IF(OUTTYPE=1)THEN
		SELECT U_ID,(select avatarimage from users where id=U_ID) as avatarimage,REPLACE(scenario,'#NAME#',(select username from users where id=U_ID)) as scenario from user_newsfeed_history where S_ID=inSID and U_ID in (select id from users where status=1 and visible=1)  AND DATE(Datetime) between instartdate and inenddate  ORDER BY ID DESC LIMIT 100;
	ELSE
		SELECT U_ID,(select avatarimage from users where id=U_ID) as avatarimage,REPLACE(scenario,'#NAME#',(select username from users where id=U_ID)) as scenario from user_newsfeed_history where G_ID=inGID and U_ID in (select id from users where status=1 and visible=1) AND DATE(Datetime) between instartdate and inenddate  ORDER BY ID DESC LIMIT 100;
	END IF;
ELSE
		SELECT U_ID,(select avatarimage from users where id=U_ID) as avatarimage,REPLACE(scenario,'#NAME#','You') as scenario from user_newsfeed_history where U_ID=inUID and U_ID in (select id from users where status=1 and visible=1) AND DATE(Datetime) between instartdate and inenddate ORDER BY ID DESC LIMIT 100;	
END IF;
	
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getNewsFeedCount` (IN `inSID` INT(11), IN `inGID` INT(11), IN `inUID` INT(11), IN `intype` VARCHAR(55), IN `instartdate` DATE, IN `inenddate` DATE, IN `incurdate` DATE)  BEGIN
DECLARE OUTTYPE INT(11);
DECLARE OUTMINECOUNT INT(11);
DECLARE OUTALLCOUNT INT(11);


	SET OUTTYPE=(select Type from newsfeed_config where status=1);
	IF(OUTTYPE=1)THEN
		SET OUTALLCOUNT=(SELECT COUNT(U_ID) As ALLCount from user_newsfeed_history where S_ID=inSID and U_ID in (select id from users where status=1 and visible=1) AND DATE(Datetime) between instartdate and inenddate AND DATE(Datetime)=incurdate ORDER BY ID DESC);
	ELSE
		SET OUTALLCOUNT=(SELECT COUNT(U_ID) As ALLCount from user_newsfeed_history where S_ID=inSID and G_ID=inGID and U_ID in (select id from users where status=1 and visible=1) AND DATE(Datetime) between instartdate and inenddate AND DATE(Datetime)=incurdate ORDER BY ID DESC);
	END IF;

		SET OUTMINECOUNT=(SELECT COUNT(U_ID) As MineCount from user_newsfeed_history where U_ID=inUID and U_ID in (select id from users where status=1 and visible=1) AND DATE(Datetime) between instartdate and inenddate AND DATE(Datetime)=incurdate ORDER BY ID DESC);	

	
select 	OUTALLCOUNT,OUTMINECOUNT;

END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getNewsFeedCount~old` (IN `inSID` INT(11), IN `inGID` INT(11), IN `inUID` INT(11), IN `intype` VARCHAR(55))  BEGIN
DECLARE OUTTYPE INT(11);
DECLARE OUTMINECOUNT INT(11);
DECLARE OUTALLCOUNT INT(11);


	SET OUTTYPE=(select Type from newsfeed_config where status=1);
	IF(OUTTYPE=1)THEN
		SET OUTALLCOUNT=(SELECT COUNT(U_ID) As ALLCount from user_newsfeed_history where S_ID=inSID  ORDER BY ID DESC);
	ELSE
		SET OUTALLCOUNT=(SELECT COUNT(U_ID) As ALLCount from user_newsfeed_history where G_ID=inGID ORDER BY ID DESC);
	END IF;

		SET OUTMINECOUNT=(SELECT COUNT(U_ID) As MineCount from user_newsfeed_history where U_ID=inUID ORDER BY ID DESC);	

	
select 	OUTALLCOUNT,OUTMINECOUNT;

END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getNewsFeed~old` (IN `inSID` INT(11), IN `inGID` INT(11), IN `inUID` INT(11), IN `intype` VARCHAR(55))  BEGIN

DECLARE OUTTYPE INT(11);

IF(intype='ALL')THEN
	SET OUTTYPE=(select Type from newsfeed_config where status=1);
	IF(OUTTYPE=1)THEN
		SELECT U_ID,(select avatarimage from users where id=U_ID) as avatarimage,REPLACE(scenario,'#NAME#',(select username from users where id=U_ID)) as scenario from user_newsfeed_history where S_ID=inSID  ORDER BY ID DESC;
	ELSE
		SELECT U_ID,(select avatarimage from users where id=U_ID) as avatarimage,REPLACE(scenario,'#NAME#',(select username from users where id=U_ID)) as scenario from user_newsfeed_history where G_ID=inGID ORDER BY ID DESC;
	END IF;
ELSE
		SELECT U_ID,(select avatarimage from users where id=U_ID) as avatarimage,REPLACE(scenario,'#NAME#','You') as scenario from user_newsfeed_history where U_ID=inUID ORDER BY ID DESC;	
END IF;
	
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `insertbandwidth` (IN `inschoolid` INT(11), IN `inuser_id` INT(11), IN `inBps` VARCHAR(110), IN `inKbps` VARCHAR(110), IN `inMbps` VARCHAR(110), IN `innow` DATETIME)  BEGIN
DECLARE OUTisexist INT(11);
SET OUTisexist=(select count(ID) as isexist from bandwidth_log where school_id=inschoolid and TIMESTAMPDIFF(MINUTE,`updatedtime`,innow)<(select TimeInterval from bandwidth_config where ID=1 and status=1) and status=1);

IF(OUTisexist=0)THEN
	Insert into bandwidth_log(school_id,user_id,bandwidth_bps,bandwidth_kbps,bandwidth_mbps,status,updatedtime)values(inschoolid,inuser_id,inBps,inKbps,inMbps,1,innow);
END IF;

END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `insertnewsfeeddata` (IN `inSID` INT(11), IN `inGID` INT(11), IN `inUID` INT(11), IN `inScenarioCode` VARCHAR(55), IN `inTotal_Ques` INT(11), IN `inAttempt_Ques` INT(11), IN `inAnswer` INT(11), IN `inGame_Score` INT(11), IN `inPlanid` INT(11), IN `inGameid` INT(11), IN `innow` DATETIME, IN `incurdate` DATE)  BEGIN

DECLARE OUTGAMENAME VARCHAR(55);
DECLARE OUTNTHTIME INT(11);
DECLARE NOOFTIMESPLAY INT(11);
DECLARE OUTSKILLNAME VARCHAR(55);
DECLARE OUTCURPOSITION INT(11);
DECLARE OUTSTATUS INT(11);
DECLARE OUTTHEME VARCHAR(55);
DECLARE OUTLASTMONDATA INT(11);

SET OUTGAMENAME=(SELECT gname from games where gid=inGameid);
SET OUTNTHTIME=(SELECT COUNT(*) from game_reports where g_id=inGameid AND gp_id=inPlanid and gu_id=inUID and lastupdate=incurdate);
SET NOOFTIMESPLAY=(SELECT ntimes from game_limit where g_id=inGameid AND gp_id=inPlanid);
SET OUTSKILLNAME=(SELECT name from category_skills where id=(select gs_id from games where gid=inGameid));

IF(inScenarioCode='GAME_END')THEN
	INSERT INTO user_newsfeed_history(S_ID,G_ID,U_ID,Scenario,Datetime)SELECT inSID,inGID,inUID,REPLACE(REPLACE(Scenario,'#GN#',OUTGAMENAME),'#NTH#',OUTNTHTIME),innow from newsfeedmaster where Code='1GAME_COMPLETE' and Status=1; 	
	IF(NOOFTIMESPLAY=OUTNTHTIME)THEN
	INSERT INTO user_newsfeed_history(S_ID,G_ID,U_ID,Scenario,Datetime)SELECT inSID,inGID,inUID,REPLACE(Scenario,'#SKILLNAME#',OUTSKILLNAME),innow from newsfeedmaster where Code='1SKILL_COMPLETE' and Status=1;
	END IF;
END IF;

    SET OUTCURPOSITION=(Select FLOOR(sum(Points)/100) as curpos from user_sparkies_history where S_ID=inSID and G_ID=inGID and U_ID=inUID);
	IF(OUTCURPOSITION!=0)THEN
	SET OUTSTATUS=(select count(ID) from newsfeed_data_status where U_ID=inUID and Value=OUTCURPOSITION and Value!=0);
	ELSE
	SET OUTSTATUS=-1;
	END IF;
	IF(OUTSTATUS=0)THEN
	INSERT INTO user_newsfeed_history(S_ID,G_ID,U_ID,Scenario,Datetime)SELECT inSID,inGID,inUID,REPLACE(Scenario,'#POINTVAL#',(OUTCURPOSITION*100)),innow from newsfeedmaster where Code='SPARKEY_LIMIT' and Status=1;
	INSERT INTO newsfeed_data_status(S_ID,G_ID,U_ID,Value)SELECT inSID,inGID,inUID,OUTCURPOSITION;
           IF(OUTCURPOSITION=10 || OUTCURPOSITION=20 || OUTCURPOSITION=30 || OUTCURPOSITION=40)THEN
	SET OUTTHEME=(SELECT theme_name from thememaster where sparky_range=(OUTCURPOSITION*100) and status=1);
		INSERT INTO user_newsfeed_history(S_ID,G_ID,U_ID,Scenario,Datetime)SELECT inSID,inGID,inUID,REPLACE(Scenario,'#THEME#',OUTTHEME),innow from newsfeedmaster where Code='THEME_ACTIVATION' and Status=1;	
	END IF;
    
	END IF;
    
    SET OUTLASTMONDATA=(SELECT COUNT(ID) from userbadge_data where S_ID=inSID and G_ID=inGID and MonthNumber=date_format(incurdate-INTERVAL 1 MONTH,'%m') and isexist=1);
IF(OUTLASTMONDATA>=1)THEN
		
    INSERT INTO user_newsfeed_history(S_ID,G_ID,U_ID,Scenario,Datetime)SELECT inSID,inGID,id,REPLACE(REPLACE((select Scenario from newsfeedmaster where Code='BADGES' and Status=1),'#MONTH#',CONCAT(date_format(incurdate-INTERVAL 1 MONTH,'%b'),'-',date_format(incurdate,'%Y'))),'#B#','Super Brain'),innow FROM users where FIND_IN_SET(id,(select SuperBrian from userbadge_data where S_ID=inSID and G_ID=inGID and MonthNumber=date_format(incurdate-INTERVAL 1 MONTH,'%m') and isexist=1));
	
	INSERT INTO user_newsfeed_history(S_ID,G_ID,U_ID,Scenario,Datetime)SELECT inSID,inGID,id,REPLACE(REPLACE((select Scenario from newsfeedmaster where Code='BADGES' and Status=1),'#MONTH#',CONCAT(date_format(incurdate-INTERVAL 1 MONTH,'%b'),'-',date_format(incurdate,'%Y'))),'#B#','Super Goer'),innow FROM users where FIND_IN_SET(id,(select SuperGoer from userbadge_data where S_ID=inSID and G_ID=inGID and MonthNumber=date_format(incurdate-INTERVAL 1 MONTH,'%m') and isexist=1));
	
	INSERT INTO user_newsfeed_history(S_ID,G_ID,U_ID,Scenario,Datetime)SELECT inSID,inGID,id,REPLACE(REPLACE((select Scenario from newsfeedmaster where Code='BADGES' and Status=1),'#MONTH#',CONCAT(date_format(incurdate-INTERVAL 1 MONTH,'%b'),'-',date_format(incurdate,'%Y'))),'#B#','Super Angel'),innow FROM users where FIND_IN_SET(id,(select SuperAngel from userbadge_data where S_ID=inSID and G_ID=inGID and MonthNumber=date_format(incurdate-INTERVAL 1 MONTH,'%m') and isexist=1));
UPDATE userbadge_data SET isexist=0 where S_ID=inSID and G_ID=inGID and MonthNumber=date_format(incurdate-INTERVAL 1 MONTH,'%m');	
	
END IF;



END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `insertsparkies` (IN `inSID` INT(11), IN `inGID` INT(11), IN `inUID` INT(11), IN `inScenarioCode` VARCHAR(55), IN `inTotal_Ques` INT(11), IN `inAttempt_Ques` INT(11), IN `inAnswer` INT(11), IN `inGame_Score` INT(11), IN `inDateTime` VARCHAR(55))  BEGIN



IF(inScenarioCode='GAME_END')THEN

	INSERT INTO user_sparkies_history(S_ID,G_ID,U_ID,Scenario_ID,Type,Points,Datetime)SELECT inSID,inGID,inUID,ID,Type,Points,inDateTime from sparkiesmaster where Code='ONE_Q' and Status=1;

END IF;


END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `insertsparkiesnew` (IN `inSID` INT(11), IN `inGID` INT(11), IN `inUID` INT(11), IN `inScenarioCode` VARCHAR(55), IN `inTotal_Ques` INT(11), IN `inAttempt_Ques` INT(11), IN `inAnswer` INT(11), IN `inGame_Score` INT(11), IN `inPlanid` INT(11), IN `inGameid` INT(11), IN `innow` DATETIME, IN `incurdate` DATE, IN `incurtime` DATETIME)  BEGIN

DECLARE OUTPOINTS INT(11);
DECLARE NOOFTIMESPLAY INT(11);
DECLARE NOOFTIMESPLAYED INT(11);
DECLARE OUTWEEKEND INT(11);
DECLARE OUTFIRSTLOGIN INT(11);
DECLARE OUTSECTIONNAME Varchar(16);
DECLARE OUTGRADENAME Varchar(16);
DECLARE OUTAVAIBILITY INT(11);	
DECLARE OUTTIME INT(11);
DECLARE OUTAID INT(11);

SET OUTPOINTS=0;

IF(inScenarioCode='GAME_END')THEN
	IF(inAttempt_Ques>=1)THEN 
		INSERT INTO user_sparkies_history(S_ID,G_ID,U_ID,Scenario_ID,Type,Points,Datetime)SELECT inSID,inGID,inUID,ID,Type,(inAttempt_Ques * Points),innow from sparkiesmaster where Code='ONE_Q' and Status=1;
		SET OUTPOINTS=OUTPOINTS + (inAttempt_Ques * (SELECT Points from sparkiesmaster where Code='ONE_Q' and Status=1));
	END IF;	
	IF(inAttempt_Ques='10')THEN
		INSERT INTO user_sparkies_history(S_ID,G_ID,U_ID,Scenario_ID,Type,Points,Datetime)SELECT inSID,inGID,inUID,ID,Type,Points,innow from sparkiesmaster where Code='ALL_Q' and Status=1;
		SET OUTPOINTS=OUTPOINTS + (SELECT Points from sparkiesmaster where Code='ALL_Q' and Status=1);
	END IF;
	IF(inAnswer>=1)THEN
		INSERT INTO user_sparkies_history(S_ID,G_ID,U_ID,Scenario_ID,Type,Points,Datetime)SELECT inSID,inGID,inUID,ID,Type,(inAnswer * Points),innow from sparkiesmaster where Code='1QC' and Status=1;
		SET OUTPOINTS=OUTPOINTS + (inAnswer * (SELECT Points from sparkiesmaster where Code='1QC' and Status=1));
	END IF;
	IF(inAnswer='10')THEN
		INSERT INTO user_sparkies_history(S_ID,G_ID,U_ID,Scenario_ID,Type,Points,Datetime)SELECT inSID,inGID,inUID,ID,Type,Points,innow from sparkiesmaster where Code='10QC' and Status=1;
		SET OUTPOINTS=OUTPOINTS + (SELECT Points from sparkiesmaster where Code='10QC' and Status=1);
	END IF;	
	IF(inGame_Score>=60)THEN
		INSERT INTO user_sparkies_history(S_ID,G_ID,U_ID,Scenario_ID,Type,Points,Datetime)SELECT inSID,inGID,inUID,ID,Type,Points,innow from sparkiesmaster where Code='ABOVE_60' and Status=1;
		SET OUTPOINTS=OUTPOINTS + (SELECT Points from sparkiesmaster where Code='ABOVE_60' and Status=1);
	END IF;
    
    SET NOOFTIMESPLAY=(SELECT ntimes from game_limit where g_id=inGameid AND gp_id=inPlanid );
	SET NOOFTIMESPLAYED=(SELECT COUNT(*) from game_reports where g_id=inGameid AND gp_id=inPlanid and gu_id=inUID and lastupdate=incurdate);
	IF(NOOFTIMESPLAY=NOOFTIMESPLAYED)THEN
		INSERT INTO user_sparkies_history(S_ID,G_ID,U_ID,Scenario_ID,Type,Points,Datetime)SELECT inSID,inGID,inUID,ID,Type,Points,innow from sparkiesmaster where Code='ALL5TGP' and Status=1;
		SET OUTPOINTS=OUTPOINTS + (SELECT Points from sparkiesmaster where Code='ALL5TGP' and Status=1);
	END IF;
		
    INSERT INTO user_sparkies_history(S_ID,G_ID,U_ID,Scenario_ID,Type,Points,Datetime)SELECT inSID,inGID,inUID,ID,Type,Points,innow from sparkiesmaster where Code='NOTPOAG' and Status=1;
    
	SET OUTPOINTS=OUTPOINTS + (SELECT Points from sparkiesmaster where Code='NOTPOAG' and Status=1);
    
END IF;
IF(inScenarioCode='LOGIN')THEN
	SET OUTFIRSTLOGIN=(select count(ID) as firstlogin  from user_sparkies_history where U_ID=inUID and date(Datetime)=incurdate);
	SET OUTWEEKEND=(SELECT DAYOFWEEK(incurdate) = 7 or DAYOFWEEK(incurdate) = 1);
	
			SET OUTSECTIONNAME=(select section from users where id=inUID);
			SET OUTGRADENAME=(select grade_id from users where id=inUID);
			SET OUTTIME=(SELECT incurtime >= '18:00:00' OR incurtime <= "06:00:00");
			SET OUTAID=(select academic_id from schools where id=inSID);
			
			SET OUTAVAIBILITY=(select (CASE DAYNAME(innow)
            WHEN 'Monday'    THEN (SELECT '1' from schools_period_schedule where `monday_grade`=(select replace(classname,'Grade ','') from class where id=OUTGRADENAME) and `monday_section`=OUTSECTIONNAME and `school_id`=inSID and academic_id=OUTAID)
            WHEN 'Tuesday'   THEN (SELECT '1' from schools_period_schedule where `tuesday_grade`=(select replace(classname,'Grade ','') from class where id=OUTGRADENAME) and `tuesday_section`=OUTSECTIONNAME and `school_id`=inSID and academic_id=OUTAID)
            WHEN 'Wednesday' THEN (SELECT '1' from schools_period_schedule where `wednesday_grade`=(select replace(classname,'Grade ','') from class where id=OUTGRADENAME) and `wednesday_section`=OUTSECTIONNAME and `school_id`=inSID and academic_id=OUTAID)
            WHEN 'Thursday'  THEN (SELECT '1' from schools_period_schedule where `thursday_grade`=(select replace(classname,'Grade ','') from class where id=OUTGRADENAME) and `thursday_section`=OUTSECTIONNAME and `school_id`=inSID and academic_id=OUTAID)
            WHEN 'Friday'    THEN (SELECT '1' from schools_period_schedule where `friday_grade`=(select replace(classname,'Grade ','') from class where id=OUTGRADENAME) and `friday_section`=OUTSECTIONNAME and `school_id`=inSID and academic_id=OUTAID)
			WHEN 'Saturday'    THEN (SELECT '1' from schools_period_schedule where `saturday_grade`=(select replace(classname,'Grade ','') from class where id=OUTGRADENAME) and `saturday_section`=OUTSECTIONNAME and `school_id`=inSID and academic_id=OUTAID)
			WHEN 'Friday'    THEN (SELECT '1' from schools_period_schedule where `sunday_grade`=(select replace(classname,'Grade ','') from class where id=OUTGRADENAME) and `sunday_section`=OUTSECTIONNAME and `school_id`=inSID and academic_id=OUTAID)
            END) as isexist);
			
		IF(OUTFIRSTLOGIN=0)THEN 
			IF(OUTWEEKEND=1)THEN
				INSERT INTO user_sparkies_history(S_ID,G_ID,U_ID,Scenario_ID,Type,Points,Datetime)SELECT inSID,inGID,inUID,ID,Type,Points,innow from sparkiesmaster where Code='WEEKEND' and Status=1;
				SET OUTPOINTS=OUTPOINTS + (SELECT Points from sparkiesmaster where Code='WEEKEND' and Status=1);
			END IF;
			
			IF(OUTAVAIBILITY=1)THEN
				INSERT INTO user_sparkies_history(S_ID,G_ID,U_ID,Scenario_ID,Type,Points,Datetime)SELECT inSID,inGID,inUID,ID,Type,Points,innow from sparkiesmaster where Code='FLOSSD' and Status=1;
				SET OUTPOINTS=OUTPOINTS + (SELECT Points from sparkiesmaster where Code='FLOSSD' and Status=1);
			ELSE
				INSERT INTO user_sparkies_history(S_ID,G_ID,U_ID,Scenario_ID,Type,Points,Datetime)SELECT inSID,inGID,inUID,ID,Type,Points,innow from sparkiesmaster where Code='FLFH' and Status=1;
				SET OUTPOINTS=OUTPOINTS + (SELECT Points from sparkiesmaster where Code='FLFH' and Status=1);
			
			END IF;
			
			IF(OUTTIME=1)THEN
				INSERT INTO user_sparkies_history(S_ID,G_ID,U_ID,Scenario_ID,Type,Points,Datetime)SELECT inSID,inGID,inUID,ID,Type,Points,innow from sparkiesmaster where Code='6T6' and Status=1;
				SET OUTPOINTS=OUTPOINTS + (SELECT Points from sparkiesmaster where Code='6T6' and Status=1);
			END IF;
            
			IF(LAST_DAY(incurdate)=date(innow))THEN
				IF(day(last_day(incurdate))=(SELECT count(distinct(date(Datetime))) as monplayed from user_sparkies_history where month(Datetime)=MONTH(innow) and U_ID=inUID))THEN
					INSERT INTO user_sparkies_history(S_ID,G_ID,U_ID,Scenario_ID,Type,Points,Datetime)SELECT inSID,inGID,inUID,ID,Type,Points,innow from sparkiesmaster where Code='ALLDAY' and Status=1;
					SET OUTPOINTS=OUTPOINTS + (SELECT Points from sparkiesmaster where Code='ALLDAY' and Status=1);
				END IF;
			END IF;
	
		END IF;
END IF;


SELECT OUTPOINTS;
 
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `insertsparkiesnew~100417` (IN `inSID` INT(11), IN `inGID` INT(11), IN `inUID` INT(11), IN `inScenarioCode` VARCHAR(55), IN `inTotal_Ques` INT(11), IN `inAttempt_Ques` INT(11), IN `inAnswer` INT(11), IN `inGame_Score` INT(11), IN `inPlanid` INT(11), IN `inGameid` INT(11), IN `inDateTime` VARCHAR(55))  BEGIN

DECLARE OUTPOINTS INT(11);
DECLARE NOOFTIMESPLAY INT(11);
DECLARE NOOFTIMESPLAYED INT(11);

SET OUTPOINTS=0;

IF(inScenarioCode='GAME_END')THEN
	IF(inAttempt_Ques>=1)THEN 
		INSERT INTO user_sparkies_history(S_ID,G_ID,U_ID,Scenario_ID,Type,Points,Datetime)SELECT inSID,inGID,inUID,ID,Type,Points,inDateTime from sparkiesmaster where Code='ONE_Q' and Status=1;
		SET OUTPOINTS=OUTPOINTS + (SELECT Points from sparkiesmaster where Code='ONE_Q' and Status=1);
	END IF;	
	IF(inAttempt_Ques='10')THEN
		INSERT INTO user_sparkies_history(S_ID,G_ID,U_ID,Scenario_ID,Type,Points,Datetime)SELECT inSID,inGID,inUID,ID,Type,Points,inDateTime from sparkiesmaster where Code='ALL_Q' and Status=1;
		SET OUTPOINTS=OUTPOINTS + (SELECT Points from sparkiesmaster where Code='ALL_Q' and Status=1);
	END IF;
	IF(inAnswer>=1)THEN
		INSERT INTO user_sparkies_history(S_ID,G_ID,U_ID,Scenario_ID,Type,Points,Datetime)SELECT inSID,inGID,inUID,ID,Type,Points,inDateTime from sparkiesmaster where Code='1QC' and Status=1;
		SET OUTPOINTS=OUTPOINTS + (SELECT Points from sparkiesmaster where Code='1QC' and Status=1);
	END IF;
	IF(inAnswer='10')THEN
		INSERT INTO user_sparkies_history(S_ID,G_ID,U_ID,Scenario_ID,Type,Points,Datetime)SELECT inSID,inGID,inUID,ID,Type,Points,inDateTime from sparkiesmaster where Code='10QC' and Status=1;
		SET OUTPOINTS=OUTPOINTS + (SELECT Points from sparkiesmaster where Code='10QC' and Status=1);
	END IF;	
	IF(inGame_Score>=60)THEN
		INSERT INTO user_sparkies_history(S_ID,G_ID,U_ID,Scenario_ID,Type,Points,Datetime)SELECT inSID,inGID,inUID,ID,Type,Points,inDateTime from sparkiesmaster where Code='ABOVE_60' and Status=1;
		SET OUTPOINTS=OUTPOINTS + (SELECT Points from sparkiesmaster where Code='ABOVE_60' and Status=1);
	END IF;
    
    SET NOOFTIMESPLAY=(SELECT ntimes from game_limit where g_id=inGameid AND gp_id=inPlanid);
	SET NOOFTIMESPLAYED=(SELECT COUNT(id) from game_reports where g_id=inGameid AND gp_id=inPlanid and gu_id=inUID);
	IF(NOOFTIMESPLAY=NOOFTIMESPLAYED)THEN
		INSERT INTO user_sparkies_history(S_ID,G_ID,U_ID,Scenario_ID,Type,Points,Datetime)SELECT inSID,inGID,inUID,ID,Type,Points,inDateTime from sparkiesmaster where Code='ALL5TGP' and Status=1;
		SET OUTPOINTS=OUTPOINTS + (SELECT Points from sparkiesmaster where Code='ALL5TGP' and Status=1);
	END IF;
    
    

END IF;

SELECT  OUTPOINTS;
 
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `insertsparkiesnew~100417.1` (IN `inSID` INT(11), IN `inGID` INT(11), IN `inUID` INT(11), IN `inScenarioCode` VARCHAR(55), IN `inTotal_Ques` INT(11), IN `inAttempt_Ques` INT(11), IN `inAnswer` INT(11), IN `inGame_Score` INT(11), IN `inPlanid` INT(11), IN `inGameid` INT(11), IN `inDateTime` VARCHAR(55))  BEGIN

DECLARE OUTPOINTS INT(11);
DECLARE NOOFTIMESPLAY INT(11);
DECLARE NOOFTIMESPLAYED INT(11);
DECLARE OUTWEEKEND INT(11);
DECLARE OUTFIRSTLOGIN INT(11);
DECLARE OUTSECTIONNAME Varchar(16);
DECLARE OUTGRADENAME Varchar(16);
DECLARE OUTCOLGRADENAME VARCHAR(55);
DECLARE OUTCOLSECTIONNAME VARCHAR(55);
DECLARE OUTAVAIBILITY INT(11);	
	
SET OUTPOINTS=0;

IF(inScenarioCode='GAME_END')THEN
	IF(inAttempt_Ques>=1)THEN 
		INSERT INTO user_sparkies_history(S_ID,G_ID,U_ID,Scenario_ID,Type,Points,Datetime)SELECT inSID,inGID,inUID,ID,Type,Points,inDateTime from sparkiesmaster where Code='ONE_Q' and Status=1;
		SET OUTPOINTS=OUTPOINTS + (SELECT Points from sparkiesmaster where Code='ONE_Q' and Status=1);
	END IF;	
	IF(inAttempt_Ques='10')THEN
		INSERT INTO user_sparkies_history(S_ID,G_ID,U_ID,Scenario_ID,Type,Points,Datetime)SELECT inSID,inGID,inUID,ID,Type,Points,inDateTime from sparkiesmaster where Code='ALL_Q' and Status=1;
		SET OUTPOINTS=OUTPOINTS + (SELECT Points from sparkiesmaster where Code='ALL_Q' and Status=1);
	END IF;
	IF(inAnswer>=1)THEN
		INSERT INTO user_sparkies_history(S_ID,G_ID,U_ID,Scenario_ID,Type,Points,Datetime)SELECT inSID,inGID,inUID,ID,Type,Points,inDateTime from sparkiesmaster where Code='1QC' and Status=1;
		SET OUTPOINTS=OUTPOINTS + (SELECT Points from sparkiesmaster where Code='1QC' and Status=1);
	END IF;
	IF(inAnswer='10')THEN
		INSERT INTO user_sparkies_history(S_ID,G_ID,U_ID,Scenario_ID,Type,Points,Datetime)SELECT inSID,inGID,inUID,ID,Type,Points,inDateTime from sparkiesmaster where Code='10QC' and Status=1;
		SET OUTPOINTS=OUTPOINTS + (SELECT Points from sparkiesmaster where Code='10QC' and Status=1);
	END IF;	
	IF(inGame_Score>=60)THEN
		INSERT INTO user_sparkies_history(S_ID,G_ID,U_ID,Scenario_ID,Type,Points,Datetime)SELECT inSID,inGID,inUID,ID,Type,Points,inDateTime from sparkiesmaster where Code='ABOVE_60' and Status=1;
		SET OUTPOINTS=OUTPOINTS + (SELECT Points from sparkiesmaster where Code='ABOVE_60' and Status=1);
	END IF;
    
    SET NOOFTIMESPLAY=(SELECT ntimes from game_limit where g_id=inGameid AND gp_id=inPlanid);
	SET NOOFTIMESPLAYED=(SELECT COUNT(id) from game_reports where g_id=inGameid AND gp_id=inPlanid and gu_id=inUID);
	IF(NOOFTIMESPLAY=NOOFTIMESPLAYED)THEN
		INSERT INTO user_sparkies_history(S_ID,G_ID,U_ID,Scenario_ID,Type,Points,Datetime)SELECT inSID,inGID,inUID,ID,Type,Points,inDateTime from sparkiesmaster where Code='ALL5TGP' and Status=1;
		SET OUTPOINTS=OUTPOINTS + (SELECT Points from sparkiesmaster where Code='ALL5TGP' and Status=1);
	END IF;
		
    INSERT INTO user_sparkies_history(S_ID,G_ID,U_ID,Scenario_ID,Type,Points,Datetime)SELECT inSID,inGID,inUID,ID,Type,Points,inDateTime from sparkiesmaster where Code='NOTPOAG' and Status=1;
	SET OUTPOINTS=OUTPOINTS + (SELECT Points from sparkiesmaster where Code='NOTPOAG' and Status=1);
    
END IF;
IF(inScenarioCode='LOGIN')THEN
	SET OUTFIRSTLOGIN=(select count(ID) as firstlogin  from user_sparkies_history where U_ID=inUID and date(Datetime)=CURDATE());
	SET OUTWEEKEND=(SELECT DAYOFWEEK(CURDATE()) = 7 or DAYOFWEEK(CURDATE()) = 1);
		IF(OUTFIRSTLOGIN=0)THEN 
			IF(OUTWEEKEND=1)THEN
				INSERT INTO user_sparkies_history(S_ID,G_ID,U_ID,Scenario_ID,Type,Points,Datetime)SELECT inSID,inGID,inUID,ID,Type,Points,inDateTime from sparkiesmaster where Code='WEEKEND' and Status=1;
				SET OUTPOINTS=OUTPOINTS + (SELECT Points from sparkiesmaster where Code='WEEKEND' and Status=1);
			END IF;
			
			SET OUTSECTIONNAME=(select section from users where id=inUID);
			SET OUTGRADENAME=(select REPLACE(classname,'Grade ','') as classname  from class  where id=(select grade_id from users where id=inUID));
            SET OUTCOLGRADENAME=(select CONCAT(LOWER(DAYNAME(CURDATE())),'_grade') as gradename from schools_period_schedule where school_id=inSID limit 1 );
			SET OUTCOLSECTIONNAME=(select CONCAT(LOWER(DAYNAME(CURDATE())),'_section') as sectionname from schools_period_schedule where school_id=inSID limit 1 );
	
    SET OUTAVAIBILITY=(SELECt COUNT(schedule_id) as availability from schools_period_schedule where school_id=inSID and OUTCOLGRADENAME=OUTGRADENAME and OUTCOLSECTIONNAME=OUTSECTIONNAME);
	
		END IF;
END IF;


SELECT OUTPOINTS,OUTCOLGRADENAME,OUTGRADENAME,OUTCOLSECTIONNAME,OUTSECTIONNAME,OUTAVAIBILITY;
 
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `insertsparkiesnew~old1` (IN `inSID` INT(11), IN `inGID` INT(11), IN `inUID` INT(11), IN `inScenarioCode` VARCHAR(55), IN `inTotal_Ques` INT(11), IN `inAttempt_Ques` INT(11), IN `inAnswer` INT(11), IN `inGame_Score` INT(11), IN `inDateTime` VARCHAR(55))  BEGIN

DECLARE OUTPOINTS INT(11);

SET OUTPOINTS=0;

IF(inScenarioCode='GAME_END')THEN
	IF(inAttempt_Ques>=1)THEN 
		INSERT INTO user_sparkies_history(S_ID,G_ID,U_ID,Scenario_ID,Type,Points,Datetime)SELECT inSID,inGID,inUID,ID,Type,Points,inDateTime from sparkiesmaster where Code='ONE_Q' and Status=1;
		SET OUTPOINTS=OUTPOINTS + (SELECT Points from sparkiesmaster where Code='ONE_Q' and Status=1);
	END IF;	
	IF(inAttempt_Ques='10')THEN
		INSERT INTO user_sparkies_history(S_ID,G_ID,U_ID,Scenario_ID,Type,Points,Datetime)SELECT inSID,inGID,inUID,ID,Type,Points,inDateTime from sparkiesmaster where Code='ALL_Q' and Status=1;
		SET OUTPOINTS=OUTPOINTS + (SELECT Points from sparkiesmaster where Code='ALL_Q' and Status=1);
	END IF;
	IF(inAnswer>=1)THEN
		INSERT INTO user_sparkies_history(S_ID,G_ID,U_ID,Scenario_ID,Type,Points,Datetime)SELECT inSID,inGID,inUID,ID,Type,Points,inDateTime from sparkiesmaster where Code='1QC' and Status=1;
		SET OUTPOINTS=OUTPOINTS + (SELECT Points from sparkiesmaster where Code='1QC' and Status=1);
	END IF;
	IF(inAnswer='10')THEN
		INSERT INTO user_sparkies_history(S_ID,G_ID,U_ID,Scenario_ID,Type,Points,Datetime)SELECT inSID,inGID,inUID,ID,Type,Points,inDateTime from sparkiesmaster where Code='10QC' and Status=1;
		SET OUTPOINTS=OUTPOINTS + (SELECT Points from sparkiesmaster where Code='10QC' and Status=1);
	END IF;	
	IF(inGame_Score>=60)THEN
		INSERT INTO user_sparkies_history(S_ID,G_ID,U_ID,Scenario_ID,Type,Points,Datetime)SELECT inSID,inGID,inUID,ID,Type,Points,inDateTime from sparkiesmaster where Code='ABOVE_60' and Status=1;
		SET OUTPOINTS=OUTPOINTS + (SELECT Points from sparkiesmaster where Code='ABOVE_60' and Status=1);
	END IF;

END IF;

SELECT  OUTPOINTS;
 
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `IsLogin` (IN `inusername` VARCHAR(255), IN `inpwd` VARCHAR(255), IN `inidealtime` VARCHAR(55), IN `inuserid` INT(11), IN `innow` DATETIME)  BEGIN

select count(id) as islogin FROM users a WHERE username=inusername AND password=SHA1(CONCAT(salt1,inpwd,salt2)) AND status=1 AND (SELECT school_id FROM school_admin WHERE school_id=a.sid AND active=1  AND flag=1) AND islogin=1 AND TIMESTAMPDIFF(MINUTE,last_active_datetime,innow)<=inidealtime;

END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `KGGameDataInsert` (IN `inuserid` INT(11), IN `incatid` INT(11), IN `ingp_id` INT(11), IN `ingameid` INT(11), IN `intotal_ques` INT(11), IN `inattempt_ques` INT(11), IN `inanswer` INT(11), IN `inscore` INT(11), IN `ingtime` INT(11), IN `inrtime` INT(11), IN `incrtime` INT(11), IN `inwrtime` INT(11), IN `inlastupdate` DATE, IN `increated_date_time` DATETIME, IN `inIs_schedule` INT(11), IN `inskills` INT(11))  BEGIN

DECLARE Oskillid INT(11);
DECLARE OnoofskillPlayed INT(11);
DECLARE OUTSESSIONID INT(11);
DECLARE OUTSESSIONLEVEL INT(11);


SET Oskillid=(select gs_id from games where gid=ingameid and gstatus=1);
SET OnoofskillPlayed=(select count(gu_id) from game_reports where gu_id=inuserid and g_id=ingameid and lastupdate=inlastupdate and gs_id IN(1,2,3));

IF(inskills>OnoofskillPlayed)THEN

	insert into gamedata (gu_id,gc_id,gs_id,gp_id,g_id,total_question,attempt_question,answer,game_score,gtime,rtime,crtime,wrtime,lastupdate,created_date_time,Is_schedule)	values(inuserid,incatid,Oskillid,ingp_id,ingameid,intotal_ques,inattempt_ques,inanswer,inscore,ingtime,inrtime,incrtime,inwrtime,inlastupdate,increated_date_time,inIs_schedule);

	SET OnoofskillPlayed=(select count(gu_id) from game_reports where gu_id=inuserid and g_id=ingameid and lastupdate=inlastupdate and gs_id IN(1,2,3));
	
	IF(OnoofskillPlayed>=inskills)THEN
	
		SET OUTSESSIONID=(select session_id from gamedata where gu_id=inuserid and lastupdate!=inlastupdate and session_id!=0 order by id DESC limit 1);
	
		IF(OUTSESSIONID!='') THEN
			Update gamedata SET session_id=OUTSESSIONID+1 where gu_id=inuserid and lastupdate=inlastupdate;
			SET OUTSESSIONLEVEL=OUTSESSIONID+1;
		ELSE
			Update gamedata SET session_id=1 where gu_id=inuserid and lastupdate=inlastupdate;
			 SET OUTSESSIONLEVEL=1;
		END IF;
		
	END IF;
	
	Select OUTSESSIONLEVEL as result;

ELSE

Select -1 as result;

END IF;

END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `KinderIsLogin` (IN `inusername` VARCHAR(255), IN `inpwd` VARCHAR(255), IN `inidealtime` VARCHAR(55), IN `inuserid` INT(11), IN `innow` DATETIME)  BEGIN

select count(id) as islogin FROM blessedangel_v1_kinder.users a WHERE username=inusername AND password=SHA1(CONCAT(salt1,inpwd,salt2)) AND status=1 AND (SELECT school_id FROM blessedangel_v1_kinder.school_admin WHERE school_id=a.sid AND active=1  AND flag=1) AND islogin=1 AND TIMESTAMPDIFF(MINUTE,last_active_datetime,innow)<=inidealtime;

END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `Schools_Period_Schedule_Days` (IN `inschoolid` INT(11), IN `instartdate` DATE, IN `inenddate` DATE)  BEGIN 
DECLARE outisexist INT(11);

SET outisexist=(select count(id) from schools_period_schedule_daystesting where sid=inschoolid and period_date=instartdate);
IF(outisexist=0)THEN

INSERT INTO schools_period_schedule_daystesting(period_no, period_date, period_day, grade_id, grade_name, section, starttime, endtime, sid, academic_id, expected_user, status)
select period,selected_date,nameofday,(select id from class where REPLACE(classname,'Grade ','') = j1.monday_grade) as gradeid1,concat('Grade ','',monday_grade) as gradename,section,start_time,end_time,inschoolid as sid,20 as academicid,(select count(distinct(u.id)) as regusers from users u  where u.grade_id=(select id from class where REPLACE(classname,'Grade ','') = j1.monday_grade) and u.section=j1.section and u.sid=inschoolid and u.status = 1 and u.visible=1) as totalusers ,1
from (
select period,school_id,monday_grade,monday_section as section,'Monday' as dayname1,start_time,end_time from schools_period_schedule where school_id=inschoolid and academic_id=20 and monday_grade!=''

union select period,school_id,tuesday_grade,tuesday_section as section,'Tuesday' as dayname1,start_time,end_time from schools_period_schedule where school_id=inschoolid and academic_id=20 and tuesday_grade!=''

union select period,school_id,wednesday_grade,wednesday_section as section,'Wednesday' as dayname1,start_time,end_time  from schools_period_schedule where school_id=inschoolid and academic_id=20 and wednesday_grade!=''

union select period,school_id,thursday_grade,thursday_section as section,'Thursday' as dayname1,start_time,end_time from schools_period_schedule where school_id=inschoolid and academic_id=20 and thursday_grade!=''

union select period,school_id,friday_grade,friday_section as section,'Friday' as dayname1,start_time,end_time from schools_period_schedule where school_id=inschoolid and academic_id=20 and friday_grade!=''

union select period,school_id,saturday_grade,saturday_section as section,'Saturday' as dayname1,start_time,end_time from schools_period_schedule where school_id=inschoolid and academic_id=20 and saturday_grade!=''

union select period,school_id,sunday_grade,sunday_section as section,'Sunday' as dayname1,start_time,end_time from schools_period_schedule where school_id=inschoolid and academic_id=20 and sunday_grade!='')j1 cross join 

(select *,dayname(selected_date) as nameofday from 
(select adddate('1970-01-01',t4.i*10000 + t3.i*1000 + t2.i*100 + t1.i*10 + t0.i) selected_date from
 (select 0 i union select 1 union select 2 union select 3 union select 4 union select 5 union select 6 union select 7 union select 8 union select 9) t0,
 (select 0 i union select 1 union select 2 union select 3 union select 4 union select 5 union select 6 union select 7 union select 8 union select 9) t1,
 (select 0 i union select 1 union select 2 union select 3 union select 4 union select 5 union select 6 union select 7 union select 8 union select 9) t2,
 (select 0 i union select 1 union select 2 union select 3 union select 4 union select 5 union select 6 union select 7 union select 8 union select 9) t3,
 (select 0 i union select 1 union select 2 union select 3 union select 4 union select 5 union select 6 union select 7 union select 8 union select 9) t4) v
where selected_date between instartdate and inenddate and selected_date >= (select start_date from schools where id=inschoolid and status=1 and active=1 and visible=1) and selected_date NOT IN (select leave_date from schools_leave_list where school_id = inschoolid and status=1)) j2 on j1.dayname1=j2.nameofday order by selected_date asc;

END IF;

END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `Schools_Wise_Period_Insert` (IN `instartdate` DATE, IN `inenddate` DATE)  BEGIN
 
DECLARE v_finished INTEGER DEFAULT 0;
DECLARE v_sid INT(11) DEFAULT "";
 
DEClARE sid_cursor CURSOR FOR  select id from schools where active=1 and visible=1 and status=1;
 
DECLARE CONTINUE HANDLER FOR NOT FOUND SET v_finished = 1;
 
 OPEN sid_cursor;
 
 get_id: LOOP
 
 FETCH sid_cursor INTO v_sid;
 
 IF v_finished = 1 THEN 
 LEAVE get_id;
 END IF;
 
Call  Schools_Period_Schedule_Days (v_sid,instartdate,inenddate);
 
 END LOOP get_id;
 
 CLOSE sid_cursor;
 
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `SkillkitGameAssign` (IN `inuserid` INT(11), IN `ingrade_id` INT(11), IN `innoofdaysplay` INT(11), IN `insession_start_range` INT(11), IN `insession_end_range` INT(11), IN `ingp_id` INT(11), IN `inNext_Session_StartRange` INT(11), IN `inNext_Session_EndRange` INT(11), IN `incurdate` DATE, IN `inastartdate` DATE, IN `inaenddate` DATE, IN `incurdatetime` DATETIME, IN `inintervalrange` INT(11))  BEGIN
 
DECLARE OTodayGameAssigned INT(11);
DECLARE OPlayedDaysCount INT(11);
DECLARE OGameScore Varchar(55);
DECLARE Ogs_id INT(11);
DECLARE Oskill_id INT(11);
DECLARE Omedian_value INT(11);
DECLARE Omaxsession INT(11);
DECLARE Oweekskillcount INT(11);

DECLARE v_done INT DEFAULT FALSE;
DECLARE cursorForProfile CURSOR FOR 
select ROUND(avg(gamescore),2) as gamescore,gs_id,sm.skill_id,SUBSTRING_INDEX(sm.median_value, '-', 1) as median_value from (SELECT (AVG(game_score)) as gamescore ,gs_id , lastupdate,DATE_FORMAT(lastupdate,'%m') as playedMonth,session_id  FROM game_reports WHERE gs_id in (59,60,61,62,63) and gu_id=inuserid and  (lastupdate between inastartdate and inaenddate) and (session_id between insession_start_range and insession_end_range) and session_id!=0 group by gs_id , session_id) as a2  join skillkit_master as sm on sm.skill_id=a2.gs_id  where grade_id=ingrade_id  group by gs_id order by gs_id asc;

DECLARE CONTINUE HANDLER FOR NOT FOUND SET v_done = TRUE; 


SET OTodayGameAssigned=(select count(ID) as isavailable from sk_user_game_list where userID=inuserid and DATE(created_date)=incurdate);

SET OPlayedDaysCount=(select count(distinct(lastupdate)) as playedDate from game_reports gr where gr.gu_id=inuserid and lastupdate between inastartdate and inaenddate and session_id!=0 and lastupdate!=incurdate);

IF(OTodayGameAssigned=0)THEN

	IF((OPlayedDaysCount!=0) && ((OPlayedDaysCount%innoofdaysplay)=0)) THEN

	DROP TEMPORARY TABLE IF EXISTS WeekSkills;
	CREATE TEMPORARY TABLE WeekSkills(
		wid INT NOT NULL AUTO_INCREMENT,
		PRIMARY KEY(wid),
		tmpgs_id VARCHAR(55),
		tmplevel VARCHAR(55) ); 
        
		OPEN cursorForProfile;

		read_loop: LOOP
		FETCH cursorForProfile INTO OGameScore,Ogs_id,Oskill_id,Omedian_value;
		IF v_done THEN
		LEAVE read_loop;
		END IF;
		
		 
		IF(Omedian_value>=OGameScore)
		THEN
			IF((Omedian_value>=OGameScore) && ((Omedian_value-5)<=OGameScore))
			THEN 
				INSERT INTO WeekSkills(tmpgs_id,tmplevel)VALUES(Ogs_id,'1');
			
			ELSE IF(((Omedian_value-5)>=OGameScore))
			THEN 
				INSERT INTO WeekSkills(tmpgs_id,tmplevel)VALUES(Ogs_id,'2');
			END IF;
			END IF;
		END IF;
		
		
		
		END LOOP;

		CLOSE cursorForProfile; 
		
        SET Omaxsession=(OPlayedDaysCount/innoofdaysplay);
        update sk_user_game_list set status=1 where userID=inuserid and planID=ingp_id;
        
        SET Oweekskillcount=(select count(wid) from WeekSkills);        
        IF(Oweekskillcount>0)THEN
			insert into sk_user_game_list(userID,planID,SessionID,weakSkills,levelid,status,created_date,session_start_range,session_end_range)select inuserid,ingp_id,Omaxsession,group_concat(tmpgs_id),group_concat(tmplevel),0,incurdatetime,inNext_Session_StartRange,inNext_Session_EndRange from WeekSkills;
        END IF;
	END IF;

END IF;
 
 select 1;
 
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `SK_GameDataInsert` (IN `inuid` INT(11), IN `inSID` INT(11), IN `inGID` INT(11), IN `inResponseTime` INT(11), IN `inBalaceTime` INT(11), IN `inCorrectAnswer` INT(11), IN `inUserAnswer` VARCHAR(16), IN `inAnswerStaus` VARCHAR(16), IN `inQNO` INT(11), IN `inSCORE` INT(11), IN `inTimeOverStatus` INT(11), IN `inpuzzle_cycle` INT(11), IN `incurdate` DATE, IN `incurdatetime` DATETIME, IN `ingtime` INT(11), IN `ingp_id` INT(11))  BEGIN

DECLARE outPlayedCount INT(11);
DECLARE outPlayedQusCount INT(11);
DECLARE Ototal_question INT(11);
DECLARE Oattempt_question INT(11);
DECLARE Oanswer INT(11);
DECLARE Ogame_score INT(11);
DECLARE Ogtime INT(11);
DECLARE Ortime INT(11);
DECLARE Ocrtime INT(11);
DECLARE Owrtime INT(11);



INSERT INTO sk_gamescore(gu_id, gs_id, g_id, que_id, answer, useranswer, game_score, answer_status, timeoverstatus, responsetime, balancetime, lastupdate, creation_date, modified_date, puzzle_cycle)
VALUES(inuid,inSID,inGID,inQNO,inCorrectAnswer,inUserAnswer,inSCORE,inAnswerStaus,inTimeOverStatus,inResponseTime,inBalaceTime,incurdate,incurdatetime,incurdatetime,inpuzzle_cycle);

SET outPlayedQusCount=(SELECT count(gs_id) Completedquestion FROM sk_gamescore as gs where g_id=inGID and gu_id=inuid  and puzzle_cycle=inpuzzle_cycle and lastupdate=incurdate);

IF(inBalaceTime=0 and inAnswerStaus!='U' and outPlayedQusCount!=10)THEN

	INSERT INTO sk_gamescore(gu_id, gs_id, g_id, que_id, answer, useranswer, game_score, answer_status, timeoverstatus, responsetime, balancetime, lastupdate, creation_date, modified_date, puzzle_cycle)
	VALUES(inuid,inSID,inGID,inQNO,inCorrectAnswer,'NotAnswered',0,'U',inTimeOverStatus,inResponseTime,inBalaceTime,incurdate,incurdatetime,incurdatetime,inpuzzle_cycle);
END IF;

SET outPlayedCount=(SELECT CASE when count(gs_id)>=10 THEN 1 WHEN FIND_IN_SET('U',group_concat(answer_status))>=1 THEN 1 ELSE 0 END CompletedSkill FROM sk_gamescore as gs where g_id=inGID and gu_id=inuid and puzzle_cycle=inpuzzle_cycle and lastupdate=incurdate);

IF(outPlayedCount=1) 
THEN
	SET Ototal_question=10;
	
	SET Oattempt_question=(select count(gu_id)  from sk_gamescore where g_id=inGID and gu_id=inuid and answer_status!='U' and puzzle_cycle=inpuzzle_cycle and lastupdate=incurdate);
	
	SET Oanswer=(select count(answer_status) from sk_gamescore where g_id=inGID and gu_id=inuid and answer_status='correct' and puzzle_cycle=inpuzzle_cycle and lastupdate=incurdate);
	
	SET Ogame_score=(select coalesce(sum(game_score),0) from sk_gamescore where g_id=inGID and gu_id=inuid and puzzle_cycle=inpuzzle_cycle and lastupdate=incurdate);
	
	SET Ortime=(select coalesce(sum(CAST(responsetime AS UNSIGNED)),0) from sk_gamescore where g_id=inGID and gu_id=inuid and answer_status!='U' and puzzle_cycle=inpuzzle_cycle and lastupdate=incurdate);
	
	SET Ocrtime=(select coalesce(sum(CAST(responsetime AS UNSIGNED)),0) from sk_gamescore where g_id=inGID and gu_id=inuid and answer_status='correct' and puzzle_cycle=inpuzzle_cycle and lastupdate=incurdate);
	
	SET Owrtime=(select coalesce(sum(CAST(responsetime AS UNSIGNED)),0) from sk_gamescore where g_id=inGID and gu_id=inuid and answer_status='wrong' and puzzle_cycle=inpuzzle_cycle and lastupdate=incurdate);
	
	insert into sk_gamedata (gu_id,gc_id,gs_id,gp_id,g_id,total_question,attempt_question,answer,game_score,gtime,rtime,crtime,wrtime,lastupdate,puzzle_cycle)
	values(inuid,1,inSID,ingp_id,inGID,Ototal_question,Oattempt_question,Oanswer,Ogame_score,ingtime,Ortime,Ocrtime,Owrtime,incurdate,inpuzzle_cycle);
END IF;

select LAST_INSERT_ID();



END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_userlogin` (IN `inuserid` INT(11), IN `inuniqueid` VARCHAR(400), IN `ingrade` INT(11), IN `insid` INT(11), IN `insection` VARCHAR(100), IN `inIP` VARCHAR(100), IN `incountry` VARCHAR(800), IN `inregion` VARCHAR(800), IN `incity` VARCHAR(800), IN `inisp` VARCHAR(800), IN `inbrowser` TEXT, IN `instatus` INT(11), IN `indate` VARCHAR(100), IN `indatetime` VARCHAR(100))  BEGIN

DECLARE OUTlastsessiondate INT(11);
DECLARE OUTstartdate Date;
DECLARE OUTenddate Date;
DECLARE OUTsession_id INT(11);

update users set pre_logindate=login_date,login_date=indate,login_count=login_count+1,session_id=inuniqueid,islogin=1,last_active_datetime=indatetime WHERE id =inuserid;

SET OUTlastsessiondate=(select count(lastupdate) as lastsessiondate from gamedata where gu_id = inuserid and lastupdate = (select max(period_date) from schools_period_schedule_days where grade_id=ingrade and section=insection and sid=insid));


select startdate,enddate from academic_year where id=(select academic_id from schools where id=insid)order by id desc limit 1 INTO OUTstartdate,OUTenddate;

SET OUTsession_id=(select session_id from gamedata where gu_id=inuserid and session_id!=0 order by id DESC limit 1);


INSERT INTO user_login_log(userid,sessionid,first_login_datetime,created_date,lastupdate,logout_date,ip,country,region,city,browser,isp,status)VALUES(inuserid,inuniqueid,indatetime,indatetime,indatetime,indatetime, inIP,incountry,inregion,incity,inbrowser,inisp,instatus);

select OUTlastsessiondate,OUTstartdate,OUTenddate,OUTsession_id;


END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `TESTING` (IN `inuid` INT(11), IN `insid` INT(11))  BEGIN

DECLARE OUTSECTIONNAME Varchar(16);
DECLARE OUTGRADENAME Varchar(16);
DECLARE OUTAVAIBILITY INT(11);

SET OUTSECTIONNAME=(select section from users where id=inuid);
SET OUTGRADENAME=(select REPLACE(classname,'Grade ','') as classname  from class  where id=(select grade_id from users where id=inuid));

SET OUTAVAIBILITY=(select COUNT(schedule_id)  from schools_period_schedule where school_id=insid  and 1 IN ((CASE WHEN (monday_grade=OUTGRADENAME and monday_section=OUTSECTIONNAME) OR (tuesday_grade=OUTGRADENAME and tuesday_section=OUTSECTIONNAME) OR   (wednesday_grade=OUTGRADENAME and wednesday_section=OUTSECTIONNAME) OR   (thursday_grade=OUTGRADENAME and thursday_section=OUTSECTIONNAME) OR  (friday_grade=OUTGRADENAME and friday_section=OUTSECTIONNAME) >0 THEN 1 ELSE 0 END )));

select OUTSECTIONNAME,OUTGRADENAME,OUTAVAIBILITY;

END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `TodayTimerInsert` (IN `inuserid` INT(11), IN `incurdate` DATE, IN `incurdatetime` DATETIME)  BEGIN

DECLARE OMaxPlayTime INT(11);
DECLARE OSumoftotTimeUsed INT(11);
DECLARE ORemainingTime INT(11);
DECLARE OTodayInsert INT(11);



SET OMaxPlayTime=(select value from config_master where code='MAXTIMEOFPLAY' and status='Y');
SET OSumoftotTimeUsed=(SELECT SUM(TimeLoggedIn) as LoggedIntime from(SELECT TIMESTAMPDIFF(SECOND,created_date,lastupdate) AS TimeLoggedIn FROM user_login_log WHERE userid=inuserid and date(created_date)=incurdate) as a2);

SET ORemainingTime=OMaxPlayTime-OSumoftotTimeUsed;

IF(OSumoftotTimeUsed>=OMaxPlayTime)THEN
		
	SET OTodayInsert=(Select count(id) as isexist from userplaytime where userid=inuserid and expiredon=incurdate);
	IF(OTodayInsert=0)THEN
		Insert into userplaytime(userid,expiredon,expireddatetime)values(inuserid,incurdate,incurdatetime);
	END IF;
END IF; 

Select OMaxPlayTime,OSumoftotTimeUsed,ORemainingTime;

END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `UpdateSkillkitSession` (IN `inuserid` INT(11), IN `intodaydate` DATE, IN `instart_range` INT(11), IN `inend_range` INT(11))  BEGIN

DECLARE OUTPLAYEDCOUNT INT(11);
DECLARE OUTPLAYCOUNT INT(11);
DECLARE OUTSESSIONID INT(11);
DECLARE OUTSESSIONLEVEL INT(11);

SET OUTPLAYEDCOUNT=(select count(DISTINCT gs_id) as playedskill from sk_gamedata where gu_id=inuserid and lastupdate=intodaydate);
SET OUTPLAYCOUNT=(select count(id)  from category_skills where FIND_IN_SET(id,(select weakSkills from sk_user_game_list where  userID=inuserid and status=0)));

SET OUTSESSIONID=(select CASE when session_id BETWEEN instart_range and inend_range then session_id else instart_range end session_id from (select session_id from sk_gamedata where gu_id=inuserid and lastupdate!=intodaydate and session_id!=0 order by id DESC limit 1) as a1);

IF(OUTPLAYCOUNT=OUTPLAYEDCOUNT)THEN
	IF(OUTSESSIONID!='') THEN
		Update sk_gamedata SET session_id=OUTSESSIONID+1 where gu_id=inuserid and lastupdate=intodaydate;
        SET OUTSESSIONLEVEL=OUTSESSIONID+1;
	ELSE
		Update sk_gamedata SET session_id=(select session_start_range from sk_user_game_list where userID=inuserid and status=0) where gu_id=inuserid and lastupdate=intodaydate;
         SET OUTSESSIONLEVEL=(select session_start_range from sk_user_game_list where userID=inuserid and status=0);
	END IF;
END IF;

select OUTSESSIONLEVEL,OUTPLAYCOUNT,OUTPLAYEDCOUNT;

END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `UpdateTodaySession` (IN `inuserid` INT(11), IN `intodaydate` DATE)  BEGIN

DECLARE OUTPLAYCOUNT INT(11);
DECLARE OUTSESSIONID INT(11);
DECLARE OUTSESSIONLEVEL INT(11);

SET OUTPLAYCOUNT=(select count( DISTINCT gs_id) as playedskill from gamedata where gu_id=inuserid and lastupdate=intodaydate);
SET OUTSESSIONID=(select session_id from gamedata where gu_id=inuserid and lastupdate!=intodaydate and session_id!=0 order by id DESC limit 1);

IF(OUTPLAYCOUNT=5)THEN
	IF(OUTSESSIONID!='') THEN
		Update users set current_session=(OUTSESSIONID+1) where id=inuserid;
		Update gamedata SET session_id=OUTSESSIONID+1 where gu_id=inuserid and lastupdate=intodaydate;  
        SET OUTSESSIONLEVEL=OUTSESSIONID+1;
	ELSE
		Update users set current_session=1 where id=inuserid;
		Update gamedata SET session_id=1 where gu_id=inuserid and lastupdate=intodaydate;		
         SET OUTSESSIONLEVEL=1;       
	END IF;
END IF;

 

END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `UpdateTodaySessionnew` (IN `inuserid` INT(11), IN `intodaydate` DATE, IN `inoofskills` INT(11))  BEGIN

DECLARE OUTPLAYCOUNT INT(11);
DECLARE OUTSESSIONID INT(11);
DECLARE OUTSESSIONLEVEL INT(11);

SET OUTPLAYCOUNT=(select count( DISTINCT gs_id) as playedskill from gamedata where gu_id=inuserid and lastupdate=intodaydate);
SET OUTSESSIONID=(select session_id from gamedata where gu_id=inuserid and lastupdate!=intodaydate and session_id!=0 order by id DESC limit 1);

IF(OUTPLAYCOUNT=inoofskills)THEN
	IF(OUTSESSIONID!='') THEN
		Update gamedata SET session_id=OUTSESSIONID+1 where gu_id=inuserid and lastupdate=intodaydate;
        SET OUTSESSIONLEVEL=OUTSESSIONID+1;
	ELSE
		Update gamedata SET session_id=1 where gu_id=inuserid and lastupdate=intodaydate;
         SET OUTSESSIONLEVEL=1;
	END IF;
END IF;

select OUTSESSIONLEVEL,OUTPLAYCOUNT;

END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `updateuserloginstatus` (IN `inuserid` VARCHAR(11), IN `inlogin_session_id` VARCHAR(255))  BEGIN

Update users set islogin=0 WHERE id=inuserid AND status=1;


END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `Update_Academic_Year` (IN `inacademic_start` VARCHAR(100) CHARSET utf8, IN `inacademic_end` VARCHAR(100) CHARSET utf8)  BEGIN
DECLARE inIsChange INT(11);
SELECT COUNT(id) FROM academic_year WHERE startdate=inacademic_start AND enddate=inacademic_end INTO inIsChange;
START TRANSACTION;
IF inIsChange=0 THEN
UPDATE academic_year SET startdate=inacademic_start , enddate=inacademic_end;
RENAME TABLE game_reports TO game_reports_2015_16;
CREATE TABLE IF NOT EXISTS game_reports (id int(11) NOT NULL AUTO_INCREMENT,gu_id int(10) NOT NULL,gc_id int(10) NOT NULL,gs_id int(10) NOT NULL,gp_id varchar(100) NOT NULL,g_id int(30) NOT NULL,total_question varchar(15) NOT NULL,attempt_question varchar(20) NOT NULL,answer varchar(20) NOT NULL,game_score varchar(50) NOT NULL,gtime varchar(100) NOT NULL,rtime varchar(100) NOT NULL,crtime varchar(100) NOT NULL,wrtime varchar(100) NOT NULL,lastupdate date NOT NULL,createdby varchar(100) NOT NULL,creation_date date NOT NULL,modifiedby varchar(100) NOT NULL,modified_date timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,PRIMARY KEY (id)) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;
INSERT INTO game_reports (id, gu_id, gc_id, gs_id, gp_id, g_id, total_question, attempt_question, answer, game_score, gtime, rtime, crtime, wrtime, lastupdate, createdby, creation_date, modifiedby, modified_date) select id, gu_id, gc_id, gs_id, gp_id, g_id, total_question, attempt_question, answer, game_score, gtime, rtime, crtime, wrtime, lastupdate, createdby, creation_date, modifiedby, modified_date FROM game_reports_2015_16;
DELETE  FROM game_reports;
update users set status='0' where sid=1 and gp_id = 8;
update users set gp_id=gp_id+1,grade_id=(select grade_id from g_plans where id=gp_id limit 1) where sid=1 and gp_id between 1 and 7;
update users set status='0' where sid IN (2,6) and gp_id=8;
update users set gp_id=gp_id+1,grade_id=(select grade_id from g_plans where id=gp_id limit 1) where sid IN (2,6) and gp_id between 1 and 7;
update users set gp_id=1,grade_id=(select grade_id from g_plans where id=1 limit 1) where gp_id=11 and sid IN (2,6);
update users set gp_id=gp_id+1,grade_id=(select grade_id from g_plans where id=gp_id limit 1) where gp_id=10 and sid IN (2,6);
update users set status='0' where sid=3 and gp_id=5;
update users set gp_id=gp_id+1,grade_id=(select grade_id from g_plans where id=gp_id limit 1) where gp_id IN(3,4) and sid=3;
update users set status='0' where sid=4 and gp_id=21;
update users set gp_id=gp_id+1,grade_id=(select grade_id from g_plans where id=gp_id limit 1) where sid=4 and gp_id between 14 and 20;
update users set status='0' where sid=5 and gp_id=31;
update users set gp_id=gp_id+1,grade_id=(select grade_id from g_plans where id=gp_id limit 1) where sid=5 and gp_id between 22 and 30;
update users set status='0' where sid=8 and gp_id=8;
update users set gp_id=gp_id+1,grade_id=(select grade_id from  g_plans where id=gp_id limit 1) where gp_id IN (6,7) and sid =8;
update users set status='0' where sid=9 and gp_id=37;
update users set gp_id=gp_id+1,grade_id=(select grade_id from  g_plans where id=gp_id limit 1) where sid=9 and gp_id between 32 and 36;
update users set gp_id=gp_id+1,grade_id=(select grade_id from  g_plans where id=gp_id limit 1) where gp_id IN(38,39) and sid=9;
update users set gp_id=32,grade_id=(select grade_id from  g_plans where id=1 limit 1) where gp_id=40 and sid =9;
update users set status='0' where sid=10 and gp_id=50;
update users set gp_id=gp_id+1,grade_id=(select grade_id from g_plans where id=gp_id limit 1) where sid=10 and gp_id between 41 and 49;
update users set status='0' where sid=11 and gp_id=60;
update users set gp_id=gp_id+1,grade_id=(select grade_id from g_plans where id=gp_id limit 1) where sid=11 and gp_id between 51 and 59;
END IF;
COMMIT ;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `Update_Academic_Year_15_16_ck_grg` (IN `inacademic_start` VARCHAR(100) CHARSET utf8, IN `inacademic_end` VARCHAR(100) CHARSET utf8)  BEGIN
DECLARE inIsChange INT(11);
SELECT COUNT(id) FROM academic_year WHERE startdate=inacademic_start AND enddate=inacademic_end INTO inIsChange;
START TRANSACTION;
IF inIsChange=0 THEN
UPDATE academic_year SET startdate=inacademic_start , enddate=inacademic_end;

update users set status='0' where sid=1 and gp_id = 8;
update users set gp_id=gp_id+1,grade_id=(select grade_id from g_plans where id=gp_id limit 1) where sid=1 and gp_id between 1 and 7;

update users set status='0' where sid=4 and gp_id=21;
update users set gp_id=gp_id+1,grade_id=(select grade_id from g_plans where id=gp_id limit 1) where sid=4 and gp_id between 14 and 20;

END IF;
COMMIT ;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `Update_Academic_Year_New_Year` ()  BEGIN
START TRANSACTION;
update users set status='0' where sid=1 and gp_id = 8;
update users set gp_id=gp_id+1,grade_id=(select grade_id from g_plans where id=gp_id limit 1) where sid=1 and gp_id between 1 and 7;
update users set status='0' where sid IN (2,6) and gp_id=8;
update users set gp_id=gp_id+1,grade_id=(select grade_id from g_plans where id=gp_id limit 1) where sid IN (2,6) and gp_id between 1 and 7;
update users set gp_id=1,grade_id=(select grade_id from g_plans where id=1 limit 1) where gp_id=11 and sid IN (2,6);
update users set gp_id=gp_id+1,grade_id=(select grade_id from g_plans where id=gp_id limit 1) where gp_id=10 and sid IN (2,6);
update users set status='0' where sid=3 and gp_id=5;
update users set gp_id=gp_id+1,grade_id=(select grade_id from g_plans where id=gp_id limit 1) where gp_id IN(3,4) and sid=3;
update users set status='0' where sid=4 and gp_id=21;
update users set gp_id=gp_id+1,grade_id=(select grade_id from g_plans where id=gp_id limit 1) where sid=4 and gp_id between 14 and 20;
update users set status='0' where sid=5 and gp_id=31;
update users set gp_id=gp_id+1,grade_id=(select grade_id from g_plans where id=gp_id limit 1) where sid=5 and gp_id between 22 and 30;
update users set status='0' where sid=8 and gp_id=8;
update users set gp_id=gp_id+1,grade_id=(select grade_id from  g_plans where id=gp_id limit 1) where gp_id IN (6,7) and sid =8;
update users set status='0' where sid=9 and gp_id=37;
update users set gp_id=gp_id+1,grade_id=(select grade_id from  g_plans where id=gp_id limit 1) where sid=9 and gp_id between 32 and 36;
update users set gp_id=gp_id+1,grade_id=(select grade_id from  g_plans where id=gp_id limit 1) where gp_id IN(38,39) and sid=9;
update users set gp_id=32,grade_id=(select grade_id from  g_plans where id=1 limit 1) where gp_id=40 and sid =9;
update users set status='0' where sid=10 and gp_id=50;
update users set gp_id=gp_id+1,grade_id=(select grade_id from g_plans where id=gp_id limit 1) where sid=10 and gp_id between 41 and 49;
update users set status='0' where sid=11 and gp_id=60;
update users set gp_id=gp_id+1,grade_id=(select grade_id from g_plans where id=gp_id limit 1) where sid=11 and gp_id between 51 and 59;
COMMIT ;
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `academic_year`
--

CREATE TABLE `academic_year` (
  `id` int(11) NOT NULL,
  `academicyear` int(5) NOT NULL,
  `startdate` varchar(100) NOT NULL,
  `enddate` varchar(100) NOT NULL,
  `createdby` varchar(100) NOT NULL,
  `creation_date` date NOT NULL,
  `modifieby` varchar(100) NOT NULL,
  `modified_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `academic_year`
--

INSERT INTO `academic_year` (`id`, `academicyear`, `startdate`, `enddate`, `createdby`, `creation_date`, `modifieby`, `modified_date`) VALUES
(19, 0, '2016-06-01', '2017-05-31', '', '0000-00-00', '', '2017-06-05 22:43:05'),
(20, 0, '2019-04-01', '2020-03-31', '', '0000-00-00', '', '2019-04-11 06:48:58'),
(21, 0, '2017-06-01', '2018-05-31', '', '0000-00-00', '', '2018-04-28 01:20:03');

-- --------------------------------------------------------

--
-- Table structure for table `actual_class`
--

CREATE TABLE `actual_class` (
  `id` int(11) NOT NULL,
  `classname` varchar(100) NOT NULL,
  `stage` varchar(110) NOT NULL,
  `status` int(1) NOT NULL,
  `createdby` varchar(100) NOT NULL,
  `creation_date` date NOT NULL,
  `modifiedby` varchar(100) NOT NULL,
  `modified_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `actual_class`
--

INSERT INTO `actual_class` (`id`, `classname`, `stage`, `status`, `createdby`, `creation_date`, `modifiedby`, `modified_date`) VALUES
(1, 'Grade LKG', 'I', 1, '', '0000-00-00', '', '2019-04-05 11:48:35'),
(2, 'Grade UKG', 'II', 1, '', '0000-00-00', '', '2019-04-05 11:48:53'),
(3, 'Grade I', 'III', 1, '', '0000-00-00', '', '2019-04-05 11:48:53'),
(4, 'Grade II', 'IV', 1, '', '0000-00-00', '', '2019-04-05 11:48:53'),
(5, 'Grade III', 'V', 1, '', '0000-00-00', '', '2019-04-05 11:48:53'),
(6, 'Grade IV', 'VI', 1, '', '0000-00-00', '', '2019-04-05 11:48:53'),
(7, 'Grade V', 'VII', 1, '', '0000-00-00', '', '2019-04-05 11:48:53'),
(8, 'Grade VI', 'VIII', 1, '', '0000-00-00', '', '2019-04-05 11:48:53'),
(9, 'Grade VII', 'IX', 1, '', '0000-00-00', '', '2019-04-05 11:48:53'),
(10, 'Grade VIII', 'X', 1, '', '0000-00-00', '', '2019-04-06 05:08:01'),
(12, 'Grade IX', 'XI', 0, '', '0000-00-00', '', '2019-04-06 05:07:55'),
(13, 'Grade X', 'XII', 0, '', '0000-00-00', '', '2019-04-06 05:07:50'),
(14, 'Grade XI', 'XIII', 0, '', '0000-00-00', '', '2019-04-06 05:07:48'),
(15, 'Grade XII', 'XIV', 0, '', '0000-00-00', '', '2019-04-06 05:07:45');

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(10) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `fname` varchar(100) NOT NULL,
  `lname` varchar(100) NOT NULL,
  `mobile` int(12) NOT NULL,
  `level` int(10) NOT NULL,
  `role` varchar(20) NOT NULL,
  `academic_id` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `createdby` varchar(100) NOT NULL,
  `creation_date` date NOT NULL,
  `modifiedby` varchar(100) NOT NULL,
  `modified_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `email`, `password`, `fname`, `lname`, `mobile`, `level`, `role`, `academic_id`, `status`, `createdby`, `creation_date`, `modifiedby`, `modified_date`) VALUES
(1, 'admin@skillangels.com', 'ca9139d33a0a27a6bcf77910a32514be', 'SkillAngles', 'Admin', 2147483647, 1, 'SU', 20, 1, '', '0000-00-00', '', '2018-12-23 23:06:29'),
(2, 'sandhya', '827ccb0eea8a706c4c34a16891f84e7b', 'SkillAngles', 'Admin', 2147483647, 1, '', 0, 0, '', '0000-00-00', '', '2018-03-26 21:58:22'),
(3, 'vidyalaya@skillangels.com', '3f19af718d9d5c238a4d2d208a326d90', 'SkillAngles', 'Admin', 2147483647, 1, 'SC', 20, 1, '', '0000-00-00', '', '2018-12-31 02:04:21');

-- --------------------------------------------------------

--
-- Table structure for table `admin_login_log`
--

CREATE TABLE `admin_login_log` (
  `ID` int(11) NOT NULL,
  `adminid` int(11) NOT NULL,
  `sessionid` varchar(255) NOT NULL,
  `created_date` datetime NOT NULL,
  `lastupdate` datetime NOT NULL,
  `logout_date` datetime NOT NULL,
  `ip` varchar(50) NOT NULL,
  `country` varchar(800) NOT NULL,
  `region` varchar(800) NOT NULL,
  `city` varchar(800) NOT NULL,
  `browser` text NOT NULL,
  `isp` text NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `android_games`
--

CREATE TABLE `android_games` (
  `id` int(100) NOT NULL,
  `gname` varchar(100) NOT NULL,
  `img_path` varchar(100) NOT NULL,
  `gpath` varchar(100) NOT NULL,
  `createdby` varchar(100) NOT NULL,
  `creation_date` date NOT NULL,
  `modifiedby` varchar(100) NOT NULL,
  `modified_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `asap_gamescore`
--

CREATE TABLE `asap_gamescore` (
  `id` int(11) NOT NULL,
  `gu_id` int(10) NOT NULL,
  `stage_id` int(11) NOT NULL,
  `gs_id` int(10) NOT NULL,
  `g_id` int(30) NOT NULL,
  `que_id` int(11) NOT NULL,
  `answer` varchar(20) NOT NULL,
  `useranswer` varchar(55) NOT NULL,
  `game_score` varchar(50) NOT NULL,
  `answer_status` varchar(55) NOT NULL,
  `timeoverstatus` int(11) NOT NULL,
  `responsetime` int(11) NOT NULL,
  `balancetime` int(11) NOT NULL,
  `lastupdate` date NOT NULL,
  `creation_date` date NOT NULL,
  `modified_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `puzzle_cycle` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `asap_game_reports`
--

CREATE TABLE `asap_game_reports` (
  `id` int(11) NOT NULL,
  `gu_id` int(10) NOT NULL,
  `gs_id` int(10) NOT NULL,
  `stage_id` int(11) NOT NULL COMMENT 'Stage ID',
  `g_id` int(30) NOT NULL,
  `total_question` varchar(15) NOT NULL,
  `attempt_question` varchar(20) NOT NULL,
  `answer` varchar(20) NOT NULL,
  `game_score` varchar(50) NOT NULL,
  `gtime` varchar(100) NOT NULL,
  `rtime` varchar(100) NOT NULL,
  `crtime` varchar(100) NOT NULL,
  `wrtime` varchar(100) NOT NULL,
  `lastupdate` date NOT NULL,
  `createdby` varchar(100) NOT NULL,
  `creation_date` date NOT NULL,
  `modifiedby` varchar(100) NOT NULL,
  `modified_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `portal_type` enum('ASAP1','ASAP2') NOT NULL,
  `session_id` int(11) NOT NULL,
  `puzzle_cycle` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `asap_rand_selection`
--

CREATE TABLE `asap_rand_selection` (
  `id` int(11) NOT NULL,
  `sid` int(11) NOT NULL,
  `grade_id` int(11) NOT NULL,
  `stage_id` int(11) NOT NULL,
  `gs_id` int(11) NOT NULL,
  `gid` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `created_on` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `asap_rand_selection`
--

INSERT INTO `asap_rand_selection` (`id`, `sid`, `grade_id`, `stage_id`, `gs_id`, `gid`, `status`, `created_on`) VALUES
(1, 2, 0, 3, 59, 1121, 1, '2019-08-12 15:15:39'),
(2, 2, 0, 3, 60, 1202, 1, '2019-08-12 15:15:39'),
(3, 2, 0, 3, 61, 1123, 1, '2019-08-12 15:15:39'),
(4, 2, 0, 3, 62, 1124, 1, '2019-08-12 15:15:39'),
(5, 2, 0, 3, 63, 1205, 1, '2019-08-12 15:15:39'),
(6, 2, 0, 4, 59, 1046, 1, '2019-08-12 15:15:39'),
(7, 2, 0, 4, 60, 1087, 1, '2019-08-12 15:15:39'),
(8, 2, 0, 4, 61, 1088, 1, '2019-08-12 15:15:39'),
(9, 2, 0, 4, 62, 1049, 1, '2019-08-12 15:15:39'),
(10, 2, 0, 4, 63, 1090, 1, '2019-08-12 15:15:39'),
(11, 2, 0, 5, 59, 1211, 1, '2019-08-12 15:15:39'),
(12, 2, 0, 5, 60, 1172, 1, '2019-08-12 15:15:39'),
(13, 2, 0, 5, 61, 1133, 1, '2019-08-12 15:15:39'),
(14, 2, 0, 5, 62, 1214, 1, '2019-08-12 15:15:39'),
(15, 2, 0, 5, 63, 1135, 1, '2019-08-12 15:15:39'),
(16, 2, 0, 6, 59, 1176, 1, '2019-08-12 15:15:39'),
(17, 2, 0, 6, 60, 1177, 1, '2019-08-12 15:15:39'),
(18, 2, 0, 6, 61, 1178, 1, '2019-08-12 15:15:39'),
(19, 2, 0, 6, 62, 1179, 1, '2019-08-12 15:15:39'),
(20, 2, 0, 6, 63, 1140, 1, '2019-08-12 15:15:39'),
(21, 2, 0, 7, 59, 1141, 1, '2019-08-12 15:15:39'),
(22, 2, 0, 7, 60, 1142, 1, '2019-08-12 15:15:39'),
(23, 2, 0, 7, 61, 1183, 1, '2019-08-12 15:15:39'),
(24, 2, 0, 7, 62, 1104, 1, '2019-08-12 15:15:39'),
(25, 2, 0, 7, 63, 1065, 1, '2019-08-12 15:15:39'),
(26, 2, 0, 8, 59, 1226, 1, '2019-08-12 15:15:39'),
(27, 2, 0, 8, 60, 1187, 1, '2019-08-12 15:15:39'),
(28, 2, 0, 8, 61, 1148, 1, '2019-08-12 15:15:39'),
(29, 2, 0, 8, 62, 1189, 1, '2019-08-12 15:15:39'),
(30, 2, 0, 8, 63, 1305, 1, '2019-08-12 15:15:39'),
(31, 2, 0, 9, 59, 1191, 1, '2019-08-12 15:15:39'),
(32, 2, 0, 9, 60, 1192, 1, '2019-08-12 15:15:39'),
(33, 2, 0, 9, 61, 1153, 1, '2019-08-12 15:15:39'),
(34, 2, 0, 9, 62, 1154, 1, '2019-08-12 15:15:39'),
(35, 2, 0, 9, 63, 1155, 1, '2019-08-12 15:15:39'),
(36, 2, 0, 10, 59, 1276, 1, '2019-08-12 15:15:39'),
(37, 2, 0, 10, 60, 1032, 1, '2019-08-12 15:15:39'),
(38, 2, 0, 10, 61, 1198, 1, '2019-08-12 15:15:39'),
(39, 2, 0, 10, 62, 1119, 1, '2019-08-12 15:15:39'),
(40, 2, 0, 10, 63, 1240, 1, '2019-08-12 15:15:39'),
(41, 2, 0, 14, 59, 1031, 1, '2019-08-12 15:15:39'),
(42, 2, 0, 14, 60, 1072, 1, '2019-08-12 15:15:39'),
(43, 2, 0, 14, 61, 1033, 1, '2019-08-12 15:15:39'),
(44, 2, 0, 14, 62, 1034, 1, '2019-08-12 15:15:39'),
(45, 2, 0, 14, 63, 1035, 1, '2019-08-12 15:15:39'),
(46, 2, 0, 13, 59, 1340, 1, '2019-08-12 15:15:39'),
(47, 2, 0, 13, 60, 1341, 1, '2019-08-12 15:15:39'),
(49, 2, 0, 13, 61, 1342, 1, '2019-08-12 15:15:39'),
(50, 2, 0, 13, 62, 1343, 1, '2019-08-12 15:15:39'),
(51, 2, 0, 13, 63, 1344, 1, '2019-08-12 15:15:39'),
(52, 2, 0, 12, 59, 1336, 1, '2019-08-12 15:15:39'),
(53, 2, 0, 12, 60, 1337, 1, '2019-08-12 15:15:39'),
(54, 2, 0, 12, 61, 1118, 1, '2019-08-12 15:15:39'),
(55, 2, 0, 12, 62, 1338, 1, '2019-08-12 15:15:39'),
(56, 2, 0, 12, 63, 1339, 1, '2019-08-12 15:15:39'),
(57, 2, 0, 15, 59, 1076, 1, '2019-08-12 15:15:39'),
(58, 2, 0, 15, 60, 1037, 1, '2019-08-12 15:15:39'),
(59, 2, 0, 15, 61, 1078, 1, '2019-08-12 15:15:39'),
(60, 2, 0, 15, 62, 1079, 1, '2019-08-12 15:15:39'),
(61, 2, 0, 15, 63, 1040, 1, '2019-08-12 15:15:39');

-- --------------------------------------------------------

--
-- Table structure for table `asap_userscore`
--

CREATE TABLE `asap_userscore` (
  `autoid` int(11) NOT NULL,
  `id` int(11) NOT NULL,
  `fname` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `gp_id` int(11) NOT NULL,
  `section` varchar(16) NOT NULL,
  `grade_id` int(11) NOT NULL,
  `sid` int(11) NOT NULL,
  `M1` varchar(55) NOT NULL,
  `VP1` varchar(55) NOT NULL,
  `FA1` varchar(55) NOT NULL,
  `PS1` varchar(55) NOT NULL,
  `LI1` varchar(55) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `bandwidth_config`
--

CREATE TABLE `bandwidth_config` (
  `ID` int(11) NOT NULL,
  `TimeInterval` int(11) NOT NULL,
  `Status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bandwidth_config`
--

INSERT INTO `bandwidth_config` (`ID`, `TimeInterval`, `Status`) VALUES
(1, 10, 1);

-- --------------------------------------------------------

--
-- Table structure for table `bandwidth_log`
--

CREATE TABLE `bandwidth_log` (
  `ID` int(11) NOT NULL,
  `school_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `bandwidth_bps` varchar(110) NOT NULL,
  `bandwidth_kbps` varchar(110) NOT NULL,
  `bandwidth_mbps` varchar(110) NOT NULL,
  `status` int(11) NOT NULL,
  `updatedtime` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `braintest_games`
--

CREATE TABLE `braintest_games` (
  `gid` int(100) NOT NULL,
  `gc_id` int(100) NOT NULL,
  `gs_id` int(100) NOT NULL,
  `gname` varchar(100) NOT NULL,
  `path` varchar(500) NOT NULL,
  `descs` varchar(500) NOT NULL,
  `img_path` varchar(100) NOT NULL,
  `gstatus` int(1) NOT NULL,
  `gplans` varchar(100) NOT NULL,
  `createdby` varchar(100) NOT NULL,
  `creation_date` date NOT NULL,
  `modifiedby` varchar(100) NOT NULL,
  `modified_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `game_html` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `braintest_games`
--

INSERT INTO `braintest_games` (`gid`, `gc_id`, `gs_id`, `gname`, `path`, `descs`, `img_path`, `gstatus`, `gplans`, `createdby`, `creation_date`, `modifiedby`, `modified_date`, `game_html`) VALUES
(1, 1, 59, 'AlphaNumericEncode-Level1', 'uploads/AlphaNumericEncode-Level1_4518458847.swf', 'Memory', 'uploads/AlphaNumericEncode-Level1_4518458847.png', 1, '', '', '2014-06-17', '', '2016-12-07 19:39:20', 'AlphaNumericEncode-Level1'),
(2, 1, 59, 'BusRide-Level1', 'uploads/BusRide-Level1_9721776302.swf', 'Memory', 'uploads/BusRide-Level1_9721776302.png', 1, '', '', '2014-06-17', '', '2018-08-20 03:58:32', 'BusRide-Level1'),
(3, 1, 59, 'CycleRace-Level1', 'uploads/CycleRace-Level1_2532993447.swf', 'Memory', 'uploads/CycleRace-Level1_2532993447.png', 1, '', '', '2014-06-17', '', '2018-08-20 03:58:37', 'CycleRace-Level1'),
(4, 1, 59, 'MemoryCheck-Level1', 'uploads/MemoryCheck-Level1_1938757994.swf', 'Memory', 'uploads/MemoryCheck-Level1_1938757994.png', 1, '', '', '2014-06-17', '', '2018-08-20 03:58:40', 'MemoryCheck-Level1'),
(5, 1, 59, 'MindCapture-Level1', 'uploads/MindCapture-Level1_9870321140.swf', 'Memory', 'uploads/MindCapture-Level1_9870321140.png', 1, '', '', '2014-06-17', '', '2018-08-20 03:58:43', 'MindCapture-Level1'),
(6, 1, 59, 'MomAndMe', 'uploads/MomAndMe_6942562656.swf', 'Memory', 'uploads/MomAndMe_6942562656.png', 1, '', '', '2014-06-17', '', '2018-08-20 03:58:46', 'MomAndMe'),
(7, 1, 59, 'SequenceMemory-Level1', 'uploads/SequenceMemory-Level1_903124888.swf', 'Memory', 'uploads/SequenceMemory-Level1_903124888.png', 1, '', '', '2014-06-17', '', '2018-08-20 03:58:49', 'SequenceMemory-Level1'),
(8, 1, 60, 'BestFit-Level3', 'uploads/BestFit-Level2_6896948479.swf', 'VP', 'uploads/BestFit-Level2_6896948479.png', 1, '', '', '2014-06-17', '', '2018-08-20 03:58:51', 'BestFit-Level3');

-- --------------------------------------------------------

--
-- Table structure for table `braintest_mapping`
--

CREATE TABLE `braintest_mapping` (
  `id` int(11) NOT NULL,
  `sid` int(11) NOT NULL,
  `gradeid` int(11) NOT NULL,
  `gameid` int(11) NOT NULL,
  `startdate` date NOT NULL,
  `enddate` date NOT NULL,
  `level` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `created_date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `braintest_mapping`
--

INSERT INTO `braintest_mapping` (`id`, `sid`, `gradeid`, `gameid`, `startdate`, `enddate`, `level`, `status`, `created_date`) VALUES
(1, 2, 8, 1, '2018-10-01', '2018-11-09', 1, 1, '0000-00-00 00:00:00'),
(2, 2, 9, 2, '2018-10-01', '2018-11-09', 1, 1, '0000-00-00 00:00:00'),
(3, 2, 10, 3, '2018-10-01', '2018-11-09', 1, 1, '0000-00-00 00:00:00'),
(4, 2, 12, 4, '2018-10-01', '2018-11-09', 1, 1, '0000-00-00 00:00:00'),
(5, 2, 13, 5, '2018-10-01', '2018-11-09', 1, 1, '0000-00-00 00:00:00'),
(6, 2, 14, 6, '2018-10-01', '2018-11-09', 1, 1, '0000-00-00 00:00:00'),
(7, 2, 15, 7, '2018-10-01', '2018-11-09', 1, 1, '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `bt_gamedata`
--

CREATE TABLE `bt_gamedata` (
  `id` int(11) NOT NULL,
  `gu_id` int(10) NOT NULL,
  `gc_id` int(10) NOT NULL,
  `gs_id` int(10) NOT NULL,
  `gp_id` int(100) NOT NULL,
  `g_id` int(30) NOT NULL,
  `total_question` varchar(15) NOT NULL,
  `attempt_question` varchar(20) NOT NULL,
  `answer` varchar(20) NOT NULL,
  `game_score` varchar(50) NOT NULL,
  `gtime` varchar(100) NOT NULL,
  `rtime` varchar(100) NOT NULL,
  `crtime` varchar(100) NOT NULL,
  `wrtime` varchar(100) NOT NULL,
  `lastupdate` date NOT NULL,
  `createdby` varchar(100) NOT NULL,
  `creation_date` date NOT NULL,
  `modifiedby` varchar(100) NOT NULL,
  `modified_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `BT_LEVEL` int(11) NOT NULL,
  `languageID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bt_gamedata`
--

INSERT INTO `bt_gamedata` (`id`, `gu_id`, `gc_id`, `gs_id`, `gp_id`, `g_id`, `total_question`, `attempt_question`, `answer`, `game_score`, `gtime`, `rtime`, `crtime`, `wrtime`, `lastupdate`, `createdby`, `creation_date`, `modifiedby`, `modified_date`, `BT_LEVEL`, `languageID`) VALUES
(409, 38332, 1, 0, 6, 0, '6 ', '6', '3', '30', '1788', '8', '4', '0', '2018-10-29', '', '0000-00-00', '', '2018-10-29 02:09:57', 1, 0),
(883, 38336, 1, 0, 8, 0, '8 ', '8', '4', '40', '1788', '9', '2', '0', '2018-10-29', '', '0000-00-00', '', '2018-10-29 09:02:59', 1, 0),
(1879, 38334, 1, 0, 7, 0, '7 ', '7', '1', '10', '1787', '8', '0', '2', '2018-11-01', '', '0000-00-00', '', '2018-10-31 22:33:36', 1, 103);

-- --------------------------------------------------------

--
-- Table structure for table `bt_languages`
--

CREATE TABLE `bt_languages` (
  `ID` int(11) NOT NULL,
  `name` varchar(400) NOT NULL,
  `status` enum('Y','N') NOT NULL,
  `language_key` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bt_languages`
--

INSERT INTO `bt_languages` (`ID`, `name`, `status`, `language_key`) VALUES
(101, 'English', 'Y', 'english'),
(102, 'Tamil', 'Y', 'tamil'),
(103, 'Hindi', 'Y', 'Hindi'),
(104, 'Gujarathi', 'Y', 'Gujarathi');

-- --------------------------------------------------------

--
-- Table structure for table `category_skills`
--

CREATE TABLE `category_skills` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `icon` varchar(250) NOT NULL,
  `description` text NOT NULL,
  `category_id` int(11) NOT NULL,
  `status` int(1) NOT NULL,
  `colorcode` varchar(100) NOT NULL,
  `createdby` varchar(100) NOT NULL,
  `creation_date` date NOT NULL,
  `modifiedby` varchar(100) NOT NULL,
  `modified_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `category_skills`
--

INSERT INTO `category_skills` (`id`, `name`, `icon`, `description`, `category_id`, `status`, `colorcode`, `createdby`, `creation_date`, `modifiedby`, `modified_date`) VALUES
(1, 'Memory', '', 'Memory', 1, 1, '#e81919', '', '2019-04-05', '', '2019-04-08 14:28:37'),
(2, 'Visual Processing', '', 'Visual Motor Coordination\r\nVisual Motor Perception\r\nVisual Matching', 1, 1, '#f16202', '', '2019-04-05', '', '2019-04-08 14:28:54'),
(3, 'Classification', '', 'Sorting and Numbering\r\nPerceptual Contancy', 1, 1, '#8bcc46', '', '2019-04-05', '', '2019-04-08 14:29:02'),
(59, 'Memory', '1403077986Memory.png', 'Memory Skill', 2, 1, '#da0404', '', '0000-00-00', '', '2019-04-10 07:23:01'),
(60, 'Visual Processing', '1403077998VisualProcessing.png', 'Visual Processing', 2, 1, '#ffc000', '', '0000-00-00', '', '2019-04-10 07:23:03'),
(61, 'Focus & Attention', '1403078012Focus_Attention.png', 'Focus & Attention', 2, 1, '#92d050', '', '0000-00-00', '', '2019-04-10 07:23:05'),
(62, 'Problem Solving', '1403078026ProblemSolving.png', 'Problem Solving', 2, 1, '#ff6600', '', '0000-00-00', '', '2019-04-10 07:23:07'),
(63, 'Linguistics', '1403078039Linguistics.png', 'Linguistics', 2, 1, '#00b0f0', '', '0000-00-00', '', '2019-04-10 07:23:09'),
(69, 'Maths', '1402513038Icon.png', '', 3, 0, '', '', '0000-00-00', '', '2019-04-05 12:15:01'),
(70, 'Life Skills', '1402513057Icon.png', '', 6, 0, '', '', '0000-00-00', '', '2014-06-11 13:27:37');

-- --------------------------------------------------------

--
-- Table structure for table `class`
--

CREATE TABLE `class` (
  `id` int(11) NOT NULL,
  `classname` varchar(100) NOT NULL,
  `stage` varchar(110) NOT NULL,
  `status` int(1) NOT NULL,
  `createdby` varchar(100) NOT NULL,
  `creation_date` date NOT NULL,
  `modifiedby` varchar(100) NOT NULL,
  `modified_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `class`
--

INSERT INTO `class` (`id`, `classname`, `stage`, `status`, `createdby`, `creation_date`, `modifiedby`, `modified_date`) VALUES
(1, 'Grade LKG', 'I', 1, '', '0000-00-00', '', '2019-04-05 11:48:35'),
(2, 'Grade UKG', 'II', 1, '', '0000-00-00', '', '2019-04-05 11:48:53'),
(3, 'Grade I', 'III', 1, '', '0000-00-00', '', '2019-04-05 11:48:53'),
(4, 'Grade II', 'IV', 1, '', '0000-00-00', '', '2019-04-05 11:48:53'),
(5, 'Grade III', 'V', 1, '', '0000-00-00', '', '2019-04-05 11:48:53'),
(6, 'Grade IV', 'VI', 1, '', '0000-00-00', '', '2019-04-05 11:48:53'),
(7, 'Grade V', 'VII', 1, '', '0000-00-00', '', '2019-04-05 11:48:53'),
(8, 'Grade VI', 'VIII', 1, '', '0000-00-00', '', '2019-04-05 11:48:53'),
(9, 'Grade VII', 'IX', 1, '', '0000-00-00', '', '2019-04-05 11:48:53'),
(10, 'Grade VIII', 'X', 1, '', '0000-00-00', '', '2019-04-06 05:08:01'),
(11, 'Grade PreKG', 'prekg', 1, '', '0000-00-00', '', '2019-04-06 05:08:01'),
(12, 'Grade IX', 'XI', 0, '', '0000-00-00', '', '2019-04-06 05:07:55'),
(13, 'Grade X', 'XII', 0, '', '0000-00-00', '', '2019-04-06 05:07:50'),
(14, 'Grade XI', 'XIII', 0, '', '0000-00-00', '', '2019-04-06 05:07:48'),
(15, 'Grade XII', 'XIV', 0, '', '0000-00-00', '', '2019-04-06 05:07:45');

-- --------------------------------------------------------

--
-- Table structure for table `class_plan_game`
--

CREATE TABLE `class_plan_game` (
  `id` int(11) NOT NULL,
  `class_id` int(11) NOT NULL,
  `plan_id` int(11) NOT NULL,
  `skill_id` int(11) NOT NULL,
  `game_id` int(11) NOT NULL,
  `status` int(1) NOT NULL,
  `createdby` varchar(100) NOT NULL,
  `creation_date` date NOT NULL,
  `modifiedby` varchar(100) NOT NULL,
  `modified_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `complexity_level` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `class_plan_game`
--

INSERT INTO `class_plan_game` (`id`, `class_id`, `plan_id`, `skill_id`, `game_id`, `status`, `createdby`, `creation_date`, `modifiedby`, `modified_date`, `complexity_level`) VALUES
(1, 3, 1, 59, 1001, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 1),
(2, 3, 1, 60, 1002, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 1),
(3, 3, 1, 61, 1003, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 1),
(4, 3, 1, 62, 1004, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 1),
(5, 3, 1, 63, 1005, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 1),
(6, 4, 2, 59, 1006, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 1),
(7, 4, 2, 60, 1007, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 1),
(8, 4, 2, 61, 1008, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 1),
(9, 4, 2, 62, 1009, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 1),
(10, 4, 2, 63, 1010, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 1),
(11, 5, 3, 59, 1011, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 1),
(12, 5, 3, 60, 1012, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 1),
(13, 5, 3, 61, 1013, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 1),
(14, 5, 3, 62, 1014, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 1),
(15, 5, 3, 63, 1015, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 1),
(16, 6, 4, 59, 1016, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 1),
(17, 6, 4, 60, 1017, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 1),
(18, 6, 4, 61, 1018, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 1),
(19, 6, 4, 62, 1019, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 1),
(20, 6, 4, 63, 1020, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 1),
(21, 7, 5, 59, 1021, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 1),
(22, 7, 5, 60, 1022, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 1),
(23, 7, 5, 61, 1023, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 1),
(24, 7, 5, 62, 1024, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 1),
(25, 7, 5, 63, 1025, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 1),
(26, 8, 6, 59, 1026, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 1),
(27, 8, 6, 60, 1027, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 1),
(28, 8, 6, 61, 1028, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 1),
(29, 8, 6, 62, 1029, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 1),
(30, 8, 6, 63, 1030, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 1),
(31, 9, 7, 59, 1031, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 1),
(32, 9, 7, 60, 1032, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 1),
(33, 9, 7, 61, 1033, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 1),
(34, 9, 7, 62, 1034, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 1),
(35, 9, 7, 63, 1035, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 1),
(36, 10, 8, 59, 1036, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 1),
(37, 10, 8, 60, 1037, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 1),
(38, 10, 8, 61, 1038, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 1),
(39, 10, 8, 62, 1039, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 1),
(40, 10, 8, 63, 1040, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 1),
(41, 3, 1, 59, 1041, 1, '1', '2019-06-13', '1', '2019-06-14 14:06:59', 2),
(42, 3, 1, 60, 1042, 1, '1', '2019-06-13', '1', '2019-06-14 14:06:59', 2),
(43, 3, 1, 61, 1043, 1, '1', '2019-06-13', '1', '2019-06-14 14:06:59', 2),
(44, 3, 1, 62, 1044, 1, '1', '2019-06-13', '1', '2019-06-14 14:06:59', 2),
(45, 3, 1, 63, 1045, 1, '1', '2019-06-13', '1', '2019-06-14 14:06:59', 2),
(46, 4, 2, 59, 1046, 1, '1', '2019-06-13', '1', '2019-06-14 14:06:59', 2),
(47, 4, 2, 60, 1047, 1, '1', '2019-06-13', '1', '2019-06-14 14:06:59', 2),
(48, 4, 2, 61, 1048, 1, '1', '2019-06-13', '1', '2019-06-14 14:06:59', 2),
(49, 4, 2, 62, 1049, 1, '1', '2019-06-13', '1', '2019-06-14 14:06:59', 2),
(50, 4, 2, 63, 1050, 1, '1', '2019-06-13', '1', '2019-06-14 14:06:59', 2),
(51, 5, 3, 59, 1051, 1, '1', '2019-06-13', '1', '2019-06-14 14:06:59', 2),
(52, 5, 3, 60, 1052, 1, '1', '2019-06-13', '1', '2019-06-14 14:06:59', 2),
(53, 5, 3, 61, 1053, 1, '1', '2019-06-13', '1', '2019-06-14 14:06:59', 2),
(54, 5, 3, 62, 1054, 1, '1', '2019-06-13', '1', '2019-06-14 14:06:59', 2),
(55, 5, 3, 63, 1055, 1, '1', '2019-06-13', '1', '2019-06-14 14:06:59', 2),
(56, 6, 4, 59, 1056, 1, '1', '2019-06-13', '1', '2019-06-14 14:06:59', 2),
(57, 6, 4, 60, 1057, 1, '1', '2019-06-13', '1', '2019-06-14 14:06:59', 2),
(58, 6, 4, 61, 1058, 1, '1', '2019-06-13', '1', '2019-06-14 14:06:59', 2),
(59, 6, 4, 62, 1059, 1, '1', '2019-06-13', '1', '2019-06-14 14:06:59', 2),
(60, 6, 4, 63, 1060, 1, '1', '2019-06-13', '1', '2019-06-14 14:06:59', 2),
(61, 7, 5, 59, 1061, 1, '1', '2019-06-13', '1', '2019-06-14 14:06:59', 2),
(62, 7, 5, 60, 1062, 1, '1', '2019-06-13', '1', '2019-06-14 14:06:59', 2),
(63, 7, 5, 61, 1063, 1, '1', '2019-06-13', '1', '2019-06-14 14:06:59', 2),
(64, 7, 5, 62, 1064, 1, '1', '2019-06-13', '1', '2019-06-14 14:06:59', 2),
(65, 7, 5, 63, 1065, 1, '1', '2019-06-13', '1', '2019-06-14 14:06:59', 2),
(66, 8, 6, 59, 1066, 1, '1', '2019-06-13', '1', '2019-06-14 14:06:59', 2),
(67, 8, 6, 60, 1067, 1, '1', '2019-06-13', '1', '2019-06-14 14:06:59', 2),
(68, 8, 6, 61, 1068, 1, '1', '2019-06-13', '1', '2019-06-14 14:06:59', 2),
(69, 8, 6, 62, 1069, 1, '1', '2019-06-13', '1', '2019-06-14 14:06:59', 2),
(70, 8, 6, 63, 1070, 1, '1', '2019-06-13', '1', '2019-06-14 14:06:59', 2),
(71, 9, 7, 59, 1071, 1, '1', '2019-06-13', '1', '2019-06-14 14:06:59', 2),
(72, 9, 7, 60, 1072, 1, '1', '2019-06-13', '1', '2019-06-14 14:06:59', 2),
(73, 9, 7, 61, 1073, 1, '1', '2019-06-13', '1', '2019-06-14 14:06:59', 2),
(74, 9, 7, 62, 1074, 1, '1', '2019-06-13', '1', '2019-06-14 14:06:59', 2),
(75, 9, 7, 63, 1075, 1, '1', '2019-06-13', '1', '2019-06-14 14:06:59', 2),
(76, 10, 8, 59, 1076, 1, '1', '2019-06-13', '1', '2019-06-14 14:06:59', 2),
(77, 10, 8, 60, 1077, 1, '1', '2019-06-13', '1', '2019-06-14 14:06:59', 2),
(78, 10, 8, 61, 1078, 1, '1', '2019-06-13', '1', '2019-06-14 14:06:59', 2),
(79, 10, 8, 62, 1079, 1, '1', '2019-06-13', '1', '2019-06-14 14:06:59', 2),
(80, 10, 8, 63, 1080, 1, '1', '2019-06-13', '1', '2019-06-14 14:06:59', 2),
(81, 3, 1, 59, 1081, 1, '1', '2019-06-13', '1', '2019-06-14 14:07:11', 3),
(82, 3, 1, 60, 1082, 1, '1', '2019-06-13', '1', '2019-06-14 14:07:11', 3),
(83, 3, 1, 61, 1083, 1, '1', '2019-06-13', '1', '2019-06-14 14:07:11', 3),
(84, 3, 1, 62, 1084, 1, '1', '2019-06-13', '1', '2019-06-14 14:07:11', 3),
(85, 3, 1, 63, 1085, 1, '1', '2019-06-13', '1', '2019-06-14 14:07:11', 3),
(86, 4, 2, 59, 1086, 1, '1', '2019-06-13', '1', '2019-06-14 14:07:11', 3),
(87, 4, 2, 60, 1087, 1, '1', '2019-06-13', '1', '2019-06-14 14:07:11', 3),
(88, 4, 2, 61, 1088, 1, '1', '2019-06-13', '1', '2019-06-14 14:07:11', 3),
(89, 4, 2, 62, 1089, 1, '1', '2019-06-13', '1', '2019-06-14 14:07:11', 3),
(90, 4, 2, 63, 1090, 1, '1', '2019-06-13', '1', '2019-06-14 14:07:11', 3),
(91, 5, 3, 59, 1091, 1, '1', '2019-06-13', '1', '2019-06-14 14:07:11', 3),
(92, 5, 3, 60, 1092, 1, '1', '2019-06-13', '1', '2019-06-14 14:07:11', 3),
(93, 5, 3, 61, 1093, 1, '1', '2019-06-13', '1', '2019-06-14 14:07:11', 3),
(94, 5, 3, 62, 1094, 1, '1', '2019-06-13', '1', '2019-06-14 14:07:11', 3),
(95, 5, 3, 63, 1095, 1, '1', '2019-06-13', '1', '2019-06-14 14:07:11', 3),
(96, 6, 4, 59, 1096, 1, '1', '2019-06-13', '1', '2019-06-14 14:07:11', 3),
(97, 6, 4, 60, 1097, 1, '1', '2019-06-13', '1', '2019-06-14 14:07:11', 3),
(98, 6, 4, 61, 1098, 1, '1', '2019-06-13', '1', '2019-06-14 14:07:11', 3),
(99, 6, 4, 62, 1099, 1, '1', '2019-06-13', '1', '2019-06-14 14:07:11', 3),
(100, 6, 4, 63, 1100, 1, '1', '2019-06-13', '1', '2019-06-14 14:07:11', 3),
(101, 7, 5, 59, 1101, 1, '1', '2019-06-13', '1', '2019-06-14 14:07:11', 3),
(102, 7, 5, 60, 1102, 1, '1', '2019-06-13', '1', '2019-06-14 14:07:11', 3),
(103, 7, 5, 61, 1103, 1, '1', '2019-06-13', '1', '2019-06-14 14:07:11', 3),
(104, 7, 5, 62, 1104, 1, '1', '2019-06-13', '1', '2019-06-14 14:07:11', 3),
(105, 7, 5, 63, 1105, 1, '1', '2019-06-13', '1', '2019-06-14 14:07:11', 3),
(106, 8, 6, 59, 1106, 1, '1', '2019-06-13', '1', '2019-06-14 14:07:11', 3),
(107, 8, 6, 60, 1107, 1, '1', '2019-06-13', '1', '2019-06-14 14:07:11', 3),
(108, 8, 6, 61, 1108, 1, '1', '2019-06-13', '1', '2019-06-14 14:07:11', 3),
(109, 8, 6, 62, 1109, 1, '1', '2019-06-13', '1', '2019-06-14 14:07:11', 3),
(110, 8, 6, 63, 1110, 1, '1', '2019-06-13', '1', '2019-06-14 14:07:11', 3),
(111, 9, 7, 59, 1111, 1, '1', '2019-06-13', '1', '2019-06-14 14:07:11', 3),
(112, 9, 7, 60, 1112, 1, '1', '2019-06-13', '1', '2019-06-14 14:07:11', 3),
(113, 9, 7, 61, 1113, 1, '1', '2019-06-13', '1', '2019-06-14 14:07:11', 3),
(114, 9, 7, 62, 1114, 1, '1', '2019-06-13', '1', '2019-06-14 14:07:11', 3),
(115, 9, 7, 63, 1115, 1, '1', '2019-06-13', '1', '2019-06-14 14:07:11', 3),
(116, 10, 8, 59, 1116, 1, '1', '2019-06-13', '1', '2019-06-14 14:07:11', 3),
(117, 10, 8, 60, 1117, 1, '1', '2019-06-13', '1', '2019-06-14 14:07:11', 3),
(118, 10, 8, 61, 1118, 1, '1', '2019-06-13', '1', '2019-06-14 14:07:11', 3),
(119, 10, 8, 62, 1119, 1, '1', '2019-06-13', '1', '2019-06-14 14:07:11', 3),
(120, 10, 8, 63, 1120, 1, '1', '2019-06-13', '1', '2019-06-14 14:07:11', 3),
(128, 3, 1, 59, 1121, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 4),
(129, 3, 1, 60, 1122, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 4),
(130, 3, 1, 61, 1123, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 4),
(131, 3, 1, 62, 1124, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 4),
(132, 3, 1, 63, 1125, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 4),
(133, 4, 2, 59, 1126, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 4),
(134, 4, 2, 60, 1127, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 4),
(135, 4, 2, 61, 1128, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 4),
(136, 4, 2, 62, 1129, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 4),
(137, 4, 2, 63, 1130, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 4),
(138, 5, 3, 59, 1131, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 4),
(139, 5, 3, 60, 1132, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 4),
(140, 5, 3, 61, 1133, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 4),
(141, 5, 3, 62, 1134, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 4),
(142, 5, 3, 63, 1135, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 4),
(143, 6, 4, 59, 1136, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 4),
(144, 6, 4, 60, 1137, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 4),
(145, 6, 4, 61, 1138, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 4),
(146, 6, 4, 62, 1139, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 4),
(147, 6, 4, 63, 1140, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 4),
(148, 7, 5, 59, 1141, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 4),
(149, 7, 5, 60, 1142, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 4),
(150, 7, 5, 61, 1143, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 4),
(151, 7, 5, 62, 1144, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 4),
(152, 7, 5, 63, 1145, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 4),
(153, 8, 6, 59, 1146, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 4),
(154, 8, 6, 60, 1147, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 4),
(155, 8, 6, 61, 1148, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 4),
(156, 8, 6, 62, 1149, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 4),
(157, 8, 6, 63, 1150, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 4),
(158, 9, 7, 59, 1151, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 4),
(159, 9, 7, 60, 1152, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 4),
(160, 9, 7, 61, 1153, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 4),
(161, 9, 7, 62, 1154, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 4),
(162, 9, 7, 63, 1155, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 4),
(163, 10, 8, 59, 1156, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 4),
(164, 10, 8, 60, 1157, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 4),
(165, 10, 8, 61, 1158, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 4),
(166, 10, 8, 62, 1159, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 4),
(167, 10, 8, 63, 1160, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 4),
(191, 3, 1, 59, 1161, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 5),
(192, 3, 1, 60, 1162, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 5),
(193, 3, 1, 61, 1163, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 5),
(194, 3, 1, 62, 1164, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 5),
(195, 3, 1, 63, 1165, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 5),
(196, 4, 2, 59, 1166, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 5),
(197, 4, 2, 60, 1167, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 5),
(198, 4, 2, 61, 1168, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 5),
(199, 4, 2, 62, 1169, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 5),
(200, 4, 2, 63, 1170, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 5),
(201, 5, 3, 59, 1171, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 5),
(202, 5, 3, 60, 1172, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 5),
(203, 5, 3, 61, 1173, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 5),
(204, 5, 3, 62, 1174, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 5),
(205, 5, 3, 63, 1175, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 5),
(206, 6, 4, 59, 1176, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 5),
(207, 6, 4, 60, 1177, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 5),
(208, 6, 4, 61, 1178, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 5),
(209, 6, 4, 62, 1179, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 5),
(210, 6, 4, 63, 1180, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 5),
(211, 7, 5, 59, 1181, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 5),
(212, 7, 5, 60, 1182, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 5),
(213, 7, 5, 61, 1183, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 5),
(214, 7, 5, 62, 1184, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 5),
(215, 7, 5, 63, 1185, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 5),
(216, 8, 6, 59, 1186, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 5),
(217, 8, 6, 60, 1187, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 5),
(218, 8, 6, 61, 1188, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 5),
(219, 8, 6, 62, 1189, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 5),
(220, 8, 6, 63, 1190, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 5),
(221, 9, 7, 59, 1191, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 5),
(222, 9, 7, 60, 1192, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 5),
(223, 9, 7, 61, 1193, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 5),
(224, 9, 7, 62, 1194, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 5),
(225, 9, 7, 63, 1195, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 5),
(226, 10, 8, 59, 1196, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 5),
(227, 10, 8, 60, 1197, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 5),
(228, 10, 8, 61, 1198, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 5),
(229, 10, 8, 62, 1199, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 5),
(230, 10, 8, 63, 1200, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 5),
(378, 3, 1, 59, 1201, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 6),
(379, 3, 1, 60, 1202, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 6),
(380, 3, 1, 61, 1203, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 6),
(381, 3, 1, 62, 1204, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 6),
(382, 3, 1, 63, 1205, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 6),
(383, 4, 2, 59, 1206, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 6),
(384, 4, 2, 60, 1207, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 6),
(385, 4, 2, 61, 1208, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 6),
(386, 4, 2, 62, 1209, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 6),
(387, 4, 2, 63, 1210, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 6),
(388, 5, 3, 59, 1211, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 6),
(389, 5, 3, 60, 1212, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 6),
(390, 5, 3, 61, 1213, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 6),
(391, 5, 3, 62, 1214, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 6),
(392, 5, 3, 63, 1215, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 6),
(393, 6, 4, 59, 1216, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 6),
(394, 6, 4, 60, 1217, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 6),
(395, 6, 4, 61, 1218, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 6),
(396, 6, 4, 62, 1219, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 6),
(397, 6, 4, 63, 1220, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 6),
(398, 7, 5, 59, 1221, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 6),
(399, 7, 5, 60, 1222, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 6),
(400, 7, 5, 61, 1223, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 6),
(401, 7, 5, 62, 1224, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 6),
(402, 7, 5, 63, 1225, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 6),
(403, 8, 6, 59, 1226, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 6),
(404, 8, 6, 60, 1227, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 6),
(405, 8, 6, 61, 1228, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 6),
(406, 8, 6, 62, 1229, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 6),
(407, 8, 6, 63, 1230, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 6),
(408, 9, 7, 59, 1231, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 6),
(409, 9, 7, 60, 1232, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 6),
(410, 9, 7, 61, 1233, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 6),
(411, 9, 7, 62, 1234, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 6),
(412, 9, 7, 63, 1235, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 6),
(413, 10, 8, 59, 1236, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 6),
(414, 10, 8, 60, 1237, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 6),
(415, 10, 8, 61, 1238, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 6),
(416, 10, 8, 62, 1239, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 6),
(417, 10, 8, 63, 1240, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 6),
(441, 3, 1, 59, 1206, 1, '1', '2019-06-13', '1', '2019-06-21 13:41:23', 7),
(442, 3, 1, 60, 1242, 1, '1', '2019-06-13', '1', '2019-06-21 13:41:23', 7),
(443, 3, 1, 61, 1208, 1, '1', '2019-06-13', '1', '2019-06-21 13:41:23', 7),
(444, 3, 1, 62, 1169, 1, '1', '2019-06-13', '1', '2019-06-21 13:41:23', 7),
(445, 3, 1, 63, 1245, 1, '1', '2019-06-13', '1', '2019-06-21 13:41:23', 7),
(446, 4, 2, 59, 1246, 1, '1', '2019-06-13', '1', '2019-06-21 13:41:23', 7),
(447, 4, 2, 60, 1247, 1, '1', '2019-06-13', '1', '2019-06-21 13:41:23', 7),
(448, 4, 2, 61, 1248, 1, '1', '2019-06-13', '1', '2019-06-21 13:41:23', 7),
(449, 4, 2, 62, 1249, 1, '1', '2019-06-13', '1', '2019-06-21 13:41:23', 7),
(450, 4, 2, 63, 1250, 1, '1', '2019-06-13', '1', '2019-06-21 13:41:23', 7),
(451, 5, 3, 59, 1251, 1, '1', '2019-06-13', '1', '2019-06-21 13:41:23', 7),
(452, 5, 3, 60, 1252, 1, '1', '2019-06-13', '1', '2019-06-21 13:41:23', 7),
(453, 5, 3, 61, 1253, 1, '1', '2019-06-13', '1', '2019-06-21 13:41:23', 7),
(454, 5, 3, 62, 1254, 1, '1', '2019-06-13', '1', '2019-06-21 13:41:23', 7),
(455, 5, 3, 63, 1255, 1, '1', '2019-06-13', '1', '2019-06-21 13:41:23', 7),
(456, 6, 4, 59, 1256, 1, '1', '2019-06-13', '1', '2019-06-21 13:41:23', 7),
(457, 6, 4, 60, 1257, 1, '1', '2019-06-13', '1', '2019-06-21 13:41:23', 7),
(458, 6, 4, 61, 1258, 1, '1', '2019-06-13', '1', '2019-06-21 13:41:23', 7),
(459, 6, 4, 62, 1259, 1, '1', '2019-06-13', '1', '2019-06-21 13:41:23', 7),
(460, 6, 4, 63, 1260, 1, '1', '2019-06-13', '1', '2019-06-21 13:41:23', 7),
(461, 7, 5, 59, 1261, 1, '1', '2019-06-13', '1', '2019-06-21 13:41:23', 7),
(462, 7, 5, 60, 1262, 1, '1', '2019-06-13', '1', '2019-06-21 13:41:23', 7),
(463, 7, 5, 61, 1263, 1, '1', '2019-06-13', '1', '2019-06-21 13:41:23', 7),
(464, 7, 5, 62, 1264, 1, '1', '2019-06-13', '1', '2019-06-21 13:41:23', 7),
(465, 7, 5, 63, 1265, 1, '1', '2019-06-13', '1', '2019-06-21 13:41:23', 7),
(466, 8, 6, 59, 1266, 1, '1', '2019-06-13', '1', '2019-06-21 13:41:23', 7),
(467, 8, 6, 60, 1267, 1, '1', '2019-06-13', '1', '2019-06-21 13:41:23', 7),
(468, 8, 6, 61, 1268, 1, '1', '2019-06-13', '1', '2019-06-21 13:41:23', 7),
(469, 8, 6, 62, 1269, 1, '1', '2019-06-13', '1', '2019-06-21 13:41:23', 7),
(470, 8, 6, 63, 1270, 1, '1', '2019-06-13', '1', '2019-06-21 13:41:23', 7),
(471, 9, 7, 59, 1271, 1, '1', '2019-06-13', '1', '2019-06-21 13:41:23', 7),
(472, 9, 7, 60, 1272, 1, '1', '2019-06-13', '1', '2019-06-21 13:41:23', 7),
(473, 9, 7, 61, 1273, 1, '1', '2019-06-13', '1', '2019-06-21 13:41:23', 7),
(474, 9, 7, 62, 1274, 1, '1', '2019-06-13', '1', '2019-06-21 13:41:23', 7),
(475, 9, 7, 63, 1275, 1, '1', '2019-06-13', '1', '2019-06-21 13:41:23', 7),
(476, 10, 8, 59, 1276, 1, '1', '2019-06-13', '1', '2019-06-21 13:41:23', 7),
(477, 10, 8, 60, 1277, 1, '1', '2019-06-13', '1', '2019-06-21 13:41:23', 7),
(478, 10, 8, 61, 1278, 1, '1', '2019-06-13', '1', '2019-06-21 13:41:23', 7),
(479, 10, 8, 62, 1279, 1, '1', '2019-06-13', '1', '2019-06-21 13:41:23', 7),
(480, 10, 8, 63, 1280, 1, '1', '2019-06-13', '1', '2019-06-21 13:41:23', 7),
(481, 3, 1, 59, 1166, 1, '1', '2019-06-13', '1', '2019-06-21 13:41:23', 8),
(482, 3, 1, 60, 1282, 1, '1', '2019-06-13', '1', '2019-06-21 13:41:23', 8),
(483, 3, 1, 61, 1248, 1, '1', '2019-06-13', '1', '2019-06-21 13:41:23', 8),
(484, 3, 1, 62, 1209, 1, '1', '2019-06-13', '1', '2019-06-21 13:41:23', 8),
(485, 3, 1, 63, 1285, 1, '1', '2019-06-13', '1', '2019-06-21 13:41:23', 8),
(486, 4, 2, 59, 1286, 1, '1', '2019-06-13', '1', '2019-06-21 13:41:23', 8),
(487, 4, 2, 60, 1287, 1, '1', '2019-06-13', '1', '2019-06-21 13:41:23', 8),
(488, 4, 2, 61, 1288, 1, '1', '2019-06-13', '1', '2019-06-21 13:41:23', 8),
(489, 4, 2, 62, 1289, 1, '1', '2019-06-13', '1', '2019-06-21 13:41:23', 8),
(490, 4, 2, 63, 1290, 1, '1', '2019-06-13', '1', '2019-06-21 13:41:23', 8),
(491, 5, 3, 59, 1291, 1, '1', '2019-06-13', '1', '2019-06-21 13:41:23', 8),
(492, 5, 3, 60, 1292, 1, '1', '2019-06-13', '1', '2019-06-21 13:41:23', 8),
(493, 5, 3, 61, 1293, 1, '1', '2019-06-13', '1', '2019-06-21 13:41:23', 8),
(494, 5, 3, 62, 1294, 1, '1', '2019-06-13', '1', '2019-06-21 13:41:23', 8),
(495, 5, 3, 63, 1250, 1, '1', '2019-06-13', '1', '2019-06-21 13:41:23', 8),
(496, 6, 4, 59, 1296, 1, '1', '2019-06-13', '1', '2019-06-21 13:41:23', 8),
(497, 6, 4, 60, 1297, 1, '1', '2019-06-13', '1', '2019-06-21 13:41:23', 8),
(498, 6, 4, 61, 1298, 1, '1', '2019-06-13', '1', '2019-06-21 13:41:23', 8),
(499, 6, 4, 62, 1299, 1, '1', '2019-06-13', '1', '2019-06-21 13:41:23', 8),
(500, 6, 4, 63, 1300, 1, '1', '2019-06-13', '1', '2019-06-21 13:41:23', 8),
(501, 7, 5, 59, 1301, 1, '1', '2019-06-13', '1', '2019-06-21 13:41:23', 8),
(502, 7, 5, 60, 1302, 1, '1', '2019-06-13', '1', '2019-06-21 13:41:23', 8),
(503, 7, 5, 61, 1303, 1, '1', '2019-06-13', '1', '2019-06-21 13:41:23', 8),
(504, 7, 5, 62, 1029, 1, '1', '2019-06-13', '1', '2019-06-21 13:41:23', 8),
(505, 7, 5, 63, 1305, 1, '1', '2019-06-13', '1', '2019-06-21 13:41:23', 8),
(506, 8, 6, 59, 1306, 1, '1', '2019-06-13', '1', '2019-06-21 13:41:23', 8),
(507, 8, 6, 60, 1307, 1, '1', '2019-06-13', '1', '2019-06-21 13:41:23', 8),
(508, 8, 6, 61, 1308, 1, '1', '2019-06-13', '1', '2019-06-21 13:41:23', 8),
(509, 8, 6, 62, 1309, 1, '1', '2019-06-13', '1', '2019-06-21 13:41:23', 8),
(510, 8, 6, 63, 1310, 1, '1', '2019-06-13', '1', '2019-06-21 13:41:23', 8),
(511, 9, 7, 59, 1311, 1, '1', '2019-06-13', '1', '2019-06-21 13:41:23', 8),
(512, 9, 7, 60, 1312, 1, '1', '2019-06-13', '1', '2019-06-21 13:41:23', 8),
(513, 9, 7, 61, 1313, 1, '1', '2019-06-13', '1', '2019-06-21 13:41:23', 8),
(514, 9, 7, 62, 1314, 1, '1', '2019-06-13', '1', '2019-06-21 13:41:23', 8),
(515, 9, 7, 63, 1315, 1, '1', '2019-06-13', '1', '2019-06-21 13:41:23', 8),
(516, 10, 8, 59, 1316, 1, '1', '2019-06-13', '1', '2019-06-21 13:41:23', 8),
(517, 10, 8, 60, 1232, 1, '1', '2019-06-13', '1', '2019-06-21 13:41:23', 8),
(518, 10, 8, 61, 1318, 1, '1', '2019-06-13', '1', '2019-06-21 13:41:23', 8),
(519, 10, 8, 62, 1319, 1, '1', '2019-06-13', '1', '2019-06-21 13:41:23', 8),
(520, 10, 8, 63, 1320, 1, '1', '2019-06-13', '1', '2019-06-21 13:41:23', 8),
(1025, 12, 92, 59, 1026, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 1),
(1026, 12, 92, 60, 1027, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 1),
(1027, 12, 92, 61, 1028, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 1),
(1028, 12, 92, 62, 1029, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 1),
(1029, 12, 92, 63, 1030, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 1),
(1030, 12, 92, 59, 1066, 1, '1', '2019-06-13', '1', '2019-06-14 14:06:59', 2),
(1031, 12, 92, 60, 1067, 1, '1', '2019-06-13', '1', '2019-06-14 14:06:59', 2),
(1032, 12, 92, 61, 1068, 1, '1', '2019-06-13', '1', '2019-06-14 14:06:59', 2),
(1033, 12, 92, 62, 1069, 1, '1', '2019-06-13', '1', '2019-06-14 14:06:59', 2),
(1034, 12, 92, 63, 1070, 1, '1', '2019-06-13', '1', '2019-06-14 14:06:59', 2),
(1035, 12, 92, 59, 1106, 1, '1', '2019-06-13', '1', '2019-06-14 14:07:11', 3),
(1036, 12, 92, 60, 1107, 1, '1', '2019-06-13', '1', '2019-06-14 14:07:11', 3),
(1037, 12, 92, 61, 1108, 1, '1', '2019-06-13', '1', '2019-06-14 14:07:11', 3),
(1038, 12, 92, 62, 1109, 1, '1', '2019-06-13', '1', '2019-06-14 14:07:11', 3),
(1039, 12, 92, 63, 1110, 1, '1', '2019-06-13', '1', '2019-06-14 14:07:11', 3),
(1040, 12, 92, 59, 1146, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 4),
(1041, 12, 92, 60, 1147, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 4),
(1042, 12, 92, 61, 1148, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 4),
(1043, 12, 92, 62, 1149, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 4),
(1044, 12, 92, 63, 1150, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 4),
(1045, 12, 92, 59, 1186, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 5),
(1046, 12, 92, 60, 1187, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 5),
(1047, 12, 92, 61, 1188, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 5),
(1048, 12, 92, 62, 1189, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 5),
(1049, 12, 92, 63, 1190, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 5),
(1050, 12, 92, 59, 1226, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 6),
(1051, 12, 92, 60, 1227, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 6),
(1052, 12, 92, 61, 1228, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 6),
(1053, 12, 92, 62, 1229, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 6),
(1054, 12, 92, 63, 1230, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 6),
(1055, 12, 92, 59, 1266, 1, '1', '2019-06-13', '1', '2019-06-21 13:41:23', 7),
(1056, 12, 92, 60, 1267, 1, '1', '2019-06-13', '1', '2019-06-21 13:41:23', 7),
(1057, 12, 92, 61, 1268, 1, '1', '2019-06-13', '1', '2019-06-21 13:41:23', 7),
(1058, 12, 92, 62, 1269, 1, '1', '2019-06-13', '1', '2019-06-21 13:41:23', 7),
(1059, 12, 92, 63, 1270, 1, '1', '2019-06-13', '1', '2019-06-21 13:41:23', 7),
(1060, 12, 92, 59, 1306, 1, '1', '2019-06-13', '1', '2019-06-21 13:41:23', 8),
(1061, 12, 92, 60, 1307, 1, '1', '2019-06-13', '1', '2019-06-21 13:41:23', 8),
(1062, 12, 92, 61, 1308, 1, '1', '2019-06-13', '1', '2019-06-21 13:41:23', 8),
(1063, 12, 92, 62, 1309, 1, '1', '2019-06-13', '1', '2019-06-21 13:41:23', 8),
(1064, 12, 92, 63, 1310, 1, '1', '2019-06-13', '1', '2019-06-21 13:41:23', 8),
(1088, 13, 93, 59, 1031, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 1),
(1089, 13, 93, 60, 1032, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 1),
(1090, 13, 93, 61, 1033, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 1),
(1091, 13, 93, 62, 1034, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 1),
(1092, 13, 93, 63, 1035, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 1),
(1093, 13, 93, 59, 1071, 1, '1', '2019-06-13', '1', '2019-06-14 14:06:59', 2),
(1094, 13, 93, 60, 1072, 1, '1', '2019-06-13', '1', '2019-06-14 14:06:59', 2),
(1095, 13, 93, 61, 1073, 1, '1', '2019-06-13', '1', '2019-06-14 14:06:59', 2),
(1096, 13, 93, 62, 1074, 1, '1', '2019-06-13', '1', '2019-06-14 14:06:59', 2),
(1097, 13, 93, 63, 1075, 1, '1', '2019-06-13', '1', '2019-06-14 14:06:59', 2),
(1098, 13, 93, 59, 1111, 1, '1', '2019-06-13', '1', '2019-06-14 14:07:11', 3),
(1099, 13, 93, 60, 1112, 1, '1', '2019-06-13', '1', '2019-06-14 14:07:11', 3),
(1100, 13, 93, 61, 1113, 1, '1', '2019-06-13', '1', '2019-06-14 14:07:11', 3),
(1101, 13, 93, 62, 1114, 1, '1', '2019-06-13', '1', '2019-06-14 14:07:11', 3),
(1102, 13, 93, 63, 1115, 1, '1', '2019-06-13', '1', '2019-06-14 14:07:11', 3),
(1103, 13, 93, 59, 1151, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 4),
(1104, 13, 93, 60, 1152, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 4),
(1105, 13, 93, 61, 1153, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 4),
(1106, 13, 93, 62, 1154, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 4),
(1107, 13, 93, 63, 1155, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 4),
(1108, 13, 93, 59, 1191, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 5),
(1109, 13, 93, 60, 1192, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 5),
(1110, 13, 93, 61, 1193, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 5),
(1111, 13, 93, 62, 1194, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 5),
(1112, 13, 93, 63, 1195, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 5),
(1113, 13, 93, 59, 1231, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 6),
(1114, 13, 93, 60, 1232, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 6),
(1115, 13, 93, 61, 1233, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 6),
(1116, 13, 93, 62, 1234, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 6),
(1117, 13, 93, 63, 1235, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 6),
(1118, 13, 93, 59, 1271, 1, '1', '2019-06-13', '1', '2019-06-21 13:41:23', 7),
(1119, 13, 93, 60, 1272, 1, '1', '2019-06-13', '1', '2019-06-21 13:41:23', 7),
(1120, 13, 93, 61, 1273, 1, '1', '2019-06-13', '1', '2019-06-21 13:41:23', 7),
(1121, 13, 93, 62, 1274, 1, '1', '2019-06-13', '1', '2019-06-21 13:41:23', 7),
(1122, 13, 93, 63, 1275, 1, '1', '2019-06-13', '1', '2019-06-21 13:41:23', 7),
(1123, 13, 93, 59, 1311, 1, '1', '2019-06-13', '1', '2019-06-21 13:41:23', 8),
(1124, 13, 93, 60, 1312, 1, '1', '2019-06-13', '1', '2019-06-21 13:41:23', 8),
(1125, 13, 93, 61, 1313, 1, '1', '2019-06-13', '1', '2019-06-21 13:41:23', 8),
(1126, 13, 93, 62, 1314, 1, '1', '2019-06-13', '1', '2019-06-21 13:41:23', 8),
(1127, 13, 93, 63, 1315, 1, '1', '2019-06-13', '1', '2019-06-21 13:41:23', 8),
(1151, 14, 94, 59, 1036, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 1),
(1152, 14, 94, 60, 1037, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 1),
(1153, 14, 94, 61, 1038, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 1),
(1154, 14, 94, 62, 1039, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 1),
(1155, 14, 94, 63, 1040, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 1),
(1156, 14, 94, 59, 1076, 1, '1', '2019-06-13', '1', '2019-06-14 14:06:59', 2),
(1157, 14, 94, 60, 1077, 1, '1', '2019-06-13', '1', '2019-06-14 14:06:59', 2),
(1158, 14, 94, 61, 1078, 1, '1', '2019-06-13', '1', '2019-06-14 14:06:59', 2),
(1159, 14, 94, 62, 1079, 1, '1', '2019-06-13', '1', '2019-06-14 14:06:59', 2),
(1160, 14, 94, 63, 1080, 1, '1', '2019-06-13', '1', '2019-06-14 14:06:59', 2),
(1161, 14, 94, 59, 1116, 1, '1', '2019-06-13', '1', '2019-06-14 14:07:11', 3),
(1162, 14, 94, 60, 1117, 1, '1', '2019-06-13', '1', '2019-06-14 14:07:11', 3),
(1163, 14, 94, 61, 1118, 1, '1', '2019-06-13', '1', '2019-06-14 14:07:11', 3),
(1164, 14, 94, 62, 1119, 1, '1', '2019-06-13', '1', '2019-06-14 14:07:11', 3),
(1165, 14, 94, 63, 1120, 1, '1', '2019-06-13', '1', '2019-06-14 14:07:11', 3),
(1166, 14, 94, 59, 1156, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 4),
(1167, 14, 94, 60, 1157, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 4),
(1168, 14, 94, 61, 1158, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 4),
(1169, 14, 94, 62, 1159, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 4),
(1170, 14, 94, 63, 1160, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 4),
(1171, 14, 94, 59, 1196, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 5),
(1172, 14, 94, 60, 1197, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 5),
(1173, 14, 94, 61, 1198, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 5),
(1174, 14, 94, 62, 1199, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 5),
(1175, 14, 94, 63, 1200, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 5),
(1176, 14, 94, 59, 1236, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 6),
(1177, 14, 94, 60, 1237, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 6),
(1178, 14, 94, 61, 1238, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 6),
(1179, 14, 94, 62, 1239, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 6),
(1180, 14, 94, 63, 1240, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 6),
(1181, 14, 94, 59, 1276, 1, '1', '2019-06-13', '1', '2019-06-21 13:41:23', 7),
(1182, 14, 94, 60, 1277, 1, '1', '2019-06-13', '1', '2019-06-21 13:41:23', 7),
(1183, 14, 94, 61, 1278, 1, '1', '2019-06-13', '1', '2019-06-21 13:41:23', 7),
(1184, 14, 94, 62, 1279, 1, '1', '2019-06-13', '1', '2019-06-21 13:41:23', 7),
(1185, 14, 94, 63, 1280, 1, '1', '2019-06-13', '1', '2019-06-21 13:41:23', 7),
(1186, 14, 94, 59, 1316, 1, '1', '2019-06-13', '1', '2019-06-21 13:41:23', 8),
(1187, 14, 94, 60, 1232, 1, '1', '2019-06-13', '1', '2019-06-21 13:41:23', 8),
(1188, 14, 94, 61, 1318, 1, '1', '2019-06-13', '1', '2019-06-21 13:41:23', 8),
(1189, 14, 94, 62, 1319, 1, '1', '2019-06-13', '1', '2019-06-21 13:41:23', 8),
(1190, 14, 94, 63, 1320, 1, '1', '2019-06-13', '1', '2019-06-21 13:41:23', 8),
(1214, 15, 95, 59, 1036, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 1),
(1215, 15, 95, 60, 1037, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 1),
(1216, 15, 95, 61, 1038, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 1),
(1217, 15, 95, 62, 1039, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 1),
(1218, 15, 95, 63, 1040, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 1),
(1219, 15, 95, 59, 1076, 1, '1', '2019-06-13', '1', '2019-06-14 14:06:59', 2),
(1220, 15, 95, 60, 1077, 1, '1', '2019-06-13', '1', '2019-06-14 14:06:59', 2),
(1221, 15, 95, 61, 1078, 1, '1', '2019-06-13', '1', '2019-06-14 14:06:59', 2),
(1222, 15, 95, 62, 1079, 1, '1', '2019-06-13', '1', '2019-06-14 14:06:59', 2),
(1223, 15, 95, 63, 1080, 1, '1', '2019-06-13', '1', '2019-06-14 14:06:59', 2),
(1224, 15, 95, 59, 1116, 1, '1', '2019-06-13', '1', '2019-06-14 14:07:11', 3),
(1225, 15, 95, 60, 1117, 1, '1', '2019-06-13', '1', '2019-06-14 14:07:11', 3),
(1226, 15, 95, 61, 1118, 1, '1', '2019-06-13', '1', '2019-06-14 14:07:11', 3),
(1227, 15, 95, 62, 1119, 1, '1', '2019-06-13', '1', '2019-06-14 14:07:11', 3),
(1228, 15, 95, 63, 1120, 1, '1', '2019-06-13', '1', '2019-06-14 14:07:11', 3),
(1229, 15, 95, 59, 1156, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 4),
(1230, 15, 95, 60, 1157, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 4),
(1231, 15, 95, 61, 1158, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 4),
(1232, 15, 95, 62, 1159, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 4),
(1233, 15, 95, 63, 1160, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 4),
(1234, 15, 95, 59, 1196, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 5),
(1235, 15, 95, 60, 1197, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 5),
(1236, 15, 95, 61, 1198, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 5),
(1237, 15, 95, 62, 1199, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 5),
(1238, 15, 95, 63, 1200, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 5),
(1239, 15, 95, 59, 1236, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 6),
(1240, 15, 95, 60, 1237, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 6),
(1241, 15, 95, 61, 1238, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 6),
(1242, 15, 95, 62, 1239, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 6),
(1243, 15, 95, 63, 1240, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00', 6),
(1244, 15, 95, 59, 1276, 1, '1', '2019-06-13', '1', '2019-06-21 13:41:23', 7),
(1245, 15, 95, 60, 1277, 1, '1', '2019-06-13', '1', '2019-06-21 13:41:23', 7),
(1246, 15, 95, 61, 1278, 1, '1', '2019-06-13', '1', '2019-06-21 13:41:23', 7),
(1247, 15, 95, 62, 1279, 1, '1', '2019-06-13', '1', '2019-06-21 13:41:23', 7),
(1248, 15, 95, 63, 1280, 1, '1', '2019-06-13', '1', '2019-06-21 13:41:23', 7),
(1249, 15, 95, 59, 1316, 1, '1', '2019-06-13', '1', '2019-06-21 13:41:23', 8),
(1250, 15, 95, 60, 1232, 1, '1', '2019-06-13', '1', '2019-06-21 13:41:23', 8),
(1251, 15, 95, 61, 1318, 1, '1', '2019-06-13', '1', '2019-06-21 13:41:23', 8),
(1252, 15, 95, 62, 1319, 1, '1', '2019-06-13', '1', '2019-06-21 13:41:23', 8),
(1253, 15, 95, 63, 1320, 1, '1', '2019-06-13', '1', '2019-06-21 13:41:23', 8),
(1254, 1, 10, 1, 414, 1, '1', '2019-08-05', '', '2019-08-05 14:00:53', 1),
(1255, 1, 10, 1, 416, 1, '1', '2019-08-05', '', '2019-08-05 14:00:53', 1),
(1256, 1, 10, 2, 418, 1, '1', '2019-08-05', '', '2019-08-05 14:00:53', 1),
(1257, 1, 10, 1, 419, 1, '1', '2019-08-05', '', '2019-08-05 14:00:53', 1),
(1258, 1, 10, 1, 421, 1, '1', '2019-08-05', '', '2019-08-05 14:00:53', 1),
(1259, 1, 10, 3, 422, 1, '1', '2019-08-05', '', '2019-08-05 14:00:53', 1),
(1260, 1, 10, 2, 424, 1, '1', '2019-08-05', '', '2019-08-05 14:00:53', 1),
(1261, 1, 10, 3, 425, 1, '1', '2019-08-05', '', '2019-08-05 14:00:53', 1),
(1262, 1, 10, 2, 426, 1, '1', '2019-08-05', '', '2019-08-05 14:00:53', 1),
(1263, 1, 10, 2, 429, 1, '1', '2019-08-05', '', '2019-08-05 14:00:53', 1),
(1264, 1, 10, 2, 431, 1, '1', '2019-08-05', '', '2019-08-05 14:00:53', 1),
(1265, 1, 10, 2, 432, 1, '1', '2019-08-05', '', '2019-08-05 14:00:53', 1),
(1266, 1, 10, 2, 433, 1, '1', '2019-08-05', '', '2019-08-05 14:00:53', 1),
(1267, 1, 10, 2, 434, 1, '1', '2019-08-05', '', '2019-08-05 14:00:53', 1),
(1268, 1, 10, 2, 435, 1, '1', '2019-08-05', '', '2019-08-05 14:00:53', 1),
(1269, 1, 10, 3, 439, 1, '1', '2019-08-05', '', '2019-08-05 14:00:53', 1),
(1270, 1, 10, 3, 440, 1, '1', '2019-08-05', '', '2019-08-05 14:00:53', 1),
(1271, 1, 10, 3, 516, 1, '1', '2019-08-05', '', '2019-08-05 14:00:53', 1),
(1272, 1, 10, 2, 518, 1, '1', '2019-08-05', '', '2019-08-05 14:00:53', 1),
(1273, 1, 10, 1, 594, 1, '1', '2019-08-05', '', '2019-08-05 14:00:53', 1),
(1274, 1, 10, 1, 595, 1, '1', '2019-08-05', '', '2019-08-05 14:00:53', 1),
(1275, 1, 10, 2, 597, 1, '1', '2019-08-05', '', '2019-08-05 14:00:53', 1),
(1276, 1, 10, 2, 599, 1, '1', '2019-08-05', '', '2019-08-05 14:00:53', 1),
(1277, 1, 10, 2, 601, 1, '1', '2019-08-05', '', '2019-08-05 14:00:53', 1),
(1278, 1, 10, 2, 602, 1, '1', '2019-08-05', '', '2019-08-05 14:00:53', 1),
(1279, 1, 10, 2, 603, 1, '1', '2019-08-05', '', '2019-08-05 14:00:53', 1),
(1280, 1, 10, 2, 604, 1, '1', '2019-08-05', '', '2019-08-05 14:00:53', 1),
(1281, 1, 10, 2, 605, 1, '1', '2019-08-05', '', '2019-08-05 14:00:53', 1),
(1282, 1, 10, 2, 612, 1, '1', '2019-08-05', '', '2019-08-05 14:00:53', 1),
(1283, 1, 10, 2, 613, 1, '1', '2019-08-05', '', '2019-08-05 14:00:53', 1),
(1284, 1, 10, 2, 614, 1, '1', '2019-08-05', '', '2019-08-05 14:00:53', 1),
(1285, 1, 10, 2, 615, 1, '1', '2019-08-05', '', '2019-08-05 14:00:53', 1),
(1286, 1, 10, 3, 619, 1, '1', '2019-08-05', '', '2019-08-05 14:00:53', 1),
(1287, 1, 10, 3, 620, 1, '1', '2019-08-05', '', '2019-08-05 14:00:53', 1),
(1288, 1, 10, 3, 621, 1, '1', '2019-08-05', '', '2019-08-05 14:00:53', 1),
(1289, 1, 10, 3, 624, 1, '1', '2019-08-05', '', '2019-08-05 14:00:53', 1),
(1290, 1, 10, 3, 625, 1, '1', '2019-08-05', '', '2019-08-05 14:00:53', 1),
(1291, 2, 11, 1, 464, 1, '1', '2019-08-05', '', '2019-08-05 14:00:53', 1),
(1292, 2, 11, 1, 467, 1, '1', '2019-08-05', '', '2019-08-05 14:00:53', 1),
(1293, 2, 11, 1, 469, 1, '1', '2019-08-05', '', '2019-08-05 14:00:53', 1),
(1294, 2, 11, 1, 470, 1, '1', '2019-08-05', '', '2019-08-05 14:00:53', 1),
(1295, 2, 11, 1, 471, 1, '1', '2019-08-05', '', '2019-08-05 14:00:53', 1),
(1296, 2, 11, 3, 472, 1, '1', '2019-08-05', '', '2019-08-05 14:00:53', 1),
(1297, 2, 11, 2, 474, 1, '1', '2019-08-05', '', '2019-08-05 14:00:53', 1),
(1298, 2, 11, 3, 475, 1, '1', '2019-08-05', '', '2019-08-05 14:00:53', 1),
(1299, 2, 11, 2, 476, 1, '1', '2019-08-05', '', '2019-08-05 14:00:53', 1),
(1300, 2, 11, 2, 479, 1, '1', '2019-08-05', '', '2019-08-05 14:00:53', 1),
(1301, 2, 11, 2, 481, 1, '1', '2019-08-05', '', '2019-08-05 14:00:53', 1),
(1302, 2, 11, 2, 482, 1, '1', '2019-08-05', '', '2019-08-05 14:00:53', 1),
(1303, 2, 11, 2, 483, 1, '1', '2019-08-05', '', '2019-08-05 14:00:53', 1),
(1304, 2, 11, 2, 484, 1, '1', '2019-08-05', '', '2019-08-05 14:00:53', 1),
(1305, 2, 11, 2, 485, 1, '1', '2019-08-05', '', '2019-08-05 14:00:53', 1),
(1306, 2, 11, 3, 489, 1, '1', '2019-08-05', '', '2019-08-05 14:00:53', 1),
(1307, 2, 11, 3, 490, 1, '1', '2019-08-05', '', '2019-08-05 14:00:53', 1),
(1308, 2, 11, 1, 515, 1, '1', '2019-08-05', '', '2019-08-05 14:00:53', 1),
(1309, 2, 11, 2, 517, 1, '1', '2019-08-05', '', '2019-08-05 14:00:53', 1),
(1310, 2, 11, 1, 596, 1, '1', '2019-08-05', '', '2019-08-05 14:00:53', 1),
(1311, 2, 11, 2, 598, 1, '1', '2019-08-05', '', '2019-08-05 14:00:53', 1),
(1312, 2, 11, 2, 600, 1, '1', '2019-08-05', '', '2019-08-05 14:00:53', 1),
(1313, 2, 11, 2, 606, 1, '1', '2019-08-05', '', '2019-08-05 14:00:53', 1),
(1314, 2, 11, 2, 607, 1, '1', '2019-08-05', '', '2019-08-05 14:00:53', 1),
(1315, 2, 11, 2, 608, 1, '1', '2019-08-05', '', '2019-08-05 14:00:53', 1),
(1316, 2, 11, 2, 609, 1, '1', '2019-08-05', '', '2019-08-05 14:00:53', 1),
(1317, 2, 11, 2, 610, 1, '1', '2019-08-05', '', '2019-08-05 14:00:53', 1),
(1318, 2, 11, 2, 611, 1, '1', '2019-08-05', '', '2019-08-05 14:00:53', 1),
(1319, 2, 11, 2, 616, 1, '1', '2019-08-05', '', '2019-08-05 14:00:53', 1),
(1320, 2, 11, 2, 617, 1, '1', '2019-08-05', '', '2019-08-05 14:00:53', 1),
(1321, 2, 11, 2, 618, 1, '1', '2019-08-05', '', '2019-08-05 14:00:53', 1),
(1322, 2, 11, 3, 622, 1, '1', '2019-08-05', '', '2019-08-05 14:00:53', 1),
(1323, 2, 11, 3, 623, 1, '1', '2019-08-05', '', '2019-08-05 14:00:53', 1),
(1324, 2, 11, 3, 626, 1, '1', '2019-08-05', '', '2019-08-05 14:00:53', 1),
(1325, 2, 11, 3, 627, 1, '1', '2019-08-05', '', '2019-08-05 14:00:53', 1),
(1326, 2, 11, 3, 628, 1, '1', '2019-08-05', '', '2019-08-05 14:00:53', 1);

-- --------------------------------------------------------

--
-- Table structure for table `class_skill_game`
--

CREATE TABLE `class_skill_game` (
  `id` int(11) NOT NULL,
  `class_id` int(11) NOT NULL,
  `skill_id` int(11) NOT NULL,
  `game_id` int(11) NOT NULL,
  `status` int(1) NOT NULL,
  `createdby` varchar(100) NOT NULL,
  `creation_date` date NOT NULL,
  `modifiedby` varchar(100) NOT NULL,
  `modified_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `class_skill_game`
--

INSERT INTO `class_skill_game` (`id`, `class_id`, `skill_id`, `game_id`, `status`, `createdby`, `creation_date`, `modifiedby`, `modified_date`) VALUES
(1, 3, 59, 1001, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(2, 3, 60, 1002, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(3, 3, 61, 1003, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(4, 3, 62, 1004, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(5, 3, 63, 1005, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(6, 4, 59, 1006, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(7, 4, 60, 1007, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(8, 4, 61, 1008, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(9, 4, 62, 1009, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(10, 4, 63, 1010, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(11, 5, 59, 1011, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(12, 5, 60, 1012, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(13, 5, 61, 1013, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(14, 5, 62, 1014, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(15, 5, 63, 1015, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(16, 6, 59, 1016, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(17, 6, 60, 1017, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(18, 6, 61, 1018, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(19, 6, 62, 1019, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(20, 6, 63, 1020, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(21, 7, 59, 1021, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(22, 7, 60, 1022, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(23, 7, 61, 1023, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(24, 7, 62, 1024, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(25, 7, 63, 1025, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(26, 8, 59, 1026, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(27, 8, 60, 1027, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(28, 8, 61, 1028, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(29, 8, 62, 1029, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(30, 8, 63, 1030, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(31, 9, 59, 1031, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(32, 9, 60, 1032, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(33, 9, 61, 1033, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(34, 9, 62, 1034, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(35, 9, 63, 1035, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(36, 10, 59, 1036, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(37, 10, 60, 1037, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(38, 10, 61, 1038, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(39, 10, 62, 1039, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(40, 10, 63, 1040, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(41, 3, 59, 1041, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(42, 3, 60, 1042, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(43, 3, 61, 1043, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(44, 3, 62, 1044, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(45, 3, 63, 1045, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(46, 4, 59, 1046, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(47, 4, 60, 1047, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(48, 4, 61, 1048, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(49, 4, 62, 1049, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(50, 4, 63, 1050, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(51, 5, 59, 1051, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(52, 5, 60, 1052, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(53, 5, 61, 1053, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(54, 5, 62, 1054, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(55, 5, 63, 1055, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(56, 6, 59, 1056, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(57, 6, 60, 1057, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(58, 6, 61, 1058, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(59, 6, 62, 1059, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(60, 6, 63, 1060, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(61, 7, 59, 1061, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(62, 7, 60, 1062, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(63, 7, 61, 1063, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(64, 7, 62, 1064, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(65, 7, 63, 1065, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(66, 8, 59, 1066, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(67, 8, 60, 1067, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(68, 8, 61, 1068, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(69, 8, 62, 1069, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(70, 8, 63, 1070, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(71, 9, 59, 1071, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(72, 9, 60, 1072, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(73, 9, 61, 1073, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(74, 9, 62, 1074, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(75, 9, 63, 1075, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(76, 10, 59, 1076, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(77, 10, 60, 1077, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(78, 10, 61, 1078, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(79, 10, 62, 1079, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(80, 10, 63, 1080, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(81, 3, 59, 1081, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(82, 3, 60, 1082, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(83, 3, 61, 1083, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(84, 3, 62, 1084, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(85, 3, 63, 1085, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(86, 4, 59, 1086, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(87, 4, 60, 1087, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(88, 4, 61, 1088, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(89, 4, 62, 1089, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(90, 4, 63, 1090, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(91, 5, 59, 1091, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(92, 5, 60, 1092, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(93, 5, 61, 1093, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(94, 5, 62, 1094, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(95, 5, 63, 1095, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(96, 6, 59, 1096, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(97, 6, 60, 1097, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(98, 6, 61, 1098, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(99, 6, 62, 1099, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(100, 6, 63, 1100, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(101, 7, 59, 1101, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(102, 7, 60, 1102, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(103, 7, 61, 1103, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(104, 7, 62, 1104, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(105, 7, 63, 1105, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(106, 8, 59, 1106, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(107, 8, 60, 1107, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(108, 8, 61, 1108, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(109, 8, 62, 1109, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(110, 8, 63, 1110, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(111, 9, 59, 1111, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(112, 9, 60, 1112, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(113, 9, 61, 1113, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(114, 9, 62, 1114, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(115, 9, 63, 1115, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(116, 10, 59, 1116, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(117, 10, 60, 1117, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(118, 10, 61, 1118, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(119, 10, 62, 1119, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(120, 10, 63, 1120, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(121, 3, 59, 1121, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(122, 3, 60, 1122, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(123, 3, 61, 1123, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(124, 3, 62, 1124, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(125, 3, 63, 1125, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(126, 4, 59, 1126, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(127, 4, 60, 1127, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(128, 4, 61, 1128, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(129, 4, 62, 1129, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(130, 4, 63, 1130, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(131, 5, 59, 1131, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(132, 5, 60, 1132, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(133, 5, 61, 1133, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(134, 5, 62, 1134, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(135, 5, 63, 1135, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(136, 6, 59, 1136, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(137, 6, 60, 1137, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(138, 6, 61, 1138, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(139, 6, 62, 1139, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(140, 6, 63, 1140, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(141, 7, 59, 1141, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(142, 7, 60, 1142, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(143, 7, 61, 1143, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(144, 7, 62, 1144, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(145, 7, 63, 1145, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(146, 8, 59, 1146, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(147, 8, 60, 1147, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(148, 8, 61, 1148, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(149, 8, 62, 1149, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(150, 8, 63, 1150, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(151, 9, 59, 1151, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(152, 9, 60, 1152, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(153, 9, 61, 1153, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(154, 9, 62, 1154, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(155, 9, 63, 1155, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(156, 10, 59, 1156, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(157, 10, 60, 1157, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(158, 10, 61, 1158, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(159, 10, 62, 1159, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(160, 10, 63, 1160, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(161, 3, 59, 1161, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(162, 3, 60, 1162, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(163, 3, 61, 1163, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(164, 3, 62, 1164, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(165, 3, 63, 1165, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(166, 4, 59, 1166, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(167, 4, 60, 1167, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(168, 4, 61, 1168, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(169, 4, 62, 1169, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(170, 4, 63, 1170, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(171, 5, 59, 1171, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(172, 5, 60, 1172, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(173, 5, 61, 1173, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(174, 5, 62, 1174, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(175, 5, 63, 1175, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(176, 6, 59, 1176, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(177, 6, 60, 1177, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(178, 6, 61, 1178, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(179, 6, 62, 1179, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(180, 6, 63, 1180, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(181, 7, 59, 1181, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(182, 7, 60, 1182, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(183, 7, 61, 1183, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(184, 7, 62, 1184, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(185, 7, 63, 1185, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(186, 8, 59, 1186, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(187, 8, 60, 1187, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(188, 8, 61, 1188, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(189, 8, 62, 1189, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(190, 8, 63, 1190, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(191, 9, 59, 1191, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(192, 9, 60, 1192, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(193, 9, 61, 1193, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(194, 9, 62, 1194, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(195, 9, 63, 1195, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(196, 10, 59, 1196, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(197, 10, 60, 1197, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(198, 10, 61, 1198, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(199, 10, 62, 1199, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(200, 10, 63, 1200, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(372, 3, 59, 1201, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(373, 3, 60, 1202, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(374, 3, 61, 1203, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(375, 3, 62, 1204, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(376, 3, 63, 1205, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(377, 4, 59, 1206, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(378, 4, 60, 1207, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(379, 4, 61, 1208, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(380, 4, 62, 1209, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(381, 4, 63, 1210, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(382, 5, 59, 1211, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(383, 5, 60, 1212, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(384, 5, 61, 1213, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(385, 5, 62, 1214, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(386, 5, 63, 1215, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(387, 6, 59, 1216, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(388, 6, 60, 1217, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(389, 6, 61, 1218, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(390, 6, 62, 1219, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(391, 6, 63, 1220, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(392, 7, 59, 1221, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(393, 7, 60, 1222, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(394, 7, 61, 1223, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(395, 7, 62, 1224, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(396, 7, 63, 1225, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(397, 8, 59, 1226, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(398, 8, 60, 1227, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(399, 8, 61, 1228, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(400, 8, 62, 1229, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(401, 8, 63, 1230, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(402, 9, 59, 1231, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(403, 9, 60, 1232, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(404, 9, 61, 1233, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(405, 9, 62, 1234, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(406, 9, 63, 1235, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(407, 10, 59, 1236, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(408, 10, 60, 1237, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(409, 10, 61, 1238, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(410, 10, 62, 1239, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(411, 10, 63, 1240, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(435, 3, 59, 1206, 1, '1', '2019-06-13', '1', '2019-06-21 13:45:35'),
(436, 3, 60, 1242, 1, '1', '2019-06-13', '1', '2019-06-21 13:45:35'),
(437, 3, 61, 1208, 1, '1', '2019-06-13', '1', '2019-06-21 13:45:35'),
(438, 3, 62, 1169, 1, '1', '2019-06-13', '1', '2019-06-21 13:45:35'),
(439, 3, 63, 1245, 1, '1', '2019-06-13', '1', '2019-06-21 13:45:35'),
(440, 4, 59, 1246, 1, '1', '2019-06-13', '1', '2019-06-21 13:45:35'),
(441, 4, 60, 1247, 1, '1', '2019-06-13', '1', '2019-06-21 13:45:35'),
(442, 4, 61, 1248, 1, '1', '2019-06-13', '1', '2019-06-21 13:45:35'),
(443, 4, 62, 1249, 1, '1', '2019-06-13', '1', '2019-06-21 13:45:35'),
(444, 4, 63, 1250, 1, '1', '2019-06-13', '1', '2019-06-21 13:45:35'),
(445, 5, 59, 1251, 1, '1', '2019-06-13', '1', '2019-06-21 13:45:35'),
(446, 5, 60, 1252, 1, '1', '2019-06-13', '1', '2019-06-21 13:45:35'),
(447, 5, 61, 1253, 1, '1', '2019-06-13', '1', '2019-06-21 13:45:35'),
(448, 5, 62, 1254, 1, '1', '2019-06-13', '1', '2019-06-21 13:45:35'),
(449, 5, 63, 1255, 1, '1', '2019-06-13', '1', '2019-06-21 13:45:35'),
(450, 6, 59, 1256, 1, '1', '2019-06-13', '1', '2019-06-21 13:45:35'),
(451, 6, 60, 1257, 1, '1', '2019-06-13', '1', '2019-06-21 13:45:35'),
(452, 6, 61, 1258, 1, '1', '2019-06-13', '1', '2019-06-21 13:45:35'),
(453, 6, 62, 1259, 1, '1', '2019-06-13', '1', '2019-06-21 13:45:35'),
(454, 6, 63, 1260, 1, '1', '2019-06-13', '1', '2019-06-21 13:45:35'),
(455, 7, 59, 1261, 1, '1', '2019-06-13', '1', '2019-06-21 13:45:35'),
(456, 7, 60, 1262, 1, '1', '2019-06-13', '1', '2019-06-21 13:45:35'),
(457, 7, 61, 1263, 1, '1', '2019-06-13', '1', '2019-06-21 13:45:35'),
(458, 7, 62, 1264, 1, '1', '2019-06-13', '1', '2019-06-21 13:45:35'),
(459, 7, 63, 1265, 1, '1', '2019-06-13', '1', '2019-06-21 13:45:35'),
(460, 8, 59, 1266, 1, '1', '2019-06-13', '1', '2019-06-21 13:45:35'),
(461, 8, 60, 1267, 1, '1', '2019-06-13', '1', '2019-06-21 13:45:35'),
(462, 8, 61, 1268, 1, '1', '2019-06-13', '1', '2019-06-21 13:45:35'),
(463, 8, 62, 1269, 1, '1', '2019-06-13', '1', '2019-06-21 13:45:35'),
(464, 8, 63, 1270, 1, '1', '2019-06-13', '1', '2019-06-21 13:45:35'),
(465, 9, 59, 1271, 1, '1', '2019-06-13', '1', '2019-06-21 13:45:35'),
(466, 9, 60, 1272, 1, '1', '2019-06-13', '1', '2019-06-21 13:45:35'),
(467, 9, 61, 1273, 1, '1', '2019-06-13', '1', '2019-06-21 13:45:35'),
(468, 9, 62, 1274, 1, '1', '2019-06-13', '1', '2019-06-21 13:45:35'),
(469, 9, 63, 1275, 1, '1', '2019-06-13', '1', '2019-06-21 13:45:35'),
(470, 10, 59, 1276, 1, '1', '2019-06-13', '1', '2019-06-21 13:45:35'),
(471, 10, 60, 1277, 1, '1', '2019-06-13', '1', '2019-06-21 13:45:35'),
(472, 10, 61, 1278, 1, '1', '2019-06-13', '1', '2019-06-21 13:45:35'),
(473, 10, 62, 1279, 1, '1', '2019-06-13', '1', '2019-06-21 13:45:35'),
(474, 10, 63, 1280, 1, '1', '2019-06-13', '1', '2019-06-21 13:45:35'),
(475, 3, 59, 1166, 1, '1', '2019-06-13', '1', '2019-06-21 13:45:35'),
(476, 3, 60, 1282, 1, '1', '2019-06-13', '1', '2019-06-21 13:45:35'),
(477, 3, 61, 1248, 1, '1', '2019-06-13', '1', '2019-06-21 13:45:35'),
(478, 3, 62, 1209, 1, '1', '2019-06-13', '1', '2019-06-21 13:45:35'),
(479, 3, 63, 1285, 1, '1', '2019-06-13', '1', '2019-06-21 13:45:35'),
(480, 4, 59, 1286, 1, '1', '2019-06-13', '1', '2019-06-21 13:45:35'),
(481, 4, 60, 1287, 1, '1', '2019-06-13', '1', '2019-06-21 13:45:35'),
(482, 4, 61, 1288, 1, '1', '2019-06-13', '1', '2019-06-21 13:45:35'),
(483, 4, 62, 1289, 1, '1', '2019-06-13', '1', '2019-06-21 13:45:35'),
(484, 4, 63, 1290, 1, '1', '2019-06-13', '1', '2019-06-21 13:45:35'),
(485, 5, 59, 1291, 1, '1', '2019-06-13', '1', '2019-06-21 13:45:35'),
(486, 5, 60, 1292, 1, '1', '2019-06-13', '1', '2019-06-21 13:45:35'),
(487, 5, 61, 1293, 1, '1', '2019-06-13', '1', '2019-06-21 13:45:35'),
(488, 5, 62, 1294, 1, '1', '2019-06-13', '1', '2019-06-21 13:45:35'),
(489, 5, 63, 1250, 1, '1', '2019-06-13', '1', '2019-06-21 13:45:35'),
(490, 6, 59, 1296, 1, '1', '2019-06-13', '1', '2019-06-21 13:45:35'),
(491, 6, 60, 1297, 1, '1', '2019-06-13', '1', '2019-06-21 13:45:35'),
(492, 6, 61, 1298, 1, '1', '2019-06-13', '1', '2019-06-21 13:45:35'),
(493, 6, 62, 1299, 1, '1', '2019-06-13', '1', '2019-06-21 13:45:35'),
(494, 6, 63, 1300, 1, '1', '2019-06-13', '1', '2019-06-21 13:45:35'),
(495, 7, 59, 1301, 1, '1', '2019-06-13', '1', '2019-06-21 13:45:35'),
(496, 7, 60, 1302, 1, '1', '2019-06-13', '1', '2019-06-21 13:45:35'),
(497, 7, 61, 1303, 1, '1', '2019-06-13', '1', '2019-06-21 13:45:35'),
(498, 7, 62, 1029, 1, '1', '2019-06-13', '1', '2019-06-21 13:45:35'),
(499, 7, 63, 1305, 1, '1', '2019-06-13', '1', '2019-06-21 13:45:35'),
(500, 8, 59, 1306, 1, '1', '2019-06-13', '1', '2019-06-21 13:45:35'),
(501, 8, 60, 1307, 1, '1', '2019-06-13', '1', '2019-06-21 13:45:35'),
(502, 8, 61, 1308, 1, '1', '2019-06-13', '1', '2019-06-21 13:45:35'),
(503, 8, 62, 1309, 1, '1', '2019-06-13', '1', '2019-06-21 13:45:35'),
(504, 8, 63, 1310, 1, '1', '2019-06-13', '1', '2019-06-21 13:45:35'),
(505, 9, 59, 1311, 1, '1', '2019-06-13', '1', '2019-06-21 13:45:35'),
(506, 9, 60, 1312, 1, '1', '2019-06-13', '1', '2019-06-21 13:45:35'),
(507, 9, 61, 1313, 1, '1', '2019-06-13', '1', '2019-06-21 13:45:35'),
(508, 9, 62, 1314, 1, '1', '2019-06-13', '1', '2019-06-21 13:45:35'),
(509, 9, 63, 1315, 1, '1', '2019-06-13', '1', '2019-06-21 13:45:35'),
(510, 10, 59, 1316, 1, '1', '2019-06-13', '1', '2019-06-21 13:45:35'),
(511, 10, 60, 1232, 1, '1', '2019-06-13', '1', '2019-06-21 13:45:35'),
(512, 10, 61, 1318, 1, '1', '2019-06-13', '1', '2019-06-21 13:45:35'),
(513, 10, 62, 1319, 1, '1', '2019-06-13', '1', '2019-06-21 13:45:35'),
(514, 10, 63, 1320, 1, '1', '2019-06-13', '1', '2019-06-21 13:45:35'),
(1019, 12, 59, 1026, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(1020, 12, 60, 1027, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(1021, 12, 61, 1028, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(1022, 12, 62, 1029, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(1023, 12, 63, 1030, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(1024, 12, 59, 1066, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(1025, 12, 60, 1067, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(1026, 12, 61, 1068, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(1027, 12, 62, 1069, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(1028, 12, 63, 1070, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(1029, 12, 59, 1106, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(1030, 12, 60, 1107, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(1031, 12, 61, 1108, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(1032, 12, 62, 1109, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(1033, 12, 63, 1110, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(1034, 12, 59, 1146, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(1035, 12, 60, 1147, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(1036, 12, 61, 1148, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(1037, 12, 62, 1149, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(1038, 12, 63, 1150, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(1039, 12, 59, 1186, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(1040, 12, 60, 1187, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(1041, 12, 61, 1188, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(1042, 12, 62, 1189, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(1043, 12, 63, 1190, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(1044, 12, 59, 1226, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(1045, 12, 60, 1227, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(1046, 12, 61, 1228, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(1047, 12, 62, 1229, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(1048, 12, 63, 1230, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(1049, 12, 59, 1266, 1, '1', '2019-06-13', '1', '2019-06-21 13:45:35'),
(1050, 12, 60, 1267, 1, '1', '2019-06-13', '1', '2019-06-21 13:45:35'),
(1051, 12, 61, 1268, 1, '1', '2019-06-13', '1', '2019-06-21 13:45:35'),
(1052, 12, 62, 1269, 1, '1', '2019-06-13', '1', '2019-06-21 13:45:35'),
(1053, 12, 63, 1270, 1, '1', '2019-06-13', '1', '2019-06-21 13:45:35'),
(1054, 12, 59, 1306, 1, '1', '2019-06-13', '1', '2019-06-21 13:45:35'),
(1055, 12, 60, 1307, 1, '1', '2019-06-13', '1', '2019-06-21 13:45:35'),
(1056, 12, 61, 1308, 1, '1', '2019-06-13', '1', '2019-06-21 13:45:35'),
(1057, 12, 62, 1309, 1, '1', '2019-06-13', '1', '2019-06-21 13:45:35'),
(1058, 12, 63, 1310, 1, '1', '2019-06-13', '1', '2019-06-21 13:45:35'),
(1082, 13, 59, 1031, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(1083, 13, 60, 1032, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(1084, 13, 61, 1033, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(1085, 13, 62, 1034, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(1086, 13, 63, 1035, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(1087, 13, 59, 1071, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(1088, 13, 60, 1072, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(1089, 13, 61, 1073, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(1090, 13, 62, 1074, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(1091, 13, 63, 1075, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(1092, 13, 59, 1111, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(1093, 13, 60, 1112, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(1094, 13, 61, 1113, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(1095, 13, 62, 1114, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(1096, 13, 63, 1115, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(1097, 13, 59, 1151, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(1098, 13, 60, 1152, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(1099, 13, 61, 1153, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(1100, 13, 62, 1154, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(1101, 13, 63, 1155, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(1102, 13, 59, 1191, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(1103, 13, 60, 1192, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(1104, 13, 61, 1193, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(1105, 13, 62, 1194, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(1106, 13, 63, 1195, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(1107, 13, 59, 1231, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(1108, 13, 60, 1232, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(1109, 13, 61, 1233, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(1110, 13, 62, 1234, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(1111, 13, 63, 1235, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(1112, 13, 59, 1271, 1, '1', '2019-06-13', '1', '2019-06-21 13:45:35'),
(1113, 13, 60, 1272, 1, '1', '2019-06-13', '1', '2019-06-21 13:45:35'),
(1114, 13, 61, 1273, 1, '1', '2019-06-13', '1', '2019-06-21 13:45:35'),
(1115, 13, 62, 1274, 1, '1', '2019-06-13', '1', '2019-06-21 13:45:35'),
(1116, 13, 63, 1275, 1, '1', '2019-06-13', '1', '2019-06-21 13:45:35'),
(1117, 13, 59, 1311, 1, '1', '2019-06-13', '1', '2019-06-21 13:45:35'),
(1118, 13, 60, 1312, 1, '1', '2019-06-13', '1', '2019-06-21 13:45:35'),
(1119, 13, 61, 1313, 1, '1', '2019-06-13', '1', '2019-06-21 13:45:35'),
(1120, 13, 62, 1314, 1, '1', '2019-06-13', '1', '2019-06-21 13:45:35'),
(1121, 13, 63, 1315, 1, '1', '2019-06-13', '1', '2019-06-21 13:45:35'),
(1145, 14, 59, 1036, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(1146, 14, 60, 1037, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(1147, 14, 61, 1038, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(1148, 14, 62, 1039, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(1149, 14, 63, 1040, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(1150, 14, 59, 1076, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(1151, 14, 60, 1077, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(1152, 14, 61, 1078, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(1153, 14, 62, 1079, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(1154, 14, 63, 1080, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(1155, 14, 59, 1116, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(1156, 14, 60, 1117, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(1157, 14, 61, 1118, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(1158, 14, 62, 1119, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(1159, 14, 63, 1120, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(1160, 14, 59, 1156, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(1161, 14, 60, 1157, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(1162, 14, 61, 1158, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(1163, 14, 62, 1159, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(1164, 14, 63, 1160, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(1165, 14, 59, 1196, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(1166, 14, 60, 1197, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(1167, 14, 61, 1198, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(1168, 14, 62, 1199, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(1169, 14, 63, 1200, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(1170, 14, 59, 1236, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(1171, 14, 60, 1237, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(1172, 14, 61, 1238, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(1173, 14, 62, 1239, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(1174, 14, 63, 1240, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(1175, 14, 59, 1276, 1, '1', '2019-06-13', '1', '2019-06-21 13:45:35'),
(1176, 14, 60, 1277, 1, '1', '2019-06-13', '1', '2019-06-21 13:45:35'),
(1177, 14, 61, 1278, 1, '1', '2019-06-13', '1', '2019-06-21 13:45:35'),
(1178, 14, 62, 1279, 1, '1', '2019-06-13', '1', '2019-06-21 13:45:35'),
(1179, 14, 63, 1280, 1, '1', '2019-06-13', '1', '2019-06-21 13:45:35'),
(1180, 14, 59, 1316, 1, '1', '2019-06-13', '1', '2019-06-21 13:45:35'),
(1181, 14, 60, 1232, 1, '1', '2019-06-13', '1', '2019-06-21 13:45:35'),
(1182, 14, 61, 1318, 1, '1', '2019-06-13', '1', '2019-06-21 13:45:35'),
(1183, 14, 62, 1319, 1, '1', '2019-06-13', '1', '2019-06-21 13:45:35'),
(1184, 14, 63, 1320, 1, '1', '2019-06-13', '1', '2019-06-21 13:45:35'),
(1208, 15, 59, 1036, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(1209, 15, 60, 1037, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(1210, 15, 61, 1038, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(1211, 15, 62, 1039, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(1212, 15, 63, 1040, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(1213, 15, 59, 1076, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(1214, 15, 60, 1077, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(1215, 15, 61, 1078, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(1216, 15, 62, 1079, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(1217, 15, 63, 1080, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(1218, 15, 59, 1116, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(1219, 15, 60, 1117, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(1220, 15, 61, 1118, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(1221, 15, 62, 1119, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(1222, 15, 63, 1120, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(1223, 15, 59, 1156, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(1224, 15, 60, 1157, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(1225, 15, 61, 1158, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(1226, 15, 62, 1159, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(1227, 15, 63, 1160, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(1228, 15, 59, 1196, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(1229, 15, 60, 1197, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(1230, 15, 61, 1198, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(1231, 15, 62, 1199, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(1232, 15, 63, 1200, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(1233, 15, 59, 1236, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(1234, 15, 60, 1237, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(1235, 15, 61, 1238, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(1236, 15, 62, 1239, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(1237, 15, 63, 1240, 1, '1', '2019-06-13', '1', '2019-06-12 18:30:00'),
(1238, 15, 59, 1276, 1, '1', '2019-06-13', '1', '2019-06-21 13:45:35'),
(1239, 15, 60, 1277, 1, '1', '2019-06-13', '1', '2019-06-21 13:45:35'),
(1240, 15, 61, 1278, 1, '1', '2019-06-13', '1', '2019-06-21 13:45:35'),
(1241, 15, 62, 1279, 1, '1', '2019-06-13', '1', '2019-06-21 13:45:35'),
(1242, 15, 63, 1280, 1, '1', '2019-06-13', '1', '2019-06-21 13:45:35'),
(1243, 15, 59, 1316, 1, '1', '2019-06-13', '1', '2019-06-21 13:45:35'),
(1244, 15, 60, 1232, 1, '1', '2019-06-13', '1', '2019-06-21 13:45:35'),
(1245, 15, 61, 1318, 1, '1', '2019-06-13', '1', '2019-06-21 13:45:35'),
(1246, 15, 62, 1319, 1, '1', '2019-06-13', '1', '2019-06-21 13:45:35'),
(1247, 15, 63, 1320, 1, '1', '2019-06-13', '1', '2019-06-21 13:45:35'),
(1248, 1, 1, 414, 1, '1', '2019-08-05', '', '2019-08-05 14:03:15'),
(1249, 1, 1, 416, 1, '1', '2019-08-05', '', '2019-08-05 14:03:15'),
(1250, 1, 2, 418, 1, '1', '2019-08-05', '', '2019-08-05 14:03:15'),
(1251, 1, 1, 419, 1, '1', '2019-08-05', '', '2019-08-05 14:03:15'),
(1252, 1, 1, 421, 1, '1', '2019-08-05', '', '2019-08-05 14:03:15'),
(1253, 1, 3, 422, 1, '1', '2019-08-05', '', '2019-08-05 14:03:15'),
(1254, 1, 2, 424, 1, '1', '2019-08-05', '', '2019-08-05 14:03:15'),
(1255, 1, 3, 425, 1, '1', '2019-08-05', '', '2019-08-05 14:03:15'),
(1256, 1, 2, 426, 1, '1', '2019-08-05', '', '2019-08-05 14:03:15'),
(1257, 1, 2, 429, 1, '1', '2019-08-05', '', '2019-08-05 14:03:15'),
(1258, 1, 2, 431, 1, '1', '2019-08-05', '', '2019-08-05 14:03:15'),
(1259, 1, 2, 432, 1, '1', '2019-08-05', '', '2019-08-05 14:03:15'),
(1260, 1, 2, 433, 1, '1', '2019-08-05', '', '2019-08-05 14:03:15'),
(1261, 1, 2, 434, 1, '1', '2019-08-05', '', '2019-08-05 14:03:15'),
(1262, 1, 2, 435, 1, '1', '2019-08-05', '', '2019-08-05 14:03:15'),
(1263, 1, 3, 439, 1, '1', '2019-08-05', '', '2019-08-05 14:03:15'),
(1264, 1, 3, 440, 1, '1', '2019-08-05', '', '2019-08-05 14:03:15'),
(1265, 1, 3, 516, 1, '1', '2019-08-05', '', '2019-08-05 14:03:15'),
(1266, 1, 2, 518, 1, '1', '2019-08-05', '', '2019-08-05 14:03:15'),
(1267, 1, 1, 594, 1, '1', '2019-08-05', '', '2019-08-05 14:03:15'),
(1268, 1, 1, 595, 1, '1', '2019-08-05', '', '2019-08-05 14:03:15'),
(1269, 1, 2, 597, 1, '1', '2019-08-05', '', '2019-08-05 14:03:15'),
(1270, 1, 2, 599, 1, '1', '2019-08-05', '', '2019-08-05 14:03:15'),
(1271, 1, 2, 601, 1, '1', '2019-08-05', '', '2019-08-05 14:03:15'),
(1272, 1, 2, 602, 1, '1', '2019-08-05', '', '2019-08-05 14:03:15'),
(1273, 1, 2, 603, 1, '1', '2019-08-05', '', '2019-08-05 14:03:15'),
(1274, 1, 2, 604, 1, '1', '2019-08-05', '', '2019-08-05 14:03:15'),
(1275, 1, 2, 605, 1, '1', '2019-08-05', '', '2019-08-05 14:03:15'),
(1276, 1, 2, 612, 1, '1', '2019-08-05', '', '2019-08-05 14:03:15'),
(1277, 1, 2, 613, 1, '1', '2019-08-05', '', '2019-08-05 14:03:15'),
(1278, 1, 2, 614, 1, '1', '2019-08-05', '', '2019-08-05 14:03:15'),
(1279, 1, 2, 615, 1, '1', '2019-08-05', '', '2019-08-05 14:03:15'),
(1280, 1, 3, 619, 1, '1', '2019-08-05', '', '2019-08-05 14:03:15'),
(1281, 1, 3, 620, 1, '1', '2019-08-05', '', '2019-08-05 14:03:15'),
(1282, 1, 3, 621, 1, '1', '2019-08-05', '', '2019-08-05 14:03:15'),
(1283, 1, 3, 624, 1, '1', '2019-08-05', '', '2019-08-05 14:03:15'),
(1284, 1, 3, 625, 1, '1', '2019-08-05', '', '2019-08-05 14:03:15'),
(1285, 2, 1, 464, 1, '1', '2019-08-05', '', '2019-08-05 14:03:15'),
(1286, 2, 1, 467, 1, '1', '2019-08-05', '', '2019-08-05 14:03:15'),
(1287, 2, 1, 469, 1, '1', '2019-08-05', '', '2019-08-05 14:03:15'),
(1288, 2, 1, 470, 1, '1', '2019-08-05', '', '2019-08-05 14:03:15'),
(1289, 2, 1, 471, 1, '1', '2019-08-05', '', '2019-08-05 14:03:15'),
(1290, 2, 3, 472, 1, '1', '2019-08-05', '', '2019-08-05 14:03:15'),
(1291, 2, 2, 474, 1, '1', '2019-08-05', '', '2019-08-05 14:03:15'),
(1292, 2, 3, 475, 1, '1', '2019-08-05', '', '2019-08-05 14:03:15'),
(1293, 2, 2, 476, 1, '1', '2019-08-05', '', '2019-08-05 14:03:15'),
(1294, 2, 2, 479, 1, '1', '2019-08-05', '', '2019-08-05 14:03:15'),
(1295, 2, 2, 481, 1, '1', '2019-08-05', '', '2019-08-05 14:03:15'),
(1296, 2, 2, 482, 1, '1', '2019-08-05', '', '2019-08-05 14:03:15'),
(1297, 2, 2, 483, 1, '1', '2019-08-05', '', '2019-08-05 14:03:15'),
(1298, 2, 2, 484, 1, '1', '2019-08-05', '', '2019-08-05 14:03:15'),
(1299, 2, 2, 485, 1, '1', '2019-08-05', '', '2019-08-05 14:03:15'),
(1300, 2, 3, 489, 1, '1', '2019-08-05', '', '2019-08-05 14:03:15'),
(1301, 2, 3, 490, 1, '1', '2019-08-05', '', '2019-08-05 14:03:15'),
(1302, 2, 1, 515, 1, '1', '2019-08-05', '', '2019-08-05 14:03:15'),
(1303, 2, 2, 517, 1, '1', '2019-08-05', '', '2019-08-05 14:03:15'),
(1304, 2, 1, 596, 1, '1', '2019-08-05', '', '2019-08-05 14:03:15'),
(1305, 2, 2, 598, 1, '1', '2019-08-05', '', '2019-08-05 14:03:15'),
(1306, 2, 2, 600, 1, '1', '2019-08-05', '', '2019-08-05 14:03:15'),
(1307, 2, 2, 606, 1, '1', '2019-08-05', '', '2019-08-05 14:03:15'),
(1308, 2, 2, 607, 1, '1', '2019-08-05', '', '2019-08-05 14:03:15'),
(1309, 2, 2, 608, 1, '1', '2019-08-05', '', '2019-08-05 14:03:15'),
(1310, 2, 2, 609, 1, '1', '2019-08-05', '', '2019-08-05 14:03:15'),
(1311, 2, 2, 610, 1, '1', '2019-08-05', '', '2019-08-05 14:03:15'),
(1312, 2, 2, 611, 1, '1', '2019-08-05', '', '2019-08-05 14:03:15'),
(1313, 2, 2, 616, 1, '1', '2019-08-05', '', '2019-08-05 14:03:15'),
(1314, 2, 2, 617, 1, '1', '2019-08-05', '', '2019-08-05 14:03:15'),
(1315, 2, 2, 618, 1, '1', '2019-08-05', '', '2019-08-05 14:03:15'),
(1316, 2, 3, 622, 1, '1', '2019-08-05', '', '2019-08-05 14:03:15'),
(1317, 2, 3, 623, 1, '1', '2019-08-05', '', '2019-08-05 14:03:15'),
(1318, 2, 3, 626, 1, '1', '2019-08-05', '', '2019-08-05 14:03:15'),
(1319, 2, 3, 627, 1, '1', '2019-08-05', '', '2019-08-05 14:03:15'),
(1320, 2, 3, 628, 1, '1', '2019-08-05', '', '2019-08-05 14:03:15');

-- --------------------------------------------------------

--
-- Table structure for table `config_master`
--

CREATE TABLE `config_master` (
  `id` int(11) NOT NULL,
  `code` varchar(40) NOT NULL,
  `value` int(11) NOT NULL,
  `status` varchar(40) NOT NULL,
  `type` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `config_master`
--

INSERT INTO `config_master` (`id`, `code`, `value`, `status`, `type`) VALUES
(1, 'SKILLKIT_NODAYSPLAY', 8, 'Y', 1),
(2, 'MAXTIMEOFPLAY', 2400, 'Y', 1),
(3, 'UTILIZATIONPERCENTAGE', 50, 'Y', 1),
(4, 'MINIMUM_SKILLSCORE', 45, 'Y', 1);

-- --------------------------------------------------------

--
-- Table structure for table `cycle_master`
--

CREATE TABLE `cycle_master` (
  `id` int(11) NOT NULL,
  `name` varchar(110) NOT NULL,
  `range_start` int(11) NOT NULL,
  `range_end` int(11) NOT NULL,
  `value` varchar(16) NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cycle_master`
--

INSERT INTO `cycle_master` (`id`, `name`, `range_start`, `range_end`, `value`, `status`) VALUES
(1, 'Detailed Assessment', 1, 8, '1-8', 1),
(2, 'Personalized Training - C1', 9, 16, '9-16', 1),
(3, 'Personalized Training - C2', 17, 24, '17-24', 1),
(4, 'Personalized Training - C3', 25, 32, '25-32', 1),
(5, 'Personalized Training - C4', 33, 40, '33-40', 1),
(6, 'Personalized Training - C5', 41, 48, '41-48', 1),
(7, 'Personalized Training - C6', 49, 56, '49-56', 1),
(8, 'Personalized Training - C7', 57, 64, '57-64', 1),
(9, 'Personalized Training - C8', 65, 72, '65-72', 1),
(10, 'Personalized Training - C9', 73, 80, '73-80', 1),
(11, 'Personalized Training - C10', 81, 88, '81-88', 1),
(12, 'Personalized Training - C11', 89, 96, '89-96', 1),
(13, 'Personalized Training - C12', 97, 104, '97-104', 1),
(14, 'Personalized Training - C13', 105, 112, '105-112', 1),
(15, 'Personalized Training - C14', 113, 120, '113-120', 1);

-- --------------------------------------------------------

--
-- Table structure for table `eod_mail_log`
--

CREATE TABLE `eod_mail_log` (
  `id` int(11) NOT NULL,
  `sid` int(11) NOT NULL,
  `sent_on` datetime NOT NULL,
  `status` int(11) NOT NULL COMMENT '0 => Not sent , 1 => Mail Sent'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `eom_report`
--

CREATE TABLE `eom_report` (
  `ID` int(11) NOT NULL,
  `School_id` int(11) NOT NULL,
  `Month_no` varchar(55) NOT NULL,
  `RCode` varchar(55) NOT NULL,
  `HdMessage` text NOT NULL,
  `FooMessage` text NOT NULL,
  `Status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `eom_report`
--

INSERT INTO `eom_report` (`ID`, `School_id`, `Month_no`, `RCode`, `HdMessage`, `FooMessage`, `Status`) VALUES
(1, 39, '04', 'SUMMARY', '<p><strong>Header Msg&nbsp;</strong></p>\n', '<p><strong>Footer Msg</strong></p>\n', 1),
(2, 38, '05', 'SUMMARY', 'SkillAngels', '<p>Skillangels New</p>\n', 1);

-- --------------------------------------------------------

--
-- Table structure for table `feedback_subject_master`
--

CREATE TABLE `feedback_subject_master` (
  `id` int(11) NOT NULL,
  `subject` varchar(100) NOT NULL,
  `status` enum('Y','N') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `feedback_subject_master`
--

INSERT INTO `feedback_subject_master` (`id`, `subject`, `status`) VALUES
(1, 'Game', 'Y'),
(2, 'Suggestion', 'Y'),
(3, 'Portal', 'Y'),
(4, 'Others', 'Y');

-- --------------------------------------------------------

--
-- Table structure for table `gamedata`
--

CREATE TABLE `gamedata` (
  `id` int(11) NOT NULL,
  `gu_id` int(10) NOT NULL,
  `gc_id` int(10) NOT NULL,
  `gs_id` int(10) NOT NULL,
  `gp_id` varchar(100) NOT NULL,
  `g_id` int(30) NOT NULL,
  `total_question` varchar(15) NOT NULL,
  `attempt_question` varchar(20) NOT NULL,
  `answer` varchar(20) NOT NULL,
  `game_score` varchar(50) NOT NULL,
  `gtime` varchar(100) NOT NULL,
  `rtime` varchar(100) NOT NULL,
  `crtime` varchar(100) NOT NULL,
  `wrtime` varchar(100) NOT NULL,
  `lastupdate` date NOT NULL,
  `createdby` varchar(100) NOT NULL,
  `creation_date` date NOT NULL,
  `created_date_time` datetime NOT NULL,
  `modifiedby` varchar(100) NOT NULL,
  `modified_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `Is_schedule` int(11) NOT NULL,
  `session_id` int(11) NOT NULL,
  `puzzle_cycle` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Stand-in structure for view `gamedata_updated`
-- (See below for the actual view)
--
CREATE TABLE `gamedata_updated` (
`id` int(11)
,`gu_id` int(10)
,`gs_id` int(10)
,`g_id` int(30)
,`que_id` int(11)
,`answer` varchar(20)
,`useranswer` varchar(55)
,`game_score` varchar(50)
,`answer_status` varchar(55)
,`timeoverstatus` int(11)
,`responsetime` int(11)
,`balancetime` int(11)
,`lastupdate` date
,`creation_date` date
,`modified_date` timestamp
,`puzzle_cycle` int(11)
);

-- --------------------------------------------------------

--
-- Table structure for table `games`
--

CREATE TABLE `games` (
  `gid` int(100) NOT NULL,
  `gc_id` int(100) NOT NULL,
  `gs_id` int(100) NOT NULL,
  `gname` varchar(100) NOT NULL,
  `path` varchar(500) NOT NULL,
  `descs` varchar(500) NOT NULL,
  `img_path` varchar(100) NOT NULL,
  `gstatus` int(1) NOT NULL,
  `gplans` varchar(100) NOT NULL,
  `createdby` varchar(100) NOT NULL,
  `creation_date` date NOT NULL,
  `modifiedby` varchar(100) NOT NULL,
  `modified_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `game_html` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `games`
--

INSERT INTO `games` (`gid`, `gc_id`, `gs_id`, `gname`, `path`, `descs`, `img_path`, `gstatus`, `gplans`, `createdby`, `creation_date`, `modifiedby`, `modified_date`, `game_html`) VALUES
(1, 2, 59, 'AlphaNumericEncode-Level1', 'uploads/AlphaNumericEncode-Level1_4518458847.swf', 'Memory', 'uploads/AlphaNumericEncode-Level1_4518458847.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'AlphaNumericEncode-Level1'),
(3, 2, 59, 'BusRide-Level1', 'uploads/BusRide-Level1_9721776302.swf', 'Memory', 'uploads/BusRide-Level1_9721776302.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'BusRide-Level1'),
(4, 2, 59, 'CycleRace-Level1', 'uploads/CycleRace-Level1_2532993447.swf', 'Memory', 'uploads/CycleRace-Level1_2532993447.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'CycleRace-Level1'),
(5, 2, 59, 'MemoryCheck-Level1', 'uploads/MemoryCheck-Level1_1938757994.swf', 'Memory', 'uploads/MemoryCheck-Level1_1938757994.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'MemoryCheck-Level1'),
(6, 2, 59, 'MindCapture-Level1', 'uploads/MindCapture-Level1_9870321140.swf', 'Memory', 'uploads/MindCapture-Level1_9870321140.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'MindCapture-Level1'),
(7, 2, 59, 'MomAndMe', 'uploads/MomAndMe_6942562656.swf', 'Memory', 'uploads/MomAndMe_6942562656.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'MomAndMe'),
(8, 2, 59, 'SequenceMemory-Level1', 'uploads/SequenceMemory-Level1_903124888.swf', 'Memory', 'uploads/SequenceMemory-Level1_903124888.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'SequenceMemory-Level1'),
(9, 2, 60, 'BestFit-Level3', 'uploads/BestFit-Level2_6896948479.swf', 'VP', 'uploads/BestFit-Level2_6896948479.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'BestFit-Level3'),
(10, 2, 60, 'CharacterShade-Level1', 'uploads/CharacterShade-Level1_3409011624.swf', 'VP', 'uploads/CharacterShade-Level1_3409011624.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'CharacterShade-Level1'),
(11, 2, 60, 'EdCells-Level1', 'uploads/EdCells-Level1_376414950.swf', 'VP', 'uploads/EdCells-Level1_376414950.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'EdCells-Level1'),
(12, 2, 60, 'EyeCells-Level1', 'uploads/EyeCells-Level1_7996039153.swf', 'VP', 'uploads/EyeCells-Level1_7996039153.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'EyeCells-Level1'),
(15, 2, 60, 'Face2Face-Level1', 'uploads/Face2Face-Level1_5178543743.swf', 'VP', 'uploads/Face2Face-Level1_5178543743.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'Face2Face-Level1'),
(16, 2, 60, 'MatchMe-Level1', 'uploads/MatchMe-Level1_3344377102.swf', 'VP', 'uploads/MatchMe-Level1_3344377102.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'MatchMe-Level1'),
(17, 2, 60, 'ObjectShade', 'uploads/ObjectShade_7239343100.swf', 'VP', 'uploads/ObjectShade_7239343100.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'ObjectShade'),
(18, 2, 60, 'WordWipe-Level1', 'uploads/WordWipe-Level1_7054595984.swf', 'VP', 'uploads/WordWipe-Level1_7054595984.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'WordWipe-Level1'),
(19, 2, 61, 'LetterJigsaw-Level1', 'uploads/AlphabetJigsaw-Level1_6780601199.swf', 'FA', 'uploads/AlphabetJigsaw-Level1_6780601199.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'LetterJigsaw-Level1'),
(20, 2, 61, 'DownUnder-Level1', 'uploads/DownUnder-Level1_9248090591.swf', 'FA', 'uploads/DownUnder-Level1_9248090591.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'DownUnder-Level1'),
(21, 2, 61, 'LastLegend-Level1', 'uploads/LastLegend-Level1_3132143379.swf', 'FA', 'uploads/LastLegend-Level1_3132143379.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'LastLegend-Level1'),
(22, 2, 61, 'NumberJigsaw-Level1', 'uploads/NumberJigsaw-Level1_3981064627.swf', 'FA', 'uploads/NumberJigsaw-Level1_3981064627.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'NumberJigsaw-Level1'),
(23, 2, 61, 'SpotMe-Level1', 'uploads/SpotMe-Level1_2213080883.swf', 'FA', 'uploads/SpotMe-Level1_2213080883.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'SpotMe-Level1'),
(24, 2, 61, 'StarLight-Level3', 'uploads/StarLight-Level1_9186881147.swf', 'FA', 'uploads/StarLight-Level1_9186881147.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'StarLight-Level3'),
(25, 2, 61, 'StrangerGrid-Level3', 'uploads/StrangerGrid_9728514011.swf', 'FA', 'uploads/StrangerGrid_9728514011.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'StrangerGrid-Level3'),
(26, 2, 61, 'WordSpell-Level1', 'uploads/WordSpell-Level1_4793716236.swf', 'FA', 'uploads/WordSpell-Level1_4793716236.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'WordSpell-Level1'),
(27, 2, 62, 'AddMaster-Level1', 'uploads/AddMaster-Level1_5437691258.swf', 'PS', 'uploads/AddMaster-Level1_5437691258.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'AddMaster-Level1'),
(28, 2, 62, 'HeavyOrLight-Level1', 'uploads/HeavyOrLight-Level1_9671432706.swf', 'PS', 'uploads/HeavyOrLight-Level1_9671432706.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'HeavyOrLight-Level1'),
(29, 2, 62, 'NumberDecode-Level1', 'uploads/NumberDecode-Level1_5552706075.swf', 'PS', 'uploads/NumberDecode-Level1_5552706075.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'NumberDecode-Level1'),
(30, 2, 62, 'NumbersOnTheWheel-Level1', 'uploads/NumbersOnTheWheel-Level1_5239142207.swf', 'PS', 'uploads/NumbersOnTheWheel-Level1_5239142207.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'NumbersOnTheWheel-Level1'),
(31, 2, 62, 'ParaMaster-Level1', 'uploads/ParaMaster-Level1_8246283596.swf', 'PS', 'uploads/ParaMaster-Level1_8246283596.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'ParaMaster-Level1'),
(32, 2, 62, 'Reshuffle-Level1', 'uploads/Reshuffle-Level1_9448890620.swf', 'PS', 'uploads/Reshuffle-Level1_9448890620.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'Reshuffle-Level1'),
(33, 2, 62, 'WhatComesNext', 'uploads/WhatComesNext_8895443235.swf', 'PS', 'uploads/WhatComesNext_8895443235.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'WhatComesNext'),
(34, 2, 62, 'WordShapes-Level1', 'uploads/WordShapes-Level1_5870673032.swf', 'PS', 'uploads/WordShapes-Level1_5870673032.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'WordShapes-Level1'),
(35, 2, 63, 'CompoundWords', 'uploads/CompoundWords_12777526.swf', 'L', 'uploads/CompoundWords_12777526.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'CompoundWords'),
(36, 2, 63, 'WhoAmI-Birds', 'uploads/WhoAmI-Birds_7869069152.swf', 'L', 'uploads/WhoAmI-Birds_7869069152.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'WhoAmI-Birds'),
(37, 2, 63, 'WhoAmI-Colors', 'uploads/WhoAmI-Colors_1446446431.swf', 'L', 'uploads/WhoAmI-Colors_1446446431.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'WhoAmI-Colors'),
(38, 2, 63, 'WhoAmI-DomesticAnimals', 'uploads/WhoAmI-DomesticAnimals_818332880.swf', 'L', 'uploads/WhoAmI-DomesticAnimals_818332880.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'WhoAmI-DomesticAnimals'),
(39, 2, 63, 'WhoAmI-Fruits', 'uploads/WhoAmI-Fruits_91387722.swf', 'L', 'uploads/WhoAmI-Fruits_91387722.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'WhoAmI-Fruits'),
(40, 2, 63, 'WhoAmI-HouseHoldThings', 'uploads/WhoAmI-HouseHoldThings_8783441544.swf', 'L', 'uploads/WhoAmI-HouseHoldThings_8783441544.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'WhoAmI-HouseHoldThings'),
(41, 2, 63, 'WhoAmI-Shapes', 'uploads/WhoAmI-Shapes_7515025790.swf', 'L', 'uploads/WhoAmI-Shapes_7515025790.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'WhoAmI-Shapes'),
(42, 2, 63, 'WhoAmI-Vegetables', 'uploads/WhoAmI-Vegetables_7871570191.swf', 'L', 'uploads/WhoAmI-Vegetables_7871570191.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'WhoAmI-Vegetables'),
(43, 2, 59, 'AlphaNumericEncode-Level2', 'uploads/AlphaNumericEncode-Level2_546242767.swf', 'M', 'uploads/AlphaNumericEncode-Level2_546242767.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'AlphaNumericEncode-Level2'),
(44, 2, 59, 'BalloonBurst-Level2', 'uploads/BalloonBurst-Level2_244336309.swf', 'M', 'uploads/BalloonBurst-Level2_244336309.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'BalloonBurst-Level2'),
(45, 2, 59, 'BusRide-Level2', 'uploads/BusRide-Level2_6232746895.swf', 'M', 'uploads/BusRide-Level2_6232746895.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'BusRide-Level2'),
(46, 2, 59, 'CycleRace-Level2', 'uploads/CycleRace-Level2_5460967603.swf', 'M', 'uploads/CycleRace-Level2_5460967603.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'CycleRace-Level2'),
(47, 2, 59, 'Fishing', 'uploads/Fishing_4694063616.swf', 'M', 'uploads/Fishing_4694063616.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'Fishing'),
(48, 2, 59, 'MemoryCheck-Level2', 'uploads/MemoryCheck-Level2_8882285202.swf', 'M', 'uploads/MemoryCheck-Level2_8882285202.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'MemoryCheck-Level2'),
(49, 2, 59, 'MindCapture-Level2', 'uploads/MindCapture-Level2_5165879982.swf', 'M', 'uploads/MindCapture-Level2_5165879982.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'MindCapture-Level2'),
(50, 2, 59, 'SequenceMemory-Level2', 'uploads/SequenceMemory-Level2_9874571016.swf', 'M', 'uploads/SequenceMemory-Level2_9874571016.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'SequenceMemory-Level2'),
(51, 2, 60, 'AlphaNumberRead', 'uploads/AlphaNumberRead_8101214673.swf', 'VP', 'uploads/AlphaNumberRead_8101214673.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'AlphaNumberRead'),
(52, 2, 60, 'BestFit-Level4', 'uploads/BestFit-Level3_8792649721.swf', 'VP', 'uploads/BestFit-Level3_8792649721.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'BestFit-Level4'),
(53, 2, 60, 'CharacterShade-Level2', 'uploads/CharacterShade-Level2_8845140137.swf', 'VP', 'uploads/CharacterShade-Level2_8845140137.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'CharacterShade-Level2'),
(54, 2, 60, 'EdCells-Level2', 'uploads/EdCells-Level2_812620040.swf', 'VP', 'uploads/EdCells-Level2_812620040.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'EdCells-Level2'),
(55, 2, 60, 'EyeCells-Level2', 'uploads/EyeCells-Level2_5889739277.swf', 'VP', 'uploads/EyeCells-Level2_5889739277.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'EyeCells-Level2'),
(56, 2, 60, 'Face2Face-Level2', 'uploads/Face2Face-Level2_9013552083.swf', 'VP', 'uploads/Face2Face-Level2_9013552083.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'Face2Face-Level2'),
(57, 2, 60, 'MatchMe-Level2', 'uploads/MatchMe-Level2_5947240493.swf', 'VP', 'uploads/MatchMe-Level2_5947240493.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'MatchMe-Level2'),
(58, 2, 60, 'WordWipe-Level2', 'uploads/WordWipe-Level2_4875887525.swf', 'VP', 'uploads/WordWipe-Level2_4875887525.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'WordWipe-Level2'),
(59, 2, 61, 'LetterJigsaw-Level2', 'uploads/AlphabetJigsaw-Level2_439756815.swf', 'FA', 'uploads/AlphabetJigsaw-Level2_439756815.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'LetterJigsaw-Level2'),
(60, 2, 61, 'AnimalSpell', 'uploads/AnimalSpell_5479293791.swf', 'FA', 'uploads/AnimalSpell_5479293791.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'AnimalSpell'),
(61, 2, 61, 'DownUnder-Level2', 'uploads/DownUnder-Level2_5347298909.swf', 'FA', 'uploads/DownUnder-Level2_5347298909.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'DownUnder-Level2'),
(62, 2, 61, 'LastLegend-Level2', 'uploads/LastLegend-Level2_5781244020.swf', 'FA', 'uploads/LastLegend-Level2_5781244020.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'LastLegend-Level2'),
(63, 2, 61, 'NumberJigsaw-Level2', 'uploads/NumberJigsaw-Level2_5454463027.swf', 'FA', 'uploads/NumberJigsaw-Level2_5454463027.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'NumberJigsaw-Level2'),
(64, 2, 61, 'ObjectSpell-Level1', 'uploads/ObjectSpell-Level1_6468444657.swf', 'FA', 'uploads/ObjectSpell-Level1_6468444657.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'ObjectSpell-Level1'),
(65, 2, 61, 'SpotMe-Level2', 'uploads/SpotMe-Level2_5270674000.swf', 'FA', 'uploads/SpotMe-Level2_5270674000.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'SpotMe-Level2'),
(66, 2, 61, 'StarLight-Level4', 'uploads/StarLight-Level2_988681958.swf', 'FA', 'uploads/StarLight-Level2_988681958.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'StarLight-Level4'),
(67, 2, 62, 'AddMaster-Level2', 'uploads/AddMaster-Level2_6791430432.swf', 'PS', 'uploads/AddMaster-Level2_6791430432.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'AddMaster-Level2'),
(68, 2, 62, 'ClockArithmetic', 'uploads/ClockArithmetic_6831587473.swf', 'PS', 'uploads/ClockArithmetic_6831587473.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'ClockArithmetic'),
(69, 2, 62, 'HeavyOrLight-Level2', 'uploads/HeavyOrLight-Level2_607259180.swf', 'PS', 'uploads/HeavyOrLight-Level2_607259180.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'HeavyOrLight-Level2'),
(70, 2, 62, 'NumberDecode-Level2', 'uploads/NumberDecode-Level2_2425581049.swf', 'PS', 'uploads/NumberDecode-Level2_2425581049.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'NumberDecode-Level2'),
(71, 2, 62, 'NumbersOnTheWheel-Level2', 'uploads/NumbersOnTheWheel-Level2_5032758838.swf', 'PS', 'uploads/NumbersOnTheWheel-Level2_5032758838.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'NumbersOnTheWheel-Level2'),
(72, 2, 62, 'ParaMaster-Level2', 'uploads/ParaMaster-Level2_9887385293.swf', 'PS', 'uploads/ParaMaster-Level2_9887385293.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'ParaMaster-Level2'),
(73, 2, 62, 'Reshuffle-Level2', 'uploads/Reshuffle-Level2_5333331595.swf', 'PS', 'uploads/Reshuffle-Level2_5333331595.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'Reshuffle-Level2'),
(74, 2, 62, 'WordShapes-Level2', 'uploads/WordShapes-Level2_2368690557.swf', 'PS', 'uploads/WordShapes-Level2_2368690557.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'WordShapes-Level2'),
(75, 2, 63, 'ArrangeTheWords-Level1', 'uploads/ArrangeTheWords-Level1_350359375.swf', 'L', 'uploads/ArrangeTheWords-Level1_350359375.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'ArrangeTheWords-Level1'),
(76, 2, 63, 'VowelMagic', 'uploads/VowelMagic_9324571550.swf', 'L', 'uploads/VowelMagic_9324571550.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'VowelMagic'),
(77, 2, 63, 'WhoAmI-Clothes', 'uploads/WhoAmI-Clothes_236435011.swf', 'L', 'uploads/WhoAmI-Clothes_236435011.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'WhoAmI-Clothes'),
(78, 2, 63, 'WhoAmI-Insects', 'uploads/WhoAmI-Insects_9486121060.swf', 'L', 'uploads/WhoAmI-Insects_9486121060.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'WhoAmI-Insects'),
(79, 2, 63, 'WhoAmI-School', 'uploads/WhoAmI-School_1506193187.swf', 'L', 'uploads/WhoAmI-School_1506193187.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'WhoAmI-School'),
(80, 2, 63, 'WhoAmI-SeaAnimals', 'uploads/WhoAmI-SeaAnimals_9400465255.swf', 'L', 'uploads/WhoAmI-SeaAnimals_9400465255.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'WhoAmI-SeaAnimals'),
(81, 2, 63, 'WhoAmI-Transport', 'uploads/WhoAmI-Transport_156703181.swf', 'L', 'uploads/WhoAmI-Transport_156703181.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'WhoAmI-Transport'),
(82, 2, 63, 'WhoAmI-WildAnimals', 'uploads/WhoAmI-WildAnimals_8843113635.swf', 'L', 'uploads/WhoAmI-WildAnimals_8843113635.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'WhoAmI-WildAnimals'),
(83, 2, 59, 'AlphaNumericEncode-Level3', 'uploads/AlphaNumericEncode-Level3_387589167.swf', 'M', 'uploads/AlphaNumericEncode-Level3_387589167.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'AlphaNumericEncode-Level3'),
(84, 2, 59, 'BalloonBurst-Level3', 'uploads/BalloonBurst-Level3_2492009233.swf', 'M', 'uploads/BalloonBurst-Level3_2492009233.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'BalloonBurst-Level3'),
(85, 2, 59, 'CycleRace-Level3', 'uploads/CycleRace-Level3_6173525671.swf', 'M', 'uploads/CycleRace-Level3_6173525671.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'CycleRace-Level3'),
(86, 2, 59, 'DialAnumber', 'uploads/DialANumber_8347820923.swf', 'M', 'uploads/DialANumber_8347820923.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'DialAnumber'),
(87, 2, 59, 'MemoryCheck-Level3', 'uploads/MemoryCheck-Level3_7822075057.swf', 'M', 'uploads/MemoryCheck-Level3_7822075057.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'MemoryCheck-Level3'),
(88, 2, 59, 'MindCapture-Level3', 'uploads/MindCapture-Level3_3766070040.swf', 'M', 'uploads/MindCapture-Level3_3766070040.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'MindCapture-Level3'),
(89, 2, 59, 'SequenceMemory-Level3', 'uploads/SequenceMemory-Level3_9452287289.swf', 'M', 'uploads/SequenceMemory-Level3_9452287289.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'SequenceMemory-Level3'),
(90, 2, 59, 'WhatsInStore-Level1', 'uploads/WhatsInStore-Level1_99412277.swf', 'M', 'uploads/WhatsInStore-Level1_99412277.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'WhatsInStore-Level1'),
(91, 2, 60, 'CharacterShade-Level3', 'uploads/CharacterShade-Level3_3322312142.swf', 'VP', 'uploads/CharacterShade-Level3_3322312142.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'CharacterShade-Level3'),
(92, 2, 60, 'EdCells-Level3', 'uploads/EdCells-Level3_4655870916.swf', 'VP', 'uploads/EdCells-Level3_4655870916.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'EdCells-Level3'),
(93, 2, 60, 'EyeCells-Level3', 'uploads/EyeCells-Level3_8897464917.swf', 'VP', 'uploads/EyeCells-Level3_8897464917.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'EyeCells-Level3'),
(94, 2, 60, 'Hand2Hand', 'uploads/Hand2Hand_5783699043.swf', 'VP', 'uploads/Hand2Hand_5783699043.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'Hand2Hand'),
(95, 2, 60, 'JustNotHalf-Level1', 'uploads/JustNotHalf-Level1_6506787771.swf', 'VP', 'uploads/JustNotHalf-Level1_6506787771.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'JustNotHalf-Level1'),
(96, 2, 60, 'MatchMe-Level3', 'uploads/MatchMe-Level3_3926392993.swf', 'VP', 'uploads/MatchMe-Level3_3926392993.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'MatchMe-Level3'),
(97, 2, 60, 'MirrorMatch-Level1', 'uploads/MirrorMatch-Level1_3191918600.swf', 'VP', 'uploads/MirrorMatch-Level1_3191918600.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'MirrorMatch-Level1'),
(98, 2, 60, 'MissingPiece-Level1', 'uploads/MissingPiece-Level1_5453919009.swf', 'VP', 'uploads/MissingPiece-Level1_5453919009.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'MissingPiece-Level1'),
(99, 2, 61, 'LetterJigsaw-Level3', 'uploads/AlphabetJigsaw-Level3_1882078954.swf', 'FA', 'uploads/AlphabetJigsaw-Level3_1882078954.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'LetterJigsaw-Level3'),
(100, 2, 61, 'BalloonWorks-Level1', 'uploads/BalloonWorks-Level1_1963271764.swf', 'FA', 'uploads/BalloonWorks-Level1_1963271764.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'BalloonWorks-Level1'),
(101, 2, 61, 'CarPark-Level1', 'uploads/CarPark-Level1_8054239703.swf', 'FA', 'uploads/CarPark-Level1_8054239703.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'CarPark-Level1'),
(102, 2, 61, 'DarkLight-Level1', 'uploads/DarkLight-Level1_1779258348.swf', 'FA', 'uploads/DarkLight-Level1_1779258348.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'DarkLight-Level1'),
(103, 2, 61, 'DeepUnder-Level1', 'uploads/DeepUnder-Level1_7213067221.swf', 'FA', 'uploads/DeepUnder-Level1_7213067221.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'DeepUnder-Level1'),
(104, 2, 61, 'LastLegend-Level3', 'uploads/LastLegend-Level3_5495434515.swf', 'FA', 'uploads/LastLegend-Level3_5495434515.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'LastLegend-Level3'),
(105, 2, 61, 'NumberJigsaw-Level3', 'uploads/NumberJigsaw-Level3_7143653305.swf', 'FA', 'uploads/NumberJigsaw-Level3_7143653305.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'NumberJigsaw-Level3'),
(106, 2, 61, 'ObjectSpell-Level2', 'uploads/ObjectSpell-Level2_9643486370.swf', 'FA', 'uploads/ObjectSpell-Level2_9643486370.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'ObjectSpell-Level2'),
(107, 2, 62, 'AddMaster-Level3', 'uploads/AddMaster-Level3_2056090440.swf', 'PS', 'uploads/AddMaster-Level3_2056090440.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'AddMaster-Level3'),
(108, 2, 62, 'ATeddyForATeddy-Level1', 'uploads/ATeddyForATeddy-Level1_5987485046.swf', 'PS', 'uploads/ATeddyForATeddy-Level1_5987485046.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'ATeddyForATeddy-Level1'),
(109, 2, 62, 'NumberSeries-Level1', 'uploads/NumberSeries-Level1_292791444.swf', 'PS', 'uploads/NumberSeries-Level1_292791444.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'NumberSeries-Level1'),
(110, 2, 62, 'NumbersOnTheWheel-Level3', 'uploads/NumbersOnTheWheel-Level3_7181768785.swf', 'PS', 'uploads/NumbersOnTheWheel-Level3_7181768785.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'NumbersOnTheWheel-Level3'),
(111, 2, 62, 'ParaMaster-Level3', 'uploads/ParaMaster-Level3_8316638404.swf', 'PS', 'uploads/ParaMaster-Level3_8316638404.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'ParaMaster-Level3'),
(112, 2, 62, 'Reshuffle-Level3', 'uploads/Reshuffle-Level3_2661516019.swf', 'PS', 'uploads/Reshuffle-Level3_2661516019.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'Reshuffle-Level3'),
(113, 2, 62, 'WordShapes-Level3', 'uploads/WordShapes-Level3_9543727268.swf', 'PS', 'uploads/WordShapes-Level3_9543727268.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'WordShapes-Level3'),
(114, 2, 62, 'WordWalls-Level1', 'uploads/WordWalls-Level1_1536627309.swf', 'PS', 'uploads/WordWalls-Level1_1536627309.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'WordWalls-Level1'),
(115, 2, 63, 'Anagrams-Animals', 'uploads/Anagrams-Animals_690025119.swf', 'L', 'uploads/Anagrams-Animals_690025119.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'Anagrams-Animals'),
(116, 2, 63, 'Anagrams-Body', 'uploads/Anagrams-Body_8010135167.swf', 'L', 'uploads/Anagrams-Body_8010135167.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'Anagrams-Body'),
(117, 2, 63, 'Anagrams-Clothes', 'uploads/Anagrams-Clothing_8464276143.swf', 'L', 'uploads/Anagrams-Clothing_8464276143.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'Anagrams-Clothes'),
(118, 2, 63, 'Anagrams-Colors', 'uploads/Anagrams-Colors_4401654419.swf', 'L', 'uploads/Anagrams-Colors_4401654419.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'Anagrams-Colors'),
(119, 2, 63, 'ArrangeTheWords-Level2', 'uploads/ArrangeTheWords-Level2_2614120254.swf', 'L', 'uploads/ArrangeTheWords-Level2_2614120254.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'ArrangeTheWords-Level2'),
(120, 2, 63, 'MissingLetter-Level1', 'uploads/MissingLetter-Level1_4396478235.swf', 'L', 'uploads/MissingLetter-Level1_4396478235.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'MissingLetter-Level1'),
(121, 2, 63, 'NameLand-Level1', 'uploads/NameLand-Level1_3850891082.swf', 'L', 'uploads/NameLand-Level1_3850891082.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'NameLand-Level1'),
(122, 2, 63, 'WhoAmI-Birthday', 'uploads/WhoAmI-Birthday_9790617101.swf', 'L', 'uploads/WhoAmI-Birthday_9790617101.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'WhoAmI-Birthday'),
(123, 2, 59, 'AlphaNumericEncode-Level4', 'uploads/AlphaNumericEncode-Level4_2667365404.swf', 'M', 'uploads/AlphaNumericEncode-Level4_2667365404.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'AlphaNumericEncode-Level4'),
(124, 2, 59, 'BackTrack-Level1', 'uploads/BackTrack-Level1_257858377.swf', 'M', 'uploads/BackTrack-Level1_257858377.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'BackTrack-Level1'),
(125, 2, 59, 'BalloonBurst-Level4', 'uploads/BalloonBurst-Level4_2785141328.swf', 'M', 'uploads/BalloonBurst-Level4_2785141328.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'BalloonBurst-Level4'),
(126, 2, 59, 'CycleRace-Level4', 'uploads/CycleRace-Level4_4780295565.swf', 'M', 'uploads/CycleRace-Level4_4780295565.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'CycleRace-Level4'),
(127, 2, 59, 'MemoryCheck-Level4', 'uploads/MemoryCheck-Level4_3053050003.swf', 'M', 'uploads/MemoryCheck-Level4_3053050003.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'MemoryCheck-Level4'),
(128, 2, 59, 'MindCapture-Level4', 'uploads/MindCapture-Level4_95845567.swf', 'M', 'uploads/MindCapture-Level4_95845567.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'MindCapture-Level4'),
(129, 2, 59, 'SequenceMemory-Level4', 'uploads/SequenceMemory-Level4_9387351195.swf', 'M', 'uploads/SequenceMemory-Level4_9387351195.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'SequenceMemory-Level4'),
(130, 2, 59, 'WhatsInStore-Level2', 'uploads/WhatsInStore-Level2_3776093176.swf', 'M', 'uploads/WhatsInStore-Level2_3776093176.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'WhatsInStore-Level2'),
(131, 2, 60, 'AnimalWipe', 'uploads/AnimalWipe_6567529789.swf', 'VP', 'uploads/AnimalWipe_6567529789.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'AnimalWipe'),
(132, 2, 60, 'CharacterShade-Level4', 'uploads/CharacterShade-Level4_7572658732.swf', 'VP', 'uploads/CharacterShade-Level4_7572658732.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'CharacterShade-Level4'),
(133, 2, 60, 'FindTheTwins-Level1', 'uploads/FindTheTwins-Level1_7979904958.swf', 'VP', 'uploads/FindTheTwins-Level1_7979904958.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'FindTheTwins-Level1'),
(134, 2, 60, 'JustNotHalf-Level2', 'uploads/JustNotHalf-Level2_2203953666.swf', 'VP', 'uploads/JustNotHalf-Level2_2203953666.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'JustNotHalf-Level2'),
(135, 2, 60, 'MirrorMatch-Level2', 'uploads/MirrorMatch-Level2_4265700853.swf', 'VP', 'uploads/MirrorMatch-Level2_4265700853.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'MirrorMatch-Level2'),
(136, 2, 60, 'MissingPiece-Level2', 'uploads/MissingPiece-Level2_9361892873.swf', 'VP', 'uploads/MissingPiece-Level2_9361892873.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'MissingPiece-Level2'),
(137, 2, 60, 'ReflectionRead-Level1', 'uploads/ReflectionRead-Level1_7608671374.swf', 'VP', 'uploads/ReflectionRead-Level1_7608671374.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'ReflectionRead-Level1'),
(138, 2, 60, 'ReverseReading-Level1', 'uploads/ReverseReading-Level1_3469542353.swf', 'VP', 'uploads/ReverseReading-Level1_3469542353.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'ReverseReading-Level1'),
(139, 2, 61, 'LetterJigsaw-Level4', 'uploads/AlphabetJigsaw-Level4_5252252509.swf', 'FA', 'uploads/AlphabetJigsaw-Level4_5252252509.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'LetterJigsaw-Level4'),
(140, 2, 61, 'BalloonWorks-Level2', 'uploads/BalloonWorks-Level2_3179936059.swf', 'FA', 'uploads/BalloonWorks-Level2_3179936059.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'BalloonWorks-Level2'),
(141, 2, 61, 'CarPark-Level2', 'uploads/CarPark-Level2_116904969.swf', 'FA', 'uploads/CarPark-Level2_116904969.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'CarPark-Level2'),
(142, 2, 61, 'DarkLight-Level2', 'uploads/DarkLight-Level2_7840619147.swf', 'FA', 'uploads/DarkLight-Level2_7840619147.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'DarkLight-Level2'),
(143, 2, 61, 'DeepUnder-Level2', 'uploads/DeepUnder-Level2_5933240540.swf', 'FA', 'uploads/DeepUnder-Level2_5933240540.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'DeepUnder-Level2'),
(144, 2, 61, 'LastLegend-Level4', 'uploads/LastLegend-Level4_3372493218.swf', 'FA', 'uploads/LastLegend-Level4_3372493218.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'LastLegend-Level4'),
(145, 2, 61, 'NumberJigsaw-Level4', 'uploads/NumberJigsaw-Level4_3807144016.swf', 'FA', 'uploads/NumberJigsaw-Level4_3807144016.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'NumberJigsaw-Level4'),
(146, 2, 61, 'SpotMe-Level3', 'uploads/SpotMe-Level3_4077972709.swf', 'FA', 'uploads/SpotMe-Level3_4077972709.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'SpotMe-Level3'),
(147, 2, 62, 'ATeddyForATeddy-Level2', 'uploads/ATeddyForATeddy-Level2_5931731625.swf', 'PS', 'uploads/ATeddyForATeddy-Level2_5931731625.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'ATeddyForATeddy-Level2'),
(148, 2, 62, 'FitMeRight-Level1', 'uploads/FitMeRight-Level1_9128276687.swf', 'PS', 'uploads/FitMeRight-Level1_9128276687.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'FitMeRight-Level1'),
(149, 2, 62, 'NumberSeries-Level2', 'uploads/NumberSeries-Level2_1761797624.swf', 'PS', 'uploads/NumberSeries-Level2_1761797624.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'NumberSeries-Level2'),
(150, 2, 62, 'NumbersOnTheWheel-Level4', 'uploads/NumbersOnTheWheel-Level4_1754132225.swf', 'PS', 'uploads/NumbersOnTheWheel-Level4_1754132225.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'NumbersOnTheWheel-Level4'),
(151, 2, 62, 'ParaMaster-Level4', 'uploads/ParaMaster-Level4_3163872654.swf', 'PS', 'uploads/ParaMaster-Level4_3163872654.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'ParaMaster-Level4'),
(152, 2, 62, 'Reshuffle-Level4', 'uploads/Reshuffle-Level4_4280022010.swf', 'PS', 'uploads/Reshuffle-Level4_4280022010.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'Reshuffle-Level4'),
(153, 2, 62, 'WordShapes-Level4', 'uploads/WordShapes-Level4_9880864322.swf', 'PS', 'uploads/WordShapes-Level4_9880864322.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'WordShapes-Level4'),
(154, 2, 62, 'WordWalls-Level2', 'uploads/WordWalls-Level2_7409162675.swf', 'PS', 'uploads/WordWalls-Level2_7409162675.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'WordWalls-Level2'),
(155, 2, 63, 'Anagrams-Food', 'uploads/Anagrams-Food_9358940329.swf', 'L', 'uploads/Anagrams-Food_9358940329.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'Anagrams-Food'),
(156, 2, 63, 'Anagrams-Math', 'uploads/Anagrams-Math_3996595479.swf', 'L', 'uploads/Anagrams-Math_3996595479.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'Anagrams-Math'),
(157, 2, 63, 'Anagrams-Plants', 'uploads/Anagrams-Plants_2974008941.swf', 'L', 'uploads/Anagrams-Plants_2974008941.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'Anagrams-Plants'),
(158, 2, 63, 'Anagrams-Vehicles', 'uploads/Anagrams-Vehicles_8503454732.swf', 'L', 'uploads/Anagrams-Vehicles_8503454732.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'Anagrams-Vehicles'),
(159, 2, 63, 'ArrangeTheWords-Level3', 'uploads/ArrangeTheWords-Level3_6521334904.swf', 'L', 'uploads/ArrangeTheWords-Level3_6521334904.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'ArrangeTheWords-Level3'),
(160, 2, 63, 'MissingLetter-Level2', 'uploads/MissingLetter-Level2_3469503405.swf', 'L', 'uploads/MissingLetter-Level2_3469503405.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'MissingLetter-Level2'),
(161, 2, 63, 'NameLand-Level2', 'uploads/NameLand-Level2_9281079615.swf', 'L', 'uploads/NameLand-Level2_9281079615.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'NameLand-Level2'),
(162, 2, 63, 'WhoAmI-Flowers', 'uploads/WhoAmI-Flowers_4361387616.swf', 'L', 'uploads/WhoAmI-Flowers_4361387616.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'WhoAmI-Flowers'),
(163, 2, 59, 'AlphaNumericEncode-Level5', 'uploads/AlphaNumericEncode-Level5_5666280859.swf', 'M', 'uploads/AlphaNumericEncode-Level5_5666280859.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'AlphaNumericEncode-Level5'),
(164, 2, 59, 'AnimalWatch-Level1', 'uploads/AnimalWatch-Level1_8736748136.swf', 'M', 'uploads/AnimalWatch-Level1_8736748136.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'AnimalWatch-Level1'),
(165, 2, 59, 'BackTrack-Level2', 'uploads/BackTrack-Level2_16276659.swf', 'M', 'uploads/BackTrack-Level2_16276659.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'BackTrack-Level2'),
(166, 2, 59, 'CycleRace-Level5', 'uploads/CycleRace-Level5_1506978459.swf', 'M', 'uploads/CycleRace-Level5_1506978459.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'CycleRace-Level5'),
(167, 2, 59, 'MemoryCheck-Level5', 'uploads/MemoryCheck-Level5_9116933126.swf', 'M', 'uploads/MemoryCheck-Level5_9116933126.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'MemoryCheck-Level5'),
(168, 2, 59, 'MindCapture-Level5', 'uploads/MindCapture-Level5_2807246898.swf', 'M', 'uploads/MindCapture-Level5_2807246898.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'MindCapture-Level5'),
(169, 2, 59, 'SequenceMemory-Level5', 'uploads/SequenceMemory-Level5_7487447718.swf', 'M', 'uploads/SequenceMemory-Level5_7487447718.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'SequenceMemory-Level5'),
(170, 2, 59, 'WhatsInStore-Level3', 'uploads/WhatsInStore-Level3_4075730568.swf', 'M', 'uploads/WhatsInStore-Level3_4075730568.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'WhatsInStore-Level3'),
(171, 2, 60, 'CubeSherlock-Level1', 'uploads/CubeSherlock-Level1_9494013660.swf', 'VP', 'uploads/CubeSherlock-Level1_9494013660.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'CubeSherlock-Level1'),
(172, 2, 60, 'FindTheTwins-Level2', 'uploads/FindTheTwins-Level2_3434965950.swf', 'VP', 'uploads/FindTheTwins-Level2_3434965950.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'FindTheTwins-Level2'),
(173, 2, 60, 'IAmCube-Level1', 'uploads/IAmCube-Level1_3901067436.swf', 'VP', 'uploads/IAmCube-Level1_3901067436.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'IAmCube-Level1'),
(174, 2, 60, 'JustNotHalf-Level3', 'uploads/JustNotHalf-Level3_486829234.swf', 'VP', 'uploads/JustNotHalf-Level3_486829234.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'JustNotHalf-Level3'),
(175, 2, 60, 'MirrorMatch-Level3', 'uploads/MirrorMatch-Level3_3233505128.swf', 'VP', 'uploads/MirrorMatch-Level3_3233505128.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'MirrorMatch-Level3'),
(176, 2, 60, 'MissingPiece-Level3', 'uploads/MissingPiece-Level3_1563094099.swf', 'VP', 'uploads/MissingPiece-Level3_1563094099.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'MissingPiece-Level3'),
(177, 2, 60, 'ReflectionRead-Level2', 'uploads/ReflectionRead-Level2_2878144294.swf', 'VP', 'uploads/ReflectionRead-Level2_2878144294.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'ReflectionRead-Level2'),
(178, 2, 60, 'ReverseReading-Level2', 'uploads/ReverseReading-Level2_7025720854.swf', 'VP', 'uploads/ReverseReading-Level2_7025720854.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'ReverseReading-Level2'),
(179, 2, 61, 'BalloonWorks-Level3', 'uploads/BalloonWorks-Level3_3529471680.swf', 'FA', 'uploads/BalloonWorks-Level3_3529471680.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'BalloonWorks-Level3'),
(180, 2, 61, 'CarPark-Level3', 'uploads/CarPark-Level3_5003174929.swf', 'FA', 'uploads/CarPark-Level3_5003174929.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'CarPark-Level3'),
(181, 2, 61, 'DarkLight-Level3', 'uploads/DarkLight-Level3_6337577155.swf', 'FA', 'uploads/DarkLight-Level3_6337577155.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'DarkLight-Level3'),
(182, 2, 61, 'DeepUnder-Level3', 'uploads/DeepUnder-Level3_9918525810.swf', 'FA', 'uploads/DeepUnder-Level3_9918525810.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'DeepUnder-Level3'),
(183, 2, 61, 'LastLegend-Level5', 'uploads/LastLegend-Level5_7495082467.swf', 'FA', 'uploads/LastLegend-Level5_7495082467.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'LastLegend-Level5'),
(184, 2, 61, 'Rainbow-Level1', 'uploads/Rainbow-Level1_1321175633.swf', 'FA', 'uploads/Rainbow-Level1_1321175633.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'Rainbow-Level1'),
(185, 2, 61, 'ShapeRollers-Level1', 'uploads/ShapeRollers-Level1_1497070817.swf', 'FA', 'uploads/ShapeRollers-Level1_1497070817.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'ShapeRollers-Level1'),
(186, 2, 61, 'SpotMe-Level4', 'uploads/SpotMe-Level4_1111856144.swf', 'FA', 'uploads/SpotMe-Level4_1111856144.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'SpotMe-Level4'),
(187, 2, 62, 'ATeddyForATeddy-Level3', 'uploads/ATeddyForATeddy-Level3_1824636519.swf', 'PS', 'uploads/ATeddyForATeddy-Level3_1824636519.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'ATeddyForATeddy-Level3'),
(188, 2, 62, 'ColorGuess', 'uploads/ColorGuess_7757099242.swf', 'PS', 'uploads/ColorGuess_7757099242.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'ColorGuess'),
(189, 2, 62, 'FitMeRight-Level2', 'uploads/FitMeRight-Level2_340231573.swf', 'PS', 'uploads/FitMeRight-Level2_340231573.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'FitMeRight-Level2'),
(190, 2, 62, 'HueCram', 'uploads/HueCram_438871416.swf', 'PS', 'uploads/HueCram_438871416.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'HueCram'),
(191, 2, 62, 'NumbersOnTheWheel-Level5', 'uploads/NumbersOnTheWheel-Level5_1027476550.swf', 'PS', 'uploads/NumbersOnTheWheel-Level5_1027476550.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'NumbersOnTheWheel-Level5'),
(192, 2, 62, 'ParaMaster-Level5', 'uploads/ParaMaster-Level5_5265605337.swf', 'PS', 'uploads/ParaMaster-Level5_5265605337.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'ParaMaster-Level5'),
(193, 2, 62, 'Reshuffle-Level5', 'uploads/Reshuffle-Level5_1823949897.swf', 'PS', 'uploads/Reshuffle-Level5_1823949897.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'Reshuffle-Level5'),
(194, 2, 62, 'TakeTurns-Level1', 'uploads/TakeTurns-Level1_1136886626.swf', 'PS', 'uploads/TakeTurns-Level1_1136886626.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'TakeTurns-Level1'),
(195, 2, 63, 'Anagrams-CountryNames', 'uploads/Anagrams-CountryNames_9848174657.swf', 'L', 'uploads/Anagrams-CountryNames_9848174657.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'Anagrams-CountryNames'),
(196, 2, 63, 'Anagrams-HouseHold', 'uploads/Anagrams-Household_4300776333.swf', 'L', 'uploads/Anagrams-Household_4300776333.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'Anagrams-HouseHold'),
(197, 2, 63, 'Anagrams-Schools', 'uploads/Anagrams-School_220320839.swf', 'L', 'uploads/Anagrams-School_220320839.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'Anagrams-Schools'),
(198, 2, 63, 'Anagrams-Sports', 'uploads/Anagrams-Sports_9202636964.swf', 'L', 'uploads/Anagrams-Sports_9202636964.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'Anagrams-Sports'),
(199, 2, 63, 'Anagrams-Weather', 'uploads/Anagrams-Weather_3403326552.swf', 'L', 'uploads/Anagrams-Weather_3403326552.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'Anagrams-Weather'),
(200, 2, 63, 'ArrangeTheWords-Level4', 'uploads/ArrangeTheWords-Level4_1263861129.swf', 'L', 'uploads/ArrangeTheWords-Level4_1263861129.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'ArrangeTheWords-Level4'),
(201, 2, 63, 'MissingLetter-Level3', 'uploads/MissingLetter-Level3_7274801447.swf', 'L', 'uploads/MissingLetter-Level3_7274801447.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'MissingLetter-Level3'),
(202, 2, 63, 'WordStem', 'uploads/WordStem_1920470679.swf', 'L', 'uploads/WordStem_1920470679.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'WordStem'),
(203, 2, 59, 'AlphaNumericEncode-Level6', 'uploads/AlphaNumericEncode-Level6_7225111038.swf', 'M', 'uploads/AlphaNumericEncode-Level6_7225111038.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'AlphaNumericEncode-Level6'),
(204, 2, 59, 'AnimalWatch-Level2', 'uploads/AnimalWatch-Level2_2552103889.swf', 'M', 'uploads/AnimalWatch-Level2_2552103889.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'AnimalWatch-Level2'),
(205, 2, 59, 'BackTrack-Level3', 'uploads/BackTrack-Level3_4500490999.swf', 'M', 'uploads/BackTrack-Level3_4500490999.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'BackTrack-Level3'),
(206, 2, 59, 'CycleRace-Level6', 'uploads/CycleRace-Level6_5745665873.swf', 'M', 'uploads/CycleRace-Level6_5745665873.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'CycleRace-Level6'),
(207, 2, 59, 'GraphDecoder', 'uploads/GraphDecoder_6767004569.swf', 'M', 'uploads/GraphDecoder_6767004569.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'GraphDecoder'),
(208, 2, 59, 'MemoryCheck-Level6', 'uploads/MemoryCheck-Level6_2935850583.swf', 'M', 'uploads/MemoryCheck-Level6_2935850583.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'MemoryCheck-Level6'),
(209, 2, 59, 'MindCapture-Level6', 'uploads/MindCapture-Level6_6117593380.swf', 'M', 'uploads/MindCapture-Level6_6117593380.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'MindCapture-Level6'),
(210, 2, 59, 'SequenceMemory-Level6', 'uploads/SequenceMemory-Level6_9447641619.swf', 'M', 'uploads/SequenceMemory-Level6_9447641619.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'SequenceMemory-Level6'),
(211, 2, 60, 'CubeSherlock-Level2', 'uploads/CubeSherlock-Level2_2803261997.swf', 'VP', 'uploads/CubeSherlock-Level2_2803261997.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'CubeSherlock-Level2'),
(212, 2, 60, 'FindTheTwins-Level3', 'uploads/FindTheTwins-Level3_8413515225.swf', 'VP', 'uploads/FindTheTwins-Level3_8413515225.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'FindTheTwins-Level3'),
(213, 2, 60, 'IAmCube-Level2', 'uploads/IAmCube-Level2_7666559526.swf', 'VP', 'uploads/IAmCube-Level2_7666559526.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'IAmCube-Level2'),
(214, 2, 60, 'JustNotHalf-Level4', 'uploads/JustNotHalf-Level4_2555441330.swf', 'VP', 'uploads/JustNotHalf-Level4_2555441330.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'JustNotHalf-Level4'),
(215, 2, 60, 'MirrorMatch-Level4', 'uploads/MirrorMatch-Level4_9751465697.swf', 'VP', 'uploads/MirrorMatch-Level4_9751465697.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'MirrorMatch-Level4'),
(216, 2, 60, 'MissingPiece-Level4', 'uploads/MissingPiece-Level4_1507440302.swf', 'VP', 'uploads/MissingPiece-Level4_1507440302.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'MissingPiece-Level4'),
(217, 2, 60, 'ReflectionRead-Level3', 'uploads/ReflectionRead-Level3_7118542841.swf', 'VP', 'uploads/ReflectionRead-Level3_7118542841.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'ReflectionRead-Level3'),
(218, 2, 60, 'ReverseReading-Level3', 'uploads/ReverseReading-Level3_5393561688.swf', 'VP', 'uploads/ReverseReading-Level3_5393561688.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'ReverseReading-Level3'),
(219, 2, 61, 'CarPark-Level4', 'uploads/CarPark-Level4_5836739456.swf', 'FA', 'uploads/CarPark-Level4_5836739456.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'CarPark-Level4'),
(220, 2, 61, 'DarkLight-Level4', 'uploads/DarkLight-Level4_4173842570.swf', 'FA', 'uploads/DarkLight-Level4_4173842570.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'DarkLight-Level4'),
(221, 2, 61, 'DeepUnder-Level4', 'uploads/DeepUnder-Level4_8108292836.swf', 'FA', 'uploads/DeepUnder-Level4_8108292836.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'DeepUnder-Level4'),
(222, 2, 61, 'DiscretePadle-Level1', 'uploads/DiscretePadle-Level1_2005080394.swf', 'FA', 'uploads/DiscretePadle-Level1_2005080394.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'DiscretePadle-Level1'),
(223, 2, 61, 'Rainbow-Level2', 'uploads/Rainbow-Level2_2451191339.swf', 'FA', 'uploads/Rainbow-Level2_2451191339.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'Rainbow-Level2'),
(224, 2, 61, 'ShapeRollers-Level2', 'uploads/ShapeRollers-Level2_5863707675.swf', 'FA', 'uploads/ShapeRollers-Level2_5863707675.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'ShapeRollers-Level2'),
(225, 2, 61, 'ShapeVsColor', 'uploads/ShapeVsColor_5882827830.swf', 'FA', 'uploads/ShapeVsColor_5882827830.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'ShapeVsColor'),
(226, 2, 61, 'SpotMe-Level5', 'uploads/SpotMe-Level5_2089167693.swf', 'FA', 'uploads/SpotMe-Level5_2089167693.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'SpotMe-Level5'),
(227, 2, 62, 'AnalogyAction-Level1', 'uploads/AnalogyAction-Level1_6299363239.swf', 'PS', 'uploads/AnalogyAction-Level1_6299363239.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'AnalogyAction-Level1'),
(228, 2, 62, 'NumberPuzzle-Level1', 'uploads/NumberPuzzle-Level1_222259401.swf', 'PS', 'uploads/NumberPuzzle-Level1_222259401.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'NumberPuzzle-Level1'),
(229, 2, 62, 'NumbersOnTheWheel-Level6', 'uploads/NumbersOnTheWheel-Level6_2458961391.swf', 'PS', 'uploads/NumbersOnTheWheel-Level6_2458961391.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'NumbersOnTheWheel-Level6'),
(230, 2, 62, 'ParaMaster-Level6', 'uploads/ParaMaster-Level6_4617435368.swf', 'PS', 'uploads/ParaMaster-Level6_4617435368.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'ParaMaster-Level6'),
(231, 2, 62, 'Reshuffle-Level6', 'uploads/Reshuffle-Level6_4803005247.swf', 'PS', 'uploads/Reshuffle-Level6_4803005247.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'Reshuffle-Level6'),
(232, 2, 62, 'SequenceGrid', 'uploads/SequenceGrid_9023916260.swf', 'PS', 'uploads/SequenceGrid_9023916260.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'SequenceGrid'),
(233, 2, 62, 'SmartRider', 'uploads/SmartRider_1083469698.swf', 'PS', 'uploads/SmartRider_1083469698.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'SmartRider'),
(234, 2, 62, 'TakeTurns-Level2', 'uploads/TakeTurns-Level2_7725315545.swf', 'PS', 'uploads/TakeTurns-Level2_7725315545.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'TakeTurns-Level2'),
(235, 2, 63, 'Anagrams-DolchWords', 'uploads/Anagrams-DolchWords_4271674626.swf', 'L', 'uploads/Anagrams-DolchWords_4271674626.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'Anagrams-DolchWords'),
(236, 2, 63, 'Anagrams-FourLetterWord', 'uploads/Anagrams-FourLetterWords_96878870.swf', 'L', 'uploads/Anagrams-FourLetterWords_96878870.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'Anagrams-FourLetterWord'),
(237, 2, 63, 'Anagrams-Geography', 'uploads/Anagrams-Geography_5710392687.swf', 'L', 'uploads/Anagrams-Geography_5710392687.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'Anagrams-Geography'),
(238, 2, 63, 'Anagrams-Jobs', 'uploads/Anagrams-Jobs_2256901105.swf', 'L', 'uploads/Anagrams-Jobs_2256901105.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'Anagrams-Jobs'),
(239, 2, 63, 'Anagrams-Military', 'uploads/Anagrams-Military_2205101763.swf', 'L', 'uploads/Anagrams-Military_2205101763.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'Anagrams-Military'),
(240, 2, 63, 'Anagrams-People', 'uploads/Anagrams-People_1156277623.swf', 'L', 'uploads/Anagrams-People_1156277623.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'Anagrams-People'),
(241, 2, 63, 'ArrangeTheWords-Level5', 'uploads/ArrangeTheWords-Level5_4423534446.swf', 'L', 'uploads/ArrangeTheWords-Level5_4423534446.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'ArrangeTheWords-Level5'),
(242, 2, 63, 'MissingLetter-Level4', 'uploads/MissingLetter-Level4_7994128023.swf', 'L', 'uploads/MissingLetter-Level4_7994128023.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'MissingLetter-Level4'),
(243, 2, 59, 'BallAndBox-Level1', 'uploads/BallAndBox-Level1_3074306286.swf', 'M', 'uploads/BallAndBox-Level1_3074306286.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'BallAndBox-Level1'),
(244, 2, 59, 'BugSpot-Level1', 'uploads/BugSpot-Level1_4068491952.swf', 'M', 'uploads/BugSpot-Level1_4068491952.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'BugSpot-Level1'),
(245, 2, 59, 'CoordinateGraph-Level1', 'uploads/CoordinateGraph-Level1_1309713018.swf', 'M', 'uploads/CoordinateGraph-Level1_1309713018.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'CoordinateGraph-Level1'),
(246, 2, 59, 'DropBox-Level1', 'uploads/DropBox-Level1_6700938204.swf', 'M', 'uploads/DropBox-Level1_6700938204.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'DropBox-Level1'),
(247, 2, 59, 'MisplacedBuddy-Level1', 'uploads/MisplacedBuddy-Level1_4661093535.swf', 'M', 'uploads/MisplacedBuddy-Level1_4661093535.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'MisplacedBuddy-Level1'),
(248, 2, 59, 'RouteMemory-Level1', 'uploads/RouteMemory-Level1_3141601332.swf', 'M', 'uploads/RouteMemory-Level1_3141601332.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'RouteMemory-Level1'),
(249, 2, 59, 'SequenceMemory-Level7', 'uploads/SequenceMemory-Level7_6659360751.swf', 'M', 'uploads/SequenceMemory-Level7_6659360751.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'SequenceMemory-Level7'),
(250, 2, 59, 'SpotMyPlace-Level1', 'uploads/SpotMyPlace-Level1_8555905618.swf', 'M', 'uploads/SpotMyPlace-Level1_8555905618.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'SpotMyPlace-Level1'),
(251, 2, 60, 'ChooseTwoToMakeOne', 'uploads/ChooseTwoToMakeOne_7422157558.swf', 'VP', 'uploads/ChooseTwoToMakeOne_7422157558.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'ChooseTwoToMakeOne'),
(252, 2, 60, 'FlipTrick-Level1', 'uploads/FlipTrick-Level1_6290403776.swf', 'VP', 'uploads/FlipTrick-Level1_6290403776.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'FlipTrick-Level1');
INSERT INTO `games` (`gid`, `gc_id`, `gs_id`, `gname`, `path`, `descs`, `img_path`, `gstatus`, `gplans`, `createdby`, `creation_date`, `modifiedby`, `modified_date`, `game_html`) VALUES
(253, 2, 60, 'FormTheSquare-Level1', 'uploads/FormTheSquare-Level1_9003437426.swf', 'VP', 'uploads/FormTheSquare-Level1_9003437426.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'FormTheSquare-Level1'),
(254, 2, 60, 'MirrorImage-Level1', 'uploads/MirrorImage-Level1_4596876199.swf', 'VP', 'uploads/MirrorImage-Level1_4596876199.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'MirrorImage-Level1'),
(255, 2, 60, 'ReflectionRead-Level4', 'uploads/ReflectionRead-Level4_4669125583.swf', 'VP', 'uploads/ReflectionRead-Level4_4669125583.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'ReflectionRead-Level4'),
(256, 2, 60, 'ReverseReading-Level4', 'uploads/ReverseReading-Level4_3547282922.swf', 'VP', 'uploads/ReverseReading-Level4_3547282922.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'ReverseReading-Level4'),
(257, 2, 60, 'WaterImage-Level1', 'uploads/WaterImage-Level1_4578736186.swf', 'VP', 'uploads/WaterImage-Level1_4578736186.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'WaterImage-Level1'),
(258, 2, 60, 'WhoIsNotThere-Level1', 'uploads/WhoIsNotThere-Level1_3340305127.swf', 'VP', 'uploads/WhoIsNotThere-Level1_3340305127.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'WhoIsNotThere-Level1'),
(259, 2, 61, 'ColorInColor-Level1', 'uploads/ColorInColor-Level1_1204938488.swf', 'FA', 'uploads/ColorInColor-Level1_1204938488.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'ColorInColor-Level1'),
(260, 2, 61, 'DarkLight-Level5', 'uploads/DarkLight-Level5_4619532418.swf', 'FA', 'uploads/DarkLight-Level5_4619532418.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'DarkLight-Level5'),
(261, 2, 61, 'DiscretePaddle-Level2', 'uploads/DiscretePadle-Level2_4007870662.swf', 'FA', 'uploads/DiscretePadle-Level2_4007870662.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'DiscretePaddle-Level2'),
(262, 2, 61, 'NumberMe-Level1', 'uploads/NumberMe-Level1_9366972525.swf', 'FA', 'uploads/NumberMe-Level1_9366972525.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'NumberMe-Level1'),
(263, 2, 61, 'OddBall-Level1', 'uploads/OddBall-Level1_1096781706.swf', 'FA', 'uploads/OddBall-Level1_1096781706.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'OddBall-Level1'),
(264, 2, 61, 'ShapeRollers-Level3', 'uploads/ShapeRollers-Level3_6991897872.swf', 'FA', 'uploads/ShapeRollers-Level3_6991897872.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'ShapeRollers-Level3'),
(265, 2, 61, 'ShapeVsColorVsPattern-Level1', 'uploads/ShapeVsColorVsPattern-Level1_9182052793.swf', 'FA', 'uploads/ShapeVsColorVsPattern-Level1_9182052793.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'ShapeVsColorVsPattern-Level1'),
(266, 2, 61, 'SpotMe-Level6', 'uploads/SpotMe-Level6_7799745416.swf', 'FA', 'uploads/SpotMe-Level6_7799745416.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'SpotMe-Level6'),
(267, 2, 62, 'AnalogyAction-Level2', 'uploads/AnalogyAction-Level2_5585269308.swf', 'PS', 'uploads/AnalogyAction-Level2_5585269308.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'AnalogyAction-Level2'),
(268, 2, 62, 'Equate-Level1', 'uploads/Equate-Level1_3846404044.swf', 'PS', 'uploads/Equate-Level1_3846404044.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'Equate-Level1'),
(269, 2, 62, 'MasterVenn-Level1', 'uploads/MasterVenn-Level1_7031834167.swf', 'PS', 'uploads/MasterVenn-Level1_7031834167.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'MasterVenn-Level1'),
(270, 2, 62, 'NittyGritty', 'uploads/NittyGritty_5187215218.swf', 'PS', 'uploads/NittyGritty_5187215218.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'NittyGritty'),
(271, 2, 62, 'NumberPuzzle-Level2', 'uploads/NumberPuzzle-Level2_6727183759.swf', 'PS', 'uploads/NumberPuzzle-Level2_6727183759.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'NumberPuzzle-Level2'),
(272, 2, 62, 'NumbersOnTheVertices-Level1', 'uploads/NumbersOnTheVertices-Level1_6839827257.swf', 'PS', 'uploads/NumbersOnTheVertices-Level1_6839827257.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'NumbersOnTheVertices-Level1'),
(273, 2, 62, 'Shopping-Level1', 'uploads/Shopping-Level1_6256451136.swf', 'PS', 'uploads/Shopping-Level1_6256451136.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'Shopping-Level1'),
(274, 2, 62, 'TakeTurns-Level3', 'uploads/TakeTurns-Level3_8987652403.swf', 'PS', 'uploads/TakeTurns-Level3_8987652403.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'TakeTurns-Level3'),
(275, 2, 63, 'ConfusionGalore-Level1', 'uploads/ConfusionGalore-Level1_4439043053.swf', 'L', 'uploads/ConfusionGalore-Level1_4439043053.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'ConfusionGalore-Level1'),
(276, 2, 63, 'DividedWords-Level1', 'uploads/DividedWords-Level1_9592156563.swf', 'L', 'uploads/DividedWords-Level1_9592156563.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'DividedWords-Level1'),
(277, 2, 63, 'GuessTheWord-Level1', 'uploads/GuessTheWord-Level1_8028972977.swf', 'L', 'uploads/GuessTheWord-Level1_8028972977.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'GuessTheWord-Level1'),
(278, 2, 63, 'HomoPhones-Level1', 'uploads/HomoPhones-Level1_1627698740.swf', 'L', 'uploads/HomoPhones-Level1_1627698740.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'HomoPhones-Level1'),
(279, 2, 63, 'JumbledLetters-Level1', 'uploads/JumbledLetters-Level1_7572877304.swf', 'L', 'uploads/JumbledLetters-Level1_7572877304.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'JumbledLetters-Level1'),
(280, 2, 63, 'KangarooWords', 'uploads/KangarooWords_1111639351.swf', 'L', 'uploads/KangarooWords_1111639351.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'KangarooWords'),
(281, 2, 63, 'Rebus-Level1', 'uploads/Rebus-Level1_8831456145.swf', 'L', 'uploads/Rebus-Level1_8831456145.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'Rebus-Level1'),
(282, 2, 63, 'RootWords-Level1', 'uploads/RootWords-Level1_8710642922.swf', 'L', 'uploads/RootWords-Level1_8710642922.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'RootWords-Level1'),
(283, 2, 59, 'BallAndBox-Level2', 'uploads/BallAndBox-Level2_5648189471.swf', 'M', 'uploads/BallAndBox-Level2_5648189471.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'BallAndBox-Level2'),
(284, 2, 59, 'BugSpot-Level2', 'uploads/BugSpot-Level2_807683826.swf', 'M', 'uploads/BugSpot-Level2_807683826.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'BugSpot-Level2'),
(285, 2, 59, 'CoordinateGraph-Level2', 'uploads/CoordinateGraph-Level2_2700936608.swf', 'M', 'uploads/CoordinateGraph-Level2_2700936608.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'CoordinateGraph-Level2'),
(286, 2, 59, 'DropBox-Level2', 'uploads/DropBox-Level2_6796904369.swf', 'M', 'uploads/DropBox-Level2_6796904369.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'DropBox-Level2'),
(287, 2, 59, 'MisplacedBuddy-Level2', 'uploads/MisplacedBuddy-Level2_2612883471.swf', 'M', 'uploads/MisplacedBuddy-Level2_2612883471.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'MisplacedBuddy-Level2'),
(288, 2, 59, 'RouteMemory-Level2', 'uploads/RouteMemory-Level2_3784374403.swf', 'M', 'uploads/RouteMemory-Level2_3784374403.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'RouteMemory-Level2'),
(289, 2, 59, 'SequenceMemory-Level8', 'uploads/SequenceMemory-Level8_6523781293.swf', 'M', 'uploads/SequenceMemory-Level8_6523781293.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'SequenceMemory-Level8'),
(290, 2, 59, 'SpotMyPlace-Level2', 'uploads/SpotMyPlace-Level2_128739713.swf', 'M', 'uploads/SpotMyPlace-Level2_128739713.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'SpotMyPlace-Level2'),
(291, 2, 60, 'ChooseThreeToMakeOne-Level2', 'uploads/ChooseThreeToMakeOne_6421778858.swf', 'VP', 'uploads/ChooseThreeToMakeOne_6421778858.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'ChooseThreeToMakeOne-Level2'),
(292, 2, 60, 'FlipTrick-Level2', 'uploads/FlipTrick-Level2_2970519540.swf', 'VP', 'uploads/FlipTrick-Level2_2970519540.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'FlipTrick-Level2'),
(293, 2, 60, 'FormTheSquare-Level2', 'uploads/FormTheSquare-Level2_925395623.swf', 'VP', 'uploads/FormTheSquare-Level2_925395623.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'FormTheSquare-Level2'),
(294, 2, 60, 'MirrorImage-Level2', 'uploads/MirrorImage-Level2_8513625911.swf', 'M', 'uploads/MirrorImage-Level2_8513625911.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'MirrorImage-Level2'),
(295, 2, 60, 'ReflectionRead-Level5', 'uploads/ReflectionRead-Level5_3237627618.swf', 'M', 'uploads/ReflectionRead-Level5_3237627618.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'ReflectionRead-Level5'),
(296, 2, 60, 'ReverseReading-Level5', 'uploads/ReverseReading-Level5_5669675888.swf', 'VP', 'uploads/ReverseReading-Level5_5669675888.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'ReverseReading-Level5'),
(297, 2, 60, 'WaterImage-Level2', 'uploads/WaterImage-Level2_3779711904.swf', 'VP', 'uploads/WaterImage-Level2_3779711904.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'WaterImage-Level2'),
(298, 2, 60, 'WhoIsNotThere-Level2', 'uploads/WhoIsNotThere-Level2_67013050.swf', 'VP', 'uploads/WhoIsNotThere-Level2_67013050.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'WhoIsNotThere-Level2'),
(299, 2, 61, 'ColorInColor-Level2', 'uploads/ColorInColor-Level2_4620457286.swf', 'FA', 'uploads/ColorInColor-Level2_4620457286.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'ColorInColor-Level2'),
(300, 2, 61, 'DarkLight-Level6', 'uploads/DarkLight-Level6_8921038703.swf', 'FA', 'uploads/DarkLight-Level6_8921038703.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'DarkLight-Level6'),
(301, 2, 61, 'DiscretePaddle-Level3', 'uploads/DiscretePadle-Level3_3544559371.swf', 'FA', 'uploads/DiscretePadle-Level3_3544559371.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'DiscretePaddle-Level3'),
(302, 2, 61, 'NumberMe-Level2', 'uploads/NumberMe-Level2_1924527920.swf', 'FA', 'uploads/NumberMe-Level2_1924527920.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'NumberMe-Level2'),
(303, 2, 61, 'OddBall-Level2', 'uploads/OddBall-Level2_3363969377.swf', 'FA', 'uploads/OddBall-Level2_3363969377.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'OddBall-Level2'),
(304, 2, 61, 'ShapeRollers-Level4', 'uploads/ShapeRollers-Level4_452656652.swf', 'FA', 'uploads/ShapeRollers-Level4_452656652.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'ShapeRollers-Level4'),
(306, 2, 61, 'ShapeVsColorVsPattern-Level2', 'uploads/ShapeVsColorVsPattern-Level2_533262947.swf', 'FA', 'uploads/ShapeVsColorVsPattern-Level2_533262947.png', 0, '', '', '2014-06-18', '', '2019-08-05 11:01:04', 'ShapeVsColorVsPattern-Level2'),
(307, 2, 61, 'SpotMe-Level7', 'uploads/SpotMe-Level7_2691923594.swf', 'FA', 'uploads/SpotMe-Level7_2691923594.png', 0, '', '', '2014-06-18', '', '2019-08-05 11:01:04', 'SpotMe-Level7'),
(308, 2, 62, 'AnalogyAction-Level3', 'uploads/AnalogyAction-Level3_1947425035.swf', 'PS', 'uploads/AnalogyAction-Level3_1947425035.png', 0, '', '', '2014-06-18', '', '2019-08-05 11:01:04', 'AnalogyAction-Level3'),
(309, 2, 62, 'Equate-Level2', 'uploads/Equate-Level2_6867011720.swf', 'PS', 'uploads/Equate-Level2_6867011720.png', 0, '', '', '2014-06-18', '', '2019-08-05 11:01:04', 'Equate-Level2'),
(310, 2, 62, 'LogicalSequence', 'uploads/LogicalSequence_3583530234.swf', 'PS', 'uploads/LogicalSequence_3583530234.png', 0, '', '', '2014-06-18', '', '2019-08-05 11:01:04', 'LogicalSequence'),
(311, 2, 62, 'MasterVenn-Level2', 'uploads/MasterVenn-Level2_6223853942.swf', 'PS', 'uploads/MasterVenn-Level2_6223853942.png', 0, '', '', '2014-06-18', '', '2019-08-05 11:01:04', 'MasterVenn-Level2'),
(312, 2, 62, 'NumberPuzzle-Level3', 'uploads/NumberPuzzle-Level3_4147070031.swf', 'PS', 'uploads/NumberPuzzle-Level3_4147070031.png', 0, '', '', '2014-06-18', '', '2019-08-05 11:01:04', 'NumberPuzzle-Level3'),
(313, 2, 62, 'NumbersOnTheVertices-Level2', 'uploads/NumbersOnTheVertices-Level2_1932858121.swf', 'PS', 'uploads/NumbersOnTheVertices-Level2.png', 0, '', '', '2014-06-18', '', '2019-08-05 11:01:04', 'NumbersOnTheVertices-Level2'),
(314, 2, 62, 'Shopping-Level2', 'uploads/Shopping-Level2_4992981352.swf', 'PS', 'uploads/Shopping-Level2_4992981352.png', 0, '', '', '2014-06-18', '', '2019-08-05 11:01:04', 'Shopping-Level2'),
(315, 2, 62, 'TakeTurns-Level4', 'uploads/TakeTurns-Level4_4899050295.swf', 'PS', 'uploads/TakeTurns-Level4_4899050295.png', 0, '', '', '2014-06-18', '', '2019-08-05 11:01:04', 'TakeTurns-Level4'),
(316, 2, 63, 'ConfusionGalore-Level2', 'uploads/ConfusionGalore-Level2_9538272568.swf', 'L', 'uploads/ConfusionGalore-Level2_9538272568.png', 0, '', '', '2014-06-18', '', '2019-08-05 11:01:04', 'ConfusionGalore-Level2'),
(317, 2, 63, 'DividedWords-Level2', 'uploads/DividedWords-Level2_482863192.swf', 'L', 'uploads/DividedWords-Level2_482863192.png', 0, '', '', '2014-06-18', '', '2019-08-05 11:01:04', 'DividedWords-Level2'),
(318, 2, 63, 'GuessTheWord-Level2', 'uploads/GuessTheWord-Level2_718786111.swf', 'L', 'uploads/GuessTheWord-Level2_718786111.png', 0, '', '', '2014-06-18', '', '2019-08-05 11:01:04', 'GuessTheWord-Level2'),
(319, 2, 63, 'Homophones-Level2', 'uploads/HomoPhones-Level2_3726777150.swf', 'L', 'uploads/HomoPhones-Level2_3726777150.png', 0, '', '', '2014-06-18', '', '2019-08-05 11:01:04', 'Homophones-Level2'),
(320, 2, 63, 'JumbledLetters-Level2', 'uploads/JumbledLetters-Level2_497916364.swf', 'L', 'uploads/JumbledLetters-Level2_497916364.png', 0, '', '', '2014-06-18', '', '2019-08-05 11:01:04', 'JumbledLetters-Level2'),
(321, 2, 63, 'PrefixRootAndSuffix', 'uploads/PrefixRootAndSuffix_204385071.swf', 'L', 'uploads/PrefixRootAndSuffix_204385071.png', 0, '', '', '2014-06-18', '', '2019-08-05 11:01:04', 'PrefixRootAndSuffix'),
(322, 2, 63, 'Rebus-Level2', 'uploads/Rebus-Level2_2737128175.swf', 'L', 'uploads/Rebus-Level2_2737128175.png', 0, '', '', '2014-06-18', '', '2019-08-05 11:01:04', 'Rebus-Level2'),
(323, 2, 63, 'RootWords-Level2', 'uploads/RootWords-Level2_162112307.swf', 'L', 'uploads/RootWords-Level2_162112307.png', 0, '', '', '2014-06-18', '', '2019-08-05 11:01:04', 'RootWords-Level2'),
(324, 2, 69, 'Abacus', 'uploads/Abacus_4180846726.swf', 'Maths', 'uploads/Abacus_4180846726.png', 0, '', '', '2014-06-18', '', '2019-08-05 11:01:04', 'Abacus'),
(325, 2, 69, 'AdditionSentence', 'uploads/AdditionSentence_680920318.swf', 'Maths', 'uploads/AdditionSentence_680920318.png', 0, '', '', '2014-06-18', '', '2019-08-05 11:01:04', 'AdditionSentence'),
(326, 2, 69, 'CountUpDown', 'uploads/CountUpDown_6672292379.swf', 'Maths', 'uploads/CountUpDown_6672292379.png', 0, '', '', '2014-06-18', '', '2019-08-05 11:01:04', 'CountUpDown'),
(327, 2, 69, 'DataHandling', 'uploads/DataHandling_5863983076.swf', 'Maths', 'uploads/DataHandling_5863983076.png', 0, '', '', '2014-06-18', '', '2019-08-05 11:01:04', 'DataHandling'),
(328, 2, 69, 'ExpandedForms', 'uploads/ExpandedForms_4122805078.swf', 'Maths', 'uploads/ExpandedForms_4122805078.png', 0, '', '', '2014-06-18', '', '2019-08-05 11:01:04', 'ExpandedForms'),
(329, 2, 69, 'FindThePlaceValue', 'uploads/FindThePlaceValue_5762330922.swf', 'Maths', 'uploads/FindThePlaceValue_5762330922.png', 0, '', '', '2014-06-18', '', '2019-08-05 11:01:04', 'FindThePlaceValue'),
(330, 2, 69, 'Ordering', 'uploads/Ordering_8629188877.swf', 'Maths', 'uploads/Ordering_8629188877.png', 0, '', '', '2014-06-18', '', '2019-08-05 11:01:04', 'Ordering'),
(331, 2, 69, 'SubtractionSentence', 'uploads/SubtractionSentence_9375076512.swf', 'Maths', 'uploads/SubtractionSentence_9375076512.png', 0, '', '', '2014-06-18', '', '2019-08-05 11:01:04', 'SubtractionSentence'),
(332, 2, 69, 'TellingTime', 'uploads/TellingTime_4473059936.swf', 'Maths', 'uploads/TellingTime_4473059936.png', 0, '', '', '2014-06-18', '', '2019-08-05 11:01:04', 'TellingTime'),
(333, 2, 69, 'TensAndOnes', 'uploads/TensAndOnes_8073049881.swf', 'Maths', 'uploads/TensAndOnes_8073049881.png', 0, '', '', '2014-06-18', '', '2019-08-05 11:01:04', 'TensAndOnes'),
(334, 2, 69, 'Comparison', 'uploads/Comparison_6910987743.swf', 'Maths', 'uploads/Comparison_6910987743.png', 0, '', '', '2014-06-18', '', '2019-08-05 11:01:04', 'Comparison'),
(335, 2, 69, 'Division', 'uploads/Division_4689232660.swf', 'Maths', 'uploads/Division_4689232660.png', 0, '', '', '2014-06-18', '', '2019-08-05 11:01:04', 'Division'),
(336, 2, 69, 'Fractions', 'uploads/Fractions_4599967375.swf', 'Maths', 'uploads/Fractions_4599967375.png', 0, '', '', '2014-06-18', '', '2019-08-05 11:01:04', 'Fractions'),
(337, 2, 69, 'MeasuringLength', 'uploads/MeasuringLength_2218617442.swf', 'Maths', 'uploads/MeasuringLength_2218617442.png', 0, '', '', '2014-06-18', '', '2019-08-05 11:01:04', 'MeasuringLength'),
(338, 2, 69, 'MeasuringWeight', 'uploads/MeasuringWeight_3056199173.swf', 'Maths', 'uploads/MeasuringWeight_3056199173.png', 0, '', '', '2014-06-18', '', '2019-08-05 11:01:04', 'MeasuringWeight'),
(339, 2, 69, 'Money', 'uploads/Money_3217458599.swf', 'Maths', 'uploads/Money_3217458599.png', 0, '', '', '2014-06-18', '', '2019-08-05 11:01:04', 'Money'),
(340, 2, 69, 'Multiplication', 'uploads/Multiplication_4357592845.swf', 'Maths', 'uploads/Multiplication_4357592845.png', 0, '', '', '2014-06-18', '', '2019-08-05 11:01:04', 'Multiplication'),
(341, 2, 69, 'OrderingNumbers', 'uploads/OrderingNumbers_3988811578.swf', 'Maths', 'uploads/OrderingNumbers_3988811578.png', 0, '', '', '2014-06-18', '', '2019-08-05 11:01:04', 'OrderingNumbers'),
(342, 2, 69, 'PlaceValues1', 'uploads/PlaceValues1_591116957.swf', 'Maths', 'uploads/PlaceValues1_591116957.png', 0, '', '', '2014-06-18', '', '2019-08-05 11:01:04', 'PlaceValues1'),
(343, 2, 69, 'SkipCounting', 'uploads/SkipCounting_3080642288.swf', 'Maths', 'uploads/SkipCounting_3080642288.png', 0, '', '', '2014-06-18', '', '2019-08-05 11:01:04', 'SkipCounting'),
(344, 2, 69, 'Addition', 'uploads/Addition_6498162765.swf', 'Maths', 'uploads/Addition_6498162765.png', 0, '', '', '2014-06-18', '', '2019-08-05 11:01:04', 'Addition'),
(345, 2, 69, 'CalendarReading', 'uploads/CalendarReading_4089399431.swf', 'Maths', 'uploads/CalendarReading_4089399431.png', 0, '', '', '2014-06-18', '', '2019-08-05 11:01:04', 'CalendarReading'),
(346, 2, 69, 'Division', 'uploads/Division_1746674422.swf', 'Maths', 'uploads/Division_1746674422.png', 0, '', '', '2014-06-18', '', '2019-08-05 11:01:04', 'Division'),
(347, 2, 69, 'Money1', 'uploads/Money1_9447521078.swf', 'Maths', 'uploads/Money1_9447521078.png', 0, '', '', '2014-06-18', '', '2019-08-05 11:01:04', 'Money1'),
(348, 2, 69, 'Multiplication', 'uploads/Multiplication_5754009238.swf', 'Maths', 'uploads/Multiplication_5754009238.png', 0, '', '', '2014-06-18', '', '2019-08-05 11:01:04', 'Multiplication'),
(349, 2, 69, 'NumberNames', 'uploads/NumberNames_7866210732.swf', 'Maths', 'uploads/NumberNames_7866210732.png', 0, '', '', '2014-06-18', '', '2019-08-05 11:01:04', 'NumberNames'),
(350, 2, 69, 'PictoGraph', 'uploads/PictoGraph_697983442.swf', 'Maths', 'uploads/PictoGraph_697983442.png', 0, '', '', '2014-06-18', '', '2019-08-05 11:01:04', 'PictoGraph'),
(351, 2, 69, 'Subtraction', 'uploads/Subtraction_4698918811.swf', 'Maths', 'uploads/Subtraction_4698918811.png', 0, '', '', '2014-06-18', '', '2019-08-05 11:01:04', 'Subtraction'),
(352, 2, 69, 'TellingTime', 'uploads/TellingTime_7427436001.swf', 'Maths', 'uploads/TellingTime_7427436001.png', 0, '', '', '2014-06-18', '', '2019-08-05 11:01:04', 'TellingTime'),
(353, 2, 69, 'WeightsAndBalance', 'uploads/WeightsAndBalance_6692334171.swf', 'Maths', 'uploads/WeightsAndBalance_6692334171.png', 0, '', '', '2014-06-18', '', '2019-08-05 11:01:04', 'WeightsAndBalance'),
(354, 2, 69, 'Decimal', 'uploads/Decimal_1167141757.swf', 'Maths', 'uploads/Decimal_1167141757.png', 0, '', '', '2014-06-18', '', '2019-08-05 11:01:04', 'Decimal'),
(355, 2, 69, 'Division', 'uploads/Division_2050925893.swf', 'Maths', 'uploads/Division_2050925893.png', 0, '', '', '2014-06-18', '', '2019-08-05 11:01:04', 'Division'),
(356, 2, 69, 'Factors', 'uploads/Factors_3122764904.swf', 'Maths', 'uploads/Factors_3122764904.png', 0, '', '', '2014-06-18', '', '2019-08-05 11:01:04', 'Factors'),
(357, 2, 69, 'Fractions', 'uploads/Fractions_1580422050.swf', 'Maths', 'uploads/Fractions_1580422050.png', 0, '', '', '2014-06-18', '', '2019-08-05 11:01:04', 'Fractions'),
(358, 2, 69, 'MetricMeasures', 'uploads/MetricMeasures_7104065096.swf', 'Maths', 'uploads/MetricMeasures_7104065096.png', 0, '', '', '2014-06-18', '', '2019-08-05 11:01:04', 'MetricMeasures'),
(359, 2, 69, 'Money', 'uploads/Money_3255188809.swf', 'Maths', 'uploads/Money_3255188809.png', 0, '', '', '2014-06-18', '', '2019-08-05 11:01:04', 'Money'),
(360, 2, 69, 'Numbers', 'uploads/Numbers_9507074630.swf', 'Maths', 'uploads/Numbers_9507074630.png', 0, '', '', '2014-06-18', '', '2019-08-05 11:01:04', 'Numbers'),
(361, 2, 69, 'PictoGraph', 'uploads/PictoGraph_5385083197.swf', 'Maths', 'uploads/PictoGraph_5385083197.png', 0, '', '', '2014-06-18', '', '2019-08-05 11:01:04', 'PictoGraph'),
(362, 2, 69, 'RomanNumerals', 'uploads/RomanNumerals_8442225940.swf', 'Maths', 'uploads/RomanNumerals_8442225940.png', 0, '', '', '2014-06-18', '', '2019-08-05 11:01:04', 'RomanNumerals'),
(363, 2, 69, 'Time', 'uploads/Time_596343181.swf', 'Maths', 'uploads/Time_596343181.png', 0, '', '', '2014-06-18', '', '2019-08-05 11:01:04', 'Time'),
(364, 2, 69, 'Area', 'uploads/Area_7308138380.swf', 'Maths', 'uploads/Area_7308138380.png', 0, '', '', '2014-06-18', '', '2019-08-05 11:01:04', 'Area'),
(365, 2, 69, 'ArithmeticOperation', 'uploads/ArithmeticOperation_9885068116.swf', 'Maths', 'uploads/ArithmeticOperation_9885068116.png', 0, '', '', '2014-06-18', '', '2019-08-05 11:01:04', 'ArithmeticOperation'),
(366, 2, 69, 'DataHandling', 'uploads/DataHandling_7074244553.swf', 'Maths', 'uploads/DataHandling_7074244553.png', 0, '', '', '2014-06-18', '', '2019-08-05 11:01:04', 'DataHandling'),
(367, 2, 69, 'DecimalsPictorialRepresentation', 'uploads/DecimalsPictorialRepresentation_6688598385.swf', 'Maths', 'uploads/DecimalsPictorialRepresentation_6688598385.png', 0, '', '', '2014-06-18', '', '2019-08-05 11:01:04', 'DecimalsPictorialRepresentation'),
(368, 2, 69, 'Fractions', 'uploads/Fractions_5533746783.swf', 'Maths', 'uploads/Fractions_5533746783.png', 0, '', '', '2014-06-18', '', '2019-08-05 11:01:04', 'Fractions'),
(369, 2, 69, 'MeasuringAngles', 'uploads/MeasuringAngles_6643810006.swf', 'Maths', 'uploads/MeasuringAngles_6643810006.png', 0, '', '', '2014-06-18', '', '2019-08-05 11:01:04', 'MeasuringAngles'),
(370, 2, 69, 'MultiplicationAndDivision', 'uploads/MultiplicationAndDivision_646652863.swf', 'Maths', 'uploads/MultiplicationAndDivision_646652863.png', 0, '', '', '2014-06-18', '', '2019-08-05 11:01:04', 'MultiplicationAndDivision'),
(371, 2, 69, 'Perimeter', 'uploads/Perimeter_7896288982.swf', 'Maths', 'uploads/Perimeter_7896288982.png', 0, '', '', '2014-06-18', '', '2019-08-05 11:01:04', 'Perimeter'),
(372, 2, 69, 'ProfitOrLoss', 'uploads/ProfitOrLoss_2083436325.swf', 'Maths', 'uploads/ProfitOrLoss_2083436325.png', 0, '', '', '2014-06-18', '', '2019-08-05 11:01:04', 'ProfitOrLoss'),
(373, 2, 69, 'ReadingTemperature', 'uploads/ReadingTemperature_1073123300.swf', 'Maths', 'uploads/ReadingTemperature_1073123300.png', 0, '', '', '2014-06-18', '', '2019-08-05 11:01:04', 'ReadingTemperature'),
(374, 2, 69, 'AlgebraicExpressions', 'uploads/AlgebraicExpressions_5022678836.swf', 'Maths', 'uploads/AlgebraicExpressions_5022678836.png', 0, '', '', '2014-06-18', '', '2019-08-05 11:01:04', 'AlgebraicExpressions'),
(375, 2, 69, 'Angles', 'uploads/Angles_4316686284.swf', 'Maths', 'uploads/Angles_4316686284.png', 0, '', '', '2014-06-18', '', '2019-08-05 11:01:04', 'Angles'),
(376, 2, 69, 'BarGraphs', 'uploads/BarGraphs_9455108931.swf', 'Maths', 'uploads/BarGraphs_9455108931.png', 0, '', '', '2014-06-18', '', '2019-08-05 11:01:04', 'BarGraphs'),
(377, 2, 69, 'Bodmas', 'uploads/Bodmas_4129943009.swf', 'Maths', 'uploads/Bodmas_4129943009.png', 0, '', '', '2014-06-18', '', '2019-08-05 11:01:04', 'Bodmas'),
(378, 2, 69, 'ComparisonOfFractions', 'uploads/ComparisonOfFractions_974161447.swf', 'Maths', 'uploads/ComparisonOfFractions_974161447.png', 0, '', '', '2014-06-18', '', '2019-08-05 11:01:04', 'ComparisonOfFractions'),
(379, 2, 69, 'Integers', 'uploads/Integers_2501885509.swf', 'Maths', 'uploads/Integers_2501885509.png', 0, '', '', '2014-06-18', '', '2019-08-05 11:01:04', 'Integers'),
(380, 2, 69, 'Perimeter', 'uploads/Perimeter_2815022724.swf', 'Maths', 'uploads/Perimeter_2815022724.png', 0, '', '', '2014-06-18', '', '2019-08-05 11:01:04', 'Perimeter'),
(381, 2, 69, 'PlaceValue', 'uploads/PlaceValue_9205328556.swf', 'Maths', 'uploads/PlaceValue_9205328556.png', 0, '', '', '2014-06-18', '', '2019-08-05 11:01:04', 'PlaceValue'),
(382, 2, 69, 'Ratios1', 'uploads/Ratios1_9841325306.swf', 'Maths', 'uploads/Ratios1_9841325306.png', 0, '', '', '2014-06-18', '', '2019-08-05 11:01:04', 'Ratios1'),
(383, 2, 69, 'WordProblems', 'uploads/WordProblems_9072397956.swf', 'Maths', 'uploads/WordProblems_9072397956.png', 0, '', '', '2014-06-18', '', '2019-08-05 11:01:04', 'WordProblems'),
(384, 2, 69, 'AlgebraicExpressions', 'uploads/AlgebraicExpressions_9315167246.swf', 'Maths', 'uploads/AlgebraicExpressions_9315167246.png', 0, '', '', '2014-06-18', '', '2019-08-05 11:01:04', 'AlgebraicExpressions'),
(385, 2, 69, 'AnglesFormedByATransversal', 'uploads/AnglesFormedByATransversal_8090837569.swf', 'Maths', 'uploads/AnglesFormedByATransversal_8090837569.png', 0, '', '', '2014-06-18', '', '2019-08-05 11:01:04', 'AnglesFormedByATransversal'),
(386, 2, 69, 'ComplementaryAndSupplementaryAngles', 'uploads/ComplementaryAndSupplementaryAngles_2207047650.swf', 'Maths', 'uploads/ComplementaryAndSupplementaryAngles_2207047650.png', 0, '', '', '2014-06-18', '', '2019-08-05 11:01:04', 'ComplementaryAndSupplementaryAngles'),
(387, 2, 69, 'FormAlgebraicExpression', 'uploads/FormAlgebraicExpression_9936249903.swf', 'Maths', 'uploads/FormAlgebraicExpression_9936249903.png', 0, '', '', '2014-06-18', '', '2019-08-05 11:01:04', 'FormAlgebraicExpression'),
(388, 2, 69, 'Fractions', 'uploads/Fractions_9750380129.swf', 'Maths', 'uploads/Fractions_9750380129.png', 0, '', '', '2014-06-18', '', '2019-08-05 11:01:04', 'Fractions'),
(389, 2, 69, 'Integers', 'uploads/Integers_5691198534.swf', 'Maths', 'uploads/Integers_5691198534.png', 0, '', '', '2014-06-18', '', '2019-08-05 11:01:04', 'Integers'),
(390, 2, 69, 'PowerAndExponent', 'uploads/PowerAndExponent_7979888189.swf', 'Maths', 'uploads/PowerAndExponent_7979888189.png', 0, '', '', '2014-06-18', '', '2019-08-05 11:01:04', 'PowerAndExponent'),
(391, 2, 69, 'Probability', 'uploads/Probability_5193795752.swf', 'Maths', 'uploads/Probability_5193795752.png', 0, '', '', '2014-06-18', '', '2019-08-05 11:01:04', 'Probability'),
(392, 2, 69, 'ProfitAndLoss', 'uploads/ProfitAndLoss_7107260106.swf', 'Maths', 'uploads/ProfitAndLoss_7107260106.png', 0, '', '', '2014-06-18', '', '2019-08-05 11:01:04', 'ProfitAndLoss'),
(393, 2, 69, 'Ratio', 'uploads/Ratio_4942117589.swf', 'Maths', 'uploads/Ratio_4942117589.png', 0, '', '', '2014-06-18', '', '2019-08-05 11:01:04', 'Ratio'),
(394, 2, 69, 'ComparingRationalNumbers', 'uploads/ComparingRationalNumbers_2835911917.swf', 'Maths', 'uploads/ComparingRationalNumbers_2835911917.png', 0, '', '', '2014-06-18', '', '2019-08-05 11:01:04', 'ComparingRationalNumbers'),
(395, 2, 69, 'CoordinateGraph', 'uploads/CoordinateGraph_2505224277.swf', 'Maths', 'uploads/CoordinateGraph_2505224277.png', 0, '', '', '2014-06-18', '', '2019-08-05 11:01:04', 'CoordinateGraph'),
(396, 2, 69, 'Discounts', 'uploads/Discounts_8263450651.swf', 'Maths', 'uploads/Discounts_8263450651.png', 0, '', '', '2014-06-18', '', '2019-08-05 11:01:04', 'Discounts'),
(397, 2, 69, 'FrequencyDistribution', 'uploads/FrequencyDistribution_5845637982.swf', 'Maths', 'uploads/FrequencyDistribution_5845637982.png', 0, '', '', '2014-06-18', '', '2019-08-05 11:01:04', 'FrequencyDistribution'),
(398, 2, 69, 'Histograms', 'uploads/Histograms_2570651620.swf', 'Maths', 'uploads/Histograms_2570651620.png', 0, '', '', '2014-06-18', '', '2019-08-05 11:01:04', 'Histograms'),
(399, 2, 69, 'Parallelogram', 'uploads/Parallelogram_3395389467.swf', 'Maths', 'uploads/Parallelogram_3395389467.png', 0, '', '', '2014-06-18', '', '2019-08-05 11:01:04', 'Parallelogram'),
(400, 2, 69, 'PieCharts', 'uploads/PieCharts_8026213934.swf', 'Maths', 'uploads/PieCharts_8026213934.png', 0, '', '', '2014-06-18', '', '2019-08-05 11:01:04', 'PieCharts'),
(401, 2, 69, 'Probability', 'uploads/Probability_2443953682.swf', 'Maths', 'uploads/Probability_2443953682.png', 0, '', '', '2014-06-18', '', '2019-08-05 11:01:04', 'Probability'),
(402, 2, 69, 'Proportions', 'uploads/Proportions_5851775417.swf', 'Maths', 'uploads/Proportions_5851775417.png', 0, '', '', '2014-06-18', '', '2019-08-05 11:01:04', 'Proportions'),
(403, 2, 69, 'RepresentRationalNumbers', 'uploads/RepresentRationalNumbers_810125921.swf', 'Maths', 'uploads/RepresentRationalNumbers_810125921.png', 0, '', '', '2014-06-18', '', '2019-08-05 11:01:04', 'RepresentRationalNumbers'),
(404, 6, 70, 'ATM', 'uploads/ATM_7717034993.swf', 'ATM', 'uploads/ATM_7717034993.png', 0, '', '', '2014-06-20', '', '2019-08-05 11:01:04', 'ATM'),
(405, 6, 70, 'DealingWithEmotions', 'uploads/DealingWithEmotions_3983766115.swf', 'DealingWithEmotions', 'uploads/DealingWithEmotions_3983766115.png', 0, '', '', '2014-06-20', '', '2019-08-05 11:01:04', 'DealingWithEmotions'),
(406, 6, 70, 'EatWellPlate', 'uploads/EatWellPlate_4084221348.swf', 'EatWellPlate', 'uploads/EatWellPlate_4084221348.png', 0, '', '', '2014-06-20', '', '2019-08-05 11:01:04', 'EatWellPlate'),
(407, 6, 70, 'Emotions', 'uploads/Emotions_3634422519.swf', 'Emotions', 'uploads/Emotions_3634422519.png', 0, '', '', '2014-06-20', '', '2019-08-05 11:01:04', 'Emotions'),
(408, 6, 70, 'HouseHoldWasteManagement', 'uploads/HouseHoldWasteManagement_7283752178.swf', 'HouseHoldWasteManagement', 'uploads/HouseHoldWasteManagement_7283752178.png', 0, '', '', '2014-06-20', '', '2019-08-05 11:01:04', 'HouseHoldWasteManagement'),
(409, 6, 70, 'PowerSaver', 'uploads/PowerSaver_2495759082.swf', 'PowerSaver', 'uploads/PowerSaver_2495759082.png', 0, '', '', '2014-06-21', '', '2019-08-05 11:01:04', 'PowerSaver'),
(410, 6, 70, 'SaveMe', 'uploads/SaveMe_2517943475.swf', 'SaveMe', 'uploads/SaveMe_2517943475.png', 0, '', '', '2014-06-21', '', '2019-08-05 11:01:04', 'SaveMe'),
(411, 6, 70, 'TrafficSigns', 'uploads/TrafficSigns_3680023457.swf', 'TrafficSigns', 'uploads/TrafficSigns_3680023457.png', 0, '', '', '2014-06-21', '', '2019-08-05 11:01:04', 'TrafficSigns'),
(412, 6, 70, 'WasteManagement', 'uploads/WasteManagement_8675311719.swf', 'WasteManagement', 'uploads/WasteManagement_8675311719.png', 0, '', '', '2014-06-21', '', '2019-08-05 11:01:04', 'WasteManagement'),
(413, 6, 70, 'WritingCheque', 'uploads/WritingCheque_9349958524.swf', 'WritingCheque', 'uploads/WritingCheque_9349958524.png', 0, '', '', '2014-06-21', '', '2019-08-05 11:01:04', 'WritingCheque'),
(414, 1, 1, 'AddOn-Level1', 'uploads/AddOn-Level1_29916255.swf', 'M', 'uploads/AddOn-Level1_29916255.png', 1, '', '', '2014-06-26', '', '2019-08-05 13:50:43', 'AddOn-Level1'),
(415, 1, 1, 'AnimalRecall-Level1', 'uploads/AnimalRecall-Level1_5902908118.swf', 'M', 'uploads/AnimalRecall-Level1_5902908118.png', 0, '', '', '2014-06-26', '', '2019-08-05 11:01:04', 'AnimalRecall-Level1'),
(416, 1, 1, 'BuddySpot-Level1', 'uploads/BuddySpot-Level1_4558774498.swf', 'BuddySpot-Level1', 'uploads/BuddySpot-Level1_4558774498.png', 1, '', '', '2014-06-26', '', '2019-08-05 13:50:43', 'BuddySpot-Level1'),
(417, 1, 1, 'FruitDrop-Level1', 'uploads/FruitDrop-Level1_5968954963.swf', 'M', 'uploads/FruitDrop-Level1_5968954963.png', 0, '', '', '2014-06-26', '', '2019-08-05 11:01:04', 'FruitDrop-Level1'),
(418, 1, 2, 'JackInTheBox-Level1', 'uploads/JackInTheBox-Level1_8967085247.swf', 'M', 'uploads/JackInTheBox-Level1_8967085247.png', 1, '', '', '2014-06-26', '', '2019-08-05 13:50:43', 'JackInTheBox-Level1'),
(419, 1, 1, 'LocateTheParts-Level1', 'uploads/LocateTheParts-Level1_9876082488.swf', 'M', 'uploads/LocateTheParts-Level1_9876082488.png', 1, '', '', '2014-06-26', '', '2019-08-05 13:50:43', 'LocateTheParts-Level1'),
(420, 1, 1, 'NumberScramble', 'uploads/NumberScramble_5994973969.swf', 'M', 'uploads/NumberScramble_5994973969.png', 0, '', '', '2014-06-26', '', '2019-08-05 11:01:04', 'NumberScramble'),
(421, 1, 1, 'SmileySeries-Level1', 'uploads/SmileySeries-Level1_3376116408.swf', 'M', 'uploads/SmileySeries-Level1_3376116408.png', 1, '', '', '2014-06-26', '', '2019-08-05 13:50:43', 'SmileySeries-Level1'),
(422, 1, 3, 'BestFit-Level1', 'uploads/BestFit-KG1_6883309637.swf', 'M', 'uploads/BestFit-KG1_6883309637.png', 1, '', '', '2014-06-26', '', '2019-08-05 13:50:43', 'BestFit-Level1'),
(423, 1, 2, 'EarringMatch-Level1', 'uploads/EarringMatch-Level1_9153384454.swf', 'VP', 'uploads/EarringMatch-Level1_9153384454.png', 0, '', '', '2014-06-26', '', '2019-08-05 11:01:04', 'EarringMatch-Level1'),
(424, 1, 2, 'FaceCut-Level1', 'uploads/FaceCut-Level1_7893398585.swf', 'VP', 'uploads/FaceCut-Level1_7893398585.png', 1, '', '', '2014-06-26', '', '2019-08-05 13:50:43', 'FaceCut-Level1'),
(425, 1, 3, 'IconMatch-Level1', 'uploads/IconMatch-Level1_4288190002.swf', 'VP', 'uploads/IconMatch-Level1_4288190002.png', 1, '', '', '2014-06-26', '', '2019-08-05 13:50:43', 'IconMatch-Level1'),
(426, 1, 2, 'LostLastPart-Level1', 'uploads/LostLastPart-Level1_6288307351.swf', 'VP', 'uploads/LostLastPart-Level1_6288307351.png', 1, '', '', '2014-06-26', '', '2019-08-05 13:50:43', 'LostLastPart-Level1'),
(427, 1, 2, 'MysteryWord-Level1', 'uploads/MysteryWord-Level1_4597698734.swf', 'VP', 'uploads/MysteryWord-Level1_4597698734.png', 0, '', '', '2014-06-26', '', '2019-08-05 11:01:04', 'MysteryWord-Level1'),
(428, 1, 2, 'TwinPiece-Level1', 'uploads/TwinPiece-Level1_277658514.swf', 'VP', 'uploads/TwinPiece-Level1_277658514.png', 0, '', '', '2014-06-26', '', '2019-08-05 11:01:04', 'TwinPiece-Level1'),
(429, 1, 2, 'WhoHits-Level1', 'uploads/WhoHits-Level1_1098579633.swf', 'VP', 'uploads/WhoHits-Level1_1098579633.png', 1, '', '', '2014-06-26', '', '2019-08-05 13:50:43', 'WhoHits-Level1'),
(430, 1, 3, 'AlphaFocus-Level1', 'uploads/AlphaFocus-Level1_7799442643.swf', 'FA', 'uploads/AlphaFocus-Level1_7799442643.png', 0, '', '', '2014-06-26', '', '2019-08-05 11:01:04', 'AlphaFocus-Level1'),
(431, 1, 2, 'ArrowHit-Level1', 'uploads/ArrowHit-Level1_2562350165.swf', 'FA', 'uploads/ArrowHit-Level1_2562350165.png', 1, '', '', '2014-06-26', '', '2019-08-05 13:50:43', 'ArrowHit-Level1'),
(432, 1, 2, 'DoWeDiffer-Level1', 'uploads/DoWeDiffer-Level1_9961162102.swf', 'FA', 'uploads/DoWeDiffer-Level1_9961162102.png', 1, '', '', '2014-06-26', '', '2019-08-05 13:50:43', 'DoWeDiffer-Level1'),
(433, 1, 2, 'PathTrace-Level1', 'uploads/PathTrace-Level1_9113778676.swf', 'FA', 'uploads/PathTrace-Level1_9113778676.png', 1, '', '', '2014-06-26', '', '2019-08-05 13:50:43', 'PathTrace-Level1'),
(434, 1, 2, 'StarLight-Level1', 'uploads/StarLight-KG1_6201227623.swf', 'FA', 'uploads/StarLight-KG1_6201227623.png', 1, '', '', '2014-06-26', '', '2019-08-05 13:50:43', 'StarLight-Level1'),
(435, 1, 2, 'StrangerGrid-Level1', 'uploads/StrangerGrid-KG1_7493638731.swf', 'FA', 'uploads/StrangerGrid-KG1_7493638731.png', 1, '', '', '2014-06-26', '', '2019-08-05 13:50:43', 'StrangerGrid-Level1'),
(436, 1, 3, 'OddAlphaNumber-Level1', 'uploads/WeirdAlphaNumber-Level1_4951013289.swf', 'FA', 'uploads/WeirdAlphaNumber-Level1_4951013289.png', 0, '', '', '2014-06-26', '', '2019-08-05 11:01:04', 'OddAlphaNumber-Level1'),
(437, 1, 3, 'WhoReachesOut-Level1', 'uploads/WhoReachesOut-Level1_8087662272.swf', 'FA', 'uploads/WhoReachesOut-Level1_8087662272.png', 0, '', '', '2014-06-26', '', '2019-08-05 11:01:04', 'WhoReachesOut-Level1'),
(438, 1, 62, 'CompareContest-Level1', 'uploads/CompareContest-Level1_1414912887.swf', 'PS', 'uploads/CompareContest-Level1_1414912887.png', 0, '', '', '2014-06-26', '', '2019-08-05 11:01:04', 'CompareContest-Level1'),
(439, 1, 3, 'GroupIt-Level1', 'uploads/GroupIt-Level1_2434460278.swf', 'PS', 'uploads/GroupIt-Level1_2434460278.png', 1, '', '', '2014-06-26', '', '2019-08-05 13:50:43', 'GroupIt-Level1'),
(440, 1, 3, 'ImageSequence-Level1', 'uploads/ImageSequence-Level1_1271936539.swf', 'PS', 'uploads/ImageSequence-Level1_1271936539.png', 1, '', '', '2014-06-26', '', '2019-08-05 13:50:43', 'ImageSequence-Level1'),
(441, 1, 62, 'MakeAPattern-Level1', 'uploads/MakeAPattern-Level1_374257480.swf', 'PS', 'uploads/MakeAPattern-Level1_374257480.png', 0, '', '', '2014-06-26', '', '2019-08-05 11:01:04', 'MakeAPattern-Level1'),
(442, 1, 62, 'PatternForAPattern-Level1', 'uploads/PatternForAPattern-Level1_5394952590.swf', 'PS', 'uploads/PatternForAPattern-Level1_5394952590.png', 0, '', '', '2014-06-26', '', '2019-08-05 11:01:04', 'PatternForAPattern-Level1'),
(443, 1, 62, 'PatternRepresentation-Level1', 'uploads/PatternRepresentation-Level1_7518243058.swf', 'PS', 'uploads/PatternRepresentation-Level1_7518243058.png', 0, '', '', '2014-06-26', '', '2019-08-05 11:01:04', 'PatternRepresentation-Level1'),
(444, 1, 62, 'SymmetryOrNot-Level1', 'uploads/SymmetryOrNot-Level1_535150892.swf', 'PS', 'uploads/SymmetryOrNot-Level1_535150892.png', 0, '', '', '2014-06-26', '', '2019-08-05 11:01:04', 'SymmetryOrNot-Level1'),
(445, 1, 3, 'WhatComesNext-Level1', 'uploads/WhatComesNext-Level1_3932243706.swf', 'PS', 'uploads/WhatComesNext-Level1_3932243706.png', 0, '', '', '2014-06-26', '', '2019-08-05 11:01:04', 'WhatComesNext-Level1'),
(446, 1, 63, 'AbsentInAlphabet', 'uploads/AbsentAlphabet_5964533849.swf', 'L', 'uploads/AbsentAlphabet_5964533849.png', 0, '', '', '2014-06-26', '', '2019-08-05 11:01:04', 'AbsentInAlphabet'),
(447, 1, 63, 'LetterPicturePair', 'uploads/AlphabetPicturePair_441006175.swf', 'L', 'uploads/AlphabetPicturePair_441006175.png', 0, '', '', '2014-06-26', '', '2019-08-05 11:01:04', 'LetterPicturePair'),
(448, 1, 63, 'LetterSearch', 'uploads/AlphabetSearch_1266466071.swf', 'L', 'uploads/AlphabetSearch_1266466071.png', 0, '', '', '2014-06-26', '', '2019-08-05 11:01:04', 'LetterSearch'),
(449, 1, 63, 'LetterStart', 'uploads/AlphabetStart_6351753645.swf', 'L', 'uploads/AlphabetStart_6351753645.png', 0, '', '', '2014-06-26', '', '2019-08-05 11:01:04', 'LetterStart'),
(450, 1, 63, 'LetterCases', 'uploads/LetterCases_8069400168.swf', 'L', 'uploads/LetterCases_8069400168.png', 0, '', '', '2014-06-26', '', '2019-08-05 11:01:04', 'LetterCases'),
(451, 1, 63, 'MissingInMiddle', 'uploads/MissingInMiddle_5156854209.swf', 'L', 'uploads/MissingInMiddle_5156854209.png', 0, '', '', '2014-06-26', '', '2019-08-05 11:01:04', 'MissingInMiddle'),
(452, 1, 63, 'SpellIt-Level1', 'uploads/SpellIt-Level1_4972556773.swf', 'L', 'uploads/SpellIt-Level1_4972556773.png', 0, '', '', '2014-06-26', '', '2019-08-05 11:01:04', 'SpellIt-Level1'),
(453, 1, 63, 'WhoStartsWithMe', 'uploads/WhoStartsWithMe_9145371927.swf', 'L', 'uploads/WhoStartsWithMe_9145371927.png', 0, '', '', '2014-06-26', '', '2019-08-05 11:01:04', 'WhoStartsWithMe'),
(454, 5, 69, 'ConnectTheDots', 'uploads/ConnectTheDots_2368787559.swf', 'Maths', 'uploads/ConnectTheDots_2368787559.png', 0, '', '', '2014-06-26', '', '2019-08-05 11:01:04', 'ConnectTheDots'),
(455, 5, 69, 'DrawObjects', 'uploads/DrawObjects_6511433022.swf', 'Maths', 'uploads/DrawObjects_6511433022.png', 0, '', '', '2014-06-26', '', '2019-08-05 11:01:04', 'DrawObjects'),
(456, 5, 69, 'MatchPictureAndNumber', 'uploads/MatchPictureAndNumber_8035868098.swf', 'Maths', 'uploads/MatchPictureAndNumber_8035868098.png', 0, '', '', '2014-06-26', '', '2019-08-05 11:01:04', 'MatchPictureAndNumber'),
(457, 5, 69, 'MissingNumber', 'uploads/MissingNumber_7184725282.swf', 'Maths', 'uploads/MissingNumber_7184725282.png', 0, '', '', '2014-06-26', '', '2019-08-05 11:01:04', 'MissingNumber'),
(458, 5, 69, 'NumberRecognition', 'uploads/NumberRecognition_2360329194.swf', 'Maths', 'uploads/NumberRecognition_2360329194.png', 0, '', '', '2014-06-26', '', '2019-08-05 11:01:04', 'NumberRecognition'),
(459, 5, 69, 'SceneCounting', 'uploads/SceneCounting_6976411170.swf', 'Maths', 'uploads/SceneCounting_6976411170.png', 0, '', '', '2014-06-26', '', '2019-08-05 11:01:04', 'SceneCounting'),
(460, 5, 69, 'ShapeIndentification', 'uploads/ShapeIndentification_6541579924.swf', 'Maths', 'uploads/ShapeIndentification_6541579924.png', 0, '', '', '2014-06-26', '', '2019-08-05 11:01:04', 'ShapeIndentification'),
(461, 5, 69, 'WhatComeAfter', 'uploads/WhatComeAfter_812028921.swf', 'Maths', 'uploads/WhatComeAfter_812028921.png', 0, '', '', '2014-06-26', '', '2019-08-05 11:01:04', 'WhatComeAfter'),
(462, 5, 69, 'WhatComeBefore', 'uploads/WhatComeBefore_334682455.swf', 'Maths', 'uploads/WhatComeBefore_334682455.png', 0, '', '', '2014-06-26', '', '2019-08-05 11:01:04', 'WhatComeBefore'),
(463, 5, 69, 'WhatComeInBetween', 'uploads/WhatComeInBetween_7709090574.swf', 'Maths', 'uploads/WhatComeInBetween_7709090574.png', 0, '', '', '2014-06-26', '', '2019-08-05 11:01:04', 'WhatComeInBetween'),
(464, 1, 1, 'AddOn-Level2', 'uploads/AddOn-Level2_2288141329.swf', 'M', 'uploads/AddOn-Level2_2288141329.png', 1, '', '', '2014-06-26', '', '2019-08-05 13:50:43', 'AddOn-Level2'),
(465, 1, 1, 'AlphaNumberScramble', 'uploads/AlphaNumberScramble_3375521898.swf', 'M', 'uploads/AlphaNumberScramble_3375521898.png', 0, '', '', '2014-06-26', '', '2019-08-05 11:01:04', 'AlphaNumberScramble'),
(466, 1, 1, 'AnimalRecall-Level2', 'uploads/AnimalRecall-Level2_6097432286.swf', 'M', 'uploads/AnimalRecall-Level2_6097432286.png', 0, '', '', '2014-06-26', '', '2019-08-05 11:01:04', 'AnimalRecall-Level2'),
(467, 1, 1, 'BuddySpot-Level2', 'uploads/BuddySpot-Level2_9439796507.swf', 'M', 'uploads/BuddySpot-Level2_9439796507.png', 1, '', '', '2014-06-26', '', '2019-08-05 13:50:43', 'BuddySpot-Level2'),
(468, 1, 1, 'FruitDrop-Level2', 'uploads/FruitDrop-Level2_321508771.swf', 'M', 'uploads/FruitDrop-Level2_321508771.png', 0, '', '', '2014-06-26', '', '2019-08-05 11:01:04', 'FruitDrop-Level2'),
(469, 1, 1, 'JackInTheBox-Level2', 'uploads/JackInTheBox-Level2_5127689531.swf', 'M', 'uploads/JackInTheBox-Level2_5127689531.png', 1, '', '', '2014-06-26', '', '2019-08-05 13:50:43', 'JackInTheBox-Level2'),
(470, 1, 1, 'LocateTheParts-Level2', 'uploads/LocateTheParts-Level2_4917782000.swf', 'M', 'uploads/LocateTheParts-Level2_4917782000.png', 1, '', '', '2014-06-26', '', '2019-08-05 13:50:43', 'LocateTheParts-Level2'),
(471, 1, 1, 'SmileySeries-Level2', 'uploads/SmileySeries-Level2_3532663313.swf', 'M', 'uploads/SmileySeries-Level2_3532663313.png', 1, '', '', '2014-06-26', '', '2019-08-05 13:50:43', 'SmileySeries-Level2'),
(472, 1, 3, 'BestFit-Level2', 'uploads/BestFit-KG2_8591418769.swf', 'VP', 'uploads/BestFit-KG2_8591418769.png', 1, '', '', '2014-06-26', '', '2019-08-05 13:50:43', 'BestFit-Level2'),
(473, 1, 2, 'EarringMatch-Level2', 'uploads/EarringMatch-Level2_9765920392.swf', 'VP', 'uploads/EarringMatch-Level2_9765920392.png', 0, '', '', '2014-06-26', '', '2019-08-05 11:01:04', 'EarringMatch-Level2'),
(474, 1, 2, 'FaceCut-Level2', 'uploads/FaceCut-Level2_8397557884.swf', 'VP', 'uploads/FaceCut-Level2_8397557884.png', 1, '', '', '2014-06-26', '', '2019-08-05 13:50:43', 'FaceCut-Level2'),
(475, 1, 3, 'IconMatch-Level2', 'uploads/IconMatch-Level2_191964996.swf', 'VP', 'uploads/IconMatch-Level2_191964996.png', 1, '', '', '2014-06-26', '', '2019-08-05 13:50:43', 'IconMatch-Level2'),
(476, 1, 2, 'LostLastPart-Level2', 'uploads/LostLastPart-Level2_6243226788.swf', 'VP', 'uploads/LostLastPart-Level2_6243226788.png', 1, '', '', '2014-06-26', '', '2019-08-05 13:50:43', 'LostLastPart-Level2'),
(477, 1, 2, 'MysteryWord-Level2', 'uploads/MysteryWord-Level2_8829181427.swf', 'VP', 'uploads/MysteryWord-Level2_8829181427.png', 0, '', '', '2014-06-26', '', '2019-08-05 11:01:04', 'MysteryWord-Level2'),
(478, 1, 2, 'TwinPiece-Level2', 'uploads/TwinPiece-Level2_4966554236.swf', 'VP', 'uploads/TwinPiece-Level2_4966554236.png', 0, '', '', '2014-06-26', '', '2019-08-05 11:01:04', 'TwinPiece-Level2'),
(479, 1, 2, 'WhoHits-Level2', 'uploads/WhoHits-Level2_3314637686.swf', 'VP', 'uploads/WhoHits-Level2_3314637686.png', 1, '', '', '2014-06-26', '', '2019-08-05 13:50:43', 'WhoHits-Level2'),
(480, 1, 3, 'AlphaFocus-Level2', 'uploads/AlphaFocus-Level2_9990389710.swf', 'FA', 'uploads/AlphaFocus-Level2_9990389710.png', 0, '', '', '2014-06-26', '', '2019-08-05 11:01:04', 'AlphaFocus-Level2'),
(481, 1, 2, 'ArrowHit-Level2', 'uploads/ArrowHit-Level2_7136968858.swf', 'FA', 'uploads/ArrowHit-Level2_7136968858.png', 1, '', '', '2014-06-26', '', '2019-08-05 13:50:43', 'ArrowHit-Level2'),
(482, 1, 2, 'DoWeDiffer-Level2', 'uploads/DoWeDiffer-Level2_7497774129.swf', 'FA', 'uploads/DoWeDiffer-Level2_7497774129.png', 1, '', '', '2014-06-26', '', '2019-08-05 13:50:43', 'DoWeDiffer-Level2'),
(483, 1, 2, 'PathTrace-Level2', 'uploads/PathTrace-Level2_9511187383.swf', 'FA', 'uploads/PathTrace-Level2_9511187383.png', 1, '', '', '2014-06-26', '', '2019-08-05 13:50:43', 'PathTrace-Level2'),
(484, 1, 2, 'StarLight-Level2', 'uploads/StarLight-KG2_7005840959.swf', 'FA', 'uploads/StarLight-KG2_7005840959.png', 1, '', '', '2014-06-26', '', '2019-08-05 13:50:43', 'StarLight-Level2'),
(485, 1, 2, 'StrangerGrid-Level2', 'uploads/StrangerGrid-KG2_1036263587.swf', 'FA', 'uploads/StrangerGrid-KG2_1036263587.png', 1, '', '', '2014-06-26', '', '2019-08-05 13:50:43', 'StrangerGrid-Level2'),
(486, 1, 3, 'OddAlphaNumber-Level2', 'uploads/WeirdAlphaNumber-Level2_4363326304.swf', 'FA', 'uploads/WeirdAlphaNumber-Level2_4363326304.png', 0, '', '', '2014-06-26', '', '2019-08-05 11:01:04', 'OddAlphaNumber-Level2'),
(487, 1, 3, 'WhoReachesOut-Level2', 'uploads/WhoReachesOut-Level2_9702787548.swf', 'FA', 'uploads/WhoReachesOut-Level2_9702787548.png', 0, '', '', '2014-06-26', '', '2019-08-05 11:01:04', 'WhoReachesOut-Level2'),
(488, 1, 62, 'CompareContest-Level2', 'uploads/CompareContest-Level2_1971407081.swf', 'PS', 'uploads/CompareContest-Level2_1971407081.png', 0, '', '', '2014-06-26', '', '2019-08-05 11:01:04', 'CompareContest-Level2'),
(489, 1, 3, 'GroupIt-Level2', 'uploads/GroupIt-Level2_8481714227.swf', 'PS', 'uploads/GroupIt-Level2.png', 1, '', '', '2014-06-26', '', '2019-08-05 13:50:43', 'GroupIt-Level2'),
(490, 1, 3, 'ImageSequence-Level2', 'uploads/ImageSequence-Level2_3751685819.swf', 'PS', 'uploads/ImageSequence-Level2_3751685819.png', 1, '', '', '2014-06-26', '', '2019-08-05 13:50:43', 'ImageSequence-Level2'),
(491, 1, 62, 'MakeAPattern-Level2', 'uploads/MakeAPattern-Level2_4096280215.swf', 'PS', 'uploads/MakeAPattern-Level2_4096280215.png', 0, '', '', '2014-06-26', '', '2019-08-05 11:01:04', 'MakeAPattern-Level2'),
(492, 1, 62, 'PatternForAPattern-Level2', 'uploads/PatternForAPattern-Level2_7414737520.swf', 'PS', 'uploads/PatternForAPattern-Level2_7414737520.png', 0, '', '', '2014-06-26', '', '2019-08-05 11:01:04', 'PatternForAPattern-Level2'),
(493, 1, 62, 'PatternRepresentation-Level2', 'uploads/PatternRepresentation-Level2_1035452852.swf', 'PS', 'uploads/PatternRepresentation-Level2_1035452852.png', 0, '', '', '2014-06-26', '', '2019-08-05 11:01:04', 'PatternRepresentation-Level2'),
(494, 1, 62, 'SymmetryOrNot-Level2', 'uploads/SymmetryOrNot-Level2_4635163354.swf', 'PS', 'uploads/SymmetryOrNot-Level2_4635163354.png', 0, '', '', '2014-06-26', '', '2019-08-05 11:01:04', 'SymmetryOrNot-Level2'),
(495, 1, 62, 'WhoJoinsTheGroup', 'uploads/WhoJoinsTheGroup_9253409225.swf', 'PS', 'uploads/WhoJoinsTheGroup_9253409225.png', 0, '', '', '2014-06-26', '', '2019-08-05 11:01:04', 'WhoJoinsTheGroup'),
(496, 1, 63, 'LetterOrder', 'uploads/AlphabetOrder_1804643566.swf', 'L', 'uploads/AlphabetOrder_1804643566.png', 0, '', '', '2014-06-26', '', '2019-08-05 11:01:04', 'LetterOrder'),
(497, 1, 63, 'Articles', 'uploads/Articles_6478719203.swf', 'L', 'uploads/Articles_6478719203.png', 0, '', '', '2014-06-26', '', '2019-08-05 11:01:04', 'Articles'),
(498, 1, 63, 'FormTheWord', 'uploads/FormTheWord_5906901671.swf', 'L', 'uploads/FormTheWord_5906901671.png', 0, '', '', '2014-06-26', '', '2019-08-05 11:01:04', 'FormTheWord'),
(499, 1, 63, 'InAndOn', 'uploads/InAndOn_9388019754.swf', 'L', 'uploads/InAndOn_9388019754.png', 0, '', '', '2014-06-26', '', '2019-08-05 11:01:04', 'InAndOn'),
(500, 1, 63, 'MissingVowel', 'uploads/MissingVowel_7264694026.swf', 'L', 'uploads/MissingVowel_7264694026.png', 0, '', '', '2014-06-26', '', '2019-08-05 11:01:04', 'MissingVowel'),
(501, 1, 63, 'RhymingWords', 'uploads/RhymingWords_5765644419.swf', 'L', 'uploads/RhymingWords_5765644419.png', 0, '', '', '2014-06-26', '', '2019-08-05 11:01:04', 'RhymingWords'),
(502, 1, 63, 'SpellIt-Level2', 'uploads/SpellIt-Level2_2642293530.swf', 'L', 'uploads/SpellIt-Level2_2642293530.png', 0, '', '', '2014-06-26', '', '2019-08-05 11:01:04', 'SpellIt-Level2'),
(503, 1, 63, 'WordBuilding', 'uploads/WordBuilding_9514361643.swf', 'L', 'uploads/WordBuilding_9514361643.png', 0, '', '', '2014-06-26', '', '2019-08-05 11:01:04', 'WordBuilding'),
(504, 5, 69, 'Abacus', 'uploads/Abacus_4005045536.swf', 'Maths', 'uploads/Abacus_4005045536.png', 0, '', '', '2014-06-26', '', '2019-08-05 11:01:04', 'Abacus'),
(505, 5, 69, 'Addition', 'uploads/Addition_6705379108.swf', 'Maths', 'uploads/Addition_6705379108.png', 0, '', '', '2014-06-26', '', '2019-08-05 11:01:04', 'Addition'),
(506, 5, 69, 'AscendingOrDescending', 'uploads/AscendingOrDescending_7524199825.swf', 'Maths', 'uploads/AscendingOrDescending_7524199825.png', 0, '', '', '2014-06-26', '', '2019-08-05 11:01:04', 'AscendingOrDescending'),
(507, 5, 69, 'BeforeAfterBetween', 'uploads/BeforeAfterBetween_1382627706.swf', 'Maths', 'uploads/BeforeAfterBetween_1382627706.png', 0, '', '', '2014-06-26', '', '2019-08-05 11:01:04', 'BeforeAfterBetween'),
(508, 5, 69, 'MissingNumbers', 'uploads/MissingNumbers_4701846409.swf', 'Maths', 'uploads/MissingNumbers_4701846409.png', 0, '', '', '2014-06-26', '', '2019-08-05 11:01:04', 'MissingNumbers');
INSERT INTO `games` (`gid`, `gc_id`, `gs_id`, `gname`, `path`, `descs`, `img_path`, `gstatus`, `gplans`, `createdby`, `creation_date`, `modifiedby`, `modified_date`, `game_html`) VALUES
(509, 5, 69, 'NumbersAndTheirNames', 'uploads/NumbersAndTheirNames_1728372559.swf', 'M', 'uploads/NumbersAndTheirNames_1728372559.png', 0, '', '', '2014-06-26', '', '2019-08-05 11:01:04', 'NumbersAndTheirNames'),
(510, 5, 69, 'OrdinalNumbers', 'uploads/OrdinalNumbers_7629372733.swf', 'Maths', 'uploads/OrdinalNumbers_7629372733.png', 0, '', '', '2014-06-26', '', '2019-08-05 11:01:04', 'OrdinalNumbers'),
(511, 5, 69, 'Positions', 'uploads/Positions_4461775524.swf', 'Maths', 'uploads/Positions_4461775524.png', 0, '', '', '2014-06-26', '', '2019-08-05 11:01:04', 'Positions'),
(512, 5, 69, 'RepresentTheGivenNumber', 'uploads/RepresentTheGivenNumber_4813793930.swf', 'Maths', 'uploads/RepresentTheGivenNumber_4813793930.png', 0, '', '', '2014-06-26', '', '2019-08-05 11:01:04', 'RepresentTheGivenNumber'),
(513, 5, 69, 'Subtraction', 'uploads/Subtraction_5720178936.swf', 'Maths', 'uploads/Subtraction_5720178936.png', 0, '', '', '2014-06-26', '', '2019-08-05 11:01:04', 'Subtraction'),
(514, 2, 59, 'BalloonBurst-Level1', 'uploads/BalloonBurst-Level1_8117342898.swf', 'Memory', 'uploads/BalloonBurst-Level1_8117342898.png', 0, '', '', '2014-06-17', '', '2019-08-05 11:01:04', 'BalloonBurst-Level1'),
(515, 1, 1, 'BirdRecall-Level2', 'uploads/BirdRecall-Level2.swf', 'BirdRecall-Level2', 'uploads/AnimalRecall-Level1_5902908118.png', 1, '', '', '2014-06-26', '', '2019-08-05 13:50:43', 'BirdRecall-Level2'),
(516, 1, 3, 'OddShape-Level1', 'uploads/GroupIt-Level2_8481714227.swf', 'PS', 'uploads/OddShape-Level2.png', 1, '', '', '2014-06-26', '', '2019-08-05 13:50:43', 'OddShape-Level1'),
(517, 1, 2, 'ShadowMatch-Level2', 'uploads/GroupIt-Level2_8481714227.swf', 'PS', 'uploads/New-Kinder-Shadowmatch.png', 1, '', '', '2014-06-26', '', '2019-08-05 13:50:43', 'ShadowMatch-Level2'),
(518, 1, 2, 'ShapeGrid-Level1', 'uploads/GroupIt-Level2_8481714227.swf', 'PS', 'uploads/ShapeGrid-KG.png', 1, '', '', '2014-06-26', '', '2019-08-05 13:50:43', 'ShapeGrid-Level1'),
(574, 1, 59, 'RememberMyName-Level1', 'uploads/RememberMyName-Level1.swf', 'Memory', 'uploads/RememberMyName-Level1.png', 0, '', '', '2017-05-15', '', '2019-08-05 11:01:04', 'RememberMyName-Level1'),
(575, 1, 59, 'OutOfFocus-Level1', 'uploads/OutofFocus-Level1.swf', 'Memory', 'uploads/OutofFocus-Level1.png', 0, '', '', '2017-05-15', '', '2019-08-05 11:01:04', 'OutOfFocus-Level1'),
(576, 1, 59, 'ClockGrid-Level1', 'uploads/ClockGrid-Level1.swf', 'Memory', 'uploads/ClockGrid-Level1.png', 0, '', '', '2017-05-15', '', '2019-08-05 11:01:04', 'ClockGrid-Level1'),
(577, 1, 59, 'ChessBoard-Level1', 'uploads/ChessBoard-Level1.swf', 'Memory', 'uploads/ChessBoard-Level1.png', 0, '', '', '2017-05-15', '', '2019-08-05 11:01:04', 'ChessBoard-Level1'),
(578, 1, 60, 'FormTheShape-Level1', 'uploads/FormTheShape-Level1.swf', 'VP', 'uploads/FormTheShape-Level1.png', 0, '', '', '2017-05-15', '', '2019-08-05 11:01:04', 'FormTheShape-Level1'),
(579, 1, 60, 'PhotoShop-Level1', 'uploads/Photoshop-Level1.swf', 'VP', 'uploads/Photoshop-Level1.png', 0, '', '', '2017-05-15', '', '2019-08-05 11:01:04', 'PhotoShop-Level1'),
(580, 1, 60, 'FormTheFace-Level1', 'uploads/FormtheFace-Level1.swf', 'VP', 'uploads/FormtheFace-Level1.png', 0, '', '', '2017-05-15', '', '2019-08-05 11:01:04', 'FormTheFace-Level1'),
(581, 1, 60, 'RearMagic-Level1', 'uploads/RearMagic-Level1.swf', 'VP', 'uploads/RearMagic-Level1.png', 0, '', '', '2017-05-15', '', '2019-08-05 11:01:04', 'RearMagic-Level1'),
(582, 1, 61, 'JigsawPieces-Level1', 'uploads/JigsawPieces-Level1.swf', 'FA', 'uploads/JigsawPieces-Level1.png', 0, '', '', '2017-05-15', '', '2019-08-05 11:01:04', 'JigsawPieces-Level1'),
(585, 1, 61, 'AnimalLeap-Level3', 'uploads/AnimalLeap-Level3.swf', 'FA', 'uploads/AnimalLeap-Level3.png', 0, '', '', '2017-05-15', '', '2019-08-05 11:01:04', 'AnimalLeap-Level3'),
(586, 1, 62, 'VennDiagram-Level1', 'uploads/VennDiagram-Level1.swf', 'PS', 'uploads/VennDiagram-Level1.png', 0, '', '', '2017-05-15', '', '2019-08-05 11:01:04', 'VennDiagram-Level1'),
(587, 1, 62, 'UnLockTheSuitcase-Level1', 'uploads/UnlocktheSuitcase-Level1.swf', 'PS', 'uploads/UnlocktheSuitcase-Level1.png', 0, '', '', '2017-05-15', '', '2019-08-05 11:01:04', 'UnLockTheSuitcase-Level1'),
(588, 1, 62, 'TeamUp-Level1', 'uploads/TeamUp-Level1.swf', 'PS', 'uploads/TeamUp-Level1.png', 0, '', '', '2017-05-15', '', '2019-08-05 11:01:04', 'TeamUp-Level1'),
(590, 1, 63, 'BeginToEnd-Level1', 'uploads/BegintoEnd-Level1.swf', 'L', 'uploads/BegintoEnd-Level1.png', 0, '', '', '2017-05-15', '', '2019-08-05 11:01:04', 'BeginToEnd-Level1'),
(591, 1, 63, 'Capitonyms-Level1', 'uploads/Capitonyms-Level1.swf', 'L', 'uploads/Capitonyms-Level1.png', 0, '', '', '2017-05-15', '', '2019-08-05 11:01:04', 'Capitonyms-Level1'),
(592, 1, 63, 'Anagrams-Level1', 'uploads/Anagrams-Level1.swf', 'L', 'uploads/Anagrams-Level1.png', 0, '', '', '2017-05-15', '', '2019-08-05 11:01:04', 'Anagrams-Level1'),
(593, 1, 63, 'Metaphors-Level1', 'uploads/Metaphors-Level1.swf', 'L', 'uploads/Metaphors-Level1.png', 0, '', '', '2017-05-15', '', '2019-08-05 11:01:04', 'Metaphours-Level1'),
(594, 1, 1, 'BallDrop-Level1', '', '', 'uploads/BallDrop-KG.png', 1, '', '', '2019-05-02', '', '2019-08-05 13:50:43', 'BallDrop-Level1'),
(595, 1, 1, 'TransPortRecall-Level1', '', '', 'uploads/AnimalRecall-Level1_5902908118.png', 1, '', '', '2019-05-02', '', '2019-08-05 13:50:43', 'TransPortRecall-Level1'),
(596, 1, 1, 'ShapeDrop-Level2', '', '', 'uploads/ShapeDrop-Level2.png', 1, '', '', '2019-05-02', '', '2019-08-05 13:50:43', 'ShapeDrop-Level2'),
(597, 1, 2, 'TheFinishLine-Level1', '', '', 'uploads/TheFinishLine-Level1.png', 1, '', '', '2019-05-02', '', '2019-08-05 13:50:43', 'TheFinishLine-Level1'),
(598, 1, 2, 'TheFinishLine-Level2', '', '', 'uploads/TheFinishLine-Level1.png', 1, '', '', '2019-05-02', '', '2019-08-05 13:50:43', 'TheFinishLine-Level2'),
(599, 1, 2, 'LaternLight-Level1', '', '', 'uploads/LanternLight.png', 1, '', '', '2019-05-02', '', '2019-08-05 13:50:43', 'LaternLight-Level1'),
(600, 1, 2, 'LaternLight-Level2', '', '', 'uploads/LanternLight.png', 1, '', '', '2019-05-02', '', '2019-08-05 13:50:43', 'LaternLight-Level2'),
(601, 1, 2, 'ObjectMatch-Level1', '', '', 'uploads/ObjectMatch-Level1.png', 1, '', '', '2019-05-02', '', '2019-08-05 13:50:43', 'ObjectMatch-Level1'),
(602, 1, 2, 'CompleteMe-Level1', '', '', 'uploads/CompleteMe.png', 1, '', '', '2019-05-02', '', '2019-08-05 13:50:43', 'CompleteMe-Level1'),
(603, 1, 2, 'MysteryShape-Level1', '', '', 'uploads/MysteryShape-Level1.png', 1, '', '', '2019-05-02', '', '2019-08-05 13:50:43', 'MysteryShape-Level1'),
(604, 1, 2, 'ShapeFocus-Level1', '', '', 'uploads/ShapeFocus-Level1.png', 1, '', '', '2019-05-02', '', '2019-08-05 13:50:43', 'ShapeFocus-Level1'),
(605, 1, 2, 'MatchmeObjects-Level1', '', '', 'uploads/MatchMe-Level1_3344377102.png.png', 1, '', '', '2019-05-02', '', '2019-08-05 13:50:43', 'MatchmeObjects-Level1'),
(606, 1, 2, 'ShapeGrid-Level2', '', '', 'uploads/ShapeGrid-KG.png', 1, '', '', '2019-05-02', '', '2019-08-05 13:50:43', 'ShapeGrid-Level2'),
(607, 1, 2, 'ObjectMatch-Level2', '', '', 'uploads/ObjectMatch-Level1.png', 1, '', '', '2019-05-02', '', '2019-08-05 13:50:43', 'ObjectMatch-Level2'),
(608, 1, 2, 'CompleteMe-Level2', '', '', 'uploads/CompleteMe.png', 1, '', '', '2019-05-02', '', '2019-08-05 13:50:43', 'CompleteMe-Level2'),
(609, 1, 2, 'MysteryShape-Level2', '', '', 'uploads/MysteryShape-Level1.png', 1, '', '', '2019-05-02', '', '2019-08-05 13:50:43', 'MysteryShape-Level2'),
(610, 1, 2, 'ShapeFocus-Level2', '', '', 'uploads/ShapeFocus-Level2.png', 1, '', '', '2019-05-02', '', '2019-08-05 13:50:43', 'ShapeFocus-Level2'),
(611, 1, 2, 'MatchmeObjects-Level2', '', '', 'uploads/MatchMe-Level1_3344377102.png.png', 1, '', '', '2019-05-02', '', '2019-08-05 13:50:43', 'MatchmeObjects-Level2'),
(612, 1, 2, 'TallShort-Level1', '', '', 'uploads/New-Kinder-TallShort.png', 1, '', '', '2019-05-02', '', '2019-08-05 13:50:43', 'TallShort-Level1'),
(613, 1, 2, 'BigSmall-Level1', '', '', 'uploads/Big-Small-Level1.png', 1, '', '', '2019-05-02', '', '2019-08-05 13:50:43', 'BigSmall-Level1'),
(614, 1, 2, 'ShadowMatch-Level1', '', '', 'uploads/New-Kinder-Shadowmatch.png', 1, '', '', '2019-05-02', '', '2019-08-05 13:50:43', 'ShadowMatch-Level1'),
(615, 1, 2, 'GiftBox-Level1', '', '', 'uploads/GiftBox.png', 1, '', '', '2019-05-02', '', '2019-08-05 13:50:43', 'GiftBox-Level1'),
(616, 1, 2, 'TallShort-Level2', '', '', 'uploads/New-Kinder-TallShort.png', 1, '', '', '2019-05-02', '', '2019-08-05 13:50:43', 'TallShort-Level2'),
(617, 1, 2, 'BigSmall-Level2', '', '', 'uploads/Big-Small-Level1.png', 1, '', '', '2019-05-02', '', '2019-08-05 13:50:43', 'BigSmall-Level2'),
(618, 1, 2, 'GiftBox-Level2', '', '', 'uploads/GiftBox.png', 1, '', '', '2019-05-02', '', '2019-08-05 13:50:43', 'GiftBox-Level2'),
(619, 1, 3, 'GroupRepresentation-Level1', '', '', 'uploads/PatternRepresentation-Level1_7518243058.png', 1, '', '', '2019-05-02', '', '2019-08-05 13:50:43', 'GroupRepresentation-Level1'),
(620, 1, 3, 'MatchTheShape-Level1', '', '', 'uploads/MatchTheShape.png', 1, '', '', '2019-05-02', '', '2019-08-05 13:50:43', 'MatchTheShape-Level1'),
(621, 1, 3, 'Findtheshapes-Level1', '', '', 'uploads/FindTheShapes.png', 1, '', '', '2019-05-02', '', '2019-08-05 13:50:43', 'Findtheshapes-Level1'),
(622, 1, 3, 'Matchtheshape-Level2', '', '', 'uploads/MatchTheShape.png', 1, '', '', '2019-05-02', '', '2019-08-05 13:50:43', 'Matchtheshape-Level2'),
(623, 1, 3, 'Findtheshapes-Level2', '', '', 'uploads/FindTheShapes.png', 1, '', '', '2019-05-02', '', '2019-08-05 13:50:43', 'Findtheshapes-Level2'),
(624, 1, 3, 'CountMe-Level1', '', '', 'uploads/New-Kinder-CountMe.png', 1, '', '', '2019-05-02', '', '2019-08-05 13:50:43', 'CountMe-Level1'),
(625, 1, 3, 'Buttonholes-Level1', '', '', 'uploads/ButtonHoles.png', 1, '', '', '2019-05-02', '', '2019-08-05 13:50:43', 'Buttonholes-Level1'),
(626, 1, 3, 'CountMe-Level2', '', '', 'uploads/New-Kinder-CountMe.png', 1, '', '', '2019-05-02', '', '2019-08-05 13:50:43', 'CountMe-Level2'),
(627, 1, 3, 'Buttonholes-Level2', '', '', 'uploads/ButtonHoles.png', 1, '', '', '2019-05-02', '', '2019-08-05 13:50:43', 'Buttonholes-Level2'),
(628, 1, 3, 'OddShape-Level2', '', '', 'uploads/OddShape-Level2.png', 1, '', '', '2019-05-02', '', '2019-08-05 13:50:43', 'OddShape-Level2'),
(1001, 2, 59, 'BusRide-Level1', '', 'Memory', 'uploads/BusRide-Level1_9721776302.png', 1, '1', '', '2019-06-11', '', '2019-08-12 15:10:46', 'BusRide-Level1'),
(1002, 2, 60, 'EyeCells-Level1', '', 'VP', 'uploads/EyeCells-Level1_7996039153.png', 1, '1', '', '2019-06-11', '', '2019-08-12 15:10:46', 'EyeCells-Level1'),
(1003, 2, 61, 'LastLegend-Level1', '', 'FA', 'uploads/LastLegend-Level1_3132143379.png', 1, '1', '', '2019-06-11', '', '2019-08-12 15:10:46', 'LastLegend-Level1'),
(1004, 2, 62, 'WhatComesNext', '', 'PS', 'uploads/WhatComesNext_8895443235.png', 1, '1', '', '2019-06-11', '', '2019-08-12 15:10:46', 'WhatComesNext'),
(1005, 2, 63, 'WhoAmI-Shapes', '', 'LI', 'uploads/WhoAmI-Shapes_7515025790.png', 1, '1', '', '2019-06-11', '', '2019-08-12 15:10:46', 'WhoAmI-Shapes'),
(1006, 2, 59, 'MemoryCheck-Level2', '', 'Memory', 'uploads/MemoryCheck-Level2_8882285202.png', 1, '2', '', '2019-06-11', '', '2019-08-12 15:10:46', 'MemoryCheck-Level2'),
(1007, 2, 60, 'EyeCells-Level2', '', 'VP', 'uploads/EyeCells-Level2_5889739277.png', 1, '2', '', '2019-06-11', '', '2019-08-12 15:10:46', 'EyeCells-Level2'),
(1008, 2, 61, 'LetterJigsaw-Level2', '', 'FA', 'uploads/AlphabetJigsaw-Level2_439756815.png', 1, '2', '', '2019-06-11', '', '2019-08-12 15:10:46', 'LetterJigsaw-Level2'),
(1009, 2, 62, 'ParaMaster-Level1', '', 'PS', 'uploads/ParaMaster-Level1_8246283596.png', 1, '2', '', '2019-06-11', '', '2019-08-12 15:10:46', 'ParaMaster-Level1'),
(1010, 2, 63, 'WhoAmI-Clothes', '', 'LI', 'uploads/WhoAmI-Clothes_236435011.png', 1, '2', '', '2019-06-11', '', '2019-08-12 15:10:46', 'WhoAmI-Clothes'),
(1011, 2, 59, 'BalloonBurst-Level2', '', 'Memory', 'uploads/BalloonBurst-Level2_244336309.png', 1, '3', '', '2019-06-11', '', '2019-08-12 15:10:46', 'BalloonBurst-Level2'),
(1012, 2, 60, 'BestFit-Level4', '', 'VP', 'uploads/BestFit-Level3_8792649721.png', 1, '3', '', '2019-06-11', '', '2019-08-12 15:10:46', 'BestFit-Level4'),
(1013, 2, 61, 'AnimalSpell', '', 'FA', 'uploads/AnimalSpell_5479293791.png', 1, '3', '', '2019-06-11', '', '2019-08-12 15:10:46', 'AnimalSpell'),
(1014, 2, 62, 'NumberDecode-Level2', '', 'PS', 'uploads/NumberDecode-Level2_2425581049.png', 1, '3', '', '2019-06-11', '', '2019-08-12 15:10:46', 'NumberDecode-Level2'),
(1015, 2, 63, 'Anagrams-Clothes', '', 'LI', 'uploads/Anagrams-Clothing_8464276143.png', 1, '3', '', '2019-06-11', '', '2019-08-12 15:10:46', 'Anagrams-Clothes'),
(1016, 2, 59, 'BalloonBurst-Level3', '', 'Memory', 'uploads/BalloonBurst-Level3_2492009233.png', 1, '4', '', '2019-06-11', '', '2019-08-12 15:10:46', 'BalloonBurst-Level3'),
(1017, 2, 60, 'ReverseReading-Level5', '', 'VP', 'uploads/ReverseReading-Level5_5669675888.png', 1, '4', '', '2019-06-11', '', '2019-08-12 15:10:46', 'ReverseReading-Level5'),
(1018, 2, 61, 'DownUnder-Level2', '', 'FA', 'uploads/DownUnder-Level2_5347298909.png', 1, '4', '', '2019-06-11', '', '2019-08-12 15:10:46', 'DownUnder-Level2'),
(1019, 2, 62, 'ParaMaster-Level3', '', 'PS', 'uploads/ParaMaster-Level3_8316638404.png', 1, '4', '', '2019-06-11', '', '2019-08-12 15:10:46', 'ParaMaster-Level3'),
(1020, 2, 63, 'Anagrams-Math', '', 'LI', 'uploads/Anagrams-Math_3996595479.png', 1, '4', '', '2019-06-11', '', '2019-08-12 15:10:46', 'Anagrams-Math'),
(1021, 2, 59, 'BalloonBurst-Level4', '', 'Memory', 'uploads/BalloonBurst-Level4_2785141328.png', 1, '5', '', '2019-06-11', '', '2019-08-12 15:10:46', 'BalloonBurst-Level4'),
(1022, 2, 60, 'JustNotHalf-Level2', '', 'VP', 'uploads/JustNotHalf-Level2_2203953666.png', 1, '5', '', '2019-06-11', '', '2019-08-12 15:10:46', 'JustNotHalf-Level2'),
(1023, 2, 61, 'LastLegend-Level4', '', 'FA', 'uploads/LastLegend-Level4_3372493218.png', 1, '5', '', '2019-06-11', '', '2019-08-12 15:10:46', 'LastLegend-Level4'),
(1024, 2, 62, 'NumberSeries-Level2', '', 'PS', 'uploads/NumberSeries-Level2_1761797624.png', 1, '5', '', '2019-06-11', '', '2019-08-12 15:10:46', 'NumberSeries-Level2'),
(1025, 2, 63, 'Anagrams-HouseHold', '', 'LI', 'uploads/Anagrams-Household_4300776333.png', 1, '5', '', '2019-06-11', '', '2019-08-12 15:10:46', 'Anagrams-HouseHold'),
(1026, 2, 59, 'AlphaNumericEncode-Level5', '', 'Memory', 'uploads/AlphaNumericEncode-Level5_5666280859.png', 1, '6', '', '2019-06-11', '', '2019-08-12 15:10:46', 'AlphaNumericEncode-Level5'),
(1027, 2, 60, 'CubeSherlock-Level1', '', 'VP', 'uploads/CubeSherlock-Level1_9494013660.png', 1, '6', '', '2019-06-11', '', '2019-08-12 15:10:46', 'CubeSherlock-Level1'),
(1028, 2, 61, 'DeepUnder-Level4', '', 'FA', 'uploads/DeepUnder-Level4_8108292836.png', 1, '6', '', '2019-06-11', '', '2019-08-12 15:10:46', 'DeepUnder-Level4'),
(1029, 2, 62, 'ParaMaster-Level5', '', 'PS', 'uploads/ParaMaster-Level5_5265605337.png', 1, '6', '', '2019-06-11', '', '2019-08-12 15:10:46', 'ParaMaster-Level5'),
(1030, 2, 63, 'Anagrams-FourLetterWord', '', 'LI', 'uploads/Anagrams-FourLetterWords_96878870.png', 1, '6', '', '2019-06-11', '', '2019-08-12 15:10:46', 'Anagrams-FourLetterWord'),
(1031, 2, 59, 'AlphaNumericEncode-Level6', '', 'Memory', 'uploads/AlphaNumericEncode-Level6_7225111038.png', 1, '7', '', '2019-06-11', '', '2019-08-12 15:10:46', 'AlphaNumericEncode-Level6'),
(1032, 2, 60, 'ChooseTwoToMakeOne', '', 'VP', 'uploads/ChooseTwoToMakeOne_7422157558.png', 1, '7', '', '2019-06-11', '', '2019-08-12 15:10:46', 'ChooseTwoToMakeOne'),
(1033, 2, 61, 'ShapeRollers-Level4', '', 'FA', 'uploads/ShapeRollers-Level4_452656652.png', 1, '7', '', '2019-06-11', '', '2019-08-12 15:10:46', 'ShapeRollers-Level4'),
(1034, 2, 62, 'ATeddyForATeddy-Level3', '', 'PS', 'uploads/ATeddyForATeddy-Level3_1824636519.png', 1, '7', '', '2019-06-11', '', '2019-08-12 15:10:46', 'ATeddyForATeddy-Level3'),
(1035, 2, 63, 'Anagrams-Geography', '', 'LI', 'uploads/Anagrams-Geography_5710392687.png', 1, '7', '', '2019-06-11', '', '2019-08-12 15:10:46', 'Anagrams-Geography'),
(1036, 2, 59, 'CoordinateGraph-Level1', '', 'Memory', 'uploads/CoordinateGraph-Level1_1309713018.png', 1, '8', '', '2019-06-11', '', '2019-08-12 15:10:46', 'CoordinateGraph-Level1'),
(1037, 2, 60, 'JustNotHalf-Level4', '', 'VP', 'uploads/JustNotHalf-Level4_2555441330.png', 1, '8', '', '2019-06-11', '', '2019-08-12 15:10:46', 'JustNotHalf-Level4'),
(1038, 2, 61, 'ColorInColor-Level1', '', 'FA', 'uploads/ColorInColor-Level1_1204938488.png', 1, '8', '', '2019-06-11', '', '2019-08-12 15:10:46', 'ColorInColor-Level1'),
(1039, 2, 62, 'Equate-Level1', '', 'PS', 'uploads/Equate-Level1_3846404044.png', 1, '8', '', '2019-06-11', '', '2019-08-12 15:10:46', 'Equate-Level1'),
(1040, 2, 63, 'GuessTheWord-Level1', '', 'LI', 'uploads/GuessTheWord-Level1_8028972977.png', 1, '8', '', '2019-06-11', '', '2019-08-12 15:10:46', 'GuessTheWord-Level1'),
(1041, 2, 59, 'AlphaNumericEncode-Level1', '', 'Memory', 'uploads/AlphaNumericEncode-Level1_4518458847.png', 1, '1', '', '0000-00-00', '', '2019-08-12 15:10:46', 'AlphaNumericEncode-Level1'),
(1042, 2, 60, 'ObjectShade', '', 'VP', 'uploads/ObjectShade_7239343100.png', 1, '1', '', '0000-00-00', '', '2019-08-12 15:10:46', 'ObjectShade'),
(1043, 2, 61, 'NumberJigsaw-Level1', '', 'FA', 'uploads/NumberJigsaw-Level1_3981064627.png', 1, '1', '', '0000-00-00', '', '2019-08-12 15:10:46', 'NumberJigsaw-Level1'),
(1044, 2, 62, 'WordShapes-Level1', '', 'PS', 'uploads/WordShapes-Level1_5870673032.png', 1, '1', '', '0000-00-00', '', '2019-08-12 15:10:46', 'WordShapes-Level1'),
(1045, 2, 63, 'WhoAmI-Birds', '', 'LI', 'uploads/WhoAmI-Birds_7869069152.png', 1, '1', '', '0000-00-00', '', '2019-08-12 15:10:46', 'WhoAmI-Birds'),
(1046, 2, 59, 'BalloonBurst-Level1', '', 'Memory', 'uploads/BalloonBurst-Level1_8117342898.png', 1, '2', '', '0000-00-00', '', '2019-08-12 15:10:46', 'BalloonBurst-Level1'),
(1047, 2, 60, 'CharacterShade-Level3', '', 'VP', 'uploads/CharacterShade-Level3_3322312142.png', 1, '2', '', '0000-00-00', '', '2019-08-12 15:10:46', 'CharacterShade-Level3'),
(1048, 2, 61, 'ObjectSpell-Level1', '', 'FA', 'uploads/ObjectSpell-Level1_6468444657.png', 1, '2', '', '0000-00-00', '', '2019-08-12 15:10:46', 'ObjectSpell-Level1'),
(1049, 2, 62, 'Reshuffle-Level1', '', 'PS', 'uploads/Reshuffle-Level1_9448890620.png', 1, '2', '', '0000-00-00', '', '2019-08-12 15:10:46', 'Reshuffle-Level1'),
(1050, 2, 63, 'WhoAmI-Insects', '', 'LI', 'uploads/WhoAmI-Insects_9486121060.png', 1, '2', '', '0000-00-00', '', '2019-08-12 15:10:46', 'WhoAmI-Insects'),
(1051, 2, 59, 'BusRide-Level2', '', 'Memory', 'uploads/BusRide-Level2_6232746895.png', 1, '3', '', '0000-00-00', '', '2019-08-12 15:10:46', 'BusRide-Level2'),
(1052, 2, 60, 'Hand2Hand', '', 'VP', 'uploads/Hand2Hand_5783699043.png', 1, '3', '', '0000-00-00', '', '2019-08-12 15:10:46', 'Hand2Hand'),
(1053, 2, 61, 'BallShooter-Level1', '', 'FA', 'uploads/Ball_Shooter.png', 1, '3', '', '0000-00-00', '', '2019-08-12 15:10:46', 'BallShooter-Level1'),
(1054, 2, 62, 'NumbersOnTheWheel-Level2', '', 'PS', 'uploads/NumbersOnTheWheel-Level2_5032758838.png', 1, '3', '', '0000-00-00', '', '2019-08-12 15:10:46', 'NumbersOnTheWheel-Level2'),
(1055, 2, 63, 'NameLand-Level1', '', 'LI', 'uploads/NameLand-Level1_3850891082.png', 1, '3', '', '0000-00-00', '', '2019-08-12 15:10:46', 'NameLand-Level1'),
(1056, 2, 59, 'CycleRace-Level3', '', 'Memory', 'uploads/CycleRace-Level3_6173525671.png', 1, '4', '', '0000-00-00', '', '2019-08-12 15:10:46', 'CycleRace-Level3'),
(1057, 2, 60, 'MirrorMatch-Level1', '', 'VP', 'uploads/MirrorMatch-Level1_3191918600.png', 1, '4', '', '0000-00-00', '', '2019-08-12 15:10:46', 'MirrorMatch-Level1'),
(1058, 2, 61, 'NumberJigsaw-Level3', '', 'FA', 'uploads/NumberJigsaw-Level3_7143653305.png', 1, '4', '', '0000-00-00', '', '2019-08-12 15:10:46', 'NumberJigsaw-Level3'),
(1059, 2, 62, 'NumbersOnTheWheel-Level3', '', 'PS', 'uploads/NumbersOnTheWheel-Level3_7181768785.png', 1, '4', '', '0000-00-00', '', '2019-08-12 15:10:46', 'NumbersOnTheWheel-Level3'),
(1060, 2, 63, 'ArrangeTheWords-Level3', '', 'LI', 'uploads/ArrangeTheWords-Level3_6521334904.png', 1, '4', '', '0000-00-00', '', '2019-08-12 15:10:46', 'ArrangeTheWords-Level3'),
(1061, 2, 59, 'CycleRace-Level4', '', 'Memory', 'uploads/CycleRace-Level4_4780295565.png', 1, '5', '', '0000-00-00', '', '2019-08-12 15:10:46', 'CycleRace-Level4'),
(1062, 2, 60, 'MirrorMatch-Level2', '', 'VP', 'uploads/MirrorMatch-Level2_4265700853.png', 1, '5', '', '0000-00-00', '', '2019-08-12 15:10:46', 'MirrorMatch-Level2'),
(1063, 2, 61, 'LetterJigsaw-Level4', '', 'FA', 'uploads/AlphabetJigsaw-Level4_5252252509.png', 1, '5', '', '0000-00-00', '', '2019-08-12 15:10:46', 'LetterJigsaw-Level4'),
(1064, 2, 62, 'NumbersOnTheWheel-Level4', '', 'PS', 'uploads/NumbersOnTheWheel-Level4_1754132225.png', 1, '5', '', '0000-00-00', '', '2019-08-12 15:10:46', 'NumbersOnTheWheel-Level4'),
(1065, 2, 63, 'Anagrams-Vehicles', '', 'LI', 'uploads/Anagrams-Vehicles_8503454732.png', 1, '5', '', '0000-00-00', '', '2019-08-12 15:10:46', 'Anagrams-Vehicles'),
(1066, 2, 59, 'AnimalWatch-Level1', '', 'Memory', 'uploads/AnimalWatch-Level1_8736748136.png', 1, '6', '', '0000-00-00', '', '2019-08-12 15:10:46', 'AnimalWatch-Level1'),
(1067, 2, 60, 'FindTheTwins-Level2', '', 'VP', 'uploads/FindTheTwins-Level2_3434965950.png', 1, '6', '', '0000-00-00', '', '2019-08-12 15:10:46', 'FindTheTwins-Level2'),
(1068, 2, 61, 'LastLegend-Level5', '', 'FA', 'uploads/LastLegend-Level5_7495082467.png', 1, '6', '', '0000-00-00', '', '2019-08-12 15:10:46', 'LastLegend-Level5'),
(1069, 2, 62, 'FitMeRight-Level2', '', 'PS', 'uploads/FitMeRight-Level2_340231573.png', 1, '6', '', '0000-00-00', '', '2019-08-12 15:10:46', 'FitMeRight-Level2'),
(1070, 2, 63, 'Anagrams-Jobs', '', 'LI', 'uploads/Anagrams-Jobs_2256901105.png', 1, '6', '', '0000-00-00', '', '2019-08-12 15:10:46', 'Anagrams-Jobs'),
(1071, 2, 59, 'CycleRace-Level6', '', 'Memory', 'uploads/CycleRace-Level6_5745665873.png', 1, '7', '', '0000-00-00', '', '2019-08-12 15:10:46', 'CycleRace-Level6'),
(1072, 2, 60, 'FlipTrick-Level1', '', 'VP', 'uploads/FlipTrick-Level1_6290403776.png', 1, '7', '', '0000-00-00', '', '2019-08-12 15:10:46', 'FlipTrick-Level1'),
(1073, 2, 61, 'Rainbow-Level2', '', 'FA', 'uploads/Rainbow-Level2_2451191339.png', 1, '7', '', '0000-00-00', '', '2019-08-12 15:10:46', 'Rainbow-Level2'),
(1074, 2, 62, 'Reshuffle-Level6', '', 'PS', 'uploads/Reshuffle-Level6_4803005247.png', 1, '7', '', '0000-00-00', '', '2019-08-12 15:10:46', 'Reshuffle-Level6'),
(1075, 2, 63, 'Anagrams-Military', '', 'LI', 'uploads/Anagrams-Military_2205101763.png', 1, '7', '', '0000-00-00', '', '2019-08-12 15:10:46', 'Anagrams-Military'),
(1076, 2, 59, 'CoordinateGraph-Level2', '', 'Memory', 'uploads/CoordinateGraph-Level2_2700936608.png', 1, '8', '', '0000-00-00', '', '2019-08-12 15:10:46', 'CoordinateGraph-Level2'),
(1077, 2, 60, 'MirrorImage-Level2', '', 'VP', 'uploads/MirrorImage-Level2_8513625911.png', 1, '8', '', '0000-00-00', '', '2019-08-12 15:10:46', 'MirrorImage-Level2'),
(1078, 2, 61, 'NumberMe-Level1', '', 'FA', 'uploads/NumberMe-Level1_9366972525.png', 1, '8', '', '0000-00-00', '', '2019-08-12 15:10:46', 'NumberMe-Level1'),
(1079, 2, 62, 'NumbersOnTheVertices-Level1', '', 'PS', 'uploads/NumbersOnTheVertices-Level1_6839827257.png', 1, '8', '', '0000-00-00', '', '2019-08-12 15:10:46', 'NumbersOnTheVertices-Level1'),
(1080, 2, 63, 'GuessTheWord-Level2', '', 'LI', 'uploads/GuessTheWord-Level2_718786111.png', 1, '8', '', '0000-00-00', '', '2019-08-12 15:10:46', 'GuessTheWord-Level2'),
(1081, 2, 59, 'MindCapture-Level1', '', 'Memory', 'uploads/MindCapture-Level1_9870321140.png', 1, '1', '', '0000-00-00', '', '2019-08-12 15:10:46', 'MindCapture-Level1'),
(1082, 2, 60, 'WordWipe-Level1', '', 'VP', 'uploads/WordWipe-Level1_7054595984.png', 1, '1', '', '0000-00-00', '', '2019-08-12 15:10:46', 'WordWipe-Level1'),
(1083, 2, 61, 'StarLight-Level3', '', 'FA', 'uploads/StarLight-Level1_9186881147.png', 1, '1', '', '0000-00-00', '', '2019-08-12 15:10:46', 'StarLight-Level3'),
(1084, 2, 62, 'AddMaster-Level1', '', 'PS', 'uploads/AddMaster-Level1_5437691258.png', 1, '1', '', '0000-00-00', '', '2019-08-12 15:10:46', 'AddMaster-Level1'),
(1085, 2, 63, 'CompoundWords', '', 'LI', 'uploads/CompoundWords_12777526.png', 1, '1', '', '0000-00-00', '', '2019-08-12 15:10:46', 'CompoundWords'),
(1086, 2, 59, 'CycleRace-Level1', '', 'Memory', 'uploads/CycleRace-Level1_2532993447.png', 1, '2', '', '0000-00-00', '', '2019-08-12 15:10:46', 'CycleRace-Level1'),
(1087, 2, 60, 'MatchMe-Level2', '', 'VP', 'uploads/MatchMe-Level2_5947240493.png', 1, '2', '', '0000-00-00', '', '2019-08-12 15:10:46', 'MatchMe-Level2'),
(1088, 2, 61, 'LastLegend-Level2', '', 'FA', 'uploads/LastLegend-Level2_5781244020.png', 1, '2', '', '0000-00-00', '', '2019-08-12 15:10:46', 'LastLegend-Level2'),
(1089, 2, 62, 'NumberDecode-Level1', '', 'PS', 'uploads/NumberDecode-Level1_5552706075.png', 1, '2', '', '0000-00-00', '', '2019-08-12 15:10:46', 'NumberDecode-Level1'),
(1090, 2, 63, 'WhoAmI-Transport', '', 'LI', 'uploads/WhoAmI-Transport_156703181.png', 1, '2', '', '0000-00-00', '', '2019-08-12 15:10:46', 'WhoAmI-Transport'),
(1091, 2, 59, 'CycleRace-Level2', '', 'Memory', 'uploads/CycleRace-Level2_5460967603.png', 1, '3', '', '0000-00-00', '', '2019-08-12 15:10:46', 'CycleRace-Level2'),
(1092, 2, 60, 'JustNotHalf-Level1', '', 'VP', 'uploads/JustNotHalf-Level1_6506787771.png', 1, '3', '', '0000-00-00', '', '2019-08-12 15:10:46', 'JustNotHalf-Level1'),
(1093, 2, 61, 'ObjectSpell-Level2', '', 'FA', 'uploads/ObjectSpell-Level2_9643486370.png', 1, '3', '', '0000-00-00', '', '2019-08-12 15:10:46', 'ObjectSpell-Level2'),
(1094, 2, 62, 'ParaMaster-Level2', '', 'PS', 'uploads/ParaMaster-Level2_9887385293.png', 1, '3', '', '0000-00-00', '', '2019-08-12 15:10:46', 'ParaMaster-Level2'),
(1095, 2, 63, 'WhoAmI_SeaAnimals', '', 'LI', 'uploads/WhoAmI-SeaAnimals_9400465255.png', 1, '3', '', '0000-00-00', '', '2019-08-12 15:10:46', 'WhoAmI_SeaAnimals'),
(1096, 2, 59, 'DialAnumber', '', 'Memory', 'uploads/DialANumber_8347820923.png', 1, '4', '', '0000-00-00', '', '2019-08-12 15:10:46', 'DialAnumber'),
(1097, 2, 60, 'CharacterShade-Level4', '', 'VP', 'uploads/CharacterShade-Level4_7572658732.png', 1, '4', '', '0000-00-00', '', '2019-08-12 15:10:46', 'CharacterShade-Level4'),
(1098, 2, 61, 'BalloonLight-Level3', '', 'FA', 'uploads/DarkLight-Level3_6337577155.png', 1, '4', '', '0000-00-00', '', '2019-08-12 15:10:46', 'BalloonLight-Level3'),
(1099, 2, 62, 'Reshuffle-Level3', '', 'PS', 'uploads/Reshuffle-Level3_2661516019.png', 1, '4', '', '0000-00-00', '', '2019-08-12 15:10:46', 'Reshuffle-Level3'),
(1100, 2, 63, 'NameLand-Level2', '', 'LI', 'uploads/NameLand-Level2_9281079615.png', 1, '4', '', '0000-00-00', '', '2019-08-12 15:10:46', 'NameLand-Level2'),
(1101, 2, 59, 'MemoryCheck-Level5', '', 'Memory', 'uploads/MemoryCheck-Level5_9116933126.png', 1, '5', '', '0000-00-00', '', '2019-08-12 15:10:46', 'MemoryCheck-Level5'),
(1102, 2, 60, 'IAmCube-Level1', '', 'VP', 'uploads/IAmCube-Level1_3901067436.png', 1, '5', '', '0000-00-00', '', '2019-08-12 15:10:46', 'IAmCube-Level1'),
(1103, 2, 61, 'NumberJigsaw-Level4', '', 'FA', 'uploads/NumberJigsaw-Level4_3807144016.png', 1, '5', '', '0000-00-00', '', '2019-08-12 15:10:46', 'NumberJigsaw-Level4'),
(1104, 2, 62, 'HueCram', '', 'PS', 'uploads/HueCram_438871416.png', 1, '5', '', '0000-00-00', '', '2019-08-12 15:10:46', 'HueCram'),
(1105, 2, 63, 'MissingLetter-Level2', '', 'LI', 'uploads/MissingLetter-Level2_3469503405.png', 1, '5', '', '0000-00-00', '', '2019-08-12 15:10:46', 'MissingLetter-Level2'),
(1106, 2, 59, 'SequenceMemory-Level5', '', 'Memory', 'uploads/SequenceMemory-Level5_7487447718.png', 1, '6', '', '0000-00-00', '', '2019-08-12 15:10:46', 'SequenceMemory-Level5'),
(1107, 2, 60, 'JustNotHalf-Level3', '', 'VP', 'uploads/JustNotHalf-Level3_486829234.png', 1, '6', '', '0000-00-00', '', '2019-08-12 15:10:46', 'JustNotHalf-Level3'),
(1108, 2, 61, 'Rainbow-Level1', '', 'FA', 'uploads/Rainbow-Level1_1321175633.png', 1, '6', '', '0000-00-00', '', '2019-08-12 15:10:46', 'Rainbow-Level1'),
(1109, 2, 62, 'Reshuffle-Level5', '', 'PS', 'uploads/Reshuffle-Level5_1823949897.png', 1, '6', '', '0000-00-00', '', '2019-08-12 15:10:46', 'Reshuffle-Level5'),
(1110, 2, 63, 'Anagrams-Schools', '', 'LI', 'uploads/Anagrams-School_220320839.png', 1, '6', '', '0000-00-00', '', '2019-08-12 15:10:46', 'Anagrams-Schools'),
(1111, 2, 59, 'GraphDecoder', '', 'Memory', 'uploads/GraphDecoder_6767004569.png', 1, '7', '', '0000-00-00', '', '2019-08-12 15:10:46', 'GraphDecoder'),
(1112, 2, 60, 'MirrorImage-Level1', '', 'VP', 'uploads/MirrorImage-Level1_4596876199.png', 1, '7', '', '0000-00-00', '', '2019-08-12 15:10:46', 'MirrorImage-Level1'),
(1113, 2, 61, 'ColorInColor-Level2', '', 'FA', 'uploads/ColorInColor-Level2_4620457286.png', 1, '7', '', '0000-00-00', '', '2019-08-12 15:10:46', 'ColorInColor-Level2'),
(1114, 2, 62, 'Shopping-Level1', '', 'PS', 'uploads/Shopping-Level1_6256451136.png', 1, '7', '', '0000-00-00', '', '2019-08-12 15:10:46', 'Shopping-Level1'),
(1115, 2, 63, 'Anagrams-People', '', 'LI', 'uploads/Anagrams-People_1156277623.png', 1, '7', '', '0000-00-00', '', '2019-08-12 15:10:46', 'Anagrams-People'),
(1116, 2, 59, 'MisplacedBuddy-Level1', '', 'Memory', 'uploads/MisplacedBuddy-Level1_4661093535.png', 1, '8', '', '0000-00-00', '', '2019-08-12 15:10:46', 'MisplacedBuddy-Level1'),
(1117, 2, 60, 'WhoIsNotThere-Level1', '', 'VP', 'uploads/WhoIsNotThere-Level1_3340305127.png', 1, '8', '', '0000-00-00', '', '2019-08-12 15:10:46', 'WhoIsNotThere-Level1'),
(1118, 2, 61, 'NumberMe-Level2', '', 'FA', 'uploads/NumberMe-Level2_1924527920.png', 1, '8', '', '0000-00-00', '', '2019-08-12 15:10:46', 'NumberMe-Level2'),
(1119, 2, 62, 'Shopping-Level2', '', 'PS', 'uploads/Shopping-Level2_4992981352.png', 1, '8', '', '0000-00-00', '', '2019-08-12 15:10:46', 'Shopping-Level2'),
(1120, 2, 63, 'JumbledLetters-Level1', '', 'LI', 'uploads/JumbledLetters-Level1_7572877304.png', 1, '8', '', '0000-00-00', '', '2019-08-12 15:10:46', 'JumbledLetters-Level1'),
(1121, 2, 59, 'MemoryCheck-Level1', '', 'Memory', 'uploads/MemoryCheck-Level1_1938757994.png', 1, '1', '', '0000-00-00', '', '2019-08-12 15:10:46', 'MemoryCheck-Level1'),
(1122, 2, 60, 'BestFit-Level3', '', 'VP', 'uploads/BestFit-Level2_6896948479.png', 1, '1', '', '0000-00-00', '', '2019-08-12 15:10:46', 'BestFit-Level3'),
(1123, 2, 61, 'StarLight-Level4', '', 'FA', 'uploads/StarLight-Level2_988681958.png', 1, '1', '', '0000-00-00', '', '2019-08-12 15:10:46', 'StarLight-Level4'),
(1124, 2, 62, 'HeavyOrLight-Level1', '', 'PS', 'uploads/HeavyOrLight-Level1_9671432706.png', 1, '1', '', '0000-00-00', '', '2019-08-12 15:10:46', 'HeavyOrLight-Level1'),
(1125, 2, 63, 'WhoAmI-HouseHoldThings', '', 'LI', 'uploads/WhoAmI-HouseHoldThings_8783441544.png', 1, '1', '', '0000-00-00', '', '2019-08-12 15:10:46', 'WhoAmI-HouseHoldThings'),
(1126, 2, 59, 'SequenceMemory-Level1', '', 'Memory', 'uploads/SequenceMemory-Level1_903124888.png', 1, '2', '', '0000-00-00', '', '2019-08-12 15:10:46', 'SequenceMemory-Level1'),
(1127, 2, 60, 'EdCells-Level2', '', 'VP', 'uploads/EdCells-Level2_812620040.png', 1, '2', '', '0000-00-00', '', '2019-08-12 15:10:46', 'EdCells-Level2'),
(1128, 2, 61, 'DownUnder-Level1', '', 'FA', 'uploads/DownUnder-Level1_9248090591.png', 1, '2', '', '0000-00-00', '', '2019-08-12 15:10:46', 'DownUnder-Level1'),
(1129, 2, 62, 'NumbersOnTheWheel-Level1', '', 'PS', 'uploads/NumbersOnTheWheel-Level1_5239142207.png', 1, '2', '', '0000-00-00', '', '2019-08-12 15:10:46', 'NumbersOnTheWheel-Level1'),
(1130, 2, 63, 'WhoAmI-School', '', 'LI', 'uploads/WhoAmI-School_1506193187.png', 1, '2', '', '0000-00-00', '', '2019-08-12 15:10:46', 'WhoAmI-School'),
(1131, 2, 59, 'AlphaNumericEncode-Level2', '', 'Memory', 'uploads/AlphaNumericEncode-Level2_546242767.png', 1, '3', '', '0000-00-00', '', '2019-08-12 15:10:46', 'AlphaNumericEncode-Level2'),
(1132, 2, 60, 'EdCells-Level3', '', 'VP', 'uploads/EdCells-Level3_4655870916.png', 1, '3', '', '0000-00-00', '', '2019-08-12 15:10:46', 'EdCells-Level3'),
(1133, 2, 61, 'BalloonLight-Level2', '', 'FA', 'uploads/DarkLight-Level2_7840619147.png', 1, '3', '', '0000-00-00', '', '2019-08-12 15:10:46', 'BalloonLight-Level2'),
(1134, 2, 62, 'AddMaster-Level2', '', 'PS', 'uploads/AddMaster-Level2_6791430432.png', 1, '3', '', '0000-00-00', '', '2019-08-12 15:10:46', 'AddMaster-Level2'),
(1135, 2, 63, 'Anagrams-Animals', '', 'LI', 'uploads/Anagrams-Animals_690025119.png', 1, '3', '', '0000-00-00', '', '2019-08-12 15:10:46', 'Anagrams-Animals'),
(1136, 2, 59, 'SequenceMemory-Level3', '', 'Memory', 'uploads/SequenceMemory-Level3_9452287289.png', 1, '4', '', '0000-00-00', '', '2019-08-12 15:10:46', 'SequenceMemory-Level3'),
(1137, 2, 60, 'EyeCells-Level3', '', 'VP', 'uploads/EyeCells-Level3_8897464917.png', 1, '4', '', '0000-00-00', '', '2019-08-12 15:10:46', 'EyeCells-Level3'),
(1138, 2, 61, 'LastLegend-Level3', '', 'FA', 'uploads/LastLegend-Level3_5495434515.png', 1, '4', '', '0000-00-00', '', '2019-08-12 15:10:46', 'LastLegend-Level3'),
(1139, 2, 62, 'AddMaster-Level3', '', 'PS', 'uploads/AddMaster-Level3_2056090440.png', 1, '4', '', '0000-00-00', '', '2019-08-12 15:10:46', 'AddMaster-Level3'),
(1140, 2, 63, 'Anagrams-Body', '', 'LI', 'uploads/Anagrams-Body_8010135167.png', 1, '4', '', '0000-00-00', '', '2019-08-12 15:10:46', 'Anagrams-Body'),
(1141, 2, 59, 'AlphaNumericEncode-Level4', '', 'Memory', 'uploads/AlphaNumericEncode-Level4_2667365404.png', 1, '5', '', '0000-00-00', '', '2019-08-12 15:10:46', 'AlphaNumericEncode-Level4'),
(1142, 2, 60, 'MirrorMatch-Level3', '', 'VP', 'uploads/MirrorMatch-Level3_3233505128.png', 1, '5', '', '0000-00-00', '', '2019-08-12 15:10:46', 'MirrorMatch-Level3'),
(1143, 2, 61, 'CarPark-Level2', '', 'FA', 'uploads/CarPark-Level2_116904969.png', 1, '5', '', '0000-00-00', '', '2019-08-12 15:10:46', 'CarPark-Level2'),
(1144, 2, 62, 'ParaMaster-Level4', '', 'PS', 'uploads/ParaMaster-Level4_3163872654.png', 1, '5', '', '0000-00-00', '', '2019-08-12 15:10:46', 'ParaMaster-Level4'),
(1145, 2, 63, 'HomoPhones-Level1', '', 'LI', 'uploads/HomoPhones-Level1_1627698740.png', 1, '5', '', '0000-00-00', '', '2019-08-12 15:10:46', 'HomoPhones-Level1'),
(1146, 2, 59, 'AnimalWatch-Level2', '', 'Memory', 'uploads/AnimalWatch-Level2_2552103889.png', 1, '6', '', '0000-00-00', '', '2019-08-12 15:10:46', 'AnimalWatch-Level2'),
(1147, 2, 60, 'IAmCube-Level2', '', 'VP', 'uploads/IAmCube-Level2_7666559526.png', 1, '6', '', '0000-00-00', '', '2019-08-12 15:10:46', 'IAmCube-Level2'),
(1148, 2, 61, 'CarPark-Level4', '', 'FA', 'uploads/CarPark-Level4_5836739456.png', 1, '6', '', '0000-00-00', '', '2019-08-12 15:10:46', 'CarPark-Level4'),
(1149, 2, 62, 'NumbersOnTheWheel-Level5', '', 'PS', 'uploads/NumbersOnTheWheel-Level5_1027476550.png', 1, '6', '', '0000-00-00', '', '2019-08-12 15:10:46', 'NumbersOnTheWheel-Level5'),
(1150, 2, 63, 'Anagrams-Sports', '', 'LI', 'uploads/Anagrams-Sports_9202636964.png', 1, '6', '', '0000-00-00', '', '2019-08-12 15:10:46', 'Anagrams-Sports'),
(1151, 2, 59, 'DropBox-Level1', '', 'Memory', 'uploads/DropBox-Level1_6700938204.png', 1, '7', '', '0000-00-00', '', '2019-08-12 15:10:46', 'DropBox-Level1'),
(1152, 2, 60, 'CubeSherlock-Level2', '', 'VP', 'uploads/CubeSherlock-Level2_2803261997.png', 1, '7', '', '0000-00-00', '', '2019-08-12 15:10:46', 'CubeSherlock-Level2'),
(1153, 2, 61, 'DiscretePaddle-Level2', '', 'FA', 'uploads/DiscretePadle-Level2_4007870662.png', 1, '7', '', '0000-00-00', '', '2019-08-12 15:10:46', 'DiscretePaddle-Level2'),
(1154, 2, 62, 'NittyGritty', '', 'PS', 'uploads/NittyGritty_5187215218.png', 1, '7', '', '0000-00-00', '', '2019-08-12 15:10:46', 'NittyGritty'),
(1155, 2, 63, 'ConfusionGalore-Level1', '', 'LI', 'uploads/ConfusionGalore-Level1_4439043053.png', 1, '7', '', '0000-00-00', '', '2019-08-12 15:10:46', 'ConfusionGalore-Level1'),
(1156, 2, 59, 'SpotMyPlace-Level2', '', 'Memory', 'uploads/SpotMyPlace-Level2_128739713.png', 1, '8', '', '0000-00-00', '', '2019-08-12 15:10:46', 'SpotMyPlace-Level2'),
(1157, 2, 60, 'WaterImage-Level2', '', 'VP', 'uploads/WaterImage-Level2_3779711904.png', 1, '8', '', '0000-00-00', '', '2019-08-12 15:10:46', 'WaterImage-Level2'),
(1158, 2, 61, 'DiscretePaddle-Level3', '', 'FA', 'uploads/DiscretePadle-Level3_3544559371.png', 1, '8', '', '0000-00-00', '', '2019-08-12 15:10:46', 'DiscretePaddle-Level3'),
(1159, 2, 62, 'AnalogyAction-Level3', '', 'PS', 'uploads/AnalogyAction-Level3_1947425035.png', 1, '8', '', '0000-00-00', '', '2019-08-12 15:10:46', 'AnalogyAction-Level3'),
(1160, 2, 63, 'KangarooWords', '', 'LI', 'uploads/KangarooWords_1111639351.png', 1, '8', '', '0000-00-00', '', '2019-08-12 15:10:46', 'KangarooWords'),
(1161, 2, 59, 'MomAndMe', '', 'Memory', 'uploads/MomAndMe_6942562656.png', 1, '1', '', '0000-00-00', '', '2019-08-12 15:10:46', 'MomAndMe'),
(1162, 2, 60, 'EdCells-Level1', '', 'VP', 'uploads/EdCells-Level1_376414950.png', 1, '1', '', '0000-00-00', '', '2019-08-12 15:10:46', 'EdCells-Level1'),
(1163, 2, 61, 'StrangerGrid-Level3', '', 'FA', 'uploads/StrangerGrid_9728514011.png', 1, '1', '', '0000-00-00', '', '2019-08-12 15:10:46', 'StrangerGrid-Level3'),
(1164, 2, 62, 'ClockArithmetic', '', 'PS', 'uploads/ClockArithmetic_6831587473.png', 1, '1', '', '0000-00-00', '', '2019-08-12 15:10:46', 'ClockArithmetic'),
(1165, 2, 63, 'WhoAmI-Vegetables', '', 'LI', 'uploads/WhoAmI-Vegetables_7871570191.png', 1, '1', '', '0000-00-00', '', '2019-08-12 15:10:46', 'WhoAmI-Vegetables'),
(1166, 2, 59, 'MindCapture-Level2', '', 'Memory', 'uploads/MindCapture-Level2_5165879982.png', 1, '2', '', '0000-00-00', '', '2019-08-12 15:10:46', 'MindCapture-Level2'),
(1167, 2, 60, 'WordWipe-Level2', '', 'VP', 'uploads/WordWipe-Level2_4875887525.png', 1, '2', '', '0000-00-00', '', '2019-08-12 15:10:46', 'WordWipe-Level2'),
(1168, 2, 61, 'SpotMe-Level2', '', 'FA', 'uploads/SpotMe-Level2_5270674000.png', 1, '2', '', '0000-00-00', '', '2019-08-12 15:10:46', 'SpotMe-Level2'),
(1169, 2, 62, 'WordShapes-Level2', '', 'PS', 'uploads/WordShapes-Level2_2368690557.png', 1, '2', '', '0000-00-00', '', '2019-08-12 15:10:46', 'WordShapes-Level2'),
(1170, 2, 63, 'WhoAmI-WildAnimals', '', 'LI', 'uploads/WhoAmI-WildAnimals_8843113635.png', 1, '2', '', '0000-00-00', '', '2019-08-12 15:10:46', 'WhoAmI-WildAnimals'),
(1171, 2, 59, 'MemoryCheck-Level3', '', 'Memory', 'uploads/MemoryCheck-Level3_7822075057.png', 1, '3', '', '0000-00-00', '', '2019-08-12 15:10:46', 'MemoryCheck-Level3'),
(1172, 2, 60, 'MatchMe-Level3', '', 'VP', 'uploads/MatchMe-Level3_3926392993.png', 1, '3', '', '0000-00-00', '', '2019-08-12 15:10:46', 'MatchMe-Level3'),
(1173, 2, 61, 'DeepUnder-Level1', '', 'FA', 'uploads/DeepUnder-Level1_7213067221.png', 1, '3', '', '0000-00-00', '', '2019-08-12 15:10:46', 'DeepUnder-Level1'),
(1174, 2, 62, 'HeavyOrLight-Level2', '', 'PS', 'uploads/HeavyOrLight-Level2_607259180.png', 1, '3', '', '0000-00-00', '', '2019-08-12 15:10:46', 'HeavyOrLight-Level2'),
(1175, 2, 63, 'ArrangeTheWords-Level1', '', 'LI', 'uploads/ArrangeTheWords-Level1_350359375.png', 1, '3', '', '0000-00-00', '', '2019-08-12 15:10:46', 'ArrangeTheWords-Level1'),
(1176, 2, 59, 'AlphaNumericEncode-Level3', '', 'Memory', 'uploads/AlphaNumericEncode-Level3_387589167.png', 1, '4', '', '0000-00-00', '', '2019-08-12 15:10:46', 'AlphaNumericEncode-Level3'),
(1177, 2, 60, 'ReflectionRead-Level2', '', 'VP', 'uploads/ReflectionRead-Level2_2878144294.png', 1, '4', '', '0000-00-00', '', '2019-08-12 15:10:46', 'ReflectionRead-Level2'),
(1178, 2, 61, 'LetterJigsaw-Level3', '', 'FA', 'uploads/AlphabetJigsaw-Level3_1882078954.png', 1, '4', '', '0000-00-00', '', '2019-08-12 15:10:46', 'LetterJigsaw-Level3'),
(1179, 2, 62, 'ATeddyForATeddy-Level1', '', 'PS', 'uploads/ATeddyForATeddy-Level1_5987485046.png', 1, '4', '', '0000-00-00', '', '2019-08-12 15:10:46', 'ATeddyForATeddy-Level1'),
(1180, 2, 63, 'Anagrams-Plants', '', 'LI', 'uploads/Anagrams-Plants_2974008941.png', 1, '4', '', '0000-00-00', '', '2019-08-12 15:10:46', 'Anagrams-Plants'),
(1181, 2, 59, 'SequenceMemory-Level4', '', 'Memory', 'uploads/SequenceMemory-Level4_9387351195.png', 1, '5', '', '0000-00-00', '', '2019-08-12 15:10:46', 'SequenceMemory-Level4'),
(1182, 2, 60, 'MissingPiece-Level2', '', 'VP', 'uploads/MissingPiece-Level2_9361892873.png', 1, '5', '', '0000-00-00', '', '2019-08-12 15:10:46', 'MissingPiece-Level2'),
(1183, 2, 61, 'CarPark-Level3', '', 'FA', 'uploads/CarPark-Level3_5003174929.png', 1, '5', '', '0000-00-00', '', '2019-08-12 15:10:46', 'CarPark-Level3'),
(1184, 2, 62, 'Reshuffle-Level4', '', 'PS', 'uploads/Reshuffle-Level4_4280022010.png', 1, '5', '', '0000-00-00', '', '2019-08-12 15:10:46', 'Reshuffle-Level4'),
(1185, 2, 63, 'MissingLetter-Level4', '', 'LI', 'uploads/MissingLetter-Level4_7994128023.png', 1, '5', '', '0000-00-00', '', '2019-08-12 15:10:46', 'MissingLetter-Level4'),
(1186, 2, 59, 'CycleRace-Level5', '', 'Memory', 'uploads/CycleRace-Level5_1506978459.png', 1, '6', '', '0000-00-00', '', '2019-08-12 15:10:46', 'CycleRace-Level5'),
(1187, 2, 60, 'MirrorMatch-Level4', '', 'VP', 'uploads/MirrorMatch-Level4_9751465697.png', 1, '6', '', '0000-00-00', '', '2019-08-12 15:10:46', 'MirrorMatch-Level4'),
(1188, 2, 61, 'ShapeRollers-Level2', '', 'FA', 'uploads/ShapeRollers-Level2_5863707675.png', 1, '6', '', '0000-00-00', '', '2019-08-12 15:10:46', 'ShapeRollers-Level2'),
(1189, 2, 62, 'SequenceGrid', '', 'PS', 'uploads/SequenceGrid_9023916260.png', 1, '6', '', '0000-00-00', '', '2019-08-12 15:10:46', 'SequenceGrid'),
(1190, 2, 63, 'Anagrams-Weather', '', 'LI', 'uploads/Anagrams-Weather_3403326552.png', 1, '6', '', '0000-00-00', '', '2019-08-12 15:10:46', 'Anagrams-Weather'),
(1191, 2, 59, 'SequenceMemory-Level7', '', 'Memory', 'uploads/SequenceMemory-Level7_6659360751.png', 1, '7', '', '0000-00-00', '', '2019-08-12 15:10:46', 'SequenceMemory-Level7'),
(1192, 2, 60, 'FindTheTwins-Level3', '', 'VP', 'uploads/FindTheTwins-Level3_8413515225.png', 1, '7', '', '0000-00-00', '', '2019-08-12 15:10:46', 'FindTheTwins-Level3'),
(1193, 2, 61, 'ShapeVsColorVsPattern-Level1', '', 'FA', 'uploads/ShapeVsColorVsPattern-Level1_9182052793.png', 1, '7', '', '0000-00-00', '', '2019-08-12 15:10:46', 'ShapeVsColorVsPattern-Level1'),
(1194, 2, 62, 'NumbersOnTheWheel-Level6', '', 'PS', 'uploads/NumbersOnTheWheel-Level6_2458961391.png', 1, '7', '', '0000-00-00', '', '2019-08-12 15:10:46', 'NumbersOnTheWheel-Level6'),
(1195, 2, 63, 'DividedWords-Level1', '', 'LI', 'uploads/DividedWords-Level1_9592156563.png', 1, '7', '', '0000-00-00', '', '2019-08-12 15:10:46', 'DividedWords-Level1'),
(1196, 2, 59, 'BugSpot-Level2', '', 'Memory', 'uploads/BugSpot-Level2_807683826.png', 1, '8', '', '0000-00-00', '', '2019-08-12 15:10:46', 'BugSpot-Level2'),
(1197, 2, 60, 'FlipTrick-Level2', '', 'VP', 'uploads/FlipTrick-Level2_2970519540.png', 1, '8', '', '0000-00-00', '', '2019-08-12 15:10:46', 'FlipTrick-Level2'),
(1198, 2, 61, 'ShapeVsColorVsPattern-Level2', '', 'FA', 'uploads/ShapeVsColorVsPattern-Level2_533262947.png', 1, '8', '', '0000-00-00', '', '2019-08-12 15:10:46', 'ShapeVsColorVsPattern-Level2'),
(1199, 2, 62, 'MasterVenn-Level2', '', 'PS', 'uploads/MasterVenn-Level2_6223853942.png', 1, '8', '', '0000-00-00', '', '2019-08-12 15:10:46', 'MasterVenn-Level2'),
(1200, 2, 63, 'DividedWords-Level2', '', 'LI', 'uploads/DividedWords-Level2_482863192.png', 1, '8', '', '0000-00-00', '', '2019-08-12 15:10:46', 'DividedWords-Level2'),
(1201, 2, 59, 'Fishing', '', 'Memory', 'uploads/Fishing_4694063616.png', 1, '1', '', '0000-00-00', '', '2019-08-12 15:10:46', 'Fishing'),
(1202, 2, 60, 'Face2Face-Level1', '', 'VP', 'uploads/Face2Face-Level1_5178543743.png', 1, '1', '', '0000-00-00', '', '2019-08-12 15:10:46', 'Face2Face-Level1'),
(1203, 2, 61, 'SpotMe-Level1', '', 'FA', 'uploads/SpotMe-Level1_2213080883.png', 1, '1', '', '0000-00-00', '', '2019-08-12 15:10:46', 'SpotMe-Level1'),
(1204, 2, 62, 'NumberDecode', '', 'PS', 'uploads/NumberDecode-Level1_5552706075.png', 1, '1', '', '0000-00-00', '', '2019-08-12 15:10:46', 'NumberDecode'),
(1205, 2, 63, 'WhoAmI-Fruits', '', 'LI', 'uploads/WhoAmI-Fruits_91387722.png', 1, '1', '', '0000-00-00', '', '2019-08-12 15:10:46', 'WhoAmI-Fruits'),
(1206, 2, 59, 'BalloonBurst-A1', '', 'Memory', 'uploads/BalloonBurst-Level2_244336309.png', 1, '2', '', '0000-00-00', '', '2019-08-12 15:10:46', 'BalloonBurst-A1'),
(1207, 2, 60, 'AlphaNumberRead', '', 'VP', 'uploads/AlphaNumberRead_8101214673.png', 1, '2', '', '0000-00-00', '', '2019-08-12 15:10:46', 'AlphaNumberRead'),
(1208, 2, 61, 'WordSpell-Level1', '', 'FA', 'uploads/WordSpell-Level1_4793716236.png', 1, '2', '', '0000-00-00', '', '2019-08-12 15:10:46', 'WordSpell-Level1'),
(1209, 2, 62, 'Reshuffle', '', 'PS', 'uploads/Reshuffle-Level1_9448890620.png', 1, '2', '', '0000-00-00', '', '2019-08-12 15:10:46', 'Reshuffle'),
(1210, 2, 63, 'Anagrams-Food', '', 'LI', 'uploads/Anagrams-Food_9358940329.png', 1, '2', '', '0000-00-00', '', '2019-08-12 15:10:46', 'Anagrams-Food'),
(1211, 2, 59, 'SequenceMemory-Level2', '', 'Memory', 'uploads/SequenceMemory-Level2_9874571016.png', 1, '3', '', '0000-00-00', '', '2019-08-12 15:10:46', 'SequenceMemory-Level2'),
(1212, 2, 60, 'MissingPiece-Level1', '', 'VP', 'uploads/MissingPiece-Level1_5453919009.png', 1, '3', '', '0000-00-00', '', '2019-08-12 15:10:46', 'MissingPiece-Level1'),
(1213, 2, 61, 'NumberJigsaw-Level2', '', 'FA', 'uploads/NumberJigsaw-Level2_5454463027.png', 1, '3', '', '0000-00-00', '', '2019-08-12 15:10:46', 'NumberJigsaw-Level2'),
(1214, 2, 62, 'Reshuffle-Level2', '', 'PS', 'uploads/Reshuffle-Level2_5333331595.png', 1, '3', '', '0000-00-00', '', '2019-08-12 15:10:46', 'Reshuffle-Level2'),
(1215, 2, 63, 'VowelMagic', '', 'LI', 'uploads/VowelMagic_9324571550.png', 1, '3', '', '0000-00-00', '', '2019-08-12 15:10:46', 'VowelMagic'),
(1216, 2, 59, 'WhatsInStore-Level1', '', 'Memory', 'uploads/WhatsInStore-Level1_99412277.png', 1, '4', '', '0000-00-00', '', '2019-08-12 15:10:46', 'WhatsInStore-Level1'),
(1217, 2, 60, 'FormTheSquare-Level2', '', 'VP', 'uploads/FormTheSquare-Level2_925395623.png', 1, '4', '', '0000-00-00', '', '2019-08-12 15:10:46', 'FormTheSquare-Level2'),
(1218, 2, 61, 'DeepUnder-Level2', '', 'FA', 'uploads/DeepUnder-Level2_5933240540.png', 1, '4', '', '0000-00-00', '', '2019-08-12 15:10:46', 'DeepUnder-Level2'),
(1219, 2, 62, 'WordWalls-Level2', '', 'PS', 'uploads/WordWalls-Level2_7409162675.png', 1, '4', '', '0000-00-00', '', '2019-08-12 15:10:46', 'WordWalls-Level2'),
(1220, 2, 63, 'ArrangeTheWords-Level2', '', 'LI', 'uploads/ArrangeTheWords-Level2_2614120254.png', 1, '4', '', '0000-00-00', '', '2019-08-12 15:10:46', 'ArrangeTheWords-Level2'),
(1221, 2, 59, 'BackTrack-Level2', '', 'Memory', 'uploads/BackTrack-Level2_16276659.png', 1, '5', '', '0000-00-00', '', '2019-08-12 15:10:46', 'BackTrack-Level2'),
(1222, 2, 60, 'ReverseReading-Level3', '', 'VP', 'uploads/ReverseReading-Level3_5393561688.png', 1, '5', '', '0000-00-00', '', '2019-08-12 15:10:46', 'ReverseReading-Level3'),
(1223, 2, 61, 'ShapeVsColor', '', 'FA', 'uploads/ShapeVsColor_5882827830.png', 1, '5', '', '0000-00-00', '', '2019-08-12 15:10:46', 'ShapeVsColor'),
(1224, 2, 62, 'NumberSeries-Level1', '', 'PS', 'uploads/NumberSeries-Level1_292791444.png', 1, '5', '', '0000-00-00', '', '2019-08-12 15:10:46', 'NumberSeries-Level1'),
(1225, 2, 63, 'WordStem', '', 'LI', 'uploads/WordStem_1920470679.png', 1, '5', '', '0000-00-00', '', '2019-08-12 15:10:46', 'WordStem'),
(1226, 2, 59, 'MemoryCheck-Level6', '', 'Memory', 'uploads/MemoryCheck-Level6_2935850583.png', 1, '6', '', '0000-00-00', '', '2019-08-12 15:10:46', 'MemoryCheck-Level6'),
(1227, 2, 60, 'MissingPiece-Level3', '', 'VP', 'uploads/MissingPiece-Level3_1563094099.png', 1, '6', '', '0000-00-00', '', '2019-08-12 15:10:46', 'MissingPiece-Level3'),
(1228, 2, 61, 'ShapeRollers-Level3', '', 'FA', 'uploads/ShapeRollers-Level3_6991897872.png', 1, '6', '', '0000-00-00', '', '2019-08-12 15:10:46', 'ShapeRollers-Level3'),
(1229, 2, 62, 'ColorGuess', '', 'PS', 'uploads/ColorGuess_7757099242.png', 1, '6', '', '0000-00-00', '', '2019-08-12 15:10:46', 'ColorGuess'),
(1230, 2, 63, 'ArrangeTheWords-Level5', '', 'LI', 'uploads/ArrangeTheWords-Level5_4423534446.png', 1, '6', '', '0000-00-00', '', '2019-08-12 15:10:46', 'ArrangeTheWords-Level5'),
(1231, 2, 59, 'SpotMyPlace-Level1', '', 'Memory', 'uploads/SpotMyPlace-Level1_8555905618.png', 1, '7', '', '0000-00-00', '', '2019-08-12 15:10:46', 'SpotMyPlace-Level1'),
(1232, 2, 60, 'MissingPiece-Level4', '', 'VP', 'uploads/MissingPiece-Level4_1507440302.png', 1, '7', '', '0000-00-00', '', '2019-08-12 15:10:46', 'MissingPiece-Level4'),
(1233, 2, 61, 'BalloonLight-Level5', '', 'FA', 'uploads/DarkLight-Level5_4619532418.png', 1, '7', '', '0000-00-00', '', '2019-08-12 15:10:46', 'BalloonLight-Level5'),
(1234, 2, 62, 'AnalogyAction-Level2', '', 'PS', 'uploads/AnalogyAction-Level2_5585269308.png', 1, '7', '', '0000-00-00', '', '2019-08-12 15:10:46', 'AnalogyAction-Level2'),
(1235, 2, 63, 'Rebus-Level1', '', 'LI', 'uploads/Rebus-Level1_8831456145.png', 1, '7', '', '0000-00-00', '', '2019-08-12 15:10:46', 'Rebus-Level1'),
(1236, 2, 59, 'DropBox-Level2', '', 'Memory', 'uploads/DropBox-Level2_6796904369.png', 1, '8', '', '0000-00-00', '', '2019-08-12 15:10:46', 'DropBox-Level2'),
(1237, 2, 60, 'ChooseThreeToMakeOne-Level2', '', 'VP', 'uploads/ChooseThreeToMakeOne_6421778858.png', 1, '8', '', '0000-00-00', '', '2019-08-12 15:10:46', 'ChooseThreeToMakeOne-Level2'),
(1238, 2, 61, 'BalloonLight-Level6', '', 'FA', 'uploads/DarkLight-Level6_8921038703.png', 1, '8', '', '0000-00-00', '', '2019-08-12 15:10:46', 'BalloonLight-Level6'),
(1239, 2, 62, 'NumberPuzzle-Level3', '', 'PS', 'uploads/NumberPuzzle-Level3_4147070031.png', 1, '8', '', '0000-00-00', '', '2019-08-12 15:10:46', 'NumberPuzzle-Level3'),
(1240, 2, 63, 'JumbledLetters-Level2', '', 'LI', 'uploads/JumbledLetters-Level2_497916364.png', 1, '8', '', '0000-00-00', '', '2019-08-12 15:10:46', 'JumbledLetters-Level2'),
(1242, 2, 60, 'MatchMe-Level1', '', 'VP', 'uploads/MatchMe-Level1_3344377102.png', 1, '1', '', '0000-00-00', '', '2019-08-12 15:10:46', 'MatchMe-Level1'),
(1245, 2, 63, 'WhoAmI-DomesticAnimals', '', 'LI', 'uploads/WhoAmI-DomesticAnimals_818332880.png', 1, '1', '', '0000-00-00', '', '2019-08-12 15:10:46', 'WhoAmI-DomesticAnimals');
INSERT INTO `games` (`gid`, `gc_id`, `gs_id`, `gname`, `path`, `descs`, `img_path`, `gstatus`, `gplans`, `createdby`, `creation_date`, `modifiedby`, `modified_date`, `game_html`) VALUES
(1246, 2, 59, 'BalloonBurst-A2', '', 'Memory', 'uploads/BalloonBurst-Level2_244336309.png', 1, '2', '', '0000-00-00', '', '2019-08-12 15:10:46', 'BalloonBurst-A2'),
(1247, 2, 60, 'Face2Face-Level2', '', 'VP', 'uploads/Face2Face-Level2_9013552083.png', 1, '2', '', '0000-00-00', '', '2019-08-12 15:10:46', 'Face2Face-Level2'),
(1248, 2, 61, 'LetterJigsaw-Level1', '', 'FA', 'uploads/AlphabetJigsaw-Level1_6780601199.png', 1, '2', '', '0000-00-00', '', '2019-08-12 15:10:46', 'LetterJigsaw-Level1'),
(1249, 2, 62, 'NumbersOnTheWheel-A1', '', 'PS', 'uploads/NumbersOnTheWheel-Level1_5239142207.png', 1, '2', '', '0000-00-00', '', '2019-08-12 15:10:46', 'NumbersOnTheWheel-A1'),
(1250, 2, 63, 'WhoAmI-Flowers', '', 'LI', 'uploads/WhoAmI-Flowers_4361387616.png', 1, '2', '', '0000-00-00', '', '2019-08-12 15:10:46', 'WhoAmI-Flowers'),
(1251, 2, 59, 'MindCapture-Level4', '', 'Memory', 'uploads/MindCapture-Level4_95845567.png', 1, '3', '', '0000-00-00', '', '2019-08-12 15:10:46', 'MindCapture-Level4'),
(1252, 2, 60, 'AnimalWipe', '', 'VP', 'uploads/AnimalWipe_6567529789.png', 1, '3', '', '0000-00-00', '', '2019-08-12 15:10:46', 'AnimalWipe'),
(1253, 2, 61, 'CarPark-Level1', '', 'FA', 'uploads/CarPark-Level1_8054239703.png', 1, '3', '', '0000-00-00', '', '2019-08-12 15:10:46', 'CarPark-Level1'),
(1254, 2, 62, 'WordShapes-Level3', '', 'PS', 'uploads/WordShapes-Level3_9543727268.png', 1, '3', '', '0000-00-00', '', '2019-08-12 15:10:46', 'WordShapes-Level3'),
(1255, 2, 63, 'WhoAmI-Birthday', '', 'LI', 'uploads/WhoAmI-Birthday_9790617101.png', 1, '3', '', '0000-00-00', '', '2019-08-12 15:10:46', 'WhoAmI-Birthday'),
(1256, 2, 59, 'WhatsInStore-Level2', '', 'Memory', 'uploads/WhatsInStore-Level2_3776093176.png', 1, '4', '', '0000-00-00', '', '2019-08-12 15:10:46', 'WhatsInStore-Level2'),
(1257, 2, 60, 'FindTheTwins-Level1', '', 'VP', 'uploads/FindTheTwins-Level1_7979904958.png', 1, '4', '', '0000-00-00', '', '2019-08-12 15:10:46', 'FindTheTwins-Level1'),
(1258, 2, 61, 'BallShooter-Level2', '', 'FA', 'uploads/Ball_Shooter.png', 1, '4', '', '0000-00-00', '', '2019-08-12 15:10:46', 'BallShooter-Level2'),
(1259, 2, 62, 'FitMeRight-Level1', '', 'PS', 'uploads/FitMeRight-Level1_9128276687.png', 1, '4', '', '0000-00-00', '', '2019-08-12 15:10:46', 'FitMeRight-Level1'),
(1260, 2, 63, 'Anagrams-Colors', '', 'LI', 'uploads/Anagrams-Colors_4401654419.png', 1, '4', '', '0000-00-00', '', '2019-08-12 15:10:46', 'Anagrams-Colors'),
(1261, 2, 59, 'MindCapture-Level6', '', 'Memory', 'uploads/MindCapture-Level6_6117593380.png', 1, '5', '', '0000-00-00', '', '2019-08-12 15:10:46', 'MindCapture-Level6'),
(1262, 2, 60, 'ReflectionRead-Level3', '', 'VP', 'uploads/ReflectionRead-Level3_7118542841.png', 1, '5', '', '0000-00-00', '', '2019-08-12 15:10:46', 'ReflectionRead-Level3'),
(1263, 2, 61, 'DeepUnder-Level3', '', 'FA', 'uploads/DeepUnder-Level3_9918525810.png', 1, '5', '', '0000-00-00', '', '2019-08-12 15:10:46', 'DeepUnder-Level3'),
(1264, 2, 62, 'AnalogyAction-Level1', '', 'PS', 'uploads/AnalogyAction-Level1_6299363239.png', 1, '5', '', '0000-00-00', '', '2019-08-12 15:10:46', 'AnalogyAction-Level1'),
(1265, 2, 63, 'RootWords-Level1', '', 'LI', 'uploads/RootWords-Level1_8710642922.png', 1, '5', '', '0000-00-00', '', '2019-08-12 15:10:46', 'RootWords-Level1'),
(1266, 2, 59, 'WhatsInStore-Level3', '', 'Memory', 'uploads/WhatsInStore-Level3_4075730568.png', 1, '6', '', '0000-00-00', '', '2019-08-12 15:10:46', 'WhatsInStore-Level3'),
(1267, 2, 60, 'ReflectionRead-Level5', '', 'VP', 'uploads/ReflectionRead-Level5_3237627618.png', 1, '6', '', '0000-00-00', '', '2019-08-12 15:10:46', 'ReflectionRead-Level5'),
(1268, 2, 61, 'BalloonLight-Level4', '', 'FA', 'uploads/DarkLight-Level4_4173842570.png', 1, '6', '', '0000-00-00', '', '2019-08-12 15:10:46', 'BalloonLight-Level4'),
(1269, 2, 62, 'MasterVenn-Level1', '', 'PS', 'uploads/MasterVenn-Level1_7031834167.png', 1, '6', '', '0000-00-00', '', '2019-08-12 15:10:46', 'MasterVenn-Level1'),
(1270, 2, 63, 'Anagrams-DolchWords', '', 'LI', 'uploads/Anagrams-DolchWords_4271674626.png', 1, '6', '', '0000-00-00', '', '2019-08-12 15:10:46', 'Anagrams-DolchWords'),
(1271, 2, 59, 'BugSpot-Level1', '', 'Memory', 'uploads/BugSpot-Level1_4068491952.png', 1, '7', '', '0000-00-00', '', '2019-08-12 15:10:46', 'BugSpot-Level1'),
(1272, 2, 60, 'ReflectionRead-Level4', '', 'VP', 'uploads/ReflectionRead-Level4_4669125583.png', 1, '7', '', '0000-00-00', '', '2019-08-12 15:10:46', 'ReflectionRead-Level4'),
(1273, 2, 61, 'OddBall-Level1', '', 'FA', 'uploads/OddBall-Level1_1096781706.png', 1, '7', '', '0000-00-00', '', '2019-08-12 15:10:46', 'OddBall-Level1'),
(1274, 2, 62, 'TakeTurns-Level2', '', 'PS', 'uploads/TakeTurns-Level2_7725315545.png', 1, '7', '', '0000-00-00', '', '2019-08-12 15:10:46', 'TakeTurns-Level2'),
(1275, 2, 63, 'RootWords-Level2', '', 'LI', 'uploads/RootWords-Level2_162112307.png', 1, '7', '', '0000-00-00', '', '2019-08-12 15:10:46', 'RootWords-Level2'),
(1276, 2, 59, 'SequenceMemory-Level8', '', 'Memory', 'uploads/SequenceMemory-Level8_6523781293.png', 1, '8', '', '0000-00-00', '', '2019-08-12 15:10:46', 'SequenceMemory-Level8'),
(1277, 2, 60, 'WhoIsNotThere-Level2', '', 'VP', 'uploads/WhoIsNotThere-Level2_67013050.png', 1, '8', '', '0000-00-00', '', '2019-08-12 15:10:46', 'WhoIsNotThere-Level2'),
(1278, 2, 61, 'OddBall-Level2', '', 'FA', 'uploads/OddBall-Level2_3363969377.png', 1, '8', '', '0000-00-00', '', '2019-08-12 15:10:46', 'OddBall-Level2'),
(1279, 2, 62, 'SmartRider', '', 'PS', 'uploads/SmartRider_1083469698.png', 1, '8', '', '0000-00-00', '', '2019-08-12 15:10:46', 'SmartRider'),
(1280, 2, 63, 'ConfusionGalore-Level2', '', 'LI', 'uploads/ConfusionGalore-Level2_9538272568.png', 1, '8', '', '0000-00-00', '', '2019-08-12 15:10:46', 'ConfusionGalore-Level2'),
(1282, 2, 60, 'CharacterShade-Level1', '', 'VP', 'uploads/CharacterShade-Level1_3409011624.png', 1, '1', '', '0000-00-00', '', '2019-08-12 15:10:46', 'CharacterShade-Level1'),
(1285, 2, 63, 'WhoAmI-Colors', '', 'LI', 'uploads/WhoAmI-Colors_1446446431.png', 1, '1', '', '0000-00-00', '', '2019-08-12 15:10:46', 'WhoAmI-Colors'),
(1286, 2, 59, 'MindCapture-Level3', '', 'Memory', 'uploads/MindCapture-Level3_3766070040.png', 1, '2', '', '0000-00-00', '', '2019-08-12 15:10:46', 'MindCapture-Level3'),
(1287, 2, 60, 'ReflectionRead-Level1', '', 'VP', 'uploads/ReflectionRead-Level1_7608671374.png', 1, '2', '', '0000-00-00', '', '2019-08-12 15:10:46', 'ReflectionRead-Level1'),
(1288, 2, 61, 'SpotMe-Level3', '', 'FA', 'uploads/SpotMe-Level3_4077972709.png', 1, '2', '', '0000-00-00', '', '2019-08-12 15:10:46', 'SpotMe-Level3'),
(1289, 2, 62, 'NumbersOnTheWheel-A2', '', 'PS', 'uploads/NumbersOnTheWheel-Level1_5239142207.png', 1, '2', '', '0000-00-00', '', '2019-08-12 15:10:46', 'NumbersOnTheWheel-A2'),
(1290, 2, 63, 'Anagrams-CountryNames', '', 'LI', 'uploads/Anagrams-CountryNames_9848174657.png', 1, '2', '', '0000-00-00', '', '2019-08-12 15:10:46', 'Anagrams-CountryNames'),
(1291, 2, 59, 'MindCapture-Level5', '', 'Memory', 'uploads/MindCapture-Level5_2807246898.png', 1, '3', '', '0000-00-00', '', '2019-08-12 15:10:46', 'MindCapture-Level5'),
(1292, 2, 60, 'ReverseReading-Level1', '', 'VP', 'uploads/ReverseReading-Level1_3469542353.png', 1, '3', '', '0000-00-00', '', '2019-08-12 15:10:46', 'ReverseReading-Level1'),
(1293, 2, 61, 'BalloonLight-Level1', '', 'FA', 'uploads/DarkLight-Level1_1779258348.png', 1, '3', '', '0000-00-00', '', '2019-08-12 15:10:46', 'BalloonLight-Level1'),
(1294, 2, 62, 'WordWalls-Level1', '', 'PS', 'uploads/WordWalls-Level1_1536627309.png', 1, '3', '', '0000-00-00', '', '2019-08-12 15:10:46', 'WordWalls-Level1'),
(1296, 2, 59, 'BackTrack-Level1', '', 'Memory', 'uploads/BackTrack-Level1_257858377.png', 1, '4', '', '0000-00-00', '', '2019-08-12 15:10:46', 'BackTrack-Level1'),
(1297, 2, 60, 'FormTheSquare-Level1', '', 'VP', 'uploads/FormTheSquare-Level1_9003437426.png', 1, '4', '', '0000-00-00', '', '2019-08-12 15:10:46', 'FormTheSquare-Level1'),
(1298, 2, 61, 'SpotMe-Level4', '', 'FA', 'uploads/SpotMe-Level4_1111856144.png', 1, '4', '', '0000-00-00', '', '2019-08-12 15:10:46', 'SpotMe-Level4'),
(1299, 2, 62, 'WordShapes-Level4', '', 'PS', 'uploads/WordShapes-Level4_9880864322.png', 1, '4', '', '0000-00-00', '', '2019-08-12 15:10:46', 'WordShapes-Level4'),
(1300, 2, 63, 'MissingLetter-Level1', '', 'LI', 'uploads/MissingLetter-Level1_4396478235.png', 1, '4', '', '0000-00-00', '', '2019-08-12 15:10:46', 'MissingLetter-Level1'),
(1301, 2, 59, 'RouteMemory-Level1', '', 'Memory', 'uploads/RouteMemory-Level1_3141601332.png', 1, '5', '', '0000-00-00', '', '2019-08-12 15:10:46', 'RouteMemory-Level1'),
(1302, 2, 60, 'ReverseReading-Level2', '', 'VP', 'uploads/ReverseReading-Level2_7025720854.png', 1, '5', '', '0000-00-00', '', '2019-08-12 15:10:46', 'ReverseReading-Level2'),
(1303, 2, 61, 'ShapeRollers-Level1', '', 'FA', 'uploads/ShapeRollers-Level1_1497070817.png', 1, '5', '', '0000-00-00', '', '2019-08-12 15:10:46', 'ShapeRollers-Level1'),
(1305, 2, 63, 'ArrangeTheWords-Level4', '', 'LI', 'uploads/ArrangeTheWords-Level4_1263861129.png', 1, '5', '', '0000-00-00', '', '2019-08-12 15:10:46', 'ArrangeTheWords-Level4'),
(1306, 2, 59, 'BackTrack-Level3', '', 'Memory', 'uploads/BackTrack-Level3_4500490999.png', 1, '6', '', '0000-00-00', '', '2019-08-12 15:10:46', 'BackTrack-Level3'),
(1307, 2, 60, 'ReverseReading-Level4', '', 'VP', 'uploads/ReverseReading-Level4_3547282922.png', 1, '6', '', '0000-00-00', '', '2019-08-12 15:10:46', 'ReverseReading-Level4'),
(1308, 2, 61, 'DiscretePaddle-Level1', '', 'FA', 'uploads/DiscretePadle-Level1_2005080394.png', 1, '6', '', '0000-00-00', '', '2019-08-12 15:10:46', 'DiscretePaddle-Level1'),
(1309, 2, 62, 'TakeTurns-Level1', '', 'PS', 'uploads/TakeTurns-Level1_1136886626.png', 1, '6', '', '0000-00-00', '', '2019-08-12 15:10:46', 'TakeTurns-Level1'),
(1310, 2, 63, 'MissingLetter-Level3', '', 'LI', 'uploads/MissingLetter-Level3_7274801447.png', 1, '6', '', '0000-00-00', '', '2019-08-12 15:10:46', 'MissingLetter-Level3'),
(1311, 2, 59, 'RouteMemory-Level2', '', 'Memory', 'uploads/RouteMemory-Level2_3784374403.png', 1, '7', '', '0000-00-00', '', '2019-08-12 15:10:46', 'RouteMemory-Level2'),
(1312, 2, 60, 'WaterImage-Level1', '', 'VP', 'uploads/WaterImage-Level1_4578736186.png', 1, '7', '', '0000-00-00', '', '2019-08-12 15:10:46', 'WaterImage-Level1'),
(1313, 2, 61, 'LightRays-Level1', '', 'FA', 'uploads/LightRays1.png', 1, '7', '', '0000-00-00', '', '2019-08-12 15:10:46', 'LightRays-Level1'),
(1314, 2, 62, 'NumberPuzzle-Level2', '', 'PS', 'uploads/NumberPuzzle-Level2_6727183759.png', 1, '7', '', '0000-00-00', '', '2019-08-12 15:10:46', 'NumberPuzzle-Level2'),
(1315, 2, 63, 'HomoPhones-Level2', '', 'LI', 'uploads/HomoPhones-Level2_3726777150.png', 1, '7', '', '0000-00-00', '', '2019-08-12 15:10:46', 'HomoPhones-Level2'),
(1316, 2, 59, 'BallAndBox-Level2', '', 'Memory', 'uploads/BallAndBox-Level2_5648189471.png', 1, '8', '', '0000-00-00', '', '2019-08-12 15:10:46', 'BallAndBox-Level2'),
(1318, 2, 61, 'SpotMe-Level7', '', 'FA', 'uploads/SpotMe-Level7_2691923594.png', 1, '8', '', '0000-00-00', '', '2019-08-12 15:10:46', 'SpotMe-Level7'),
(1319, 2, 62, 'LogicalSequence', '', 'PS', 'uploads/LogicalSequence_3583530234.png', 1, '8', '', '0000-00-00', '', '2019-08-12 15:10:46', 'LogicalSequence'),
(1320, 2, 63, 'PrefixRootAndSuffix', '', 'LI', 'uploads/PrefixRootAndSuffix_204385071.png', 1, '8', '', '0000-00-00', '', '2019-08-12 15:10:46', 'PrefixRootAndSuffix'),
(1336, 1, 59, 'ClockGrid-Level1', 'uploads/RememberMyName-Level1.swf', 'Memory', 'uploads/ClockGrid-Level1.png', 1, '', '', '2017-05-15', '', '2019-08-12 15:10:46', 'ClockGrid-Level1'),
(1337, 1, 60, 'FormTheFace-Level1', 'uploads/FormTheShape-Level1.swf', 'VP', 'uploads/FormtheFace-Level1.png', 1, '', '', '2017-05-15', '', '2019-08-12 15:10:46', 'FormTheFace-Level1'),
(1338, 1, 62, 'TeamUp-Level1', 'uploads/VennDiagram-Level1.swf', 'PS', 'uploads/TeamUp-Level1.png', 1, '', '', '2017-05-15', '', '2019-08-12 15:10:46', 'TeamUp-Level1'),
(1339, 1, 63, 'Anagrams-Level1', 'uploads/BegintoEnd-Level1.swf', 'L', 'uploads/Anagrams-Level1.png', 1, '', '', '2017-05-15', '', '2019-08-12 15:10:46', 'Anagrams-Level1'),
(1340, 1, 59, 'OutOfFocus-Level1', 'uploads/OutofFocus-Level1.swf', 'Memory', 'uploads/OutofFocus-Level1.png', 1, '', '', '2017-05-15', '', '2019-08-12 15:10:46', 'OutOfFocus-Level1'),
(1341, 1, 60, 'PhotoShop-Level1', 'uploads/Photoshop-Level1.swf', 'VP', 'uploads/Photoshop-Level1.png', 1, '', '', '2017-05-15', '', '2019-08-12 15:10:46', 'PhotoShop-Level1'),
(1342, 1, 61, 'JackInTheBox-Level1', 'uploads/Jackinthebox-Level1.swf', 'FA', 'uploads/Jackinthebox-Level1.png', 1, '', '', '2017-05-15', '', '2019-08-12 15:10:46', 'JackInTheBox-Level1'),
(1343, 1, 62, 'UnLockTheSuitcase-Level1', 'uploads/UnlocktheSuitcase-Level1.swf', 'PS', 'uploads/UnlocktheSuitcase-Level1.png', 1, '', '', '2017-05-15', '', '2019-08-12 15:10:46', 'UnLockTheSuitcase-Level1'),
(1344, 1, 63, 'Capitonyms-Level1', 'uploads/Capitonyms-Level1.swf', 'L', 'uploads/Capitonyms-Level1.png', 1, '', '', '2017-05-15', '', '2019-08-12 15:10:46', 'Capitonyms-Level1');

-- --------------------------------------------------------

--
-- Table structure for table `gamescore`
--

CREATE TABLE `gamescore` (
  `id` int(11) NOT NULL,
  `gu_id` int(10) NOT NULL,
  `gs_id` int(10) NOT NULL,
  `g_id` int(30) NOT NULL,
  `que_id` int(11) NOT NULL,
  `answer` varchar(20) NOT NULL,
  `useranswer` varchar(55) NOT NULL,
  `game_score` varchar(50) NOT NULL,
  `answer_status` varchar(55) NOT NULL,
  `timeoverstatus` int(11) NOT NULL,
  `responsetime` int(11) NOT NULL,
  `balancetime` int(11) NOT NULL,
  `lastupdate` date NOT NULL,
  `creation_date` date NOT NULL,
  `modified_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `puzzle_cycle` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `game_language_track`
--

CREATE TABLE `game_language_track` (
  `ID` int(11) NOT NULL,
  `gameID` int(11) NOT NULL,
  `userID` int(11) NOT NULL,
  `languageID` int(11) NOT NULL,
  `skillkit` int(11) NOT NULL,
  `createddatetime` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `game_levels`
--

CREATE TABLE `game_levels` (
  `id` int(11) NOT NULL,
  `level` varchar(30) NOT NULL,
  `status` int(1) NOT NULL,
  `createdby` varchar(100) NOT NULL,
  `creation_date` date NOT NULL,
  `modifiedby` varchar(100) NOT NULL,
  `modified_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `game_limit`
--

CREATE TABLE `game_limit` (
  `id` int(11) NOT NULL,
  `gc_id` int(11) NOT NULL,
  `gs_id` int(11) NOT NULL,
  `g_id` int(11) NOT NULL,
  `gp_id` int(11) NOT NULL,
  `ntimes` int(11) NOT NULL,
  `createdby` varchar(100) NOT NULL,
  `creation_date` date NOT NULL,
  `modifiedby` varchar(100) NOT NULL,
  `modified_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Stand-in structure for view `game_reports`
-- (See below for the actual view)
--
CREATE TABLE `game_reports` (
`id` int(11)
,`gu_id` int(10)
,`gp_id` varchar(100)
,`gc_id` int(10)
,`gs_id` int(10)
,`g_id` int(30)
,`total_question` varchar(15)
,`attempt_question` varchar(20)
,`answer` varchar(20)
,`game_score` varchar(50)
,`gtime` varchar(100)
,`rtime` varchar(100)
,`crtime` varchar(100)
,`wrtime` varchar(100)
,`lastupdate` date
,`Is_schedule` int(11)
,`session_id` int(11)
,`puzzle_cycle` int(11)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `game_reports_detailed`
-- (See below for the actual view)
--
CREATE TABLE `game_reports_detailed` (
`userid` int(100)
,`grade_id` int(10)
,`section` varchar(10)
,`sid` varchar(100)
,`user_status` int(1)
,`user_visible` int(1)
,`id` int(11)
,`gu_id` int(10)
,`gp_id` varchar(100)
,`gc_id` int(10)
,`gs_id` int(10)
,`g_id` int(30)
,`total_question` varchar(15)
,`attempt_question` varchar(20)
,`answer` varchar(20)
,`game_score` varchar(50)
,`gtime` varchar(100)
,`rtime` varchar(100)
,`crtime` varchar(100)
,`wrtime` varchar(100)
,`lastupdate` date
,`Is_schedule` int(11)
);

-- --------------------------------------------------------

--
-- Table structure for table `g_category`
--

CREATE TABLE `g_category` (
  `id` int(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `description` varchar(100) NOT NULL,
  `status` int(1) NOT NULL,
  `createdby` varchar(100) NOT NULL,
  `creation_date` date NOT NULL,
  `modifiedby` varchar(100) NOT NULL,
  `modified_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `g_category`
--

INSERT INTO `g_category` (`id`, `name`, `description`, `status`, `createdby`, `creation_date`, `modifiedby`, `modified_date`) VALUES
(1, 'Brain Skills', 'Cognitive Development', 1, '', '0000-00-00', '', '2014-06-03 03:57:11'),
(2, 'Brain Skills', 'Cognitive Development', 1, '', '0000-00-00', '', '2014-06-03 03:57:11'),
(5, 'Curriculum', 'Academic Subjects', 1, '', '0000-00-00', '', '2014-06-03 03:57:33'),
(6, 'Life Skills', 'Life Skill Development', 1, '', '0000-00-00', '', '2014-06-02 08:03:42');

-- --------------------------------------------------------

--
-- Table structure for table `g_plans`
--

CREATE TABLE `g_plans` (
  `id` int(100) NOT NULL,
  `grade_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `validity` int(100) NOT NULL,
  `pricewaos` int(100) NOT NULL,
  `pricewoaos` int(100) NOT NULL,
  `ngames` int(100) NOT NULL,
  `bprof` int(1) NOT NULL,
  `gwpt` int(1) NOT NULL,
  `lspc` int(1) NOT NULL,
  `mpc` int(1) NOT NULL,
  `eepc` int(1) NOT NULL,
  `cspt` int(1) NOT NULL,
  `obspi` int(1) NOT NULL,
  `ioapt` int(1) NOT NULL,
  `oacr` int(1) NOT NULL,
  `oagcr` int(1) NOT NULL,
  `oascr` int(1) NOT NULL,
  `status` int(1) NOT NULL,
  `createdby` varchar(100) NOT NULL,
  `creation_date` date NOT NULL,
  `modifiedby` varchar(100) NOT NULL,
  `modified_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `g_plans`
--

INSERT INTO `g_plans` (`id`, `grade_id`, `name`, `validity`, `pricewaos`, `pricewoaos`, `ngames`, `bprof`, `gwpt`, `lspc`, `mpc`, `eepc`, `cspt`, `obspi`, `ioapt`, `oacr`, `oagcr`, `oascr`, `status`, `createdby`, `creation_date`, `modifiedby`, `modified_date`) VALUES
(1, 3, 'PerformancePowerPack-I', 365, 1550, 1250, 40, 1, 1, 1, 1, 0, 1, 1, 0, 0, 0, 0, 1, '', '0000-00-00', '', '2014-06-17 05:48:03'),
(2, 4, 'PerformancePowerPack-II', 365, 1550, 1250, 40, 1, 1, 1, 1, 0, 1, 1, 0, 0, 0, 0, 1, '', '0000-00-00', '', '2014-06-17 05:48:41'),
(3, 5, 'PerformancePowerPack-III', 365, 1550, 1250, 40, 1, 1, 1, 1, 0, 1, 1, 0, 0, 0, 0, 1, '', '0000-00-00', '', '2014-06-17 05:50:37'),
(4, 6, 'PerformancePowerPack-IV', 365, 1550, 1250, 40, 1, 1, 1, 1, 0, 1, 1, 0, 0, 0, 0, 1, '', '0000-00-00', '', '2014-06-17 05:51:16'),
(5, 7, 'PerformancePowerPack-V', 365, 1550, 1250, 40, 1, 1, 1, 1, 0, 1, 1, 0, 0, 0, 0, 1, '', '0000-00-00', '', '2014-06-17 05:51:45'),
(6, 8, 'PerformancePowerPack-VI', 365, 1550, 1250, 40, 1, 1, 1, 1, 0, 1, 1, 0, 0, 0, 0, 1, '', '0000-00-00', '', '2014-06-17 05:52:15'),
(7, 9, 'PerformancePowerPack-VII', 365, 1550, 1250, 40, 1, 1, 1, 1, 0, 1, 1, 0, 0, 0, 0, 1, '', '0000-00-00', '', '2014-06-17 05:52:50'),
(8, 10, 'PerformancePowerPack-VIII', 365, 1550, 1250, 40, 1, 1, 1, 1, 0, 1, 1, 0, 0, 0, 0, 1, '', '0000-00-00', '', '2014-06-17 05:53:58'),
(10, 1, 'PerformancePowerPack-LKG', 365, 1550, 1250, 40, 1, 1, 1, 1, 0, 1, 1, 0, 0, 0, 0, 1, '', '0000-00-00', '', '2014-06-26 03:17:10'),
(11, 2, 'PerformancePowerPack-UKG', 365, 1550, 1250, 40, 1, 1, 1, 1, 0, 1, 1, 0, 0, 0, 0, 1, '', '0000-00-00', '', '2014-06-26 03:17:54'),
(92, 12, 'PerformancePowerPack-IX', 365, 1550, 1250, 40, 1, 1, 1, 1, 0, 1, 1, 0, 0, 0, 0, 1, '', '0000-00-00', '', '2017-02-09 05:06:28'),
(93, 13, 'PerformancePowerPack-X', 365, 1550, 1250, 40, 1, 1, 1, 1, 0, 1, 1, 0, 0, 0, 0, 1, '', '0000-00-00', '', '2017-02-09 05:06:28'),
(94, 14, 'PerformancePowerPack-XI', 365, 1550, 1250, 40, 1, 1, 1, 1, 0, 1, 1, 0, 0, 0, 0, 1, '', '0000-00-00', '', '2017-02-09 05:06:28'),
(95, 15, 'PerformancePowerPack-XII', 365, 1550, 1250, 40, 1, 1, 1, 1, 0, 1, 1, 0, 0, 0, 0, 1, '', '0000-00-00', '', '2017-02-09 05:06:28');

-- --------------------------------------------------------

--
-- Table structure for table `g_skills`
--

CREATE TABLE `g_skills` (
  `id` int(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `gc_id` int(100) NOT NULL,
  `img_path` text NOT NULL,
  `code` varchar(100) NOT NULL,
  `timages` varchar(100) NOT NULL,
  `status` int(1) NOT NULL,
  `createdby` varchar(100) NOT NULL,
  `creation_date` date NOT NULL,
  `modifiedby` varchar(100) NOT NULL,
  `modified_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `isuser_log`
--

CREATE TABLE `isuser_log` (
  `ID` int(11) NOT NULL,
  `User_id` int(11) NOT NULL,
  `Login_type` int(11) NOT NULL COMMENT '1=> FTL, 2=>NSTL',
  `Confirmation_type` int(11) NOT NULL COMMENT '1=> Yes, 0 => NO',
  `Logged_datetime` datetime NOT NULL,
  `Org_userid` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `language_master`
--

CREATE TABLE `language_master` (
  `ID` int(11) NOT NULL,
  `name` varchar(400) NOT NULL,
  `status` enum('Y','N') NOT NULL,
  `language_key` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `language_master`
--

INSERT INTO `language_master` (`ID`, `name`, `status`, `language_key`) VALUES
(1, 'English', 'Y', 'english'),
(2, 'Tamil', 'Y', 'tamil'),
(3, 'Kannada', 'Y', 'kannada');

-- --------------------------------------------------------

--
-- Table structure for table `leaderboard`
--

CREATE TABLE `leaderboard` (
  `id` int(11) NOT NULL,
  `sid` int(11) NOT NULL,
  `gradeid` int(11) NOT NULL,
  `year` varchar(55) NOT NULL,
  `monthname` varchar(55) NOT NULL,
  `monthnumber` varchar(55) NOT NULL,
  `userid` text NOT NULL,
  `value` varchar(55) NOT NULL,
  `type` enum('CB','SAB','SBB','SGB') NOT NULL COMMENT 'CB => Crowney Badge,SAB => Super Angel Badge,SBB=> Super Brain Badge,SGB => Super Goer Badge',
  `Created_on` datetime NOT NULL,
  `academic_id` int(11) NOT NULL DEFAULT '20'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `lgames`
--

CREATE TABLE `lgames` (
  `id` int(100) NOT NULL,
  `gname` varchar(100) NOT NULL,
  `img_path` varchar(100) NOT NULL,
  `gpath` varchar(100) NOT NULL,
  `des` varchar(200) NOT NULL,
  `status` int(1) NOT NULL,
  `createdby` varchar(100) NOT NULL,
  `creation_date` date NOT NULL,
  `modifiedby` varchar(100) NOT NULL,
  `modified_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `mathrand_selection`
--

CREATE TABLE `mathrand_selection` (
  `id` int(11) NOT NULL,
  `mid` int(11) DEFAULT NULL,
  `grade_id` int(11) DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  `created_date` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `mathrand_selection`
--

INSERT INTO `mathrand_selection` (`id`, `mid`, `grade_id`, `user_id`, `created_date`) VALUES
(12, 61, 9, 38334, '2018-11-19 09:47:08'),
(24, 62, 9, 38334, '2018-12-03 02:24:42'),
(26, 63, 9, 38334, '2018-12-04 01:29:27'),
(28, 64, 9, 38334, '2018-12-06 04:01:37'),
(30, 1, 3, 48176, '2018-12-13 10:15:42'),
(31, 71, 10, 48281, '2018-12-13 10:17:01'),
(32, 1, 3, 48177, '2018-12-13 11:49:25'),
(33, 61, 9, 48266, '2018-12-13 12:00:26'),
(34, 31, 6, 48221, '2018-12-14 02:09:11'),
(35, 2, 3, 48176, '2018-12-14 05:58:24'),
(38, 3, 3, 48176, '2018-12-18 11:09:38'),
(39, 11, 4, 48191, '2018-12-18 01:39:36'),
(42, 41, 7, 38331, '2019-01-07 03:46:49'),
(43, 42, 7, 38331, '2019-01-08 12:17:44'),
(45, 41, 7, 806, '2019-01-09 10:51:39'),
(46, 41, 7, 807, '2019-01-09 10:54:09'),
(47, 11, 4, 38324, '2019-01-09 11:36:15'),
(48, 11, 4, 38325, '2019-01-09 11:36:43'),
(50, 43, 7, 38331, '2019-01-09 12:17:13'),
(51, 65, 9, 38334, '2019-01-09 12:42:53'),
(52, 61, 9, 38335, '2019-01-09 12:43:00'),
(55, 21, 5, 38320, '2019-02-11 05:12:21'),
(56, 11, 4, 48142, '2019-02-11 05:13:54'),
(57, 22, 5, 38320, '2019-02-12 12:16:45'),
(58, 23, 5, 38320, '2019-02-13 10:12:20'),
(61, 24, 5, 38320, '2019-02-14 12:58:13'),
(62, 1, 3, 48356, '2019-02-15 11:34:36'),
(64, 72, 10, 38337, '2019-03-18 06:05:00'),
(65, 71, 10, 38337, '2019-03-19 12:46:38'),
(66, 1, 3, 798, '2019-03-19 04:39:54'),
(67, 2, 3, 798, '2019-03-20 01:11:11'),
(68, 66, 9, 38334, '2019-03-19 04:50:52'),
(69, 62, 9, 38335, '2019-03-19 17:25:03'),
(70, 21, 5, 802, '2019-03-19 02:12:43'),
(71, 21, 5, 803, '2019-03-19 23:43:37'),
(72, 31, 6, 804, '2019-03-19 06:14:05'),
(73, 42, 7, 806, '2019-03-20 02:14:42'),
(74, 61, 9, 810, '2019-03-19 18:45:31'),
(75, 22, 5, 803, '2019-03-20 00:11:27'),
(76, 21, 5, 38326, '2019-03-20 11:45:15'),
(77, 62, 9, 810, '2019-03-20 11:54:42'),
(78, 31, 6, 38328, '2019-03-19 23:51:51'),
(79, 32, 6, 38328, '2019-03-20 00:01:25'),
(80, 32, 6, 804, '2019-03-20 00:01:30'),
(81, 21, 5, 38327, '2019-03-21 00:00:24'),
(82, 22, 5, 802, '2019-03-20 17:18:30'),
(85, 43, 7, 806, '2019-03-21 17:48:36'),
(86, 22, 5, 38326, '2019-03-21 00:02:17'),
(87, 23, 5, 802, '2019-03-21 00:56:01'),
(88, 24, 5, 802, '2019-03-22 01:55:36'),
(89, 23, 5, 803, '2019-03-22 20:29:27'),
(90, 33, 6, 804, '2019-03-22 05:55:37'),
(91, 44, 7, 806, '2019-03-22 05:05:34'),
(94, 24, 5, 803, '2019-03-23 15:57:57'),
(96, 23, 5, 38326, '2019-03-25 04:03:59'),
(97, 22, 5, 38327, '2019-03-25 20:45:37'),
(98, 73, 10, 38337, '2019-03-25 17:21:15'),
(99, 25, 5, 802, '2019-03-25 01:31:54'),
(100, 23, 5, 38327, '2019-03-26 16:34:05'),
(101, 33, 6, 38328, '2019-03-26 01:22:48'),
(103, 24, 5, 38326, '2019-03-26 00:49:06'),
(104, 26, 5, 802, '2019-03-26 00:12:41'),
(105, 12, 4, 38324, '2019-03-26 16:43:24'),
(106, 25, 5, 38326, '2019-03-27 00:00:46'),
(107, 74, 10, 38337, '2019-03-27 12:21:49'),
(108, 24, 5, 38327, '2019-03-27 18:09:58'),
(109, 34, 6, 804, '2019-03-27 02:49:36'),
(110, 21, 5, 38328, '2019-04-11 11:33:05'),
(111, 1, 3, 38322, '2019-05-07 13:34:32'),
(112, 81, 1, 60456, '2019-05-08 15:58:22'),
(113, 81, 1, 60439, '2019-05-08 16:05:16'),
(114, 81, 1, 60468, '2019-05-08 17:10:07'),
(115, 81, 1, 60469, '2019-05-08 17:40:21'),
(116, 91, 2, 60457, '2019-05-08 17:53:32'),
(117, 21, 5, 60460, '2019-05-08 18:23:24'),
(118, 11, 4, 60459, '2019-05-08 18:32:24'),
(119, 31, 6, 60461, '2019-05-08 18:51:31'),
(120, 41, 7, 60462, '2019-05-08 19:09:10'),
(121, 51, 8, 60463, '2019-05-08 19:48:30'),
(122, 61, 9, 60465, '2019-05-08 20:00:29'),
(123, 82, 1, 60439, '2019-05-09 10:12:14'),
(124, 82, 1, 60469, '2019-05-09 10:20:19'),
(125, 91, 2, 60441, '2019-05-09 10:31:40'),
(126, 2, 3, 38322, '2019-05-09 11:50:45'),
(127, 62, 9, 60465, '2019-05-09 14:22:20'),
(128, 13, 4, 38324, '2019-05-09 15:37:15'),
(129, 26, 5, 38326, '2019-05-09 16:07:24'),
(130, 81, 1, 60482, '2019-05-09 19:43:09'),
(131, 81, 1, 60483, '2019-05-09 19:52:32'),
(132, 91, 2, 60470, '2019-05-09 19:58:02'),
(133, 1, 3, 60471, '2019-05-09 20:14:43'),
(134, 11, 4, 60472, '2019-05-09 20:42:09'),
(135, 21, 5, 60473, '2019-05-10 10:51:26'),
(136, 31, 6, 60474, '2019-05-10 11:13:27'),
(137, 41, 7, 60475, '2019-05-10 11:38:03'),
(138, 51, 8, 60476, '2019-05-10 11:54:06'),
(139, 61, 9, 60477, '2019-05-10 12:01:08'),
(140, 11, 4, 60443, '2019-05-10 12:21:13'),
(141, 21, 5, 60444, '2019-05-10 12:32:41'),
(142, 31, 6, 60445, '2019-05-10 12:48:41'),
(143, 41, 7, 60446, '2019-05-10 13:01:56'),
(144, 51, 8, 60447, '2019-05-10 13:31:10'),
(145, 61, 9, 60448, '2019-05-10 13:46:44'),
(146, 71, 10, 60449, '2019-05-10 15:10:43'),
(147, 81, 1, 60454, '2019-05-10 15:29:15'),
(148, 91, 2, 60455, '2019-05-10 15:36:35'),
(149, 83, 1, 60439, '2019-05-13 10:27:17'),
(150, 92, 2, 60441, '2019-05-13 10:45:04'),
(151, 82, 1, 60482, '2019-05-13 10:52:43'),
(152, 3, 3, 38322, '2019-05-13 10:53:29'),
(153, 14, 4, 38324, '2019-05-13 11:20:34'),
(154, 27, 5, 38326, '2019-05-13 11:46:30'),
(155, 34, 6, 38328, '2019-05-13 12:03:03'),
(158, 67, 9, 38334, '2019-05-13 13:01:50'),
(159, 71, 10, 38336, '2019-05-13 13:14:42'),
(160, 82, 1, 60468, '2019-05-13 13:38:39'),
(161, 83, 1, 60469, '2019-05-13 13:43:54'),
(162, 52, 8, 60463, '2019-05-13 13:49:30'),
(163, 42, 7, 60462, '2019-05-13 14:01:52'),
(164, 32, 6, 60461, '2019-05-13 15:15:22'),
(165, 22, 5, 60460, '2019-05-13 15:27:19'),
(166, 1, 3, 60442, '2019-05-13 15:36:39'),
(167, 12, 4, 60459, '2019-05-13 15:44:20'),
(168, 1, 3, 60458, '2019-05-13 16:06:04'),
(169, 92, 2, 60457, '2019-05-13 16:15:23'),
(170, 82, 1, 60456, '2019-05-13 16:19:12'),
(171, 82, 1, 60483, '2019-05-13 16:36:13'),
(172, 62, 9, 60477, '2019-05-13 16:42:34'),
(173, 52, 8, 60476, '2019-05-13 16:55:21'),
(174, 32, 6, 60474, '2019-05-13 17:05:49'),
(175, 42, 7, 60475, '2019-05-13 17:20:47'),
(176, 63, 9, 60465, '2019-05-13 18:15:49'),
(177, 71, 10, 60466, '2019-05-13 18:24:15'),
(178, 92, 2, 60470, '2019-05-13 18:33:30'),
(179, 71, 10, 60479, '2019-05-13 18:50:50'),
(180, 84, 1, 60439, '2019-05-17 10:51:07'),
(181, 82, 1, 60454, '2019-05-17 12:05:29'),
(182, 4, 3, 38322, '2019-05-17 12:06:18'),
(183, 15, 4, 38324, '2019-05-17 13:01:01'),
(184, 28, 5, 38326, '2019-05-17 13:16:22'),
(185, 35, 6, 38328, '2019-05-17 13:51:49'),
(186, 41, 7, 38330, '2019-05-17 15:22:08'),
(187, 51, 8, 38332, '2019-05-17 16:51:42'),
(188, 68, 9, 38334, '2019-05-17 17:19:37'),
(189, 72, 10, 38336, '2019-05-17 17:42:19'),
(190, 83, 1, 60482, '2019-05-20 10:11:03'),
(191, 83, 1, 60483, '2019-05-20 10:37:47'),
(192, 83, 1, 60454, '2019-05-20 10:53:12'),
(193, 93, 2, 60470, '2019-05-20 10:57:53'),
(194, 2, 3, 60471, '2019-05-20 11:33:03'),
(195, 12, 4, 60472, '2019-05-20 12:33:19'),
(196, 22, 5, 60473, '2019-05-20 13:25:31'),
(197, 33, 6, 60474, '2019-05-20 15:09:55'),
(198, 43, 7, 60475, '2019-05-20 15:51:05'),
(199, 53, 8, 60476, '2019-05-20 16:45:42'),
(200, 63, 9, 60477, '2019-05-20 17:46:42'),
(201, 92, 2, 60455, '2019-05-20 18:07:04'),
(202, 72, 10, 60479, '2019-05-20 18:23:34'),
(203, 93, 2, 60455, '2019-05-21 10:06:29'),
(204, 16, 4, 38324, '2019-08-05 17:41:42');

-- --------------------------------------------------------

--
-- Table structure for table `math_gamemaster`
--

CREATE TABLE `math_gamemaster` (
  `mid` int(100) NOT NULL,
  `grade_id` int(11) NOT NULL,
  `gs_id` int(11) NOT NULL,
  `gamename` varchar(110) NOT NULL,
  `img_path` varchar(110) NOT NULL,
  `gstatus` int(11) NOT NULL,
  `creation_date` date NOT NULL,
  `modified_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `game_html` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `math_gamemaster`
--

INSERT INTO `math_gamemaster` (`mid`, `grade_id`, `gs_id`, `gamename`, `img_path`, `gstatus`, `creation_date`, `modified_date`, `game_html`) VALUES
(1, 3, 69, 'Abacus1', 'sm_uploads/Abacus_4180846726.png', 1, '2018-11-14', '2018-11-30 02:31:14', 'Abacus1'),
(2, 3, 69, 'AdditionSentence', 'sm_uploads/AdditionSentence_680920318.png', 1, '2018-11-14', '2018-11-14 14:20:34', 'AdditionSentence'),
(3, 3, 69, 'CountUpDown', 'sm_uploads/CountUpDown_6672292379.png', 1, '2018-11-14', '2018-11-14 14:20:34', 'CountUpDown'),
(4, 3, 69, 'DataHandling', 'sm_uploads/DataHandling_5863983076.png', 1, '2018-11-14', '2018-11-14 14:20:34', 'DataHandling'),
(5, 3, 69, 'ExpandedForm', 'sm_uploads/ExpandedForms_4122805078.png', 1, '2018-11-14', '2018-11-30 02:44:38', 'ExpandedForm'),
(6, 3, 69, 'FindThePlaceValue', 'sm_uploads/FindThePlaceValue_5762330922.png', 1, '2018-11-14', '2018-11-14 14:20:34', 'FindThePlaceValue'),
(7, 3, 69, 'Ordering', 'sm_uploads/Ordering_8629188877.png', 1, '2018-11-14', '2018-11-14 14:20:34', 'Ordering'),
(8, 3, 69, 'SubtractionSentence', 'sm_uploads/SubtractionSentence_9375076512.png', 1, '2018-11-14', '2018-11-14 14:20:34', 'SubtractionSentence'),
(9, 3, 69, 'TellingTime', 'sm_uploads/TellingTime_4473059936.png', 1, '2018-11-14', '2018-11-14 14:20:34', 'TellingTime'),
(10, 3, 69, 'TensAndOnes', 'sm_uploads/TensAndOnes_8073049881.png', 1, '2018-11-14', '2018-11-14 14:20:34', 'TensAndOnes'),
(11, 4, 69, 'Comparison', 'sm_uploads/Comparison_6910987743.png', 1, '2018-11-14', '2018-11-14 14:20:34', 'Comparison'),
(12, 4, 69, 'Division', 'sm_uploads/Division_4689232660.png', 1, '2018-11-14', '2018-11-14 14:20:34', 'Division'),
(13, 4, 69, 'Fractions', 'sm_uploads/Fractions_4599967375.png', 1, '2018-11-14', '2018-11-14 14:20:34', 'Fractions'),
(14, 4, 69, 'MeasuringLength', 'sm_uploads/MeasuringLength_2218617442.png', 1, '2018-11-14', '2018-11-14 14:20:34', 'MeasuringLength'),
(15, 4, 69, 'MeasuringWeight', 'sm_uploads/MeasuringWeight_3056199173.png', 1, '2018-11-14', '2018-11-14 14:20:34', 'MeasuringWeight'),
(16, 4, 69, 'Money', 'sm_uploads/Money_3217458599.png', 1, '2018-11-14', '2018-11-14 14:20:34', 'Money'),
(17, 4, 69, 'Multiplication', 'sm_uploads/Multiplication_4357592845.png', 1, '2018-11-14', '2018-11-14 14:20:34', 'Multiplication'),
(18, 4, 69, 'OrderingNumbers', 'sm_uploads/OrderingNumbers_3988811578.png', 1, '2018-11-14', '2018-11-14 14:20:34', 'OrderingNumbers'),
(19, 4, 69, 'PlaceValues1', 'sm_uploads/PlaceValues1_591116957.png', 1, '2018-11-14', '2018-11-14 14:20:34', 'PlaceValues1'),
(20, 4, 69, 'SkipCounting', 'sm_uploads/SkipCounting_3080642288.png', 1, '2018-11-14', '2018-11-14 14:20:34', 'SkipCounting'),
(21, 5, 69, 'Addition1', 'sm_uploads/Addition_6498162765.png', 1, '2018-11-14', '2018-11-30 02:53:14', 'Addition1'),
(22, 5, 69, 'CalendarReading', 'sm_uploads/CalendarReading_4089399431.png', 1, '2018-11-14', '2018-11-14 14:20:34', 'CalendarReading'),
(23, 5, 69, 'Division1', 'sm_uploads/Division_1746674422.png', 1, '2018-11-14', '2018-11-30 02:19:51', 'Division1'),
(24, 5, 69, 'Money1', 'sm_uploads/Money1_9447521078.png', 1, '2018-11-14', '2018-11-14 14:20:34', 'Money1'),
(25, 5, 69, 'Multiplication1', 'sm_uploads/Multiplication_5754009238.png', 1, '2018-11-14', '2018-11-30 02:33:10', 'Multiplication1'),
(26, 5, 69, 'NumberNames', 'sm_uploads/NumberNames_7866210732.png', 1, '2018-11-14', '2018-11-14 14:20:34', 'NumberNames'),
(27, 5, 69, 'PictoGraph', 'sm_uploads/PictoGraph_697983442.png', 1, '2018-11-14', '2018-11-14 14:20:34', 'PictoGraph'),
(28, 5, 69, 'Subtraction1', 'sm_uploads/Subtraction_4698918811.png', 1, '2018-11-14', '2018-11-30 02:24:11', 'Subtraction1'),
(29, 5, 69, 'TellingTime1', 'sm_uploads/TellingTime_7427436001.png', 1, '2018-11-14', '2018-11-30 02:28:39', 'TellingTime1'),
(30, 5, 69, 'WeightsAndBalance', 'sm_uploads/WeightsAndBalance_6692334171.png', 1, '2018-11-14', '2018-11-14 14:20:34', 'WeightsAndBalance'),
(31, 6, 69, 'Decimal', 'sm_uploads/Decimal_1167141757.png', 1, '2018-11-14', '2018-11-14 14:20:34', 'Decimal'),
(32, 6, 69, 'Division2', 'sm_uploads/Division_2050925893.png', 1, '2018-11-14', '2018-11-30 02:21:11', 'Division2'),
(33, 6, 69, 'Factors', 'sm_uploads/Factors_3122764904.png', 1, '2018-11-14', '2018-11-14 14:20:34', 'Factors'),
(34, 6, 69, 'Fractions1', 'sm_uploads/Fractions_1580422050.png', 1, '2018-11-14', '2018-11-30 02:53:14', 'Fractions1'),
(35, 6, 69, 'MetricMeasures', 'sm_uploads/MetricMeasures_7104065096.png', 1, '2018-11-14', '2018-11-14 14:20:34', 'MetricMeasures'),
(36, 6, 69, 'Money2', 'sm_uploads/Money_3255188809.png', 1, '2018-11-14', '2018-11-30 02:30:09', 'Money2'),
(37, 6, 69, 'Numbers', 'sm_uploads/Numbers_9507074630.png', 1, '2018-11-14', '2018-11-14 14:20:34', 'Numbers'),
(38, 6, 69, 'PictoGraph1', 'sm_uploads/PictoGraph_5385083197.png', 1, '2018-11-14', '2018-11-30 02:23:23', 'PictoGraph1'),
(39, 6, 69, 'RomanNumerals', 'sm_uploads/RomanNumerals_8442225940.png', 1, '2018-11-14', '2018-11-14 14:20:34', 'RomanNumerals'),
(40, 6, 69, 'Time', 'sm_uploads/Time_596343181.png', 1, '2018-11-14', '2018-11-14 14:20:34', 'Time'),
(41, 7, 69, 'Area', 'sm_uploads/Area_7308138380.png', 1, '2018-11-14', '2018-11-14 14:20:34', 'Area'),
(42, 7, 69, 'ArithmeticOperation', 'sm_uploads/ArithmeticOperation_9885068116.png', 1, '2018-11-14', '2018-11-14 14:20:34', 'ArithmeticOperation'),
(43, 7, 69, 'DataHandling1', 'sm_uploads/DataHandling_7074244553.png', 1, '2018-11-14', '2018-11-30 02:53:14', 'DataHandling1'),
(44, 7, 69, 'DecimalsPictorialRepresentation', 'sm_uploads/DecimalsPictorialRepresentation_6688598385.png', 1, '2018-11-14', '2018-11-14 14:20:34', 'DecimalsPictorialRepresentation'),
(45, 7, 69, 'Fractions2', 'sm_uploads/Fractions_5533746783.png', 1, '2018-11-14', '2018-11-30 02:53:14', 'Fractions2'),
(46, 7, 69, 'MeasuringAngles', 'sm_uploads/MeasuringAngles_6643810006.png', 1, '2018-11-14', '2018-11-14 14:20:34', 'MeasuringAngles'),
(47, 7, 69, 'MultiplicationAndDivision', 'sm_uploads/MultiplicationAndDivision_646652863.png', 1, '2018-11-14', '2018-11-14 14:20:34', 'MultiplicationAndDivision'),
(48, 7, 69, 'Perimeter', 'sm_uploads/Perimeter_7896288982.png', 1, '2018-11-14', '2018-11-14 14:20:34', 'Perimeter'),
(49, 7, 69, 'ProfitOrLoss', 'sm_uploads/ProfitOrLoss_2083436325.png', 1, '2018-11-14', '2018-11-14 14:20:34', 'ProfitOrLoss'),
(50, 7, 69, 'ReadingTemperature', 'sm_uploads/ReadingTemperature_1073123300.png', 1, '2018-11-14', '2018-11-14 14:20:34', 'ReadingTemperature'),
(51, 8, 69, 'AlgebraicExpressions', 'sm_uploads/AlgebraicExpressions_5022678836.png', 1, '2018-11-14', '2018-11-14 14:20:34', 'AlgebraicExpressions'),
(52, 8, 69, 'Angles', 'sm_uploads/Angles_4316686284.png', 1, '2018-11-14', '2018-11-14 14:20:34', 'Angles'),
(53, 8, 69, 'BarGraphs', 'sm_uploads/BarGraphs_9455108931.png', 1, '2018-11-14', '2018-11-14 14:20:34', 'BarGraphs'),
(54, 8, 69, 'Bodmas', 'sm_uploads/Bodmas_4129943009.png', 1, '2018-11-14', '2018-11-14 14:20:34', 'Bodmas'),
(55, 8, 69, 'ComparisonOfFractions', 'sm_uploads/ComparisonOfFractions_974161447.png', 1, '2018-11-14', '2018-11-14 14:20:34', 'ComparisonOfFractions'),
(56, 8, 69, 'Integers', 'sm_uploads/Integers_2501885509.png', 1, '2018-11-14', '2018-11-14 14:20:34', 'Integers'),
(57, 8, 69, 'Perimeter1', 'sm_uploads/Perimeter_2815022724.png', 1, '2018-11-14', '2018-11-30 01:45:32', 'Perimeter1'),
(58, 8, 69, 'PlaceValue', 'sm_uploads/PlaceValue_9205328556.png', 1, '2018-11-14', '2018-11-14 14:20:34', 'PlaceValue'),
(59, 8, 69, 'Ratios1', 'sm_uploads/Ratios1_9841325306.png', 1, '2018-11-14', '2018-11-14 14:20:34', 'Ratios1'),
(60, 8, 69, 'WordProblems', 'sm_uploads/WordProblems_9072397956.png', 1, '2018-11-14', '2018-11-14 14:20:34', 'WordProblems'),
(61, 9, 69, 'AlgebraicExpressions1', 'sm_uploads/AlgebraicExpressions_9315167246.png', 1, '2018-11-14', '2018-11-30 02:32:24', 'AlgebraicExpressions1'),
(62, 9, 69, 'AnglesFormedByATransversal', 'sm_uploads/AnglesFormedByATransversal_8090837569.png', 1, '2018-11-14', '2018-11-14 14:20:34', 'AnglesFormedByATransversal'),
(63, 9, 69, 'ComplementaryAndSupplementaryAngles', 'sm_uploads/ComplementaryAndSupplementaryAngles_2207047650.png', 1, '2018-11-14', '2018-11-14 14:20:34', 'ComplementaryAndSupplementaryAngles'),
(64, 9, 69, 'FormAlgebraicExpression', 'sm_uploads/FormAlgebraicExpression_9936249903.png', 1, '2018-11-14', '2018-11-14 14:20:34', 'FormAlgebraicExpression'),
(65, 9, 69, 'Fractions3', 'sm_uploads/Fractions_9750380129.png', 1, '2018-11-14', '2018-11-30 02:53:14', 'Fractions3'),
(66, 9, 69, 'Integers1', 'sm_uploads/Integers_5691198534.png', 1, '2018-11-14', '2018-11-30 02:34:24', 'Integers1'),
(67, 9, 69, 'PowerAndExponent', 'sm_uploads/PowerAndExponent_7979888189.png', 1, '2018-11-14', '2018-11-14 14:20:34', 'PowerAndExponent'),
(68, 9, 69, 'Probability1', 'sm_uploads/Probability_5193795752.png', 1, '2018-11-14', '2018-11-30 02:53:14', 'Probability1'),
(69, 9, 69, 'ProfitAndLoss', 'sm_uploads/ProfitAndLoss_7107260106.png', 1, '2018-11-14', '2018-11-14 14:20:34', 'ProfitAndLoss'),
(70, 9, 69, 'Ratio', 'sm_uploads/Ratio_4942117589.png', 1, '2018-11-14', '2018-11-14 14:20:34', 'Ratio'),
(71, 10, 69, 'ComparingRationalNumbers', 'sm_uploads/ComparingRationalNumbers_2835911917.png', 1, '2018-11-14', '2018-11-14 14:20:34', 'ComparingRationalNumbers'),
(72, 10, 69, 'CoordinateGraph', 'sm_uploads/CoordinateGraph_2505224277.png', 1, '2018-11-14', '2018-11-14 14:20:34', 'CoordinateGraph'),
(73, 10, 69, 'Discounts', 'sm_uploads/Discounts_8263450651.png', 1, '2018-11-14', '2018-11-14 14:20:34', 'Discounts'),
(74, 10, 69, 'FrequencyDistribution', 'sm_uploads/FrequencyDistribution_5845637982.png', 1, '2018-11-14', '2018-11-14 14:20:34', 'FrequencyDistribution'),
(75, 10, 69, 'Histograms', 'sm_uploads/Histograms_2570651620.png', 1, '2018-11-14', '2018-11-14 14:20:34', 'Histograms'),
(76, 10, 69, 'Parallelogram', 'sm_uploads/Parallelogram_3395389467.png', 1, '2018-11-14', '2018-11-14 14:20:34', 'Parallelogram'),
(77, 10, 69, 'PieCharts', 'sm_uploads/PieCharts_8026213934.png', 1, '2018-11-14', '2018-11-14 14:20:34', 'PieCharts'),
(78, 10, 69, 'Probability', 'sm_uploads/Probability_2443953682.png', 1, '2018-11-14', '2018-11-14 14:20:34', 'Probability'),
(79, 10, 69, 'Proportions', 'sm_uploads/Proportions_5851775417.png', 1, '2018-11-14', '2018-11-14 14:20:34', 'Proportions'),
(80, 10, 69, 'RepresentRationalNumbers', 'sm_uploads/RepresentRationalNumbers_810125921.png', 1, '2018-11-14', '2018-11-14 14:20:34', 'RepresentRationalNumbers'),
(81, 1, 69, 'ConnectTheDots', 'sm_uploads/ConnectTheDots_2368787559.png', 1, '2018-11-14', '2018-11-14 14:20:34', 'ConnectTheDots'),
(82, 1, 69, 'DrawObjects', 'sm_uploads/DrawObjects_6511433022.png', 1, '2018-11-14', '2018-11-14 14:20:34', 'DrawObjects'),
(83, 1, 69, 'MatchPictureAndNumber', 'sm_uploads/MatchPictureAndNumber_8035868098.png', 1, '2018-11-14', '2018-11-14 14:20:34', 'MatchPictureAndNumber'),
(84, 1, 69, 'MissingNumber', 'sm_uploads/MissingNumber_7184725282.png', 1, '2018-11-14', '2018-11-14 14:20:34', 'MissingNumber'),
(85, 1, 69, 'NumberRecognition', 'sm_uploads/NumberRecognition_2360329194.png', 1, '2018-11-14', '2018-11-14 14:20:34', 'NumberRecognition'),
(86, 1, 69, 'SceneCounting', 'sm_uploads/SceneCounting_6976411170.png', 1, '2018-11-14', '2018-11-14 14:20:34', 'SceneCounting'),
(87, 1, 69, 'ShapeIdentification', 'sm_uploads/ShapeIndentification_6541579924.png', 1, '2018-11-14', '2018-11-30 02:43:09', 'ShapeIdentification'),
(88, 1, 69, 'WhatComesAfter', 'sm_uploads/WhatComeAfter_812028921.png', 1, '2018-11-14', '2018-11-30 02:42:14', 'WhatComesAfter'),
(89, 1, 69, 'WhatComesBefore', 'sm_uploads/WhatComeBefore_334682455.png', 1, '2018-11-14', '2018-11-30 02:42:22', 'WhatComesBefore'),
(90, 1, 69, 'WhatComeInBetween', 'sm_uploads/WhatComeInBetween_7709090574.png', 1, '2018-11-14', '2018-11-14 14:20:34', 'WhatComeInBetween'),
(91, 2, 69, 'Abacus', 'sm_uploads/Abacus_4005045536.png', 1, '2018-11-14', '2018-11-14 14:20:34', 'Abacus'),
(92, 2, 69, 'Addition', 'sm_uploads/Addition_6705379108.png', 1, '2018-11-14', '2018-11-14 14:20:34', 'Addition'),
(93, 2, 69, 'AscendingOrDescending', 'sm_uploads/AscendingOrDescending_7524199825.png', 1, '2018-11-14', '2018-11-14 14:20:34', 'AscendingOrDescending'),
(94, 2, 69, 'BeforeAfterBetween', 'sm_uploads/BeforeAfterBetween_1382627706.png', 1, '2018-11-14', '2018-11-14 14:20:34', 'BeforeAfterBetween'),
(95, 2, 69, 'MissingNumbers', 'sm_uploads/MissingNumbers_4701846409.png', 1, '2018-11-14', '2018-11-14 14:20:34', 'MissingNumbers'),
(96, 2, 69, 'NumbersAndTheirNames', 'sm_uploads/NumbersAndTheirNames_1728372559.png', 1, '2018-11-14', '2018-11-14 14:20:34', 'NumbersAndTheirNames'),
(97, 2, 69, 'OrdinalNumbers', 'sm_uploads/OrdinalNumbers_7629372733.png', 1, '2018-11-14', '2018-11-14 14:20:34', 'OrdinalNumbers'),
(98, 2, 69, 'Positions', 'sm_uploads/Positions_4461775524.png', 1, '2018-11-14', '2018-11-14 14:20:34', 'Positions'),
(99, 2, 69, 'RepresentTheGivenNumber', 'sm_uploads/RepresentTheGivenNumber_4813793930.png', 1, '2018-11-14', '2018-11-14 14:20:34', 'RepresentTheGivenNumber'),
(100, 2, 69, 'Subtraction', 'sm_uploads/Subtraction_5720178936.png', 1, '2018-11-14', '2018-11-14 14:20:34', 'Subtraction');

-- --------------------------------------------------------

--
-- Table structure for table `math_reports`
--

CREATE TABLE `math_reports` (
  `id` int(11) NOT NULL,
  `gu_id` int(10) NOT NULL,
  `gc_id` int(10) NOT NULL,
  `gs_id` int(10) NOT NULL,
  `gp_id` varchar(100) NOT NULL,
  `g_id` int(30) NOT NULL,
  `total_question` varchar(15) NOT NULL,
  `attempt_question` varchar(20) NOT NULL,
  `answer` varchar(20) NOT NULL,
  `game_score` varchar(50) NOT NULL,
  `gtime` varchar(100) NOT NULL,
  `rtime` varchar(100) NOT NULL,
  `crtime` varchar(100) NOT NULL,
  `wrtime` varchar(100) NOT NULL,
  `lastupdate` date NOT NULL,
  `createdby` varchar(100) NOT NULL,
  `creation_date` date NOT NULL,
  `created_date_time` datetime NOT NULL,
  `modifiedby` varchar(100) NOT NULL,
  `modified_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `Is_schedule` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `newsfeedmaster`
--

CREATE TABLE `newsfeedmaster` (
  `ID` int(11) NOT NULL,
  `Scenario` text NOT NULL,
  `Code` varchar(55) NOT NULL,
  `Status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `newsfeedmaster`
--

INSERT INTO `newsfeedmaster` (`ID`, `Scenario`, `Code`, `Status`) VALUES
(1, 'Congratulations - #NAME# completed #GN# #NTH# attempt', '1GAME_COMPLETE', 1),
(2, 'New #THEME# unlocked for #NAME# ', 'THEME_ACTIVATION', 1),
(3, '#NAME# crossed crowny point by #POINTVAL#', 'SPARKEY_LIMIT', 1),
(4, '#NAME# got #B# for #MONTH#', 'BADGES', 1),
(5, 'Congratulations - #NAME# completed all attempts in  #SKILLNAME#', '1SKILL_COMPLETE', 1);

-- --------------------------------------------------------

--
-- Table structure for table `newsfeed_config`
--

CREATE TABLE `newsfeed_config` (
  `ID` int(11) NOT NULL,
  `Type` enum('1','2') NOT NULL COMMENT '1=> School, 2=> Grad',
  `Status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `newsfeed_config`
--

INSERT INTO `newsfeed_config` (`ID`, `Type`, `Status`) VALUES
(1, '2', 1);

-- --------------------------------------------------------

--
-- Table structure for table `newsfeed_data_status`
--

CREATE TABLE `newsfeed_data_status` (
  `ID` int(11) NOT NULL,
  `S_ID` int(11) NOT NULL,
  `G_ID` int(11) NOT NULL,
  `U_ID` int(11) NOT NULL,
  `Value` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `nonschedule`
--

CREATE TABLE `nonschedule` (
  `id` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `noofdays` int(11) NOT NULL,
  `weektype` enum('WD','WE') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `order_number` varchar(15) COLLATE latin1_general_ci NOT NULL,
  `gu_id` int(11) NOT NULL,
  `gp_id` int(10) NOT NULL,
  `date` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `status` int(2) NOT NULL,
  `discount` int(1) NOT NULL,
  `price` varchar(10) COLLATE latin1_general_ci NOT NULL,
  `createdby` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `creation_date` date NOT NULL,
  `modifiedby` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `modified_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `order_details`
--

CREATE TABLE `order_details` (
  `id` int(11) NOT NULL,
  `order_number` varchar(15) COLLATE latin1_general_ci NOT NULL,
  `payment_status` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `createdby` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `creation_date` date NOT NULL,
  `modifiedby` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `modified_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `overalltoppers`
--

CREATE TABLE `overalltoppers` (
  `id` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `gradeid` int(11) NOT NULL,
  `sid` int(11) NOT NULL,
  `value` varchar(55) NOT NULL,
  `type` enum('CT','BT') NOT NULL COMMENT 'CT => Crowny Toppers , BT=> Bspi Toppers',
  `duedate` date NOT NULL,
  `created_on` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `overalltoppers`
--

INSERT INTO `overalltoppers` (`id`, `userid`, `gradeid`, `sid`, `value`, `type`, `duedate`, `created_on`) VALUES
(1, 54938, 3, 80, '96', 'BT', '2019-03-05', '2019-03-05 10:30:02'),
(2, 39740, 4, 2, '94.8', 'BT', '2019-03-05', '2019-03-05 10:30:02'),
(3, 52717, 5, 61, '77', 'BT', '2019-03-05', '2019-03-05 10:30:02'),
(4, 56422, 6, 80, '86.8', 'BT', '2019-03-05', '2019-03-05 10:30:02'),
(5, 39519, 7, 38, '79.02', 'BT', '2019-03-05', '2019-03-05 10:30:02'),
(6, 45870, 8, 51, '78.72', 'BT', '2019-03-05', '2019-03-05 10:30:02'),
(7, 39634, 9, 38, '88', 'BT', '2019-03-05', '2019-03-05 10:30:02'),
(8, 46458, 10, 51, '95.93', 'BT', '2019-03-05', '2019-03-05 10:30:02'),
(9, 51208, 12, 66, '84.4', 'BT', '2019-03-05', '2019-03-05 10:30:02'),
(10, 51445, 13, 66, '85.8', 'BT', '2019-03-05', '2019-03-05 10:30:02'),
(11, 52541, 14, 2, '70.46', 'BT', '2019-03-05', '2019-03-05 10:30:02'),
(12, 48663, 15, 2, '37.5', 'BT', '2019-03-05', '2019-03-05 10:30:02'),
(16, 40173, 3, 38, '28894', 'CT', '2019-03-05', '2019-03-05 10:30:29'),
(17, 52412, 4, 59, '33377', 'CT', '2019-03-05', '2019-03-05 10:30:29'),
(18, 39419, 5, 38, '46420', 'CT', '2019-03-05', '2019-03-05 10:30:29'),
(19, 40209, 6, 38, '16442', 'CT', '2019-03-05', '2019-03-05 10:30:29'),
(20, 39519, 7, 38, '58839', 'CT', '2019-03-05', '2019-03-05 10:30:29'),
(21, 40639, 8, 48, '12964', 'CT', '2019-03-05', '2019-03-05 10:30:29'),
(22, 44317, 9, 50, '23021', 'CT', '2019-03-05', '2019-03-05 10:30:29'),
(23, 44461, 10, 50, '25295', 'CT', '2019-03-05', '2019-03-05 10:30:29'),
(24, 51162, 12, 66, '11148', 'CT', '2019-03-05', '2019-03-05 10:30:29'),
(25, 48503, 13, 53, '3146', 'CT', '2019-03-05', '2019-03-05 10:30:29'),
(26, 52541, 14, 2, '2496', 'CT', '2019-03-05', '2019-03-05 10:30:29'),
(27, 48663, 15, 2, '272', 'CT', '2019-03-05', '2019-03-05 10:30:29');

-- --------------------------------------------------------

--
-- Table structure for table `parent_login_log`
--

CREATE TABLE `parent_login_log` (
  `ID` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `sessionid` varchar(255) NOT NULL,
  `created_date` datetime NOT NULL,
  `lastupdate` datetime NOT NULL,
  `logout_date` datetime NOT NULL,
  `ip` varchar(50) NOT NULL,
  `country` varchar(800) NOT NULL,
  `region` varchar(800) NOT NULL,
  `city` varchar(800) NOT NULL,
  `browser` text NOT NULL,
  `isp` text NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `password_history`
--

CREATE TABLE `password_history` (
  `id` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `changed_on` datetime NOT NULL,
  `newpwd` varchar(110) NOT NULL,
  `ip` varchar(110) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Stand-in structure for view `popupstar`
-- (See below for the actual view)
--
CREATE TABLE `popupstar` (
`gu_id` int(10)
,`lastupdate` date
,`cat_id` int(11)
,`ct` int(1)
,`name` varchar(50)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `popupstargreaterthanninty`
-- (See below for the actual view)
--
CREATE TABLE `popupstargreaterthanninty` (
`gu_id` int(10)
,`lastupdate` date
,`cat_id` int(11)
,`name` varchar(50)
,`ct` double(17,0)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `popupstarlessequalninty`
-- (See below for the actual view)
--
CREATE TABLE `popupstarlessequalninty` (
`gu_id` int(10)
,`lastupdate` date
,`cat_id` int(11)
,`name` varchar(50)
,`ct` double(17,0)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `popupstars`
-- (See below for the actual view)
--
CREATE TABLE `popupstars` (
`lastupdate` date
,`name` varchar(50)
,`ct` double(17,0)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `popuptrophys`
-- (See below for the actual view)
--
CREATE TABLE `popuptrophys` (
`gu_id` int(10)
,`catid` int(11)
,`name` varchar(50)
,`month` int(2)
,`diamond` decimal(16,0)
,`gold` decimal(16,0)
,`silver` decimal(16,0)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `q1_1dayskillcorebymon`
-- (See below for the actual view)
--
CREATE TABLE `q1_1dayskillcorebymon` (
`score` double(19,2)
,`gu_id` int(10)
,`gs_id` int(10)
,`sid` varchar(100)
,`grade_id` int(10)
,`section` varchar(10)
,`username` varchar(100)
,`monthNumber` varchar(2)
,`yearName` varchar(4)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `q1_1dayskillscore`
-- (See below for the actual view)
--
CREATE TABLE `q1_1dayskillscore` (
`score` varchar(50)
,`gs_id` int(10)
,`gu_id` int(10)
,`sid` varchar(100)
,`grade_id` int(10)
,`section` varchar(10)
,`lastupdate` date
,`username` varchar(100)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `q1_avguserbspiscorebymon`
-- (See below for the actual view)
--
CREATE TABLE `q1_avguserbspiscorebymon` (
`finalscore` double(19,2)
,`gu_id` int(10)
,`sid` varchar(100)
,`grade_id` int(10)
,`section` varchar(10)
,`username` varchar(100)
,`monthNumber` varchar(2)
,`monthName` varchar(9)
,`yearName` varchar(4)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `q1_bspibygradesec`
-- (See below for the actual view)
--
CREATE TABLE `q1_bspibygradesec` (
`topbspi` double(19,2)
,`grade_id` int(10)
,`section` varchar(10)
,`sid` varchar(100)
);

-- --------------------------------------------------------

--
-- Table structure for table `q1_bspitopper`
--

CREATE TABLE `q1_bspitopper` (
  `id` int(11) NOT NULL,
  `userid` varchar(510) NOT NULL,
  `sid` int(11) NOT NULL,
  `grade_id` int(11) NOT NULL,
  `section` varchar(16) NOT NULL,
  `name` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `topbspi` varchar(110) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `q1_crowniestopper`
--

CREATE TABLE `q1_crowniestopper` (
  `id` int(11) NOT NULL,
  `userid` varchar(510) NOT NULL,
  `sid` int(11) NOT NULL,
  `grade_id` int(11) NOT NULL,
  `section` varchar(16) NOT NULL,
  `name` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `topbspi` varchar(110) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Stand-in structure for view `q1_crownyuserspoints`
-- (See below for the actual view)
--
CREATE TABLE `q1_crownyuserspoints` (
`cpoints` decimal(32,0)
,`U_ID` int(11)
,`fname` varchar(100)
,`lname` varchar(100)
,`grade_id` int(10)
,`section` varchar(10)
,`sid` varchar(100)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `q1_eachuserbspi`
-- (See below for the actual view)
--
CREATE TABLE `q1_eachuserbspi` (
`finalbspi` double(19,2)
,`gu_id` int(10)
,`grade_id` int(10)
,`section` varchar(10)
,`fname` varchar(100)
,`lname` varchar(100)
,`sid` varchar(100)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `q1_maxcrownypoints`
-- (See below for the actual view)
--
CREATE TABLE `q1_maxcrownypoints` (
`maxpoints` decimal(32,0)
,`grade_id` int(10)
,`section` varchar(10)
,`sid` varchar(100)
);

-- --------------------------------------------------------

--
-- Table structure for table `q1_skilltopper`
--

CREATE TABLE `q1_skilltopper` (
  `id` int(11) NOT NULL,
  `userid` varchar(510) NOT NULL,
  `sid` int(11) NOT NULL,
  `grade_id` int(11) NOT NULL,
  `section` varchar(16) NOT NULL,
  `name` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `skillscore` varchar(110) NOT NULL,
  `gs_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Stand-in structure for view `q1_userscore`
-- (See below for the actual view)
--
CREATE TABLE `q1_userscore` (
`bspi` double(19,2)
,`gu_id` int(10)
,`gs_id` int(10)
,`grade_id` int(10)
,`section` varchar(10)
,`fname` varchar(100)
,`lname` varchar(100)
,`sid` varchar(100)
);

-- --------------------------------------------------------

--
-- Table structure for table `q2_skilltoppersname`
--

CREATE TABLE `q2_skilltoppersname` (
  `id` int(11) NOT NULL,
  `sid` int(11) NOT NULL,
  `gp_id` int(11) NOT NULL,
  `section` varchar(55) NOT NULL,
  `gs_id` int(11) NOT NULL,
  `username` text NOT NULL,
  `value` varchar(55) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `rand_selection`
--

CREATE TABLE `rand_selection` (
  `id` int(11) NOT NULL,
  `gc_id` int(11) DEFAULT NULL,
  `gs_id` int(11) DEFAULT NULL,
  `gid` int(11) DEFAULT NULL,
  `gp_id` int(11) DEFAULT NULL,
  `grade_id` int(11) DEFAULT NULL,
  `section` varchar(10) DEFAULT NULL,
  `school_id` int(11) DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  `created_date` datetime DEFAULT NULL,
  `complexity_level` int(11) NOT NULL,
  `noofpuzzleplayed` int(11) NOT NULL,
  `noofquestionplayed` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `range_values`
--

CREATE TABLE `range_values` (
  `ID` int(11) NOT NULL,
  `startRange` int(11) NOT NULL,
  `endRange` int(11) NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `range_values`
--

INSERT INTO `range_values` (`ID`, `startRange`, `endRange`, `status`) VALUES
(1, 0, 5, 1),
(2, 5, 10, 1),
(3, 10, 15, 1),
(4, 15, 20, 1),
(5, 10, 15, 1),
(6, 15, 20, 1),
(7, 20, 25, 1),
(8, 25, 30, 1),
(9, 30, 35, 1),
(10, 35, 40, 1),
(11, 40, 45, 1),
(12, 45, 50, 1),
(13, 50, 55, 1),
(14, 55, 60, 1),
(15, 60, 65, 1),
(16, 65, 70, 1),
(17, 70, 75, 1),
(18, 75, 80, 1),
(19, 80, 85, 1),
(20, 85, 90, 1),
(21, 90, 95, 1),
(22, 95, 100, 1);

-- --------------------------------------------------------

--
-- Table structure for table `schools`
--

CREATE TABLE `schools` (
  `id` int(100) NOT NULL,
  `school_name` varchar(100) NOT NULL,
  `school_address` varchar(100) NOT NULL,
  `phone` int(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `school_code` varchar(100) NOT NULL,
  `zone` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `district` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `state` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `country` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `city` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `logo` longblob NOT NULL,
  `active` varchar(100) NOT NULL,
  `type` varchar(100) NOT NULL,
  `flag` tinyint(1) NOT NULL,
  `status` int(1) NOT NULL,
  `academic_id` int(11) NOT NULL,
  `createdby` varchar(100) NOT NULL,
  `creation_date` date NOT NULL,
  `modifiedby` varchar(100) NOT NULL,
  `modified_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `visible` int(11) NOT NULL DEFAULT '1',
  `start_date` varchar(20) NOT NULL,
  `session_division` varchar(10) NOT NULL,
  `emailcc` text NOT NULL,
  `timer_value` int(11) NOT NULL,
  `isemailneed` enum('Y','N') NOT NULL DEFAULT 'N'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `schools`
--

INSERT INTO `schools` (`id`, `school_name`, `school_address`, `phone`, `email`, `school_code`, `zone`, `district`, `state`, `country`, `city`, `logo`, `active`, `type`, `flag`, `status`, `academic_id`, `createdby`, `creation_date`, `modifiedby`, `modified_date`, `visible`, `start_date`, `session_division`, `emailcc`, `timer_value`, `isemailneed`) VALUES
(2, 'Edsix School', 'Chennai', 1234567890, 'kalp@skillangels.com', '100', 'Chennai', 'Chennai', 'Tamil Nadu', 'India', 'Chennai', 0x41544d2e706e67, '1', 'CBSE', 1, 1, 20, '', '0000-00-00', '', '2019-03-20 00:44:46', 1, '2017-06-01', '1', '', 18000, 'N'),
(172, 'VK Demo', 'Chennai', 1234567890, 'vk@skillangels.com', 'vk', 'Chennai', 'Chennai', 'Tamil Nadu', 'India', 'Chennai', '', '1', 'CBSE', 1, 1, 20, '', '2019-08-22', '', '2019-08-23 04:54:00', 1, '2019-08-22', '1', '', 18000, 'N');

-- --------------------------------------------------------

--
-- Table structure for table `schools_language`
--

CREATE TABLE `schools_language` (
  `ID` int(11) NOT NULL,
  `schoolID` int(11) NOT NULL,
  `languageID` int(11) NOT NULL,
  `status` enum('Y','N') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `schools_language`
--

INSERT INTO `schools_language` (`ID`, `schoolID`, `languageID`, `status`) VALUES
(11, 2, 1, 'Y'),
(12, 2, 3, 'Y');

-- --------------------------------------------------------

--
-- Table structure for table `schools_leave_list`
--

CREATE TABLE `schools_leave_list` (
  `id` int(11) NOT NULL,
  `school_id` int(11) NOT NULL,
  `leave_date` varchar(20) CHARACTER SET utf8 NOT NULL,
  `reason` varchar(100) NOT NULL,
  `academic_id` int(11) NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `schools_period_schedule`
--

CREATE TABLE `schools_period_schedule` (
  `schedule_id` int(11) NOT NULL,
  `school_id` int(11) NOT NULL,
  `period` int(11) NOT NULL,
  `start_time` varchar(20) CHARACTER SET utf8 NOT NULL,
  `end_time` varchar(20) NOT NULL,
  `monday_grade` varchar(10) NOT NULL,
  `tuesday_grade` varchar(10) NOT NULL,
  `wednesday_grade` varchar(10) NOT NULL,
  `thursday_grade` varchar(10) NOT NULL,
  `friday_grade` varchar(10) NOT NULL,
  `saturday_grade` varchar(10) NOT NULL,
  `sunday_grade` varchar(10) NOT NULL,
  `monday_section` varchar(10) NOT NULL,
  `tuesday_section` varchar(10) NOT NULL,
  `wednesday_section` varchar(10) NOT NULL,
  `thursday_section` varchar(10) NOT NULL,
  `friday_section` varchar(10) NOT NULL,
  `saturday_section` varchar(10) NOT NULL,
  `sunday_section` varchar(10) NOT NULL,
  `academic_id` int(11) NOT NULL,
  `status` enum('Y','N','D') NOT NULL,
  `remarks` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `schools_period_schedule`
--

INSERT INTO `schools_period_schedule` (`schedule_id`, `school_id`, `period`, `start_time`, `end_time`, `monday_grade`, `tuesday_grade`, `wednesday_grade`, `thursday_grade`, `friday_grade`, `saturday_grade`, `sunday_grade`, `monday_section`, `tuesday_section`, `wednesday_section`, `thursday_section`, `friday_section`, `saturday_section`, `sunday_section`, `academic_id`, `status`, `remarks`) VALUES
(25, 2, 1, '9:30', '10:15', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 20, 'Y', ''),
(26, 2, 2, '10:15', '11:00', '', '', 'IV', '', 'V', '', '', '', '', 'A', '', 'A', '', '', 20, 'Y', ''),
(27, 2, 3, '11:10', '11:50', 'VII', 'I', '', '', '', '', '', 'A', 'A', '', '', '', '', '', 20, 'Y', ''),
(28, 2, 4, '11:50', '12:30', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 20, 'Y', ''),
(29, 2, 5, '13:15', '14:05', 'I', '', 'VI', '', 'III', '', '', 'A', '', 'A', '', 'A', '', '', 20, 'Y', ''),
(30, 2, 6, '14:05', '14:50', 'V', '', '', '', '', '', '', 'A', '', '', '', '', '', '', 20, 'Y', ''),
(31, 2, 7, '15:00', '15:45', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 20, 'Y', ''),
(32, 2, 8, '15:45', '16:30', 'III', '', '', '', '', '', '', 'A', '', '', '', '', '', '', 20, 'Y', '');

-- --------------------------------------------------------

--
-- Table structure for table `schools_period_schedule_days`
--

CREATE TABLE `schools_period_schedule_days` (
  `ID` int(11) NOT NULL,
  `period_no` int(11) NOT NULL,
  `period_date` date NOT NULL,
  `period_day` varchar(20) NOT NULL,
  `grade_id` int(11) NOT NULL,
  `grade_name` varchar(20) NOT NULL,
  `section` varchar(10) NOT NULL,
  `starttime` time NOT NULL,
  `endtime` time NOT NULL,
  `sid` int(11) NOT NULL,
  `academic_id` int(11) NOT NULL,
  `expected_user` int(11) NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `schools_period_schedule_daysbeta`
--

CREATE TABLE `schools_period_schedule_daysbeta` (
  `ID` int(11) NOT NULL,
  `period_no` int(11) NOT NULL,
  `period_date` date NOT NULL,
  `period_day` varchar(20) NOT NULL,
  `grade_id` int(11) NOT NULL,
  `grade_name` varchar(20) NOT NULL,
  `section` varchar(10) NOT NULL,
  `starttime` time NOT NULL,
  `endtime` time NOT NULL,
  `sid` int(11) NOT NULL,
  `academic_id` int(11) NOT NULL,
  `total_user` int(11) NOT NULL,
  `expected_user` int(11) NOT NULL,
  `session_division` varchar(55) NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `schools_period_schedule_daysbeta_session`
--

CREATE TABLE `schools_period_schedule_daysbeta_session` (
  `ID` int(11) NOT NULL,
  `period_no` int(11) NOT NULL,
  `period_date` date NOT NULL,
  `period_day` varchar(20) NOT NULL,
  `grade_id` int(11) NOT NULL,
  `grade_name` varchar(20) NOT NULL,
  `section` varchar(10) NOT NULL,
  `starttime` time NOT NULL,
  `endtime` time NOT NULL,
  `sid` int(11) NOT NULL,
  `academic_id` int(11) NOT NULL,
  `total_user` int(11) NOT NULL,
  `expected_user` int(11) NOT NULL,
  `session_division` varchar(55) NOT NULL,
  `status` int(11) NOT NULL,
  `attended_user` int(11) NOT NULL,
  `completed_user` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `school_academic_mapping`
--

CREATE TABLE `school_academic_mapping` (
  `ID` int(11) NOT NULL,
  `SID` int(11) NOT NULL COMMENT 'SID => School ID',
  `AID` int(11) NOT NULL COMMENT 'AID => Academic ID',
  `Status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `school_academic_mapping`
--

INSERT INTO `school_academic_mapping` (`ID`, `SID`, `AID`, `Status`) VALUES
(3, 2, 20, 1),
(4, 172, 20, 1);

-- --------------------------------------------------------

--
-- Table structure for table `school_admin`
--

CREATE TABLE `school_admin` (
  `id` int(11) NOT NULL,
  `email` varchar(250) NOT NULL,
  `password` varchar(100) NOT NULL,
  `fname` varchar(50) NOT NULL,
  `lname` varchar(50) DEFAULT NULL,
  `initial` varchar(5) DEFAULT NULL,
  `mobile` int(15) NOT NULL,
  `dob` date DEFAULT NULL,
  `address` varchar(300) NOT NULL,
  `School_Name` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `school_id` int(11) NOT NULL,
  `active` int(1) NOT NULL,
  `status` int(1) NOT NULL,
  `flag` int(11) NOT NULL,
  `createdby` varchar(100) NOT NULL,
  `creation_date` datetime NOT NULL,
  `modifiedby` varchar(100) NOT NULL,
  `modified_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `session_id` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `school_admin`
--

INSERT INTO `school_admin` (`id`, `email`, `password`, `fname`, `lname`, `initial`, `mobile`, `dob`, `address`, `School_Name`, `school_id`, `active`, `status`, `flag`, `createdby`, `creation_date`, `modifiedby`, `modified_date`, `session_id`) VALUES
(41, 'adminskillangels', 'ca9139d33a0a27a6bcf77910a32514be', 'EdSix', 'Admin', NULL, 994049481, NULL, 'Chennai', '', 2, 1, 0, 1, '', '0000-00-00 00:00:00', '', '2014-06-26 01:13:37', '');

-- --------------------------------------------------------

--
-- Stand-in structure for view `sc_usertotgamescore`
-- (See below for the actual view)
--
CREATE TABLE `sc_usertotgamescore` (
`gu_id` int(10)
,`grade_id` int(10)
,`gp_id` int(10)
,`sid` varchar(100)
,`section` varchar(10)
,`username` varchar(100)
,`fname` varchar(100)
,`score` double
);

-- --------------------------------------------------------

--
-- Table structure for table `section`
--

CREATE TABLE `section` (
  `id` int(11) NOT NULL,
  `section` int(11) NOT NULL,
  `status` int(1) NOT NULL,
  `createdby` varchar(100) NOT NULL,
  `creation_date` date NOT NULL,
  `modifiedby` varchar(100) NOT NULL,
  `modified_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `skillkit_configuration`
--

CREATE TABLE `skillkit_configuration` (
  `Recid` int(11) NOT NULL,
  `GamesNos` int(11) NOT NULL,
  `PlayTimes` int(11) NOT NULL,
  `EffectiveFrom` date NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `skillkit_configuration`
--

INSERT INTO `skillkit_configuration` (`Recid`, `GamesNos`, `PlayTimes`, `EffectiveFrom`) VALUES
(3, 3, 1, '2015-02-01');

-- --------------------------------------------------------

--
-- Table structure for table `skillkit_game_reports`
--

CREATE TABLE `skillkit_game_reports` (
  `id` int(11) NOT NULL,
  `gu_id` int(10) NOT NULL,
  `gc_id` int(10) NOT NULL,
  `gs_id` int(10) NOT NULL,
  `gp_id` varchar(100) NOT NULL,
  `g_id` int(30) NOT NULL,
  `total_question` varchar(15) NOT NULL,
  `attempt_question` varchar(20) NOT NULL,
  `answer` varchar(20) NOT NULL,
  `game_score` varchar(50) NOT NULL,
  `gtime` varchar(100) NOT NULL,
  `rtime` varchar(100) NOT NULL,
  `crtime` varchar(100) NOT NULL,
  `wrtime` varchar(100) NOT NULL,
  `GameTypeFlg` varchar(25) NOT NULL,
  `lastupdate` date NOT NULL,
  `createdby` varchar(100) NOT NULL,
  `creation_date` date NOT NULL,
  `modifiedby` varchar(100) NOT NULL,
  `modified_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `skillkit_master`
--

CREATE TABLE `skillkit_master` (
  `id` int(11) NOT NULL,
  `grade_id` int(11) NOT NULL,
  `skill_id` int(11) NOT NULL,
  `median_score` varchar(55) NOT NULL,
  `median_value` varchar(55) NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `skillkit_master`
--

INSERT INTO `skillkit_master` (`id`, `grade_id`, `skill_id`, `median_score`, `median_value`, `status`) VALUES
(1, 3, 59, '30', '25-30', 1),
(2, 3, 60, '67', '65-70', 1),
(3, 3, 61, '75', '70-75', 1),
(4, 3, 62, '49', '45-50', 1),
(5, 3, 63, '36', '35-40', 1),
(6, 4, 59, '48', '45-50', 1),
(7, 4, 60, '52', '50-55', 1),
(8, 4, 61, '53', '50-55', 1),
(9, 4, 62, '39', '35-40', 1),
(10, 4, 63, '66', '65-70', 1),
(11, 5, 59, '10', '5-10', 1),
(12, 5, 60, '56', '55-60', 1),
(13, 5, 61, '50', '45-50', 1),
(14, 5, 62, '22', '25-30', 1),
(15, 5, 63, '17', '15-20', 1),
(16, 6, 59, '30', '25-30', 1),
(17, 6, 60, '57', '55-60', 1),
(18, 6, 61, '30', '25-30', 1),
(19, 6, 62, '29', '25-30', 1),
(20, 6, 63, '10', '5-10', 1),
(21, 7, 59, '30', '25-30', 1),
(22, 7, 60, '40', '35-40', 1),
(23, 7, 61, '76', '75-80', 1),
(24, 7, 62, '28', '25-30', 1),
(25, 7, 63, '26', '25-30', 1),
(26, 8, 59, '40', '35-40', 1),
(27, 8, 60, '30', '25-30', 1),
(28, 8, 61, '46', '45-50', 1),
(29, 8, 62, '40', '35-40', 1),
(30, 8, 63, '29', '25-30', 1),
(31, 9, 59, '38', '35-40', 1),
(32, 9, 60, '31', '30-35', 1),
(33, 9, 61, '45', '40-45', 1),
(34, 9, 62, '34', '30-35', 1),
(35, 9, 63, '49', '45-50', 1),
(36, 10, 59, '20', '15-20', 1),
(37, 10, 60, '25', '20-25', 1),
(38, 10, 61, '40', '35-40', 1),
(39, 10, 62, '33', '30-35', 1),
(40, 10, 63, '3', '0-5', 1),
(41, 12, 59, '30', '25-30', 1),
(42, 12, 60, '50', '45-50', 1),
(43, 12, 61, '27', '25-30', 1),
(44, 12, 62, '24', '20-25', 1),
(45, 12, 63, '7', '5-10', 1),
(46, 13, 59, '47', '45-50', 1),
(47, 13, 60, '28', '25-30', 1),
(48, 13, 61, '64', '65-70', 1),
(49, 13, 62, '0', '0-5', 1),
(50, 13, 63, '46', '45-50', 1),
(51, 14, 59, '40', '35-40', 1),
(52, 14, 60, '26', '25-30', 1),
(53, 14, 61, '78', '75-80', 1),
(54, 14, 62, '10', '5-10', 1),
(55, 14, 63, '7', '5-10', 1);

-- --------------------------------------------------------

--
-- Table structure for table `skillkit_random_game`
--

CREATE TABLE `skillkit_random_game` (
  `id` int(5) NOT NULL,
  `userid` varchar(50) NOT NULL,
  `gameid` varchar(50) NOT NULL,
  `datecreated` date NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `skl_class`
--

CREATE TABLE `skl_class` (
  `id` int(11) NOT NULL,
  `school_id` int(11) NOT NULL,
  `class_id` int(11) NOT NULL,
  `status` int(1) NOT NULL,
  `createdby` varchar(100) NOT NULL,
  `creation_date` date NOT NULL,
  `modifiedby` varchar(100) NOT NULL,
  `modified_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `skl_class_plan`
--

CREATE TABLE `skl_class_plan` (
  `id` int(11) NOT NULL,
  `school_id` int(11) NOT NULL,
  `class_id` int(11) NOT NULL,
  `plan_id` int(11) NOT NULL,
  `status` int(1) NOT NULL,
  `createdby` varchar(100) NOT NULL,
  `creation_date` date NOT NULL,
  `modifiedby` varchar(100) NOT NULL,
  `modified_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `skl_class_plan`
--

INSERT INTO `skl_class_plan` (`id`, `school_id`, `class_id`, `plan_id`, `status`, `createdby`, `creation_date`, `modifiedby`, `modified_date`) VALUES
(19, 2, 3, 1, 0, '', '0000-00-00', '', '2017-06-03 04:09:53'),
(20, 2, 4, 2, 0, '', '0000-00-00', '', '2017-06-03 04:09:57'),
(21, 2, 5, 3, 0, '', '0000-00-00', '', '2017-06-03 04:10:01'),
(22, 2, 6, 4, 0, '', '0000-00-00', '', '2017-06-03 04:10:08'),
(23, 2, 7, 5, 0, '', '0000-00-00', '', '2017-06-03 04:10:13'),
(24, 2, 8, 6, 0, '', '0000-00-00', '', '2017-06-03 04:10:21'),
(25, 2, 9, 7, 0, '', '0000-00-00', '', '2017-06-03 04:10:25'),
(26, 2, 10, 8, 0, '', '0000-00-00', '', '2017-06-03 04:10:28'),
(162, 2, 12, 92, 0, '', '2018-07-26', '', '2018-07-26 06:34:23'),
(163, 2, 13, 93, 0, '', '2018-07-26', '', '2018-07-26 06:34:23'),
(164, 2, 14, 94, 0, '', '2018-07-26', '', '2018-07-26 06:34:23'),
(165, 2, 15, 95, 0, '', '2018-07-26', '', '2018-07-26 06:34:23'),
(166, 2, 1, 10, 0, '', '0000-00-00', '', '2017-06-03 04:09:53'),
(167, 2, 2, 11, 0, '', '0000-00-00', '', '2017-06-03 04:09:53');

-- --------------------------------------------------------

--
-- Table structure for table `skl_class_section`
--

CREATE TABLE `skl_class_section` (
  `id` int(11) NOT NULL,
  `school_id` int(11) NOT NULL,
  `class_id` int(11) NOT NULL,
  `section` varchar(10) NOT NULL,
  `status` int(1) NOT NULL,
  `createdby` varchar(100) NOT NULL,
  `creation_date` date NOT NULL,
  `modifiedby` text NOT NULL,
  `modified_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `skl_class_section`
--

INSERT INTO `skl_class_section` (`id`, `school_id`, `class_id`, `section`, `status`, `createdby`, `creation_date`, `modifiedby`, `modified_date`) VALUES
(39, 2, 3, 'A', 0, '', '0000-00-00', '', '2014-06-25 14:22:26'),
(40, 2, 4, 'A', 0, '', '0000-00-00', '', '2014-06-25 14:22:30'),
(41, 2, 5, 'A', 0, '', '0000-00-00', '', '2014-06-25 14:22:37'),
(42, 2, 6, 'A', 0, '', '0000-00-00', '', '2014-06-25 14:22:41'),
(43, 2, 7, 'A', 0, '', '0000-00-00', '', '2014-06-25 14:22:46'),
(44, 2, 8, 'A', 0, '', '0000-00-00', '', '2014-06-25 14:22:51'),
(45, 2, 9, 'A', 0, '', '0000-00-00', '', '2014-06-25 14:22:58'),
(46, 2, 10, 'A', 0, '', '0000-00-00', '', '2014-06-25 14:23:04'),
(385, 2, 12, 'A', 0, '', '2018-07-26', '', '2018-07-26 06:35:12'),
(386, 2, 13, 'A', 0, '', '2018-07-26', '', '2018-07-26 06:35:12'),
(387, 2, 14, 'A', 0, '', '2018-07-26', '', '2018-07-26 06:35:12'),
(388, 2, 15, 'A', 0, '', '2018-07-26', '', '2018-07-26 06:35:12');

-- --------------------------------------------------------

--
-- Table structure for table `skl_dcnt_coupon`
--

CREATE TABLE `skl_dcnt_coupon` (
  `id` int(11) NOT NULL,
  `dcnt_name` varchar(70) NOT NULL,
  `dcnt_code` varchar(25) NOT NULL,
  `percentage` varchar(11) NOT NULL,
  `timecreated` int(11) NOT NULL,
  `timemodified` int(11) NOT NULL,
  `startdate` int(11) NOT NULL,
  `enddate` int(11) NOT NULL,
  `status` int(1) NOT NULL,
  `createdby` varchar(100) NOT NULL,
  `creation_date` date NOT NULL,
  `modifiedby` varchar(100) NOT NULL,
  `modified_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `skl_grade`
--

CREATE TABLE `skl_grade` (
  `id` int(11) NOT NULL,
  `grdname` varchar(45) NOT NULL,
  `status` int(1) NOT NULL,
  `createdby` varchar(100) NOT NULL,
  `creation_date` date NOT NULL,
  `modifiedby` varchar(100) NOT NULL,
  `modified_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `skl_grade_game_map`
--

CREATE TABLE `skl_grade_game_map` (
  `id` int(11) NOT NULL,
  `school_id` int(11) NOT NULL,
  `game_id` int(11) NOT NULL,
  `grade_id` int(11) NOT NULL,
  `status` int(1) NOT NULL,
  `createdby` varchar(100) NOT NULL,
  `creation_date` date NOT NULL,
  `modifiedby` varchar(100) NOT NULL,
  `modified_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `skl_grade_game_map`
--

INSERT INTO `skl_grade_game_map` (`id`, `school_id`, `game_id`, `grade_id`, `status`, `createdby`, `creation_date`, `modifiedby`, `modified_date`) VALUES
(1, 0, 1, 0, 0, '', '0000-00-00', '', '2014-06-17 08:11:13'),
(2, 0, 2, 0, 0, '', '0000-00-00', '', '2014-06-17 08:11:52'),
(3, 0, 3, 0, 0, '', '0000-00-00', '', '2014-06-17 08:12:19'),
(4, 0, 4, 0, 0, '', '0000-00-00', '', '2014-06-17 08:12:51'),
(5, 0, 5, 0, 0, '', '0000-00-00', '', '2014-06-17 08:13:30'),
(6, 0, 6, 0, 0, '', '0000-00-00', '', '2014-06-17 08:14:17'),
(7, 0, 7, 0, 0, '', '0000-00-00', '', '2014-06-17 08:15:07'),
(8, 0, 8, 0, 0, '', '0000-00-00', '', '2014-06-17 08:15:39'),
(9, 0, 9, 0, 0, '', '0000-00-00', '', '2014-06-17 08:16:36'),
(10, 0, 10, 0, 0, '', '0000-00-00', '', '2014-06-17 08:19:37'),
(11, 0, 11, 0, 0, '', '0000-00-00', '', '2014-06-17 08:20:13'),
(12, 0, 12, 0, 0, '', '0000-00-00', '', '2014-06-17 08:20:45'),
(13, 0, 13, 0, 0, '', '0000-00-00', '', '2014-06-17 08:21:24'),
(14, 0, 14, 0, 0, '', '0000-00-00', '', '2014-06-17 08:21:56'),
(15, 0, 15, 0, 0, '', '0000-00-00', '', '2014-06-17 08:25:47'),
(16, 0, 16, 0, 0, '', '0000-00-00', '', '2014-06-17 08:26:17'),
(17, 0, 17, 0, 0, '', '0000-00-00', '', '2014-06-17 08:26:56'),
(18, 0, 18, 0, 0, '', '0000-00-00', '', '2014-06-17 08:27:30'),
(19, 0, 19, 0, 0, '', '0000-00-00', '', '2014-06-17 08:28:32'),
(20, 0, 20, 0, 0, '', '0000-00-00', '', '2014-06-17 08:29:01'),
(21, 0, 21, 0, 0, '', '0000-00-00', '', '2014-06-17 08:30:24'),
(22, 0, 22, 0, 0, '', '0000-00-00', '', '2014-06-17 08:31:54'),
(23, 0, 23, 0, 0, '', '0000-00-00', '', '2014-06-17 08:32:26'),
(24, 0, 24, 0, 0, '', '0000-00-00', '', '2014-06-17 08:33:28'),
(25, 0, 25, 0, 0, '', '0000-00-00', '', '2014-06-17 08:34:10'),
(26, 0, 26, 0, 0, '', '0000-00-00', '', '2014-06-17 08:34:43'),
(27, 0, 27, 0, 0, '', '0000-00-00', '', '2014-06-17 08:35:28'),
(28, 0, 28, 0, 0, '', '0000-00-00', '', '2014-06-17 08:36:29'),
(29, 0, 29, 0, 0, '', '0000-00-00', '', '2014-06-17 08:37:52'),
(30, 0, 30, 0, 0, '', '0000-00-00', '', '2014-06-17 08:38:37'),
(31, 0, 31, 0, 0, '', '0000-00-00', '', '2014-06-17 08:39:10'),
(32, 0, 32, 0, 0, '', '0000-00-00', '', '2014-06-17 08:39:47'),
(33, 0, 33, 0, 0, '', '0000-00-00', '', '2014-06-17 08:40:24'),
(34, 0, 34, 0, 0, '', '0000-00-00', '', '2014-06-17 08:41:06'),
(35, 0, 35, 0, 0, '', '0000-00-00', '', '2014-06-17 08:44:00'),
(36, 0, 36, 0, 0, '', '0000-00-00', '', '2014-06-17 08:50:47'),
(37, 0, 37, 0, 0, '', '0000-00-00', '', '2014-06-17 08:51:37'),
(38, 0, 38, 0, 0, '', '0000-00-00', '', '2014-06-17 08:52:08'),
(39, 0, 39, 0, 0, '', '0000-00-00', '', '2014-06-17 08:52:41'),
(40, 0, 40, 0, 0, '', '0000-00-00', '', '2014-06-17 08:53:17'),
(41, 0, 41, 0, 0, '', '0000-00-00', '', '2014-06-17 08:53:51'),
(42, 0, 42, 0, 0, '', '0000-00-00', '', '2014-06-17 08:54:24'),
(43, 0, 43, 0, 0, '', '0000-00-00', '', '2014-06-17 08:55:25'),
(44, 0, 44, 0, 0, '', '0000-00-00', '', '2014-06-17 08:55:49'),
(45, 0, 45, 0, 0, '', '0000-00-00', '', '2014-06-17 08:56:15'),
(46, 0, 46, 0, 0, '', '0000-00-00', '', '2014-06-17 08:56:42'),
(47, 0, 47, 0, 0, '', '0000-00-00', '', '2014-06-17 08:57:43'),
(48, 0, 48, 0, 0, '', '0000-00-00', '', '2014-06-17 08:58:18'),
(49, 0, 49, 0, 0, '', '0000-00-00', '', '2014-06-17 08:59:02'),
(50, 0, 50, 0, 0, '', '0000-00-00', '', '2014-06-17 08:59:37'),
(51, 0, 51, 0, 0, '', '0000-00-00', '', '2014-06-17 09:00:17'),
(52, 0, 52, 0, 0, '', '0000-00-00', '', '2014-06-17 09:01:01'),
(53, 0, 53, 0, 0, '', '0000-00-00', '', '2014-06-17 09:01:39'),
(54, 0, 54, 0, 0, '', '0000-00-00', '', '2014-06-17 09:02:21'),
(55, 0, 55, 0, 0, '', '0000-00-00', '', '2014-06-17 09:02:56'),
(56, 0, 56, 0, 0, '', '0000-00-00', '', '2014-06-17 09:03:34'),
(57, 0, 57, 0, 0, '', '0000-00-00', '', '2014-06-17 09:04:04'),
(58, 0, 58, 0, 0, '', '0000-00-00', '', '2014-06-17 09:04:48'),
(59, 0, 59, 0, 0, '', '0000-00-00', '', '2014-06-17 09:05:23'),
(60, 0, 60, 0, 0, '', '0000-00-00', '', '2014-06-17 09:05:50'),
(61, 0, 61, 0, 0, '', '0000-00-00', '', '2014-06-17 09:06:19'),
(62, 0, 62, 0, 0, '', '0000-00-00', '', '2014-06-17 09:07:36'),
(63, 0, 63, 0, 0, '', '0000-00-00', '', '2014-06-17 09:09:45'),
(64, 0, 64, 0, 0, '', '0000-00-00', '', '2014-06-17 09:12:09'),
(65, 0, 65, 0, 0, '', '0000-00-00', '', '2014-06-17 09:12:42'),
(66, 0, 66, 0, 0, '', '0000-00-00', '', '2014-06-17 09:13:17'),
(67, 0, 67, 0, 0, '', '0000-00-00', '', '2014-06-17 09:14:01'),
(68, 0, 68, 0, 0, '', '0000-00-00', '', '2014-06-17 09:14:31'),
(69, 0, 69, 0, 0, '', '0000-00-00', '', '2014-06-17 09:15:01'),
(70, 0, 70, 0, 0, '', '0000-00-00', '', '2014-06-17 09:16:04'),
(71, 0, 71, 0, 0, '', '0000-00-00', '', '2014-06-17 09:16:48'),
(72, 0, 72, 0, 0, '', '0000-00-00', '', '2014-06-17 09:17:17'),
(73, 0, 73, 0, 0, '', '0000-00-00', '', '2014-06-17 09:21:00'),
(74, 0, 74, 0, 0, '', '0000-00-00', '', '2014-06-17 09:21:33'),
(75, 0, 75, 0, 0, '', '0000-00-00', '', '2014-06-17 09:22:15'),
(76, 0, 76, 0, 0, '', '0000-00-00', '', '2014-06-17 09:23:03'),
(77, 0, 77, 0, 0, '', '0000-00-00', '', '2014-06-17 09:23:44'),
(78, 0, 78, 0, 0, '', '0000-00-00', '', '2014-06-17 09:24:36'),
(79, 0, 79, 0, 0, '', '0000-00-00', '', '2014-06-17 09:25:11'),
(80, 0, 80, 0, 0, '', '0000-00-00', '', '2014-06-17 09:25:45'),
(81, 0, 81, 0, 0, '', '0000-00-00', '', '2014-06-17 09:26:23'),
(82, 0, 82, 0, 0, '', '0000-00-00', '', '2014-06-17 09:26:59'),
(83, 0, 83, 0, 0, '', '0000-00-00', '', '2014-06-17 09:34:17'),
(84, 0, 84, 0, 0, '', '0000-00-00', '', '2014-06-17 09:34:58'),
(85, 0, 85, 0, 0, '', '0000-00-00', '', '2014-06-17 09:35:26'),
(86, 0, 86, 0, 0, '', '0000-00-00', '', '2014-06-17 09:36:01'),
(87, 0, 87, 0, 0, '', '0000-00-00', '', '2014-06-17 09:36:41'),
(88, 0, 88, 0, 0, '', '0000-00-00', '', '2014-06-17 09:37:24'),
(89, 0, 89, 0, 0, '', '0000-00-00', '', '2014-06-17 09:37:59'),
(90, 0, 90, 0, 0, '', '0000-00-00', '', '2014-06-17 09:38:30'),
(91, 0, 91, 0, 0, '', '0000-00-00', '', '2014-06-17 09:39:22'),
(92, 0, 92, 0, 0, '', '0000-00-00', '', '2014-06-17 09:39:58'),
(93, 0, 93, 0, 0, '', '0000-00-00', '', '2014-06-17 09:40:36'),
(94, 0, 94, 0, 0, '', '0000-00-00', '', '2014-06-17 09:41:04'),
(95, 0, 95, 0, 0, '', '0000-00-00', '', '2014-06-17 09:41:42'),
(96, 0, 96, 0, 0, '', '0000-00-00', '', '2014-06-17 09:42:14'),
(97, 0, 97, 0, 0, '', '0000-00-00', '', '2014-06-17 09:42:59'),
(98, 0, 98, 0, 0, '', '0000-00-00', '', '2014-06-17 09:43:29'),
(99, 0, 99, 0, 0, '', '0000-00-00', '', '2014-06-17 09:44:14'),
(100, 0, 100, 0, 0, '', '0000-00-00', '', '2014-06-17 09:44:46'),
(101, 0, 101, 0, 0, '', '0000-00-00', '', '2014-06-17 09:45:14'),
(102, 0, 102, 0, 0, '', '0000-00-00', '', '2014-06-17 09:45:44'),
(103, 0, 103, 0, 0, '', '0000-00-00', '', '2014-06-17 09:46:13'),
(104, 0, 104, 0, 0, '', '0000-00-00', '', '2014-06-17 09:47:28'),
(105, 0, 105, 0, 0, '', '0000-00-00', '', '2014-06-17 09:48:09'),
(106, 0, 106, 0, 0, '', '0000-00-00', '', '2014-06-17 09:48:38'),
(107, 0, 107, 0, 0, '', '0000-00-00', '', '2014-06-17 09:49:30'),
(108, 0, 108, 0, 0, '', '0000-00-00', '', '2014-06-17 09:49:59'),
(109, 0, 109, 0, 0, '', '0000-00-00', '', '2014-06-17 09:50:45'),
(110, 0, 110, 0, 0, '', '0000-00-00', '', '2014-06-17 09:51:48'),
(111, 0, 111, 0, 0, '', '0000-00-00', '', '2014-06-17 09:52:23'),
(112, 0, 112, 0, 0, '', '0000-00-00', '', '2014-06-17 09:52:56'),
(113, 0, 113, 0, 0, '', '0000-00-00', '', '2014-06-17 09:53:25'),
(114, 0, 114, 0, 0, '', '0000-00-00', '', '2014-06-17 09:53:54'),
(115, 0, 115, 0, 0, '', '0000-00-00', '', '2014-06-17 09:54:35'),
(116, 0, 116, 0, 0, '', '0000-00-00', '', '2014-06-17 09:55:18'),
(117, 0, 117, 0, 0, '', '0000-00-00', '', '2014-06-17 09:55:43'),
(118, 0, 118, 0, 0, '', '0000-00-00', '', '2014-06-17 09:56:07'),
(119, 0, 119, 0, 0, '', '0000-00-00', '', '2014-06-17 09:56:40'),
(120, 0, 120, 0, 0, '', '0000-00-00', '', '2014-06-17 09:57:08'),
(121, 0, 121, 0, 0, '', '0000-00-00', '', '2014-06-17 09:57:50'),
(122, 0, 122, 0, 0, '', '0000-00-00', '', '2014-06-17 09:58:22'),
(123, 0, 123, 0, 0, '', '0000-00-00', '', '2014-06-17 10:17:18'),
(124, 0, 124, 0, 0, '', '0000-00-00', '', '2014-06-17 10:17:48'),
(125, 0, 125, 0, 0, '', '0000-00-00', '', '2014-06-17 10:18:28'),
(126, 0, 126, 0, 0, '', '0000-00-00', '', '2014-06-17 10:18:54'),
(127, 0, 127, 0, 0, '', '0000-00-00', '', '2014-06-17 10:20:28'),
(128, 0, 128, 0, 0, '', '0000-00-00', '', '2014-06-17 10:21:10'),
(129, 0, 129, 0, 0, '', '0000-00-00', '', '2014-06-17 10:21:43'),
(130, 0, 130, 0, 0, '', '0000-00-00', '', '2014-06-17 10:22:15'),
(131, 0, 131, 0, 0, '', '0000-00-00', '', '2014-06-17 10:23:16'),
(132, 0, 132, 0, 0, '', '0000-00-00', '', '2014-06-17 10:24:02'),
(133, 0, 133, 0, 0, '', '0000-00-00', '', '2014-06-17 10:24:52'),
(134, 0, 134, 0, 0, '', '0000-00-00', '', '2014-06-17 10:25:28'),
(135, 0, 135, 0, 0, '', '0000-00-00', '', '2014-06-17 10:26:02'),
(136, 0, 136, 0, 0, '', '0000-00-00', '', '2014-06-17 10:26:36'),
(137, 0, 137, 0, 0, '', '0000-00-00', '', '2014-06-17 10:27:10'),
(138, 0, 138, 0, 0, '', '0000-00-00', '', '2014-06-17 10:27:47'),
(139, 0, 139, 0, 0, '', '0000-00-00', '', '2014-06-17 10:28:55'),
(140, 0, 140, 0, 0, '', '0000-00-00', '', '2014-06-17 10:29:36'),
(141, 0, 141, 0, 0, '', '0000-00-00', '', '2014-06-17 10:30:04'),
(142, 0, 142, 0, 0, '', '0000-00-00', '', '2014-06-17 10:30:34'),
(143, 0, 143, 0, 0, '', '0000-00-00', '', '2014-06-17 10:31:01'),
(144, 0, 144, 0, 0, '', '0000-00-00', '', '2014-06-17 10:32:07'),
(145, 0, 145, 0, 0, '', '0000-00-00', '', '2014-06-17 10:32:51'),
(146, 0, 146, 0, 0, '', '0000-00-00', '', '2014-06-17 10:33:41'),
(147, 0, 147, 0, 0, '', '0000-00-00', '', '2014-06-17 10:34:43'),
(148, 0, 148, 0, 0, '', '0000-00-00', '', '2014-06-17 10:35:10'),
(149, 0, 149, 0, 0, '', '0000-00-00', '', '2014-06-17 10:35:49'),
(150, 0, 150, 0, 0, '', '0000-00-00', '', '2014-06-17 10:36:33'),
(151, 0, 151, 0, 0, '', '0000-00-00', '', '2014-06-17 10:37:08'),
(152, 0, 152, 0, 0, '', '0000-00-00', '', '2014-06-17 10:37:45'),
(153, 0, 153, 0, 0, '', '0000-00-00', '', '2014-06-17 10:38:13'),
(154, 0, 154, 0, 0, '', '0000-00-00', '', '2014-06-17 10:38:51'),
(155, 0, 155, 0, 0, '', '0000-00-00', '', '2014-06-17 10:39:30'),
(156, 0, 156, 0, 0, '', '0000-00-00', '', '2014-06-17 10:39:53'),
(157, 0, 157, 0, 0, '', '0000-00-00', '', '2014-06-17 10:40:23'),
(158, 0, 158, 0, 0, '', '0000-00-00', '', '2014-06-17 10:42:17'),
(159, 0, 159, 0, 0, '', '0000-00-00', '', '2014-06-17 10:43:06'),
(160, 0, 160, 0, 0, '', '0000-00-00', '', '2014-06-17 10:44:45'),
(161, 0, 161, 0, 0, '', '0000-00-00', '', '2014-06-17 10:45:32'),
(162, 0, 162, 0, 0, '', '0000-00-00', '', '2014-06-17 10:46:13'),
(163, 0, 163, 0, 0, '', '0000-00-00', '', '2014-06-17 10:52:55'),
(164, 0, 164, 0, 0, '', '0000-00-00', '', '2014-06-17 10:53:36'),
(165, 0, 165, 0, 0, '', '0000-00-00', '', '2014-06-17 10:54:31'),
(166, 0, 166, 0, 0, '', '0000-00-00', '', '2014-06-17 10:55:10'),
(167, 0, 167, 0, 0, '', '0000-00-00', '', '2014-06-17 10:55:49'),
(168, 0, 168, 0, 0, '', '0000-00-00', '', '2014-06-17 10:56:37'),
(169, 0, 169, 0, 0, '', '0000-00-00', '', '2014-06-17 10:57:09'),
(170, 0, 170, 0, 0, '', '0000-00-00', '', '2014-06-17 10:57:49'),
(171, 0, 171, 0, 0, '', '0000-00-00', '', '2014-06-17 10:59:19'),
(172, 0, 172, 0, 0, '', '0000-00-00', '', '2014-06-17 11:09:28'),
(173, 0, 173, 0, 0, '', '0000-00-00', '', '2014-06-17 11:10:35'),
(174, 0, 174, 0, 0, '', '0000-00-00', '', '2014-06-17 11:11:13'),
(175, 0, 175, 0, 0, '', '0000-00-00', '', '2014-06-17 11:11:46'),
(176, 0, 176, 0, 0, '', '0000-00-00', '', '2014-06-17 11:12:16'),
(177, 0, 177, 0, 0, '', '0000-00-00', '', '2014-06-17 11:12:48'),
(178, 0, 178, 0, 0, '', '0000-00-00', '', '2014-06-17 11:13:20'),
(179, 0, 179, 0, 0, '', '0000-00-00', '', '2014-06-17 11:14:04'),
(180, 0, 180, 0, 0, '', '0000-00-00', '', '2014-06-17 11:14:34'),
(181, 0, 181, 0, 0, '', '0000-00-00', '', '2014-06-17 11:15:13'),
(182, 0, 182, 0, 0, '', '0000-00-00', '', '2014-06-17 11:15:38'),
(183, 0, 183, 0, 0, '', '0000-00-00', '', '2014-06-17 11:16:54'),
(184, 0, 184, 0, 0, '', '0000-00-00', '', '2014-06-17 11:17:35'),
(185, 0, 185, 0, 0, '', '0000-00-00', '', '2014-06-17 11:18:05'),
(186, 0, 186, 0, 0, '', '0000-00-00', '', '2014-06-17 11:18:44'),
(187, 0, 187, 0, 0, '', '0000-00-00', '', '2014-06-17 11:19:41'),
(188, 0, 188, 0, 0, '', '0000-00-00', '', '2014-06-17 11:20:28'),
(189, 0, 189, 0, 0, '', '0000-00-00', '', '2014-06-17 11:20:58'),
(190, 0, 190, 0, 0, '', '0000-00-00', '', '2014-06-17 11:21:29'),
(191, 0, 191, 0, 0, '', '0000-00-00', '', '2014-06-17 11:22:08'),
(192, 0, 192, 0, 0, '', '0000-00-00', '', '2014-06-17 11:22:39'),
(193, 0, 193, 0, 0, '', '0000-00-00', '', '2014-06-17 11:23:17'),
(194, 0, 194, 0, 0, '', '0000-00-00', '', '2014-06-17 11:23:53'),
(195, 0, 195, 0, 0, '', '0000-00-00', '', '2014-06-17 11:24:31'),
(196, 0, 196, 0, 0, '', '0000-00-00', '', '2014-06-17 11:24:58'),
(197, 0, 197, 0, 0, '', '0000-00-00', '', '2014-06-17 11:25:29'),
(198, 0, 198, 0, 0, '', '0000-00-00', '', '2014-06-17 11:25:54'),
(199, 0, 199, 0, 0, '', '0000-00-00', '', '2014-06-17 11:26:18'),
(200, 0, 200, 0, 0, '', '0000-00-00', '', '2014-06-17 11:26:50'),
(201, 0, 201, 0, 0, '', '0000-00-00', '', '2014-06-17 11:27:31'),
(202, 0, 202, 0, 0, '', '0000-00-00', '', '2014-06-17 11:28:07'),
(203, 0, 203, 0, 0, '', '0000-00-00', '', '2014-06-17 11:29:36'),
(204, 0, 204, 0, 0, '', '0000-00-00', '', '2014-06-17 11:30:33'),
(205, 0, 205, 0, 0, '', '0000-00-00', '', '2014-06-17 11:33:39'),
(206, 0, 206, 0, 0, '', '0000-00-00', '', '2014-06-17 11:34:19'),
(207, 0, 207, 0, 0, '', '0000-00-00', '', '2014-06-17 11:36:39'),
(208, 0, 208, 0, 0, '', '0000-00-00', '', '2014-06-17 11:37:39'),
(209, 0, 209, 0, 0, '', '0000-00-00', '', '2014-06-17 11:46:34'),
(210, 0, 210, 0, 0, '', '0000-00-00', '', '2014-06-17 11:47:37'),
(211, 0, 211, 0, 0, '', '0000-00-00', '', '2014-06-17 11:50:32'),
(212, 0, 212, 0, 0, '', '0000-00-00', '', '2014-06-17 11:51:25'),
(213, 0, 213, 0, 0, '', '0000-00-00', '', '2014-06-17 11:52:30'),
(214, 0, 214, 0, 0, '', '0000-00-00', '', '2014-06-17 11:53:14'),
(215, 0, 215, 0, 0, '', '0000-00-00', '', '2014-06-17 11:54:48'),
(216, 0, 216, 0, 0, '', '0000-00-00', '', '2014-06-17 11:55:22'),
(217, 0, 217, 0, 0, '', '0000-00-00', '', '2014-06-17 11:56:03'),
(218, 0, 218, 0, 0, '', '0000-00-00', '', '2014-06-17 11:56:37'),
(219, 0, 219, 0, 0, '', '0000-00-00', '', '2014-06-17 11:57:18'),
(220, 0, 220, 0, 0, '', '0000-00-00', '', '2014-06-17 11:57:49'),
(221, 0, 221, 0, 0, '', '0000-00-00', '', '2014-06-17 11:58:16'),
(222, 0, 222, 0, 0, '', '0000-00-00', '', '2014-06-17 11:59:01'),
(223, 0, 223, 0, 0, '', '0000-00-00', '', '2014-06-17 11:59:39'),
(224, 0, 224, 0, 0, '', '0000-00-00', '', '2014-06-17 12:00:26'),
(225, 0, 225, 0, 0, '', '0000-00-00', '', '2014-06-17 12:01:04'),
(226, 0, 226, 0, 0, '', '0000-00-00', '', '2014-06-17 12:02:11'),
(227, 0, 227, 0, 0, '', '0000-00-00', '', '2014-06-17 12:10:04'),
(228, 0, 228, 0, 0, '', '0000-00-00', '', '2014-06-17 12:10:46'),
(229, 0, 229, 0, 0, '', '0000-00-00', '', '2014-06-17 12:11:29'),
(230, 0, 230, 0, 0, '', '0000-00-00', '', '2014-06-17 12:12:02'),
(231, 0, 231, 0, 0, '', '0000-00-00', '', '2014-06-17 12:12:38'),
(232, 0, 232, 0, 0, '', '0000-00-00', '', '2014-06-17 12:13:10'),
(233, 0, 233, 0, 0, '', '0000-00-00', '', '2014-06-17 12:13:59'),
(234, 0, 234, 0, 0, '', '0000-00-00', '', '2014-06-17 12:14:34'),
(235, 0, 235, 0, 0, '', '0000-00-00', '', '2014-06-17 12:15:22'),
(236, 0, 236, 0, 0, '', '0000-00-00', '', '2014-06-17 12:15:53'),
(237, 0, 237, 0, 0, '', '0000-00-00', '', '2014-06-17 12:16:31'),
(238, 0, 238, 0, 0, '', '0000-00-00', '', '2014-06-17 12:16:59'),
(239, 0, 239, 0, 0, '', '0000-00-00', '', '2014-06-17 12:17:22'),
(240, 0, 240, 0, 0, '', '0000-00-00', '', '2014-06-17 12:17:48'),
(241, 0, 241, 0, 0, '', '0000-00-00', '', '2014-06-17 12:18:27'),
(242, 0, 242, 0, 0, '', '0000-00-00', '', '2014-06-17 12:18:57'),
(243, 0, 243, 0, 0, '', '0000-00-00', '', '2014-06-17 12:21:24'),
(244, 0, 244, 0, 0, '', '0000-00-00', '', '2014-06-17 12:21:56'),
(245, 0, 245, 0, 0, '', '0000-00-00', '', '2014-06-17 12:22:23'),
(246, 0, 246, 0, 0, '', '0000-00-00', '', '2014-06-17 12:22:48'),
(247, 0, 247, 0, 0, '', '0000-00-00', '', '2014-06-17 12:23:22'),
(248, 0, 248, 0, 0, '', '0000-00-00', '', '2014-06-17 12:23:48'),
(249, 0, 249, 0, 0, '', '0000-00-00', '', '2014-06-17 12:24:23'),
(250, 0, 250, 0, 0, '', '0000-00-00', '', '2014-06-17 12:24:56'),
(251, 0, 251, 0, 0, '', '0000-00-00', '', '2014-06-17 12:25:32'),
(252, 0, 252, 0, 0, '', '0000-00-00', '', '2014-06-17 12:26:05'),
(253, 0, 253, 0, 0, '', '0000-00-00', '', '2014-06-17 12:26:30'),
(254, 0, 254, 0, 0, '', '0000-00-00', '', '2014-06-17 12:26:57'),
(255, 0, 255, 0, 0, '', '0000-00-00', '', '2014-06-17 12:27:29'),
(256, 0, 256, 0, 0, '', '0000-00-00', '', '2014-06-17 12:28:00'),
(257, 0, 257, 0, 0, '', '0000-00-00', '', '2014-06-17 12:28:42'),
(258, 0, 258, 0, 0, '', '0000-00-00', '', '2014-06-17 12:29:06'),
(259, 0, 259, 0, 0, '', '0000-00-00', '', '2014-06-17 12:29:42'),
(260, 0, 260, 0, 0, '', '0000-00-00', '', '2014-06-17 12:30:16'),
(261, 0, 261, 0, 0, '', '0000-00-00', '', '2014-06-17 12:30:59'),
(262, 0, 262, 0, 0, '', '0000-00-00', '', '2014-06-17 12:31:33'),
(263, 0, 263, 0, 0, '', '0000-00-00', '', '2014-06-17 12:32:03'),
(264, 0, 264, 0, 0, '', '0000-00-00', '', '2014-06-17 12:32:33'),
(265, 0, 265, 0, 0, '', '0000-00-00', '', '2014-06-17 12:33:10'),
(266, 0, 266, 0, 0, '', '0000-00-00', '', '2014-06-17 12:33:45'),
(267, 0, 267, 0, 0, '', '0000-00-00', '', '2014-06-17 12:34:24'),
(268, 0, 268, 0, 0, '', '0000-00-00', '', '2014-06-17 12:34:54'),
(269, 0, 269, 0, 0, '', '0000-00-00', '', '2014-06-17 12:35:22'),
(270, 0, 270, 0, 0, '', '0000-00-00', '', '2014-06-17 12:35:48'),
(271, 0, 271, 0, 0, '', '0000-00-00', '', '2014-06-17 12:36:22'),
(272, 0, 272, 0, 0, '', '0000-00-00', '', '2014-06-17 12:36:58'),
(273, 0, 273, 0, 0, '', '0000-00-00', '', '2014-06-17 12:37:23'),
(274, 0, 274, 0, 0, '', '0000-00-00', '', '2014-06-17 12:37:59'),
(275, 0, 275, 0, 0, '', '0000-00-00', '', '2014-06-17 12:39:12'),
(276, 0, 276, 0, 0, '', '0000-00-00', '', '2014-06-17 12:39:43'),
(277, 0, 277, 0, 0, '', '0000-00-00', '', '2014-06-17 12:40:14'),
(278, 0, 278, 0, 0, '', '0000-00-00', '', '2014-06-17 12:41:13'),
(279, 0, 279, 0, 0, '', '0000-00-00', '', '2014-06-17 12:41:56'),
(280, 0, 280, 0, 0, '', '0000-00-00', '', '2014-06-17 12:42:27'),
(281, 0, 281, 0, 0, '', '0000-00-00', '', '2014-06-17 12:43:04'),
(282, 0, 282, 0, 0, '', '0000-00-00', '', '2014-06-17 12:43:33'),
(283, 0, 283, 0, 0, '', '0000-00-00', '', '2014-06-17 12:46:27'),
(284, 0, 284, 0, 0, '', '0000-00-00', '', '2014-06-17 12:46:52'),
(285, 0, 285, 0, 0, '', '0000-00-00', '', '2014-06-17 12:47:46'),
(286, 0, 286, 0, 0, '', '0000-00-00', '', '2014-06-17 12:48:12'),
(287, 0, 287, 0, 0, '', '0000-00-00', '', '2014-06-17 12:48:48'),
(288, 0, 288, 0, 0, '', '0000-00-00', '', '2014-06-17 12:49:15'),
(289, 0, 289, 0, 0, '', '0000-00-00', '', '2014-06-17 12:49:54'),
(290, 0, 290, 0, 0, '', '0000-00-00', '', '2014-06-17 12:50:28'),
(291, 0, 291, 0, 0, '', '0000-00-00', '', '2014-06-17 12:51:02'),
(292, 0, 292, 0, 0, '', '0000-00-00', '', '2014-06-17 12:51:34'),
(293, 0, 293, 0, 0, '', '0000-00-00', '', '2014-06-17 12:52:06'),
(294, 0, 294, 0, 0, '', '0000-00-00', '', '2014-06-17 12:52:40'),
(295, 0, 295, 0, 0, '', '0000-00-00', '', '2014-06-17 12:53:13'),
(296, 0, 296, 0, 0, '', '0000-00-00', '', '2014-06-17 12:53:44'),
(297, 0, 297, 0, 0, '', '0000-00-00', '', '2014-06-17 12:54:37'),
(298, 0, 298, 0, 0, '', '0000-00-00', '', '2014-06-17 12:55:10'),
(299, 0, 299, 0, 0, '', '0000-00-00', '', '2014-06-17 12:56:40'),
(300, 0, 300, 0, 0, '', '0000-00-00', '', '2014-06-17 12:57:13'),
(301, 0, 301, 0, 0, '', '0000-00-00', '', '2014-06-17 12:57:59'),
(302, 0, 302, 0, 0, '', '0000-00-00', '', '2014-06-17 12:58:37'),
(303, 0, 303, 0, 0, '', '0000-00-00', '', '2014-06-17 12:59:12'),
(304, 0, 304, 0, 0, '', '0000-00-00', '', '2014-06-17 12:59:52'),
(305, 0, 305, 0, 0, '', '0000-00-00', '', '2014-06-17 13:00:27'),
(306, 0, 306, 0, 0, '', '0000-00-00', '', '2014-06-17 13:01:08'),
(307, 0, 307, 0, 0, '', '0000-00-00', '', '2014-06-17 13:01:44'),
(308, 0, 308, 0, 0, '', '0000-00-00', '', '2014-06-17 13:03:05'),
(309, 0, 309, 0, 0, '', '0000-00-00', '', '2014-06-17 13:03:37'),
(310, 0, 310, 0, 0, '', '0000-00-00', '', '2014-06-17 13:04:11'),
(311, 0, 311, 0, 0, '', '0000-00-00', '', '2014-06-17 13:04:50'),
(312, 0, 312, 0, 0, '', '0000-00-00', '', '2014-06-17 13:05:41'),
(313, 0, 313, 0, 0, '', '0000-00-00', '', '2014-06-17 13:06:10'),
(314, 0, 314, 0, 0, '', '0000-00-00', '', '2014-06-17 13:06:36'),
(315, 0, 315, 0, 0, '', '0000-00-00', '', '2014-06-17 13:07:06'),
(316, 0, 316, 0, 0, '', '0000-00-00', '', '2014-06-17 13:07:49'),
(317, 0, 317, 0, 0, '', '0000-00-00', '', '2014-06-17 13:08:21'),
(318, 0, 318, 0, 0, '', '0000-00-00', '', '2014-06-17 13:09:02'),
(319, 0, 319, 0, 0, '', '0000-00-00', '', '2014-06-17 13:10:13'),
(320, 0, 320, 0, 0, '', '0000-00-00', '', '2014-06-17 13:10:50'),
(321, 0, 321, 0, 0, '', '0000-00-00', '', '2014-06-17 13:11:17'),
(322, 0, 322, 0, 0, '', '0000-00-00', '', '2014-06-17 13:11:59'),
(323, 0, 323, 0, 0, '', '0000-00-00', '', '2014-06-17 13:12:31'),
(324, 0, 324, 0, 0, '', '0000-00-00', '', '2014-06-17 16:42:24'),
(325, 0, 325, 0, 0, '', '0000-00-00', '', '2014-06-17 16:42:59'),
(326, 0, 326, 0, 0, '', '0000-00-00', '', '2014-06-17 16:43:40'),
(327, 0, 327, 0, 0, '', '0000-00-00', '', '2014-06-17 16:44:16'),
(328, 0, 328, 0, 0, '', '0000-00-00', '', '2014-06-17 16:44:55'),
(329, 0, 329, 0, 0, '', '0000-00-00', '', '2014-06-17 16:45:44'),
(330, 0, 330, 0, 0, '', '0000-00-00', '', '2014-06-17 16:46:20'),
(331, 0, 331, 0, 0, '', '0000-00-00', '', '2014-06-17 16:46:57'),
(332, 0, 332, 0, 0, '', '0000-00-00', '', '2014-06-17 16:47:33'),
(333, 0, 333, 0, 0, '', '0000-00-00', '', '2014-06-17 16:48:12'),
(334, 0, 334, 0, 0, '', '0000-00-00', '', '2014-06-17 16:49:56'),
(335, 0, 335, 0, 0, '', '0000-00-00', '', '2014-06-17 16:50:26'),
(336, 0, 336, 0, 0, '', '0000-00-00', '', '2014-06-17 16:50:56'),
(337, 0, 337, 0, 0, '', '0000-00-00', '', '2014-06-17 16:51:28'),
(338, 0, 338, 0, 0, '', '0000-00-00', '', '2014-06-17 16:52:00'),
(339, 0, 339, 0, 0, '', '0000-00-00', '', '2014-06-17 16:52:38'),
(340, 0, 340, 0, 0, '', '0000-00-00', '', '2014-06-17 16:53:08'),
(341, 0, 341, 0, 0, '', '0000-00-00', '', '2014-06-17 16:54:18'),
(342, 0, 342, 0, 0, '', '0000-00-00', '', '2014-06-17 16:54:49'),
(343, 0, 343, 0, 0, '', '0000-00-00', '', '2014-06-17 16:55:24'),
(344, 0, 344, 0, 0, '', '0000-00-00', '', '2014-06-17 17:01:54'),
(345, 0, 345, 0, 0, '', '0000-00-00', '', '2014-06-17 17:02:30'),
(346, 0, 346, 0, 0, '', '0000-00-00', '', '2014-06-17 17:03:09'),
(347, 0, 347, 0, 0, '', '0000-00-00', '', '2014-06-17 17:03:44'),
(348, 0, 348, 0, 0, '', '0000-00-00', '', '2014-06-17 17:04:18'),
(349, 0, 349, 0, 0, '', '0000-00-00', '', '2014-06-17 17:04:56'),
(350, 0, 350, 0, 0, '', '0000-00-00', '', '2014-06-17 17:05:34'),
(351, 0, 351, 0, 0, '', '0000-00-00', '', '2014-06-17 17:06:08'),
(352, 0, 352, 0, 0, '', '0000-00-00', '', '2014-06-17 17:06:50'),
(353, 0, 353, 0, 0, '', '0000-00-00', '', '2014-06-17 17:08:16'),
(354, 0, 354, 0, 0, '', '0000-00-00', '', '2014-06-17 17:11:14'),
(355, 0, 355, 0, 0, '', '0000-00-00', '', '2014-06-17 17:11:46'),
(356, 0, 356, 0, 0, '', '0000-00-00', '', '2014-06-17 17:12:23'),
(357, 0, 357, 0, 0, '', '0000-00-00', '', '2014-06-17 17:12:51'),
(358, 0, 358, 0, 0, '', '0000-00-00', '', '2014-06-17 17:13:22'),
(359, 0, 359, 0, 0, '', '0000-00-00', '', '2014-06-17 17:13:58'),
(360, 0, 360, 0, 0, '', '0000-00-00', '', '2014-06-17 17:14:36'),
(361, 0, 361, 0, 0, '', '0000-00-00', '', '2014-06-17 17:15:12'),
(362, 0, 362, 0, 0, '', '0000-00-00', '', '2014-06-17 17:15:45'),
(363, 0, 363, 0, 0, '', '0000-00-00', '', '2014-06-17 17:16:17'),
(364, 0, 364, 0, 0, '', '0000-00-00', '', '2014-06-17 17:22:04'),
(365, 0, 365, 0, 0, '', '0000-00-00', '', '2014-06-17 17:22:36'),
(366, 0, 366, 0, 0, '', '0000-00-00', '', '2014-06-17 17:23:13'),
(367, 0, 367, 0, 0, '', '0000-00-00', '', '2014-06-17 17:23:51'),
(368, 0, 368, 0, 0, '', '0000-00-00', '', '2014-06-17 17:24:26'),
(369, 0, 369, 0, 0, '', '0000-00-00', '', '2014-06-17 17:24:58'),
(370, 0, 370, 0, 0, '', '0000-00-00', '', '2014-06-17 17:25:37'),
(371, 0, 371, 0, 0, '', '0000-00-00', '', '2014-06-17 17:26:12'),
(372, 0, 372, 0, 0, '', '0000-00-00', '', '2014-06-17 17:26:48'),
(373, 0, 373, 0, 0, '', '0000-00-00', '', '2014-06-17 17:27:23'),
(374, 0, 374, 0, 0, '', '0000-00-00', '', '2014-06-17 17:29:30'),
(375, 0, 375, 0, 0, '', '0000-00-00', '', '2014-06-17 17:29:58'),
(376, 0, 376, 0, 0, '', '0000-00-00', '', '2014-06-17 17:30:45'),
(377, 0, 377, 0, 0, '', '0000-00-00', '', '2014-06-17 17:31:18'),
(378, 0, 378, 0, 0, '', '0000-00-00', '', '2014-06-17 17:31:47'),
(379, 0, 379, 0, 0, '', '0000-00-00', '', '2014-06-17 17:32:15'),
(380, 0, 380, 0, 0, '', '0000-00-00', '', '2014-06-17 17:32:45'),
(381, 0, 381, 0, 0, '', '0000-00-00', '', '2014-06-17 17:33:15'),
(382, 0, 382, 0, 0, '', '0000-00-00', '', '2014-06-17 17:33:45'),
(383, 0, 383, 0, 0, '', '0000-00-00', '', '2014-06-17 17:34:13'),
(384, 0, 384, 0, 0, '', '0000-00-00', '', '2014-06-17 17:43:47'),
(385, 0, 385, 0, 0, '', '0000-00-00', '', '2014-06-17 17:44:22'),
(386, 0, 386, 0, 0, '', '0000-00-00', '', '2014-06-17 17:44:54'),
(387, 0, 387, 0, 0, '', '0000-00-00', '', '2014-06-17 17:47:43'),
(388, 0, 388, 0, 0, '', '0000-00-00', '', '2014-06-17 17:51:13'),
(389, 0, 389, 0, 0, '', '0000-00-00', '', '2014-06-17 17:51:45'),
(390, 0, 390, 0, 0, '', '0000-00-00', '', '2014-06-17 17:52:33'),
(391, 0, 391, 0, 0, '', '0000-00-00', '', '2014-06-17 17:53:07'),
(392, 0, 392, 0, 0, '', '0000-00-00', '', '2014-06-17 17:53:39'),
(393, 0, 393, 0, 0, '', '0000-00-00', '', '2014-06-17 17:54:11'),
(394, 0, 394, 0, 0, '', '0000-00-00', '', '2014-06-17 18:04:15'),
(395, 0, 395, 0, 0, '', '0000-00-00', '', '2014-06-17 18:04:43'),
(396, 0, 396, 0, 0, '', '0000-00-00', '', '2014-06-17 18:05:11'),
(397, 0, 397, 0, 0, '', '0000-00-00', '', '2014-06-17 18:08:01'),
(398, 0, 398, 0, 0, '', '0000-00-00', '', '2014-06-17 18:12:53'),
(399, 0, 399, 0, 0, '', '0000-00-00', '', '2014-06-17 18:13:26'),
(400, 0, 400, 0, 0, '', '0000-00-00', '', '2014-06-17 18:13:56'),
(401, 0, 401, 0, 0, '', '0000-00-00', '', '2014-06-17 18:14:26'),
(402, 0, 402, 0, 0, '', '0000-00-00', '', '2014-06-17 18:15:00'),
(403, 0, 403, 0, 0, '', '0000-00-00', '', '2014-06-17 18:15:32'),
(404, 0, 404, 0, 0, '', '0000-00-00', '', '2014-06-20 12:57:00'),
(405, 0, 405, 0, 0, '', '0000-00-00', '', '2014-06-20 12:57:38'),
(406, 0, 406, 0, 0, '', '0000-00-00', '', '2014-06-20 12:58:21'),
(407, 0, 407, 0, 0, '', '0000-00-00', '', '2014-06-20 12:58:58'),
(408, 0, 408, 0, 0, '', '0000-00-00', '', '2014-06-20 12:59:55'),
(409, 0, 409, 0, 0, '', '0000-00-00', '', '2014-06-20 13:00:43'),
(410, 0, 410, 0, 0, '', '0000-00-00', '', '2014-06-20 13:01:31'),
(411, 0, 411, 0, 0, '', '0000-00-00', '', '2014-06-20 13:02:39'),
(412, 0, 412, 0, 0, '', '0000-00-00', '', '2014-06-20 13:03:27'),
(413, 0, 413, 0, 0, '', '0000-00-00', '', '2014-06-20 13:04:15'),
(414, 0, 414, 0, 0, '', '0000-00-00', '', '2014-06-26 03:20:13'),
(415, 0, 415, 0, 0, '', '0000-00-00', '', '2014-06-26 03:20:45'),
(416, 0, 416, 0, 0, '', '0000-00-00', '', '2014-06-26 03:21:17'),
(417, 0, 417, 0, 0, '', '0000-00-00', '', '2014-06-26 03:21:53'),
(418, 0, 418, 0, 0, '', '0000-00-00', '', '2014-06-26 03:22:22'),
(419, 0, 419, 0, 0, '', '0000-00-00', '', '2014-06-26 03:22:58'),
(420, 0, 420, 0, 0, '', '0000-00-00', '', '2014-06-26 03:23:22'),
(421, 0, 421, 0, 0, '', '0000-00-00', '', '2014-06-26 03:23:54'),
(422, 0, 422, 0, 0, '', '0000-00-00', '', '2014-06-26 03:24:28'),
(423, 0, 423, 0, 0, '', '0000-00-00', '', '2014-06-26 03:25:01'),
(424, 0, 424, 0, 0, '', '0000-00-00', '', '2014-06-26 03:25:26'),
(425, 0, 425, 0, 0, '', '0000-00-00', '', '2014-06-26 03:25:59'),
(426, 0, 426, 0, 0, '', '0000-00-00', '', '2014-06-26 03:26:43'),
(427, 0, 427, 0, 0, '', '0000-00-00', '', '2014-06-26 03:27:14'),
(428, 0, 428, 0, 0, '', '0000-00-00', '', '2014-06-26 03:27:57'),
(429, 0, 429, 0, 0, '', '0000-00-00', '', '2014-06-26 03:28:37'),
(430, 0, 430, 0, 0, '', '0000-00-00', '', '2014-06-26 03:30:59'),
(431, 0, 431, 0, 0, '', '0000-00-00', '', '2014-06-26 03:31:49'),
(432, 0, 432, 0, 0, '', '0000-00-00', '', '2014-06-26 03:32:16'),
(433, 0, 433, 0, 0, '', '0000-00-00', '', '2014-06-26 03:33:14'),
(434, 0, 434, 0, 0, '', '0000-00-00', '', '2014-06-26 03:33:47'),
(435, 0, 435, 0, 0, '', '0000-00-00', '', '2014-06-26 03:34:33'),
(436, 0, 436, 0, 0, '', '0000-00-00', '', '2014-06-26 03:35:13'),
(437, 0, 437, 0, 0, '', '0000-00-00', '', '2014-06-26 03:35:50'),
(438, 0, 438, 0, 0, '', '0000-00-00', '', '2014-06-26 03:36:56'),
(439, 0, 439, 0, 0, '', '0000-00-00', '', '2014-06-26 03:37:22'),
(440, 0, 440, 0, 0, '', '0000-00-00', '', '2014-06-26 03:38:17'),
(441, 0, 441, 0, 0, '', '0000-00-00', '', '2014-06-26 03:38:41'),
(442, 0, 442, 0, 0, '', '0000-00-00', '', '2014-06-26 03:39:27'),
(443, 0, 443, 0, 0, '', '0000-00-00', '', '2014-06-26 03:40:23'),
(444, 0, 444, 0, 0, '', '0000-00-00', '', '2014-06-26 03:40:53'),
(445, 0, 445, 0, 0, '', '0000-00-00', '', '2014-06-26 03:42:08'),
(446, 0, 446, 0, 0, '', '0000-00-00', '', '2014-06-26 03:42:56'),
(447, 0, 447, 0, 0, '', '0000-00-00', '', '2014-06-26 03:43:52'),
(448, 0, 448, 0, 0, '', '0000-00-00', '', '2014-06-26 03:44:26'),
(449, 0, 449, 0, 0, '', '0000-00-00', '', '2014-06-26 03:45:07'),
(450, 0, 450, 0, 0, '', '0000-00-00', '', '2014-06-26 03:46:06'),
(451, 0, 451, 0, 0, '', '0000-00-00', '', '2014-06-26 03:47:06'),
(452, 0, 452, 0, 0, '', '0000-00-00', '', '2014-06-26 03:47:52'),
(453, 0, 453, 0, 0, '', '0000-00-00', '', '2014-06-26 03:49:08'),
(454, 0, 454, 0, 0, '', '0000-00-00', '', '2014-06-26 04:05:10'),
(455, 0, 455, 0, 0, '', '0000-00-00', '', '2014-06-26 04:05:48'),
(456, 0, 456, 0, 0, '', '0000-00-00', '', '2014-06-26 04:07:14'),
(457, 0, 457, 0, 0, '', '0000-00-00', '', '2014-06-26 04:07:43'),
(458, 0, 458, 0, 0, '', '0000-00-00', '', '2014-06-26 04:08:22'),
(459, 0, 459, 0, 0, '', '0000-00-00', '', '2014-06-26 04:08:51'),
(460, 0, 460, 0, 0, '', '0000-00-00', '', '2014-06-26 04:09:25'),
(461, 0, 461, 0, 0, '', '0000-00-00', '', '2014-06-26 04:09:59'),
(462, 0, 462, 0, 0, '', '0000-00-00', '', '2014-06-26 04:10:33'),
(463, 0, 463, 0, 0, '', '0000-00-00', '', '2014-06-26 04:11:18'),
(464, 0, 464, 0, 0, '', '0000-00-00', '', '2014-06-26 04:17:15'),
(465, 0, 465, 0, 0, '', '0000-00-00', '', '2014-06-26 04:17:42'),
(466, 0, 466, 0, 0, '', '0000-00-00', '', '2014-06-26 04:18:20'),
(467, 0, 467, 0, 0, '', '0000-00-00', '', '2014-06-26 04:18:51'),
(468, 0, 468, 0, 0, '', '0000-00-00', '', '2014-06-26 04:19:19'),
(469, 0, 469, 0, 0, '', '0000-00-00', '', '2014-06-26 04:19:54'),
(470, 0, 470, 0, 0, '', '0000-00-00', '', '2014-06-26 04:20:20'),
(471, 0, 471, 0, 0, '', '0000-00-00', '', '2014-06-26 04:20:51'),
(472, 0, 472, 0, 0, '', '0000-00-00', '', '2014-06-26 04:21:31'),
(473, 0, 473, 0, 0, '', '0000-00-00', '', '2014-06-26 04:21:58'),
(474, 0, 474, 0, 0, '', '0000-00-00', '', '2014-06-26 04:22:25'),
(475, 0, 475, 0, 0, '', '0000-00-00', '', '2014-06-26 04:22:58'),
(476, 0, 476, 0, 0, '', '0000-00-00', '', '2014-06-26 04:23:41'),
(477, 0, 477, 0, 0, '', '0000-00-00', '', '2014-06-26 04:24:14'),
(478, 0, 478, 0, 0, '', '0000-00-00', '', '2014-06-26 04:25:00'),
(479, 0, 479, 0, 0, '', '0000-00-00', '', '2014-06-26 04:25:45'),
(480, 0, 480, 0, 0, '', '0000-00-00', '', '2014-06-26 04:26:22'),
(481, 0, 481, 0, 0, '', '0000-00-00', '', '2014-06-26 04:26:56'),
(482, 0, 482, 0, 0, '', '0000-00-00', '', '2014-06-26 04:27:34'),
(483, 0, 483, 0, 0, '', '0000-00-00', '', '2014-06-26 04:28:22'),
(484, 0, 484, 0, 0, '', '0000-00-00', '', '2014-06-26 04:28:54'),
(485, 0, 485, 0, 0, '', '0000-00-00', '', '2014-06-26 04:29:28'),
(486, 0, 486, 0, 0, '', '0000-00-00', '', '2014-06-26 04:29:56'),
(487, 0, 487, 0, 0, '', '0000-00-00', '', '2014-06-26 04:30:28'),
(488, 0, 488, 0, 0, '', '0000-00-00', '', '2014-06-26 04:31:27'),
(489, 0, 489, 0, 0, '', '0000-00-00', '', '2014-06-26 04:31:53'),
(490, 0, 490, 0, 0, '', '0000-00-00', '', '2014-06-26 04:32:20'),
(491, 0, 491, 0, 0, '', '0000-00-00', '', '2014-06-26 04:32:43'),
(492, 0, 492, 0, 0, '', '0000-00-00', '', '2014-06-26 04:33:45'),
(493, 0, 493, 0, 0, '', '0000-00-00', '', '2014-06-26 04:34:14'),
(494, 0, 494, 0, 0, '', '0000-00-00', '', '2014-06-26 04:34:44'),
(495, 0, 495, 0, 0, '', '0000-00-00', '', '2014-06-26 04:35:44'),
(496, 0, 496, 0, 0, '', '0000-00-00', '', '2014-06-26 04:41:18'),
(497, 0, 497, 0, 0, '', '0000-00-00', '', '2014-06-26 04:41:47'),
(498, 0, 498, 0, 0, '', '0000-00-00', '', '2014-06-26 04:42:50'),
(499, 0, 499, 0, 0, '', '0000-00-00', '', '2014-06-26 04:50:09'),
(500, 0, 500, 0, 0, '', '0000-00-00', '', '2014-06-26 04:50:48'),
(501, 0, 501, 0, 0, '', '0000-00-00', '', '2014-06-26 04:51:25'),
(502, 0, 502, 0, 0, '', '0000-00-00', '', '2014-06-26 04:52:19'),
(503, 0, 503, 0, 0, '', '0000-00-00', '', '2014-06-26 04:52:59'),
(504, 0, 504, 0, 0, '', '0000-00-00', '', '2014-06-26 04:55:19'),
(505, 0, 505, 0, 0, '', '0000-00-00', '', '2014-06-26 04:55:54'),
(506, 0, 506, 0, 0, '', '0000-00-00', '', '2014-06-26 04:56:26'),
(507, 0, 507, 0, 0, '', '0000-00-00', '', '2014-06-26 04:56:56'),
(508, 0, 508, 0, 0, '', '0000-00-00', '', '2014-06-26 04:57:25'),
(509, 0, 509, 0, 0, '', '0000-00-00', '', '2014-06-26 04:57:55'),
(510, 0, 510, 0, 0, '', '0000-00-00', '', '2014-06-26 04:58:21'),
(511, 0, 511, 0, 0, '', '0000-00-00', '', '2014-06-26 04:59:02'),
(512, 0, 512, 0, 0, '', '0000-00-00', '', '2014-06-26 04:59:34'),
(513, 0, 513, 0, 0, '', '0000-00-00', '', '2014-06-26 05:00:05'),
(514, 0, 514, 0, 0, '', '0000-00-00', '', '2014-07-30 05:17:08'),
(515, 0, 515, 0, 0, '', '0000-00-00', '', '2014-07-30 05:19:43');

-- --------------------------------------------------------

--
-- Table structure for table `skl_prepaid_coupon`
--

CREATE TABLE `skl_prepaid_coupon` (
  `id` int(100) NOT NULL,
  `prepaid_name` varchar(100) NOT NULL,
  `prepaid_code` varchar(100) NOT NULL,
  `plan_id` int(100) NOT NULL,
  `timecreated` int(100) NOT NULL,
  `expirytime` int(100) NOT NULL,
  `used` int(5) NOT NULL DEFAULT '0',
  `userid` int(100) NOT NULL,
  `timeenrolled` int(100) NOT NULL,
  `createdby` varchar(100) NOT NULL,
  `creation_date` date NOT NULL,
  `modifiedby` varchar(100) NOT NULL,
  `modified_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `skl_prepaid_coupon`
--

INSERT INTO `skl_prepaid_coupon` (`id`, `prepaid_name`, `prepaid_code`, `plan_id`, `timecreated`, `expirytime`, `used`, `userid`, `timeenrolled`, `createdby`, `creation_date`, `modifiedby`, `modified_date`) VALUES
(1, '', '62168145352', 52, 1400415621, 1398882600, 0, 0, 0, '', '0000-00-00', '', '2014-05-18 06:50:21'),
(2, '', '63579785352', 52, 1400415621, 1398882600, 0, 0, 0, '', '0000-00-00', '', '2014-05-18 06:50:21'),
(3, '', '68148375352', 52, 1400415621, 1398882600, 0, 0, 0, '', '0000-00-00', '', '2014-05-18 06:50:21'),
(4, '', '75349695352', 52, 1400415621, 1398882600, 0, 0, 0, '', '0000-00-00', '', '2014-05-18 06:50:21'),
(5, '', '81925175352', 52, 1400415621, 1398882600, 0, 0, 0, '', '0000-00-00', '', '2014-05-18 06:50:21'),
(6, '', '17813485352', 52, 1400415621, 1398882600, 0, 0, 0, '', '0000-00-00', '', '2014-05-18 06:50:21'),
(7, '', '48575475352', 52, 1400415621, 1398882600, 0, 0, 0, '', '0000-00-00', '', '2014-05-18 06:50:21'),
(8, '', '12952595352', 52, 1400415621, 1398882600, 0, 0, 0, '', '0000-00-00', '', '2014-05-18 06:50:21'),
(9, '', '38638545352', 52, 1400415621, 1398882600, 0, 0, 0, '', '0000-00-00', '', '2014-05-18 06:50:21'),
(10, '', '15738965352', 52, 1400415621, 1398882600, 0, 0, 0, '', '0000-00-00', '', '2014-05-18 06:50:21'),
(11, '', '39321965352', 52, 1400415621, 1398882600, 0, 0, 0, '', '0000-00-00', '', '2014-05-18 06:50:21'),
(12, '', '95387545352', 52, 1400415621, 1398882600, 0, 0, 0, '', '0000-00-00', '', '2014-05-18 06:50:21'),
(13, '', '42971255352', 52, 1400415621, 1398882600, 0, 0, 0, '', '0000-00-00', '', '2014-05-18 06:50:21'),
(14, '', '91253725352', 52, 1400415621, 1398882600, 0, 0, 0, '', '0000-00-00', '', '2014-05-18 06:50:21'),
(15, '', '67231615352', 52, 1400415621, 1398882600, 0, 0, 0, '', '0000-00-00', '', '2014-05-18 06:50:21'),
(16, '', '15852635352', 52, 1400415621, 1398882600, 0, 0, 0, '', '0000-00-00', '', '2014-05-18 06:50:21'),
(17, '', '95674745352', 52, 1400415621, 1398882600, 0, 0, 0, '', '0000-00-00', '', '2014-05-18 06:50:21'),
(18, '', '29645745352', 52, 1400415621, 1398882600, 0, 0, 0, '', '0000-00-00', '', '2014-05-18 06:50:21'),
(19, '', '54159795352', 52, 1400415621, 1398882600, 0, 0, 0, '', '0000-00-00', '', '2014-05-18 06:50:21'),
(20, '', '83652835352', 52, 1400415621, 1398882600, 0, 0, 0, '', '0000-00-00', '', '2014-05-18 06:50:21'),
(21, '', '24259385352', 52, 1400415621, 1398882600, 0, 0, 0, '', '0000-00-00', '', '2014-05-18 06:50:21'),
(22, '', '72917975352', 52, 1400415621, 1398882600, 0, 0, 0, '', '0000-00-00', '', '2014-05-18 06:50:21'),
(23, '', '58616935352', 52, 1400415621, 1398882600, 0, 0, 0, '', '0000-00-00', '', '2014-05-18 06:50:21');

-- --------------------------------------------------------

--
-- Table structure for table `sk_gamedata`
--

CREATE TABLE `sk_gamedata` (
  `id` int(11) NOT NULL,
  `gu_id` int(10) NOT NULL,
  `gc_id` int(10) NOT NULL,
  `gs_id` int(10) NOT NULL,
  `gp_id` int(100) NOT NULL,
  `g_id` int(30) NOT NULL,
  `total_question` varchar(15) NOT NULL,
  `attempt_question` varchar(20) NOT NULL,
  `answer` varchar(20) NOT NULL,
  `game_score` varchar(50) NOT NULL,
  `gtime` varchar(100) NOT NULL,
  `rtime` varchar(100) NOT NULL,
  `crtime` varchar(100) NOT NULL,
  `wrtime` varchar(100) NOT NULL,
  `lastupdate` date NOT NULL,
  `createdby` varchar(100) NOT NULL,
  `creation_date` date NOT NULL,
  `modifiedby` varchar(100) NOT NULL,
  `modified_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `session_id` int(11) NOT NULL,
  `puzzle_cycle` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sk_gamedata`
--

INSERT INTO `sk_gamedata` (`id`, `gu_id`, `gc_id`, `gs_id`, `gp_id`, `g_id`, `total_question`, `attempt_question`, `answer`, `game_score`, `gtime`, `rtime`, `crtime`, `wrtime`, `lastupdate`, `createdby`, `creation_date`, `modifiedby`, `modified_date`, `session_id`, `puzzle_cycle`) VALUES
(1, 38324, 1, 62, 2, 1204, '10', '10', '3', '28', '180', '15', '7', '8', '2019-08-06', '', '0000-00-00', '', '2019-08-06 10:37:14', 9, 1),
(2, 38324, 1, 62, 2, 1204, '10', '10', '0', '0', '180', '10', '0', '10', '2019-08-06', '', '0000-00-00', '', '2019-08-06 10:37:14', 9, 2),
(3, 38324, 1, 61, 2, 1043, '10', '10', '3', '30', '180', '10', '3', '7', '2019-08-06', '', '0000-00-00', '', '2019-08-06 10:37:14', 9, 1),
(4, 38324, 1, 61, 2, 1043, '10', '10', '3', '30', '180', '107', '3', '104', '2019-08-06', '', '0000-00-00', '', '2019-08-06 10:37:14', 9, 2),
(5, 38324, 1, 59, 2, 1121, '10', '10', '5', '50', '180', '10', '5', '5', '2019-08-06', '', '0000-00-00', '', '2019-08-06 10:37:14', 9, 1),
(6, 38324, 1, 59, 2, 1121, '10', '10', '5', '50', '180', '20', '7', '13', '2019-08-06', '', '0000-00-00', '', '2019-08-06 10:37:14', 9, 2),
(7, 38324, 1, 63, 2, 1165, '10', '10', '9', '88', '180', '14', '13', '1', '2019-08-06', '', '0000-00-00', '', '2019-08-06 10:37:14', 9, 1),
(8, 38324, 1, 63, 2, 1165, '10', '10', '3', '30', '180', '73', '6', '67', '2019-08-06', '', '0000-00-00', '', '2019-08-06 10:39:29', 9, 2),
(9, 60498, 1, 61, 1, 1003, '10', '10', '5', '50', '180', '18', '5', '13', '2019-06-09', '', '0000-00-00', '', '2019-08-14 12:00:02', 9, 1),
(10, 60498, 1, 61, 1, 1003, '10', '10', '5', '50', '180', '10', '5', '5', '2019-06-09', '', '0000-00-00', '', '2019-08-14 12:00:02', 9, 2),
(11, 60498, 1, 61, 1, 1208, '10', '10', '4', '39', '180', '63', '9', '54', '2019-06-10', '', '0000-00-00', '', '2019-08-14 12:24:40', 10, 1),
(12, 60498, 1, 61, 1, 1208, '10', '2', '1', '10', '180', '5', '1', '4', '2019-06-10', '', '0000-00-00', '', '2019-08-14 12:24:40', 10, 2),
(13, 60498, 1, 61, 1, 1043, '10', '10', '4', '40', '180', '10', '4', '6', '2019-06-11', '', '0000-00-00', '', '2019-08-14 14:37:49', 11, 1),
(14, 60498, 1, 61, 1, 1043, '10', '10', '1', '10', '180', '11', '1', '10', '2019-06-11', '', '0000-00-00', '', '2019-08-14 14:37:49', 11, 2),
(15, 60498, 1, 61, 1, 1163, '10', '10', '8', '78', '180', '19', '12', '7', '2019-07-01', '', '0000-00-00', '', '2019-08-19 07:26:02', 18, 1),
(16, 60498, 1, 61, 1, 1163, '10', '10', '7', '70', '180', '36', '9', '27', '2019-07-01', '', '0000-00-00', '', '2019-08-19 07:26:02', 18, 2),
(17, 60498, 1, 60, 1, 1242, '10', '10', '10', '91', '180', '29', '29', '0', '2019-07-01', '', '0000-00-00', '', '2019-08-19 07:26:02', 18, 1),
(18, 60498, 1, 60, 1, 1242, '10', '10', '9', '85', '180', '23', '22', '1', '2019-07-01', '', '0000-00-00', '', '2019-08-19 07:26:02', 18, 2),
(19, 60498, 1, 60, 1, 1122, '10', '10', '5', '50', '180', '13', '8', '5', '2019-08-19', '', '0000-00-00', '', '2019-08-19 07:39:57', 26, 1),
(20, 60498, 1, 60, 1, 1122, '10', '10', '2', '20', '180', '15', '2', '13', '2019-08-19', '', '0000-00-00', '', '2019-08-19 07:39:57', 26, 2),
(21, 60498, 1, 61, 1, 1123, '10', '10', '10', '100', '180', '13', '13', '0', '2019-08-19', '', '0000-00-00', '', '2019-08-19 07:39:57', 26, 1),
(22, 60498, 1, 61, 1, 1123, '10', '10', '8', '80', '180', '11', '8', '3', '2019-08-19', '', '0000-00-00', '', '2019-08-19 07:41:26', 26, 2);

-- --------------------------------------------------------

--
-- Stand-in structure for view `sk_gamedata_updated`
-- (See below for the actual view)
--
CREATE TABLE `sk_gamedata_updated` (
`id` int(11)
,`gu_id` int(10)
,`gs_id` int(10)
,`g_id` int(30)
,`total_question` int(2)
,`attempt_question` bigint(21)
,`answer` decimal(23,0)
,`game_score` double
,`gtime` int(11)
,`rtime` decimal(32,0)
,`crtime` decimal(32,0)
,`wrtime` decimal(32,0)
,`lastupdate` date
,`iteration` int(11)
);

-- --------------------------------------------------------

--
-- Table structure for table `sk_games`
--

CREATE TABLE `sk_games` (
  `ID` int(11) NOT NULL,
  `skill_ID` int(11) NOT NULL,
  `game_masterID` int(11) NOT NULL,
  `name` varchar(400) NOT NULL,
  `swf_path` varchar(800) NOT NULL,
  `image_path` varchar(800) NOT NULL,
  `description` varchar(400) NOT NULL,
  `status` enum('Y','N') NOT NULL,
  `created_by` int(11) NOT NULL,
  `created_date` datetime NOT NULL,
  `modified_by` int(11) NOT NULL,
  `modified_date` datetime NOT NULL,
  `game_html` varchar(800) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sk_games`
--

INSERT INTO `sk_games` (`ID`, `skill_ID`, `game_masterID`, `name`, `swf_path`, `image_path`, `description`, `status`, `created_by`, `created_date`, `modified_by`, `modified_date`, `game_html`) VALUES
(414, 1, 414, 'AddOn-Level1', '', 'uploads/AddOn-Level1_29916255.png', '', 'Y', 0, '2014-06-26 00:00:00', 0, '2019-08-05 19:20:43', 'AddOn-Level1'),
(416, 1, 416, 'BuddySpot-Level1', '', 'uploads/BuddySpot-Level1_4558774498.png', '', 'Y', 0, '2014-06-26 00:00:00', 0, '2019-08-05 19:20:43', 'BuddySpot-Level1'),
(418, 2, 418, 'JackInTheBox-Level1', '', 'uploads/JackInTheBox-Level1_8967085247.png', '', 'Y', 0, '2014-06-26 00:00:00', 0, '2019-08-05 19:20:43', 'JackInTheBox-Level1'),
(419, 1, 419, 'LocateTheParts-Level1', '', 'uploads/LocateTheParts-Level1_9876082488.png', '', 'Y', 0, '2014-06-26 00:00:00', 0, '2019-08-05 19:20:43', 'LocateTheParts-Level1'),
(421, 1, 421, 'SmileySeries-Level1', '', 'uploads/SmileySeries-Level1_3376116408.png', '', 'Y', 0, '2014-06-26 00:00:00', 0, '2019-08-05 19:20:43', 'SmileySeries-Level1'),
(422, 3, 422, 'BestFit-Level1', '', 'uploads/BestFit-KG1_6883309637.png', '', 'Y', 0, '2014-06-26 00:00:00', 0, '2019-08-05 19:20:43', 'BestFit-Level1'),
(424, 2, 424, 'FaceCut-Level1', '', 'uploads/FaceCut-Level1_7893398585.png', '', 'Y', 0, '2014-06-26 00:00:00', 0, '2019-08-05 19:20:43', 'FaceCut-Level1'),
(425, 3, 425, 'IconMatch-Level1', '', 'uploads/IconMatch-Level1_4288190002.png', '', 'Y', 0, '2014-06-26 00:00:00', 0, '2019-08-05 19:20:43', 'IconMatch-Level1'),
(426, 2, 426, 'LostLastPart-Level1', '', 'uploads/LostLastPart-Level1_6288307351.png', '', 'Y', 0, '2014-06-26 00:00:00', 0, '2019-08-05 19:20:43', 'LostLastPart-Level1'),
(429, 2, 429, 'WhoHits-Level1', '', 'uploads/WhoHits-Level1_1098579633.png', '', 'Y', 0, '2014-06-26 00:00:00', 0, '2019-08-05 19:20:43', 'WhoHits-Level1'),
(431, 2, 431, 'ArrowHit-Level1', '', 'uploads/ArrowHit-Level1_2562350165.png', '', 'Y', 0, '2014-06-26 00:00:00', 0, '2019-08-05 19:20:43', 'ArrowHit-Level1'),
(432, 2, 432, 'DoWeDiffer-Level1', '', 'uploads/DoWeDiffer-Level1_9961162102.png', '', 'Y', 0, '2014-06-26 00:00:00', 0, '2019-08-05 19:20:43', 'DoWeDiffer-Level1'),
(433, 2, 433, 'PathTrace-Level1', '', 'uploads/PathTrace-Level1_9113778676.png', '', 'Y', 0, '2014-06-26 00:00:00', 0, '2019-08-05 19:20:43', 'PathTrace-Level1'),
(434, 2, 434, 'StarLight-Level1', '', 'uploads/StarLight-KG1_6201227623.png', '', 'Y', 0, '2014-06-26 00:00:00', 0, '2019-08-05 19:20:43', 'StarLight-Level1'),
(435, 2, 435, 'StrangerGrid-Level1', '', 'uploads/StrangerGrid-KG1_7493638731.png', '', 'Y', 0, '2014-06-26 00:00:00', 0, '2019-08-05 19:20:43', 'StrangerGrid-Level1'),
(439, 3, 439, 'GroupIt-Level1', '', 'uploads/GroupIt-Level1_2434460278.png', '', 'Y', 0, '2014-06-26 00:00:00', 0, '2019-08-05 19:20:43', 'GroupIt-Level1'),
(440, 3, 440, 'ImageSequence-Level1', '', 'uploads/ImageSequence-Level1_1271936539.png', '', 'Y', 0, '2014-06-26 00:00:00', 0, '2019-08-05 19:20:43', 'ImageSequence-Level1'),
(464, 1, 464, 'AddOn-Level2', '', 'uploads/AddOn-Level2_2288141329.png', '', 'Y', 0, '2014-06-26 00:00:00', 0, '2019-08-05 19:20:43', 'AddOn-Level2'),
(467, 1, 467, 'BuddySpot-Level2', '', 'uploads/BuddySpot-Level2_9439796507.png', '', 'Y', 0, '2014-06-26 00:00:00', 0, '2019-08-05 19:20:43', 'BuddySpot-Level2'),
(469, 1, 469, 'JackInTheBox-Level2', '', 'uploads/JackInTheBox-Level2_5127689531.png', '', 'Y', 0, '2014-06-26 00:00:00', 0, '2019-08-05 19:20:43', 'JackInTheBox-Level2'),
(470, 1, 470, 'LocateTheParts-Level2', '', 'uploads/LocateTheParts-Level2_4917782000.png', '', 'Y', 0, '2014-06-26 00:00:00', 0, '2019-08-05 19:20:43', 'LocateTheParts-Level2'),
(471, 1, 471, 'SmileySeries-Level2', '', 'uploads/SmileySeries-Level2_3532663313.png', '', 'Y', 0, '2014-06-26 00:00:00', 0, '2019-08-05 19:20:43', 'SmileySeries-Level2'),
(472, 3, 472, 'BestFit-Level2', '', 'uploads/BestFit-KG2_8591418769.png', '', 'Y', 0, '2014-06-26 00:00:00', 0, '2019-08-05 19:20:43', 'BestFit-Level2'),
(474, 2, 474, 'FaceCut-Level2', '', 'uploads/FaceCut-Level2_8397557884.png', '', 'Y', 0, '2014-06-26 00:00:00', 0, '2019-08-05 19:20:43', 'FaceCut-Level2'),
(475, 3, 475, 'IconMatch-Level2', '', 'uploads/IconMatch-Level2_191964996.png', '', 'Y', 0, '2014-06-26 00:00:00', 0, '2019-08-05 19:20:43', 'IconMatch-Level2'),
(476, 2, 476, 'LostLastPart-Level2', '', 'uploads/LostLastPart-Level2_6243226788.png', '', 'Y', 0, '2014-06-26 00:00:00', 0, '2019-08-05 19:20:43', 'LostLastPart-Level2'),
(479, 2, 479, 'WhoHits-Level2', '', 'uploads/WhoHits-Level2_3314637686.png', '', 'Y', 0, '2014-06-26 00:00:00', 0, '2019-08-05 19:20:43', 'WhoHits-Level2'),
(481, 2, 481, 'ArrowHit-Level2', '', 'uploads/ArrowHit-Level2_7136968858.png', '', 'Y', 0, '2014-06-26 00:00:00', 0, '2019-08-05 19:20:43', 'ArrowHit-Level2'),
(482, 2, 482, 'DoWeDiffer-Level2', '', 'uploads/DoWeDiffer-Level2_7497774129.png', '', 'Y', 0, '2014-06-26 00:00:00', 0, '2019-08-05 19:20:43', 'DoWeDiffer-Level2'),
(483, 2, 483, 'PathTrace-Level2', '', 'uploads/PathTrace-Level2_9511187383.png', '', 'Y', 0, '2014-06-26 00:00:00', 0, '2019-08-05 19:20:43', 'PathTrace-Level2'),
(484, 2, 484, 'StarLight-Level2', '', 'uploads/StarLight-KG2_7005840959.png', '', 'Y', 0, '2014-06-26 00:00:00', 0, '2019-08-05 19:20:43', 'StarLight-Level2'),
(485, 2, 485, 'StrangerGrid-Level2', '', 'uploads/StrangerGrid-KG2_1036263587.png', '', 'Y', 0, '2014-06-26 00:00:00', 0, '2019-08-05 19:20:43', 'StrangerGrid-Level2'),
(489, 3, 489, 'GroupIt-Level2', '', 'uploads/GroupIt-Level2.png', '', 'Y', 0, '2014-06-26 00:00:00', 0, '2019-08-05 19:20:43', 'GroupIt-Level2'),
(490, 3, 490, 'ImageSequence-Level2', '', 'uploads/ImageSequence-Level2_3751685819.png', '', 'Y', 0, '2014-06-26 00:00:00', 0, '2019-08-05 19:20:43', 'ImageSequence-Level2'),
(515, 1, 515, 'BirdRecall-Level2', '', 'uploads/AnimalRecall-Level1_5902908118.png', '', 'Y', 0, '2014-06-26 00:00:00', 0, '2019-08-05 19:20:43', 'BirdRecall-Level2'),
(516, 3, 516, 'OddShape-Level1', '', 'uploads/OddShape-Level2.png', '', 'Y', 0, '2014-06-26 00:00:00', 0, '2019-08-05 19:20:43', 'OddShape-Level1'),
(517, 2, 517, 'ShadowMatch-Level2', '', 'uploads/New-Kinder-Shadowmatch.png', '', 'Y', 0, '2014-06-26 00:00:00', 0, '2019-08-05 19:20:43', 'ShadowMatch-Level2'),
(518, 2, 518, 'ShapeGrid-Level1', '', 'uploads/ShapeGrid-KG.png', '', 'Y', 0, '2014-06-26 00:00:00', 0, '2019-08-05 19:20:43', 'ShapeGrid-Level1'),
(594, 1, 594, 'BallDrop-Level1', '', 'uploads/BallDrop-KG.png', '', 'Y', 0, '2019-05-02 00:00:00', 0, '2019-08-05 19:20:43', 'BallDrop-Level1'),
(595, 1, 595, 'TransPortRecall-Level1', '', 'uploads/AnimalRecall-Level1_5902908118.png', '', 'Y', 0, '2019-05-02 00:00:00', 0, '2019-08-05 19:20:43', 'TransPortRecall-Level1'),
(596, 1, 596, 'ShapeDrop-Level2', '', 'uploads/ShapeDrop-Level2.png', '', 'Y', 0, '2019-05-02 00:00:00', 0, '2019-08-05 19:20:43', 'ShapeDrop-Level2'),
(597, 2, 597, 'TheFinishLine-Level1', '', 'uploads/TheFinishLine-Level1.png', '', 'Y', 0, '2019-05-02 00:00:00', 0, '2019-08-05 19:20:43', 'TheFinishLine-Level1'),
(598, 2, 598, 'TheFinishLine-Level2', '', 'uploads/TheFinishLine-Level1.png', '', 'Y', 0, '2019-05-02 00:00:00', 0, '2019-08-05 19:20:43', 'TheFinishLine-Level2'),
(599, 2, 599, 'LaternLight-Level1', '', 'uploads/LanternLight.png', '', 'Y', 0, '2019-05-02 00:00:00', 0, '2019-08-05 19:20:43', 'LaternLight-Level1'),
(600, 2, 600, 'LaternLight-Level2', '', 'uploads/LanternLight.png', '', 'Y', 0, '2019-05-02 00:00:00', 0, '2019-08-05 19:20:43', 'LaternLight-Level2'),
(601, 2, 601, 'ObjectMatch-Level1', '', 'uploads/ObjectMatch-Level1.png', '', 'Y', 0, '2019-05-02 00:00:00', 0, '2019-08-05 19:20:43', 'ObjectMatch-Level1'),
(602, 2, 602, 'CompleteMe-Level1', '', 'uploads/CompleteMe.png', '', 'Y', 0, '2019-05-02 00:00:00', 0, '2019-08-05 19:20:43', 'CompleteMe-Level1'),
(603, 2, 603, 'MysteryShape-Level1', '', 'uploads/MysteryShape-Level1.png', '', 'Y', 0, '2019-05-02 00:00:00', 0, '2019-08-05 19:20:43', 'MysteryShape-Level1'),
(604, 2, 604, 'ShapeFocus-Level1', '', 'uploads/ShapeFocus-Level1.png', '', 'Y', 0, '2019-05-02 00:00:00', 0, '2019-08-05 19:20:43', 'ShapeFocus-Level1'),
(605, 2, 605, 'MatchmeObjects-Level1', '', 'uploads/MatchMe-Level1_3344377102.png.png', '', 'Y', 0, '2019-05-02 00:00:00', 0, '2019-08-05 19:20:43', 'MatchmeObjects-Level1'),
(606, 2, 606, 'ShapeGrid-Level2', '', 'uploads/ShapeGrid-KG.png', '', 'Y', 0, '2019-05-02 00:00:00', 0, '2019-08-05 19:20:43', 'ShapeGrid-Level2'),
(607, 2, 607, 'ObjectMatch-Level2', '', 'uploads/ObjectMatch-Level1.png', '', 'Y', 0, '2019-05-02 00:00:00', 0, '2019-08-05 19:20:43', 'ObjectMatch-Level2'),
(608, 2, 608, 'CompleteMe-Level2', '', 'uploads/CompleteMe.png', '', 'Y', 0, '2019-05-02 00:00:00', 0, '2019-08-05 19:20:43', 'CompleteMe-Level2'),
(609, 2, 609, 'MysteryShape-Level2', '', 'uploads/MysteryShape-Level1.png', '', 'Y', 0, '2019-05-02 00:00:00', 0, '2019-08-05 19:20:43', 'MysteryShape-Level2'),
(610, 2, 610, 'ShapeFocus-Level2', '', 'uploads/ShapeFocus-Level2.png', '', 'Y', 0, '2019-05-02 00:00:00', 0, '2019-08-05 19:20:43', 'ShapeFocus-Level2'),
(611, 2, 611, 'MatchmeObjects-Level2', '', 'uploads/MatchMe-Level1_3344377102.png.png', '', 'Y', 0, '2019-05-02 00:00:00', 0, '2019-08-05 19:20:43', 'MatchmeObjects-Level2'),
(612, 2, 612, 'TallShort-Level1', '', 'uploads/New-Kinder-TallShort.png', '', 'Y', 0, '2019-05-02 00:00:00', 0, '2019-08-05 19:20:43', 'TallShort-Level1'),
(613, 2, 613, 'BigSmall-Level1', '', 'uploads/Big-Small-Level1.png', '', 'Y', 0, '2019-05-02 00:00:00', 0, '2019-08-05 19:20:43', 'BigSmall-Level1'),
(614, 2, 614, 'ShadowMatch-Level1', '', 'uploads/New-Kinder-Shadowmatch.png', '', 'Y', 0, '2019-05-02 00:00:00', 0, '2019-08-05 19:20:43', 'ShadowMatch-Level1'),
(615, 2, 615, 'GiftBox-Level1', '', 'uploads/GiftBox.png', '', 'Y', 0, '2019-05-02 00:00:00', 0, '2019-08-05 19:20:43', 'GiftBox-Level1'),
(616, 2, 616, 'TallShort-Level2', '', 'uploads/New-Kinder-TallShort.png', '', 'Y', 0, '2019-05-02 00:00:00', 0, '2019-08-05 19:20:43', 'TallShort-Level2'),
(617, 2, 617, 'BigSmall-Level2', '', 'uploads/Big-Small-Level1.png', '', 'Y', 0, '2019-05-02 00:00:00', 0, '2019-08-05 19:20:43', 'BigSmall-Level2'),
(618, 2, 618, 'GiftBox-Level2', '', 'uploads/GiftBox.png', '', 'Y', 0, '2019-05-02 00:00:00', 0, '2019-08-05 19:20:43', 'GiftBox-Level2'),
(619, 3, 619, 'GroupRepresentation-Level1', '', 'uploads/PatternRepresentation-Level1_7518243058.png', '', 'Y', 0, '2019-05-02 00:00:00', 0, '2019-08-05 19:20:43', 'GroupRepresentation-Level1'),
(620, 3, 620, 'MatchTheShape-Level1', '', 'uploads/MatchTheShape.png', '', 'Y', 0, '2019-05-02 00:00:00', 0, '2019-08-05 19:20:43', 'MatchTheShape-Level1'),
(621, 3, 621, 'Findtheshapes-Level1', '', 'uploads/FindTheShapes.png', '', 'Y', 0, '2019-05-02 00:00:00', 0, '2019-08-05 19:20:43', 'Findtheshapes-Level1'),
(622, 3, 622, 'Matchtheshape-Level2', '', 'uploads/MatchTheShape.png', '', 'Y', 0, '2019-05-02 00:00:00', 0, '2019-08-05 19:20:43', 'Matchtheshape-Level2'),
(623, 3, 623, 'Findtheshapes-Level2', '', 'uploads/FindTheShapes.png', '', 'Y', 0, '2019-05-02 00:00:00', 0, '2019-08-05 19:20:43', 'Findtheshapes-Level2'),
(624, 3, 624, 'CountMe-Level1', '', 'uploads/New-Kinder-CountMe.png', '', 'Y', 0, '2019-05-02 00:00:00', 0, '2019-08-05 19:20:43', 'CountMe-Level1'),
(625, 3, 625, 'Buttonholes-Level1', '', 'uploads/ButtonHoles.png', '', 'Y', 0, '2019-05-02 00:00:00', 0, '2019-08-05 19:20:43', 'Buttonholes-Level1'),
(626, 3, 626, 'CountMe-Level2', '', 'uploads/New-Kinder-CountMe.png', '', 'Y', 0, '2019-05-02 00:00:00', 0, '2019-08-05 19:20:43', 'CountMe-Level2'),
(627, 3, 627, 'Buttonholes-Level2', '', 'uploads/ButtonHoles.png', '', 'Y', 0, '2019-05-02 00:00:00', 0, '2019-08-05 19:20:43', 'Buttonholes-Level2'),
(628, 3, 628, 'OddShape-Level2', '', 'uploads/OddShape-Level2.png', '', 'Y', 0, '2019-05-02 00:00:00', 0, '2019-08-05 19:20:43', 'OddShape-Level2'),
(1001, 59, 1001, 'BusRide-Level1', '', 'uploads/BusRide-Level1_9721776302.png', '', 'Y', 0, '2019-06-11 00:00:00', 0, '2019-08-05 20:26:32', 'BusRide-Level1'),
(1002, 60, 1002, 'EyeCells-Level1', '', 'uploads/EyeCells-Level1_7996039153.png', '', 'Y', 0, '2019-06-11 00:00:00', 0, '2019-08-05 20:26:32', 'EyeCells-Level1'),
(1003, 61, 1003, 'LastLegend-Level1', '', 'uploads/LastLegend-Level1_3132143379.png', '', 'Y', 0, '2019-06-11 00:00:00', 0, '2019-08-05 20:26:32', 'LastLegend-Level1'),
(1004, 62, 1004, 'WhatComesNext', '', 'uploads/WhatComesNext_8895443235.png', '', 'Y', 0, '2019-06-11 00:00:00', 0, '2019-08-05 20:26:32', 'WhatComesNext'),
(1005, 63, 1005, 'WhoAmI-Shapes', '', 'uploads/WhoAmI-Shapes_7515025790.png', '', 'Y', 0, '2019-06-11 00:00:00', 0, '2019-08-05 20:26:32', 'WhoAmI-Shapes'),
(1006, 59, 1006, 'MemoryCheck-Level2', '', 'uploads/MemoryCheck-Level2_8882285202.png', '', 'Y', 0, '2019-06-11 00:00:00', 0, '2019-08-05 20:26:32', 'MemoryCheck-Level2'),
(1007, 60, 1007, 'EyeCells-Level2', '', 'uploads/EyeCells-Level2_5889739277.png', '', 'Y', 0, '2019-06-11 00:00:00', 0, '2019-08-05 20:26:32', 'EyeCells-Level2'),
(1008, 61, 1008, 'LetterJigsaw-Level2', '', 'uploads/AlphabetJigsaw-Level2_439756815.png', '', 'Y', 0, '2019-06-11 00:00:00', 0, '2019-08-05 20:26:32', 'LetterJigsaw-Level2'),
(1009, 62, 1009, 'ParaMaster-Level1', '', 'uploads/ParaMaster-Level1_8246283596.png', '', 'Y', 0, '2019-06-11 00:00:00', 0, '2019-08-05 20:26:32', 'ParaMaster-Level1'),
(1010, 63, 1010, 'WhoAmI-Clothes', '', 'uploads/WhoAmI-Clothes_236435011.png', '', 'Y', 0, '2019-06-11 00:00:00', 0, '2019-08-05 20:26:32', 'WhoAmI-Clothes'),
(1011, 59, 1011, 'BalloonBurst-Level2', '', 'uploads/BalloonBurst-Level2_244336309.png', '', 'Y', 0, '2019-06-11 00:00:00', 0, '2019-08-05 20:26:32', 'BalloonBurst-Level2'),
(1012, 60, 1012, 'BestFit-Level4', '', 'uploads/BestFit-Level3_8792649721.png', '', 'Y', 0, '2019-06-11 00:00:00', 0, '2019-08-05 20:26:32', 'BestFit-Level4'),
(1013, 61, 1013, 'AnimalSpell', '', 'uploads/AnimalSpell_5479293791.png', '', 'Y', 0, '2019-06-11 00:00:00', 0, '2019-08-05 20:26:32', 'AnimalSpell'),
(1014, 62, 1014, 'NumberDecode-Level2', '', 'uploads/NumberDecode-Level2_2425581049.png', '', 'Y', 0, '2019-06-11 00:00:00', 0, '2019-08-05 20:26:32', 'NumberDecode-Level2'),
(1015, 63, 1015, 'Anagrams-Clothes', '', 'uploads/Anagrams-Clothing_8464276143.png', '', 'Y', 0, '2019-06-11 00:00:00', 0, '2019-08-05 20:26:32', 'Anagrams-Clothes'),
(1016, 59, 1016, 'BalloonBurst-Level3', '', 'uploads/BalloonBurst-Level3_2492009233.png', '', 'Y', 0, '2019-06-11 00:00:00', 0, '2019-08-05 20:26:32', 'BalloonBurst-Level3'),
(1017, 60, 1017, 'ReverseReading-Level5', '', 'uploads/ReverseReading-Level5_5669675888.png', '', 'Y', 0, '2019-06-11 00:00:00', 0, '2019-08-05 20:26:32', 'ReverseReading-Level5'),
(1018, 61, 1018, 'DownUnder-Level2', '', 'uploads/DownUnder-Level2_5347298909.png', '', 'Y', 0, '2019-06-11 00:00:00', 0, '2019-08-05 20:26:32', 'DownUnder-Level2'),
(1019, 62, 1019, 'ParaMaster-Level3', '', 'uploads/ParaMaster-Level3_8316638404.png', '', 'Y', 0, '2019-06-11 00:00:00', 0, '2019-08-05 20:26:32', 'ParaMaster-Level3'),
(1020, 63, 1020, 'Anagrams-Math', '', 'uploads/Anagrams-Math_3996595479.png', '', 'Y', 0, '2019-06-11 00:00:00', 0, '2019-08-05 20:26:32', 'Anagrams-Math'),
(1021, 59, 1021, 'BalloonBurst-Level4', '', 'uploads/BalloonBurst-Level4_2785141328.png', '', 'Y', 0, '2019-06-11 00:00:00', 0, '2019-08-05 20:26:32', 'BalloonBurst-Level4'),
(1022, 60, 1022, 'JustNotHalf-Level2', '', 'uploads/JustNotHalf-Level2_2203953666.png', '', 'Y', 0, '2019-06-11 00:00:00', 0, '2019-08-05 20:26:32', 'JustNotHalf-Level2'),
(1023, 61, 1023, 'LastLegend-Level4', '', 'uploads/LastLegend-Level4_3372493218.png', '', 'Y', 0, '2019-06-11 00:00:00', 0, '2019-08-05 20:26:32', 'LastLegend-Level4'),
(1024, 62, 1024, 'NumberSeries-Level2', '', 'uploads/NumberSeries-Level2_1761797624.png', '', 'Y', 0, '2019-06-11 00:00:00', 0, '2019-08-05 20:26:32', 'NumberSeries-Level2'),
(1025, 63, 1025, 'Anagrams-HouseHold', '', 'uploads/Anagrams-Household_4300776333.png', '', 'Y', 0, '2019-06-11 00:00:00', 0, '2019-08-05 20:26:32', 'Anagrams-HouseHold'),
(1026, 59, 1026, 'AlphaNumericEncode-Level5', '', 'uploads/AlphaNumericEncode-Level5_5666280859.png', '', 'Y', 0, '2019-06-11 00:00:00', 0, '2019-08-05 20:26:32', 'AlphaNumericEncode-Level5'),
(1027, 60, 1027, 'CubeSherlock-Level1', '', 'uploads/CubeSherlock-Level1_9494013660.png', '', 'Y', 0, '2019-06-11 00:00:00', 0, '2019-08-05 20:26:32', 'CubeSherlock-Level1'),
(1028, 61, 1028, 'DeepUnder-Level4', '', 'uploads/DeepUnder-Level4_8108292836.png', '', 'Y', 0, '2019-06-11 00:00:00', 0, '2019-08-05 20:26:32', 'DeepUnder-Level4'),
(1029, 62, 1029, 'ParaMaster-Level5', '', 'uploads/ParaMaster-Level5_5265605337.png', '', 'Y', 0, '2019-06-11 00:00:00', 0, '2019-08-05 20:26:32', 'ParaMaster-Level5'),
(1030, 63, 1030, 'Anagrams-FourLetterWord', '', 'uploads/Anagrams-FourLetterWords_96878870.png', '', 'Y', 0, '2019-06-11 00:00:00', 0, '2019-08-05 20:26:32', 'Anagrams-FourLetterWord'),
(1031, 59, 1031, 'AlphaNumericEncode-Level6', '', 'uploads/AlphaNumericEncode-Level6_7225111038.png', '', 'Y', 0, '2019-06-11 00:00:00', 0, '2019-08-05 20:26:32', 'AlphaNumericEncode-Level6'),
(1032, 60, 1032, 'ChooseTwoToMakeOne', '', 'uploads/ChooseTwoToMakeOne_7422157558.png', '', 'Y', 0, '2019-06-11 00:00:00', 0, '2019-08-05 20:26:32', 'ChooseTwoToMakeOne'),
(1033, 61, 1033, 'ShapeRollers-Level4', '', 'uploads/ShapeRollers-Level4_452656652.png', '', 'Y', 0, '2019-06-11 00:00:00', 0, '2019-08-05 20:26:32', 'ShapeRollers-Level4'),
(1034, 62, 1034, 'ATeddyForATeddy-Level3', '', 'uploads/ATeddyForATeddy-Level3_1824636519.png', '', 'Y', 0, '2019-06-11 00:00:00', 0, '2019-08-05 20:26:32', 'ATeddyForATeddy-Level3'),
(1035, 63, 1035, 'Anagrams-Geography', '', 'uploads/Anagrams-Geography_5710392687.png', '', 'Y', 0, '2019-06-11 00:00:00', 0, '2019-08-05 20:26:32', 'Anagrams-Geography'),
(1036, 59, 1036, 'CoordinateGraph-Level1', '', 'uploads/CoordinateGraph-Level1_1309713018.png', '', 'Y', 0, '2019-06-11 00:00:00', 0, '2019-08-05 20:26:32', 'CoordinateGraph-Level1'),
(1037, 60, 1037, 'JustNotHalf-Level4', '', 'uploads/JustNotHalf-Level4_2555441330.png', '', 'Y', 0, '2019-06-11 00:00:00', 0, '2019-08-05 20:26:32', 'JustNotHalf-Level4'),
(1038, 61, 1038, 'ColorInColor-Level1', '', 'uploads/ColorInColor-Level1_1204938488.png', '', 'Y', 0, '2019-06-11 00:00:00', 0, '2019-08-05 20:26:32', 'ColorInColor-Level1'),
(1039, 62, 1039, 'Equate-Level1', '', 'uploads/Equate-Level1_3846404044.png', '', 'Y', 0, '2019-06-11 00:00:00', 0, '2019-08-05 20:26:32', 'Equate-Level1'),
(1040, 63, 1040, 'GuessTheWord-Level1', '', 'uploads/GuessTheWord-Level1_8028972977.png', '', 'Y', 0, '2019-06-11 00:00:00', 0, '2019-08-05 20:26:32', 'GuessTheWord-Level1'),
(1041, 59, 1041, 'AlphaNumericEncode-Level1', '', 'uploads/AlphaNumericEncode-Level1_4518458847.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'AlphaNumericEncode-Level1'),
(1042, 60, 1042, 'ObjectShade', '', 'uploads/ObjectShade_7239343100.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'ObjectShade'),
(1043, 61, 1043, 'NumberJigsaw-Level1', '', 'uploads/NumberJigsaw-Level1_3981064627.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'NumberJigsaw-Level1'),
(1044, 62, 1044, 'WordShapes-Level1', '', 'uploads/WordShapes-Level1_5870673032.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'WordShapes-Level1'),
(1045, 63, 1045, 'WhoAmI-Birds', '', 'uploads/WhoAmI-Birds_7869069152.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'WhoAmI-Birds'),
(1046, 59, 1046, 'BalloonBurst-Level1', '', 'uploads/BalloonBurst-Level1_8117342898.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'BalloonBurst-Level1'),
(1047, 60, 1047, 'CharacterShade-Level3', '', 'uploads/CharacterShade-Level3_3322312142.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'CharacterShade-Level3'),
(1048, 61, 1048, 'ObjectSpell-Level1', '', 'uploads/ObjectSpell-Level1_6468444657.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'ObjectSpell-Level1'),
(1049, 62, 1049, 'Reshuffle-Level1', '', 'uploads/Reshuffle-Level1_9448890620.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'Reshuffle-Level1'),
(1050, 63, 1050, 'WhoAmI-Insects', '', 'uploads/WhoAmI-Insects_9486121060.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'WhoAmI-Insects'),
(1051, 59, 1051, 'BusRide-Level2', '', 'uploads/BusRide-Level2_6232746895.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'BusRide-Level2'),
(1052, 60, 1052, 'Hand2Hand', '', 'uploads/Hand2Hand_5783699043.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'Hand2Hand'),
(1053, 61, 1053, 'BallShooter-Level1', '', 'uploads/Ball_Shooter.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'BallShooter-Level1'),
(1054, 62, 1054, 'NumbersOnTheWheel-Level2', '', 'uploads/NumbersOnTheWheel-Level2_5032758838.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'NumbersOnTheWheel-Level2'),
(1055, 63, 1055, 'NameLand-Level1', '', 'uploads/NameLand-Level1_3850891082.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'NameLand-Level1'),
(1056, 59, 1056, 'CycleRace-Level3', '', 'uploads/CycleRace-Level3_6173525671.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'CycleRace-Level3'),
(1057, 60, 1057, 'MirrorMatch-Level1', '', 'uploads/MirrorMatch-Level1_3191918600.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'MirrorMatch-Level1'),
(1058, 61, 1058, 'NumberJigsaw-Level3', '', 'uploads/NumberJigsaw-Level3_7143653305.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'NumberJigsaw-Level3'),
(1059, 62, 1059, 'NumbersOnTheWheel-Level3', '', 'uploads/NumbersOnTheWheel-Level3_7181768785.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'NumbersOnTheWheel-Level3'),
(1060, 63, 1060, 'ArrangeTheWords-Level3', '', 'uploads/ArrangeTheWords-Level3_6521334904.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'ArrangeTheWords-Level3'),
(1061, 59, 1061, 'CycleRace-Level4', '', 'uploads/CycleRace-Level4_4780295565.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'CycleRace-Level4'),
(1062, 60, 1062, 'MirrorMatch-Level2', '', 'uploads/MirrorMatch-Level2_4265700853.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'MirrorMatch-Level2'),
(1063, 61, 1063, 'LetterJigsaw-Level4', '', 'uploads/AlphabetJigsaw-Level4_5252252509.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'LetterJigsaw-Level4'),
(1064, 62, 1064, 'NumbersOnTheWheel-Level4', '', 'uploads/NumbersOnTheWheel-Level4_1754132225.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'NumbersOnTheWheel-Level4'),
(1065, 63, 1065, 'Anagrams-Vehicles', '', 'uploads/Anagrams-Vehicles_8503454732.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'Anagrams-Vehicles'),
(1066, 59, 1066, 'AnimalWatch-Level1', '', 'uploads/AnimalWatch-Level1_8736748136.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'AnimalWatch-Level1'),
(1067, 60, 1067, 'FindTheTwins-Level2', '', 'uploads/FindTheTwins-Level2_3434965950.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'FindTheTwins-Level2'),
(1068, 61, 1068, 'LastLegend-Level5', '', 'uploads/LastLegend-Level5_7495082467.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'LastLegend-Level5'),
(1069, 62, 1069, 'FitMeRight-Level2', '', 'uploads/FitMeRight-Level2_340231573.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'FitMeRight-Level2'),
(1070, 63, 1070, 'Anagrams-Jobs', '', 'uploads/Anagrams-Jobs_2256901105.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'Anagrams-Jobs'),
(1071, 59, 1071, 'CycleRace-Level6', '', 'uploads/CycleRace-Level6_5745665873.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'CycleRace-Level6'),
(1072, 60, 1072, 'FlipTrick-Level1', '', 'uploads/FlipTrick-Level1_6290403776.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'FlipTrick-Level1'),
(1073, 61, 1073, 'Rainbow-Level2', '', 'uploads/Rainbow-Level2_2451191339.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'Rainbow-Level2'),
(1074, 62, 1074, 'Reshuffle-Level6', '', 'uploads/Reshuffle-Level6_4803005247.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'Reshuffle-Level6'),
(1075, 63, 1075, 'Anagrams-Military', '', 'uploads/Anagrams-Military_2205101763.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'Anagrams-Military'),
(1076, 59, 1076, 'CoordinateGraph-Level2', '', 'uploads/CoordinateGraph-Level2_2700936608.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'CoordinateGraph-Level2'),
(1077, 60, 1077, 'MirrorImage-Level2', '', 'uploads/MirrorImage-Level2_8513625911.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'MirrorImage-Level2'),
(1078, 61, 1078, 'NumberMe-Level1', '', 'uploads/NumberMe-Level1_9366972525.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'NumberMe-Level1'),
(1079, 62, 1079, 'NumbersOnTheVertices-Level1', '', 'uploads/NumbersOnTheVertices-Level1_6839827257.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'NumbersOnTheVertices-Level1'),
(1080, 63, 1080, 'GuessTheWord-Level2', '', 'uploads/GuessTheWord-Level2_718786111.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'GuessTheWord-Level2'),
(1081, 59, 1081, 'MindCapture-Level1', '', 'uploads/MindCapture-Level1_9870321140.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'MindCapture-Level1'),
(1082, 60, 1082, 'WordWipe-Level1', '', 'uploads/WordWipe-Level1_7054595984.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'WordWipe-Level1'),
(1083, 61, 1083, 'StarLight-Level3', '', 'uploads/StarLight-Level1_9186881147.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'StarLight-Level3'),
(1084, 62, 1084, 'AddMaster-Level1', '', 'uploads/AddMaster-Level1_5437691258.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'AddMaster-Level1'),
(1085, 63, 1085, 'CompoundWords', '', 'uploads/CompoundWords_12777526.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'CompoundWords'),
(1086, 59, 1086, 'CycleRace-Level1', '', 'uploads/CycleRace-Level1_2532993447.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'CycleRace-Level1'),
(1087, 60, 1087, 'MatchMe-Level2', '', 'uploads/MatchMe-Level2_5947240493.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'MatchMe-Level2'),
(1088, 61, 1088, 'LastLegend-Level2', '', 'uploads/LastLegend-Level2_5781244020.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'LastLegend-Level2'),
(1089, 62, 1089, 'NumberDecode-Level1', '', 'uploads/NumberDecode-Level1_5552706075.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'NumberDecode-Level1'),
(1090, 63, 1090, 'WhoAmI-Transport', '', 'uploads/WhoAmI-Transport_156703181.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'WhoAmI-Transport'),
(1091, 59, 1091, 'CycleRace-Level2', '', 'uploads/CycleRace-Level2_5460967603.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'CycleRace-Level2'),
(1092, 60, 1092, 'JustNotHalf-Level1', '', 'uploads/JustNotHalf-Level1_6506787771.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'JustNotHalf-Level1'),
(1093, 61, 1093, 'ObjectSpell-Level2', '', 'uploads/ObjectSpell-Level2_9643486370.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'ObjectSpell-Level2'),
(1094, 62, 1094, 'ParaMaster-Level2', '', 'uploads/ParaMaster-Level2_9887385293.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'ParaMaster-Level2'),
(1095, 63, 1095, 'WhoAmI_SeaAnimals', '', 'uploads/WhoAmI-SeaAnimals_9400465255.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'WhoAmI_SeaAnimals'),
(1096, 59, 1096, 'DialAnumber', '', 'uploads/DialANumber_8347820923.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'DialAnumber'),
(1097, 60, 1097, 'CharacterShade-Level4', '', 'uploads/CharacterShade-Level4_7572658732.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'CharacterShade-Level4'),
(1098, 61, 1098, 'BalloonLight-Level3', '', 'uploads/DarkLight-Level3_6337577155.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'BalloonLight-Level3'),
(1099, 62, 1099, 'Reshuffle-Level3', '', 'uploads/Reshuffle-Level3_2661516019.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'Reshuffle-Level3'),
(1100, 63, 1100, 'NameLand-Level2', '', 'uploads/NameLand-Level2_9281079615.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'NameLand-Level2'),
(1101, 59, 1101, 'MemoryCheck-Level5', '', 'uploads/MemoryCheck-Level5_9116933126.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'MemoryCheck-Level5'),
(1102, 60, 1102, 'IAmCube-Level1', '', 'uploads/IAmCube-Level1_3901067436.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'IAmCube-Level1'),
(1103, 61, 1103, 'NumberJigsaw-Level4', '', 'uploads/NumberJigsaw-Level4_3807144016.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'NumberJigsaw-Level4'),
(1104, 62, 1104, 'HueCram', '', 'uploads/HueCram_438871416.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'HueCram'),
(1105, 63, 1105, 'MissingLetter-Level2', '', 'uploads/MissingLetter-Level2_3469503405.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'MissingLetter-Level2'),
(1106, 59, 1106, 'SequenceMemory-Level5', '', 'uploads/SequenceMemory-Level5_7487447718.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'SequenceMemory-Level5'),
(1107, 60, 1107, 'JustNotHalf-Level3', '', 'uploads/JustNotHalf-Level3_486829234.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'JustNotHalf-Level3'),
(1108, 61, 1108, 'Rainbow-Level1', '', 'uploads/Rainbow-Level1_1321175633.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'Rainbow-Level1'),
(1109, 62, 1109, 'Reshuffle-Level5', '', 'uploads/Reshuffle-Level5_1823949897.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'Reshuffle-Level5'),
(1110, 63, 1110, 'Anagrams-Schools', '', 'uploads/Anagrams-School_220320839.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'Anagrams-Schools'),
(1111, 59, 1111, 'GraphDecoder', '', 'uploads/GraphDecoder_6767004569.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'GraphDecoder'),
(1112, 60, 1112, 'MirrorImage-Level1', '', 'uploads/MirrorImage-Level1_4596876199.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'MirrorImage-Level1'),
(1113, 61, 1113, 'ColorInColor-Level2', '', 'uploads/ColorInColor-Level2_4620457286.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'ColorInColor-Level2'),
(1114, 62, 1114, 'Shopping-Level1', '', 'uploads/Shopping-Level1_6256451136.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'Shopping-Level1'),
(1115, 63, 1115, 'Anagrams-People', '', 'uploads/Anagrams-People_1156277623.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'Anagrams-People'),
(1116, 59, 1116, 'MisplacedBuddy-Level1', '', 'uploads/MisplacedBuddy-Level1_4661093535.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'MisplacedBuddy-Level1'),
(1117, 60, 1117, 'WhoIsNotThere-Level1', '', 'uploads/WhoIsNotThere-Level1_3340305127.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'WhoIsNotThere-Level1'),
(1118, 61, 1118, 'NumberMe-Level2', '', 'uploads/NumberMe-Level2_1924527920.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'NumberMe-Level2'),
(1119, 62, 1119, 'Shopping-Level2', '', 'uploads/Shopping-Level2_4992981352.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'Shopping-Level2'),
(1120, 63, 1120, 'JumbledLetters-Level1', '', 'uploads/JumbledLetters-Level1_7572877304.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'JumbledLetters-Level1'),
(1121, 59, 1121, 'MemoryCheck-Level1', '', 'uploads/MemoryCheck-Level1_1938757994.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'MemoryCheck-Level1'),
(1122, 60, 1122, 'BestFit-Level3', '', 'uploads/BestFit-Level2_6896948479.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'BestFit-Level3'),
(1123, 61, 1123, 'StarLight-Level4', '', 'uploads/StarLight-Level2_988681958.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'StarLight-Level4'),
(1124, 62, 1124, 'HeavyOrLight-Level1', '', 'uploads/HeavyOrLight-Level1_9671432706.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'HeavyOrLight-Level1'),
(1125, 63, 1125, 'WhoAmI-HouseHoldThings', '', 'uploads/WhoAmI-HouseHoldThings_8783441544.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'WhoAmI-HouseHoldThings'),
(1126, 59, 1126, 'SequenceMemory-Level1', '', 'uploads/SequenceMemory-Level1_903124888.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'SequenceMemory-Level1'),
(1127, 60, 1127, 'EdCells-Level2', '', 'uploads/EdCells-Level2_812620040.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'EdCells-Level2'),
(1128, 61, 1128, 'DownUnder-Level1', '', 'uploads/DownUnder-Level1_9248090591.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'DownUnder-Level1'),
(1129, 62, 1129, 'NumbersOnTheWheel-Level1', '', 'uploads/NumbersOnTheWheel-Level1_5239142207.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'NumbersOnTheWheel-Level1'),
(1130, 63, 1130, 'WhoAmI-School', '', 'uploads/WhoAmI-School_1506193187.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'WhoAmI-School'),
(1131, 59, 1131, 'AlphaNumericEncode-Level2', '', 'uploads/AlphaNumericEncode-Level2_546242767.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'AlphaNumericEncode-Level2'),
(1132, 60, 1132, 'EdCells-Level3', '', 'uploads/EdCells-Level3_4655870916.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'EdCells-Level3'),
(1133, 61, 1133, 'BalloonLight-Level2', '', 'uploads/DarkLight-Level2_7840619147.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'BalloonLight-Level2'),
(1134, 62, 1134, 'AddMaster-Level2', '', 'uploads/AddMaster-Level2_6791430432.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'AddMaster-Level2'),
(1135, 63, 1135, 'Anagrams-Animals', '', 'uploads/Anagrams-Animals_690025119.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'Anagrams-Animals'),
(1136, 59, 1136, 'SequenceMemory-Level3', '', 'uploads/SequenceMemory-Level3_9452287289.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'SequenceMemory-Level3'),
(1137, 60, 1137, 'EyeCells-Level3', '', 'uploads/EyeCells-Level3_8897464917.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'EyeCells-Level3'),
(1138, 61, 1138, 'LastLegend-Level3', '', 'uploads/LastLegend-Level3_5495434515.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'LastLegend-Level3'),
(1139, 62, 1139, 'AddMaster-Level3', '', 'uploads/AddMaster-Level3_2056090440.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'AddMaster-Level3'),
(1140, 63, 1140, 'Anagrams-Body', '', 'uploads/Anagrams-Body_8010135167.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'Anagrams-Body'),
(1141, 59, 1141, 'AlphaNumericEncode-Level4', '', 'uploads/AlphaNumericEncode-Level4_2667365404.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'AlphaNumericEncode-Level4'),
(1142, 60, 1142, 'MirrorMatch-Level3', '', 'uploads/MirrorMatch-Level3_3233505128.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'MirrorMatch-Level3'),
(1143, 61, 1143, 'CarPark-Level2', '', 'uploads/CarPark-Level2_116904969.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'CarPark-Level2'),
(1144, 62, 1144, 'ParaMaster-Level4', '', 'uploads/ParaMaster-Level4_3163872654.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'ParaMaster-Level4'),
(1145, 63, 1145, 'HomoPhones-Level1', '', 'uploads/HomoPhones-Level1_1627698740.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'HomoPhones-Level1'),
(1146, 59, 1146, 'AnimalWatch-Level2', '', 'uploads/AnimalWatch-Level2_2552103889.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'AnimalWatch-Level2'),
(1147, 60, 1147, 'IAmCube-Level2', '', 'uploads/IAmCube-Level2_7666559526.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'IAmCube-Level2'),
(1148, 61, 1148, 'CarPark-Level4', '', 'uploads/CarPark-Level4_5836739456.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'CarPark-Level4'),
(1149, 62, 1149, 'NumbersOnTheWheel-Level5', '', 'uploads/NumbersOnTheWheel-Level5_1027476550.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'NumbersOnTheWheel-Level5'),
(1150, 63, 1150, 'Anagrams-Sports', '', 'uploads/Anagrams-Sports_9202636964.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'Anagrams-Sports'),
(1151, 59, 1151, 'DropBox-Level1', '', 'uploads/DropBox-Level1_6700938204.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'DropBox-Level1'),
(1152, 60, 1152, 'CubeSherlock-Level2', '', 'uploads/CubeSherlock-Level2_2803261997.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'CubeSherlock-Level2'),
(1153, 61, 1153, 'DiscretePaddle-Level2', '', 'uploads/DiscretePadle-Level2_4007870662.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'DiscretePaddle-Level2'),
(1154, 62, 1154, 'NittyGritty', '', 'uploads/NittyGritty_5187215218.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'NittyGritty'),
(1155, 63, 1155, 'ConfusionGalore-Level1', '', 'uploads/ConfusionGalore-Level1_4439043053.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'ConfusionGalore-Level1'),
(1156, 59, 1156, 'SpotMyPlace-Level2', '', 'uploads/SpotMyPlace-Level2_128739713.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'SpotMyPlace-Level2'),
(1157, 60, 1157, 'WaterImage-Level2', '', 'uploads/WaterImage-Level2_3779711904.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'WaterImage-Level2'),
(1158, 61, 1158, 'DiscretePaddle-Level3', '', 'uploads/DiscretePadle-Level3_3544559371.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'DiscretePaddle-Level3'),
(1159, 62, 1159, 'AnalogyAction-Level3', '', 'uploads/AnalogyAction-Level3_1947425035.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'AnalogyAction-Level3'),
(1160, 63, 1160, 'KangarooWords', '', 'uploads/KangarooWords_1111639351.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'KangarooWords'),
(1161, 59, 1161, 'MomAndMe', '', 'uploads/MomAndMe_6942562656.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'MomAndMe'),
(1162, 60, 1162, 'EdCells-Level1', '', 'uploads/EdCells-Level1_376414950.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'EdCells-Level1'),
(1163, 61, 1163, 'StrangerGrid-Level3', '', 'uploads/StrangerGrid_9728514011.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'StrangerGrid-Level3'),
(1164, 62, 1164, 'ClockArithmetic', '', 'uploads/ClockArithmetic_6831587473.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'ClockArithmetic'),
(1165, 63, 1165, 'WhoAmI-Vegetables', '', 'uploads/WhoAmI-Vegetables_7871570191.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'WhoAmI-Vegetables'),
(1166, 59, 1166, 'MindCapture-Level2', '', 'uploads/MindCapture-Level2_5165879982.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'MindCapture-Level2'),
(1167, 60, 1167, 'WordWipe-Level2', '', 'uploads/WordWipe-Level2_4875887525.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'WordWipe-Level2'),
(1168, 61, 1168, 'SpotMe-Level2', '', 'uploads/SpotMe-Level2_5270674000.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'SpotMe-Level2'),
(1169, 62, 1169, 'WordShapes-Level2', '', 'uploads/WordShapes-Level2_2368690557.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'WordShapes-Level2'),
(1170, 63, 1170, 'WhoAmI-WildAnimals', '', 'uploads/WhoAmI-WildAnimals_8843113635.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'WhoAmI-WildAnimals'),
(1171, 59, 1171, 'MemoryCheck-Level3', '', 'uploads/MemoryCheck-Level3_7822075057.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'MemoryCheck-Level3'),
(1172, 60, 1172, 'MatchMe-Level3', '', 'uploads/MatchMe-Level3_3926392993.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'MatchMe-Level3'),
(1173, 61, 1173, 'DeepUnder-Level1', '', 'uploads/DeepUnder-Level1_7213067221.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'DeepUnder-Level1'),
(1174, 62, 1174, 'HeavyOrLight-Level2', '', 'uploads/HeavyOrLight-Level2_607259180.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'HeavyOrLight-Level2'),
(1175, 63, 1175, 'ArrangeTheWords-Level1', '', 'uploads/ArrangeTheWords-Level1_350359375.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'ArrangeTheWords-Level1'),
(1176, 59, 1176, 'AlphaNumericEncode-Level3', '', 'uploads/AlphaNumericEncode-Level3_387589167.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'AlphaNumericEncode-Level3'),
(1177, 60, 1177, 'ReflectionRead-Level2', '', 'uploads/ReflectionRead-Level2_2878144294.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'ReflectionRead-Level2'),
(1178, 61, 1178, 'LetterJigsaw-Level3', '', 'uploads/AlphabetJigsaw-Level3_1882078954.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'LetterJigsaw-Level3'),
(1179, 62, 1179, 'ATeddyForATeddy-Level1', '', 'uploads/ATeddyForATeddy-Level1_5987485046.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'ATeddyForATeddy-Level1'),
(1180, 63, 1180, 'Anagrams-Plants', '', 'uploads/Anagrams-Plants_2974008941.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'Anagrams-Plants'),
(1181, 59, 1181, 'SequenceMemory-Level4', '', 'uploads/SequenceMemory-Level4_9387351195.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'SequenceMemory-Level4'),
(1182, 60, 1182, 'MissingPiece-Level2', '', 'uploads/MissingPiece-Level2_9361892873.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'MissingPiece-Level2'),
(1183, 61, 1183, 'CarPark-Level3', '', 'uploads/CarPark-Level3_5003174929.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'CarPark-Level3'),
(1184, 62, 1184, 'Reshuffle-Level4', '', 'uploads/Reshuffle-Level4_4280022010.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'Reshuffle-Level4'),
(1185, 63, 1185, 'MissingLetter-Level4', '', 'uploads/MissingLetter-Level4_7994128023.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'MissingLetter-Level4'),
(1186, 59, 1186, 'CycleRace-Level5', '', 'uploads/CycleRace-Level5_1506978459.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'CycleRace-Level5'),
(1187, 60, 1187, 'MirrorMatch-Level4', '', 'uploads/MirrorMatch-Level4_9751465697.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'MirrorMatch-Level4'),
(1188, 61, 1188, 'ShapeRollers-Level2', '', 'uploads/ShapeRollers-Level2_5863707675.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'ShapeRollers-Level2'),
(1189, 62, 1189, 'SequenceGrid', '', 'uploads/SequenceGrid_9023916260.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'SequenceGrid'),
(1190, 63, 1190, 'Anagrams-Weather', '', 'uploads/Anagrams-Weather_3403326552.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'Anagrams-Weather'),
(1191, 59, 1191, 'SequenceMemory-Level7', '', 'uploads/SequenceMemory-Level7_6659360751.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'SequenceMemory-Level7'),
(1192, 60, 1192, 'FindTheTwins-Level3', '', 'uploads/FindTheTwins-Level3_8413515225.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'FindTheTwins-Level3'),
(1193, 61, 1193, 'ShapeVsColorVsPattern-Level1', '', 'uploads/ShapeVsColorVsPattern-Level1_9182052793.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'ShapeVsColorVsPattern-Level1'),
(1194, 62, 1194, 'NumbersOnTheWheel-Level6', '', 'uploads/NumbersOnTheWheel-Level6_2458961391.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'NumbersOnTheWheel-Level6'),
(1195, 63, 1195, 'DividedWords-Level1', '', 'uploads/DividedWords-Level1_9592156563.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'DividedWords-Level1'),
(1196, 59, 1196, 'BugSpot-Level2', '', 'uploads/BugSpot-Level2_807683826.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'BugSpot-Level2'),
(1197, 60, 1197, 'FlipTrick-Level2', '', 'uploads/FlipTrick-Level2_2970519540.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'FlipTrick-Level2'),
(1198, 61, 1198, 'ShapeVsColorVsPattern-Level2', '', 'uploads/ShapeVsColorVsPattern-Level2_533262947.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'ShapeVsColorVsPattern-Level2'),
(1199, 62, 1199, 'MasterVenn-Level2', '', 'uploads/MasterVenn-Level2_6223853942.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'MasterVenn-Level2'),
(1200, 63, 1200, 'DividedWords-Level2', '', 'uploads/DividedWords-Level2_482863192.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'DividedWords-Level2'),
(1201, 59, 1201, 'Fishing', '', 'uploads/Fishing_4694063616.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'Fishing'),
(1202, 60, 1202, 'Face2Face-Level1', '', 'uploads/Face2Face-Level1_5178543743.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'Face2Face-Level1'),
(1203, 61, 1203, 'SpotMe-Level1', '', 'uploads/SpotMe-Level1_2213080883.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'SpotMe-Level1'),
(1204, 62, 1204, 'NumberDecode', '', 'uploads/NumberDecode-Level1_5552706075.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'NumberDecode'),
(1205, 63, 1205, 'WhoAmI-Fruits', '', 'uploads/WhoAmI-Fruits_91387722.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'WhoAmI-Fruits'),
(1206, 59, 1206, 'BalloonBurst-A1', '', 'uploads/BalloonBurst-Level2_244336309.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'BalloonBurst-A1'),
(1207, 60, 1207, 'AlphaNumberRead', '', 'uploads/AlphaNumberRead_8101214673.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'AlphaNumberRead'),
(1208, 61, 1208, 'WordSpell-Level1', '', 'uploads/WordSpell-Level1_4793716236.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'WordSpell-Level1'),
(1209, 62, 1209, 'Reshuffle', '', 'uploads/Reshuffle-Level1_9448890620.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'Reshuffle'),
(1210, 63, 1210, 'Anagrams-Food', '', 'uploads/Anagrams-Food_9358940329.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'Anagrams-Food'),
(1211, 59, 1211, 'SequenceMemory-Level2', '', 'uploads/SequenceMemory-Level2_9874571016.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'SequenceMemory-Level2'),
(1212, 60, 1212, 'MissingPiece-Level1', '', 'uploads/MissingPiece-Level1_5453919009.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'MissingPiece-Level1'),
(1213, 61, 1213, 'NumberJigsaw-Level2', '', 'uploads/NumberJigsaw-Level2_5454463027.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'NumberJigsaw-Level2'),
(1214, 62, 1214, 'Reshuffle-Level2', '', 'uploads/Reshuffle-Level2_5333331595.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'Reshuffle-Level2'),
(1215, 63, 1215, 'VowelMagic', '', 'uploads/VowelMagic_9324571550.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'VowelMagic'),
(1216, 59, 1216, 'WhatsInStore-Level1', '', 'uploads/WhatsInStore-Level1_99412277.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'WhatsInStore-Level1'),
(1217, 60, 1217, 'FormTheSquare-Level2', '', 'uploads/FormTheSquare-Level2_925395623.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'FormTheSquare-Level2'),
(1218, 61, 1218, 'DeepUnder-Level2', '', 'uploads/DeepUnder-Level2_5933240540.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'DeepUnder-Level2'),
(1219, 62, 1219, 'WordWalls-Level2', '', 'uploads/WordWalls-Level2_7409162675.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'WordWalls-Level2'),
(1220, 63, 1220, 'ArrangeTheWords-Level2', '', 'uploads/ArrangeTheWords-Level2_2614120254.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'ArrangeTheWords-Level2'),
(1221, 59, 1221, 'BackTrack-Level2', '', 'uploads/BackTrack-Level2_16276659.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'BackTrack-Level2'),
(1222, 60, 1222, 'ReverseReading-Level3', '', 'uploads/ReverseReading-Level3_5393561688.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'ReverseReading-Level3'),
(1223, 61, 1223, 'ShapeVsColor', '', 'uploads/ShapeVsColor_5882827830.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'ShapeVsColor'),
(1224, 62, 1224, 'NumberSeries-Level1', '', 'uploads/NumberSeries-Level1_292791444.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'NumberSeries-Level1'),
(1225, 63, 1225, 'WordStem', '', 'uploads/WordStem_1920470679.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'WordStem'),
(1226, 59, 1226, 'MemoryCheck-Level6', '', 'uploads/MemoryCheck-Level6_2935850583.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'MemoryCheck-Level6'),
(1227, 60, 1227, 'MissingPiece-Level3', '', 'uploads/MissingPiece-Level3_1563094099.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'MissingPiece-Level3'),
(1228, 61, 1228, 'ShapeRollers-Level3', '', 'uploads/ShapeRollers-Level3_6991897872.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'ShapeRollers-Level3');
INSERT INTO `sk_games` (`ID`, `skill_ID`, `game_masterID`, `name`, `swf_path`, `image_path`, `description`, `status`, `created_by`, `created_date`, `modified_by`, `modified_date`, `game_html`) VALUES
(1229, 62, 1229, 'ColorGuess', '', 'uploads/ColorGuess_7757099242.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'ColorGuess'),
(1230, 63, 1230, 'ArrangeTheWords-Level5', '', 'uploads/ArrangeTheWords-Level5_4423534446.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'ArrangeTheWords-Level5'),
(1231, 59, 1231, 'SpotMyPlace-Level1', '', 'uploads/SpotMyPlace-Level1_8555905618.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'SpotMyPlace-Level1'),
(1232, 60, 1232, 'MissingPiece-Level4', '', 'uploads/MissingPiece-Level4_1507440302.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'MissingPiece-Level4'),
(1233, 61, 1233, 'BalloonLight-Level5', '', 'uploads/DarkLight-Level5_4619532418.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'BalloonLight-Level5'),
(1234, 62, 1234, 'AnalogyAction-Level2', '', 'uploads/AnalogyAction-Level2_5585269308.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'AnalogyAction-Level2'),
(1235, 63, 1235, 'Rebus-Level1', '', 'uploads/Rebus-Level1_8831456145.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'Rebus-Level1'),
(1236, 59, 1236, 'DropBox-Level2', '', 'uploads/DropBox-Level2_6796904369.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'DropBox-Level2'),
(1237, 60, 1237, 'ChooseThreeToMakeOne-Level2', '', 'uploads/ChooseThreeToMakeOne_6421778858.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'ChooseThreeToMakeOne-Level2'),
(1238, 61, 1238, 'BalloonLight-Level6', '', 'uploads/DarkLight-Level6_8921038703.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'BalloonLight-Level6'),
(1239, 62, 1239, 'NumberPuzzle-Level3', '', 'uploads/NumberPuzzle-Level3_4147070031.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'NumberPuzzle-Level3'),
(1240, 63, 1240, 'JumbledLetters-Level2', '', 'uploads/JumbledLetters-Level2_497916364.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'JumbledLetters-Level2'),
(1242, 60, 1242, 'MatchMe-Level1', '', 'uploads/MatchMe-Level1_3344377102.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'MatchMe-Level1'),
(1245, 63, 1245, 'WhoAmI-DomesticAnimals', '', 'uploads/WhoAmI-DomesticAnimals_818332880.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'WhoAmI-DomesticAnimals'),
(1246, 59, 1246, 'BalloonBurst-A2', '', 'uploads/BalloonBurst-Level2_244336309.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'BalloonBurst-A2'),
(1247, 60, 1247, 'Face2Face-Level2', '', 'uploads/Face2Face-Level2_9013552083.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'Face2Face-Level2'),
(1248, 61, 1248, 'LetterJigsaw-Level1', '', 'uploads/AlphabetJigsaw-Level1_6780601199.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'LetterJigsaw-Level1'),
(1249, 62, 1249, 'NumbersOnTheWheel-A1', '', 'uploads/NumbersOnTheWheel-Level1_5239142207.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'NumbersOnTheWheel-A1'),
(1250, 63, 1250, 'WhoAmI-Flowers', '', 'uploads/WhoAmI-Flowers_4361387616.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'WhoAmI-Flowers'),
(1251, 59, 1251, 'MindCapture-Level4', '', 'uploads/MindCapture-Level4_95845567.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'MindCapture-Level4'),
(1252, 60, 1252, 'AnimalWipe', '', 'uploads/AnimalWipe_6567529789.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'AnimalWipe'),
(1253, 61, 1253, 'CarPark-Level1', '', 'uploads/CarPark-Level1_8054239703.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'CarPark-Level1'),
(1254, 62, 1254, 'WordShapes-Level3', '', 'uploads/WordShapes-Level3_9543727268.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'WordShapes-Level3'),
(1255, 63, 1255, 'WhoAmI-Birthday', '', 'uploads/WhoAmI-Birthday_9790617101.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'WhoAmI-Birthday'),
(1256, 59, 1256, 'WhatsInStore-Level2', '', 'uploads/WhatsInStore-Level2_3776093176.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'WhatsInStore-Level2'),
(1257, 60, 1257, 'FindTheTwins-Level1', '', 'uploads/FindTheTwins-Level1_7979904958.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'FindTheTwins-Level1'),
(1258, 61, 1258, 'BallShooter-Level2', '', 'uploads/Ball_Shooter.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'BallShooter-Level2'),
(1259, 62, 1259, 'FitMeRight-Level1', '', 'uploads/FitMeRight-Level1_9128276687.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'FitMeRight-Level1'),
(1260, 63, 1260, 'Anagrams-Colors', '', 'uploads/Anagrams-Colors_4401654419.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'Anagrams-Colors'),
(1261, 59, 1261, 'MindCapture-Level6', '', 'uploads/MindCapture-Level6_6117593380.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'MindCapture-Level6'),
(1262, 60, 1262, 'ReflectionRead-Level3', '', 'uploads/ReflectionRead-Level3_7118542841.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'ReflectionRead-Level3'),
(1263, 61, 1263, 'DeepUnder-Level3', '', 'uploads/DeepUnder-Level3_9918525810.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'DeepUnder-Level3'),
(1264, 62, 1264, 'AnalogyAction-Level1', '', 'uploads/AnalogyAction-Level1_6299363239.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'AnalogyAction-Level1'),
(1265, 63, 1265, 'RootWords-Level1', '', 'uploads/RootWords-Level1_8710642922.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'RootWords-Level1'),
(1266, 59, 1266, 'WhatsInStore-Level3', '', 'uploads/WhatsInStore-Level3_4075730568.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'WhatsInStore-Level3'),
(1267, 60, 1267, 'ReflectionRead-Level5', '', 'uploads/ReflectionRead-Level5_3237627618.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'ReflectionRead-Level5'),
(1268, 61, 1268, 'BalloonLight-Level4', '', 'uploads/DarkLight-Level4_4173842570.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'BalloonLight-Level4'),
(1269, 62, 1269, 'MasterVenn-Level1', '', 'uploads/MasterVenn-Level1_7031834167.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'MasterVenn-Level1'),
(1270, 63, 1270, 'Anagrams-DolchWords', '', 'uploads/Anagrams-DolchWords_4271674626.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'Anagrams-DolchWords'),
(1271, 59, 1271, 'BugSpot-Level1', '', 'uploads/BugSpot-Level1_4068491952.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'BugSpot-Level1'),
(1272, 60, 1272, 'ReflectionRead-Level4', '', 'uploads/ReflectionRead-Level4_4669125583.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'ReflectionRead-Level4'),
(1273, 61, 1273, 'OddBall-Level1', '', 'uploads/OddBall-Level1_1096781706.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'OddBall-Level1'),
(1274, 62, 1274, 'TakeTurns-Level2', '', 'uploads/TakeTurns-Level2_7725315545.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'TakeTurns-Level2'),
(1275, 63, 1275, 'RootWords-Level2', '', 'uploads/RootWords-Level2_162112307.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'RootWords-Level2'),
(1276, 59, 1276, 'SequenceMemory-Level8', '', 'uploads/SequenceMemory-Level8_6523781293.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'SequenceMemory-Level8'),
(1277, 60, 1277, 'WhoIsNotThere-Level2', '', 'uploads/WhoIsNotThere-Level2_67013050.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'WhoIsNotThere-Level2'),
(1278, 61, 1278, 'OddBall-Level2', '', 'uploads/OddBall-Level2_3363969377.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'OddBall-Level2'),
(1279, 62, 1279, 'SmartRider', '', 'uploads/SmartRider_1083469698.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'SmartRider'),
(1280, 63, 1280, 'ConfusionGalore-Level2', '', 'uploads/ConfusionGalore-Level2_9538272568.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'ConfusionGalore-Level2'),
(1282, 60, 1282, 'CharacterShade-Level1', '', 'uploads/CharacterShade-Level1_3409011624.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'CharacterShade-Level1'),
(1285, 63, 1285, 'WhoAmI-Colors', '', 'uploads/WhoAmI-Colors_1446446431.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'WhoAmI-Colors'),
(1286, 59, 1286, 'MindCapture-Level3', '', 'uploads/MindCapture-Level3_3766070040.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'MindCapture-Level3'),
(1287, 60, 1287, 'ReflectionRead-Level1', '', 'uploads/ReflectionRead-Level1_7608671374.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'ReflectionRead-Level1'),
(1288, 61, 1288, 'SpotMe-Level3', '', 'uploads/SpotMe-Level3_4077972709.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'SpotMe-Level3'),
(1289, 62, 1289, 'NumbersOnTheWheel-A2', '', 'uploads/NumbersOnTheWheel-Level1_5239142207.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'NumbersOnTheWheel-A2'),
(1290, 63, 1290, 'Anagrams-CountryNames', '', 'uploads/Anagrams-CountryNames_9848174657.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'Anagrams-CountryNames'),
(1291, 59, 1291, 'MindCapture-Level5', '', 'uploads/MindCapture-Level5_2807246898.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'MindCapture-Level5'),
(1292, 60, 1292, 'ReverseReading-Level1', '', 'uploads/ReverseReading-Level1_3469542353.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'ReverseReading-Level1'),
(1293, 61, 1293, 'BalloonLight-Level1', '', 'uploads/DarkLight-Level1_1779258348.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'BalloonLight-Level1'),
(1294, 62, 1294, 'WordWalls-Level1', '', 'uploads/WordWalls-Level1_1536627309.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'WordWalls-Level1'),
(1296, 59, 1296, 'BackTrack-Level1', '', 'uploads/BackTrack-Level1_257858377.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'BackTrack-Level1'),
(1297, 60, 1297, 'FormTheSquare-Level1', '', 'uploads/FormTheSquare-Level1_9003437426.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'FormTheSquare-Level1'),
(1298, 61, 1298, 'SpotMe-Level4', '', 'uploads/SpotMe-Level4_1111856144.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'SpotMe-Level4'),
(1299, 62, 1299, 'WordShapes-Level4', '', 'uploads/WordShapes-Level4_9880864322.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'WordShapes-Level4'),
(1300, 63, 1300, 'MissingLetter-Level1', '', 'uploads/MissingLetter-Level1_4396478235.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'MissingLetter-Level1'),
(1301, 59, 1301, 'RouteMemory-Level1', '', 'uploads/RouteMemory-Level1_3141601332.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'RouteMemory-Level1'),
(1302, 60, 1302, 'ReverseReading-Level2', '', 'uploads/ReverseReading-Level2_7025720854.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'ReverseReading-Level2'),
(1303, 61, 1303, 'ShapeRollers-Level1', '', 'uploads/ShapeRollers-Level1_1497070817.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'ShapeRollers-Level1'),
(1305, 63, 1305, 'ArrangeTheWords-Level4', '', 'uploads/ArrangeTheWords-Level4_1263861129.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'ArrangeTheWords-Level4'),
(1306, 59, 1306, 'BackTrack-Level3', '', 'uploads/BackTrack-Level3_4500490999.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'BackTrack-Level3'),
(1307, 60, 1307, 'ReverseReading-Level4', '', 'uploads/ReverseReading-Level4_3547282922.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'ReverseReading-Level4'),
(1308, 61, 1308, 'DiscretePaddle-Level1', '', 'uploads/DiscretePadle-Level1_2005080394.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'DiscretePaddle-Level1'),
(1309, 62, 1309, 'TakeTurns-Level1', '', 'uploads/TakeTurns-Level1_1136886626.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'TakeTurns-Level1'),
(1310, 63, 1310, 'MissingLetter-Level3', '', 'uploads/MissingLetter-Level3_7274801447.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'MissingLetter-Level3'),
(1311, 59, 1311, 'RouteMemory-Level2', '', 'uploads/RouteMemory-Level2_3784374403.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'RouteMemory-Level2'),
(1312, 60, 1312, 'WaterImage-Level1', '', 'uploads/WaterImage-Level1_4578736186.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'WaterImage-Level1'),
(1313, 61, 1313, 'LightRays-Level1', '', 'uploads/LightRays1.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'LightRays-Level1'),
(1314, 62, 1314, 'NumberPuzzle-Level2', '', 'uploads/NumberPuzzle-Level2_6727183759.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'NumberPuzzle-Level2'),
(1315, 63, 1315, 'HomoPhones-Level2', '', 'uploads/HomoPhones-Level2_3726777150.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'HomoPhones-Level2'),
(1316, 59, 1316, 'BallAndBox-Level2', '', 'uploads/BallAndBox-Level2_5648189471.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'BallAndBox-Level2'),
(1318, 61, 1318, 'SpotMe-Level7', '', 'uploads/SpotMe-Level7_2691923594.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'SpotMe-Level7'),
(1319, 62, 1319, 'LogicalSequence', '', 'uploads/LogicalSequence_3583530234.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'LogicalSequence'),
(1320, 63, 1320, 'PrefixRootAndSuffix', '', 'uploads/PrefixRootAndSuffix_204385071.png', '', 'Y', 0, '0000-00-00 00:00:00', 0, '2019-08-05 20:26:32', 'PrefixRootAndSuffix');

-- --------------------------------------------------------

--
-- Table structure for table `sk_gamescore`
--

CREATE TABLE `sk_gamescore` (
  `id` int(11) NOT NULL,
  `gu_id` int(10) NOT NULL,
  `gs_id` int(10) NOT NULL,
  `g_id` int(30) NOT NULL,
  `que_id` int(11) NOT NULL,
  `answer` varchar(20) NOT NULL,
  `useranswer` varchar(55) NOT NULL,
  `game_score` varchar(50) NOT NULL,
  `answer_status` varchar(55) NOT NULL,
  `timeoverstatus` int(11) NOT NULL,
  `responsetime` int(11) NOT NULL,
  `balancetime` int(11) NOT NULL,
  `lastupdate` date NOT NULL,
  `creation_date` date NOT NULL,
  `modified_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `puzzle_cycle` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sk_gamescore`
--

INSERT INTO `sk_gamescore` (`id`, `gu_id`, `gs_id`, `g_id`, `que_id`, `answer`, `useranswer`, `game_score`, `answer_status`, `timeoverstatus`, `responsetime`, `balancetime`, `lastupdate`, `creation_date`, `modified_date`, `puzzle_cycle`) VALUES
(1, 38324, 62, 1204, 22, '0', 'O', '0', 'wrong', 0, 2, 177, '2019-08-06', '2019-08-06', '2019-08-06 10:06:14', 1),
(2, 38324, 62, 1204, 81, '0', 'M', '0', 'wrong', 0, 1, 176, '2019-08-06', '2019-08-06', '2019-08-06 10:06:19', 1),
(3, 38324, 62, 1204, 85, '1', 'I', '8', 'correct', 0, 5, 170, '2019-08-06', '2019-08-06', '2019-08-06 10:06:28', 1),
(4, 38324, 62, 1204, 66, '1', 'I', '0', 'wrong', 0, 1, 169, '2019-08-06', '2019-08-06', '2019-08-06 10:11:56', 1),
(5, 38324, 62, 1204, 96, '1', 'C', '0', 'wrong', 0, 1, 168, '2019-08-06', '2019-08-06', '2019-08-06 10:12:00', 1),
(6, 38324, 62, 1204, 89, '1', 'X', '0', 'wrong', 0, 1, 167, '2019-08-06', '2019-08-06', '2019-08-06 10:12:05', 1),
(7, 38324, 62, 1204, 52, '1', 'A', '0', 'wrong', 0, 1, 166, '2019-08-06', '2019-08-06', '2019-08-06 10:12:09', 1),
(8, 38324, 62, 1204, 59, '2', 'G', '10', 'correct', 0, 1, 165, '2019-08-06', '2019-08-06', '2019-08-06 10:12:14', 1),
(9, 38324, 62, 1204, 4, '3', 'I', '10', 'correct', 0, 1, 164, '2019-08-06', '2019-08-06', '2019-08-06 10:12:18', 1),
(10, 38324, 62, 1204, 1, '3', 'A', '0', 'wrong', 0, 1, 163, '2019-08-06', '2019-08-06', '2019-08-06 10:12:22', 1),
(11, 38324, 62, 1204, 16, '0', 'A', '0', 'wrong', 0, 1, 179, '2019-08-06', '2019-08-06', '2019-08-06 10:17:03', 2),
(12, 38324, 62, 1204, 60, '0', 'V', '0', 'wrong', 0, 1, 178, '2019-08-06', '2019-08-06', '2019-08-06 10:17:07', 2),
(13, 38324, 62, 1204, 69, '0', 'F', '0', 'wrong', 0, 1, 177, '2019-08-06', '2019-08-06', '2019-08-06 10:17:12', 2),
(14, 38324, 62, 1204, 26, '0', 'M', '0', 'wrong', 0, 1, 176, '2019-08-06', '2019-08-06', '2019-08-06 10:17:16', 2),
(15, 38324, 62, 1204, 51, '0', 'F', '0', 'wrong', 0, 1, 175, '2019-08-06', '2019-08-06', '2019-08-06 10:17:21', 2),
(16, 38324, 62, 1204, 88, '0', 'L', '0', 'wrong', 0, 1, 174, '2019-08-06', '2019-08-06', '2019-08-06 10:17:25', 2),
(17, 38324, 62, 1204, 28, '0', 'D', '0', 'wrong', 0, 1, 173, '2019-08-06', '2019-08-06', '2019-08-06 10:17:30', 2),
(18, 38324, 62, 1204, 40, '0', 'C', '0', 'wrong', 0, 1, 172, '2019-08-06', '2019-08-06', '2019-08-06 10:17:34', 2),
(19, 38324, 62, 1204, 90, '0', 'K', '0', 'wrong', 0, 1, 171, '2019-08-06', '2019-08-06', '2019-08-06 10:17:38', 2),
(20, 38324, 62, 1204, 42, '0', 'Q', '0', 'wrong', 0, 1, 170, '2019-08-06', '2019-08-06', '2019-08-06 10:17:43', 2),
(21, 38324, 61, 1043, 3, '0', '1', '0', 'wrong', 0, 1, 179, '2019-08-06', '2019-08-06', '2019-08-06 10:18:08', 1),
(22, 38324, 61, 1043, 29, '1', '1', '10', 'correct', 0, 1, 178, '2019-08-06', '2019-08-06', '2019-08-06 10:18:13', 1),
(23, 38324, 61, 1043, 59, '1', '1', '0', 'wrong', 0, 1, 177, '2019-08-06', '2019-08-06', '2019-08-06 10:18:18', 1),
(24, 38324, 61, 1043, 98, '1', '1', '0', 'wrong', 0, 1, 176, '2019-08-06', '2019-08-06', '2019-08-06 10:18:23', 1),
(25, 38324, 61, 1043, 81, '2', '1', '10', 'correct', 0, 1, 175, '2019-08-06', '2019-08-06', '2019-08-06 10:18:28', 1),
(26, 38324, 61, 1043, 90, '2', '1', '0', 'wrong', 0, 1, 174, '2019-08-06', '2019-08-06', '2019-08-06 10:18:33', 1),
(27, 38324, 61, 1043, 13, '2', '1', '0', 'wrong', 0, 1, 173, '2019-08-06', '2019-08-06', '2019-08-06 10:18:38', 1),
(28, 38324, 61, 1043, 75, '2', '1', '0', 'wrong', 0, 1, 172, '2019-08-06', '2019-08-06', '2019-08-06 10:18:43', 1),
(29, 38324, 61, 1043, 87, '3', '1', '10', 'correct', 0, 1, 171, '2019-08-06', '2019-08-06', '2019-08-06 10:18:48', 1),
(30, 38324, 61, 1043, 12, '3', '1', '0', 'wrong', 0, 1, 170, '2019-08-06', '2019-08-06', '2019-08-06 10:18:53', 1),
(31, 38324, 61, 1043, 71, '0', '1', '0', 'wrong', 0, 1, 179, '2019-08-06', '2019-08-06', '2019-08-06 10:29:26', 2),
(32, 38324, 61, 1043, 62, '1', '1', '10', 'correct', 0, 1, 178, '2019-08-06', '2019-08-06', '2019-08-06 10:29:32', 2),
(33, 38324, 61, 1043, 63, '2', '1', '10', 'correct', 0, 1, 177, '2019-08-06', '2019-08-06', '2019-08-06 10:29:37', 2),
(34, 38324, 61, 1043, 58, '3', '1', '10', 'correct', 0, 1, 176, '2019-08-06', '2019-08-06', '2019-08-06 10:29:43', 2),
(35, 38324, 61, 1043, 0, '3', '1', '0', 'wrong', 0, 1, 175, '2019-08-06', '2019-08-06', '2019-08-06 10:29:48', 2),
(36, 38324, 61, 1043, 32, '3', '1', '0', 'wrong', 0, 1, 174, '2019-08-06', '2019-08-06', '2019-08-06 10:29:53', 2),
(37, 38324, 61, 1043, 66, '3', '1', '0', 'wrong', 0, 1, 173, '2019-08-06', '2019-08-06', '2019-08-06 10:29:58', 2),
(38, 38324, 61, 1043, 68, '3', '1', '0', 'wrong', 0, 1, 172, '2019-08-06', '2019-08-06', '2019-08-06 10:30:03', 2),
(39, 38324, 61, 1043, 24, '3', '1', '0', 'wrong', 0, 98, 73, '2019-08-06', '2019-08-06', '2019-08-06 10:31:46', 2),
(40, 38324, 61, 1043, 3, '3', '1', '0', 'wrong', 0, 1, 72, '2019-08-06', '2019-08-06', '2019-08-06 10:31:51', 2),
(41, 38324, 59, 1121, 68, '1', 'ch2', '10', 'correct', 0, 1, 178, '2019-08-06', '2019-08-06', '2019-08-06 10:32:30', 1),
(42, 38324, 59, 1121, 96, '1', 'ch0', '0', 'wrong', 0, 1, 176, '2019-08-06', '2019-08-06', '2019-08-06 10:32:39', 1),
(43, 38324, 59, 1121, 27, '2', 'ch0', '10', 'correct', 0, 1, 173, '2019-08-06', '2019-08-06', '2019-08-06 10:32:49', 1),
(44, 38324, 59, 1121, 7, '3', 'ch0', '10', 'correct', 0, 1, 171, '2019-08-06', '2019-08-06', '2019-08-06 10:32:58', 1),
(45, 38324, 59, 1121, 63, '3', 'ch2', '0', 'wrong', 0, 1, 170, '2019-08-06', '2019-08-06', '2019-08-06 10:33:06', 1),
(46, 38324, 59, 1121, 59, '3', 'ch2', '0', 'wrong', 0, 1, 169, '2019-08-06', '2019-08-06', '2019-08-06 10:33:15', 1),
(47, 38324, 59, 1121, 32, '3', 'ch0', '0', 'wrong', 0, 1, 168, '2019-08-06', '2019-08-06', '2019-08-06 10:33:23', 1),
(48, 38324, 59, 1121, 23, '4', 'ch2', '10', 'correct', 0, 1, 167, '2019-08-06', '2019-08-06', '2019-08-06 10:33:32', 1),
(49, 38324, 59, 1121, 90, '4', 'ch0', '0', 'wrong', 0, 1, 166, '2019-08-06', '2019-08-06', '2019-08-06 10:33:40', 1),
(50, 38324, 59, 1121, 45, '5', 'ch0', '10', 'correct', 0, 1, 165, '2019-08-06', '2019-08-06', '2019-08-06 10:33:48', 1),
(51, 38324, 59, 1121, 90, '1', 'ch0', '10', 'correct', 0, 1, 177, '2019-08-06', '2019-08-06', '2019-08-06 10:34:12', 2),
(52, 38324, 59, 1121, 25, '1', 'ch0', '0', 'wrong', 0, 1, 176, '2019-08-06', '2019-08-06', '2019-08-06 10:34:20', 2),
(53, 38324, 59, 1121, 15, '1', 'ch0', '0', 'wrong', 0, 9, 166, '2019-08-06', '2019-08-06', '2019-08-06 10:34:37', 2),
(54, 38324, 59, 1121, 79, '2', 'ch0', '10', 'correct', 0, 1, 165, '2019-08-06', '2019-08-06', '2019-08-06 10:34:46', 2),
(55, 38324, 59, 1121, 2, '2', 'ch0', '0', 'wrong', 0, 1, 164, '2019-08-06', '2019-08-06', '2019-08-06 10:34:53', 2),
(56, 38324, 59, 1121, 0, '3', 'ch2', '10', 'correct', 0, 3, 159, '2019-08-06', '2019-08-06', '2019-08-06 10:35:05', 2),
(57, 38324, 59, 1121, 97, '4', 'ch0', '10', 'correct', 0, 1, 158, '2019-08-06', '2019-08-06', '2019-08-06 10:35:14', 2),
(58, 38324, 59, 1121, 12, '4', 'ch2', '0', 'wrong', 0, 1, 156, '2019-08-06', '2019-08-06', '2019-08-06 10:35:23', 2),
(59, 38324, 59, 1121, 20, '5', 'ch0', '10', 'correct', 0, 1, 155, '2019-08-06', '2019-08-06', '2019-08-06 10:35:32', 2),
(60, 38324, 59, 1121, 80, '5', 'ch0', '0', 'wrong', 0, 1, 154, '2019-08-06', '2019-08-06', '2019-08-06 10:35:39', 2),
(61, 38324, 63, 1165, 2, '1', '0', '8', 'correct', 0, 5, 174, '2019-08-06', '2019-08-06', '2019-08-06 10:36:10', 1),
(62, 38324, 63, 1165, 6, '2', '17', '10', 'correct', 0, 1, 172, '2019-08-06', '2019-08-06', '2019-08-06 10:36:16', 1),
(63, 38324, 63, 1165, 4, '3', '20', '10', 'correct', 0, 1, 170, '2019-08-06', '2019-08-06', '2019-08-06 10:36:21', 1),
(64, 38324, 63, 1165, 9, '4', '19', '10', 'correct', 0, 1, 168, '2019-08-06', '2019-08-06', '2019-08-06 10:36:40', 1),
(65, 38324, 63, 1165, 0, '5', '8', '10', 'correct', 0, 1, 166, '2019-08-06', '2019-08-06', '2019-08-06 10:36:45', 1),
(66, 38324, 63, 1165, 3, '6', '5', '10', 'correct', 0, 1, 164, '2019-08-06', '2019-08-06', '2019-08-06 10:36:50', 1),
(67, 38324, 63, 1165, 8, '6', '2', '0', 'wrong', 0, 1, 163, '2019-08-06', '2019-08-06', '2019-08-06 10:36:55', 1),
(68, 38324, 63, 1165, 1, '7', '1', '10', 'correct', 0, 1, 161, '2019-08-06', '2019-08-06', '2019-08-06 10:37:00', 1),
(69, 38324, 63, 1165, 7, '8', '0', '10', 'correct', 0, 1, 159, '2019-08-06', '2019-08-06', '2019-08-06 10:37:06', 1),
(70, 38324, 63, 1165, 5, '9', '14', '10', 'correct', 0, 1, 157, '2019-08-06', '2019-08-06', '2019-08-06 10:37:11', 1),
(71, 38324, 63, 1165, 4, '0', '5', '0', 'wrong', 0, 2, 177, '2019-08-06', '2019-08-06', '2019-08-06 10:37:34', 2),
(72, 38324, 63, 1165, 9, '1', '15', '10', 'correct', 0, 3, 172, '2019-08-06', '2019-08-06', '2019-08-06 10:37:42', 2),
(73, 38324, 63, 1165, 0, '1', '15', '0', 'wrong', 0, 1, 170, '2019-08-06', '2019-08-06', '2019-08-06 10:37:47', 2),
(74, 38324, 63, 1165, 7, '1', '9', '0', 'wrong', 0, 13, 156, '2019-08-06', '2019-08-06', '2019-08-06 10:38:04', 2),
(75, 38324, 63, 1165, 6, '1', '18', '0', 'wrong', 0, 44, 111, '2019-08-06', '2019-08-06', '2019-08-06 10:38:53', 2),
(76, 38324, 63, 1165, 8, '2', '8', '10', 'correct', 0, 2, 107, '2019-08-06', '2019-08-06', '2019-08-06 10:39:00', 2),
(77, 38324, 63, 1165, 2, '2', '15', '0', 'wrong', 0, 5, 101, '2019-08-06', '2019-08-06', '2019-08-06 10:39:09', 2),
(78, 38324, 63, 1165, 1, '2', '16', '0', 'wrong', 0, 1, 100, '2019-08-06', '2019-08-06', '2019-08-06 10:39:13', 2),
(79, 38324, 63, 1165, 3, '2', '15', '0', 'wrong', 0, 1, 99, '2019-08-06', '2019-08-06', '2019-08-06 10:39:17', 2),
(80, 38324, 63, 1165, 5, '3', '14', '10', 'correct', 0, 1, 97, '2019-08-06', '2019-08-06', '2019-08-06 10:39:22', 2),
(81, 60498, 61, 1003, 24, '1', '1', '10', 'correct', 0, 1, 179, '2019-06-09', '2019-08-14', '2019-08-14 11:59:45', 1),
(82, 60498, 61, 1003, 14, '2', '1', '10', 'correct', 0, 1, 178, '2019-06-09', '2019-08-14', '2019-08-14 11:59:45', 1),
(83, 60498, 61, 1003, 22, '2', '2', '0', 'wrong', 0, 1, 177, '2019-06-09', '2019-08-14', '2019-08-14 11:59:45', 1),
(84, 60498, 61, 1003, 9, '2', '2', '0', 'wrong', 0, 1, 175, '2019-06-09', '2019-08-14', '2019-08-14 11:59:45', 1),
(85, 60498, 61, 1003, 12, '3', '1', '10', 'correct', 0, 1, 173, '2019-06-09', '2019-08-14', '2019-08-14 11:59:45', 1),
(86, 60498, 61, 1003, 13, '4', '1', '10', 'correct', 0, 1, 172, '2019-06-09', '2019-08-14', '2019-08-14 11:59:45', 1),
(87, 60498, 61, 1003, 16, '4', '2', '0', 'wrong', 0, 1, 171, '2019-06-09', '2019-08-14', '2019-08-14 11:59:45', 1),
(88, 60498, 61, 1003, 19, '5', '1', '10', 'correct', 0, 1, 170, '2019-06-09', '2019-08-14', '2019-08-14 11:59:45', 1),
(89, 60498, 61, 1003, 10, '5', '2', '0', 'wrong', 0, 1, 169, '2019-06-09', '2019-08-14', '2019-08-14 11:59:45', 1),
(90, 60498, 61, 1003, 11, '5', '2', '0', 'wrong', 0, 9, 159, '2019-06-09', '2019-08-14', '2019-08-14 11:59:45', 1),
(91, 60498, 61, 1003, 13, '0', '2', '0', 'wrong', 0, 1, 179, '2019-06-09', '2019-08-14', '2019-08-14 11:59:45', 2),
(92, 60498, 61, 1003, 22, '0', '2', '0', 'wrong', 0, 1, 178, '2019-06-09', '2019-08-14', '2019-08-14 11:59:45', 2),
(93, 60498, 61, 1003, 7, '1', '1', '10', 'correct', 0, 1, 177, '2019-06-09', '2019-08-14', '2019-08-14 11:59:45', 2),
(94, 60498, 61, 1003, 24, '2', '1', '10', 'correct', 0, 1, 176, '2019-06-09', '2019-08-14', '2019-08-14 11:59:45', 2),
(95, 60498, 61, 1003, 4, '3', '1', '10', 'correct', 0, 1, 175, '2019-06-09', '2019-08-14', '2019-08-14 11:59:45', 2),
(96, 60498, 61, 1003, 17, '4', '1', '10', 'correct', 0, 1, 174, '2019-06-09', '2019-08-14', '2019-08-14 11:59:45', 2),
(97, 60498, 61, 1003, 12, '4', '2', '0', 'wrong', 0, 1, 173, '2019-06-09', '2019-08-14', '2019-08-14 11:59:45', 2),
(98, 60498, 61, 1003, 9, '5', '1', '10', 'correct', 0, 1, 172, '2019-06-09', '2019-08-14', '2019-08-14 11:59:45', 2),
(99, 60498, 61, 1003, 3, '5', '2', '0', 'wrong', 0, 1, 171, '2019-06-09', '2019-08-14', '2019-08-14 11:59:45', 2),
(100, 60498, 61, 1003, 14, '5', '2', '0', 'wrong', 0, 1, 170, '2019-06-09', '2019-08-14', '2019-08-14 11:59:45', 2),
(101, 60498, 61, 1208, 9, '1', '10', '9', 'correct', 0, 4, 175, '2019-06-10', '2019-08-14', '2019-08-14 12:24:34', 1),
(102, 60498, 61, 1208, 7, '1', 'null', '0', 'wrong', 0, 1, 174, '2019-06-10', '2019-08-14', '2019-08-14 12:24:34', 1),
(103, 60498, 61, 1208, 1, '1', '12', '0', 'wrong', 0, 1, 173, '2019-06-10', '2019-08-14', '2019-08-14 12:24:34', 1),
(104, 60498, 61, 1208, 6, '2', '4', '10', 'correct', 0, 1, 172, '2019-06-10', '2019-08-14', '2019-08-14 12:24:34', 1),
(105, 60498, 61, 1208, 5, '2', '4', '0', 'wrong', 0, 48, 123, '2019-06-10', '2019-08-14', '2019-08-14 12:24:34', 1),
(106, 60498, 61, 1208, 3, '3', '4', '10', 'correct', 0, 3, 119, '2019-06-10', '2019-08-14', '2019-08-14 12:24:34', 1),
(107, 60498, 61, 1208, 8, '3', '3', '0', 'wrong', 0, 2, 116, '2019-06-10', '2019-08-14', '2019-08-14 12:24:34', 1),
(108, 60498, 61, 1208, 4, '4', '10', '10', 'correct', 0, 1, 115, '2019-06-10', '2019-08-14', '2019-08-14 12:24:34', 1),
(109, 60498, 61, 1208, 0, '4', '10', '0', 'wrong', 0, 1, 114, '2019-06-10', '2019-08-14', '2019-08-14 12:24:34', 1),
(110, 60498, 61, 1208, 2, '4', '13', '0', 'wrong', 0, 1, 113, '2019-06-10', '2019-08-14', '2019-08-14 12:24:34', 1),
(111, 60498, 61, 1208, 6, '1', '4', '10', 'correct', 0, 1, 178, '2019-06-10', '2019-08-14', '2019-08-14 12:24:34', 2),
(112, 60498, 61, 1208, 0, '1', '4', '0', 'wrong', 0, 4, 173, '2019-06-10', '2019-08-14', '2019-08-14 12:24:34', 2),
(113, 60498, 61, 1208, 7, '1', 'NotAnswered', '0', 'U', 0, 173, 0, '2019-06-10', '2019-08-14', '2019-08-14 12:24:34', 2),
(114, 60498, 61, 1043, 95, '0', '0', '0', 'wrong', 0, 1, 179, '2019-06-11', '2019-08-14', '2019-08-14 14:37:42', 1),
(115, 60498, 61, 1043, 23, '0', '2', '0', 'wrong', 0, 1, 177, '2019-06-11', '2019-08-14', '2019-08-14 14:37:42', 1),
(116, 60498, 61, 1043, 65, '1', '2', '10', 'correct', 0, 1, 176, '2019-06-11', '2019-08-14', '2019-08-14 14:37:42', 1),
(117, 60498, 61, 1043, 14, '1', '1', '0', 'wrong', 0, 1, 174, '2019-06-11', '2019-08-14', '2019-08-14 14:37:42', 1),
(118, 60498, 61, 1043, 51, '2', '1', '10', 'correct', 0, 1, 172, '2019-06-11', '2019-08-14', '2019-08-14 14:37:42', 1),
(119, 60498, 61, 1043, 71, '2', '1', '0', 'wrong', 0, 1, 171, '2019-06-11', '2019-08-14', '2019-08-14 14:37:42', 1),
(120, 60498, 61, 1043, 96, '2', '2', '0', 'wrong', 0, 1, 170, '2019-06-11', '2019-08-14', '2019-08-14 14:37:42', 1),
(121, 60498, 61, 1043, 72, '2', '2', '0', 'wrong', 0, 1, 168, '2019-06-11', '2019-08-14', '2019-08-14 14:37:42', 1),
(122, 60498, 61, 1043, 32, '3', '2', '10', 'correct', 0, 1, 167, '2019-06-11', '2019-08-14', '2019-08-14 14:37:42', 1),
(123, 60498, 61, 1043, 31, '4', '0', '10', 'correct', 0, 1, 165, '2019-06-11', '2019-08-14', '2019-08-14 14:37:42', 1),
(124, 60498, 61, 1043, 70, '0', '1', '0', 'wrong', 0, 1, 179, '2019-06-11', '2019-08-14', '2019-08-14 14:37:42', 2),
(125, 60498, 61, 1043, 37, '0', '1', '0', 'wrong', 0, 1, 178, '2019-06-11', '2019-08-14', '2019-08-14 14:37:42', 2),
(126, 60498, 61, 1043, 39, '0', '1', '0', 'wrong', 0, 1, 177, '2019-06-11', '2019-08-14', '2019-08-14 14:37:42', 2),
(127, 60498, 61, 1043, 17, '0', '1', '0', 'wrong', 0, 2, 174, '2019-06-11', '2019-08-14', '2019-08-14 14:37:42', 2),
(128, 60498, 61, 1043, 11, '0', '1', '0', 'wrong', 0, 1, 173, '2019-06-11', '2019-08-14', '2019-08-14 14:37:42', 2),
(129, 60498, 61, 1043, 32, '0', '1', '0', 'wrong', 0, 1, 172, '2019-06-11', '2019-08-14', '2019-08-14 14:37:42', 2),
(130, 60498, 61, 1043, 0, '0', '1', '0', 'wrong', 0, 1, 171, '2019-06-11', '2019-08-14', '2019-08-14 14:37:42', 2),
(131, 60498, 61, 1043, 95, '0', '0', '0', 'wrong', 0, 1, 170, '2019-06-11', '2019-08-14', '2019-08-14 14:37:42', 2),
(132, 60498, 61, 1043, 45, '0', '2', '0', 'wrong', 0, 1, 169, '2019-06-11', '2019-08-14', '2019-08-14 14:37:42', 2),
(133, 60498, 61, 1043, 33, '1', '1', '10', 'correct', 0, 1, 167, '2019-06-11', '2019-08-14', '2019-08-14 14:37:42', 2),
(134, 60498, 61, 1163, 60, '0', '10', '0', 'wrong', 0, 2, 177, '2019-07-01', '2019-08-19', '2019-08-19 07:25:43', 1),
(135, 60498, 61, 1163, 85, '1', '10', '10', 'correct', 0, 1, 175, '2019-07-01', '2019-08-19', '2019-08-19 07:25:43', 1),
(136, 60498, 61, 1163, 95, '2', '5', '10', 'correct', 0, 1, 173, '2019-07-01', '2019-08-19', '2019-08-19 07:25:43', 1),
(137, 60498, 61, 1163, 57, '3', '2', '10', 'correct', 0, 1, 171, '2019-07-01', '2019-08-19', '2019-08-19 07:25:43', 1),
(138, 60498, 61, 1163, 30, '4', '10', '10', 'correct', 0, 1, 168, '2019-07-01', '2019-08-19', '2019-08-19 07:25:43', 1),
(139, 60498, 61, 1163, 35, '5', '11', '10', 'correct', 0, 1, 166, '2019-07-01', '2019-08-19', '2019-08-19 07:25:43', 1),
(140, 60498, 61, 1163, 11, '6', '2', '8', 'correct', 0, 5, 159, '2019-07-01', '2019-08-19', '2019-08-19 07:25:43', 1),
(141, 60498, 61, 1163, 4, '7', '1', '10', 'correct', 0, 1, 157, '2019-07-01', '2019-08-19', '2019-08-19 07:25:43', 1),
(142, 60498, 61, 1163, 6, '7', '3', '0', 'wrong', 0, 5, 151, '2019-07-01', '2019-08-19', '2019-08-19 07:25:43', 1),
(143, 60498, 61, 1163, 65, '8', '7', '10', 'correct', 0, 1, 149, '2019-07-01', '2019-08-19', '2019-08-19 07:25:43', 1),
(144, 60498, 61, 1163, 50, '0', '9', '0', 'wrong', 0, 3, 176, '2019-07-01', '2019-08-19', '2019-08-19 07:25:43', 2),
(145, 60498, 61, 1163, 66, '1', '5', '10', 'correct', 0, 1, 174, '2019-07-01', '2019-08-19', '2019-08-19 07:25:43', 2),
(146, 60498, 61, 1163, 79, '2', '6', '10', 'correct', 0, 1, 172, '2019-07-01', '2019-08-19', '2019-08-19 07:25:43', 2),
(147, 60498, 61, 1163, 59, '3', '10', '10', 'correct', 0, 1, 170, '2019-07-01', '2019-08-19', '2019-08-19 07:25:43', 2),
(148, 60498, 61, 1163, 29, '4', '7', '10', 'correct', 0, 1, 168, '2019-07-01', '2019-08-19', '2019-08-19 07:25:43', 2),
(149, 60498, 61, 1163, 1, '4', '5', '0', 'wrong', 0, 15, 152, '2019-07-01', '2019-08-19', '2019-08-19 07:25:43', 2),
(150, 60498, 61, 1163, 70, '5', '8', '10', 'correct', 0, 1, 150, '2019-07-01', '2019-08-19', '2019-08-19 07:25:43', 2),
(151, 60498, 61, 1163, 9, '6', '4', '10', 'correct', 0, 3, 146, '2019-07-01', '2019-08-19', '2019-08-19 07:25:43', 2),
(152, 60498, 61, 1163, 96, '6', '2', '0', 'wrong', 0, 9, 136, '2019-07-01', '2019-08-19', '2019-08-19 07:25:43', 2),
(153, 60498, 61, 1163, 61, '7', '0', '10', 'correct', 0, 1, 134, '2019-07-01', '2019-08-19', '2019-08-19 07:25:43', 2),
(154, 60498, 60, 1242, 27, '1', '4', '10', 'correct', 0, 2, 176, '2019-07-01', '2019-08-19', '2019-08-19 07:25:43', 1),
(155, 60498, 60, 1242, 60, '2', '2', '10', 'correct', 0, 2, 173, '2019-07-01', '2019-08-19', '2019-08-19 07:25:43', 1),
(156, 60498, 60, 1242, 66, '3', '4', '10', 'correct', 0, 3, 168, '2019-07-01', '2019-08-19', '2019-08-19 07:25:43', 1),
(157, 60498, 60, 1242, 83, '4', '1', '10', 'correct', 0, 1, 166, '2019-07-01', '2019-08-19', '2019-08-19 07:25:43', 1),
(158, 60498, 60, 1242, 99, '5', '4', '5', 'correct', 0, 8, 156, '2019-07-01', '2019-08-19', '2019-08-19 07:25:43', 1),
(159, 60498, 60, 1242, 59, '6', '1', '6', 'correct', 0, 7, 147, '2019-07-01', '2019-08-19', '2019-08-19 07:25:43', 1),
(160, 60498, 60, 1242, 62, '7', '1', '10', 'correct', 0, 2, 143, '2019-07-01', '2019-08-19', '2019-08-19 07:25:43', 1),
(161, 60498, 60, 1242, 78, '8', '4', '10', 'correct', 0, 1, 141, '2019-07-01', '2019-08-19', '2019-08-19 07:25:43', 1),
(162, 60498, 60, 1242, 24, '9', '0', '10', 'correct', 0, 2, 137, '2019-07-01', '2019-08-19', '2019-08-19 07:25:43', 1),
(163, 60498, 60, 1242, 61, '10', '0', '10', 'correct', 0, 1, 134, '2019-07-01', '2019-08-19', '2019-08-19 07:25:43', 1),
(164, 60498, 60, 1242, 67, '1', '3', '10', 'correct', 0, 3, 175, '2019-07-01', '2019-08-19', '2019-08-19 07:25:43', 2),
(165, 60498, 60, 1242, 64, '2', '3', '10', 'correct', 0, 1, 172, '2019-07-01', '2019-08-19', '2019-08-19 07:25:43', 2),
(166, 60498, 60, 1242, 29, '3', '4', '10', 'correct', 0, 2, 168, '2019-07-01', '2019-08-19', '2019-08-19 07:25:43', 2),
(167, 60498, 60, 1242, 4, '4', '2', '10', 'correct', 0, 2, 165, '2019-07-01', '2019-08-19', '2019-08-19 07:25:43', 2),
(168, 60498, 60, 1242, 38, '4', '4', '0', 'wrong', 0, 1, 164, '2019-07-01', '2019-08-19', '2019-08-19 07:25:43', 2),
(169, 60498, 60, 1242, 68, '5', '4', '10', 'correct', 0, 2, 161, '2019-07-01', '2019-08-19', '2019-08-19 07:25:43', 2),
(170, 60498, 60, 1242, 54, '6', '3', '10', 'correct', 0, 1, 158, '2019-07-01', '2019-08-19', '2019-08-19 07:25:43', 2),
(171, 60498, 60, 1242, 98, '7', '3', '10', 'correct', 0, 1, 155, '2019-07-01', '2019-08-19', '2019-08-19 07:25:43', 2),
(172, 60498, 60, 1242, 86, '8', '0', '5', 'correct', 0, 8, 146, '2019-07-01', '2019-08-19', '2019-08-19 07:25:43', 2),
(173, 60498, 60, 1242, 32, '9', '0', '10', 'correct', 0, 2, 142, '2019-07-01', '2019-08-19', '2019-08-19 07:25:43', 2),
(174, 60498, 60, 1122, 38, '0', 'ch2', '0', 'wrong', 0, 1, 178, '2019-08-19', '2019-08-19', '2019-08-19 13:05:23', 1),
(175, 60498, 60, 1122, 5, '0', 'ch3', '0', 'wrong', 0, 1, 177, '2019-08-19', '2019-08-19', '2019-08-19 13:05:27', 1),
(176, 60498, 60, 1122, 9, '0', 'ch3', '0', 'wrong', 0, 1, 176, '2019-08-19', '2019-08-19', '2019-08-19 13:05:32', 1),
(177, 60498, 60, 1122, 35, '0', 'ch2', '0', 'wrong', 0, 1, 174, '2019-08-19', '2019-08-19', '2019-08-19 13:05:36', 1),
(178, 60498, 60, 1122, 45, '1', 'ch1', '10', 'correct', 0, 1, 172, '2019-08-19', '2019-08-19', '2019-08-19 13:05:40', 1),
(179, 60498, 60, 1122, 26, '2', 'ch1', '10', 'correct', 0, 2, 169, '2019-08-19', '2019-08-19', '2019-08-19 13:05:47', 1),
(180, 60498, 60, 1122, 43, '3', 'ch1', '10', 'correct', 0, 1, 167, '2019-08-19', '2019-08-19', '2019-08-19 13:05:52', 1),
(181, 60498, 60, 1122, 30, '3', 'ch3', '0', 'wrong', 0, 1, 165, '2019-08-19', '2019-08-19', '2019-08-19 13:05:56', 1),
(182, 60498, 60, 1122, 27, '4', 'ch1', '10', 'correct', 0, 1, 163, '2019-08-19', '2019-08-19', '2019-08-19 13:06:00', 1),
(183, 60498, 60, 1122, 46, '5', 'ch1', '10', 'correct', 0, 3, 159, '2019-08-19', '2019-08-19', '2019-08-19 13:06:07', 1),
(184, 60498, 60, 1122, 17, '0', 'ch3', '0', 'wrong', 0, 1, 179, '2019-08-19', '2019-08-19', '2019-08-19 13:06:44', 2),
(185, 60498, 60, 1122, 23, '1', 'ch1', '10', 'correct', 0, 1, 177, '2019-08-19', '2019-08-19', '2019-08-19 13:06:50', 2),
(186, 60498, 60, 1122, 41, '2', 'ch1', '10', 'correct', 0, 1, 175, '2019-08-19', '2019-08-19', '2019-08-19 13:06:54', 2),
(187, 60498, 60, 1122, 16, '2', 'ch3', '0', 'wrong', 0, 1, 174, '2019-08-19', '2019-08-19', '2019-08-19 13:06:58', 2),
(188, 60498, 60, 1122, 46, '2', 'ch2', '0', 'wrong', 0, 1, 173, '2019-08-19', '2019-08-19', '2019-08-19 13:07:02', 2),
(189, 60498, 60, 1122, 36, '2', 'ch2', '0', 'wrong', 0, 5, 167, '2019-08-19', '2019-08-19', '2019-08-19 13:07:11', 2),
(190, 60498, 60, 1122, 42, '2', 'ch3', '0', 'wrong', 0, 2, 164, '2019-08-19', '2019-08-19', '2019-08-19 13:07:17', 2),
(191, 60498, 60, 1122, 9, '2', 'ch2', '0', 'wrong', 0, 1, 162, '2019-08-19', '2019-08-19', '2019-08-19 13:07:21', 2),
(192, 60498, 60, 1122, 30, '2', 'ch2', '0', 'wrong', 0, 1, 161, '2019-08-19', '2019-08-19', '2019-08-19 13:07:25', 2),
(193, 60498, 60, 1122, 38, '2', 'ch3', '0', 'wrong', 0, 1, 160, '2019-08-19', '2019-08-19', '2019-08-19 13:07:29', 2),
(194, 60498, 61, 1123, 1, '1', 'ch1', '10', 'correct', 0, 1, 179, '2019-08-19', '2019-08-19', '2019-08-19 13:08:52', 1),
(195, 60498, 61, 1123, 4, '2', 'ch4', '10', 'correct', 0, 1, 178, '2019-08-19', '2019-08-19', '2019-08-19 13:08:58', 1),
(196, 60498, 61, 1123, 14, '3', 'ch14', '10', 'correct', 0, 1, 177, '2019-08-19', '2019-08-19', '2019-08-19 13:09:04', 1),
(197, 60498, 61, 1123, 13, '4', 'ch13', '10', 'correct', 0, 2, 174, '2019-08-19', '2019-08-19', '2019-08-19 13:09:12', 1),
(198, 60498, 61, 1123, 15, '5', 'ch15', '10', 'correct', 0, 1, 173, '2019-08-19', '2019-08-19', '2019-08-19 13:09:18', 1),
(199, 60498, 61, 1123, 13, '6', 'ch13', '10', 'correct', 0, 1, 172, '2019-08-19', '2019-08-19', '2019-08-19 13:09:24', 1),
(200, 60498, 61, 1123, 11, '7', 'ch11', '10', 'correct', 0, 1, 171, '2019-08-19', '2019-08-19', '2019-08-19 13:09:30', 1),
(201, 60498, 61, 1123, 1, '8', 'ch1', '10', 'correct', 0, 1, 169, '2019-08-19', '2019-08-19', '2019-08-19 13:09:37', 1),
(202, 60498, 61, 1123, 1, '9', 'ch1', '10', 'correct', 0, 3, 165, '2019-08-19', '2019-08-19', '2019-08-19 13:09:46', 1),
(203, 60498, 61, 1123, 5, '10', 'ch5', '10', 'correct', 0, 1, 164, '2019-08-19', '2019-08-19', '2019-08-19 13:09:52', 1),
(204, 60498, 61, 1123, 15, '1', 'ch15', '10', 'correct', 0, 1, 179, '2019-08-19', '2019-08-19', '2019-08-19 13:10:24', 2),
(205, 60498, 61, 1123, 14, '1', 'ch15', '0', 'wrong', 0, 1, 178, '2019-08-19', '2019-08-19', '2019-08-19 13:10:30', 2),
(206, 60498, 61, 1123, 18, '1', 'ch16', '0', 'wrong', 0, 2, 175, '2019-08-19', '2019-08-19', '2019-08-19 13:10:39', 2),
(207, 60498, 61, 1123, 2, '2', 'ch2', '10', 'correct', 0, 1, 174, '2019-08-19', '2019-08-19', '2019-08-19 13:10:45', 2),
(208, 60498, 61, 1123, 9, '3', 'ch9', '10', 'correct', 0, 1, 173, '2019-08-19', '2019-08-19', '2019-08-19 13:10:51', 2),
(209, 60498, 61, 1123, 12, '4', 'ch12', '10', 'correct', 0, 1, 172, '2019-08-19', '2019-08-19', '2019-08-19 13:10:57', 2),
(210, 60498, 61, 1123, 17, '5', 'ch17', '10', 'correct', 0, 1, 170, '2019-08-19', '2019-08-19', '2019-08-19 13:11:04', 2),
(211, 60498, 61, 1123, 18, '6', 'ch18', '10', 'correct', 0, 1, 168, '2019-08-19', '2019-08-19', '2019-08-19 13:11:11', 2),
(212, 60498, 61, 1123, 13, '7', 'ch13', '10', 'correct', 0, 1, 167, '2019-08-19', '2019-08-19', '2019-08-19 13:11:17', 2),
(213, 60498, 61, 1123, 3, '8', 'ch3', '10', 'correct', 0, 1, 166, '2019-08-19', '2019-08-19', '2019-08-19 13:11:23', 2);

-- --------------------------------------------------------

--
-- Table structure for table `sk_games_plan`
--

CREATE TABLE `sk_games_plan` (
  `ID` int(11) NOT NULL,
  `school_ID` int(11) NOT NULL,
  `plan_ID` int(11) NOT NULL,
  `sk_game_ID` int(11) NOT NULL,
  `times_count` int(11) NOT NULL COMMENT 'Number of times a game can be played'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sk_games_plan`
--

INSERT INTO `sk_games_plan` (`ID`, `school_ID`, `plan_ID`, `sk_game_ID`, `times_count`) VALUES
(1, 2, 1, 1001, 5),
(2, 2, 1, 1002, 5),
(3, 2, 1, 1003, 5),
(4, 2, 1, 1004, 5),
(5, 2, 1, 1005, 5),
(6, 2, 2, 1006, 5),
(7, 2, 2, 1007, 5),
(8, 2, 2, 1008, 5),
(9, 2, 2, 1009, 5),
(10, 2, 2, 1010, 5),
(11, 2, 3, 1011, 5),
(12, 2, 3, 1012, 5),
(13, 2, 3, 1013, 5),
(14, 2, 3, 1014, 5),
(15, 2, 3, 1015, 5),
(16, 2, 4, 1016, 5),
(17, 2, 4, 1017, 5),
(18, 2, 4, 1018, 5),
(19, 2, 4, 1019, 5),
(20, 2, 4, 1020, 5),
(21, 2, 5, 1021, 5),
(22, 2, 5, 1022, 5),
(23, 2, 5, 1023, 5),
(24, 2, 5, 1024, 5),
(25, 2, 5, 1025, 5),
(26, 2, 6, 1026, 5),
(27, 2, 6, 1027, 5),
(28, 2, 6, 1028, 5),
(29, 2, 6, 1029, 5),
(30, 2, 6, 1030, 5),
(31, 2, 7, 1031, 5),
(32, 2, 7, 1032, 5),
(33, 2, 7, 1033, 5),
(34, 2, 7, 1034, 5),
(35, 2, 7, 1035, 5),
(36, 2, 8, 1036, 5),
(37, 2, 8, 1037, 5),
(38, 2, 8, 1038, 5),
(39, 2, 8, 1039, 5),
(40, 2, 8, 1040, 5),
(41, 2, 1, 1041, 5),
(42, 2, 1, 1042, 5),
(43, 2, 1, 1043, 5),
(44, 2, 1, 1044, 5),
(45, 2, 1, 1045, 5),
(46, 2, 2, 1046, 5),
(47, 2, 2, 1047, 5),
(48, 2, 2, 1048, 5),
(49, 2, 2, 1049, 5),
(50, 2, 2, 1050, 5),
(51, 2, 3, 1051, 5),
(52, 2, 3, 1052, 5),
(53, 2, 3, 1053, 5),
(54, 2, 3, 1054, 5),
(55, 2, 3, 1055, 5),
(56, 2, 4, 1056, 5),
(57, 2, 4, 1057, 5),
(58, 2, 4, 1058, 5),
(59, 2, 4, 1059, 5),
(60, 2, 4, 1060, 5),
(61, 2, 5, 1061, 5),
(62, 2, 5, 1062, 5),
(63, 2, 5, 1063, 5),
(64, 2, 5, 1064, 5),
(65, 2, 5, 1065, 5),
(66, 2, 6, 1066, 5),
(67, 2, 6, 1067, 5),
(68, 2, 6, 1068, 5),
(69, 2, 6, 1069, 5),
(70, 2, 6, 1070, 5),
(71, 2, 7, 1071, 5),
(72, 2, 7, 1072, 5),
(73, 2, 7, 1073, 5),
(74, 2, 7, 1074, 5),
(75, 2, 7, 1075, 5),
(76, 2, 8, 1076, 5),
(77, 2, 8, 1077, 5),
(78, 2, 8, 1078, 5),
(79, 2, 8, 1079, 5),
(80, 2, 8, 1080, 5),
(81, 2, 1, 1081, 5),
(82, 2, 1, 1082, 5),
(83, 2, 1, 1083, 5),
(84, 2, 1, 1084, 5),
(85, 2, 1, 1085, 5),
(86, 2, 2, 1086, 5),
(87, 2, 2, 1087, 5),
(88, 2, 2, 1088, 5),
(89, 2, 2, 1089, 5),
(90, 2, 2, 1090, 5),
(91, 2, 3, 1091, 5),
(92, 2, 3, 1092, 5),
(93, 2, 3, 1093, 5),
(94, 2, 3, 1094, 5),
(95, 2, 3, 1095, 5),
(96, 2, 4, 1096, 5),
(97, 2, 4, 1097, 5),
(98, 2, 4, 1098, 5),
(99, 2, 4, 1099, 5),
(100, 2, 4, 1100, 5),
(101, 2, 5, 1101, 5),
(102, 2, 5, 1102, 5),
(103, 2, 5, 1103, 5),
(104, 2, 5, 1104, 5),
(105, 2, 5, 1105, 5),
(106, 2, 6, 1106, 5),
(107, 2, 6, 1107, 5),
(108, 2, 6, 1108, 5),
(109, 2, 6, 1109, 5),
(110, 2, 6, 1110, 5),
(111, 2, 7, 1111, 5),
(112, 2, 7, 1112, 5),
(113, 2, 7, 1113, 5),
(114, 2, 7, 1114, 5),
(115, 2, 7, 1115, 5),
(116, 2, 8, 1116, 5),
(117, 2, 8, 1117, 5),
(118, 2, 8, 1118, 5),
(119, 2, 8, 1119, 5),
(120, 2, 8, 1120, 5),
(121, 2, 1, 1121, 5),
(122, 2, 1, 1122, 5),
(123, 2, 1, 1123, 5),
(124, 2, 1, 1124, 5),
(125, 2, 1, 1125, 5),
(126, 2, 2, 1126, 5),
(127, 2, 2, 1127, 5),
(128, 2, 2, 1128, 5),
(129, 2, 2, 1129, 5),
(130, 2, 2, 1130, 5),
(131, 2, 3, 1131, 5),
(132, 2, 3, 1132, 5),
(133, 2, 3, 1133, 5),
(134, 2, 3, 1134, 5),
(135, 2, 3, 1135, 5),
(136, 2, 4, 1136, 5),
(137, 2, 4, 1137, 5),
(138, 2, 4, 1138, 5),
(139, 2, 4, 1139, 5),
(140, 2, 4, 1140, 5),
(141, 2, 5, 1141, 5),
(142, 2, 5, 1142, 5),
(143, 2, 5, 1143, 5),
(144, 2, 5, 1144, 5),
(145, 2, 5, 1145, 5),
(146, 2, 6, 1146, 5),
(147, 2, 6, 1147, 5),
(148, 2, 6, 1148, 5),
(149, 2, 6, 1149, 5),
(150, 2, 6, 1150, 5),
(151, 2, 7, 1151, 5),
(152, 2, 7, 1152, 5),
(153, 2, 7, 1153, 5),
(154, 2, 7, 1154, 5),
(155, 2, 7, 1155, 5),
(156, 2, 8, 1156, 5),
(157, 2, 8, 1157, 5),
(158, 2, 8, 1158, 5),
(159, 2, 8, 1159, 5),
(160, 2, 8, 1160, 5),
(161, 2, 1, 1161, 5),
(162, 2, 1, 1162, 5),
(163, 2, 1, 1163, 5),
(164, 2, 1, 1164, 5),
(165, 2, 1, 1165, 5),
(166, 2, 2, 1166, 5),
(167, 2, 2, 1167, 5),
(168, 2, 2, 1168, 5),
(169, 2, 2, 1169, 5),
(170, 2, 2, 1170, 5),
(171, 2, 3, 1171, 5),
(172, 2, 3, 1172, 5),
(173, 2, 3, 1173, 5),
(174, 2, 3, 1174, 5),
(175, 2, 3, 1175, 5),
(176, 2, 4, 1176, 5),
(177, 2, 4, 1177, 5),
(178, 2, 4, 1178, 5),
(179, 2, 4, 1179, 5),
(180, 2, 4, 1180, 5),
(181, 2, 5, 1181, 5),
(182, 2, 5, 1182, 5),
(183, 2, 5, 1183, 5),
(184, 2, 5, 1184, 5),
(185, 2, 5, 1185, 5),
(186, 2, 6, 1186, 5),
(187, 2, 6, 1187, 5),
(188, 2, 6, 1188, 5),
(189, 2, 6, 1189, 5),
(190, 2, 6, 1190, 5),
(191, 2, 7, 1191, 5),
(192, 2, 7, 1192, 5),
(193, 2, 7, 1193, 5),
(194, 2, 7, 1194, 5),
(195, 2, 7, 1195, 5),
(196, 2, 8, 1196, 5),
(197, 2, 8, 1197, 5),
(198, 2, 8, 1198, 5),
(199, 2, 8, 1199, 5),
(200, 2, 8, 1200, 5),
(201, 2, 1, 1201, 5),
(202, 2, 1, 1202, 5),
(203, 2, 1, 1203, 5),
(204, 2, 1, 1204, 5),
(205, 2, 1, 1205, 5),
(206, 2, 2, 1206, 5),
(207, 2, 2, 1207, 5),
(208, 2, 2, 1208, 5),
(209, 2, 2, 1209, 5),
(210, 2, 2, 1210, 5),
(211, 2, 3, 1211, 5),
(212, 2, 3, 1212, 5),
(213, 2, 3, 1213, 5),
(214, 2, 3, 1214, 5),
(215, 2, 3, 1215, 5),
(216, 2, 4, 1216, 5),
(217, 2, 4, 1217, 5),
(218, 2, 4, 1218, 5),
(219, 2, 4, 1219, 5),
(220, 2, 4, 1220, 5),
(221, 2, 5, 1221, 5),
(222, 2, 5, 1222, 5),
(223, 2, 5, 1223, 5),
(224, 2, 5, 1224, 5),
(225, 2, 5, 1225, 5),
(226, 2, 6, 1226, 5),
(227, 2, 6, 1227, 5),
(228, 2, 6, 1228, 5),
(229, 2, 6, 1229, 5),
(230, 2, 6, 1230, 5),
(231, 2, 7, 1231, 5),
(232, 2, 7, 1232, 5),
(233, 2, 7, 1233, 5),
(234, 2, 7, 1234, 5),
(235, 2, 7, 1235, 5),
(236, 2, 8, 1236, 5),
(237, 2, 8, 1237, 5),
(238, 2, 8, 1238, 5),
(239, 2, 8, 1239, 5),
(240, 2, 8, 1240, 5),
(241, 2, 1, 1206, 5),
(242, 2, 1, 1242, 5),
(243, 2, 1, 1208, 5),
(244, 2, 1, 1169, 5),
(245, 2, 1, 1245, 5),
(246, 2, 2, 1246, 5),
(247, 2, 2, 1247, 5),
(248, 2, 2, 1248, 5),
(249, 2, 2, 1249, 5),
(250, 2, 2, 1250, 5),
(251, 2, 3, 1251, 5),
(252, 2, 3, 1252, 5),
(253, 2, 3, 1253, 5),
(254, 2, 3, 1254, 5),
(255, 2, 3, 1255, 5),
(256, 2, 4, 1256, 5),
(257, 2, 4, 1257, 5),
(258, 2, 4, 1258, 5),
(259, 2, 4, 1259, 5),
(260, 2, 4, 1260, 5),
(261, 2, 5, 1261, 5),
(262, 2, 5, 1262, 5),
(263, 2, 5, 1263, 5),
(264, 2, 5, 1264, 5),
(265, 2, 5, 1265, 5),
(266, 2, 6, 1266, 5),
(267, 2, 6, 1267, 5),
(268, 2, 6, 1268, 5),
(269, 2, 6, 1269, 5),
(270, 2, 6, 1270, 5),
(271, 2, 7, 1271, 5),
(272, 2, 7, 1272, 5),
(273, 2, 7, 1273, 5),
(274, 2, 7, 1274, 5),
(275, 2, 7, 1275, 5),
(276, 2, 8, 1276, 5),
(277, 2, 8, 1277, 5),
(278, 2, 8, 1278, 5),
(279, 2, 8, 1279, 5),
(280, 2, 8, 1280, 5),
(281, 2, 1, 1166, 5),
(282, 2, 1, 1282, 5),
(283, 2, 1, 1248, 5),
(284, 2, 1, 1209, 5),
(285, 2, 1, 1285, 5),
(286, 2, 2, 1286, 5),
(287, 2, 2, 1287, 5),
(288, 2, 2, 1288, 5),
(289, 2, 2, 1289, 5),
(290, 2, 2, 1290, 5),
(291, 2, 3, 1291, 5),
(292, 2, 3, 1292, 5),
(293, 2, 3, 1293, 5),
(294, 2, 3, 1294, 5),
(295, 2, 3, 1250, 5),
(296, 2, 4, 1296, 5),
(297, 2, 4, 1297, 5),
(298, 2, 4, 1298, 5),
(299, 2, 4, 1299, 5),
(300, 2, 4, 1300, 5),
(301, 2, 5, 1301, 5),
(302, 2, 5, 1302, 5),
(303, 2, 5, 1303, 5),
(304, 2, 5, 1029, 5),
(305, 2, 5, 1305, 5),
(306, 2, 6, 1306, 5),
(307, 2, 6, 1307, 5),
(308, 2, 6, 1308, 5),
(309, 2, 6, 1309, 5),
(310, 2, 6, 1310, 5),
(311, 2, 7, 1311, 5),
(312, 2, 7, 1312, 5),
(313, 2, 7, 1313, 5),
(314, 2, 7, 1314, 5),
(315, 2, 7, 1315, 5),
(316, 2, 8, 1316, 5),
(317, 2, 8, 1232, 5),
(318, 2, 8, 1318, 5),
(319, 2, 8, 1319, 5),
(320, 2, 8, 1320, 5),
(321, 2, 92, 1026, 5),
(322, 2, 92, 1027, 5),
(323, 2, 92, 1028, 5),
(324, 2, 92, 1029, 5),
(325, 2, 92, 1030, 5),
(326, 2, 92, 1066, 5),
(327, 2, 92, 1067, 5),
(328, 2, 92, 1068, 5),
(329, 2, 92, 1069, 5),
(330, 2, 92, 1070, 5),
(331, 2, 92, 1106, 5),
(332, 2, 92, 1107, 5),
(333, 2, 92, 1108, 5),
(334, 2, 92, 1109, 5),
(335, 2, 92, 1110, 5),
(336, 2, 92, 1146, 5),
(337, 2, 92, 1147, 5),
(338, 2, 92, 1148, 5),
(339, 2, 92, 1149, 5),
(340, 2, 92, 1150, 5),
(341, 2, 92, 1186, 5),
(342, 2, 92, 1187, 5),
(343, 2, 92, 1188, 5),
(344, 2, 92, 1189, 5),
(345, 2, 92, 1190, 5),
(346, 2, 92, 1226, 5),
(347, 2, 92, 1227, 5),
(348, 2, 92, 1228, 5),
(349, 2, 92, 1229, 5),
(350, 2, 92, 1230, 5),
(351, 2, 92, 1266, 5),
(352, 2, 92, 1267, 5),
(353, 2, 92, 1268, 5),
(354, 2, 92, 1269, 5),
(355, 2, 92, 1270, 5),
(356, 2, 92, 1306, 5),
(357, 2, 92, 1307, 5),
(358, 2, 92, 1308, 5),
(359, 2, 92, 1309, 5),
(360, 2, 92, 1310, 5),
(361, 2, 93, 1031, 5),
(362, 2, 93, 1032, 5),
(363, 2, 93, 1033, 5),
(364, 2, 93, 1034, 5),
(365, 2, 93, 1035, 5),
(366, 2, 93, 1071, 5),
(367, 2, 93, 1072, 5),
(368, 2, 93, 1073, 5),
(369, 2, 93, 1074, 5),
(370, 2, 93, 1075, 5),
(371, 2, 93, 1111, 5),
(372, 2, 93, 1112, 5),
(373, 2, 93, 1113, 5),
(374, 2, 93, 1114, 5),
(375, 2, 93, 1115, 5),
(376, 2, 93, 1151, 5),
(377, 2, 93, 1152, 5),
(378, 2, 93, 1153, 5),
(379, 2, 93, 1154, 5),
(380, 2, 93, 1155, 5),
(381, 2, 93, 1191, 5),
(382, 2, 93, 1192, 5),
(383, 2, 93, 1193, 5),
(384, 2, 93, 1194, 5),
(385, 2, 93, 1195, 5),
(386, 2, 93, 1231, 5),
(387, 2, 93, 1232, 5),
(388, 2, 93, 1233, 5),
(389, 2, 93, 1234, 5),
(390, 2, 93, 1235, 5),
(391, 2, 93, 1271, 5),
(392, 2, 93, 1272, 5),
(393, 2, 93, 1273, 5),
(394, 2, 93, 1274, 5),
(395, 2, 93, 1275, 5),
(396, 2, 93, 1311, 5),
(397, 2, 93, 1312, 5),
(398, 2, 93, 1313, 5),
(399, 2, 93, 1314, 5),
(400, 2, 93, 1315, 5),
(401, 2, 94, 1036, 5),
(402, 2, 94, 1037, 5),
(403, 2, 94, 1038, 5),
(404, 2, 94, 1039, 5),
(405, 2, 94, 1040, 5),
(406, 2, 94, 1076, 5),
(407, 2, 94, 1077, 5),
(408, 2, 94, 1078, 5),
(409, 2, 94, 1079, 5),
(410, 2, 94, 1080, 5),
(411, 2, 94, 1116, 5),
(412, 2, 94, 1117, 5),
(413, 2, 94, 1118, 5),
(414, 2, 94, 1119, 5),
(415, 2, 94, 1120, 5),
(416, 2, 94, 1156, 5),
(417, 2, 94, 1157, 5),
(418, 2, 94, 1158, 5),
(419, 2, 94, 1159, 5),
(420, 2, 94, 1160, 5),
(421, 2, 94, 1196, 5),
(422, 2, 94, 1197, 5),
(423, 2, 94, 1198, 5),
(424, 2, 94, 1199, 5),
(425, 2, 94, 1200, 5),
(426, 2, 94, 1236, 5),
(427, 2, 94, 1237, 5),
(428, 2, 94, 1238, 5),
(429, 2, 94, 1239, 5),
(430, 2, 94, 1240, 5),
(431, 2, 94, 1276, 5),
(432, 2, 94, 1277, 5),
(433, 2, 94, 1278, 5),
(434, 2, 94, 1279, 5),
(435, 2, 94, 1280, 5),
(436, 2, 94, 1316, 5),
(437, 2, 94, 1232, 5),
(438, 2, 94, 1318, 5),
(439, 2, 94, 1319, 5),
(440, 2, 94, 1320, 5),
(441, 2, 95, 1036, 5),
(442, 2, 95, 1037, 5),
(443, 2, 95, 1038, 5),
(444, 2, 95, 1039, 5),
(445, 2, 95, 1040, 5),
(446, 2, 95, 1076, 5),
(447, 2, 95, 1077, 5),
(448, 2, 95, 1078, 5),
(449, 2, 95, 1079, 5),
(450, 2, 95, 1080, 5),
(451, 2, 95, 1116, 5),
(452, 2, 95, 1117, 5),
(453, 2, 95, 1118, 5),
(454, 2, 95, 1119, 5),
(455, 2, 95, 1120, 5),
(456, 2, 95, 1156, 5),
(457, 2, 95, 1157, 5),
(458, 2, 95, 1158, 5),
(459, 2, 95, 1159, 5),
(460, 2, 95, 1160, 5),
(461, 2, 95, 1196, 5),
(462, 2, 95, 1197, 5),
(463, 2, 95, 1198, 5),
(464, 2, 95, 1199, 5),
(465, 2, 95, 1200, 5),
(466, 2, 95, 1236, 5),
(467, 2, 95, 1237, 5),
(468, 2, 95, 1238, 5),
(469, 2, 95, 1239, 5),
(470, 2, 95, 1240, 5),
(471, 2, 95, 1276, 5),
(472, 2, 95, 1277, 5),
(473, 2, 95, 1278, 5),
(474, 2, 95, 1279, 5),
(475, 2, 95, 1280, 5),
(476, 2, 95, 1316, 5),
(477, 2, 95, 1232, 5),
(478, 2, 95, 1318, 5),
(479, 2, 95, 1319, 5),
(480, 2, 95, 1320, 5),
(481, 2, 10, 414, 5),
(482, 2, 10, 416, 5),
(483, 2, 10, 418, 5),
(484, 2, 10, 419, 5),
(485, 2, 10, 421, 5),
(486, 2, 10, 422, 5),
(487, 2, 10, 424, 5),
(488, 2, 10, 425, 5),
(489, 2, 10, 426, 5),
(490, 2, 10, 429, 5),
(491, 2, 10, 431, 5),
(492, 2, 10, 432, 5),
(493, 2, 10, 433, 5),
(494, 2, 10, 434, 5),
(495, 2, 10, 435, 5),
(496, 2, 10, 439, 5),
(497, 2, 10, 440, 5),
(498, 2, 10, 516, 5),
(499, 2, 10, 518, 5),
(500, 2, 10, 594, 5),
(501, 2, 10, 595, 5),
(502, 2, 10, 597, 5),
(503, 2, 10, 599, 5),
(504, 2, 10, 601, 5),
(505, 2, 10, 602, 5),
(506, 2, 10, 603, 5),
(507, 2, 10, 604, 5),
(508, 2, 10, 605, 5),
(509, 2, 10, 612, 5),
(510, 2, 10, 613, 5),
(511, 2, 10, 614, 5),
(512, 2, 10, 615, 5),
(513, 2, 10, 619, 5),
(514, 2, 10, 620, 5),
(515, 2, 10, 621, 5),
(516, 2, 10, 624, 5),
(517, 2, 10, 625, 5),
(518, 2, 11, 464, 5),
(519, 2, 11, 467, 5),
(520, 2, 11, 469, 5),
(521, 2, 11, 470, 5),
(522, 2, 11, 471, 5),
(523, 2, 11, 472, 5),
(524, 2, 11, 474, 5),
(525, 2, 11, 475, 5),
(526, 2, 11, 476, 5),
(527, 2, 11, 479, 5),
(528, 2, 11, 481, 5),
(529, 2, 11, 482, 5),
(530, 2, 11, 483, 5),
(531, 2, 11, 484, 5),
(532, 2, 11, 485, 5),
(533, 2, 11, 489, 5),
(534, 2, 11, 490, 5),
(535, 2, 11, 515, 5),
(536, 2, 11, 517, 5),
(537, 2, 11, 596, 5),
(538, 2, 11, 598, 5),
(539, 2, 11, 600, 5),
(540, 2, 11, 606, 5),
(541, 2, 11, 607, 5),
(542, 2, 11, 608, 5),
(543, 2, 11, 609, 5),
(544, 2, 11, 610, 5),
(545, 2, 11, 611, 5),
(546, 2, 11, 616, 5),
(547, 2, 11, 617, 5),
(548, 2, 11, 618, 5),
(549, 2, 11, 622, 5),
(550, 2, 11, 623, 5),
(551, 2, 11, 626, 5),
(552, 2, 11, 627, 5),
(553, 2, 11, 628, 5);

-- --------------------------------------------------------

--
-- Stand-in structure for view `sk_game_reports`
-- (See below for the actual view)
--
CREATE TABLE `sk_game_reports` (
`id` int(11)
,`gu_id` int(10)
,`gp_id` int(100)
,`gc_id` int(10)
,`gs_id` int(10)
,`g_id` int(30)
,`total_question` varchar(15)
,`attempt_question` varchar(20)
,`answer` varchar(20)
,`game_score` varchar(50)
,`gtime` varchar(100)
,`rtime` varchar(100)
,`crtime` varchar(100)
,`wrtime` varchar(100)
,`lastupdate` date
,`session_id` int(11)
,`puzzle_cycle` int(11)
);

-- --------------------------------------------------------

--
-- Table structure for table `sk_personalized_game`
--

CREATE TABLE `sk_personalized_game` (
  `ID` int(11) NOT NULL,
  `sk_planSkillCountID` int(11) NOT NULL,
  `skillID` int(11) NOT NULL,
  `from_GradeID` int(11) NOT NULL,
  `level` int(11) NOT NULL,
  `gameCount` int(11) NOT NULL COMMENT 'Number of games per skill'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sk_personalized_game`
--

INSERT INTO `sk_personalized_game` (`ID`, `sk_planSkillCountID`, `skillID`, `from_GradeID`, `level`, `gameCount`) VALUES
(1, 1, 59, 1, 1, 1),
(2, 2, 59, 1, 1, 1),
(3, 3, 59, 2, 1, 1),
(4, 4, 59, 3, 1, 1),
(5, 5, 59, 4, 1, 1),
(6, 6, 59, 5, 1, 1),
(7, 7, 59, 6, 1, 1),
(8, 8, 59, 7, 1, 1),
(9, 9, 59, 8, 1, 1),
(10, 10, 59, 92, 1, 1),
(11, 11, 59, 93, 1, 1),
(12, 12, 59, 94, 1, 1),
(13, 13, 59, 10, 1, 1),
(14, 14, 59, 10, 1, 1),
(16, 1, 59, 1, 2, 1),
(17, 2, 59, 1, 2, 1),
(18, 3, 59, 1, 2, 1),
(19, 4, 59, 2, 2, 1),
(20, 5, 59, 3, 2, 1),
(21, 6, 59, 4, 2, 1),
(22, 7, 59, 5, 2, 1),
(23, 8, 59, 6, 2, 1),
(24, 9, 59, 7, 2, 1),
(25, 10, 59, 8, 2, 1),
(26, 11, 59, 92, 2, 1),
(27, 12, 59, 93, 2, 1),
(28, 13, 59, 10, 2, 1),
(29, 14, 59, 10, 2, 1),
(31, 1, 60, 1, 1, 1),
(32, 2, 60, 1, 1, 1),
(33, 3, 60, 2, 1, 1),
(34, 4, 60, 3, 1, 1),
(35, 5, 60, 4, 1, 1),
(36, 6, 60, 5, 1, 1),
(37, 7, 60, 6, 1, 1),
(38, 8, 60, 7, 1, 1),
(39, 9, 60, 8, 1, 1),
(40, 10, 60, 92, 1, 1),
(41, 11, 60, 93, 1, 1),
(42, 12, 60, 94, 1, 1),
(43, 13, 60, 10, 1, 1),
(44, 14, 60, 10, 1, 1),
(45, 1, 60, 1, 2, 1),
(46, 2, 60, 1, 2, 1),
(47, 3, 60, 1, 2, 1),
(48, 4, 60, 2, 2, 1),
(49, 5, 60, 3, 2, 1),
(50, 6, 60, 4, 2, 1),
(51, 7, 60, 5, 2, 1),
(52, 8, 60, 6, 2, 1),
(53, 9, 60, 7, 2, 1),
(54, 10, 60, 8, 2, 1),
(55, 11, 60, 92, 2, 1),
(56, 12, 60, 93, 2, 1),
(57, 13, 60, 10, 2, 1),
(58, 14, 60, 10, 2, 1),
(62, 1, 61, 1, 1, 1),
(63, 2, 61, 1, 1, 1),
(64, 3, 61, 2, 1, 1),
(65, 4, 61, 3, 1, 1),
(66, 5, 61, 4, 1, 1),
(67, 6, 61, 5, 1, 1),
(68, 7, 61, 6, 1, 1),
(69, 8, 61, 7, 1, 1),
(70, 9, 61, 8, 1, 1),
(71, 10, 61, 92, 1, 1),
(72, 11, 61, 93, 1, 1),
(73, 12, 61, 94, 1, 1),
(74, 13, 61, 10, 1, 1),
(75, 14, 61, 10, 1, 1),
(76, 1, 61, 1, 2, 1),
(77, 2, 61, 1, 2, 1),
(78, 3, 61, 1, 2, 1),
(79, 4, 61, 2, 2, 1),
(80, 5, 61, 3, 2, 1),
(81, 6, 61, 4, 2, 1),
(82, 7, 61, 5, 2, 1),
(83, 8, 61, 6, 2, 1),
(84, 9, 61, 7, 2, 1),
(85, 10, 61, 8, 2, 1),
(86, 11, 61, 92, 2, 1),
(87, 12, 61, 93, 2, 1),
(88, 13, 61, 10, 2, 1),
(89, 14, 61, 10, 2, 1),
(93, 1, 62, 1, 1, 1),
(94, 2, 62, 1, 1, 1),
(95, 3, 62, 2, 1, 1),
(96, 4, 62, 3, 1, 1),
(97, 5, 62, 4, 1, 1),
(98, 6, 62, 5, 1, 1),
(99, 7, 62, 6, 1, 1),
(100, 8, 62, 7, 1, 1),
(101, 9, 62, 8, 1, 1),
(102, 10, 62, 92, 1, 1),
(103, 11, 62, 93, 1, 1),
(104, 12, 62, 94, 1, 1),
(105, 13, 62, 10, 1, 1),
(106, 14, 62, 10, 1, 1),
(107, 1, 62, 1, 2, 1),
(108, 2, 62, 1, 2, 1),
(109, 3, 62, 1, 2, 1),
(110, 4, 62, 2, 2, 1),
(111, 5, 62, 3, 2, 1),
(112, 6, 62, 4, 2, 1),
(113, 7, 62, 5, 2, 1),
(114, 8, 62, 6, 2, 1),
(115, 9, 62, 7, 2, 1),
(116, 10, 62, 8, 2, 1),
(117, 11, 62, 92, 2, 1),
(118, 12, 62, 93, 2, 1),
(119, 13, 62, 10, 2, 1),
(120, 14, 62, 10, 2, 1),
(124, 1, 63, 1, 1, 1),
(125, 2, 63, 1, 1, 1),
(126, 3, 63, 2, 1, 1),
(127, 4, 63, 3, 1, 1),
(128, 5, 63, 4, 1, 1),
(129, 6, 63, 5, 1, 1),
(130, 7, 63, 6, 1, 1),
(131, 8, 63, 7, 1, 1),
(132, 9, 63, 8, 1, 1),
(133, 10, 63, 92, 1, 1),
(134, 11, 63, 93, 1, 1),
(135, 12, 63, 94, 1, 1),
(136, 13, 63, 10, 1, 1),
(137, 14, 63, 10, 1, 1),
(138, 1, 63, 1, 2, 1),
(139, 2, 63, 1, 2, 1),
(140, 3, 63, 1, 2, 1),
(141, 4, 63, 2, 2, 1),
(142, 5, 63, 3, 2, 1),
(143, 6, 63, 4, 2, 1),
(144, 7, 63, 5, 2, 1),
(145, 8, 63, 6, 2, 1),
(146, 9, 63, 7, 2, 1),
(147, 10, 63, 8, 2, 1),
(148, 11, 63, 92, 2, 1),
(149, 12, 63, 93, 2, 1),
(150, 13, 63, 10, 2, 1),
(151, 14, 63, 10, 2, 1);

-- --------------------------------------------------------

--
-- Table structure for table `sk_plan_skillcount`
--

CREATE TABLE `sk_plan_skillcount` (
  `ID` int(11) NOT NULL,
  `school_ID` int(11) NOT NULL,
  `plan_ID` int(11) NOT NULL,
  `skill_count` int(11) NOT NULL COMMENT 'Number of skills taken for Personalized games'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sk_plan_skillcount`
--

INSERT INTO `sk_plan_skillcount` (`ID`, `school_ID`, `plan_ID`, `skill_count`) VALUES
(1, 2, 1, 1),
(2, 2, 2, 1),
(3, 2, 3, 1),
(4, 2, 4, 1),
(5, 2, 5, 1),
(6, 2, 6, 1),
(7, 2, 7, 1),
(8, 2, 8, 1),
(9, 2, 92, 1),
(10, 2, 93, 1),
(11, 2, 94, 1),
(12, 2, 95, 1),
(13, 2, 10, 1),
(14, 2, 11, 1);

-- --------------------------------------------------------

--
-- Table structure for table `sk_rand_selection`
--

CREATE TABLE `sk_rand_selection` (
  `id` int(11) NOT NULL,
  `gc_id` int(11) DEFAULT NULL,
  `gs_id` int(11) DEFAULT NULL,
  `gid` int(11) DEFAULT NULL,
  `gp_id` int(11) DEFAULT NULL,
  `grade_id` int(11) DEFAULT NULL,
  `section` varchar(10) DEFAULT NULL,
  `school_id` int(11) DEFAULT NULL,
  `userID` int(11) NOT NULL,
  `created_date` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sk_rand_selection`
--

INSERT INTO `sk_rand_selection` (`id`, `gc_id`, `gs_id`, `gid`, `gp_id`, `grade_id`, `section`, `school_id`, `userID`, `created_date`) VALUES
(4, 2, 59, 1121, 1, 4, 'A', 2, 38324, '2019-08-06 00:00:00'),
(5, 2, 61, 1043, 1, 4, 'A', 2, 38324, '2019-08-06 00:00:00'),
(6, 2, 62, 1204, 1, 4, 'A', 2, 38324, '2019-08-06 00:00:00'),
(7, 2, 63, 1165, 1, 4, 'A', 2, 38324, '2019-08-06 00:00:00'),
(8, 2, 59, 1206, 1, 4, 'A', 2, 38324, '2019-08-07 00:00:00'),
(9, 2, 61, 1203, 1, 4, 'A', 2, 38324, '2019-08-07 00:00:00'),
(10, 2, 62, 1044, 1, 4, 'A', 2, 38324, '2019-08-07 00:00:00'),
(11, 2, 63, 1285, 1, 4, 'A', 2, 38324, '2019-08-07 00:00:00'),
(12, 2, 61, 1003, 1, 3, 'A', 2, 60498, '2019-06-09 00:00:00'),
(13, 2, 61, 1208, 1, 3, 'A', 2, 60498, '2019-06-10 00:00:00'),
(14, 2, 61, 1043, 1, 3, 'A', 2, 60498, '2019-06-11 00:00:00'),
(15, 2, 61, 1248, 1, 3, 'A', 2, 60498, '2019-08-14 00:00:00'),
(16, 2, 60, 1282, 1, 3, 'A', 2, 60498, '2019-08-14 00:00:00'),
(17, 2, 60, 1242, 1, 3, 'A', 2, 60498, '2019-07-01 00:00:00'),
(18, 2, 61, 1163, 1, 3, 'A', 2, 60498, '2019-07-01 00:00:00'),
(19, 2, 60, 1122, 1, 3, 'A', 2, 60498, '2019-08-19 00:00:00'),
(20, 2, 61, 1123, 1, 3, 'A', 2, 60498, '2019-08-19 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `sk_user_game_list`
--

CREATE TABLE `sk_user_game_list` (
  `ID` int(11) NOT NULL,
  `userID` int(11) NOT NULL,
  `planID` int(11) NOT NULL,
  `SessionID` int(11) NOT NULL COMMENT 'represents game play iteration',
  `weakSkills` varchar(100) NOT NULL COMMENT 'list of weak games of iteration delimited by comma',
  `levelid` varchar(55) NOT NULL DEFAULT '0',
  `status` int(11) NOT NULL,
  `created_date` datetime NOT NULL,
  `session_start_range` int(11) NOT NULL,
  `session_end_range` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sk_user_game_list`
--

INSERT INTO `sk_user_game_list` (`ID`, `userID`, `planID`, `SessionID`, `weakSkills`, `levelid`, `status`, `created_date`, `session_start_range`, `session_end_range`) VALUES
(1, 38324, 2, 1, '59,61,62,63', '1,2,1,2', 0, '2019-08-06 13:25:02', 9, 16),
(2, 60498, 1, 1, '61', '1', 1, '2019-06-10 13:55:11', 9, 16),
(3, 60498, 1, 2, '60,61', '2,2', 1, '2019-08-14 20:21:37', 17, 24),
(4, 60498, 1, 2, '60,61', '2,2', 1, '2019-07-01 10:18:33', 17, 24),
(5, 60498, 1, 3, '60,61', '2,2', 0, '2019-08-19 13:02:26', 25, 32);

-- --------------------------------------------------------

--
-- Stand-in structure for view `sm_q1_avgv1_user_skillscore`
-- (See below for the actual view)
--
CREATE TABLE `sm_q1_avgv1_user_skillscore` (
`final` double(19,2)
,`gs_id` int(10)
,`gu_id` int(10)
,`sid` varchar(100)
,`skillname` varchar(50)
,`grade_id` int(10)
,`section` varchar(10)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `sm_q1_avgv2_user_skillscore`
-- (See below for the actual view)
--
CREATE TABLE `sm_q1_avgv2_user_skillscore` (
`skillscore` double(19,2)
,`gs_id` int(10)
,`skillname` varchar(50)
,`sid` varchar(100)
,`grade_id` int(10)
,`section` varchar(10)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `sm_q1_avgv3_user_skillscore`
-- (See below for the actual view)
--
CREATE TABLE `sm_q1_avgv3_user_skillscore` (
`score` double(19,2)
,`gs_id` int(10)
,`skillname` varchar(50)
,`sid` varchar(100)
,`grade_id` int(10)
,`section` varchar(10)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `sm_q1_day_user_skillscore`
-- (See below for the actual view)
--
CREATE TABLE `sm_q1_day_user_skillscore` (
`gamescore` double(19,2)
,`gs_id` int(10)
,`lastupdate` date
,`gu_id` int(10)
,`sid` varchar(100)
,`grade_id` int(10)
,`section` varchar(10)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `sm_q1_top_skillscore_grade_sec`
-- (See below for the actual view)
--
CREATE TABLE `sm_q1_top_skillscore_grade_sec` (
`topscore` double(19,2)
,`gs_id` int(10)
,`skillname` varchar(50)
,`sid` varchar(100)
,`grade_id` int(10)
,`section` varchar(10)
);

-- --------------------------------------------------------

--
-- Table structure for table `sparkiesmaster`
--

CREATE TABLE `sparkiesmaster` (
  `ID` int(11) NOT NULL,
  `Scenario` varchar(255) NOT NULL,
  `Code` varchar(55) NOT NULL,
  `Type` enum('REGULAR','BONUS') NOT NULL,
  `Points` int(11) NOT NULL,
  `Status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sparkiesmaster`
--

INSERT INTO `sparkiesmaster` (`ID`, `Scenario`, `Code`, `Type`, `Points`, `Status`) VALUES
(1, 'Attempting one question', 'ONE_Q', 'REGULAR', 1, 1),
(2, 'Completion of all questions', 'ALL_Q', 'REGULAR', 1, 1),
(3, 'Number of times of play of a game', 'NOTPOAG', 'REGULAR', 5, 1),
(4, 'First login of scheduled school days', 'FLOSSD', 'REGULAR', 1, 1),
(5, 'First login from Home', 'FLFH', 'REGULAR', 5, 1),
(6, 'If completed game score got score above 60 out of 100', 'ABOVE_60', 'REGULAR', 5, 1),
(7, 'Attempting one question correct', '1QC', 'BONUS', 2, 1),
(8, 'Completion of all 10 questions correct', '10QC', 'BONUS', 10, 1),
(9, 'If all five times gets played', 'ALL5TGP', 'BONUS', 10, 1),
(10, 'First login of scheduled school days between 6 PM to 6 AM', '6T6', 'BONUS', 5, 1),
(11, 'First login of weekends (Saturday and sunday)', 'WEEKEND', 'BONUS', 10, 1),
(12, 'All days played on current month', 'ALLDAY', 'BONUS', 10, 1);

-- --------------------------------------------------------

--
-- Table structure for table `stafffeedback`
--

CREATE TABLE `stafffeedback` (
  `id` int(11) NOT NULL,
  `staffid` int(11) NOT NULL,
  `qus1` varchar(110) NOT NULL COMMENT '1. How was the Assessment process planned and conducted ?',
  `qus2` varchar(110) NOT NULL COMMENT '2. Did the Support Team coordinate well with your School ?',
  `qus3` varchar(110) NOT NULL COMMENT '3. Did the Support Team arrive on Time and spent time with the students ?',
  `qus4` varchar(100) NOT NULL COMMENT '4. Did the students or you find the level of the Program challenging ?',
  `qus5` text NOT NULL COMMENT '5. Could the Support Team have handled the implementation better ? Please share with us your suggestions',
  `status` int(11) NOT NULL,
  `created_on` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `stafffeedback`
--

INSERT INTO `stafffeedback` (`id`, `staffid`, `qus1`, `qus2`, `qus3`, `qus4`, `qus5`, `status`, `created_on`) VALUES
(1, 1, 'Well Planned', 'Excellent', 'Yes', 'Yes', 'Great Feel...', 1, '2018-12-03 17:48:02'),
(2, 2, 'Could be better', 'Satisfactory', 'No', 'No', 'Awesome !!!', 1, '2018-12-03 17:50:52');

-- --------------------------------------------------------

--
-- Table structure for table `stafffeedback_list`
--

CREATE TABLE `stafffeedback_list` (
  `id` int(11) NOT NULL,
  `sid` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `designation` varchar(110) NOT NULL,
  `status` int(11) NOT NULL,
  `created_on` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `stafffeedback_list`
--

INSERT INTO `stafffeedback_list` (`id`, `sid`, `email`, `designation`, `status`, `created_on`) VALUES
(1, 2, 'sundar@skillangels.com', 'ceo', 1, '2018-11-12 00:00:00'),
(2, 2, 'hari@skillangels.com', 'ceo', 1, '2018-11-12 00:00:00'),
(3, 2, 'damu@skillangels.com', 'ceo', 1, '2018-11-12 00:00:00'),
(4, 2, 'sundar3@gmail.com', 'ceo', 1, '2018-11-12 00:00:00'),
(5, 2, 'sundar3@gmail.com', 'ceo', 1, '2018-11-12 00:00:00');

-- --------------------------------------------------------

--
-- Stand-in structure for view `superangel`
-- (See below for the actual view)
--
CREATE TABLE `superangel` (
`ans` double
,`gu_id` int(10)
,`monthName` varchar(32)
,`monthNumber` varchar(2)
,`gs_ID` varchar(100)
,`grad_ID` bigint(11)
);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_feedback`
--

CREATE TABLE `tbl_feedback` (
  `feedbackid` int(10) NOT NULL,
  `uid` int(11) NOT NULL,
  `gid` int(11) NOT NULL,
  `rating` int(11) NOT NULL,
  `modifieddate` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `teachers`
--

CREATE TABLE `teachers` (
  `id` int(11) NOT NULL,
  `email` varchar(250) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `fname` varchar(100) NOT NULL,
  `lname` varchar(100) NOT NULL,
  `initial` varchar(5) DEFAULT NULL,
  `dob` date DEFAULT NULL,
  `address` varchar(300) NOT NULL,
  `designation` varchar(100) NOT NULL,
  `qualification` varchar(100) DEFAULT NULL,
  `phoneno` varchar(12) NOT NULL,
  `school_id` int(11) NOT NULL,
  `class_id` int(11) NOT NULL,
  `active` int(11) NOT NULL,
  `status` int(1) NOT NULL,
  `createdby` varchar(100) NOT NULL,
  `creation_date` date NOT NULL,
  `modifiedby` varchar(100) NOT NULL,
  `modified_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `teachers`
--

INSERT INTO `teachers` (`id`, `email`, `username`, `password`, `fname`, `lname`, `initial`, `dob`, `address`, `designation`, `qualification`, `phoneno`, `school_id`, `class_id`, `active`, `status`, `createdby`, `creation_date`, `modifiedby`, `modified_date`) VALUES
(8, 'varun.k@123.com', '', 'e54fd19aeca91a2ef6c1cc5590898a68', 'varun', 'krishnan', NULL, NULL, '', 'B.E', NULL, '99999999999', 7, 0, 1, 0, '', '0000-00-00', '', '2014-08-28 08:16:40'),
(10, 'a@b.com', '', '357a20e8c56e69d6f9734d23ef9517e8', 'Grade6Staff1', 'SecA', NULL, NULL, '', 'XX', NULL, '1234567890', 4, 0, 1, 0, '', '0000-00-00', '', '2014-08-29 22:12:49'),
(11, 'b@c.com', '', 'c9edf70098f8c270a022a29f0a2c876f', 'Grade6Staff2', 'SecD', NULL, NULL, '', 'XXX', NULL, '1234567890', 4, 0, 1, 0, '', '0000-00-00', '', '2014-08-29 22:13:22'),
(12, 'g@g.com', '', 'a5d502e66f116d4bd040613df88e074b', 'Grade3staff1', 'SecC', NULL, NULL, '', 'XXX', NULL, '1234567890', 0, 0, 1, 0, '', '0000-00-00', '', '2014-09-01 04:31:44'),
(14, 'grgstaff1@grg.com', '', '5fcf2b70d342536ef1a6b71c084b59f7', 'staff1', 'grg', NULL, NULL, '', 'a', NULL, '1234567890', 1, 0, 1, 0, '', '0000-00-00', '', '2014-09-14 21:48:10'),
(15, 'grgstaff2@grg.com', '', '57b7ddb4af7c4e19f477d763d79fa748', 'staff2', 'grg', NULL, NULL, '', 'a', NULL, '1234567890', 1, 0, 1, 0, '', '0000-00-00', '', '2014-09-14 21:53:18'),
(16, 'grgstaff3@grg.com', '', 'ebb7c32eb8837690ea62e5b3c799631d', 'staff3', 'grg', NULL, NULL, '', 'aaa', NULL, '1234567890', 1, 0, 1, 0, '', '0000-00-00', '', '2014-09-14 22:13:35');

-- --------------------------------------------------------

--
-- Table structure for table `teachersday_feedback`
--

CREATE TABLE `teachersday_feedback` (
  `id` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `sid` int(11) NOT NULL,
  `qone` int(11) NOT NULL,
  `comment` varchar(800) NOT NULL,
  `created_date` datetime NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `teacher_class`
--

CREATE TABLE `teacher_class` (
  `id` int(11) NOT NULL,
  `teacher_id` int(11) NOT NULL,
  `school_id` int(11) NOT NULL,
  `class_id` int(11) NOT NULL,
  `section` varchar(100) NOT NULL,
  `status` int(1) NOT NULL,
  `createdby` varchar(100) NOT NULL,
  `creation_date` date NOT NULL,
  `modifiedby` varchar(100) NOT NULL,
  `modified_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `teacher_class`
--

INSERT INTO `teacher_class` (`id`, `teacher_id`, `school_id`, `class_id`, `section`, `status`, `createdby`, `creation_date`, `modifiedby`, `modified_date`) VALUES
(12, 10, 4, 8, 'A', 0, '', '0000-00-00', '', '2014-08-29 22:13:36'),
(13, 11, 4, 8, 'D', 0, '', '0000-00-00', '', '2014-08-29 22:14:28'),
(19, 14, 1, 3, 'A', 0, '', '0000-00-00', '', '2014-09-14 21:48:53'),
(20, 14, 1, 4, 'A', 0, '', '0000-00-00', '', '2014-09-14 21:48:59'),
(21, 14, 1, 5, 'A', 0, '', '0000-00-00', '', '2014-09-14 21:49:05'),
(22, 14, 1, 6, 'A', 0, '', '0000-00-00', '', '2014-09-14 21:49:22'),
(23, 14, 1, 7, 'A', 0, '', '0000-00-00', '', '2014-09-14 21:49:29'),
(24, 14, 1, 8, 'A', 0, '', '0000-00-00', '', '2014-09-14 21:49:37'),
(25, 14, 1, 9, 'A', 0, '', '0000-00-00', '', '2014-09-14 21:49:45'),
(26, 14, 1, 10, 'A', 0, '', '0000-00-00', '', '2014-09-14 21:49:53'),
(27, 15, 1, 3, 'B', 0, '', '0000-00-00', '', '2014-09-14 21:53:47'),
(28, 15, 1, 4, 'B', 0, '', '0000-00-00', '', '2014-09-14 21:53:57'),
(29, 15, 1, 5, 'B', 0, '', '0000-00-00', '', '2014-09-14 21:54:09'),
(30, 15, 1, 6, 'B', 0, '', '0000-00-00', '', '2014-09-14 21:54:29'),
(31, 15, 1, 7, 'B', 0, '', '0000-00-00', '', '2014-09-14 21:54:57'),
(32, 15, 1, 8, 'B', 0, '', '0000-00-00', '', '2014-09-14 21:55:12'),
(33, 15, 1, 9, 'B', 0, '', '0000-00-00', '', '2014-09-14 21:55:24'),
(34, 15, 1, 10, 'B', 0, '', '0000-00-00', '', '2014-09-14 21:55:36'),
(35, 16, 1, 3, 'C', 0, '', '0000-00-00', '', '2014-09-14 22:13:51'),
(36, 16, 1, 4, 'C', 0, '', '0000-00-00', '', '2014-09-14 22:14:01'),
(37, 16, 1, 5, 'C', 0, '', '0000-00-00', '', '2014-09-14 22:14:15'),
(38, 16, 1, 6, 'C', 0, '', '0000-00-00', '', '2014-09-14 22:14:33'),
(39, 16, 1, 7, 'C', 0, '', '0000-00-00', '', '2014-09-14 22:14:43'),
(40, 16, 1, 8, 'C', 0, '', '0000-00-00', '', '2014-09-14 22:14:52'),
(41, 16, 1, 9, 'C', 0, '', '0000-00-00', '', '2014-09-14 22:15:03'),
(42, 16, 1, 10, 'C', 0, '', '0000-00-00', '', '2014-09-14 22:15:13');

-- --------------------------------------------------------

--
-- Table structure for table `test`
--

CREATE TABLE `test` (
  `datetime` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `test`
--

INSERT INTO `test` (`datetime`) VALUES
('2018-07-10 01:00:00'),
('2018-07-11 01:00:00'),
('2018-07-12 01:00:04'),
('2018-07-13 00:59:59'),
('2018-07-14 01:00:02'),
('2018-07-16 13:35:01'),
('2018-07-16 17:56:16'),
('2018-07-17 17:56:00'),
('2018-07-18 17:56:05'),
('2018-07-19 17:56:16'),
('2018-07-20 17:56:00'),
('2018-07-21 17:56:05'),
('2018-07-22 17:56:00'),
('2018-07-23 17:56:11'),
('2018-07-25 17:56:05'),
('2018-07-26 17:56:01'),
('2018-07-27 17:56:01'),
('2018-07-28 17:56:11'),
('2018-07-29 17:56:01'),
('2018-07-30 17:56:01'),
('2018-07-31 17:56:01'),
('2018-08-01 17:56:17'),
('2018-08-02 17:56:06'),
('2018-08-03 17:56:02'),
('2018-08-04 17:56:06'),
('2018-08-05 17:56:02'),
('2018-08-06 17:56:06'),
('2018-08-07 17:56:06'),
('2018-08-08 17:56:01'),
('2018-08-09 17:56:12'),
('2018-08-10 17:56:11'),
('2018-08-11 17:56:12'),
('2018-08-12 17:56:06'),
('2018-08-13 17:56:06'),
('2018-08-14 17:56:07'),
('2018-08-15 17:56:06'),
('2018-08-16 17:56:06'),
('2018-08-17 17:56:01'),
('2018-08-18 17:56:01'),
('2018-08-19 17:56:06'),
('2018-08-20 17:56:06'),
('2018-08-21 17:56:06'),
('2018-08-22 17:56:07'),
('2018-08-23 17:56:02'),
('2018-08-24 17:56:01'),
('2018-08-25 17:56:05'),
('2018-08-26 17:56:06'),
('2018-08-27 17:56:01'),
('2018-08-28 17:56:01'),
('2018-08-29 17:56:01'),
('2018-08-30 17:56:05'),
('2018-08-31 17:56:01'),
('2018-09-01 17:56:01'),
('2018-09-02 17:56:05'),
('2018-09-03 17:56:06'),
('2018-09-04 17:56:00'),
('2018-09-05 17:56:20'),
('2018-09-06 17:56:06'),
('2018-09-07 17:56:02'),
('2018-09-08 17:56:01'),
('2018-09-09 17:56:06'),
('2018-09-10 17:56:16'),
('2018-09-11 17:56:07'),
('2018-09-12 17:56:01'),
('2018-09-13 17:56:06'),
('2018-09-14 17:56:11'),
('2018-09-15 17:56:02'),
('2018-09-16 17:56:02'),
('2018-09-17 17:56:06'),
('2018-09-18 17:56:01'),
('2018-09-19 17:56:01'),
('2018-09-20 17:56:06'),
('2018-09-21 17:56:11'),
('2018-09-22 17:56:02'),
('2018-09-23 17:56:01'),
('2018-09-24 17:56:02'),
('2018-09-25 17:56:01'),
('2018-09-26 17:56:06'),
('2018-09-27 17:56:02'),
('2018-09-28 17:56:08'),
('2018-09-29 17:56:01'),
('2018-09-30 17:56:01'),
('2018-10-01 17:56:07'),
('2018-10-02 17:56:02'),
('2018-10-03 17:56:06'),
('2018-10-04 17:56:01'),
('2018-10-05 17:56:01'),
('2018-10-06 17:56:01'),
('2018-10-07 17:56:06'),
('2018-10-08 17:56:01'),
('2018-10-09 17:56:06'),
('2018-10-10 17:56:05'),
('2018-10-11 17:56:05'),
('2018-10-12 17:56:00'),
('2018-10-13 17:56:05'),
('2018-10-14 17:56:01'),
('2018-10-15 17:56:00'),
('2018-10-16 17:56:06'),
('2018-10-17 17:56:01'),
('2018-10-18 17:56:00'),
('2018-10-19 17:56:06'),
('2018-10-20 17:56:06'),
('2018-10-21 17:56:01'),
('2018-10-22 17:56:00'),
('2018-10-23 17:56:10'),
('2018-10-24 17:56:11'),
('2018-10-25 17:56:00'),
('2018-10-26 17:56:05'),
('2018-10-27 17:56:05'),
('2018-10-28 17:56:00'),
('2018-10-29 17:56:00'),
('2018-10-30 17:56:00'),
('2018-10-31 17:56:00'),
('2018-11-01 17:56:00'),
('2018-11-02 17:56:00'),
('2018-11-03 17:56:01'),
('2018-11-04 17:56:12'),
('2018-11-05 17:56:01'),
('2018-11-06 17:56:11'),
('2018-11-07 17:56:02'),
('2018-11-08 17:56:07'),
('2018-11-09 17:56:01'),
('2018-11-10 17:56:06'),
('2018-11-11 17:56:06'),
('2018-11-12 17:56:06'),
('2018-11-13 17:56:00'),
('2018-11-14 17:56:05'),
('2018-11-15 17:56:10'),
('2018-11-16 17:56:01'),
('2018-11-17 17:56:06'),
('2018-11-18 17:56:00'),
('2018-11-19 17:56:00'),
('2018-11-20 17:56:00'),
('2018-11-21 17:56:00'),
('2018-11-22 17:56:00'),
('2018-11-23 17:56:04'),
('2018-11-24 17:56:09'),
('2018-11-25 17:56:05'),
('2018-11-26 17:56:05'),
('2018-11-27 17:55:59'),
('2018-11-28 17:56:05'),
('2018-11-29 17:56:00'),
('2018-11-30 17:56:05'),
('2018-12-01 17:56:04'),
('2018-12-02 17:56:04'),
('2018-12-03 17:56:00'),
('2018-12-04 17:56:05'),
('2018-12-05 17:56:00'),
('2018-12-06 17:56:00'),
('2018-12-07 17:56:05'),
('2018-12-08 17:56:00'),
('2018-12-09 17:56:00'),
('2018-12-10 17:56:00'),
('2018-12-11 17:56:05'),
('2018-12-12 17:56:05'),
('2018-12-13 17:56:00'),
('2018-12-14 17:56:05'),
('2018-12-15 17:56:01'),
('2018-12-16 17:56:01'),
('2018-12-17 17:56:01'),
('2018-12-18 17:56:02'),
('2018-12-19 17:56:02'),
('2018-12-21 17:56:06'),
('2018-12-22 17:56:02'),
('2018-12-23 17:56:02'),
('2018-12-24 17:56:02'),
('2018-12-25 17:56:01'),
('2018-12-26 17:56:16'),
('2018-12-27 17:56:11'),
('2018-12-28 17:56:01'),
('2018-12-29 17:56:02'),
('2018-12-30 17:56:02'),
('2018-12-31 17:56:02'),
('2019-01-01 17:56:02'),
('2019-01-02 17:56:02'),
('2019-01-03 17:56:02'),
('2019-01-04 17:56:02'),
('2019-01-05 17:56:02'),
('2019-01-06 17:56:12'),
('2019-01-07 17:56:02'),
('2019-01-08 17:56:02'),
('2019-01-09 17:56:03'),
('2019-01-10 17:56:07'),
('2019-01-11 17:56:07'),
('2019-01-12 17:56:02'),
('2019-01-13 17:56:07'),
('2019-01-14 17:56:07'),
('2019-01-15 17:56:02'),
('2019-01-16 17:56:02'),
('2019-01-17 17:56:07'),
('2019-01-18 17:56:02'),
('2019-01-19 17:56:02'),
('2019-01-20 17:56:02'),
('2019-01-21 17:56:08'),
('2019-01-22 17:56:02'),
('2019-01-23 17:56:02'),
('2019-01-24 17:56:02'),
('2019-01-25 17:56:02'),
('2019-01-26 17:56:07'),
('2019-01-27 17:56:02'),
('2019-01-28 17:56:02'),
('2019-01-29 17:56:02'),
('2019-01-30 17:56:02'),
('2019-01-31 17:56:02'),
('2019-02-01 17:56:07'),
('2019-02-02 17:56:02'),
('2019-02-03 17:56:02'),
('2019-02-04 17:56:07'),
('2019-02-05 17:56:02'),
('2019-02-06 17:56:02'),
('2019-02-07 17:56:02'),
('2019-02-08 17:56:07'),
('2019-02-09 17:56:02'),
('2019-02-10 17:56:02'),
('2019-02-11 17:56:02'),
('2019-02-12 17:56:02'),
('2019-02-13 17:56:02'),
('2019-02-14 17:56:02'),
('2019-02-15 17:56:02'),
('2019-02-16 17:56:07'),
('2019-02-17 17:56:02'),
('2019-02-18 17:56:17'),
('2019-02-19 17:56:12'),
('2019-02-20 17:56:12'),
('2019-02-21 17:56:07'),
('2019-02-22 17:56:02'),
('2019-02-23 17:56:07'),
('2019-02-24 17:56:06'),
('2019-02-25 17:56:07'),
('2019-02-26 17:56:02'),
('2019-02-27 17:56:02'),
('2019-02-28 17:56:02'),
('2019-03-01 17:56:02'),
('2019-03-02 17:56:02'),
('2019-03-03 17:56:02'),
('2019-03-04 17:56:02');

-- --------------------------------------------------------

--
-- Table structure for table `thememaster`
--

CREATE TABLE `thememaster` (
  `id` int(11) NOT NULL,
  `theme_name` varchar(40) NOT NULL,
  `theme_file_name` varchar(40) NOT NULL,
  `image_name` varchar(255) NOT NULL,
  `description` varchar(100) NOT NULL,
  `sparky_range` int(11) NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `thememaster`
--

INSERT INTO `thememaster` (`id`, `theme_name`, `theme_file_name`, `image_name`, `description`, `sparky_range`, `status`) VALUES
(1, 'Default Theme', 'styleinner.css', 'default.png', 'Default Theme', 0, 1),
(2, 'Super Theme', 'styleinner_super.css', 'theme1.png', 'Earn 1000 sparkie points to activate theme', 1000, 1),
(3, 'Mega Theme', 'styleinner_super1.css', 'theme2.png', 'Earn 2000 sparkie points to activate theme', 2000, 1),
(4, 'Super Skillangels Theme', 'styleinner_super2.css', 'theme3.png', 'Earn 3000 sparkie points to activate theme', 3000, 1),
(5, 'Super Skillangels Theme', 'styleinner_super3.css', 'theme4.png', 'Earn 4000 sparkie points to activate theme', 4000, 1);

-- --------------------------------------------------------

--
-- Table structure for table `trial`
--

CREATE TABLE `trial` (
  `id` int(100) DEFAULT NULL,
  `fname` varchar(100) DEFAULT NULL,
  `gp_id` int(10) DEFAULT NULL,
  `grade_id` int(10) DEFAULT NULL,
  `username` varchar(100) DEFAULT NULL,
  `sid` varchar(100) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Stand-in structure for view `trophystar`
-- (See below for the actual view)
--
CREATE TABLE `trophystar` (
`gu_id` int(10)
,`id` int(11)
,`name` varchar(50)
,`ct` int(1)
,`lastupdate` date
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `trophystargreaterthanninty`
-- (See below for the actual view)
--
CREATE TABLE `trophystargreaterthanninty` (
`gu_id` int(10)
,`id` int(11)
,`name` varchar(50)
,`lastupdate` date
,`ct` double(17,0)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `trophystarlessequalninty`
-- (See below for the actual view)
--
CREATE TABLE `trophystarlessequalninty` (
`gu_id` int(10)
,`id` int(11)
,`name` varchar(50)
,`lastupdate` date
,`ct` double(17,0)
);

-- --------------------------------------------------------

--
-- Table structure for table `t_allbspi`
--

CREATE TABLE `t_allbspi` (
  `RowID` int(11) NOT NULL,
  `avgscore` varchar(400) NOT NULL,
  `gs_id` int(11) NOT NULL,
  `gu_id` int(11) NOT NULL,
  `lastupdate` date NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `t_sumbbspi`
--

CREATE TABLE `t_sumbbspi` (
  `RowID` int(11) NOT NULL,
  `avgscore` varchar(400) NOT NULL,
  `gs_id` int(11) NOT NULL,
  `gu_id` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `userbadge_data`
--

CREATE TABLE `userbadge_data` (
  `ID` int(11) NOT NULL,
  `S_ID` int(11) NOT NULL,
  `G_ID` int(11) NOT NULL,
  `MonthNumber` int(11) NOT NULL,
  `Sparkies` text NOT NULL,
  `SuperBrian` text NOT NULL,
  `SuperGoer` text NOT NULL,
  `SuperAngel` text NOT NULL,
  `isexist` int(11) NOT NULL DEFAULT '1',
  `Datetime` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `usermaster`
--

CREATE TABLE `usermaster` (
  `ID` int(11) NOT NULL,
  `fisrname` varchar(110) NOT NULL,
  `lastname` varchar(110) DEFAULT NULL,
  `username` varchar(110) NOT NULL,
  `salt1` varchar(55) NOT NULL,
  `password` varchar(255) NOT NULL,
  `salt2` varchar(55) NOT NULL,
  `gradeid` int(11) NOT NULL,
  `section` varchar(55) NOT NULL,
  `sid` int(11) NOT NULL,
  `contestdate` date NOT NULL,
  `starttime` varchar(55) NOT NULL,
  `endtime` varchar(55) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `userplaytime`
--

CREATE TABLE `userplaytime` (
  `id` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `expiredon` date NOT NULL,
  `expireddatetime` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `userplaytime`
--

INSERT INTO `userplaytime` (`id`, `userid`, `expiredon`, `expireddatetime`) VALUES
(1, 60465, '2019-05-09', '2019-05-09 14:22:20'),
(2, 60455, '2019-05-10', '2019-05-10 20:35:03'),
(3, 60454, '2019-05-20', '2019-05-20 15:33:45'),
(4, 60480, '2019-05-21', '2019-05-21 14:53:03'),
(5, 38324, '2019-08-05', '2019-08-05 17:45:07'),
(6, 60441, '2019-08-05', '2019-08-05 19:42:26'),
(7, 60441, '2019-08-06', '2019-08-06 10:55:40'),
(8, 38324, '2019-08-06', '2019-08-06 11:04:03'),
(9, 60498, '2019-08-13', '2019-08-13 14:28:02'),
(10, 60500, '2019-08-13', '2019-08-13 16:06:29'),
(11, 60498, '2019-08-14', '2019-08-14 10:27:34'),
(12, 60498, '2019-08-19', '2019-08-19 11:32:41');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(100) NOT NULL,
  `deviceid` varchar(40) NOT NULL,
  `rollno` varchar(100) CHARACTER SET latin1 NOT NULL,
  `email` varchar(100) CHARACTER SET latin1 NOT NULL,
  `salt1` varchar(20) CHARACTER SET utf8 NOT NULL,
  `password` varchar(100) NOT NULL,
  `salt2` varchar(20) CHARACTER SET utf8 NOT NULL,
  `fname` varchar(100) CHARACTER SET latin1 NOT NULL,
  `lname` varchar(100) CHARACTER SET latin1 NOT NULL,
  `gender` varchar(100) CHARACTER SET latin1 NOT NULL,
  `mobile` varchar(15) CHARACTER SET latin1 NOT NULL,
  `dob` varchar(100) CHARACTER SET latin1 NOT NULL,
  `status` int(1) DEFAULT NULL,
  `visible` int(1) NOT NULL,
  `gp_id` int(10) NOT NULL,
  `glevel` varchar(100) CHARACTER SET latin1 NOT NULL,
  `grade_id` int(10) NOT NULL COMMENT 'Stage ID',
  `actual_grade_id` int(11) NOT NULL COMMENT 'Orginal Grade ID',
  `sname` varchar(100) CHARACTER SET latin1 NOT NULL,
  `father` varchar(100) CHARACTER SET latin1 NOT NULL,
  `mother` varchar(100) CHARACTER SET latin1 NOT NULL,
  `address` varchar(500) CHARACTER SET latin1 NOT NULL,
  `username` varchar(100) CHARACTER SET latin1 NOT NULL,
  `initial` varchar(100) CHARACTER SET latin1 NOT NULL,
  `sid` varchar(100) CHARACTER SET latin1 NOT NULL,
  `section` varchar(10) CHARACTER SET latin1 NOT NULL,
  `academicyear` varchar(20) CHARACTER SET latin1 DEFAULT NULL,
  `createdby` varchar(100) CHARACTER SET latin1 NOT NULL,
  `login_count` int(11) NOT NULL DEFAULT '0',
  `login_date` date NOT NULL,
  `pre_logindate` date NOT NULL,
  `creation_date` date NOT NULL,
  `modifiedby` varchar(100) CHARACTER SET latin1 NOT NULL,
  `modified_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `avatarimage` varchar(800) CHARACTER SET latin1 NOT NULL,
  `agreetermsandservice` int(11) NOT NULL,
  `creationkey` varchar(20) NOT NULL,
  `usertheme` varchar(55) CHARACTER SET latin1 NOT NULL,
  `session_id` varchar(255) CHARACTER SET latin1 NOT NULL,
  `parent_session_id` varchar(255) NOT NULL,
  `islogin` int(11) NOT NULL,
  `last_active_datetime` datetime NOT NULL,
  `school_name` varchar(255) NOT NULL,
  `referedby` varchar(55) NOT NULL,
  `org_pwd` varchar(255) NOT NULL,
  `time_zone` varchar(255) NOT NULL,
  `portal_type` enum('ASAP1','ASAP2','CLP') NOT NULL,
  `current_session` int(11) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `deviceid`, `rollno`, `email`, `salt1`, `password`, `salt2`, `fname`, `lname`, `gender`, `mobile`, `dob`, `status`, `visible`, `gp_id`, `glevel`, `grade_id`, `actual_grade_id`, `sname`, `father`, `mother`, `address`, `username`, `initial`, `sid`, `section`, `academicyear`, `createdby`, `login_count`, `login_date`, `pre_logindate`, `creation_date`, `modifiedby`, `modified_date`, `avatarimage`, `agreetermsandservice`, `creationkey`, `usertheme`, `session_id`, `parent_session_id`, `islogin`, `last_active_datetime`, `school_name`, `referedby`, `org_pwd`, `time_zone`, `portal_type`, `current_session`) VALUES
(60484, '', '', '', '764086112', '604b4fa7ec77df4db4082a11e3de68677b0862e4', '443781884', 'sandy', '', '', '', '', 1, 1, 10, '', 1, 1, '', '', '', '', 'sandy', '', '2', 'A', '20', '', 46, '2019-08-05', '2019-06-04', '2019-04-10', '', '2019-08-05 06:42:52', '', 1, '', '', '604392019080511515315649861138', '', 1, '2019-08-05 12:12:52', '', '', '', 'Asia/kolkata', 'CLP', 1),
(60485, '', '', '', '764086112', '604b4fa7ec77df4db4082a11e3de68677b0862e4', '443781884', 'k1ukg', '', '', '', '', 1, 1, 11, '', 2, 2, '', '', '', '', 'nk1ukg', '', '2', 'A', '20', '', 0, '0000-00-00', '0000-00-00', '2019-08-07', '', '2019-08-09 07:31:23', '', 1, '', '', '', '', 0, '0000-00-00 00:00:00', '', '', '', 'Asia/kolkata', 'CLP', 1),
(60486, '', '', '', '764086112', '604b4fa7ec77df4db4082a11e3de68677b0862e4', '443781884', 'k2ukg', '', '', '', '', 1, 1, 11, '', 2, 2, '', '', '', '', 'nk2ukg', '', '2', 'A', '20', '', 0, '0000-00-00', '0000-00-00', '2019-08-07', '', '2019-08-09 07:31:56', '', 1, '', '', '', '', 0, '0000-00-00 00:00:00', '', '', '', 'Asia/kolkata', 'CLP', 1),
(60487, '', '', '', '764086112', '604b4fa7ec77df4db4082a11e3de68677b0862e4', '443781884', 'k3ukg', '', '', '', '', 1, 1, 11, '', 2, 2, '', '', '', '', 'nk3ukg', '', '2', 'A', '20', '', 0, '0000-00-00', '0000-00-00', '2019-08-07', '', '2019-08-09 07:31:38', '', 1, '', '', '', '', 0, '0000-00-00 00:00:00', '', '', '', 'Asia/kolkata', 'CLP', 1),
(60488, '', '', '', '764086112', '604b4fa7ec77df4db4082a11e3de68677b0862e4', '443781884', 'k4ukg', '', '', '', '', 1, 1, 11, '', 2, 2, '', '', '', '', 'nk4ukg', '', '2', 'A', '20', '', 0, '0000-00-00', '0000-00-00', '2019-08-07', '', '2019-08-09 07:31:59', '', 1, '', '', '', '', 0, '0000-00-00 00:00:00', '', '', '', 'Asia/kolkata', 'CLP', 1),
(60489, '', '', '', '764086112', '604b4fa7ec77df4db4082a11e3de68677b0862e4', '443781884', 'k1lkg', '', '', '', '', 1, 1, 10, '', 1, 2, '', '', '', '', 'nk1lkg', '', '2', 'A', '20', '', 0, '0000-00-00', '0000-00-00', '2019-08-07', '', '2019-08-09 07:32:02', '', 1, '', '', '', '', 0, '0000-00-00 00:00:00', '', '', '', 'Asia/kolkata', 'CLP', 1),
(60490, '', '', '', '764086112', '604b4fa7ec77df4db4082a11e3de68677b0862e4', '443781884', 'k2lkg', '', '', '', '', 1, 1, 10, '', 1, 2, '', '', '', '', 'nk2lkg', '', '2', 'A', '20', '', 0, '0000-00-00', '0000-00-00', '2019-08-07', '', '2019-08-09 07:32:03', '', 1, '', '', '', '', 0, '0000-00-00 00:00:00', '', '', '', 'Asia/kolkata', 'CLP', 1),
(60491, '', '', '', '764086112', '604b4fa7ec77df4db4082a11e3de68677b0862e4', '443781884', 'k3lkg', '', '', '', '', 1, 1, 10, '', 1, 2, '', '', '', '', 'nk3lkg', '', '2', 'A', '20', '', 0, '0000-00-00', '0000-00-00', '2019-08-07', '', '2019-08-09 07:32:06', '', 1, '', '', '', '', 0, '0000-00-00 00:00:00', '', '', '', 'Asia/kolkata', 'CLP', 1),
(60492, '', '', '', '764086112', '604b4fa7ec77df4db4082a11e3de68677b0862e4', '443781884', 'k4lkg', '', '', '', '', 1, 1, 10, '', 1, 2, '', '', '', '', 'nk4lkg', '', '2', 'A', '20', '', 0, '0000-00-00', '0000-00-00', '2019-08-07', '', '2019-08-09 07:32:08', '', 1, '', '', '', '', 0, '0000-00-00 00:00:00', '', '', '', 'Asia/kolkata', 'CLP', 1),
(60493, '', '', '', '764086112', '604b4fa7ec77df4db4082a11e3de68677b0862e4', '443781884', 'k1prekg', '', '', '', '', 1, 1, 91, '', 11, 2, '', '', '', '', 'nk1prekg', '', '2', 'A', '20', '', 4, '2019-08-13', '2019-08-13', '2019-08-07', '', '2019-08-13 06:10:45', '', 1, '', '', '604932019081311384515656765259', '', 0, '2019-08-13 11:38:50', '', '', '', 'Asia/kolkata', 'CLP', 1),
(60494, '', '', '', '764086112', '604b4fa7ec77df4db4082a11e3de68677b0862e4', '443781884', 'k2prekg', '', '', '', '', 1, 1, 91, '', 11, 2, '', '', '', '', 'nk2prekg', '', '2', 'A', '20', '', 1, '2019-08-13', '0000-00-00', '2019-08-07', '', '2019-08-13 06:00:48', '', 1, '', '', '604942019081311280415656758841', '', 0, '2019-08-13 11:30:48', '', '', '', 'Asia/kolkata', 'CLP', 1),
(60495, '', '', '', '764086112', '604b4fa7ec77df4db4082a11e3de68677b0862e4', '443781884', 'k3prekg', '', '', '', '', 1, 1, 91, '', 11, 2, '', '', '', '', 'nk3prekg', '', '2', 'A', '20', '', 0, '0000-00-00', '0000-00-00', '2019-08-07', '', '2019-08-09 07:32:17', '', 1, '', '', '', '', 0, '0000-00-00 00:00:00', '', '', '', 'Asia/kolkata', 'CLP', 1),
(60496, '', '', '', '764086112', '604b4fa7ec77df4db4082a11e3de68677b0862e4', '443781884', 'k4prekg', '', '', '', '', 1, 1, 91, '', 11, 2, '', '', '', '', 'nk4prekg', '', '2', 'A', '20', '', 0, '0000-00-00', '0000-00-00', '2019-08-07', '', '2019-08-09 07:32:20', '', 1, '', '', '', '', 0, '0000-00-00 00:00:00', '', '', '', 'Asia/kolkata', 'CLP', 1),
(60497, '', '', '', '764086112', '604b4fa7ec77df4db4082a11e3de68677b0862e4', '443781884', 'A1G1', '', '', '', '', 1, 1, 1, '', 3, 3, '', '', '', '', 'a1g1', '', '2', 'A', '20', '', 90, '2019-08-19', '2019-08-13', '2018-05-30', '', '2019-08-19 05:35:02', '', 1, '', '', '604972019081911044715661928875', '', 0, '2019-08-19 11:05:02', '', '', '', 'Asia/kolkata', 'ASAP1', 1),
(60498, '', '', '', '764086112', '604b4fa7ec77df4db4082a11e3de68677b0862e4', '443781884', 'A1G2', '', '', '', '', 1, 1, 1, '', 3, 4, '', '', '', '', 'a1g2', '', '2', 'A', '20', '', 114, '2019-08-19', '2019-08-19', '2018-05-30', '', '2019-08-19 13:37:49', '', 1, '', '', '604982019081919035515662216357', '', 0, '2019-08-19 19:07:49', '', '', '', 'Asia/kolkata', 'CLP', 26),
(60499, '', '', '', '764086112', '604b4fa7ec77df4db4082a11e3de68677b0862e4', '443781884', 'A1G3', '', '', '', '', 1, 1, 1, '', 3, 5, '', '', '', '', 'a1g3', '', '2', 'A', '20', '', 47, '2019-08-13', '2019-08-13', '2018-05-30', '', '2019-08-13 10:33:52', '', 1, '', '', '604992019081316012415656922845', '', 0, '2019-08-13 16:03:51', '', '', '', 'Asia/kolkata', 'ASAP1', 1),
(60500, '', '', '', '764086112', '604b4fa7ec77df4db4082a11e3de68677b0862e4', '443781884', 'A1G4', '', '', '', '', 1, 1, 4, '', 6, 6, '', '', '', '', 'a1g4', '', '2', 'A', '20', '', 45, '2019-08-13', '2019-08-13', '2018-05-30', '', '2019-08-13 10:46:49', '', 1, '', '', '605002019081316160915656931695', '', 0, '2019-08-13 16:16:49', '', '', '', 'Asia/kolkata', 'CLP', 1),
(60501, '', '', '', '764086112', '604b4fa7ec77df4db4082a11e3de68677b0862e4', '443781884', 'A1G5', '', '', '', '', 1, 1, 3, '', 5, 7, '', '', '', '', 'a1g5', '', '2', 'A', '20', '', 21, '2019-05-17', '2019-05-17', '2018-05-30', '', '2019-08-07 10:54:31', '', 1, '', '', '383302019051715192015580865607', '', 0, '2019-05-17 16:45:35', '', '', '', 'Asia/kolkata', 'ASAP1', 1),
(60502, '', '', '', '764086112', '604b4fa7ec77df4db4082a11e3de68677b0862e4', '443781884', 'A1G6', '', '', '', '', 1, 1, 4, '', 6, 8, '', '', '', '', 'a1g6', '', '2', 'A', '20', '', 63, '2019-05-22', '2019-05-17', '2018-05-30', '', '2019-08-07 10:54:34', '', 1, '', '', '383322019052212091315585071540', '', 0, '2019-05-22 12:09:25', '', '', '', 'Asia/kolkata', 'ASAP1', 1),
(60503, '', '', '', '764086112', '604b4fa7ec77df4db4082a11e3de68677b0862e4', '443781884', 'A1G7', '', '', '', '', 1, 1, 5, '', 7, 9, '', '', '', '', 'a1g7', '', '2', 'A', '20', '', 40, '2019-05-22', '2019-05-22', '2018-05-30', '', '2019-08-07 10:54:38', '', 1, '', '', '383342019052212381115585088917', '', 0, '2019-05-22 12:38:18', '', '', '', 'Asia/kolkata', 'ASAP1', 1),
(60504, '', '', '', '764086112', '604b4fa7ec77df4db4082a11e3de68677b0862e4', '443781884', 'A1G8', '', '', '', '', 1, 1, 6, '', 8, 10, '', '', '', '', 'a1g8', '', '2', 'A', '20', '', 37, '2019-05-17', '2019-05-13', '2018-05-30', '', '2019-08-07 10:54:41', '', 1, '', '', '383362019051717370715580948274', '', 0, '2019-05-17 20:17:10', '', '', '', 'Asia/kolkata', 'ASAP1', 1),
(60505, '', '', '', '764086112', '604b4fa7ec77df4db4082a11e3de68677b0862e4', '443781884', 'A1G12', '', '', '', '', 1, 1, 93, '', 13, 15, '', '', '', '', 'a1g12', '', '2', 'A', '20', '', 28, '2019-05-08', '2019-05-08', '2018-05-30', '', '2019-08-07 10:54:45', '', 1, '', '', '525802019050810355015572919509', '', 0, '2019-05-08 10:36:02', '', '', '', 'Asia/kolkata', 'ASAP1', 1),
(60506, '', '', '', '764086112', '604b4fa7ec77df4db4082a11e3de68677b0862e4', '443781884', 'A1G9', '', '', '', '', 1, 1, 7, '', 9, 12, '', '', '', '', 'a1g9', '', '2', 'A', '20', '', 31, '2019-05-13', '2019-05-13', '2018-05-30', '', '2019-08-07 10:54:48', '', 1, '', '', '525812019051318032815577508090', '', 0, '2019-05-13 18:11:22', '', '', '', 'Asia/kolkata', 'ASAP1', 1),
(60507, '', '', '', '764086112', '604b4fa7ec77df4db4082a11e3de68677b0862e4', '443781884', 'A1G10', '', '', '', '', 1, 1, 8, '', 10, 13, '', '', '', '', 'a1g10', '', '2', 'A', '20', '', 29, '2019-05-13', '2019-05-08', '2018-05-30', '', '2019-08-07 10:54:52', '', 1, '', '', '525822019051317521415577501343', '', 0, '2019-05-13 18:03:05', '', '', '', 'Asia/kolkata', 'ASAP1', 1),
(60508, '', '', '', '764086112', '604b4fa7ec77df4db4082a11e3de68677b0862e4', '443781884', 'A1G11', '', '', '', '', 1, 1, 92, '', 12, 14, '', '', '', '', 'a1g11', '', '2', 'A', '20', '', 31, '2019-05-07', '2019-05-07', '2018-05-30', '', '2019-08-07 10:54:57', '', 1, '', '', '525832019050719273515572374557', '', 0, '2019-05-07 19:27:41', '', '', '', 'Asia/kolkata', 'ASAP1', 1),
(60521, '', '', '', '764086112', '604b4fa7ec77df4db4082a11e3de68677b0862e4', '443781884', 'a2g1', '', '', '', '', 1, 1, 1, '', 3, 3, '', '', '', '', 'a2g1', '', '2', 'A', '20', '', 82, '2019-08-07', '2019-08-05', '2018-05-30', '', '2019-08-07 10:54:11', '', 1, '', '', '383222019080715273615651718562', '', 0, '2019-08-07 15:27:51', '', '', '', 'Asia/kolkata', 'ASAP1', 1),
(60522, '', '', '', '764086112', '604b4fa7ec77df4db4082a11e3de68677b0862e4', '443781884', 'a2g2', '', '', '', '', 1, 1, 1, '', 3, 4, '', '', '', '', 'a2g2', '', '2', 'A', '20', '', 41, '2019-08-07', '2019-08-06', '2018-05-30', '', '2019-08-07 10:54:19', '', 1, '', '', '383242019080710245015651536907', '', 0, '2019-08-07 10:29:40', '', '', '', 'Asia/kolkata', 'ASAP1', 1),
(60523, '', '', '', '764086112', '604b4fa7ec77df4db4082a11e3de68677b0862e4', '443781884', 'a2g3', '', '', '', '', 1, 1, 1, '', 3, 5, '', '', '', '', 'a2g3', '', '2', 'A', '20', '', 41, '2019-08-05', '2019-06-04', '2018-05-30', '', '2019-08-07 10:54:23', '', 1, '', '', '383262019080511503315649860335', '', 0, '2019-08-05 11:50:54', '', '', '', 'Asia/kolkata', 'ASAP1', 1),
(60524, '', '', '', '764086112', '604b4fa7ec77df4db4082a11e3de68677b0862e4', '443781884', 'a2g4', '', '', '', '', 1, 1, 2, '', 4, 6, '', '', '', '', 'a2g4', '', '2', 'A', '20', '', 34, '2019-08-06', '2019-05-22', '2018-05-30', '', '2019-08-07 10:54:27', '', 1, '', '', '383282019080613163515650775955', '', 0, '2019-08-06 13:18:22', '', '', '', 'Asia/kolkata', 'ASAP1', 1),
(60525, '', '', '', '764086112', '604b4fa7ec77df4db4082a11e3de68677b0862e4', '443781884', 'a2g5', '', '', '', '', 1, 1, 3, '', 5, 7, '', '', '', '', 'a2g5', '', '2', 'A', '20', '', 21, '2019-05-17', '2019-05-17', '2018-05-30', '', '2019-08-07 10:54:31', '', 1, '', '', '383302019051715192015580865607', '', 0, '2019-05-17 16:45:35', '', '', '', 'Asia/kolkata', 'ASAP1', 1),
(60526, '', '', '', '764086112', '604b4fa7ec77df4db4082a11e3de68677b0862e4', '443781884', 'a2g6', '', '', '', '', 1, 1, 4, '', 6, 8, '', '', '', '', 'a2g6', '', '2', 'A', '20', '', 63, '2019-05-22', '2019-05-17', '2018-05-30', '', '2019-08-07 10:54:34', '', 1, '', '', '383322019052212091315585071540', '', 0, '2019-05-22 12:09:25', '', '', '', 'Asia/kolkata', 'ASAP1', 1),
(60527, '', '', '', '764086112', '604b4fa7ec77df4db4082a11e3de68677b0862e4', '443781884', 'a2g7', '', '', '', '', 1, 1, 5, '', 7, 9, '', '', '', '', 'a2g7', '', '2', 'A', '20', '', 40, '2019-05-22', '2019-05-22', '2018-05-30', '', '2019-08-07 10:54:38', '', 1, '', '', '383342019052212381115585088917', '', 0, '2019-05-22 12:38:18', '', '', '', 'Asia/kolkata', 'ASAP1', 1),
(60528, '', '', '', '764086112', '604b4fa7ec77df4db4082a11e3de68677b0862e4', '443781884', 'a2g8', '', '', '', '', 1, 1, 6, '', 8, 10, '', '', '', '', 'a2g8', '', '2', 'A', '20', '', 37, '2019-05-17', '2019-05-13', '2018-05-30', '', '2019-08-07 10:54:41', '', 1, '', '', '383362019051717370715580948274', '', 0, '2019-05-17 20:17:10', '', '', '', 'Asia/kolkata', 'ASAP1', 1),
(60529, '', '', '', '764086112', '604b4fa7ec77df4db4082a11e3de68677b0862e4', '443781884', 'a2g12', '', '', '', '', 1, 1, 93, '', 13, 15, '', '', '', '', 'a2g12', '', '2', 'A', '20', '', 28, '2019-05-08', '2019-05-08', '2018-05-30', '', '2019-08-07 10:54:45', '', 1, '', '', '525802019050810355015572919509', '', 0, '2019-05-08 10:36:02', '', '', '', 'Asia/kolkata', 'ASAP1', 1),
(60530, '', '', '', '764086112', '604b4fa7ec77df4db4082a11e3de68677b0862e4', '443781884', 'a2g9', '', '', '', '', 1, 1, 7, '', 9, 12, '', '', '', '', 'a2g9', '', '2', 'A', '20', '', 31, '2019-05-13', '2019-05-13', '2018-05-30', '', '2019-08-07 10:54:48', '', 1, '', '', '525812019051318032815577508090', '', 0, '2019-05-13 18:11:22', '', '', '', 'Asia/kolkata', 'ASAP1', 1),
(60531, '', '', '', '764086112', '604b4fa7ec77df4db4082a11e3de68677b0862e4', '443781884', 'a2g10', '', '', '', '', 1, 1, 8, '', 10, 13, '', '', '', '', 'a2g10', '', '2', 'A', '20', '', 29, '2019-05-13', '2019-05-08', '2018-05-30', '', '2019-08-07 10:54:52', '', 1, '', '', '525822019051317521415577501343', '', 0, '2019-05-13 18:03:05', '', '', '', 'Asia/kolkata', 'ASAP1', 1),
(60532, '', '', '', '764086112', '604b4fa7ec77df4db4082a11e3de68677b0862e4', '443781884', 'a2g11', '', '', '', '', 1, 1, 92, '', 12, 14, '', '', '', '', 'a2g11', '', '2', 'A', '20', '', 31, '2019-05-07', '2019-05-07', '2018-05-30', '', '2019-08-07 10:54:57', '', 1, '', '', '525832019050719273515572374557', '', 0, '2019-05-07 19:27:41', '', '', '', 'Asia/kolkata', 'ASAP1', 1),
(60533, '', '', '', '764086112', '604b4fa7ec77df4db4082a11e3de68677b0862e4', '443781884', 'a3g1', '', '', '', '', 1, 1, 1, '', 3, 3, '', '', '', '', 'a3g1', '', '2', 'A', '20', '', 82, '2019-08-07', '2019-08-05', '2018-05-30', '', '2019-08-07 10:54:11', '', 1, '', '', '383222019080715273615651718562', '', 0, '2019-08-07 15:27:51', '', '', '', 'Asia/kolkata', 'ASAP1', 1),
(60534, '', '', '', '764086112', '604b4fa7ec77df4db4082a11e3de68677b0862e4', '443781884', 'a3g2', '', '', '', '', 1, 1, 1, '', 3, 4, '', '', '', '', 'a3g2', '', '2', 'A', '20', '', 41, '2019-08-07', '2019-08-06', '2018-05-30', '', '2019-08-07 10:54:19', '', 1, '', '', '383242019080710245015651536907', '', 0, '2019-08-07 10:29:40', '', '', '', 'Asia/kolkata', 'ASAP1', 1),
(60535, '', '', '', '764086112', '604b4fa7ec77df4db4082a11e3de68677b0862e4', '443781884', 'a3g3', '', '', '', '', 1, 1, 1, '', 3, 5, '', '', '', '', 'a3g3', '', '2', 'A', '20', '', 41, '2019-08-05', '2019-06-04', '2018-05-30', '', '2019-08-07 10:54:23', '', 1, '', '', '383262019080511503315649860335', '', 0, '2019-08-05 11:50:54', '', '', '', 'Asia/kolkata', 'ASAP1', 1),
(60536, '', '', '', '764086112', '604b4fa7ec77df4db4082a11e3de68677b0862e4', '443781884', 'a3g4', '', '', '', '', 1, 1, 2, '', 4, 6, '', '', '', '', 'a3g4', '', '2', 'A', '20', '', 34, '2019-08-06', '2019-05-22', '2018-05-30', '', '2019-08-07 10:54:27', '', 1, '', '', '383282019080613163515650775955', '', 0, '2019-08-06 13:18:22', '', '', '', 'Asia/kolkata', 'ASAP1', 1),
(60537, '', '', '', '764086112', '604b4fa7ec77df4db4082a11e3de68677b0862e4', '443781884', 'a3g5', '', '', '', '', 1, 1, 3, '', 5, 7, '', '', '', '', 'a3g5', '', '2', 'A', '20', '', 21, '2019-05-17', '2019-05-17', '2018-05-30', '', '2019-08-07 10:54:31', '', 1, '', '', '383302019051715192015580865607', '', 0, '2019-05-17 16:45:35', '', '', '', 'Asia/kolkata', 'ASAP1', 1),
(60538, '', '', '', '764086112', '604b4fa7ec77df4db4082a11e3de68677b0862e4', '443781884', 'a3g6', '', '', '', '', 1, 1, 4, '', 6, 8, '', '', '', '', 'a3g6', '', '2', 'A', '20', '', 63, '2019-05-22', '2019-05-17', '2018-05-30', '', '2019-08-07 10:54:34', '', 1, '', '', '383322019052212091315585071540', '', 0, '2019-05-22 12:09:25', '', '', '', 'Asia/kolkata', 'ASAP1', 1),
(60539, '', '', '', '764086112', '604b4fa7ec77df4db4082a11e3de68677b0862e4', '443781884', 'a3g7', '', '', '', '', 1, 1, 5, '', 7, 9, '', '', '', '', 'a3g7', '', '2', 'A', '20', '', 40, '2019-05-22', '2019-05-22', '2018-05-30', '', '2019-08-07 10:54:38', '', 1, '', '', '383342019052212381115585088917', '', 0, '2019-05-22 12:38:18', '', '', '', 'Asia/kolkata', 'ASAP1', 1),
(60540, '', '', '', '764086112', '604b4fa7ec77df4db4082a11e3de68677b0862e4', '443781884', 'a3g8', '', '', '', '', 1, 1, 6, '', 8, 10, '', '', '', '', 'a3g8', '', '2', 'A', '20', '', 37, '2019-05-17', '2019-05-13', '2018-05-30', '', '2019-08-07 10:54:41', '', 1, '', '', '383362019051717370715580948274', '', 0, '2019-05-17 20:17:10', '', '', '', 'Asia/kolkata', 'ASAP1', 1),
(60541, '', '', '', '764086112', '604b4fa7ec77df4db4082a11e3de68677b0862e4', '443781884', 'a3g12', '', '', '', '', 1, 1, 93, '', 13, 15, '', '', '', '', 'a3g12', '', '2', 'A', '20', '', 28, '2019-05-08', '2019-05-08', '2018-05-30', '', '2019-08-07 10:54:45', '', 1, '', '', '525802019050810355015572919509', '', 0, '2019-05-08 10:36:02', '', '', '', 'Asia/kolkata', 'ASAP1', 1),
(60542, '', '', '', '764086112', '604b4fa7ec77df4db4082a11e3de68677b0862e4', '443781884', 'a3g9', '', '', '', '', 1, 1, 7, '', 9, 12, '', '', '', '', 'a3g9', '', '2', 'A', '20', '', 31, '2019-05-13', '2019-05-13', '2018-05-30', '', '2019-08-07 10:54:48', '', 1, '', '', '525812019051318032815577508090', '', 0, '2019-05-13 18:11:22', '', '', '', 'Asia/kolkata', 'ASAP1', 1),
(60543, '', '', '', '764086112', '604b4fa7ec77df4db4082a11e3de68677b0862e4', '443781884', 'a3g10', '', '', '', '', 1, 1, 8, '', 10, 13, '', '', '', '', 'a3g10', '', '2', 'A', '20', '', 29, '2019-05-13', '2019-05-08', '2018-05-30', '', '2019-08-07 10:54:52', '', 1, '', '', '525822019051317521415577501343', '', 0, '2019-05-13 18:03:05', '', '', '', 'Asia/kolkata', 'ASAP1', 1),
(60544, '', '', '', '764086112', '604b4fa7ec77df4db4082a11e3de68677b0862e4', '443781884', 'a3g11', '', '', '', '', 1, 1, 92, '', 12, 14, '', '', '', '', 'a3g11', '', '2', 'A', '20', '', 31, '2019-05-07', '2019-05-07', '2018-05-30', '', '2019-08-07 10:54:57', '', 1, '', '', '525832019050719273515572374557', '', 0, '2019-05-07 19:27:41', '', '', '', 'Asia/kolkata', 'ASAP1', 1);

-- --------------------------------------------------------

--
-- Table structure for table `userscreenaccess`
--

CREATE TABLE `userscreenaccess` (
  `id` int(11) NOT NULL,
  `menu` varchar(100) NOT NULL,
  `page` varchar(250) NOT NULL,
  `master` varchar(5) NOT NULL,
  `userid` int(11) NOT NULL,
  `createdby` varchar(100) NOT NULL,
  `creation_date` datetime NOT NULL,
  `modifiedby` varchar(100) NOT NULL,
  `modified_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `users_feedback`
--

CREATE TABLE `users_feedback` (
  `id` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `qone` int(11) NOT NULL,
  `qtwo` int(11) NOT NULL,
  `qthree` int(11) NOT NULL,
  `skillid` varchar(20) NOT NULL,
  `comment` text NOT NULL,
  `created_date` datetime NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `users_q1`
--

CREATE TABLE `users_q1` (
  `id` int(100) NOT NULL,
  `fname` varchar(100) CHARACTER SET latin1 NOT NULL,
  `lname` varchar(100) CHARACTER SET latin1 NOT NULL,
  `gp_id` int(10) NOT NULL,
  `grade_id` int(10) NOT NULL,
  `username` varchar(100) CHARACTER SET latin1 NOT NULL,
  `sid` varchar(100) CHARACTER SET latin1 NOT NULL,
  `section` varchar(10) CHARACTER SET latin1 NOT NULL,
  `status` int(11) NOT NULL,
  `visible` int(11) NOT NULL,
  `AttendedSession` int(11) NOT NULL,
  `CompletedSession` int(11) NOT NULL,
  `scheduled_session` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `user_academic_mapping`
--

CREATE TABLE `user_academic_mapping` (
  `masterid` int(11) NOT NULL,
  `id` int(11) NOT NULL,
  `grade_id` int(11) NOT NULL,
  `gp_id` int(11) NOT NULL,
  `sid` int(11) NOT NULL,
  `section` varchar(10) NOT NULL,
  `academicid` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `visible` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_academic_mapping`
--

INSERT INTO `user_academic_mapping` (`masterid`, `id`, `grade_id`, `gp_id`, `sid`, `section`, `academicid`, `status`, `visible`) VALUES
(3070, 38321, 4, 2, 2, 'A', 20, 1, 1),
(45446, 39746, 7, 5, 2, 'A', 20, 0, 0),
(45447, 39747, 8, 6, 2, 'A', 20, 0, 0),
(53183, 46947, 8, 6, 2, 'A', 20, 1, 1),
(53184, 46948, 9, 7, 2, 'A', 20, 1, 1),
(53185, 46949, 10, 8, 2, 'A', 20, 1, 1),
(54391, 48146, 5, 3, 2, 'A', 20, 1, 1),
(54903, 48659, 13, 93, 2, 'A', 20, 1, 1),
(58105, 51866, 4, 2, 2, 'A', 20, 1, 1),
(58138, 52537, 10, 8, 2, 'A', 20, 1, 1),
(58777, 52538, 5, 3, 2, 'A', 20, 1, 1),
(58778, 52539, 9, 7, 2, 'A', 20, 1, 1),
(59360, 54182, 5, 3, 2, 'A', 20, 1, 1),
(59381, 54217, 8, 6, 2, 'A', 20, 1, 1),
(59382, 54218, 9, 7, 2, 'A', 20, 1, 1),
(59383, 54219, 10, 8, 2, 'A', 20, 1, 1),
(59393, 54229, 12, 92, 2, 'A', 20, 1, 1),
(59394, 54230, 6, 8, 2, 'A', 20, 1, 1),
(59415, 54251, 8, 6, 2, 'A', 20, 1, 1),
(63526, 58364, 5, 3, 2, 'A', 20, 1, 1),
(63527, 58365, 3, 1, 2, 'A', 20, 1, 1),
(63543, 58381, 7, 5, 2, 'A', 20, 1, 1),
(63553, 60438, 4, 2, 2, 'A', 20, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `user_access_log`
--

CREATE TABLE `user_access_log` (
  `id` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `ip` varchar(110) NOT NULL,
  `login_datetime` datetime NOT NULL,
  `country` varchar(16) NOT NULL,
  `regionname` varchar(110) NOT NULL,
  `city` varchar(110) NOT NULL,
  `zip` varchar(16) NOT NULL,
  `created_on` datetime NOT NULL,
  `mailsend` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_access_log`
--

INSERT INTO `user_access_log` (`id`, `userid`, `ip`, `login_datetime`, `country`, `regionname`, `city`, `zip`, `created_on`, `mailsend`) VALUES
(1, 38336, '27.62.132.158', '2018-10-29 20:17:13', 'India', 'Tamil Nadu', 'Chennai', '600001', '0000-00-00 00:00:00', 1),
(2, 38336, '27.62.132.158', '2018-10-29 20:19:08', 'India', 'Tamil Nadu', 'Chennai', '600001', '0000-00-00 00:00:00', 1),
(3, 38336, '27.62.132.158', '2018-10-29 20:22:56', 'India', 'Tamil Nadu', 'Chennai', '600001', '0000-00-00 00:00:00', 1),
(4, 51866, '27.62.132.158', '2018-10-29 20:25:21', 'India', 'Tamil Nadu', 'Chennai', '600001', '0000-00-00 00:00:00', 1),
(5, 51866, '27.5.72.237', '2018-10-31 14:00:23', 'India', 'Tamil Nadu', 'Chennai', '600003', '0000-00-00 00:00:00', 1),
(6, 51866, '27.5.72.237', '2018-10-31 14:14:04', 'India', 'Tamil Nadu', 'Chennai', '600003', '0000-00-00 00:00:00', 1);

-- --------------------------------------------------------

--
-- Table structure for table `user_class_limit`
--

CREATE TABLE `user_class_limit` (
  `id` int(11) NOT NULL,
  `school_id` int(11) NOT NULL,
  `class_id` int(11) NOT NULL,
  `userlimit` int(11) NOT NULL,
  `status` int(1) NOT NULL,
  `createdby` varchar(100) NOT NULL,
  `creation_date` date NOT NULL,
  `modifiedby` varchar(100) NOT NULL,
  `modified_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `user_games`
--

CREATE TABLE `user_games` (
  `id` int(11) NOT NULL,
  `gu_id` int(11) NOT NULL,
  `played_game` text NOT NULL,
  `last_update` varchar(100) NOT NULL,
  `date` varchar(100) NOT NULL,
  `status` int(1) NOT NULL,
  `academicyear` varchar(20) DEFAULT NULL,
  `createdby` varchar(100) NOT NULL,
  `creation_date` date NOT NULL,
  `modifiedby` varchar(100) NOT NULL,
  `modified_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `user_games_history`
--

CREATE TABLE `user_games_history` (
  `id` int(11) NOT NULL,
  `gu_id` int(11) NOT NULL,
  `played_game` text NOT NULL,
  `last_update` varchar(100) NOT NULL,
  `date` varchar(100) NOT NULL,
  `status` int(2) NOT NULL,
  `academicyear` varchar(20) DEFAULT NULL,
  `createdby` varchar(100) NOT NULL,
  `creation_date` date NOT NULL,
  `modifiedby` varchar(100) NOT NULL,
  `modified_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `user_games_plans`
--

CREATE TABLE `user_games_plans` (
  `id` int(100) NOT NULL,
  `gu_id` int(100) NOT NULL,
  `gp_id` int(100) NOT NULL,
  `startdate` varchar(100) NOT NULL,
  `expirytime` varchar(100) NOT NULL,
  `academicyear` varchar(20) DEFAULT NULL,
  `status` int(1) NOT NULL,
  `createdby` varchar(100) NOT NULL,
  `creation_date` date NOT NULL,
  `modifiedby` varchar(100) NOT NULL,
  `modified_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `user_limit`
--

CREATE TABLE `user_limit` (
  `id` int(50) NOT NULL,
  `gu_id` int(50) NOT NULL,
  `gs_id` int(50) NOT NULL,
  `g_id` int(50) NOT NULL,
  `ntimes` int(50) NOT NULL,
  `lastupdate` varchar(100) NOT NULL,
  `academicyear` varchar(20) DEFAULT NULL,
  `createdby` varchar(100) NOT NULL,
  `creation_date` date NOT NULL,
  `modifiedby` varchar(100) NOT NULL,
  `modified_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `user_login_log`
--

CREATE TABLE `user_login_log` (
  `ID` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `sessionid` varchar(255) NOT NULL,
  `first_login_datetime` datetime NOT NULL,
  `created_date` datetime NOT NULL,
  `lastupdate` datetime NOT NULL,
  `logout_date` datetime NOT NULL,
  `ip` varchar(50) NOT NULL,
  `country` varchar(800) NOT NULL,
  `region` varchar(800) NOT NULL,
  `city` varchar(800) NOT NULL,
  `browser` text NOT NULL,
  `isp` text NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `user_newsfeed_history`
--

CREATE TABLE `user_newsfeed_history` (
  `ID` int(11) NOT NULL,
  `S_ID` int(11) NOT NULL COMMENT 'School ID',
  `G_ID` int(11) NOT NULL COMMENT 'Grad ID',
  `U_ID` int(11) NOT NULL COMMENT 'User ID',
  `Scenario` varchar(510) NOT NULL,
  `Datetime` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `user_section_limit`
--

CREATE TABLE `user_section_limit` (
  `id` int(11) NOT NULL,
  `class_id` int(11) NOT NULL,
  `school_admin_id` int(11) NOT NULL,
  `section` varchar(10) NOT NULL,
  `userlimit` int(11) NOT NULL,
  `status` int(1) NOT NULL,
  `createdby` varchar(100) NOT NULL,
  `creation_date` date NOT NULL,
  `modifiedby` varchar(100) NOT NULL,
  `modified_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `user_sparkies_history`
--

CREATE TABLE `user_sparkies_history` (
  `ID` int(11) NOT NULL,
  `S_ID` int(11) NOT NULL COMMENT 'School_id',
  `G_ID` int(11) NOT NULL COMMENT 'Grade_ID',
  `U_ID` int(11) NOT NULL COMMENT 'User_id',
  `Scenario_ID` varchar(255) NOT NULL,
  `Type` enum('REGULAR','BONUS') NOT NULL,
  `Points` int(11) NOT NULL,
  `Datetime` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `utilizationreport`
--

CREATE TABLE `utilizationreport` (
  `id` int(11) NOT NULL,
  `weekval` int(11) NOT NULL,
  `weekvaldate` varchar(110) NOT NULL,
  `period_date` date NOT NULL,
  `period_no` varchar(55) NOT NULL,
  `starttime` varchar(55) NOT NULL,
  `endtime` varchar(55) NOT NULL,
  `gradeid` int(11) NOT NULL,
  `section` varchar(55) NOT NULL,
  `totalusers` int(11) NOT NULL COMMENT 'expected_user',
  `attenusers` int(11) NOT NULL,
  `completeduser` int(11) NOT NULL,
  `avgbspi` varchar(55) NOT NULL,
  `monthno` varchar(55) NOT NULL,
  `year` int(11) NOT NULL,
  `sid` int(11) NOT NULL,
  `academicid` int(11) NOT NULL,
  `total_user` int(11) NOT NULL,
  `sessiondivision` varchar(55) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Stand-in structure for view `viii_bspitoppergradesecwise`
-- (See below for the actual view)
--
CREATE TABLE `viii_bspitoppergradesecwise` (
`bspi` double(19,2)
,`gu_id` int(10)
,`monthNumber` int(2)
,`sid` varchar(100)
,`grade_id` int(10)
,`section` varchar(10)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `vii_1dayskillcorebymon`
-- (See below for the actual view)
--
CREATE TABLE `vii_1dayskillcorebymon` (
`score` double(19,2)
,`gu_id` int(10)
,`gs_id` int(10)
,`sid` varchar(100)
,`grade_id` int(10)
,`section` varchar(10)
,`monthNumber` varchar(2)
,`yearName` varchar(4)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `vii_1dayskillscore`
-- (See below for the actual view)
--
CREATE TABLE `vii_1dayskillscore` (
`score` varchar(50)
,`gs_id` int(10)
,`gu_id` int(10)
,`sid` varchar(100)
,`grade_id` int(10)
,`section` varchar(10)
,`lastupdate` date
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `vii_1dayskillscore_feb`
-- (See below for the actual view)
--
CREATE TABLE `vii_1dayskillscore_feb` (
`score` double
,`gs_id` int(10)
,`gu_id` int(10)
,`sid` varchar(100)
,`grade_id` int(10)
,`section` varchar(10)
,`lastupdate` date
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `vii_1dayuserscore`
-- (See below for the actual view)
--
CREATE TABLE `vii_1dayuserscore` (
`score` double
,`gu_id` int(10)
,`gs_id` int(10)
,`sid` varchar(100)
,`grade_id` int(10)
,`section` varchar(10)
,`lastupdate` date
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `vii_avguserbspiscore`
-- (See below for the actual view)
--
CREATE TABLE `vii_avguserbspiscore` (
`finalscore` double(19,2)
,`gu_id` int(10)
,`sid` varchar(100)
,`grade_id` int(10)
,`section` varchar(10)
,`username` varchar(100)
,`monthNumber` int(2)
,`monthName` varchar(32)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `vii_avguserbspiscorebymon`
-- (See below for the actual view)
--
CREATE TABLE `vii_avguserbspiscorebymon` (
`finalscore` double(19,2)
,`gu_id` int(10)
,`sid` varchar(100)
,`grade_id` int(10)
,`section` varchar(10)
,`username` varchar(100)
,`monthNumber` varchar(2)
,`monthName` varchar(9)
,`yearName` varchar(4)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `vii_bspigradetoppersbysec`
-- (See below for the actual view)
--
CREATE TABLE `vii_bspigradetoppersbysec` (
`bspi` double(19,2)
,`gu_id` int(10)
,`monthNumber` varchar(2)
,`sid` varchar(100)
,`grade_id` int(10)
,`section` varchar(10)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `vii_daywiseuserbspiscore`
-- (See below for the actual view)
--
CREATE TABLE `vii_daywiseuserbspiscore` (
`finalscore` double(19,2)
,`gu_id` int(10)
,`sid` varchar(100)
,`grade_id` int(10)
,`section` varchar(10)
,`username` varchar(100)
,`lastupdate` date
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `vii_daywiseuserbspiscore_feb`
-- (See below for the actual view)
--
CREATE TABLE `vii_daywiseuserbspiscore_feb` (
`finalscore` double(19,2)
,`gu_id` int(10)
,`sid` varchar(100)
,`grade_id` int(10)
,`section` varchar(10)
,`username` varchar(100)
,`lastupdate` date
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `vii_overallbspitoppers`
-- (See below for the actual view)
--
CREATE TABLE `vii_overallbspitoppers` (
`bspi` double(19,2)
,`gu_id` int(10)
,`sid` varchar(100)
,`grade_id` int(10)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `vii_q1_avgv1_user_skillscore`
-- (See below for the actual view)
--
CREATE TABLE `vii_q1_avgv1_user_skillscore` (
`final` double(19,2)
,`gs_id` int(10)
,`gu_id` int(10)
,`sid` varchar(100)
,`skillname` varchar(50)
,`grade_id` int(10)
,`section` varchar(10)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `vii_q1_avgv2_user_skillscore`
-- (See below for the actual view)
--
CREATE TABLE `vii_q1_avgv2_user_skillscore` (
`skillscore` double(19,2)
,`gs_id` int(10)
,`skillname` varchar(50)
,`sid` varchar(100)
,`grade_id` int(10)
,`section` varchar(10)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `vii_q1_avgv3_user_skillscore`
-- (See below for the actual view)
--
CREATE TABLE `vii_q1_avgv3_user_skillscore` (
`score` double(19,2)
,`gs_id` int(10)
,`skillname` varchar(50)
,`sid` varchar(100)
,`grade_id` int(10)
,`section` varchar(10)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `vii_q1_day_user_skillscore`
-- (See below for the actual view)
--
CREATE TABLE `vii_q1_day_user_skillscore` (
`gamescore` double(19,2)
,`gs_id` int(10)
,`lastupdate` date
,`gu_id` int(10)
,`sid` varchar(100)
,`grade_id` int(10)
,`section` varchar(10)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `vii_q1_top_skillscore_grade_sec`
-- (See below for the actual view)
--
CREATE TABLE `vii_q1_top_skillscore_grade_sec` (
`topscore` double(19,2)
,`gs_id` int(10)
,`skillname` varchar(50)
,`sid` varchar(100)
,`grade_id` int(10)
,`section` varchar(10)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `vii_topbspiscore`
-- (See below for the actual view)
--
CREATE TABLE `vii_topbspiscore` (
`bspi` double(19,2)
,`gu_id` int(10)
,`monthNumber` varchar(2)
,`sid` varchar(100)
,`grade_id` int(10)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `vii_topsuperangels`
-- (See below for the actual view)
--
CREATE TABLE `vii_topsuperangels` (
`ans` double
,`gu_id` int(10)
,`monthName` varchar(32)
,`monthNumber` varchar(2)
,`gs_ID` varchar(100)
,`grad_ID` bigint(11)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `vii_userskillscorebydate`
-- (See below for the actual view)
--
CREATE TABLE `vii_userskillscorebydate` (
`score` double(19,2)
,`gu_id` int(10)
,`gs_id` int(10)
,`sid` varchar(100)
,`grade_id` int(10)
,`section` varchar(10)
,`lastupdate` date
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `vi_1dayskillscore`
-- (See below for the actual view)
--
CREATE TABLE `vi_1dayskillscore` (
`score` double(19,2)
,`gu_id` int(10)
,`gs_id` int(10)
,`lastupdate` date
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `vi_1dayuserscore`
-- (See below for the actual view)
--
CREATE TABLE `vi_1dayuserscore` (
`score` double(19,2)
,`gu_id` int(10)
,`lastupdate` date
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `vi_avgofbspi`
-- (See below for the actual view)
--
CREATE TABLE `vi_avgofbspi` (
`score` double(19,2)
,`gu_id` int(10)
,`lastupdate` date
,`sid` varchar(100)
,`grade_id` int(10)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `vi_avguserbspiscore`
-- (See below for the actual view)
--
CREATE TABLE `vi_avguserbspiscore` (
`bspi` double(19,2)
,`gu_id` int(10)
,`monthNumber` int(2)
,`monthName` varchar(32)
,`sid` varchar(100)
,`grade_id` int(10)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `vi_diamond`
-- (See below for the actual view)
--
CREATE TABLE `vi_diamond` (
`userid` int(100)
,`UserName` varchar(201)
,`school_id` varchar(100)
,`Grade` varchar(100)
,`MONTH` int(2)
,`DMEMORY` double(17,0)
,`DVP` double(17,0)
,`DFA` double(17,0)
,`DPS` double(17,0)
,`DLG` double(17,0)
,`dtotal` double(17,0)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `vi_focusandattention`
-- (See below for the actual view)
--
CREATE TABLE `vi_focusandattention` (
`Grade` varchar(100)
,`user_section` varchar(10)
,`UserID` int(100)
,`school_id` varchar(100)
,`UserName` varchar(201)
,`Date` date
,`Memory` binary(0)
,`Visual Processing` binary(0)
,`FocusAndAttention` varchar(50)
,`ProblemSolving` binary(0)
,`Lingustics` binary(0)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `vi_focusandattentionstar`
-- (See below for the actual view)
--
CREATE TABLE `vi_focusandattentionstar` (
`Grade` varchar(100)
,`user_section` varchar(10)
,`UserID` int(100)
,`school_id` varchar(100)
,`UserName` varchar(201)
,`Date` date
,`Memory` binary(0)
,`Visual Processing` binary(0)
,`FocusAndAttention` double(17,0)
,`ProblemSolving` binary(0)
,`Lingustics` binary(0)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `vi_gameplayed`
-- (See below for the actual view)
--
CREATE TABLE `vi_gameplayed` (
`countofval` bigint(21)
,`monthName` varchar(32)
,`monthNumber` varchar(2)
,`school_id` varchar(100)
,`grad_id` bigint(11)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `vi_gold`
-- (See below for the actual view)
--
CREATE TABLE `vi_gold` (
`userid` int(100)
,`UserName` varchar(201)
,`school_id` varchar(100)
,`Grade` varchar(100)
,`MONTH` int(2)
,`GMEMORY` double(17,0)
,`GVP` double(17,0)
,`GFA` double(17,0)
,`GPS` double(17,0)
,`GLG` double(17,0)
,`gtotal` double(17,0)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `vi_gradeskillpivot`
-- (See below for the actual view)
--
CREATE TABLE `vi_gradeskillpivot` (
`Grade` varchar(100)
,`user_section` varchar(10)
,`UserID` int(100)
,`UserName` varchar(201)
,`date` date
,`school_id` varchar(100)
,`Memory` double
,`Visual Processing` double
,`Focus And Attention` double
,`Problem Solving` double
,`Linguistics` double
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `vi_gradeskillpivotsource`
-- (See below for the actual view)
--
CREATE TABLE `vi_gradeskillpivotsource` (
`Grade` varchar(100)
,`user_section` varchar(10)
,`UserID` int(100)
,`UserName` varchar(201)
,`date` date
,`school_id` varchar(100)
,`Memory` varchar(50)
,`vp` varchar(50)
,`FocusAndAttention` varchar(50)
,`ProblemSolving` varchar(50)
,`Lingustics` varchar(50)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `vi_lingustics`
-- (See below for the actual view)
--
CREATE TABLE `vi_lingustics` (
`Grade` varchar(100)
,`user_section` varchar(10)
,`UserID` int(100)
,`school_id` varchar(100)
,`UserName` varchar(201)
,`Date` date
,`Memory` binary(0)
,`Visual Processing` binary(0)
,`FocusAndAttention` binary(0)
,`ProblemSolving` binary(0)
,`Lingustics` varchar(50)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `vi_lingusticsstar`
-- (See below for the actual view)
--
CREATE TABLE `vi_lingusticsstar` (
`Grade` varchar(100)
,`user_section` varchar(10)
,`UserID` int(100)
,`school_id` varchar(100)
,`UserName` varchar(201)
,`Date` date
,`Memory` binary(0)
,`Visual Processing` binary(0)
,`FocusAndAttention` binary(0)
,`ProblemSolving` binary(0)
,`Lingustics` double(17,0)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `vi_maxbspibymsg`
-- (See below for the actual view)
--
CREATE TABLE `vi_maxbspibymsg` (
`bspi` double(19,2)
,`gu_id` int(10)
,`monthNumber` int(2)
,`sid` varchar(100)
,`grade_id` int(10)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `vi_maxfcrownypoints`
-- (See below for the actual view)
--
CREATE TABLE `vi_maxfcrownypoints` (
`points` decimal(32,0)
,`S_ID` int(11)
,`G_ID` int(11)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `vi_memory`
-- (See below for the actual view)
--
CREATE TABLE `vi_memory` (
`Grade` varchar(100)
,`user_section` varchar(10)
,`UserID` int(100)
,`school_id` varchar(100)
,`UserName` varchar(201)
,`Date` date
,`Memory` varchar(50)
,`VP` binary(0)
,`FocusAndAttention` binary(0)
,`ProblemSolving` binary(0)
,`Lingustics` binary(0)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `vi_memorystar`
-- (See below for the actual view)
--
CREATE TABLE `vi_memorystar` (
`Grade` varchar(100)
,`user_section` varchar(10)
,`UserID` int(100)
,`school_id` varchar(100)
,`UserName` varchar(201)
,`Date` date
,`Memory` double(17,0)
,`VP` binary(0)
,`FocusAndAttention` binary(0)
,`ProblemSolving` binary(0)
,`Lingustics` binary(0)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `vi_monthwisebspi`
-- (See below for the actual view)
--
CREATE TABLE `vi_monthwisebspi` (
`bspi` double(19,2)
,`monthNumber` int(2)
,`monthName` varchar(32)
,`sid` varchar(100)
,`grade_id` int(10)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `vi_overallbspitoppers`
-- (See below for the actual view)
--
CREATE TABLE `vi_overallbspitoppers` (
`bspi` double(19,2)
,`gu_id` int(10)
,`lastupdate` date
,`sid` varchar(100)
,`grade_id` int(10)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `vi_overallcrownytoppers`
-- (See below for the actual view)
--
CREATE TABLE `vi_overallcrownytoppers` (
`points` decimal(32,0)
,`G_ID` int(11)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `vi_overallsparkytopper`
-- (See below for the actual view)
--
CREATE TABLE `vi_overallsparkytopper` (
`points` decimal(32,0)
,`monthName` varchar(32)
,`monthNumber` varchar(2)
,`G_ID` int(11)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `vi_problemsolving`
-- (See below for the actual view)
--
CREATE TABLE `vi_problemsolving` (
`Grade` varchar(100)
,`user_section` varchar(10)
,`UserID` int(100)
,`school_id` varchar(100)
,`UserName` varchar(201)
,`Date` date
,`Memory` binary(0)
,`Visual Processing` binary(0)
,`FocusAndAttention` binary(0)
,`ProblemSolving` varchar(50)
,`Lingustics` binary(0)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `vi_problemsolvingstar`
-- (See below for the actual view)
--
CREATE TABLE `vi_problemsolvingstar` (
`Grade` varchar(100)
,`user_section` varchar(10)
,`UserID` int(100)
,`school_id` varchar(100)
,`UserName` varchar(201)
,`Date` date
,`Memory` binary(0)
,`Visual Processing` binary(0)
,`FocusAndAttention` binary(0)
,`ProblemSolving` double(17,0)
,`Lingustics` binary(0)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `vi_silver`
-- (See below for the actual view)
--
CREATE TABLE `vi_silver` (
`userid` int(100)
,`UserName` varchar(201)
,`school_id` varchar(100)
,`Grade` varchar(100)
,`MONTH` int(2)
,`SMEMORY` double(17,0)
,`SVP` double(17,0)
,`SFA` double(17,0)
,`SPS` double(17,0)
,`SLG` double(17,0)
,`stotal` double(17,0)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `vi_star`
-- (See below for the actual view)
--
CREATE TABLE `vi_star` (
`userid` int(100)
,`UserName` varchar(201)
,`school_id` varchar(100)
,`Grade` varchar(100)
,`date` date
,`MEMORYSTAR` double(17,0)
,`VPSTAR` double(17,0)
,`FASTAR` double(17,0)
,`PSSTAR` double(17,0)
,`LGSTAR` double(17,0)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `vi_sumofcrownypoints`
-- (See below for the actual view)
--
CREATE TABLE `vi_sumofcrownypoints` (
`U_ID` int(11)
,`S_ID` int(11)
,`G_ID` int(11)
,`points` decimal(32,0)
,`section` varchar(10)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `vi_sumofcrownypoints1`
-- (See below for the actual view)
--
CREATE TABLE `vi_sumofcrownypoints1` (
`U_ID` int(11)
,`S_ID` int(11)
,`G_ID` int(11)
,`points` decimal(32,0)
,`section` varchar(10)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `vi_toppersbspi`
-- (See below for the actual view)
--
CREATE TABLE `vi_toppersbspi` (
`bspi` double(19,2)
,`monthNumber` int(2)
,`monthName` varchar(32)
,`sid` varchar(100)
,`grade_id` int(10)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `vi_totgamesplayed`
-- (See below for the actual view)
--
CREATE TABLE `vi_totgamesplayed` (
`countofplayed` bigint(21)
,`gu_id` int(10)
,`monthName` varchar(32)
,`monthNumber` varchar(2)
,`gs_ID` varchar(100)
,`grad_ID` bigint(11)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `vi_trophies`
-- (See below for the actual view)
--
CREATE TABLE `vi_trophies` (
`userid` int(100)
,`UserName` varchar(201)
,`school_id` varchar(100)
,`Grade` varchar(100)
,`MONTH` int(2)
,`DIAMOND` double(17,0)
,`GOLD` double(17,0)
,`SILVER` double(17,0)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `vi_vp`
-- (See below for the actual view)
--
CREATE TABLE `vi_vp` (
`Grade` varchar(100)
,`user_section` varchar(10)
,`UserID` int(100)
,`school_id` varchar(100)
,`UserName` varchar(201)
,`Date` date
,`Memory` binary(0)
,`Visual Processing` varchar(50)
,`FocusAndAttention` binary(0)
,`ProblemSolving` binary(0)
,`Lingustics` binary(0)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `vi_vpstar`
-- (See below for the actual view)
--
CREATE TABLE `vi_vpstar` (
`Grade` varchar(100)
,`user_section` varchar(10)
,`UserID` int(100)
,`school_id` varchar(100)
,`UserName` varchar(201)
,`Date` date
,`Memory` binary(0)
,`Visual Processing` double(17,0)
,`FocusAndAttention` binary(0)
,`ProblemSolving` binary(0)
,`Lingustics` binary(0)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `vv1`
-- (See below for the actual view)
--
CREATE TABLE `vv1` (
`U_ID` int(11)
,`S_ID` int(11)
,`G_ID` int(11)
,`points` decimal(32,0)
,`monthName` varchar(32)
,`monthNumber` varchar(2)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `vv2`
-- (See below for the actual view)
--
CREATE TABLE `vv2` (
`points` decimal(32,0)
,`monthName` varchar(32)
,`monthNumber` varchar(2)
,`S_ID` int(11)
,`G_ID` int(11)
);

-- --------------------------------------------------------

--
-- Structure for view `gamedata_updated`
--
DROP TABLE IF EXISTS `gamedata_updated`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `gamedata_updated`  AS  select `gamescore`.`id` AS `id`,`gamescore`.`gu_id` AS `gu_id`,`gamescore`.`gs_id` AS `gs_id`,`gamescore`.`g_id` AS `g_id`,`gamescore`.`que_id` AS `que_id`,`gamescore`.`answer` AS `answer`,`gamescore`.`useranswer` AS `useranswer`,`gamescore`.`game_score` AS `game_score`,`gamescore`.`answer_status` AS `answer_status`,`gamescore`.`timeoverstatus` AS `timeoverstatus`,`gamescore`.`responsetime` AS `responsetime`,`gamescore`.`balancetime` AS `balancetime`,`gamescore`.`lastupdate` AS `lastupdate`,`gamescore`.`creation_date` AS `creation_date`,`gamescore`.`modified_date` AS `modified_date`,`gamescore`.`puzzle_cycle` AS `puzzle_cycle` from `gamescore` where 1 ;

-- --------------------------------------------------------

--
-- Structure for view `game_reports`
--
DROP TABLE IF EXISTS `game_reports`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `game_reports`  AS  select `gamedata`.`id` AS `id`,`gamedata`.`gu_id` AS `gu_id`,`gamedata`.`gp_id` AS `gp_id`,`gamedata`.`gc_id` AS `gc_id`,`gamedata`.`gs_id` AS `gs_id`,`gamedata`.`g_id` AS `g_id`,`gamedata`.`total_question` AS `total_question`,`gamedata`.`attempt_question` AS `attempt_question`,`gamedata`.`answer` AS `answer`,`gamedata`.`game_score` AS `game_score`,`gamedata`.`gtime` AS `gtime`,`gamedata`.`rtime` AS `rtime`,`gamedata`.`crtime` AS `crtime`,`gamedata`.`wrtime` AS `wrtime`,`gamedata`.`lastupdate` AS `lastupdate`,`gamedata`.`Is_schedule` AS `Is_schedule`,`gamedata`.`session_id` AS `session_id`,`gamedata`.`puzzle_cycle` AS `puzzle_cycle` from `gamedata` ;

-- --------------------------------------------------------

--
-- Structure for view `game_reports_detailed`
--
DROP TABLE IF EXISTS `game_reports_detailed`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `game_reports_detailed`  AS  select `u`.`id` AS `userid`,`u`.`grade_id` AS `grade_id`,`u`.`section` AS `section`,`u`.`sid` AS `sid`,`u`.`status` AS `user_status`,`u`.`visible` AS `user_visible`,`gd`.`id` AS `id`,`gd`.`gu_id` AS `gu_id`,`gd`.`gp_id` AS `gp_id`,`gd`.`gc_id` AS `gc_id`,`gd`.`gs_id` AS `gs_id`,`gd`.`g_id` AS `g_id`,`gd`.`total_question` AS `total_question`,`gd`.`attempt_question` AS `attempt_question`,`gd`.`answer` AS `answer`,`gd`.`game_score` AS `game_score`,`gd`.`gtime` AS `gtime`,`gd`.`rtime` AS `rtime`,`gd`.`crtime` AS `crtime`,`gd`.`wrtime` AS `wrtime`,`gd`.`lastupdate` AS `lastupdate`,`gd`.`Is_schedule` AS `Is_schedule` from (`gamedata` `gd` join `users` `u` on((`u`.`id` = `gd`.`gu_id`))) ;

-- --------------------------------------------------------

--
-- Structure for view `popupstar`
--
DROP TABLE IF EXISTS `popupstar`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `popupstar`  AS  select `gr`.`gu_id` AS `gu_id`,`gr`.`lastupdate` AS `lastupdate`,`cs`.`id` AS `cat_id`,(case when (round(max(`gr`.`game_score`),0) < 20) then 0 when ((round(max(`gr`.`game_score`),0) >= 20) and (round(max(`gr`.`game_score`),0) <= 40)) then 1 when ((round(max(`gr`.`game_score`),0) >= 41) and (round(max(`gr`.`game_score`),0) <= 60)) then 2 when ((round(max(`gr`.`game_score`),0) >= 61) and (round(max(`gr`.`game_score`),0) <= 80)) then 3 when ((round(max(`gr`.`game_score`),0) >= 81) and (round(max(`gr`.`game_score`),0) <= 90)) then 4 when ((round(max(`gr`.`game_score`),0) >= 91) and (round(max(`gr`.`game_score`),0) <= 100)) then 5 end) AS `ct`,`cs`.`name` AS `name` from (`game_reports` `gr` join `category_skills` `cs`) where ((extract(month from `gr`.`lastupdate`) = extract(month from curdate())) and (extract(year from `gr`.`lastupdate`) = extract(year from curdate())) and (`cs`.`id` = `gr`.`gs_id`)) group by `gr`.`lastupdate`,`cs`.`id`,`cs`.`name`,`gr`.`gu_id` ;

-- --------------------------------------------------------

--
-- Structure for view `popupstargreaterthanninty`
--
DROP TABLE IF EXISTS `popupstargreaterthanninty`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `popupstargreaterthanninty`  AS  select `gr`.`gu_id` AS `gu_id`,`gr`.`lastupdate` AS `lastupdate`,`cs`.`id` AS `cat_id`,`cs`.`name` AS `name`,round((avg(`gr`.`game_score`) / 20),0) AS `ct` from (`game_reports` `gr` join `category_skills` `cs`) where ((extract(month from `gr`.`lastupdate`) = extract(month from curdate())) and (extract(year from `gr`.`lastupdate`) = extract(year from curdate())) and (`cs`.`id` = `gr`.`gs_id`)) group by `gr`.`lastupdate`,`cs`.`id`,`cs`.`name`,`gr`.`gu_id` having (avg(`gr`.`game_score`) > 90) ;

-- --------------------------------------------------------

--
-- Structure for view `popupstarlessequalninty`
--
DROP TABLE IF EXISTS `popupstarlessequalninty`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `popupstarlessequalninty`  AS  select `gr`.`gu_id` AS `gu_id`,`gr`.`lastupdate` AS `lastupdate`,`cs`.`id` AS `cat_id`,`cs`.`name` AS `name`,ceiling((avg(`gr`.`game_score`) / 20)) AS `ct` from (`game_reports` `gr` join `category_skills` `cs`) where ((extract(month from `gr`.`lastupdate`) = extract(month from curdate())) and (extract(year from `gr`.`lastupdate`) = extract(year from curdate())) and (`cs`.`id` = `gr`.`gs_id`)) group by `gr`.`lastupdate`,`cs`.`id`,`cs`.`name`,`gr`.`gu_id` having (avg(`gr`.`game_score`) <= 90) ;

-- --------------------------------------------------------

--
-- Structure for view `popupstars`
--
DROP TABLE IF EXISTS `popupstars`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `popupstars`  AS  select `gr`.`lastupdate` AS `lastupdate`,`cs`.`name` AS `name`,ceiling((avg(`gr`.`game_score`) / 20)) AS `ct` from (`game_reports` `gr` join `category_skills` `cs`) where ((extract(month from `gr`.`lastupdate`) = extract(month from curdate())) and (extract(year from `gr`.`lastupdate`) = extract(year from curdate())) and (`cs`.`id` = `gr`.`gc_id`)) group by `gr`.`lastupdate`,`cs`.`name` ;

-- --------------------------------------------------------

--
-- Structure for view `popuptrophys`
--
DROP TABLE IF EXISTS `popuptrophys`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `popuptrophys`  AS  select `popupstar`.`gu_id` AS `gu_id`,`popupstar`.`cat_id` AS `catid`,`popupstar`.`name` AS `name`,extract(month from `popupstar`.`lastupdate`) AS `month`,floor((sum(`popupstar`.`ct`) / 60)) AS `diamond`,floor(((sum(`popupstar`.`ct`) % 60) / 30)) AS `gold`,floor((((sum(`popupstar`.`ct`) % 60) % 30) / 15)) AS `silver` from `popupstar` where ((extract(month from `popupstar`.`lastupdate`) = extract(month from curdate())) and (extract(year from `popupstar`.`lastupdate`) = extract(year from curdate()))) group by `popupstar`.`name`,`popupstar`.`gu_id`,extract(month from `popupstar`.`lastupdate`) ;

-- --------------------------------------------------------

--
-- Structure for view `q1_1dayskillcorebymon`
--
DROP TABLE IF EXISTS `q1_1dayskillcorebymon`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `q1_1dayskillcorebymon`  AS  select round(avg(`q1_1dayskillscore`.`score`),2) AS `score`,`q1_1dayskillscore`.`gu_id` AS `gu_id`,`q1_1dayskillscore`.`gs_id` AS `gs_id`,`q1_1dayskillscore`.`sid` AS `sid`,`q1_1dayskillscore`.`grade_id` AS `grade_id`,`q1_1dayskillscore`.`section` AS `section`,`q1_1dayskillscore`.`username` AS `username`,date_format(`q1_1dayskillscore`.`lastupdate`,'%m') AS `monthNumber`,date_format(`q1_1dayskillscore`.`lastupdate`,'%Y') AS `yearName` from `q1_1dayskillscore` group by `q1_1dayskillscore`.`gs_id`,`q1_1dayskillscore`.`gu_id`,month(`q1_1dayskillscore`.`lastupdate`) ;

-- --------------------------------------------------------

--
-- Structure for view `q1_1dayskillscore`
--
DROP TABLE IF EXISTS `q1_1dayskillscore`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `q1_1dayskillscore`  AS  select max(`gr`.`game_score`) AS `score`,`gr`.`gs_id` AS `gs_id`,`gr`.`gu_id` AS `gu_id`,`u`.`sid` AS `sid`,`u`.`grade_id` AS `grade_id`,`u`.`section` AS `section`,`gr`.`lastupdate` AS `lastupdate`,`u`.`username` AS `username` from (`game_reports` `gr` join `users_q1` `u` on((`u`.`id` = `gr`.`gu_id`))) where ((`u`.`status` = 1) and (`u`.`visible` = 1) and `u`.`sid` in (select `schools`.`id` from `schools` where ((`schools`.`visible` = 1) and (`schools`.`status` = 1))) and (`gr`.`gs_id` in (59,60,61,62,63)) and (`gr`.`lastupdate` between (select `academic_year`.`startdate` from `academic_year` where (`academic_year`.`id` = 20)) and (select `academic_year`.`enddate` from `academic_year` where (`academic_year`.`id` = 20)))) group by `gr`.`gs_id`,`gr`.`gu_id`,`gr`.`lastupdate` ;

-- --------------------------------------------------------

--
-- Structure for view `q1_avguserbspiscorebymon`
--
DROP TABLE IF EXISTS `q1_avguserbspiscorebymon`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `q1_avguserbspiscorebymon`  AS  select round((sum(`vii2`.`score`) / 5),2) AS `finalscore`,`vii2`.`gu_id` AS `gu_id`,`vii2`.`sid` AS `sid`,`vii2`.`grade_id` AS `grade_id`,`vii2`.`section` AS `section`,`vii2`.`username` AS `username`,`vii2`.`monthNumber` AS `monthNumber`,monthname(str_to_date(`vii2`.`monthNumber`,'%m')) AS `monthName`,`vii2`.`yearName` AS `yearName` from `q1_1dayskillcorebymon` `vii2` group by `vii2`.`gu_id`,`vii2`.`monthNumber` ;

-- --------------------------------------------------------

--
-- Structure for view `q1_bspibygradesec`
--
DROP TABLE IF EXISTS `q1_bspibygradesec`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `q1_bspibygradesec`  AS  select max(`x1`.`finalbspi`) AS `topbspi`,`x1`.`grade_id` AS `grade_id`,`x1`.`section` AS `section`,`x1`.`sid` AS `sid` from `q1_eachuserbspi` `x1` group by `x1`.`grade_id`,`x1`.`section`,`x1`.`sid` ;

-- --------------------------------------------------------

--
-- Structure for view `q1_crownyuserspoints`
--
DROP TABLE IF EXISTS `q1_crownyuserspoints`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `q1_crownyuserspoints`  AS  select sum(`ush`.`Points`) AS `cpoints`,`ush`.`U_ID` AS `U_ID`,`u`.`fname` AS `fname`,`u`.`lname` AS `lname`,`u`.`grade_id` AS `grade_id`,`u`.`section` AS `section`,`u`.`sid` AS `sid` from ((`user_sparkies_history` `ush` join `users` `u` on((`u`.`id` = `ush`.`U_ID`))) join `schools` `s` on((`u`.`sid` = `s`.`id`))) where ((cast(`ush`.`Datetime` as date) between `s`.`start_date` and '2018-09-30') and (`u`.`status` = 1) and (`u`.`visible` = 1)) group by `ush`.`U_ID`,`u`.`grade_id`,`u`.`section`,`u`.`sid` ;

-- --------------------------------------------------------

--
-- Structure for view `q1_eachuserbspi`
--
DROP TABLE IF EXISTS `q1_eachuserbspi`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `q1_eachuserbspi`  AS  select round(avg(`a1`.`bspi`),2) AS `finalbspi`,`a1`.`gu_id` AS `gu_id`,`a1`.`grade_id` AS `grade_id`,`a1`.`section` AS `section`,`a1`.`fname` AS `fname`,`a1`.`lname` AS `lname`,`a1`.`sid` AS `sid` from `q1_userscore` `a1` group by `a1`.`gu_id` order by round(avg(`a1`.`bspi`),2) desc ;

-- --------------------------------------------------------

--
-- Structure for view `q1_maxcrownypoints`
--
DROP TABLE IF EXISTS `q1_maxcrownypoints`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `q1_maxcrownypoints`  AS  select max(`q1_crownyuserspoints`.`cpoints`) AS `maxpoints`,`q1_crownyuserspoints`.`grade_id` AS `grade_id`,`q1_crownyuserspoints`.`section` AS `section`,`q1_crownyuserspoints`.`sid` AS `sid` from `q1_crownyuserspoints` group by `q1_crownyuserspoints`.`grade_id`,`q1_crownyuserspoints`.`section`,`q1_crownyuserspoints`.`sid` order by max(`q1_crownyuserspoints`.`cpoints`) desc ;

-- --------------------------------------------------------

--
-- Structure for view `q1_userscore`
--
DROP TABLE IF EXISTS `q1_userscore`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `q1_userscore`  AS  select round(avg(`vii`.`score`),2) AS `bspi`,`vii`.`gu_id` AS `gu_id`,`vii`.`gs_id` AS `gs_id`,`vii`.`grade_id` AS `grade_id`,`vii`.`section` AS `section`,`u`.`fname` AS `fname`,`u`.`lname` AS `lname`,`vii`.`sid` AS `sid` from ((`vii_1dayskillscore` `vii` join `users` `u` on((`u`.`id` = `vii`.`gu_id`))) join `schools` `s` on((`u`.`sid` = `s`.`id`))) where (`vii`.`lastupdate` between `s`.`start_date` and '2018-09-30') group by `vii`.`grade_id`,`vii`.`section`,`vii`.`gu_id`,`vii`.`gs_id`,`vii`.`sid` order by round(avg(`vii`.`score`),2) desc ;

-- --------------------------------------------------------

--
-- Structure for view `sc_usertotgamescore`
--
DROP TABLE IF EXISTS `sc_usertotgamescore`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `sc_usertotgamescore`  AS  select `gr`.`gu_id` AS `gu_id`,`u`.`grade_id` AS `grade_id`,`u`.`gp_id` AS `gp_id`,`u`.`sid` AS `sid`,`u`.`section` AS `section`,`u`.`username` AS `username`,`u`.`fname` AS `fname`,sum(`gr`.`game_score`) AS `score` from (`game_reports` `gr` join `users` `u` on((`u`.`id` = `gr`.`gu_id`))) where ((`u`.`status` = 1) and (`u`.`visible` = 1) and (`gr`.`gs_id` in (59,60,61,62,63))) group by `gr`.`gu_id` order by sum(`gr`.`game_score`) desc ;

-- --------------------------------------------------------

--
-- Structure for view `sk_gamedata_updated`
--
DROP TABLE IF EXISTS `sk_gamedata_updated`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `sk_gamedata_updated`  AS  select `sk_gamescore`.`id` AS `id`,`sk_gamescore`.`gu_id` AS `gu_id`,`sk_gamescore`.`gs_id` AS `gs_id`,`sk_gamescore`.`g_id` AS `g_id`,10 AS `total_question`,count(0) AS `attempt_question`,sum(if((`sk_gamescore`.`answer_status` = 'C'),1,0)) AS `answer`,sum(`sk_gamescore`.`game_score`) AS `game_score`,min(`sk_gamescore`.`timeoverstatus`) AS `gtime`,sum(`sk_gamescore`.`responsetime`) AS `rtime`,sum(if((`sk_gamescore`.`answer_status` = 'C'),`sk_gamescore`.`responsetime`,0)) AS `crtime`,sum(if((`sk_gamescore`.`answer_status` = 'W'),`sk_gamescore`.`responsetime`,0)) AS `wrtime`,cast(`sk_gamescore`.`lastupdate` as date) AS `lastupdate`,`sk_gamescore`.`puzzle_cycle` AS `iteration` from `sk_gamescore` group by `sk_gamescore`.`puzzle_cycle`,`sk_gamescore`.`g_id`,`sk_gamescore`.`gs_id`,`sk_gamescore`.`gu_id`,cast(`sk_gamescore`.`lastupdate` as date) ;

-- --------------------------------------------------------

--
-- Structure for view `sk_game_reports`
--
DROP TABLE IF EXISTS `sk_game_reports`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `sk_game_reports`  AS  select `sk_gamedata`.`id` AS `id`,`sk_gamedata`.`gu_id` AS `gu_id`,`sk_gamedata`.`gp_id` AS `gp_id`,`sk_gamedata`.`gc_id` AS `gc_id`,`sk_gamedata`.`gs_id` AS `gs_id`,`sk_gamedata`.`g_id` AS `g_id`,`sk_gamedata`.`total_question` AS `total_question`,`sk_gamedata`.`attempt_question` AS `attempt_question`,`sk_gamedata`.`answer` AS `answer`,`sk_gamedata`.`game_score` AS `game_score`,`sk_gamedata`.`gtime` AS `gtime`,`sk_gamedata`.`rtime` AS `rtime`,`sk_gamedata`.`crtime` AS `crtime`,`sk_gamedata`.`wrtime` AS `wrtime`,`sk_gamedata`.`lastupdate` AS `lastupdate`,`sk_gamedata`.`session_id` AS `session_id`,`sk_gamedata`.`puzzle_cycle` AS `puzzle_cycle` from `sk_gamedata` ;

-- --------------------------------------------------------

--
-- Structure for view `sm_q1_avgv1_user_skillscore`
--
DROP TABLE IF EXISTS `sm_q1_avgv1_user_skillscore`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `sm_q1_avgv1_user_skillscore`  AS  select round(avg(`q1`.`gamescore`),2) AS `final`,`q1`.`gs_id` AS `gs_id`,`q1`.`gu_id` AS `gu_id`,`q1`.`sid` AS `sid`,(select `category_skills`.`name` from `category_skills` where (`category_skills`.`id` = `q1`.`gs_id`)) AS `skillname`,`q1`.`grade_id` AS `grade_id`,`q1`.`section` AS `section` from `sm_q1_day_user_skillscore` `q1` group by `q1`.`lastupdate`,`q1`.`gs_id`,`q1`.`gu_id` order by `q1`.`gs_id`,`q1`.`grade_id`,`q1`.`section` ;

-- --------------------------------------------------------

--
-- Structure for view `sm_q1_avgv2_user_skillscore`
--
DROP TABLE IF EXISTS `sm_q1_avgv2_user_skillscore`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `sm_q1_avgv2_user_skillscore`  AS  select round(avg(`v1`.`final`),2) AS `skillscore`,`v1`.`gs_id` AS `gs_id`,`v1`.`skillname` AS `skillname`,`v1`.`sid` AS `sid`,`v1`.`grade_id` AS `grade_id`,`v1`.`section` AS `section` from `sm_q1_avgv1_user_skillscore` `v1` group by `v1`.`gs_id`,`v1`.`gu_id`,`v1`.`grade_id`,`v1`.`section` ;

-- --------------------------------------------------------

--
-- Structure for view `sm_q1_avgv3_user_skillscore`
--
DROP TABLE IF EXISTS `sm_q1_avgv3_user_skillscore`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `sm_q1_avgv3_user_skillscore`  AS  select round(avg(`v2`.`skillscore`),2) AS `score`,`v2`.`gs_id` AS `gs_id`,`v2`.`skillname` AS `skillname`,`v2`.`sid` AS `sid`,`v2`.`grade_id` AS `grade_id`,`v2`.`section` AS `section` from `sm_q1_avgv2_user_skillscore` `v2` group by `v2`.`gs_id`,`v2`.`sid`,`v2`.`grade_id`,`v2`.`section` order by round(avg(`v2`.`skillscore`),2) desc ;

-- --------------------------------------------------------

--
-- Structure for view `sm_q1_day_user_skillscore`
--
DROP TABLE IF EXISTS `sm_q1_day_user_skillscore`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `sm_q1_day_user_skillscore`  AS  select round(avg(`gr`.`game_score`),2) AS `gamescore`,`gr`.`gs_id` AS `gs_id`,`gr`.`lastupdate` AS `lastupdate`,`gr`.`gu_id` AS `gu_id`,`u`.`sid` AS `sid`,`u`.`grade_id` AS `grade_id`,`u`.`section` AS `section` from (`game_reports` `gr` join `users_q1` `u` on((`gr`.`gu_id` = `u`.`id`))) where ((`gr`.`gs_id` in (59,60,61,62,63)) and (`u`.`visible` = 1) and (`u`.`status` = 1) and (`gr`.`lastupdate` between (select `schools`.`start_date` from `schools` where ((`schools`.`id` = `u`.`sid`) and (`schools`.`status` = 1) and (`schools`.`active` = 1))) and '2018-09-30')) group by `gr`.`lastupdate`,`gr`.`gs_id`,`gr`.`gu_id` order by `gr`.`gs_id`,`gr`.`gu_id`,`u`.`grade_id`,`u`.`section` ;

-- --------------------------------------------------------

--
-- Structure for view `sm_q1_top_skillscore_grade_sec`
--
DROP TABLE IF EXISTS `sm_q1_top_skillscore_grade_sec`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `sm_q1_top_skillscore_grade_sec`  AS  select max(`v3`.`score`) AS `topscore`,`v3`.`gs_id` AS `gs_id`,`v3`.`skillname` AS `skillname`,`v3`.`sid` AS `sid`,`v3`.`grade_id` AS `grade_id`,`v3`.`section` AS `section` from `sm_q1_avgv3_user_skillscore` `v3` group by `v3`.`sid`,`v3`.`grade_id`,`v3`.`section` ;

-- --------------------------------------------------------

--
-- Structure for view `superangel`
--
DROP TABLE IF EXISTS `superangel`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `superangel`  AS  select sum(`game_reports`.`answer`) AS `ans`,`game_reports`.`gu_id` AS `gu_id`,date_format(`game_reports`.`lastupdate`,'%b') AS `monthName`,date_format(`game_reports`.`lastupdate`,'%m') AS `monthNumber`,(select `users`.`sid` from `users` where (`users`.`id` = `game_reports`.`gu_id`)) AS `gs_ID`,(select `users`.`grade_id` from `users` where (`users`.`id` = `game_reports`.`gu_id`)) AS `grad_ID` from `game_reports` where ((convert(date_format(`game_reports`.`lastupdate`,'%Y-%m-%d') using latin1) between (select `academic_year`.`startdate` from `academic_year` where (`academic_year`.`id` = 20)) and (select `academic_year`.`enddate` from `academic_year` where (`academic_year`.`id` = 20))) and `game_reports`.`gu_id` in (select `users`.`id` from `users` where ((`users`.`status` = 1) and (`users`.`visible` = 1)))) group by date_format(`game_reports`.`lastupdate`,'%m'),`game_reports`.`gu_id` ;

-- --------------------------------------------------------

--
-- Structure for view `trophystar`
--
DROP TABLE IF EXISTS `trophystar`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `trophystar`  AS  select `gr`.`gu_id` AS `gu_id`,`cs`.`id` AS `id`,`cs`.`name` AS `name`,(case when (round(max(`gr`.`game_score`),0) < 20) then 0 when ((round(max(`gr`.`game_score`),0) >= 20) and (round(max(`gr`.`game_score`),0) <= 40)) then 1 when ((round(max(`gr`.`game_score`),0) >= 41) and (round(max(`gr`.`game_score`),0) <= 60)) then 2 when ((round(max(`gr`.`game_score`),0) >= 61) and (round(max(`gr`.`game_score`),0) <= 80)) then 3 when ((round(max(`gr`.`game_score`),0) >= 81) and (round(max(`gr`.`game_score`),0) <= 90)) then 4 when ((round(max(`gr`.`game_score`),0) >= 91) and (round(max(`gr`.`game_score`),0) <= 100)) then 5 end) AS `ct`,`gr`.`lastupdate` AS `lastupdate` from (`game_reports` `gr` join `category_skills` `cs`) where (`cs`.`id` = `gr`.`gs_id`) group by `gr`.`lastupdate`,`cs`.`id`,`cs`.`name`,`gr`.`gu_id` ;

-- --------------------------------------------------------

--
-- Structure for view `trophystargreaterthanninty`
--
DROP TABLE IF EXISTS `trophystargreaterthanninty`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `trophystargreaterthanninty`  AS  select `gr`.`gu_id` AS `gu_id`,`cs`.`id` AS `id`,`cs`.`name` AS `name`,`gr`.`lastupdate` AS `lastupdate`,round((avg(`gr`.`game_score`) / 20),0) AS `ct` from (`game_reports` `gr` join `category_skills` `cs`) where (`cs`.`id` = `gr`.`gs_id`) group by `gr`.`lastupdate`,`cs`.`id`,`cs`.`name`,`gr`.`gu_id` having (avg(`gr`.`game_score`) > 90) ;

-- --------------------------------------------------------

--
-- Structure for view `trophystarlessequalninty`
--
DROP TABLE IF EXISTS `trophystarlessequalninty`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `trophystarlessequalninty`  AS  select `gr`.`gu_id` AS `gu_id`,`cs`.`id` AS `id`,`cs`.`name` AS `name`,`gr`.`lastupdate` AS `lastupdate`,ceiling((avg(`gr`.`game_score`) / 20)) AS `ct` from (`game_reports` `gr` join `category_skills` `cs`) where (`cs`.`id` = `gr`.`gs_id`) group by `gr`.`lastupdate`,`cs`.`id`,`cs`.`name`,`gr`.`gu_id` having (avg(`gr`.`game_score`) <= 90) ;

-- --------------------------------------------------------

--
-- Structure for view `viii_bspitoppergradesecwise`
--
DROP TABLE IF EXISTS `viii_bspitoppergradesecwise`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `viii_bspitoppergradesecwise`  AS  select max(`bspi4`.`finalscore`) AS `bspi`,`bspi4`.`gu_id` AS `gu_id`,`bspi4`.`monthNumber` AS `monthNumber`,`bspi4`.`sid` AS `sid`,`bspi4`.`grade_id` AS `grade_id`,`bspi4`.`section` AS `section` from `vii_avguserbspiscore` `bspi4` where `bspi4`.`gu_id` in (select `u`.`id` from `users` `u` where ((`u`.`status` = 1) and (`u`.`visible` = 1))) group by `bspi4`.`sid`,`bspi4`.`grade_id`,`bspi4`.`section` ;

-- --------------------------------------------------------

--
-- Structure for view `vii_1dayskillcorebymon`
--
DROP TABLE IF EXISTS `vii_1dayskillcorebymon`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vii_1dayskillcorebymon`  AS  select round(avg(`vii_1dayskillscore`.`score`),2) AS `score`,`vii_1dayskillscore`.`gu_id` AS `gu_id`,`vii_1dayskillscore`.`gs_id` AS `gs_id`,`vii_1dayskillscore`.`sid` AS `sid`,`vii_1dayskillscore`.`grade_id` AS `grade_id`,`vii_1dayskillscore`.`section` AS `section`,date_format(`vii_1dayskillscore`.`lastupdate`,'%m') AS `monthNumber`,date_format(`vii_1dayskillscore`.`lastupdate`,'%Y') AS `yearName` from `vii_1dayskillscore` group by `vii_1dayskillscore`.`gs_id`,`vii_1dayskillscore`.`gu_id`,month(`vii_1dayskillscore`.`lastupdate`) ;

-- --------------------------------------------------------

--
-- Structure for view `vii_1dayskillscore`
--
DROP TABLE IF EXISTS `vii_1dayskillscore`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vii_1dayskillscore`  AS  select max(`gr`.`game_score`) AS `score`,`gr`.`gs_id` AS `gs_id`,`gr`.`gu_id` AS `gu_id`,`u`.`sid` AS `sid`,`u`.`grade_id` AS `grade_id`,`u`.`section` AS `section`,`gr`.`lastupdate` AS `lastupdate` from (`game_reports` `gr` join `users` `u` on((`u`.`id` = `gr`.`gu_id`))) where ((`u`.`status` = 1) and (`u`.`visible` = 1) and `u`.`sid` in (select `schools`.`id` from `schools` where ((`schools`.`visible` = 1) and (`schools`.`status` = 1))) and (`gr`.`gs_id` in (59,60,61,62,63)) and (`gr`.`lastupdate` between (select `academic_year`.`startdate` from `academic_year` where (`academic_year`.`id` = 20)) and (select `academic_year`.`enddate` from `academic_year` where (`academic_year`.`id` = 20)))) group by `gr`.`gs_id`,`gr`.`gu_id`,`gr`.`lastupdate` ;

-- --------------------------------------------------------

--
-- Structure for view `vii_1dayskillscore_feb`
--
DROP TABLE IF EXISTS `vii_1dayskillscore_feb`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vii_1dayskillscore_feb`  AS  select avg(`gr`.`game_score`) AS `score`,`gr`.`gs_id` AS `gs_id`,`gr`.`gu_id` AS `gu_id`,`u`.`sid` AS `sid`,`u`.`grade_id` AS `grade_id`,`u`.`section` AS `section`,`gr`.`lastupdate` AS `lastupdate` from (`game_reports` `gr` join `users` `u` on((`u`.`id` = `gr`.`gu_id`))) where ((`u`.`status` = 1) and (`u`.`visible` = 1) and `u`.`sid` in (select `schools`.`id` from `schools` where ((`schools`.`visible` = 1) and (`schools`.`status` = 1))) and (`gr`.`gs_id` in (59,60,61,62,63)) and (`gr`.`lastupdate` between '2018-02-01' and '2018-02-28')) group by `gr`.`gs_id`,`gr`.`gu_id`,`gr`.`lastupdate` ;

-- --------------------------------------------------------

--
-- Structure for view `vii_1dayuserscore`
--
DROP TABLE IF EXISTS `vii_1dayuserscore`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vii_1dayuserscore`  AS  select avg(`vii_1dayskillscore`.`score`) AS `score`,`vii_1dayskillscore`.`gu_id` AS `gu_id`,`vii_1dayskillscore`.`gs_id` AS `gs_id`,`vii_1dayskillscore`.`sid` AS `sid`,`vii_1dayskillscore`.`grade_id` AS `grade_id`,`vii_1dayskillscore`.`section` AS `section`,`vii_1dayskillscore`.`lastupdate` AS `lastupdate` from `vii_1dayskillscore` group by `vii_1dayskillscore`.`gs_id`,`vii_1dayskillscore`.`gu_id` ;

-- --------------------------------------------------------

--
-- Structure for view `vii_avguserbspiscore`
--
DROP TABLE IF EXISTS `vii_avguserbspiscore`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vii_avguserbspiscore`  AS  select round((sum(`vii_1dayuserscore`.`score`) / 5),2) AS `finalscore`,`vii_1dayuserscore`.`gu_id` AS `gu_id`,`vii_1dayuserscore`.`sid` AS `sid`,`vii_1dayuserscore`.`grade_id` AS `grade_id`,`vii_1dayuserscore`.`section` AS `section`,(select `users`.`username` from `users` where (`users`.`id` = `vii_1dayuserscore`.`gu_id`)) AS `username`,month(`vii_1dayuserscore`.`lastupdate`) AS `monthNumber`,date_format(`vii_1dayuserscore`.`lastupdate`,'%b') AS `monthName` from `vii_1dayuserscore` group by `vii_1dayuserscore`.`gu_id` ;

-- --------------------------------------------------------

--
-- Structure for view `vii_avguserbspiscorebymon`
--
DROP TABLE IF EXISTS `vii_avguserbspiscorebymon`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vii_avguserbspiscorebymon`  AS  select round((sum(`vii2`.`score`) / 5),2) AS `finalscore`,`vii2`.`gu_id` AS `gu_id`,`vii2`.`sid` AS `sid`,`vii2`.`grade_id` AS `grade_id`,`vii2`.`section` AS `section`,(select `users`.`username` from `users` where (`users`.`id` = `vii2`.`gu_id`)) AS `username`,`vii2`.`monthNumber` AS `monthNumber`,monthname(str_to_date(`vii2`.`monthNumber`,'%m')) AS `monthName`,`vii2`.`yearName` AS `yearName` from `vii_1dayskillcorebymon` `vii2` group by `vii2`.`gu_id`,`vii2`.`monthNumber` ;

-- --------------------------------------------------------

--
-- Structure for view `vii_bspigradetoppersbysec`
--
DROP TABLE IF EXISTS `vii_bspigradetoppersbysec`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vii_bspigradetoppersbysec`  AS  select max(`bspi4`.`finalscore`) AS `bspi`,`bspi4`.`gu_id` AS `gu_id`,`bspi4`.`monthNumber` AS `monthNumber`,`bspi4`.`sid` AS `sid`,`bspi4`.`grade_id` AS `grade_id`,`bspi4`.`section` AS `section` from `vii_avguserbspiscorebymon` `bspi4` where `bspi4`.`gu_id` in (select `u`.`id` from `users` `u` where ((`u`.`status` = 1) and (`u`.`visible` = 1))) group by `bspi4`.`monthNumber`,`bspi4`.`sid`,`bspi4`.`grade_id`,`bspi4`.`section` ;

-- --------------------------------------------------------

--
-- Structure for view `vii_daywiseuserbspiscore`
--
DROP TABLE IF EXISTS `vii_daywiseuserbspiscore`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vii_daywiseuserbspiscore`  AS  select round((sum(`vii_1dayskillscore`.`score`) / 5),2) AS `finalscore`,`vii_1dayskillscore`.`gu_id` AS `gu_id`,`vii_1dayskillscore`.`sid` AS `sid`,`vii_1dayskillscore`.`grade_id` AS `grade_id`,`vii_1dayskillscore`.`section` AS `section`,(select `users`.`username` from `users` where (`users`.`id` = `vii_1dayskillscore`.`gu_id`)) AS `username`,`vii_1dayskillscore`.`lastupdate` AS `lastupdate` from `vii_1dayskillscore` group by `vii_1dayskillscore`.`gu_id`,`vii_1dayskillscore`.`lastupdate` ;

-- --------------------------------------------------------

--
-- Structure for view `vii_daywiseuserbspiscore_feb`
--
DROP TABLE IF EXISTS `vii_daywiseuserbspiscore_feb`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vii_daywiseuserbspiscore_feb`  AS  select round((sum(`vii_1dayskillscore_feb`.`score`) / 5),2) AS `finalscore`,`vii_1dayskillscore_feb`.`gu_id` AS `gu_id`,`vii_1dayskillscore_feb`.`sid` AS `sid`,`vii_1dayskillscore_feb`.`grade_id` AS `grade_id`,`vii_1dayskillscore_feb`.`section` AS `section`,(select `users`.`username` from `users` where (`users`.`id` = `vii_1dayskillscore_feb`.`gu_id`)) AS `username`,`vii_1dayskillscore_feb`.`lastupdate` AS `lastupdate` from `vii_1dayskillscore_feb` group by `vii_1dayskillscore_feb`.`gu_id`,`vii_1dayskillscore_feb`.`lastupdate` ;

-- --------------------------------------------------------

--
-- Structure for view `vii_overallbspitoppers`
--
DROP TABLE IF EXISTS `vii_overallbspitoppers`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vii_overallbspitoppers`  AS  select max(`vii_avguserbspiscore`.`finalscore`) AS `bspi`,`vii_avguserbspiscore`.`gu_id` AS `gu_id`,`vii_avguserbspiscore`.`sid` AS `sid`,`vii_avguserbspiscore`.`grade_id` AS `grade_id` from `vii_avguserbspiscore` group by `vii_avguserbspiscore`.`grade_id` ;

-- --------------------------------------------------------

--
-- Structure for view `vii_q1_avgv1_user_skillscore`
--
DROP TABLE IF EXISTS `vii_q1_avgv1_user_skillscore`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vii_q1_avgv1_user_skillscore`  AS  select round(avg(`q1`.`gamescore`),2) AS `final`,`q1`.`gs_id` AS `gs_id`,`q1`.`gu_id` AS `gu_id`,`q1`.`sid` AS `sid`,(select `category_skills`.`name` from `category_skills` where (`category_skills`.`id` = `q1`.`gs_id`)) AS `skillname`,`q1`.`grade_id` AS `grade_id`,`q1`.`section` AS `section` from `vii_q1_day_user_skillscore` `q1` group by `q1`.`lastupdate`,`q1`.`gs_id`,`q1`.`gu_id` order by `q1`.`gs_id`,`q1`.`grade_id`,`q1`.`section` ;

-- --------------------------------------------------------

--
-- Structure for view `vii_q1_avgv2_user_skillscore`
--
DROP TABLE IF EXISTS `vii_q1_avgv2_user_skillscore`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vii_q1_avgv2_user_skillscore`  AS  select round(avg(`v1`.`final`),2) AS `skillscore`,`v1`.`gs_id` AS `gs_id`,`v1`.`skillname` AS `skillname`,`v1`.`sid` AS `sid`,`v1`.`grade_id` AS `grade_id`,`v1`.`section` AS `section` from `vii_q1_avgv1_user_skillscore` `v1` group by `v1`.`gs_id`,`v1`.`gu_id`,`v1`.`grade_id`,`v1`.`section` ;

-- --------------------------------------------------------

--
-- Structure for view `vii_q1_avgv3_user_skillscore`
--
DROP TABLE IF EXISTS `vii_q1_avgv3_user_skillscore`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vii_q1_avgv3_user_skillscore`  AS  select round(avg(`v2`.`skillscore`),2) AS `score`,`v2`.`gs_id` AS `gs_id`,`v2`.`skillname` AS `skillname`,`v2`.`sid` AS `sid`,`v2`.`grade_id` AS `grade_id`,`v2`.`section` AS `section` from `vii_q1_avgv2_user_skillscore` `v2` group by `v2`.`gs_id`,`v2`.`sid`,`v2`.`grade_id`,`v2`.`section` order by round(avg(`v2`.`skillscore`),2) desc ;

-- --------------------------------------------------------

--
-- Structure for view `vii_q1_day_user_skillscore`
--
DROP TABLE IF EXISTS `vii_q1_day_user_skillscore`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vii_q1_day_user_skillscore`  AS  select round(avg(`gr`.`game_score`),2) AS `gamescore`,`gr`.`gs_id` AS `gs_id`,`gr`.`lastupdate` AS `lastupdate`,`gr`.`gu_id` AS `gu_id`,`u`.`sid` AS `sid`,`u`.`grade_id` AS `grade_id`,`u`.`section` AS `section` from (`game_reports` `gr` join `users` `u` on((`gr`.`gu_id` = `u`.`id`))) where ((`gr`.`gs_id` in (59,60,61,62,63)) and (`u`.`visible` = 1) and (`u`.`status` = 1) and (`gr`.`lastupdate` between (select `schools`.`start_date` from `schools` where ((`schools`.`id` = `u`.`sid`) and (`schools`.`status` = 1) and (`schools`.`active` = 1))) and '2018-09-30')) group by `gr`.`lastupdate`,`gr`.`gs_id`,`gr`.`gu_id` order by `gr`.`gs_id`,`gr`.`gu_id`,`u`.`grade_id`,`u`.`section` ;

-- --------------------------------------------------------

--
-- Structure for view `vii_q1_top_skillscore_grade_sec`
--
DROP TABLE IF EXISTS `vii_q1_top_skillscore_grade_sec`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vii_q1_top_skillscore_grade_sec`  AS  select max(`v3`.`score`) AS `topscore`,`v3`.`gs_id` AS `gs_id`,`v3`.`skillname` AS `skillname`,`v3`.`sid` AS `sid`,`v3`.`grade_id` AS `grade_id`,`v3`.`section` AS `section` from `vii_q1_avgv3_user_skillscore` `v3` group by `v3`.`sid`,`v3`.`grade_id`,`v3`.`section` ;

-- --------------------------------------------------------

--
-- Structure for view `vii_topbspiscore`
--
DROP TABLE IF EXISTS `vii_topbspiscore`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vii_topbspiscore`  AS  select max(`bspi4`.`finalscore`) AS `bspi`,`bspi4`.`gu_id` AS `gu_id`,`bspi4`.`monthNumber` AS `monthNumber`,`bspi4`.`sid` AS `sid`,`bspi4`.`grade_id` AS `grade_id` from `vii_avguserbspiscorebymon` `bspi4` where `bspi4`.`gu_id` in (select `u`.`id` from `users` `u` where ((`u`.`status` = 1) and (`u`.`visible` = 1))) group by `bspi4`.`monthNumber`,`bspi4`.`sid`,`bspi4`.`grade_id` ;

-- --------------------------------------------------------

--
-- Structure for view `vii_topsuperangels`
--
DROP TABLE IF EXISTS `vii_topsuperangels`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vii_topsuperangels`  AS  select max(`superangel`.`ans`) AS `ans`,`superangel`.`gu_id` AS `gu_id`,`superangel`.`monthName` AS `monthName`,`superangel`.`monthNumber` AS `monthNumber`,`superangel`.`gs_ID` AS `gs_ID`,`superangel`.`grad_ID` AS `grad_ID` from `superangel` group by `superangel`.`monthNumber`,`superangel`.`gs_ID`,`superangel`.`grad_ID` ;

-- --------------------------------------------------------

--
-- Structure for view `vii_userskillscorebydate`
--
DROP TABLE IF EXISTS `vii_userskillscorebydate`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vii_userskillscorebydate`  AS  select round(avg(`vii_1dayskillscore`.`score`),2) AS `score`,`vii_1dayskillscore`.`gu_id` AS `gu_id`,`vii_1dayskillscore`.`gs_id` AS `gs_id`,`vii_1dayskillscore`.`sid` AS `sid`,`vii_1dayskillscore`.`grade_id` AS `grade_id`,`vii_1dayskillscore`.`section` AS `section`,`vii_1dayskillscore`.`lastupdate` AS `lastupdate` from `vii_1dayskillscore` group by `vii_1dayskillscore`.`gs_id`,`vii_1dayskillscore`.`gu_id`,`vii_1dayskillscore`.`lastupdate` ;

-- --------------------------------------------------------

--
-- Structure for view `vi_1dayskillscore`
--
DROP TABLE IF EXISTS `vi_1dayskillscore`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vi_1dayskillscore`  AS  select round(avg(`game_reports`.`game_score`),2) AS `score`,`game_reports`.`gu_id` AS `gu_id`,`game_reports`.`gs_id` AS `gs_id`,`game_reports`.`lastupdate` AS `lastupdate` from `game_reports` group by `game_reports`.`gu_id`,`game_reports`.`gs_id`,`game_reports`.`lastupdate` ;

-- --------------------------------------------------------

--
-- Structure for view `vi_1dayuserscore`
--
DROP TABLE IF EXISTS `vi_1dayuserscore`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vi_1dayuserscore`  AS  select round((sum(`bspi1`.`score`) / 5),2) AS `score`,`bspi1`.`gu_id` AS `gu_id`,`bspi1`.`lastupdate` AS `lastupdate` from `vi_1dayskillscore` `bspi1` group by `bspi1`.`gu_id`,`bspi1`.`lastupdate` ;

-- --------------------------------------------------------

--
-- Structure for view `vi_avgofbspi`
--
DROP TABLE IF EXISTS `vi_avgofbspi`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vi_avgofbspi`  AS  select round(avg(`bspi1`.`score`),2) AS `score`,`bspi1`.`gu_id` AS `gu_id`,`bspi1`.`lastupdate` AS `lastupdate`,`u`.`sid` AS `sid`,`u`.`grade_id` AS `grade_id` from (`vi_1dayuserscore` `bspi1` join `users` `u` on((`u`.`id` = `bspi1`.`gu_id`))) where ((`u`.`status` = 1) and (`u`.`visible` = 1) and (`bspi1`.`lastupdate` between (select `ay`.`startdate` from (`academic_year` `ay` join `schools` `s2` on((`s2`.`academic_id` = `ay`.`id`))) where (`s2`.`id` = `u`.`sid`)) and (select `ay`.`enddate` from (`academic_year` `ay` join `schools` `s2` on((`s2`.`academic_id` = `ay`.`id`))) where (`s2`.`id` = `u`.`sid`)))) group by `bspi1`.`gu_id` ;

-- --------------------------------------------------------

--
-- Structure for view `vi_avguserbspiscore`
--
DROP TABLE IF EXISTS `vi_avguserbspiscore`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vi_avguserbspiscore`  AS  select round(avg(`bspi2`.`score`),2) AS `bspi`,`bspi2`.`gu_id` AS `gu_id`,month(`bspi2`.`lastupdate`) AS `monthNumber`,date_format(`bspi2`.`lastupdate`,'%b') AS `monthName`,`u`.`sid` AS `sid`,`u`.`grade_id` AS `grade_id` from (`vi_1dayuserscore` `bspi2` join `users` `u` on((`u`.`id` = `bspi2`.`gu_id`))) where `bspi2`.`gu_id` in (select `users`.`id` from `users` where ((`users`.`status` = 1) and (`users`.`visible` = 1))) group by `bspi2`.`gu_id`,month(`bspi2`.`lastupdate`) ;

-- --------------------------------------------------------

--
-- Structure for view `vi_diamond`
--
DROP TABLE IF EXISTS `vi_diamond`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vi_diamond`  AS  select `vi_star`.`userid` AS `userid`,`vi_star`.`UserName` AS `UserName`,`vi_star`.`school_id` AS `school_id`,`vi_star`.`Grade` AS `Grade`,extract(month from `vi_star`.`date`) AS `MONTH`,floor((sum(`vi_star`.`MEMORYSTAR`) / 60)) AS `DMEMORY`,floor((sum(`vi_star`.`VPSTAR`) / 60)) AS `DVP`,floor((sum(`vi_star`.`FASTAR`) / 60)) AS `DFA`,floor((sum(`vi_star`.`PSSTAR`) / 60)) AS `DPS`,floor((sum(`vi_star`.`LGSTAR`) / 60)) AS `DLG`,((((floor((sum(`vi_star`.`MEMORYSTAR`) / 60)) + floor((sum(`vi_star`.`VPSTAR`) / 60))) + floor((sum(`vi_star`.`FASTAR`) / 60))) + floor((sum(`vi_star`.`PSSTAR`) / 60))) + floor((sum(`vi_star`.`LGSTAR`) / 60))) AS `dtotal` from `vi_star` group by `vi_star`.`userid`,`vi_star`.`UserName`,`vi_star`.`school_id`,`vi_star`.`Grade`,extract(month from `vi_star`.`date`) ;

-- --------------------------------------------------------

--
-- Structure for view `vi_focusandattention`
--
DROP TABLE IF EXISTS `vi_focusandattention`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vi_focusandattention`  AS  select `cls`.`classname` AS `Grade`,`sec`.`section` AS `user_section`,`usr`.`id` AS `UserID`,`usr`.`sid` AS `school_id`,concat(`usr`.`fname`,' ',`usr`.`lname`) AS `UserName`,`gr`.`lastupdate` AS `Date`,NULL AS `Memory`,NULL AS `Visual Processing`,`gr`.`game_score` AS `FocusAndAttention`,NULL AS `ProblemSolving`,NULL AS `Lingustics` from ((((`game_reports` `gr` join `users` `usr` on((`usr`.`id` = `gr`.`gu_id`))) join `class` `cls` on((`cls`.`id` = `usr`.`grade_id`))) join `skl_class_section` `sec` on((`sec`.`section` = `usr`.`section`))) join `category_skills` `cs` on((`cs`.`id` = `gr`.`gs_id`))) ;

-- --------------------------------------------------------

--
-- Structure for view `vi_focusandattentionstar`
--
DROP TABLE IF EXISTS `vi_focusandattentionstar`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vi_focusandattentionstar`  AS  select `cls`.`classname` AS `Grade`,`sec`.`section` AS `user_section`,`usr`.`id` AS `UserID`,`usr`.`sid` AS `school_id`,concat(`usr`.`fname`,' ',`usr`.`lname`) AS `UserName`,`gr`.`lastupdate` AS `Date`,NULL AS `Memory`,NULL AS `Visual Processing`,ifnull(floor(avg((`gr`.`game_score` / 20))),0) AS `FocusAndAttention`,NULL AS `ProblemSolving`,NULL AS `Lingustics` from ((((`game_reports` `gr` join `users` `usr` on((`usr`.`id` = `gr`.`gu_id`))) join `class` `cls` on((`cls`.`id` = `usr`.`grade_id`))) join `skl_class_section` `sec` on((`sec`.`section` = `usr`.`section`))) join `category_skills` `cs` on((`cs`.`id` = `gr`.`gs_id`))) where (`cs`.`name` = 'Focus And Attention') ;

-- --------------------------------------------------------

--
-- Structure for view `vi_gameplayed`
--
DROP TABLE IF EXISTS `vi_gameplayed`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vi_gameplayed`  AS  select max(`vi_totgamesplayed`.`countofplayed`) AS `countofval`,`vi_totgamesplayed`.`monthName` AS `monthName`,`vi_totgamesplayed`.`monthNumber` AS `monthNumber`,`vi_totgamesplayed`.`gs_ID` AS `school_id`,`vi_totgamesplayed`.`grad_ID` AS `grad_id` from `vi_totgamesplayed` where `vi_totgamesplayed`.`gu_id` in (select `users`.`id` from `users` where ((`users`.`status` = 1) and (`users`.`visible` = 1))) group by `vi_totgamesplayed`.`monthName`,`vi_totgamesplayed`.`gs_ID`,`vi_totgamesplayed`.`grad_ID` ;

-- --------------------------------------------------------

--
-- Structure for view `vi_gold`
--
DROP TABLE IF EXISTS `vi_gold`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vi_gold`  AS  select `vi_star`.`userid` AS `userid`,`vi_star`.`UserName` AS `UserName`,`vi_star`.`school_id` AS `school_id`,`vi_star`.`Grade` AS `Grade`,extract(month from `vi_star`.`date`) AS `MONTH`,floor(((sum(`vi_star`.`MEMORYSTAR`) % 60) / 30)) AS `GMEMORY`,floor(((sum(`vi_star`.`VPSTAR`) % 60) / 30)) AS `GVP`,floor(((sum(`vi_star`.`FASTAR`) % 60) / 30)) AS `GFA`,floor(((sum(`vi_star`.`PSSTAR`) % 60) / 30)) AS `GPS`,floor(((sum(`vi_star`.`LGSTAR`) % 60) / 30)) AS `GLG`,((((floor(((sum(`vi_star`.`MEMORYSTAR`) % 60) / 30)) + floor(((sum(`vi_star`.`VPSTAR`) % 60) / 30))) + floor(((sum(`vi_star`.`FASTAR`) % 60) / 30))) + floor(((sum(`vi_star`.`PSSTAR`) % 60) / 30))) + floor(((sum(`vi_star`.`LGSTAR`) % 60) / 30))) AS `gtotal` from `vi_star` group by `vi_star`.`userid`,`vi_star`.`UserName`,`vi_star`.`school_id`,`vi_star`.`Grade`,extract(month from `vi_star`.`date`) ;

-- --------------------------------------------------------

--
-- Structure for view `vi_gradeskillpivot`
--
DROP TABLE IF EXISTS `vi_gradeskillpivot`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vi_gradeskillpivot`  AS  select `vi_gradeskillpivotsource`.`Grade` AS `Grade`,`vi_gradeskillpivotsource`.`user_section` AS `user_section`,`vi_gradeskillpivotsource`.`UserID` AS `UserID`,`vi_gradeskillpivotsource`.`UserName` AS `UserName`,`vi_gradeskillpivotsource`.`date` AS `date`,`vi_gradeskillpivotsource`.`school_id` AS `school_id`,avg(`vi_gradeskillpivotsource`.`Memory`) AS `Memory`,avg(`vi_gradeskillpivotsource`.`vp`) AS `Visual Processing`,avg(`vi_gradeskillpivotsource`.`FocusAndAttention`) AS `Focus And Attention`,avg(`vi_gradeskillpivotsource`.`ProblemSolving`) AS `Problem Solving`,avg(`vi_gradeskillpivotsource`.`Lingustics`) AS `Linguistics` from `vi_gradeskillpivotsource` group by `vi_gradeskillpivotsource`.`Grade`,`vi_gradeskillpivotsource`.`user_section`,`vi_gradeskillpivotsource`.`UserID`,`vi_gradeskillpivotsource`.`UserName`,`vi_gradeskillpivotsource`.`date` ;

-- --------------------------------------------------------

--
-- Structure for view `vi_gradeskillpivotsource`
--
DROP TABLE IF EXISTS `vi_gradeskillpivotsource`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vi_gradeskillpivotsource`  AS  select `vi_memory`.`Grade` AS `Grade`,`vi_memory`.`user_section` AS `user_section`,`vi_memory`.`UserID` AS `UserID`,`vi_memory`.`UserName` AS `UserName`,`vi_memory`.`Date` AS `date`,`vi_memory`.`school_id` AS `school_id`,`vi_memory`.`Memory` AS `Memory`,`vi_memory`.`VP` AS `vp`,`vi_memory`.`FocusAndAttention` AS `FocusAndAttention`,`vi_memory`.`ProblemSolving` AS `ProblemSolving`,`vi_memory`.`Lingustics` AS `Lingustics` from `vi_memory` union all select `vi_vp`.`Grade` AS `Grade`,`vi_vp`.`user_section` AS `user_section`,`vi_vp`.`UserID` AS `UserID`,`vi_vp`.`UserName` AS `UserName`,`vi_vp`.`Date` AS `date`,`vi_vp`.`school_id` AS `school_id`,`vi_vp`.`Memory` AS `Memory`,`vi_vp`.`Visual Processing` AS `Visual Processing`,`vi_vp`.`FocusAndAttention` AS `FocusAndAttention`,`vi_vp`.`ProblemSolving` AS `ProblemSolving`,`vi_vp`.`Lingustics` AS `Lingustics` from `vi_vp` union all select `vi_focusandattention`.`Grade` AS `Grade`,`vi_focusandattention`.`user_section` AS `user_section`,`vi_focusandattention`.`UserID` AS `UserID`,`vi_focusandattention`.`UserName` AS `UserName`,`vi_focusandattention`.`Date` AS `date`,`vi_focusandattention`.`school_id` AS `school_id`,`vi_focusandattention`.`Memory` AS `Memory`,`vi_focusandattention`.`Visual Processing` AS `Visual Processing`,`vi_focusandattention`.`FocusAndAttention` AS `FocusAndAttention`,`vi_focusandattention`.`ProblemSolving` AS `ProblemSolving`,`vi_focusandattention`.`Lingustics` AS `Lingustics` from `vi_focusandattention` union all select `vi_problemsolving`.`Grade` AS `Grade`,`vi_problemsolving`.`user_section` AS `user_section`,`vi_problemsolving`.`UserID` AS `UserID`,`vi_problemsolving`.`UserName` AS `UserName`,`vi_problemsolving`.`Date` AS `date`,`vi_problemsolving`.`school_id` AS `school_id`,`vi_problemsolving`.`Memory` AS `Memory`,`vi_problemsolving`.`Visual Processing` AS `Visual Processing`,`vi_problemsolving`.`FocusAndAttention` AS `FocusAndAttention`,`vi_problemsolving`.`ProblemSolving` AS `ProblemSolving`,`vi_problemsolving`.`Lingustics` AS `Lingustics` from `vi_problemsolving` union all select `vi_lingustics`.`Grade` AS `Grade`,`vi_lingustics`.`user_section` AS `user_section`,`vi_lingustics`.`UserID` AS `UserID`,`vi_lingustics`.`UserName` AS `UserName`,`vi_lingustics`.`Date` AS `date`,`vi_lingustics`.`school_id` AS `school_id`,`vi_lingustics`.`Memory` AS `Memory`,`vi_lingustics`.`Visual Processing` AS `Visual Processing`,`vi_lingustics`.`FocusAndAttention` AS `FocusAndAttention`,`vi_lingustics`.`ProblemSolving` AS `ProblemSolving`,`vi_lingustics`.`Lingustics` AS `Lingustics` from `vi_lingustics` ;

-- --------------------------------------------------------

--
-- Structure for view `vi_lingustics`
--
DROP TABLE IF EXISTS `vi_lingustics`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vi_lingustics`  AS  select `cls`.`classname` AS `Grade`,`sec`.`section` AS `user_section`,`usr`.`id` AS `UserID`,`usr`.`sid` AS `school_id`,concat(`usr`.`fname`,' ',`usr`.`lname`) AS `UserName`,`gr`.`lastupdate` AS `Date`,NULL AS `Memory`,NULL AS `Visual Processing`,NULL AS `FocusAndAttention`,NULL AS `ProblemSolving`,`gr`.`game_score` AS `Lingustics` from ((((`game_reports` `gr` join `users` `usr` on((`usr`.`id` = `gr`.`gu_id`))) join `class` `cls` on((`cls`.`id` = `usr`.`grade_id`))) join `skl_class_section` `sec` on((`sec`.`section` = `usr`.`section`))) join `category_skills` `cs` on((`cs`.`id` = `gr`.`gs_id`))) where (`cs`.`name` = 'Linguistics') ;

-- --------------------------------------------------------

--
-- Structure for view `vi_lingusticsstar`
--
DROP TABLE IF EXISTS `vi_lingusticsstar`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vi_lingusticsstar`  AS  select `cls`.`classname` AS `Grade`,`sec`.`section` AS `user_section`,`usr`.`id` AS `UserID`,`usr`.`sid` AS `school_id`,concat(`usr`.`fname`,' ',`usr`.`lname`) AS `UserName`,`gr`.`lastupdate` AS `Date`,NULL AS `Memory`,NULL AS `Visual Processing`,NULL AS `FocusAndAttention`,NULL AS `ProblemSolving`,ifnull(floor(avg((`gr`.`game_score` / 20))),0) AS `Lingustics` from ((((`game_reports` `gr` join `users` `usr` on((`usr`.`id` = `gr`.`gu_id`))) join `class` `cls` on((`cls`.`id` = `usr`.`grade_id`))) join `skl_class_section` `sec` on((`sec`.`section` = `usr`.`section`))) join `category_skills` `cs` on((`cs`.`id` = `gr`.`gs_id`))) where (`cs`.`name` = 'Linguistics') ;

-- --------------------------------------------------------

--
-- Structure for view `vi_maxbspibymsg`
--
DROP TABLE IF EXISTS `vi_maxbspibymsg`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vi_maxbspibymsg`  AS  select max(`bspi4`.`bspi`) AS `bspi`,`bspi4`.`gu_id` AS `gu_id`,`bspi4`.`monthNumber` AS `monthNumber`,`bspi4`.`sid` AS `sid`,`bspi4`.`grade_id` AS `grade_id` from `vi_avguserbspiscore` `bspi4` where `bspi4`.`gu_id` in (select `users`.`id` from `users` where ((`users`.`status` = 1) and (`users`.`visible` = 1))) group by `bspi4`.`monthNumber`,`bspi4`.`sid`,`bspi4`.`grade_id` ;

-- --------------------------------------------------------

--
-- Structure for view `vi_maxfcrownypoints`
--
DROP TABLE IF EXISTS `vi_maxfcrownypoints`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vi_maxfcrownypoints`  AS  select max(`vv1`.`points`) AS `points`,`vv1`.`S_ID` AS `S_ID`,`vv1`.`G_ID` AS `G_ID` from `vi_sumofcrownypoints` `vv1` group by `vv1`.`S_ID`,`vv1`.`G_ID` ;

-- --------------------------------------------------------

--
-- Structure for view `vi_memory`
--
DROP TABLE IF EXISTS `vi_memory`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vi_memory`  AS  select `cls`.`classname` AS `Grade`,`sec`.`section` AS `user_section`,`usr`.`id` AS `UserID`,`usr`.`sid` AS `school_id`,concat(`usr`.`fname`,' ',`usr`.`lname`) AS `UserName`,`gr`.`lastupdate` AS `Date`,`gr`.`game_score` AS `Memory`,NULL AS `VP`,NULL AS `FocusAndAttention`,NULL AS `ProblemSolving`,NULL AS `Lingustics` from ((((`game_reports` `gr` join `users` `usr` on((`usr`.`id` = `gr`.`gu_id`))) join `class` `cls` on((`cls`.`id` = `usr`.`grade_id`))) join `skl_class_section` `sec` on((`sec`.`section` = `usr`.`section`))) join `category_skills` `cs` on((`cs`.`id` = `gr`.`gs_id`))) where (`cs`.`name` = 'Memory') ;

-- --------------------------------------------------------

--
-- Structure for view `vi_memorystar`
--
DROP TABLE IF EXISTS `vi_memorystar`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vi_memorystar`  AS  select `cls`.`classname` AS `Grade`,`sec`.`section` AS `user_section`,`usr`.`id` AS `UserID`,`usr`.`sid` AS `school_id`,concat(`usr`.`fname`,' ',`usr`.`lname`) AS `UserName`,`gr`.`lastupdate` AS `Date`,ifnull(floor(avg((`gr`.`game_score` / 20))),0) AS `Memory`,NULL AS `VP`,NULL AS `FocusAndAttention`,NULL AS `ProblemSolving`,NULL AS `Lingustics` from ((((`game_reports` `gr` join `users` `usr` on((`usr`.`id` = `gr`.`gu_id`))) join `class` `cls` on((`cls`.`id` = `usr`.`grade_id`))) join `skl_class_section` `sec` on((`sec`.`section` = `usr`.`section`))) join `category_skills` `cs` on((`cs`.`id` = `gr`.`gs_id`))) where (`cs`.`name` = 'Memory') ;

-- --------------------------------------------------------

--
-- Structure for view `vi_monthwisebspi`
--
DROP TABLE IF EXISTS `vi_monthwisebspi`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vi_monthwisebspi`  AS  select max(`bspi3`.`bspi`) AS `bspi`,`bspi3`.`monthNumber` AS `monthNumber`,`bspi3`.`monthName` AS `monthName`,`bspi3`.`sid` AS `sid`,`bspi3`.`grade_id` AS `grade_id` from `vi_avguserbspiscore` `bspi3` group by `bspi3`.`monthNumber` ;

-- --------------------------------------------------------

--
-- Structure for view `vi_overallbspitoppers`
--
DROP TABLE IF EXISTS `vi_overallbspitoppers`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vi_overallbspitoppers`  AS  select max(`vi_avgofbspi`.`score`) AS `bspi`,`vi_avgofbspi`.`gu_id` AS `gu_id`,`vi_avgofbspi`.`lastupdate` AS `lastupdate`,`vi_avgofbspi`.`sid` AS `sid`,`vi_avgofbspi`.`grade_id` AS `grade_id` from `vi_avgofbspi` where `vi_avgofbspi`.`sid` in (select `schools`.`id` from `schools` where (`schools`.`visible` = 1)) group by `vi_avgofbspi`.`grade_id` ;

-- --------------------------------------------------------

--
-- Structure for view `vi_overallcrownytoppers`
--
DROP TABLE IF EXISTS `vi_overallcrownytoppers`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vi_overallcrownytoppers`  AS  select max(`vv2`.`points`) AS `points`,`vv2`.`G_ID` AS `G_ID` from `vi_maxfcrownypoints` `vv2` group by `vv2`.`G_ID` ;

-- --------------------------------------------------------

--
-- Structure for view `vi_overallsparkytopper`
--
DROP TABLE IF EXISTS `vi_overallsparkytopper`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vi_overallsparkytopper`  AS  select max(`vv2`.`points`) AS `points`,`vv2`.`monthName` AS `monthName`,`vv2`.`monthNumber` AS `monthNumber`,`vv2`.`G_ID` AS `G_ID` from `vv2` where `vv2`.`S_ID` in (select `schools`.`id` from `schools` where (`schools`.`visible` = 1)) group by `vv2`.`monthName`,`vv2`.`G_ID` ;

-- --------------------------------------------------------

--
-- Structure for view `vi_problemsolving`
--
DROP TABLE IF EXISTS `vi_problemsolving`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vi_problemsolving`  AS  select `cls`.`classname` AS `Grade`,`sec`.`section` AS `user_section`,`usr`.`id` AS `UserID`,`usr`.`sid` AS `school_id`,concat(`usr`.`fname`,' ',`usr`.`lname`) AS `UserName`,`gr`.`lastupdate` AS `Date`,NULL AS `Memory`,NULL AS `Visual Processing`,NULL AS `FocusAndAttention`,`gr`.`game_score` AS `ProblemSolving`,NULL AS `Lingustics` from ((((`game_reports` `gr` join `users` `usr` on((`usr`.`id` = `gr`.`gu_id`))) join `class` `cls` on((`cls`.`id` = `usr`.`grade_id`))) join `skl_class_section` `sec` on((`sec`.`section` = `usr`.`section`))) join `category_skills` `cs` on((`cs`.`id` = `gr`.`gs_id`))) where (`cs`.`name` = 'Problem Solving') ;

-- --------------------------------------------------------

--
-- Structure for view `vi_problemsolvingstar`
--
DROP TABLE IF EXISTS `vi_problemsolvingstar`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vi_problemsolvingstar`  AS  select `cls`.`classname` AS `Grade`,`sec`.`section` AS `user_section`,`usr`.`id` AS `UserID`,`usr`.`sid` AS `school_id`,concat(`usr`.`fname`,' ',`usr`.`lname`) AS `UserName`,`gr`.`lastupdate` AS `Date`,NULL AS `Memory`,NULL AS `Visual Processing`,NULL AS `FocusAndAttention`,ifnull(floor(avg((`gr`.`game_score` / 20))),0) AS `ProblemSolving`,NULL AS `Lingustics` from ((((`game_reports` `gr` join `users` `usr` on((`usr`.`id` = `gr`.`gu_id`))) join `class` `cls` on((`cls`.`id` = `usr`.`grade_id`))) join `skl_class_section` `sec` on((`sec`.`section` = `usr`.`section`))) join `category_skills` `cs` on((`cs`.`id` = `gr`.`gs_id`))) where (`cs`.`name` = 'Problem Solving') ;

-- --------------------------------------------------------

--
-- Structure for view `vi_silver`
--
DROP TABLE IF EXISTS `vi_silver`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vi_silver`  AS  select `vi_star`.`userid` AS `userid`,`vi_star`.`UserName` AS `UserName`,`vi_star`.`school_id` AS `school_id`,`vi_star`.`Grade` AS `Grade`,extract(month from `vi_star`.`date`) AS `MONTH`,floor((((sum(`vi_star`.`MEMORYSTAR`) % 60) % 30) / 15)) AS `SMEMORY`,floor((((sum(`vi_star`.`VPSTAR`) % 60) % 30) / 15)) AS `SVP`,floor((((sum(`vi_star`.`FASTAR`) % 60) % 30) / 15)) AS `SFA`,floor((((sum(`vi_star`.`PSSTAR`) % 60) % 30) / 15)) AS `SPS`,floor((((sum(`vi_star`.`LGSTAR`) % 60) % 30) / 15)) AS `SLG`,((((floor((((sum(`vi_star`.`MEMORYSTAR`) % 60) % 30) / 15)) + floor((((sum(`vi_star`.`VPSTAR`) % 60) % 30) / 15))) + floor((((sum(`vi_star`.`FASTAR`) % 60) % 30) / 15))) + floor((((sum(`vi_star`.`PSSTAR`) % 60) % 30) / 15))) + floor((((sum(`vi_star`.`LGSTAR`) % 60) % 30) / 15))) AS `stotal` from `vi_star` group by `vi_star`.`userid`,`vi_star`.`UserName`,`vi_star`.`school_id`,`vi_star`.`Grade`,extract(month from `vi_star`.`date`) ;

-- --------------------------------------------------------

--
-- Structure for view `vi_star`
--
DROP TABLE IF EXISTS `vi_star`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vi_star`  AS  select `vi_gradeskillpivotsource`.`UserID` AS `userid`,`vi_gradeskillpivotsource`.`UserName` AS `UserName`,`vi_gradeskillpivotsource`.`school_id` AS `school_id`,`vi_gradeskillpivotsource`.`Grade` AS `Grade`,`vi_gradeskillpivotsource`.`date` AS `date`,floor((avg(ifnull(`vi_gradeskillpivotsource`.`Memory`,0)) / 20)) AS `MEMORYSTAR`,floor((avg(ifnull(`vi_gradeskillpivotsource`.`vp`,0)) / 20)) AS `VPSTAR`,floor((avg(ifnull(`vi_gradeskillpivotsource`.`FocusAndAttention`,0)) / 20)) AS `FASTAR`,floor((avg(ifnull(`vi_gradeskillpivotsource`.`ProblemSolving`,0)) / 20)) AS `PSSTAR`,floor((avg(ifnull(`vi_gradeskillpivotsource`.`Lingustics`,0)) / 20)) AS `LGSTAR` from `vi_gradeskillpivotsource` group by `vi_gradeskillpivotsource`.`UserID`,`vi_gradeskillpivotsource`.`UserName`,`vi_gradeskillpivotsource`.`school_id`,`vi_gradeskillpivotsource`.`Grade`,`vi_gradeskillpivotsource`.`date` ;

-- --------------------------------------------------------

--
-- Structure for view `vi_sumofcrownypoints`
--
DROP TABLE IF EXISTS `vi_sumofcrownypoints`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vi_sumofcrownypoints`  AS  select `a2`.`U_ID` AS `U_ID`,`a2`.`S_ID` AS `S_ID`,`a2`.`G_ID` AS `G_ID`,sum(`a2`.`Points`) AS `points`,(select `users`.`section` from `users` where (`users`.`id` = `a2`.`U_ID`)) AS `section` from `user_sparkies_history` `a2` where ((convert(date_format(`a2`.`Datetime`,'%Y-%m-%d') using latin1) between (select `academic_year`.`startdate` from `academic_year` where (`academic_year`.`id` = 20)) and (select `academic_year`.`enddate` from `academic_year` where (`academic_year`.`id` = 20))) and `a2`.`U_ID` in (select `users`.`id` from `users` where ((`users`.`status` = 1) and (`users`.`visible` = 1)))) group by `a2`.`U_ID` ;

-- --------------------------------------------------------

--
-- Structure for view `vi_sumofcrownypoints1`
--
DROP TABLE IF EXISTS `vi_sumofcrownypoints1`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vi_sumofcrownypoints1`  AS  select `a2`.`U_ID` AS `U_ID`,`a2`.`S_ID` AS `S_ID`,`a2`.`G_ID` AS `G_ID`,sum(`a2`.`Points`) AS `points`,(select `users`.`section` from `users` where (`users`.`id` = `a2`.`U_ID`)) AS `section` from (`user_sparkies_history` `a2` join `users` `u` on((`u`.`id` = `a2`.`U_ID`))) where ((convert(date_format(`a2`.`Datetime`,'%Y-%m-%d') using latin1) between (select `academic_year`.`startdate` from `academic_year` where (`academic_year`.`id` = 20)) and (select `academic_year`.`enddate` from `academic_year` where (`academic_year`.`id` = 20))) and (`u`.`status` = 1) and (`u`.`visible` = 1)) group by `a2`.`U_ID` ;

-- --------------------------------------------------------

--
-- Structure for view `vi_toppersbspi`
--
DROP TABLE IF EXISTS `vi_toppersbspi`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vi_toppersbspi`  AS  select max(`bspi3`.`bspi`) AS `bspi`,`bspi3`.`monthNumber` AS `monthNumber`,`bspi3`.`monthName` AS `monthName`,`bspi3`.`sid` AS `sid`,`bspi3`.`grade_id` AS `grade_id` from `vi_avguserbspiscore` `bspi3` where `bspi3`.`sid` in (select `schools`.`id` from `schools` where (`schools`.`visible` = 1)) group by `bspi3`.`monthNumber`,`bspi3`.`grade_id` ;

-- --------------------------------------------------------

--
-- Structure for view `vi_totgamesplayed`
--
DROP TABLE IF EXISTS `vi_totgamesplayed`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vi_totgamesplayed`  AS  select count(`game_reports`.`gu_id`) AS `countofplayed`,`game_reports`.`gu_id` AS `gu_id`,date_format(`game_reports`.`lastupdate`,'%b') AS `monthName`,date_format(`game_reports`.`lastupdate`,'%m') AS `monthNumber`,(select `users`.`sid` from `users` where (`users`.`id` = `game_reports`.`gu_id`)) AS `gs_ID`,(select `users`.`grade_id` from `users` where (`users`.`id` = `game_reports`.`gu_id`)) AS `grad_ID` from `game_reports` where (convert(date_format(`game_reports`.`lastupdate`,'%Y-%m-%d') using latin1) between (select `academic_year`.`startdate` from `academic_year` where (`academic_year`.`id` = 20)) and (select `academic_year`.`enddate` from `academic_year` where (`academic_year`.`id` = 20))) group by date_format(`game_reports`.`lastupdate`,'%m'),`game_reports`.`gu_id` ;

-- --------------------------------------------------------

--
-- Structure for view `vi_trophies`
--
DROP TABLE IF EXISTS `vi_trophies`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vi_trophies`  AS  select `vi_star`.`userid` AS `userid`,`vi_star`.`UserName` AS `UserName`,`vi_star`.`school_id` AS `school_id`,`vi_star`.`Grade` AS `Grade`,extract(month from `vi_star`.`date`) AS `MONTH`,floor((((((sum(`vi_star`.`MEMORYSTAR`) + sum(`vi_star`.`VPSTAR`)) + sum(`vi_star`.`FASTAR`)) + sum(`vi_star`.`PSSTAR`)) + sum(`vi_star`.`LGSTAR`)) / 60)) AS `DIAMOND`,floor(((((((sum(`vi_star`.`MEMORYSTAR`) + sum(`vi_star`.`VPSTAR`)) + sum(`vi_star`.`FASTAR`)) + sum(`vi_star`.`PSSTAR`)) + sum(`vi_star`.`LGSTAR`)) % 60) / 30)) AS `GOLD`,floor((((((((sum(`vi_star`.`MEMORYSTAR`) + sum(`vi_star`.`VPSTAR`)) + sum(`vi_star`.`FASTAR`)) + sum(`vi_star`.`PSSTAR`)) + sum(`vi_star`.`LGSTAR`)) % 60) % 30) / 15)) AS `SILVER` from `vi_star` group by `vi_star`.`userid`,`vi_star`.`UserName`,`vi_star`.`school_id`,`vi_star`.`Grade`,extract(month from `vi_star`.`date`) ;

-- --------------------------------------------------------

--
-- Structure for view `vi_vp`
--
DROP TABLE IF EXISTS `vi_vp`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vi_vp`  AS  select `cls`.`classname` AS `Grade`,`sec`.`section` AS `user_section`,`usr`.`id` AS `UserID`,`usr`.`sid` AS `school_id`,concat(`usr`.`fname`,' ',`usr`.`lname`) AS `UserName`,`gr`.`lastupdate` AS `Date`,NULL AS `Memory`,`gr`.`game_score` AS `Visual Processing`,NULL AS `FocusAndAttention`,NULL AS `ProblemSolving`,NULL AS `Lingustics` from ((((`game_reports` `gr` join `users` `usr` on((`usr`.`id` = `gr`.`gu_id`))) join `class` `cls` on((`cls`.`id` = `usr`.`grade_id`))) join `skl_class_section` `sec` on((`sec`.`section` = `usr`.`section`))) join `category_skills` `cs` on((`cs`.`id` = `gr`.`gs_id`))) where (`cs`.`name` = 'Visual Processing') ;

-- --------------------------------------------------------

--
-- Structure for view `vi_vpstar`
--
DROP TABLE IF EXISTS `vi_vpstar`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vi_vpstar`  AS  select `cls`.`classname` AS `Grade`,`sec`.`section` AS `user_section`,`usr`.`id` AS `UserID`,`usr`.`sid` AS `school_id`,concat(`usr`.`fname`,' ',`usr`.`lname`) AS `UserName`,`gr`.`lastupdate` AS `Date`,NULL AS `Memory`,ifnull(floor(avg((`gr`.`game_score` / 20))),0) AS `Visual Processing`,NULL AS `FocusAndAttention`,NULL AS `ProblemSolving`,NULL AS `Lingustics` from ((((`game_reports` `gr` join `users` `usr` on((`usr`.`id` = `gr`.`gu_id`))) join `class` `cls` on((`cls`.`id` = `usr`.`grade_id`))) join `skl_class_section` `sec` on((`sec`.`section` = `usr`.`section`))) join `category_skills` `cs` on((`cs`.`id` = `gr`.`gs_id`))) where (`cs`.`name` = 'Visual Processing') ;

-- --------------------------------------------------------

--
-- Structure for view `vv1`
--
DROP TABLE IF EXISTS `vv1`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vv1`  AS  select `a2`.`U_ID` AS `U_ID`,`a2`.`S_ID` AS `S_ID`,`a2`.`G_ID` AS `G_ID`,sum(`a2`.`Points`) AS `points`,date_format(`a2`.`Datetime`,'%b') AS `monthName`,date_format(`a2`.`Datetime`,'%m') AS `monthNumber` from `user_sparkies_history` `a2` where (convert(date_format(`a2`.`Datetime`,'%Y-%m-%d') using latin1) between (select `academic_year`.`startdate` from `academic_year` where (`academic_year`.`id` = 20)) and (select `academic_year`.`enddate` from `academic_year` where (`academic_year`.`id` = 20))) group by date_format(`a2`.`Datetime`,'%m'),`a2`.`U_ID` ;

-- --------------------------------------------------------

--
-- Structure for view `vv2`
--
DROP TABLE IF EXISTS `vv2`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vv2`  AS  select max(`vv1`.`points`) AS `points`,`vv1`.`monthName` AS `monthName`,`vv1`.`monthNumber` AS `monthNumber`,`vv1`.`S_ID` AS `S_ID`,`vv1`.`G_ID` AS `G_ID` from `vv1` where `vv1`.`U_ID` in (select `users`.`id` from `users` where ((`users`.`status` = 1) and (`users`.`visible` = 1))) group by `vv1`.`monthName`,`vv1`.`S_ID`,`vv1`.`G_ID` ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `academic_year`
--
ALTER TABLE `academic_year`
  ADD PRIMARY KEY (`id`),
  ADD KEY `startdate` (`startdate`),
  ADD KEY `enddate` (`enddate`);

--
-- Indexes for table `actual_class`
--
ALTER TABLE `actual_class`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`),
  ADD KEY `email` (`email`),
  ADD KEY `password` (`password`),
  ADD KEY `status` (`status`);

--
-- Indexes for table `admin_login_log`
--
ALTER TABLE `admin_login_log`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `userid` (`adminid`),
  ADD KEY `sessionid` (`sessionid`);

--
-- Indexes for table `android_games`
--
ALTER TABLE `android_games`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `asap_gamescore`
--
ALTER TABLE `asap_gamescore`
  ADD PRIMARY KEY (`id`),
  ADD KEY `gu_id` (`gu_id`),
  ADD KEY `gs_id` (`gs_id`),
  ADD KEY `lastupdate` (`lastupdate`),
  ADD KEY `g_id` (`g_id`);

--
-- Indexes for table `asap_game_reports`
--
ALTER TABLE `asap_game_reports`
  ADD PRIMARY KEY (`id`),
  ADD KEY `gu_id` (`gu_id`),
  ADD KEY `gs_id` (`gs_id`),
  ADD KEY `g_id` (`g_id`),
  ADD KEY `lastupdate` (`lastupdate`),
  ADD KEY `id` (`id`);

--
-- Indexes for table `asap_rand_selection`
--
ALTER TABLE `asap_rand_selection`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `asap_userscore`
--
ALTER TABLE `asap_userscore`
  ADD PRIMARY KEY (`autoid`);

--
-- Indexes for table `bandwidth_config`
--
ALTER TABLE `bandwidth_config`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `ID` (`ID`);

--
-- Indexes for table `bandwidth_log`
--
ALTER TABLE `bandwidth_log`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `school_id` (`school_id`),
  ADD KEY `updatedtime` (`updatedtime`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `braintest_games`
--
ALTER TABLE `braintest_games`
  ADD PRIMARY KEY (`gid`),
  ADD KEY `gs_id` (`gs_id`),
  ADD KEY `game_html` (`game_html`);

--
-- Indexes for table `braintest_mapping`
--
ALTER TABLE `braintest_mapping`
  ADD PRIMARY KEY (`id`),
  ADD KEY `sid` (`sid`),
  ADD KEY `gradeid` (`gradeid`),
  ADD KEY `startdate` (`startdate`),
  ADD KEY `enddate` (`enddate`),
  ADD KEY `level` (`level`);

--
-- Indexes for table `bt_gamedata`
--
ALTER TABLE `bt_gamedata`
  ADD PRIMARY KEY (`id`),
  ADD KEY `gu_id` (`gu_id`),
  ADD KEY `gs_id` (`gs_id`),
  ADD KEY `gp_id` (`gp_id`),
  ADD KEY `g_id` (`g_id`),
  ADD KEY `BT_LEVEL` (`BT_LEVEL`);

--
-- Indexes for table `bt_languages`
--
ALTER TABLE `bt_languages`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `category_skills`
--
ALTER TABLE `category_skills`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `class`
--
ALTER TABLE `class`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `class_plan_game`
--
ALTER TABLE `class_plan_game`
  ADD PRIMARY KEY (`id`),
  ADD KEY `class_id` (`class_id`),
  ADD KEY `plan_id` (`plan_id`),
  ADD KEY `game_id` (`game_id`);

--
-- Indexes for table `class_skill_game`
--
ALTER TABLE `class_skill_game`
  ADD PRIMARY KEY (`id`),
  ADD KEY `class_id` (`class_id`),
  ADD KEY `skill_id` (`skill_id`),
  ADD KEY `game_id` (`game_id`);

--
-- Indexes for table `config_master`
--
ALTER TABLE `config_master`
  ADD PRIMARY KEY (`id`),
  ADD KEY `code` (`code`),
  ADD KEY `type` (`type`),
  ADD KEY `status` (`status`);

--
-- Indexes for table `cycle_master`
--
ALTER TABLE `cycle_master`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `eod_mail_log`
--
ALTER TABLE `eod_mail_log`
  ADD PRIMARY KEY (`id`),
  ADD KEY `sid` (`sid`),
  ADD KEY `status` (`status`);

--
-- Indexes for table `eom_report`
--
ALTER TABLE `eom_report`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `feedback_subject_master`
--
ALTER TABLE `feedback_subject_master`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `gamedata`
--
ALTER TABLE `gamedata`
  ADD PRIMARY KEY (`id`),
  ADD KEY `gu_id` (`gu_id`),
  ADD KEY `gs_id` (`gs_id`),
  ADD KEY `gp_id` (`gp_id`),
  ADD KEY `lastupdate` (`lastupdate`),
  ADD KEY `g_id` (`g_id`);

--
-- Indexes for table `games`
--
ALTER TABLE `games`
  ADD PRIMARY KEY (`gid`),
  ADD KEY `gs_id` (`gs_id`),
  ADD KEY `game_html` (`game_html`);

--
-- Indexes for table `gamescore`
--
ALTER TABLE `gamescore`
  ADD PRIMARY KEY (`id`),
  ADD KEY `gu_id` (`gu_id`),
  ADD KEY `gs_id` (`gs_id`),
  ADD KEY `lastupdate` (`lastupdate`),
  ADD KEY `g_id` (`g_id`);

--
-- Indexes for table `game_language_track`
--
ALTER TABLE `game_language_track`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `game_levels`
--
ALTER TABLE `game_levels`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `game_limit`
--
ALTER TABLE `game_limit`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `g_category`
--
ALTER TABLE `g_category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `g_plans`
--
ALTER TABLE `g_plans`
  ADD PRIMARY KEY (`id`),
  ADD KEY `grade_id` (`grade_id`);

--
-- Indexes for table `g_skills`
--
ALTER TABLE `g_skills`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `isuser_log`
--
ALTER TABLE `isuser_log`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `User_id` (`User_id`),
  ADD KEY `Login_type` (`Login_type`),
  ADD KEY `Confirmation_type` (`Confirmation_type`);

--
-- Indexes for table `language_master`
--
ALTER TABLE `language_master`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `leaderboard`
--
ALTER TABLE `leaderboard`
  ADD PRIMARY KEY (`id`),
  ADD KEY `sid` (`sid`),
  ADD KEY `gradeid` (`gradeid`),
  ADD KEY `monthnumber` (`monthnumber`),
  ADD KEY `type` (`type`);

--
-- Indexes for table `lgames`
--
ALTER TABLE `lgames`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `mathrand_selection`
--
ALTER TABLE `mathrand_selection`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `gid` (`mid`);

--
-- Indexes for table `math_gamemaster`
--
ALTER TABLE `math_gamemaster`
  ADD PRIMARY KEY (`mid`);

--
-- Indexes for table `math_reports`
--
ALTER TABLE `math_reports`
  ADD PRIMARY KEY (`id`),
  ADD KEY `gu_id` (`gu_id`),
  ADD KEY `gs_id` (`gs_id`),
  ADD KEY `gp_id` (`gp_id`),
  ADD KEY `lastupdate` (`lastupdate`);

--
-- Indexes for table `newsfeedmaster`
--
ALTER TABLE `newsfeedmaster`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `newsfeed_config`
--
ALTER TABLE `newsfeed_config`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `newsfeed_data_status`
--
ALTER TABLE `newsfeed_data_status`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `S_ID` (`S_ID`),
  ADD KEY `G_ID` (`G_ID`),
  ADD KEY `U_ID` (`U_ID`);

--
-- Indexes for table `nonschedule`
--
ALTER TABLE `nonschedule`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `order_details`
--
ALTER TABLE `order_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `overalltoppers`
--
ALTER TABLE `overalltoppers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `parent_login_log`
--
ALTER TABLE `parent_login_log`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `password_history`
--
ALTER TABLE `password_history`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `q1_bspitopper`
--
ALTER TABLE `q1_bspitopper`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `q1_crowniestopper`
--
ALTER TABLE `q1_crowniestopper`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `q1_skilltopper`
--
ALTER TABLE `q1_skilltopper`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `q2_skilltoppersname`
--
ALTER TABLE `q2_skilltoppersname`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `rand_selection`
--
ALTER TABLE `rand_selection`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `school_id` (`school_id`),
  ADD KEY `gid` (`gid`),
  ADD KEY `grade_id` (`grade_id`),
  ADD KEY `gp_id` (`gp_id`);

--
-- Indexes for table `range_values`
--
ALTER TABLE `range_values`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `startRange` (`startRange`),
  ADD KEY `endRange` (`endRange`);

--
-- Indexes for table `schools`
--
ALTER TABLE `schools`
  ADD PRIMARY KEY (`id`),
  ADD KEY `active` (`active`),
  ADD KEY `email` (`email`),
  ADD KEY `flag` (`flag`),
  ADD KEY `status` (`status`),
  ADD KEY `active_2` (`active`),
  ADD KEY `academic_id` (`academic_id`);

--
-- Indexes for table `schools_language`
--
ALTER TABLE `schools_language`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `schools_leave_list`
--
ALTER TABLE `schools_leave_list`
  ADD PRIMARY KEY (`id`),
  ADD KEY `school_id` (`school_id`),
  ADD KEY `leave_date` (`leave_date`);

--
-- Indexes for table `schools_period_schedule`
--
ALTER TABLE `schools_period_schedule`
  ADD PRIMARY KEY (`schedule_id`),
  ADD KEY `schedule_id` (`schedule_id`),
  ADD KEY `school_id` (`school_id`),
  ADD KEY `status` (`status`);

--
-- Indexes for table `schools_period_schedule_days`
--
ALTER TABLE `schools_period_schedule_days`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `sid` (`sid`),
  ADD KEY `grade_id` (`grade_id`),
  ADD KEY `period_date` (`period_date`),
  ADD KEY `section` (`section`);

--
-- Indexes for table `schools_period_schedule_daysbeta`
--
ALTER TABLE `schools_period_schedule_daysbeta`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `period_date` (`period_date`),
  ADD KEY `grade_id` (`grade_id`),
  ADD KEY `section` (`section`),
  ADD KEY `sid` (`sid`);

--
-- Indexes for table `schools_period_schedule_daysbeta_session`
--
ALTER TABLE `schools_period_schedule_daysbeta_session`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `period_date` (`period_date`),
  ADD KEY `grade_id` (`grade_id`),
  ADD KEY `section` (`section`),
  ADD KEY `sid` (`sid`);

--
-- Indexes for table `school_academic_mapping`
--
ALTER TABLE `school_academic_mapping`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `SID` (`SID`),
  ADD KEY `AID` (`AID`);

--
-- Indexes for table `school_admin`
--
ALTER TABLE `school_admin`
  ADD PRIMARY KEY (`id`),
  ADD KEY `school_id` (`school_id`),
  ADD KEY `status` (`status`),
  ADD KEY `active` (`active`);

--
-- Indexes for table `section`
--
ALTER TABLE `section`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `skillkit_configuration`
--
ALTER TABLE `skillkit_configuration`
  ADD PRIMARY KEY (`Recid`);

--
-- Indexes for table `skillkit_game_reports`
--
ALTER TABLE `skillkit_game_reports`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `skillkit_master`
--
ALTER TABLE `skillkit_master`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `skillkit_random_game`
--
ALTER TABLE `skillkit_random_game`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `skl_class`
--
ALTER TABLE `skl_class`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `skl_class_plan`
--
ALTER TABLE `skl_class_plan`
  ADD PRIMARY KEY (`id`),
  ADD KEY `school_id` (`school_id`),
  ADD KEY `class_id` (`class_id`),
  ADD KEY `plan_id` (`plan_id`);

--
-- Indexes for table `skl_class_section`
--
ALTER TABLE `skl_class_section`
  ADD PRIMARY KEY (`id`),
  ADD KEY `school_id` (`school_id`),
  ADD KEY `class_id` (`class_id`),
  ADD KEY `section` (`section`);

--
-- Indexes for table `skl_dcnt_coupon`
--
ALTER TABLE `skl_dcnt_coupon`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `skl_grade`
--
ALTER TABLE `skl_grade`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `skl_grade_game_map`
--
ALTER TABLE `skl_grade_game_map`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `skl_prepaid_coupon`
--
ALTER TABLE `skl_prepaid_coupon`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sk_gamedata`
--
ALTER TABLE `sk_gamedata`
  ADD PRIMARY KEY (`id`),
  ADD KEY `gu_id` (`gu_id`),
  ADD KEY `gs_id` (`gs_id`),
  ADD KEY `gp_id` (`gp_id`),
  ADD KEY `g_id` (`g_id`),
  ADD KEY `lastupdate` (`lastupdate`);

--
-- Indexes for table `sk_games`
--
ALTER TABLE `sk_games`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `skill_ID` (`skill_ID`);

--
-- Indexes for table `sk_gamescore`
--
ALTER TABLE `sk_gamescore`
  ADD PRIMARY KEY (`id`),
  ADD KEY `gu_id` (`gu_id`),
  ADD KEY `gs_id` (`gs_id`),
  ADD KEY `lastupdate` (`lastupdate`),
  ADD KEY `g_id` (`g_id`);

--
-- Indexes for table `sk_games_plan`
--
ALTER TABLE `sk_games_plan`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `school_ID` (`school_ID`),
  ADD KEY `plan_ID` (`plan_ID`),
  ADD KEY `sk_game_ID` (`sk_game_ID`);

--
-- Indexes for table `sk_personalized_game`
--
ALTER TABLE `sk_personalized_game`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `sk_planSkillCountID` (`sk_planSkillCountID`),
  ADD KEY `skillID` (`skillID`),
  ADD KEY `from_GradeID` (`from_GradeID`),
  ADD KEY `level` (`level`);

--
-- Indexes for table `sk_plan_skillcount`
--
ALTER TABLE `sk_plan_skillcount`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `sk_rand_selection`
--
ALTER TABLE `sk_rand_selection`
  ADD PRIMARY KEY (`id`),
  ADD KEY `gs_id` (`gs_id`),
  ADD KEY `gid` (`gid`),
  ADD KEY `gp_id` (`gp_id`),
  ADD KEY `userID` (`userID`);

--
-- Indexes for table `sk_user_game_list`
--
ALTER TABLE `sk_user_game_list`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `userID` (`userID`),
  ADD KEY `planID` (`planID`),
  ADD KEY `SessionID` (`SessionID`);

--
-- Indexes for table `sparkiesmaster`
--
ALTER TABLE `sparkiesmaster`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `Code` (`Code`),
  ADD KEY `Type` (`Type`),
  ADD KEY `Status` (`Status`);

--
-- Indexes for table `stafffeedback`
--
ALTER TABLE `stafffeedback`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `stafffeedback_list`
--
ALTER TABLE `stafffeedback_list`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_feedback`
--
ALTER TABLE `tbl_feedback`
  ADD PRIMARY KEY (`feedbackid`);

--
-- Indexes for table `teachers`
--
ALTER TABLE `teachers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `teachersday_feedback`
--
ALTER TABLE `teachersday_feedback`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `teacher_class`
--
ALTER TABLE `teacher_class`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `thememaster`
--
ALTER TABLE `thememaster`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `userbadge_data`
--
ALTER TABLE `userbadge_data`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `usermaster`
--
ALTER TABLE `usermaster`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `userplaytime`
--
ALTER TABLE `userplaytime`
  ADD PRIMARY KEY (`id`),
  ADD KEY `userid` (`userid`),
  ADD KEY `expiredon` (`expiredon`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD KEY `status` (`status`),
  ADD KEY `grade_id` (`grade_id`),
  ADD KEY `username` (`username`),
  ADD KEY `sid` (`sid`),
  ADD KEY `section` (`section`),
  ADD KEY `academicyear` (`academicyear`),
  ADD KEY `gp_id` (`gp_id`);

--
-- Indexes for table `userscreenaccess`
--
ALTER TABLE `userscreenaccess`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users_feedback`
--
ALTER TABLE `users_feedback`
  ADD PRIMARY KEY (`id`),
  ADD KEY `userid` (`userid`),
  ADD KEY `skillid` (`skillid`);

--
-- Indexes for table `users_q1`
--
ALTER TABLE `users_q1`
  ADD PRIMARY KEY (`id`),
  ADD KEY `grade_id` (`grade_id`),
  ADD KEY `username` (`username`),
  ADD KEY `sid` (`sid`),
  ADD KEY `section` (`section`);

--
-- Indexes for table `user_academic_mapping`
--
ALTER TABLE `user_academic_mapping`
  ADD PRIMARY KEY (`masterid`),
  ADD KEY `id` (`id`),
  ADD KEY `grade_id` (`grade_id`),
  ADD KEY `gp_id` (`gp_id`),
  ADD KEY `sid` (`sid`),
  ADD KEY `academicid` (`academicid`),
  ADD KEY `section` (`section`),
  ADD KEY `status` (`status`);

--
-- Indexes for table `user_access_log`
--
ALTER TABLE `user_access_log`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_class_limit`
--
ALTER TABLE `user_class_limit`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_games`
--
ALTER TABLE `user_games`
  ADD PRIMARY KEY (`id`),
  ADD KEY `gu_id` (`gu_id`),
  ADD KEY `last_update` (`last_update`),
  ADD KEY `creation_date` (`creation_date`);

--
-- Indexes for table `user_games_history`
--
ALTER TABLE `user_games_history`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_games_plans`
--
ALTER TABLE `user_games_plans`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_limit`
--
ALTER TABLE `user_limit`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_login_log`
--
ALTER TABLE `user_login_log`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `userid` (`userid`),
  ADD KEY `sessionid` (`sessionid`);

--
-- Indexes for table `user_newsfeed_history`
--
ALTER TABLE `user_newsfeed_history`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `S_ID` (`S_ID`),
  ADD KEY `G_ID` (`G_ID`),
  ADD KEY `U_ID` (`U_ID`);

--
-- Indexes for table `user_section_limit`
--
ALTER TABLE `user_section_limit`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_sparkies_history`
--
ALTER TABLE `user_sparkies_history`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `S_ID` (`S_ID`),
  ADD KEY `U_ID` (`U_ID`),
  ADD KEY `Scenario_ID` (`Scenario_ID`),
  ADD KEY `G_ID` (`G_ID`);

--
-- Indexes for table `utilizationreport`
--
ALTER TABLE `utilizationreport`
  ADD PRIMARY KEY (`id`),
  ADD KEY `weekval` (`weekval`),
  ADD KEY `gradeid` (`gradeid`),
  ADD KEY `section` (`section`),
  ADD KEY `sid` (`sid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `academic_year`
--
ALTER TABLE `academic_year`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `actual_class`
--
ALTER TABLE `actual_class`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `admin_login_log`
--
ALTER TABLE `admin_login_log`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `android_games`
--
ALTER TABLE `android_games`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `asap_gamescore`
--
ALTER TABLE `asap_gamescore`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `asap_game_reports`
--
ALTER TABLE `asap_game_reports`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `asap_rand_selection`
--
ALTER TABLE `asap_rand_selection`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=62;

--
-- AUTO_INCREMENT for table `asap_userscore`
--
ALTER TABLE `asap_userscore`
  MODIFY `autoid` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `bandwidth_config`
--
ALTER TABLE `bandwidth_config`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `bandwidth_log`
--
ALTER TABLE `bandwidth_log`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `braintest_games`
--
ALTER TABLE `braintest_games`
  MODIFY `gid` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `braintest_mapping`
--
ALTER TABLE `braintest_mapping`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `bt_gamedata`
--
ALTER TABLE `bt_gamedata`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1880;

--
-- AUTO_INCREMENT for table `bt_languages`
--
ALTER TABLE `bt_languages`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=105;

--
-- AUTO_INCREMENT for table `category_skills`
--
ALTER TABLE `category_skills`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=71;

--
-- AUTO_INCREMENT for table `class`
--
ALTER TABLE `class`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `class_plan_game`
--
ALTER TABLE `class_plan_game`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1327;

--
-- AUTO_INCREMENT for table `class_skill_game`
--
ALTER TABLE `class_skill_game`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1321;

--
-- AUTO_INCREMENT for table `config_master`
--
ALTER TABLE `config_master`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `cycle_master`
--
ALTER TABLE `cycle_master`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `eod_mail_log`
--
ALTER TABLE `eod_mail_log`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `eom_report`
--
ALTER TABLE `eom_report`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `feedback_subject_master`
--
ALTER TABLE `feedback_subject_master`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `gamedata`
--
ALTER TABLE `gamedata`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `games`
--
ALTER TABLE `games`
  MODIFY `gid` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1345;

--
-- AUTO_INCREMENT for table `gamescore`
--
ALTER TABLE `gamescore`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `game_language_track`
--
ALTER TABLE `game_language_track`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `game_levels`
--
ALTER TABLE `game_levels`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `game_limit`
--
ALTER TABLE `game_limit`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `g_category`
--
ALTER TABLE `g_category`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `g_plans`
--
ALTER TABLE `g_plans`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=96;

--
-- AUTO_INCREMENT for table `g_skills`
--
ALTER TABLE `g_skills`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `isuser_log`
--
ALTER TABLE `isuser_log`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `language_master`
--
ALTER TABLE `language_master`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `leaderboard`
--
ALTER TABLE `leaderboard`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `lgames`
--
ALTER TABLE `lgames`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `mathrand_selection`
--
ALTER TABLE `mathrand_selection`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=205;

--
-- AUTO_INCREMENT for table `math_gamemaster`
--
ALTER TABLE `math_gamemaster`
  MODIFY `mid` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=101;

--
-- AUTO_INCREMENT for table `math_reports`
--
ALTER TABLE `math_reports`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `newsfeedmaster`
--
ALTER TABLE `newsfeedmaster`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `newsfeed_config`
--
ALTER TABLE `newsfeed_config`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `newsfeed_data_status`
--
ALTER TABLE `newsfeed_data_status`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `nonschedule`
--
ALTER TABLE `nonschedule`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `order_details`
--
ALTER TABLE `order_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `overalltoppers`
--
ALTER TABLE `overalltoppers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT for table `parent_login_log`
--
ALTER TABLE `parent_login_log`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `password_history`
--
ALTER TABLE `password_history`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `q1_bspitopper`
--
ALTER TABLE `q1_bspitopper`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `q1_crowniestopper`
--
ALTER TABLE `q1_crowniestopper`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `q1_skilltopper`
--
ALTER TABLE `q1_skilltopper`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `q2_skilltoppersname`
--
ALTER TABLE `q2_skilltoppersname`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `rand_selection`
--
ALTER TABLE `rand_selection`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `range_values`
--
ALTER TABLE `range_values`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `schools`
--
ALTER TABLE `schools`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=173;

--
-- AUTO_INCREMENT for table `schools_language`
--
ALTER TABLE `schools_language`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `schools_leave_list`
--
ALTER TABLE `schools_leave_list`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `schools_period_schedule`
--
ALTER TABLE `schools_period_schedule`
  MODIFY `schedule_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT for table `schools_period_schedule_days`
--
ALTER TABLE `schools_period_schedule_days`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `schools_period_schedule_daysbeta`
--
ALTER TABLE `schools_period_schedule_daysbeta`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `schools_period_schedule_daysbeta_session`
--
ALTER TABLE `schools_period_schedule_daysbeta_session`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `school_academic_mapping`
--
ALTER TABLE `school_academic_mapping`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `school_admin`
--
ALTER TABLE `school_admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=42;

--
-- AUTO_INCREMENT for table `section`
--
ALTER TABLE `section`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `skillkit_configuration`
--
ALTER TABLE `skillkit_configuration`
  MODIFY `Recid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `skillkit_game_reports`
--
ALTER TABLE `skillkit_game_reports`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `skillkit_master`
--
ALTER TABLE `skillkit_master`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=56;

--
-- AUTO_INCREMENT for table `skillkit_random_game`
--
ALTER TABLE `skillkit_random_game`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `skl_class`
--
ALTER TABLE `skl_class`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `skl_class_plan`
--
ALTER TABLE `skl_class_plan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=168;

--
-- AUTO_INCREMENT for table `skl_class_section`
--
ALTER TABLE `skl_class_section`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=389;

--
-- AUTO_INCREMENT for table `skl_dcnt_coupon`
--
ALTER TABLE `skl_dcnt_coupon`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `skl_grade`
--
ALTER TABLE `skl_grade`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `skl_grade_game_map`
--
ALTER TABLE `skl_grade_game_map`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=516;

--
-- AUTO_INCREMENT for table `skl_prepaid_coupon`
--
ALTER TABLE `skl_prepaid_coupon`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `sk_gamedata`
--
ALTER TABLE `sk_gamedata`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `sk_games`
--
ALTER TABLE `sk_games`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1321;

--
-- AUTO_INCREMENT for table `sk_gamescore`
--
ALTER TABLE `sk_gamescore`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=214;

--
-- AUTO_INCREMENT for table `sk_games_plan`
--
ALTER TABLE `sk_games_plan`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=554;

--
-- AUTO_INCREMENT for table `sk_personalized_game`
--
ALTER TABLE `sk_personalized_game`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=152;

--
-- AUTO_INCREMENT for table `sk_plan_skillcount`
--
ALTER TABLE `sk_plan_skillcount`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `sk_rand_selection`
--
ALTER TABLE `sk_rand_selection`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `sk_user_game_list`
--
ALTER TABLE `sk_user_game_list`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `sparkiesmaster`
--
ALTER TABLE `sparkiesmaster`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `stafffeedback`
--
ALTER TABLE `stafffeedback`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `stafffeedback_list`
--
ALTER TABLE `stafffeedback_list`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `tbl_feedback`
--
ALTER TABLE `tbl_feedback`
  MODIFY `feedbackid` int(10) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `teachers`
--
ALTER TABLE `teachers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `teachersday_feedback`
--
ALTER TABLE `teachersday_feedback`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `teacher_class`
--
ALTER TABLE `teacher_class`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=43;

--
-- AUTO_INCREMENT for table `thememaster`
--
ALTER TABLE `thememaster`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `userbadge_data`
--
ALTER TABLE `userbadge_data`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `usermaster`
--
ALTER TABLE `usermaster`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `userplaytime`
--
ALTER TABLE `userplaytime`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=60545;

--
-- AUTO_INCREMENT for table `userscreenaccess`
--
ALTER TABLE `userscreenaccess`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users_feedback`
--
ALTER TABLE `users_feedback`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users_q1`
--
ALTER TABLE `users_q1`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `user_academic_mapping`
--
ALTER TABLE `user_academic_mapping`
  MODIFY `masterid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=63554;

--
-- AUTO_INCREMENT for table `user_access_log`
--
ALTER TABLE `user_access_log`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `user_class_limit`
--
ALTER TABLE `user_class_limit`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `user_games`
--
ALTER TABLE `user_games`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `user_games_history`
--
ALTER TABLE `user_games_history`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `user_games_plans`
--
ALTER TABLE `user_games_plans`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `user_limit`
--
ALTER TABLE `user_limit`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `user_login_log`
--
ALTER TABLE `user_login_log`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `user_newsfeed_history`
--
ALTER TABLE `user_newsfeed_history`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `user_section_limit`
--
ALTER TABLE `user_section_limit`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `user_sparkies_history`
--
ALTER TABLE `user_sparkies_history`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `utilizationreport`
--
ALTER TABLE `utilizationreport`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
