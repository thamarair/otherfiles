<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard_model extends CI_Model {

        
        public function __construct()
        {
                // Call the CI_Model constructor
                parent::__construct();
				 $this->load->database();
				 $this->load->library('Multipledb');
        }

		public function checklogin($username,$password)
        {
					 
			$query = $this->db->query("SELECT *  FROM admin WHERE (email='".$username."' AND password='".$password."')");		
			//echo $this->db->last_query(); exit;
			return $query->result_array();
        }	

		public function hospitallist()
        {
					 
			$query = $this->db->query("SELECT *,(select state_name from state where id=h.state) as statename  FROM hospitalmaster h");		
			//echo $this->db->last_query(); exit;
			return $query->result_array();
        }
		
		public function totalrec_doctorlist($start='',$limit='',$zoneid='',$bmid='',$frmdate='',$todate='',$docname='')
        { 
			$where = ' '; 		 
			$qry=' ';	
			
		 if($frmdate!='' && $todate!='')
		{
			 $where.= " and date(created_on) BETWEEN DATE_FORMAT('".date("Y-m-d", strtotime($frmdate))."','%Y-%m-%d') and DATE_FORMAT('".date("Y-m-d", strtotime($todate))."','%Y-%m-%d') "; 
		}
		else if($frmdate!='') {
			
			$where.= " and date(created_on) = DATE_FORMAT('".date("Y-m-d", strtotime($frmdate))."','%Y-%m-%d') "; 
		}
		
		else if($todate!='') {
			
			$where.= " and date(created_on) = DATE_FORMAT('".date("Y-m-d", strtotime($todate))."','%Y-%m-%d') "; 
		}
			
	  if($bmid!='')
		{
			 $where.= " and regionid ='".$bmid."' "; 
		}
		
	 if($zoneid!='')
		{
			 $where.= " and regionid IN (select id from regionmaster where zoneid='".$zoneid."') "; 
		}
		
		if($docname!='')
		{
			 $where.= " and CONCAT(doctorname,'',lastname) LIKE '%".$docname."%' "; 
		}
		
			$query = $this->db->query("SELECT count(*) as totalrecord FROM doctormaster d where d.isdemo=0 ".$where."");	
			return $query->result_array();
		}

		public function doctorlist($start='',$limit='',$zoneid='',$bmid='',$frmdate='',$todate='',$docname='')
        {
			$where = ' '; 		 
			$qry=' ';
			//echo $todate; exit;
		 if($frmdate!='' && $todate!='')
		{
			 $where.= " and date(created_on) BETWEEN DATE_FORMAT('".date("Y-m-d", strtotime($frmdate))."','%Y-%m-%d') and DATE_FORMAT('".date("Y-m-d", strtotime($todate))."','%Y-%m-%d') "; 
		}
		else if($frmdate!='') {
			$where.= " and date(created_on) = DATE_FORMAT('".date("Y-m-d", strtotime($frmdate))."','%Y-%m-%d') "; 
			
		}
		
		else if($todate!='') {
			$where.= " and date(created_on) = DATE_FORMAT('".date("Y-m-d", strtotime($todate))."','%Y-%m-%d') "; 
		}
			
	  if($bmid!='')
		{
			 $where.= " and regionid ='".$bmid."' "; 
		}
		
	 if($zoneid!='')
		{
			 $where.= " and regionid IN (select id from regionmaster where zoneid='".$zoneid."') "; 
		}
		
		if($docname!='')
		{
			 $where.= " and CONCAT(doctorname,'',lastname) LIKE '%".$docname."%' "; 
		}
		else if($limit=='')
			{
				$qry=" ";
			}
			else if($start=='' && $limit!=''){
				$qry=" limit ".$limit;
			}
			else if($start!='' && $limit!=''){
				$qry=" limit ".$start.','.$limit;
			}
		//	echo $zoneid; exit;
			$query = $this->db->query("SELECT doctorname,lastname,status,gender,dateofbirth,mobilenumber,secondarymobilenumber,email,secondaryemail,address,city,created_on,(select state_name from state where id=d.state) as statename,hospitalname,profileimage,(select regionname from regionmaster where id=d.regionid and isdemo=0) as headquarter,(select personname from regionmaster where id=d.regionid and isdemo=0) as bmname,(select count(qrcode) from couponmaster where doctorid=d.id and status=1) as scannedcount,(select count(qrcode) from couponmaster where doctorid=d.id and usedstatus='Y' and regionid=d.regionid) as childusedcount,pan,accholdername,accno,ifsccode,branchname,bankname   FROM doctormaster d where d.isdemo=0 ".$where." order by created_on desc ".$qry."");		
		//	echo $this->db->last_query(); 
			return $query->result_array();
        }		
		
		public function userslist()
        {
					 
			$query = $this->db->query("SELECT id,fname,username,email,mobile,address,dob,avatarimage,(select state_name from state where id=u.stateid) as statename,city,parentname,creation_date,status  FROM users u where status=1 and isdemo=0");		
			//echo $this->db->last_query(); exit;
			return $query->result_array();
        }
		
		public function hospitalcount()
        {
			$query = $this->db->query("SELECT count(*) as total FROM hospitalmaster  WHERE status=1");		
			//echo $this->db->last_query(); exit;
			return $query->result_array();
        }
		
		public function doctorcount()
        {
			$query = $this->db->query("SELECT count(*) as total FROM doctormaster  WHERE status=1 and isdemo=0");		
			//echo $this->db->last_query(); exit;
			return $query->result_array();
        } 
		
		public function usercount()
        {
			$query = $this->db->query("SELECT count(*) as total FROM users  WHERE status=1 and isdemo=0");		
			//echo $this->db->last_query(); exit;
			return $query->result_array();
        } 
		
		public function totalcouponissued()
        {
			//$query = $this->db->query("SELECT SUM(couponcount) as totalcount FROM region_coupon_count  WHERE status=1 and regionid NOT IN (select id from regionmaster where zoneid=5 and isdemo=1)");	
			$query = $this->db->query("SELECT SUM(couponcount) as totalcount FROM region_coupon_count  WHERE status=1 and regionid  IN (select id from regionmaster where zoneid!=5 and isdemo=0)");		
			//echo $this->db->last_query(); exit;
			return $query->result_array();
        } 
		
		public function scannedbyregion()
        {
			$query = $this->db->query("SELECT COUNT(qrcode) as totalcount FROM couponmaster  WHERE region_usedstatus='Y' and regionid IN (select id from regionmaster where zoneid!=5 and isdemo=0)");		
			//echo $this->db->last_query(); exit;
			return $query->result_array();
        }

		public function scannedbydoctor()
        {
			$query = $this->db->query("SELECT COUNT(qrcode) as totalcount FROM couponmaster  WHERE status=1 and regionid IN (select id from regionmaster where zoneid!=5 and isdemo=0)");		
			//echo $this->db->last_query(); exit;
			return $query->result_array();
        }		
		
		

		public function getstate()
        {
			$query = $this->db->query("SELECT id, state_name FROM state  WHERE countryid=113");		
			//echo $this->db->last_query(); exit;
			return $query->result_array();
        }	

		public function gethospital()
        {
			$query = $this->db->query("SELECT id, hospitalname FROM hospitalmaster  WHERE status=1");		
			//echo $this->db->last_query(); exit;
			return $query->result_array();
        }			
		
		public function addhospital($hospitalname,$code,$phone1,$phone2,$emailid1,$emailid2,$state,$city,$hospaddress,$contactperson,$status)
        {
			$query = $this->db->query("INSERT INTO `hospitalmaster`( `hospitalname`, `code`, `phonenumber_1`, `phonenumber_2`, `emailid_1`, `emailid_2`, `address`, `city`, `state`, `contact_person`, `status`, `createddate`) VALUES ('".$hospitalname."','".$code."','".$phone1."','".$phone2."','".$emailid1."','".$emailid2."','".$hospaddress."','".$city."','".$state."','".$contactperson."','".$status."',NOW())");		
			
			//return $query->result_array();
        }	
		
		public function adddoctor($doctorname,$lname,$gender,$dob,$emailid,$secondaryemailid,$mobile,$secondarymobile,$state,$city,$hospitalname,$address,$status)
        {
			$query = $this->db->query("INSERT INTO `doctormaster`( `doctorname`, `lastname`, `gender`, `dateofbirth`, `email`, `secondaryemail`, `state`, `city`, `mobilenumber`, `secondarymobilenumber`, `address`, `hospitalid`, `status`, `created_on`) VALUES ('".$doctorname."','".$lname."','".$gender."','".$dob."','".$emailid."','".$secondaryemailid."','".$state."','".$city."','".$mobile."','".$secondarymobile."','".$address."','".$hospitalname."','".$status."',NOW())");		
			
			//return $query->result_array();
        }	
		
		public function edithospital($editid)
        {
			$query = $this->db->query("SELECT *,(select state_name from state where id=h.state) as statename  FROM hospitalmaster h WHERE id='".$editid."'");		
			//echo $this->db->last_query(); exit;
			return $query->result_array();
        }

		public function editdoctor($editid)
        {
			$query = $this->db->query("SELECT *,(select state_name from state where id=d.state) as statename,(select hospitalname from hospitalmaster where id=d.hospitalid) as hospitalname FROM doctormaster d WHERE d.id='".$editid."'");		
			//echo $this->db->last_query(); exit;
			return $query->result_array();
        }		
		
		public function updatehospital($hospitalname,$phone1,$phone2,$emailid1,$emailid2,$state,$city,$hospaddress,$contactperson,$status,$editid)
        {
			$query = $this->db->query("UPDATE `hospitalmaster` SET `hospitalname`='".$hospitalname."',`phonenumber_1`='".$phone1."',`phonenumber_2`='".$phone2."',`emailid_1`='".$emailid1."',`emailid_2`='".$emailid2."',`address`='".$hospaddress."',`city`='".$city."',`state`='".$state."',`contact_person`='".$contactperson."',`status`='".$status."',`modifieddate`=NOW() WHERE id='".$editid."'");		
			//echo $this->db->last_query(); exit;
			
        }

		public function updatedoctor($doctorname,$lname,$gender,$dob,$emailid,$secondaryemailid,$mobile,$secondarymobile,$state,$city,$hospitalname,$address,$status,$editid)
        {
			$query = $this->db->query("UPDATE `doctormaster` SET `doctorname`='".$doctorname."',`lastname`='".$lname."',`gender`='".$gender."',`dateofbirth`='".$dob."',`email`='".$emailid."',`secondaryemail`='".$secondaryemailid."',`state`='".$state."',`city`='".$city."',`mobilenumber`='".$mobile."',`secondarymobilenumber`='".$secondarymobile."',`address`='".$address."',`hospitalid`='".$hospitalname."',`status`='".$status."',`modifed_on`=NOW() WHERE id='".$editid."'");		
			//echo $this->db->last_query(); exit;
        }		
		
		public function totalrec_patientlist($start='',$limit='',$zoneid='',$bmid='',$frmdate='',$todate='',$patientname='')
        {
			
			$where = ' '; 		 
			
		 if($frmdate!='' && $todate!='')
		{
			 $where.= " and date(creation_date) BETWEEN DATE_FORMAT('".date("Y-m-d", strtotime($frmdate))."','%Y-%m-%d') and DATE_FORMAT('".date("Y-m-d", strtotime($todate))."','%Y-%m-%d') "; 
		}
		else if($frmdate!='') {
			
			$where.= " and date(creation_date) = DATE_FORMAT('".date("Y-m-d", strtotime($frmdate))."','%Y-%m-%d') "; 
		}
		
		else if($todate!='') {
			
			$where.= " and date(creation_date) = DATE_FORMAT('".date("Y-m-d", strtotime($todate))."','%Y-%m-%d') "; 
		}
			
	  if($bmid!='')
		{
			 $where.= " and u.doctorid IN (select id from doctormaster where regionid = '".$bmid."' ) "; 
		}
		
		if($zoneid!='')
		{
			 $where.= " and u.doctorid IN (select id from doctormaster where regionid IN (select id from regionmaster where zoneid = '".$zoneid."') ) "; 
		}
		
	/*	if($docname!='')
		{
			 $where.= " and doctorname LIKE '%".$docname."%' "; 
		}
		
		if($parentname!='')
		{
			 $where.= " and parentname LIKE '%".$parentname."%' "; 
		}
		*/
		if($patientname!='')
		{
			 $where.= " and CONCAT(u.fname,'',u.lname) LIKE '%".$patientname."%' "; 
		}
			
			
			$query = $this->db->query("SELECT count(*) as totalrecord, u.fname FROM users u where u.isdemo=0 ".$where." ");
			//echo $this->db->last_query(); exit;
			return $query->result_array();
		}
		
		/*------------------grade and pgm name------------------------*/
		
		public function patientlist($start='',$limit='',$zoneid='',$bmid='',$frmdate='',$todate='',$patientname='')
        {
					 $qry=' ';
					 $where = ' '; 		 
			
		 if($frmdate!='' && $todate!='')
		{
			 $where.= " and date(creation_date) BETWEEN DATE_FORMAT('".date("Y-m-d", strtotime($frmdate))."','%Y-%m-%d') and DATE_FORMAT('".date("Y-m-d", strtotime($todate))."','%Y-%m-%d') "; 
		}
		else if($frmdate!='') {
			
			$where.= " and date(creation_date) = DATE_FORMAT('".date("Y-m-d", strtotime($frmdate))."','%Y-%m-%d') "; 
		}
		
		else if($todate!='') {
			
			$where.= " and date(creation_date) = DATE_FORMAT('".date("Y-m-d", strtotime($todate))."','%Y-%m-%d') "; 
		}
			
	   if($bmid!='')
		{
			 $where.= " and u.doctorid IN (select id from doctormaster where regionid = '".$bmid."' ) "; 
		}
		
		if($zoneid!='')
		{
			 $where.= " and u.doctorid IN (select id from doctormaster where regionid IN (select id from regionmaster where zoneid = '".$zoneid."') ) "; 
		}
		
		/*if($docname!='')
		{
			 $where.= " and doctorname LIKE '%".$docname."%' "; 
		}
		
		if($parentname!='')
		{
			 $where.= " and parentname LIKE '%".$parentname."%' "; 
		}
		*/
		if($patientname!='')
		{
			 $where.= " and CONCAT(u.fname,'',u.lname)  LIKE '%".$patientname."%' "; 
		}
		
		
			
		else if($limit=='')
			{
				$qry=" ";
			}
			else if($start=='' && $limit!=''){
				$qry=" limit ".$limit;
			}
			else if($start!='' && $limit!=''){
				$qry=" limit ".$start.','.$limit;
			}
			
			$query = $this->db->query("SELECT id,fname,lname,username,(select program_name from program_master where id=u.programid) as programname,(select gradename from program_grade_master where gradeid=u.grade_id and programid=u.programid) as gradename,email,mobile,address,dob,avatarimage,(select state_name from state where id=u.stateid) as statename,(select type from patient_type_master where id=u.patient_type) as patienttype,(select CONCAT(doctorname,' ',lastname) from doctormaster where id=u.doctorid) as doctorname,city,parentname,creation_date,status FROM users u  where u.isdemo=0 ".$where." order by creation_date desc ".$qry."");		
		//	echo $this->db->last_query(); //exit;
			return $query->result_array();
        }
		
		 /*------------------grade and pgm name------------------------*/
		
		 
		
		public function asap_reports($doctorid) 
		{
			
			$query = $this->multipledb->db->query('select id, fname,lname,username,mobile,parentname,  s1.skillscore_M as skillscorem, skillscore_V as skillscorev,skillscore_F as skillscoref,skillscore_P as skillscorep,skillscore_L as skillscorel, a3.finalscore as avgbspiset1,COALESCE(a3.playedcount,0) as playcount from users mu

left join 
 (SELECT SUM(score)/5 as finalscore, count(gu_id) as playedcount, gu_id, (SELECT sid from users where id=gu_id) as schoolid from (select (AVG(score)) as score, gu_id, gs_id from (SELECT (AVG(`game_score`)) as score , gs_id , gu_id, lastupdate FROM `game_reports` WHERE gs_id in (59,60,61,62,63) and gu_id in (select id from users) group by gs_id , gu_id, lastupdate) a1 group by gs_id, gu_id ) a2 group by gu_id) a3   on a3.gu_id=mu.id 
 
 left join
(select (AVG(score)) as skillscore_M, gu_id from (SELECT (AVG(`game_score`)) as score , gs_id , gu_id, lastupdate FROM `game_reports` WHERE gs_id =59 and gu_id in (select id from users) group by gs_id , gu_id, lastupdate) a1 group by gs_id, gu_id) s1 on s1.gu_id=mu.id 

left join
(select (AVG(score)) as skillscore_V, gu_id from (SELECT (AVG(`game_score`)) as score , gs_id , gu_id, lastupdate FROM `game_reports` WHERE gs_id =60 and gu_id in (select id from users) group by gs_id , gu_id, lastupdate) a1 group by gs_id, gu_id) s2 on s2.gu_id=mu.id 

left join
(select (AVG(score)) as skillscore_F, gu_id from (SELECT (AVG(`game_score`)) as score , gs_id , gu_id, lastupdate FROM `game_reports` WHERE gs_id =61 and gu_id in (select id from users) group by gs_id , gu_id, lastupdate) a1 group by gs_id, gu_id) s3 on s3.gu_id=mu.id 

left join
(select (AVG(score)) as skillscore_P, gu_id from (SELECT (AVG(`game_score`)) as score , gs_id , gu_id, lastupdate FROM `game_reports` WHERE gs_id =62 and gu_id in (select id from users) group by gs_id , gu_id, lastupdate) a1 group by gs_id, gu_id) s4 on s4.gu_id=mu.id 

left join
(select (AVG(score)) as skillscore_L, gu_id from (SELECT (AVG(`game_score`)) as score , gs_id , gu_id, lastupdate FROM `game_reports` WHERE gs_id =63 and gu_id in (select id from users) group by gs_id , gu_id, lastupdate) a1 group by gs_id, gu_id) s5 on s5.gu_id=mu.id where mu.isdemo=0');
			//echo $this->multipledb->db->last_query(); exit;
			return $query->result_array();
			
		}
		
		public function clp_reports($doctorid)		 
		{
			$query = $this->db->query('select id, fname,lname,username,mobile,parentname, (select type from patient_type_master where id=mu.patient_type) as patienttype, s1.skillscore_M as skillscorem, skillscore_V as skillscorev,skillscore_F as skillscoref,skillscore_P as skillscorep,skillscore_L as skillscorel, a3.finalscore as avgbspiset1,COALESCE(a3.playedcount,0) as playcount,loggedcount,creation_date,
			(select CONCAT(doctorname," ",lastname) from doctormaster where id=doctorid) as doctorname from users mu 
			
left join (SELECT SUM(score)/5 as finalscore,count(gu_id) as playedcount, gu_id, (SELECT sid from users where id=gu_id) as schoolid from (select (AVG(score)) as score, gu_id, gs_id from (SELECT (AVG(`game_score`)) as score , gs_id , gu_id, lastupdate FROM `game_reports` WHERE gs_id in (59,60,61,62,63) and gu_id in (select id from users) group by gs_id , gu_id, lastupdate) a1 group by gs_id, gu_id ) a2 group by gu_id) a3 on a3.gu_id=mu.id 
left join (select (AVG(score)) as skillscore_M, gu_id from (SELECT (AVG(`game_score`)) as score , gs_id , gu_id, lastupdate FROM `game_reports` WHERE gs_id =59 and gu_id in (select id from users) group by gs_id , gu_id, lastupdate) a1 group by gs_id, gu_id) s1 on s1.gu_id=mu.id 
left join (select (AVG(score)) as skillscore_V, gu_id from (SELECT (AVG(`game_score`)) as score , gs_id , gu_id, lastupdate FROM `game_reports` WHERE gs_id =60 and gu_id in (select id from users) group by gs_id , gu_id, lastupdate) a1 group by gs_id, gu_id) s2 on s2.gu_id=mu.id 
left join (select (AVG(score)) as skillscore_F, gu_id from (SELECT (AVG(`game_score`)) as score , gs_id , gu_id, lastupdate FROM `game_reports` WHERE gs_id =61 and gu_id in (select id from users) group by gs_id , gu_id, lastupdate) a1 group by gs_id, gu_id) s3 on s3.gu_id=mu.id 
left join (select (AVG(score)) as skillscore_P, gu_id from (SELECT (AVG(`game_score`)) as score , gs_id , gu_id, lastupdate FROM `game_reports` WHERE gs_id =62 and gu_id in (select id from users) group by gs_id , gu_id, lastupdate) a1 group by gs_id, gu_id) s4 on s4.gu_id=mu.id 
left join (select (AVG(score)) as skillscore_L, gu_id from (SELECT (AVG(`game_score`)) as score , gs_id , gu_id, lastupdate FROM `game_reports` WHERE gs_id =63 and gu_id in (select id from users) group by gs_id , gu_id, lastupdate) a1 group by gs_id, gu_id) s5 on s5.gu_id=mu.id

left join (SELECT userid,count(DISTINCT date(created_date)) as loggedcount FROM `user_login_log` group by userid) log on log.userid=mu.id  where mu.isdemo=0 order by loggedcount DESC');
 
			//echo $this->db->last_query(); exit;
			return $query->result_array();
		}
		
		/**USERVIEW MODELS**/
		
		public function getusername($userid)
        {
					 
			$query = $this->db->query("SELECT id,username,gp_id,grade_id,startdate,enddate  FROM users where id='".$userid."'");		
			//echo $this->db->last_query(); exit;
			return $query->result_array();
        }
		
		public function getasapinfo($userid)
        {
					 
			$query = $this->db->query("SELECT id,fname,lname,gender,email,mobile,dob,city,(select state_name from state where id=users.stateid) as statename,couponcode,startdate,enddate,parentname,address,avatarimage,(select type from patient_type_master where id=users.patient_type) as patienttype,portal_type  FROM users  where id='".$userid."'");		
			//echo $this->db->last_query(); exit;
			return $query->result_array();
        }
		
		public function getuserid($uname)
        {
					 
			$query = $this->multipledb->db->query("SELECT id  FROM users where username='".$uname."'");		
			//echo $this->db->last_query(); exit;
			return $query->result_array();
        }
		
		public function getpatienttype()		 
		{
			$query = $this->db->query("SELECT id,type from  patient_type_master where status=1");
			//echo $this->db->last_query(); exit;
			return $query->result_array();
		}
		
		public function getacademicmonths($startdate,$enddate)
		 { //echo ;exit;
			 
		$query = $this->db->query("select DATE_FORMAT(m1, '%m') as monthNumber,DATE_FORMAT(m1, '%Y') as yearNumber,DATE_FORMAT(m1, '%b') as monthName from (select ('".$startdate."' - INTERVAL DAYOFMONTH('".$startdate."')-1 DAY) +INTERVAL m MONTH as m1 from (select @rownum:=@rownum+1 as m from(select 1 union select 2 union select 3 union select 4) t1,(select 1 union select 2 union select 3 union select 4) t2,(select 1 union select 2 union select 3 union select 4) t3,(select 1 union select 2 union select 3 union select 4) t4,(select @rownum:=-1) t0) d1) d2 where m1<='".$enddate."' order by m1");
		//echo $this->db->last_query(); exit;
			return $query->result_array();
		 }
		 
		  public function getbspicomparison($userid)		 
		{
			$query = $this->multipledb->db->query('select id, fname,  a3.finalscore as avgbspiset1 from users mu

left join 
 (SELECT SUM(score)/5 as finalscore, gu_id, (SELECT sid from users where id=gu_id) as schoolid from (select (AVG(score)) as score, gu_id, gs_id from (SELECT (AVG(`game_score`)) as score , gs_id , gu_id, lastupdate FROM `game_reports` WHERE gs_id in (59,60,61,62,63) and gu_id =  "'.$userid.'" group by gs_id , gu_id, lastupdate) a1 group by gs_id, gu_id ) a2 group by gu_id) a3   on a3.gu_id=mu.id 
 where  id = "'.$userid.'" ORDER BY avgbspiset1 DESC');
 
			//echo $this->multipledb->db->last_query(); exit;
			return $query->result_array();
		}
		
		public function clpbspi($userid)		 
		{
			$query = $this->db->query('select id, fname, a3.finalscore as avgbspiset1 from users mu

left join 
 (SELECT SUM(score)/5 as finalscore, gu_id, (SELECT sid from users where id=gu_id) as schoolid from (select (AVG(score)) as score, gu_id, gs_id from (SELECT (AVG(`game_score`)) as score , gs_id , gu_id, lastupdate FROM `game_reports` WHERE gs_id in (59,60,61,62,63) and gu_id =  "'.$userid.'" group by gs_id , gu_id, lastupdate) a1 group by gs_id, gu_id ) a2 group by gu_id) a3   on a3.gu_id=mu.id where  id = "'.$userid.'" ORDER BY avgbspiset1 DESC');
 
			//echo $this->multipledb->db->last_query(); exit;
			return $query->result_array();
		}
		
		 public function getskillwise_avg($uname) 
		{
			
			$query = $this->multipledb->db->query('select id, fname, s1.skillscore_M as skillscorem, skillscore_V as skillscorev,skillscore_F as skillscoref,skillscore_P as skillscorep,skillscore_L as skillscorel, a3.finalscore as avgbspiset1 from users mu

left join 
 (SELECT SUM(score)/5 as finalscore, gu_id, (SELECT sid from users where id=gu_id) as schoolid from (select (AVG(score)) as score, gu_id, gs_id from (SELECT (AVG(`game_score`)) as score , gs_id , gu_id, lastupdate FROM `game_reports` WHERE gs_id in (59,60,61,62,63) and gu_id in (select id from users) group by gs_id , gu_id, lastupdate) a1 group by gs_id, gu_id ) a2 group by gu_id) a3   on a3.gu_id=mu.id 
 
 left join
(select (AVG(score)) as skillscore_M, gu_id from (SELECT (AVG(`game_score`)) as score , gs_id , gu_id, lastupdate FROM `game_reports` WHERE gs_id =59 and gu_id in (select id from users) group by gs_id , gu_id, lastupdate) a1 group by gs_id, gu_id) s1 on s1.gu_id=mu.id 

left join
(select (AVG(score)) as skillscore_V, gu_id from (SELECT (AVG(`game_score`)) as score , gs_id , gu_id, lastupdate FROM `game_reports` WHERE gs_id =60 and gu_id in (select id from users) group by gs_id , gu_id, lastupdate) a1 group by gs_id, gu_id) s2 on s2.gu_id=mu.id 

left join
(select (AVG(score)) as skillscore_F, gu_id from (SELECT (AVG(`game_score`)) as score , gs_id , gu_id, lastupdate FROM `game_reports` WHERE gs_id =61 and gu_id in (select id from users) group by gs_id , gu_id, lastupdate) a1 group by gs_id, gu_id) s3 on s3.gu_id=mu.id 

left join
(select (AVG(score)) as skillscore_P, gu_id from (SELECT (AVG(`game_score`)) as score , gs_id , gu_id, lastupdate FROM `game_reports` WHERE gs_id =62 and gu_id in (select id from users) group by gs_id , gu_id, lastupdate) a1 group by gs_id, gu_id) s4 on s4.gu_id=mu.id 

left join
(select (AVG(score)) as skillscore_L, gu_id from (SELECT (AVG(`game_score`)) as score , gs_id , gu_id, lastupdate FROM `game_reports` WHERE gs_id =63 and gu_id in (select id from users) group by gs_id , gu_id, lastupdate) a1 group by gs_id, gu_id) s5 on s5.gu_id=mu.id 
 
 

 where username="'.$uname.'" ORDER BY avgbspiset1 DESC');
			//echo $this->multipledb->db->last_query(); exit;
			return $query->result_array();
			
		}
		
		public function getcounters($userid)		 
		{
			$query = $this->db->query("SELECT ROUND((SUM(gtime)/60),0) as gtime_school_count , SUM(answer) as answer_school_count, SUM(attempt_question) as attempted_question_count FROM game_reports gr join users u on gr.gu_id=u.id
		WHERE gtime IS NOT NULL AND answer IS NOT NULL and u.id='".$userid."'  and lastupdate between (select startdate from users where id='".$userid."') and (select enddate from users where id='".$userid."')");
 
			//echo $this->db->last_query(); exit;
			return $query->result_array();
		}
		
		public function getcrowny($userid)		 
		{
			$query = $this->db->query("select points from vi_sumofcrownypoints where U_ID='".$userid."' ");
 
			//echo $this->db->last_query(); exit;
			return $query->result_array();
		}
		
		public function getattemptsession($userid)		 
		{
			$query = $this->db->query("select gu_id,count(Completed) as attempt from (select gu_id,gs_id,count(gs_id) Completed from (SELECT count(gr.id) as PalyCount,DATE_FORMAT(`lastupdate`,'%m') as monthlist ,lastupdate,gs_id,gu_id from game_reports gr join users u on u.id = gr.gu_id join user_academic_mapping um on u.id=um.id where gu_id='".$userid."' and date(lastupdate) between (select startdate from users where id='".$userid."') and (select enddate from users where id='".$userid."') group by date(lastupdate),DATE_FORMAT(`lastupdate`,'%m'),gu_id,gs_id order by date(lastupdate))a2 group by gu_id,lastupdate)a2 ");
 
		//	echo $this->db->last_query(); exit;
			return $query->result_array();
		}
		
		public function getcompsession($userid)		 
		{
			$query = $this->db->query("select gu_id,count(Completed) as comp from (select gu_id,gs_id,count(gs_id) Completed from (SELECT count(gr.id) as PalyCount,DATE_FORMAT(`lastupdate`,'%m') as monthlist ,lastupdate,gs_id,gu_id from game_reports gr join users u on u.id = gr.gu_id join user_academic_mapping um on u.id=um.id where gu_id='".$userid."' and date(lastupdate) between (select startdate from users where id='".$userid."') and (select enddate from users where id='".$userid."') group by date(lastupdate),DATE_FORMAT(`lastupdate`,'%m'),gu_id,gs_id order by date(lastupdate))a2 group by gu_id,lastupdate)a2 where Completed>=5");
 
			//echo $this->db->last_query(); exit;
			return $query->result_array();
		}
		
		public function get_clp_skillwise_avg($userid)		 
		{
			$query = $this->db->query("select id, fname, s1.skillscore_M as skillscorem, skillscore_V as skillscorev,skillscore_F as skillscoref,skillscore_P as skillscorep,skillscore_L as skillscorel, a3.finalscore as avgbspiset1 from users mu 
left join (SELECT SUM(score)/5 as finalscore, gu_id, (SELECT sid from users where id=gu_id) as schoolid from (select (AVG(score)) as score, gu_id, gs_id from (SELECT (AVG(`game_score`)) as score , gs_id , gu_id, lastupdate FROM `game_reports` WHERE gs_id in (59,60,61,62,63) and gu_id in (select id from users) group by gs_id , gu_id, lastupdate) a1 group by gs_id, gu_id ) a2 group by gu_id) a3 on a3.gu_id=mu.id 
left join (select (AVG(score)) as skillscore_M, gu_id from (SELECT (AVG(`game_score`)) as score , gs_id , gu_id, lastupdate FROM `game_reports` WHERE gs_id =59 and gu_id in (select id from users) group by gs_id , gu_id, lastupdate) a1 group by gs_id, gu_id) s1 on s1.gu_id=mu.id 
left join (select (AVG(score)) as skillscore_V, gu_id from (SELECT (AVG(`game_score`)) as score , gs_id , gu_id, lastupdate FROM `game_reports` WHERE gs_id =60 and gu_id in (select id from users) group by gs_id , gu_id, lastupdate) a1 group by gs_id, gu_id) s2 on s2.gu_id=mu.id 
left join (select (AVG(score)) as skillscore_F, gu_id from (SELECT (AVG(`game_score`)) as score , gs_id , gu_id, lastupdate FROM `game_reports` WHERE gs_id =61 and gu_id in (select id from users) group by gs_id , gu_id, lastupdate) a1 group by gs_id, gu_id) s3 on s3.gu_id=mu.id 
left join (select (AVG(score)) as skillscore_P, gu_id from (SELECT (AVG(`game_score`)) as score , gs_id , gu_id, lastupdate FROM `game_reports` WHERE gs_id =62 and gu_id in (select id from users) group by gs_id , gu_id, lastupdate) a1 group by gs_id, gu_id) s4 on s4.gu_id=mu.id 
left join (select (AVG(score)) as skillscore_L, gu_id from (SELECT (AVG(`game_score`)) as score , gs_id , gu_id, lastupdate FROM `game_reports` WHERE gs_id =63 and gu_id in (select id from users) group by gs_id , gu_id, lastupdate) a1 group by gs_id, gu_id) s5 on s5.gu_id=mu.id 

 where id='".$userid."' ORDER BY avgbspiset1 DESC");
 
			//echo $this->db->last_query(); exit;
			return $query->result_array();
		}
		
public function getUserEfficiencyGraph($userid,$startdate,$enddate)
{
	$query = $this->db->query("
	select round((sum(score)/5),2) as score,playeddate as rtime,monthNumber,yearNumber from (select avg(score) as score,sum(playeddate) as playeddate,DATE_FORMAT(lastupdate, '%m') as monthNumber,DATE_FORMAT(lastupdate, '%Y') as yearNumber from ( SELECT (AVG(`game_score`)) as score,count(distinct lastupdate) as playeddate,gs_id,lastupdate,gu_id FROM `game_reports` WHERE gs_id in (59,60,61,62,63) and gu_id='".$userid."' and (lastupdate between '".$startdate."' and '".$enddate."') group by gs_id,lastupdate) a1 group by gs_id,month(lastupdate))a2 group by monthNumber");
	//echo $this->db->last_query(); exit;
	return $query->result_array();
}
		
		/**USERVIEW MODELS**/
		
		 public function totalrec_regionlist($start='',$limit='',$zoneid='',$bmid='',$txtbmname='')		 
		{
			
				$where = ' '; 		 			
	  if($bmid!='')
		{
			 $where.= " and id ='".$bmid."' "; 
		}

	 if($zoneid!='')
		{
			 $where.= " and  zoneid='".$zoneid."'"; 
		}
		
		if($txtbmname!='')
		{
			 $where.= " and personname LIKE '%".$txtbmname."%' "; 
		}
		
			$query = $this->db->query("select count(*) as totalrecord  from regionmaster r WHERE zoneid!=5 and isdemo=0 ".$where." order by status desc");
			//echo $this->db->last_query(); exit;
			return $query->result_array();
		}
		   
		   public function regionlist($start='',$limit='',$zoneid='',$bmid='',$txtbmname='')		 
		{
			
					$qry=' ';
					$where = ' '; 		 			
		if($bmid!='')
		{
			 $where.= " and id ='".$bmid."' "; 
		}

		if($zoneid!='')
		{
			 $where.= " and  zoneid='".$zoneid."'"; 
		}
		
		if($txtbmname!='')
		{
			 $where.= " and personname LIKE '%".$txtbmname."%' "; 
		}
		else if($limit=='')
			{
				$qry=" ";
			}
			else if($start=='' && $limit!=''){
				$qry=" limit ".$limit;
			}
			else if($start!='' && $limit!=''){
				$qry=" limit ".$start.','.$limit;
			}
			
			$query = $this->db->query("select id,regionname,personname,designation,mobilenumber,email,status,created_on,(select zonename from zone_master where ID=r.zoneid) as zname, (select sum(couponcount) from region_coupon_count where regionid=r.id ) as ccount,(select count(couponcode) from couponmaster where regionid=r.id and region_usedstatus='Y' ) as rusedcount, 
            (select count(couponcode) from couponmaster where regionid=r.id and status=1 ) as dusedcount,
            (select count(couponcode) from couponmaster where regionid=r.id and usedstatus='Y') as userused from regionmaster r WHERE zoneid!=5 and isdemo=0 ".$where." order by zname desc ".$qry."");
 
			//echo $this->db->last_query(); exit;
			return $query->result_array();
		}
		
		   public function regiondetail($regionid)		 
		{
			$query = $this->db->query("select id,regionname,personname,designation,(select zonename from zone_master where ID=r.zoneid) as zname from regionmaster r where id='".$regionid."' and isdemo=0 order by status desc");
 
			//echo $this->db->last_query(); exit;
			return $query->result_array();
		}
		
		/*------------------grade and pgm name------------------------*/
		
		public function coupondetail($regionid)		 
		{
			//$query = $this->db->query("select id, qrcode, qr_scanned_date_time, region_scanned_date_time, (select creation_date from users where couponcode=cm.couponcode) as useruseddate from couponmaster cm where regionid='".$regionid."'");
			
			$query = $this->db->query("SELECT cm.qrcode,cm.couponcode,cm.region_scanned_date_time,cm.qr_scanned_date_time as docscandate,cm.gradeid,(select gradename from program_grade_master where 	gradeid=cm.gradeid and programid=cm.programid ) as gradename,cm.programid,(select program_name from program_master where id=cm.programid ) as programname,cm.paymentmode,d.doctorname,d.lastname,d.mobilenumber,d.email as docemail,u.fname,u.parentname,u.mobile,u.email,u.created_on FROM couponmaster cm left join doctormaster d ON d.id=cm.doctorid left join users u ON u.couponcode=cm.couponcode where cm.regionid='".$regionid."' ORDER BY u.created_on DESC"); 
			//echo $this->db->last_query(); exit;
			return $query->result_array();
		}
		
		/*------------------grade and pgm name------------------------*/
		
		 public function insertregion($regionname,$personname,$mobile,$email,$password,$status)		 
		{
			$query = $this->db->query("INSERT INTO `regionmaster`(`regionname`, `username`, `password`, `personname`, `mobilenumber`, `email`, `status`, `created_on`) VALUES ('".$regionname."','".$email."','".$password."','".$personname."','".$mobile."','".$email."','".$status."',NOW())");
 
			//echo $this->db->last_query(); exit;
			//return $query->result_array();
		}
		
		 public function editregion($regionid)		 
		{
			$query = $this->db->query("SELECT * FROM regionmaster where id='".$regionid."'");
			//echo $this->db->last_query(); exit;
			return $query->result_array();
		}
		
		 public function updateregion($regionname,$personname,$mobile,$email,$status,$editid)		 
		{
			$query = $this->db->query("UPDATE `regionmaster` SET `regionname`='".$regionname."',`username`='".$email."',`personname`='".$personname."',`mobilenumber`='".$mobile."',`email`='".$email."',`status`='".$status."',`modifed_on`=NOW() WHERE id='".$editid."'");
 
			//echo $this->db->last_query(); exit;
			//return $query->result_array();
		}
		
		public function getzone()		 
		{
			$query = $this->db->query("SELECT ID,zonename from zone_master where status='Y' and ID!=5");
 
			//echo $this->db->last_query(); exit;
			return $query->result_array();
		}
		
		public function getregion($zoneid)		 
		{
			$query = $this->db->query("SELECT id,regionname,personname from regionmaster where zoneid='".$zoneid."' and status=1 and isdemo=0");
 
			//echo $this->db->last_query(); exit;
			return $query->result_array();
		}
		
		public function insertcouponcount($regionname,$adminid,$noofcoupons,$issuedate)		 
		{
			$query = $this->db->query("INSERT INTO region_coupon_count (regionid,adminid, couponcount, givendatetime,status,created_on)VALUES('".$regionname."','".$adminid."','".$noofcoupons."','".$issuedate."',1,NOW())");
 
			//echo $this->db->last_query(); exit;
			//return $query->result_array();
		}
		
		public function getcouponhistory()		 
		{
			//$query = $this->db->query("SELECT *,(select regionname from regionmaster where id=regionid and status=1) as rname FROM region_coupon_count");
			
			$query = $this->db->query("SELECT couponcount,givendatetime, r.regionname,r.personname,(select zonename from zone_master where ID=r.zoneid and status=1) as zname FROM region_coupon_count rc JOIN regionmaster r ON rc.regionid=r.id WHERE r.zoneid!=5 and r.isdemo=0 ORDER BY givendatetime DESC");
			//echo $this->db->last_query(); exit;
			return $query->result_array();
		}
		public function overallcoupondetail()		 
		{
			$query = $this->db->query("SELECT cm.qrcode,cm.couponcode,cm.region_scanned_date_time,cm.qr_scanned_date_time as docscandate,d.doctorname,d.lastname,d.mobilenumber,d.email as docemail,u.fname,u.parentname,u.mobile,u.email,u.created_on,regionname,personname,designation,(select zonename from zone_master where ID=r.zoneid) as zname FROM couponmaster cm 
left join doctormaster d ON d.id=cm.doctorid 
left join users u ON u.couponcode=cm.couponcode 
left join regionmaster r ON r.id=cm.regionid 
where cm.region_usedstatus='Y' and cm.regionid IN (select id from regionmaster where zoneid!=5 and isdemo=0)");
			//echo $this->db->last_query(); exit;
			return $query->result_array();
		}
		
		public function insert_login_log($adminid,$sessionid,$ip,$country,$region,$city,$isp,$browser,$status)
		{
			$query = $this->db->query('INSERT INTO admin_login_log(	adminid,sessionid,created_date,lastupdate,logout_date,ip,country,region,city,browser,isp,status)VALUES("'.$adminid.'","'.$sessionid.'",now(),now(),now(), "'.$ip.'","'.$country.'","'.$region.'","'.$city.'","'.$browser.'","'.$isp.'","'.$status.'")');
			//echo $this->db->last_query(); exit;
			return $query;
			
		}
		
		public function update_login_log($adminid,$sessionid)
		{
			$query = $this->db->query('update admin_login_log set lastupdate=now() where adminid="'.$adminid.'" and sessionid="'.$sessionid.'"');
			return $query;
			
		}
		
		public function update_logout_log($adminid,$sessionid)
		{
			$query = $this->db->query('update admin_login_log set lastupdate=now(),logout_date=now() where adminid="'.$adminid.'" and sessionid="'.$sessionid.'"');
			return $query;
			
		}
		
		/*public function gettotalcouponcount()
		{
			$query = $this->db->query('SELECT value from config_master where code="TOTALCOUPON" and status="Y" and type=1');
			return $query->result_array();
			
		}*/
		public function gettotalcouponcount()
		{
			$query = $this->db->query('SELECT sum(noofcoupon) as value from briobliss_approved_coupon where status="Y"');
			return $query->result_array();
		}
/* ----------------- Forget Password -------------------- */
	public function checkdoctormailidexist($emailid)
	{
				 
		$query = $this->db->query('select id,count(emailid) as emailcount,fname,lname,emailid as email,email as username,mobile from admin where emailid="'.$emailid.'" and status=1');		
		//echo $this->db->last_query(); exit;
		return $query->result_array();
	}
	public function resetpwdlog($userid,$randid)
	{	
		$qry=$this->db->query("insert into admin_password_history(adminid,randid,requestdatetime,status)values('".$userid."','".$randid."',NOW(),0)");
	}
	function CheckValidActivationlink($userid,$randid)
	{
		$query=$this->db->query("select adminid as userid,randid,requestdatetime from admin_password_history where status=0 and md5(adminid)='".$userid."' and md5(randid)='".$randid."'");
		//echo $this->db->last_query(); exit;
		return $query->result_array();
	}
	public function getResetpwdDoctorDetails($userid)
	{	
		$query = $this->db->query('select id,fname,lname,emailid as email,email as username,mobile from admin where id="'.$userid.'" and status=1');
		//echo $this->db->last_query(); exit;
		return $query->result_array();
	}
	function UpdateNewPwd($pwd,$userid,$salt1,$salt2,$orgpwd)
	{
		$qry=$this->db->query("update admin set password='".$pwd."',orgpwd='".$orgpwd."' where md5(id)='".$userid."'");
	}
	function UpdateNewPwd_log($userid,$randid,$orgpwd,$ip)
	{
		$qry=$this->db->query("update admin_password_history set processdatetime=now(),status=1,update_password='".$orgpwd."',ip='".$ip."' where md5(adminid)='".$userid."' and md5(randid)='".$randid."'");
	}
	/* Forget Password End --------------------- */
	/* --------- Coupon Code Approval by BrioBliss Admin ---------  */
	public function getCoupondetails()
	{	
		$query = $this->db->query('select totcoupongiven,totcouponapproved,(totcoupongiven-totcouponapproved) as remainingcoupontoapprove,issuedcouponcount,(totcouponapproved-issuedcouponcount) as unissuedcouponcount from(SELECT (select sum(noofcoupon) from edsix_issued_coupon where status="Y") as totcoupongiven,(select  sum(noofcoupon) from briobliss_approved_coupon where status="Y") as totcouponapproved,(SELECT SUM(couponcount) as totalcount FROM region_coupon_count  WHERE status=1 and regionid  IN (select id from regionmaster where zoneid!=5 and isdemo=0)) as issuedcouponcount)a1');
		//echo $this->db->last_query(); exit;
		return $query->result_array();
	}
	public function getApprovedCoupondetails($adminid)
	{	
		$query = $this->db->query('select noofcoupon,approved_by,approved_on,created_on from briobliss_approved_coupon where  status="Y"');
		//echo $this->db->last_query(); exit;
		return $query->result_array();
	}
	public function getEdsixGivencoupon()
	{	
		$query = $this->db->query('select noofcoupon,issued_by,issued_on from edsix_issued_coupon where  status="Y"');
		//echo $this->db->last_query(); exit;
		return $query->result_array();
	}
	public function approvecouponcount($adminid,$noofcoupons,$issuedate)		 
	{
		$query = $this->db->query("INSERT INTO briobliss_approved_coupon (noofcoupon, status,approved_by,approved_on,created_on)VALUES('".$noofcoupons."',1,'".$adminid."','".$issuedate."',NOW())");
	}
	/* --------- Coupon Code Approval by BrioBliss Admin END---------  */
	
	
	public function getgamenames($userid,$pid,$startdate,$enddate)
	{
	 
	$query=$this->db->query("SELECT a.gid,a.gname FROM  games a, game_reports b where a.gid=b.g_id and b.gu_id='".$userid."' and b.gp_id = '".$pid."'  and a.gc_id = 1 and (lastupdate between '".$startdate."' and '".$enddate."') group by a.gid");
	//echo $this->db->last_query(); exit;
	return $query->result();
	}
	public function getgamedetails($userid,$gameid,$pid,$startdate,$enddate)
	{
		$query = $this->db->query("select g_id, avg(game_score) as game_score,lastupdate from game_reports where gp_id = '".$pid."' and gu_id='".$userid."' and g_id='".$gameid."' AND (lastupdate between '".$startdate."' and '".$enddate."') group by lastupdate  ORDER BY lastupdate DESC LIMIT 10");
		//echo $this->db->last_query(); 
		return $query->result_array();
	}

	public function mybspicalendarSkillChart($skillsid,$uid,$dateQry,$startdate,$enddate)
	{
	  $query = $this->db->query("select AVG(gamescore) as gamescore,gs_id,playedMonth from (SELECT (AVG(game_score)) as gamescore ,gs_id , lastupdate,DATE_FORMAT(lastupdate,'%m') as playedMonth  FROM game_reports WHERE gs_id in (59,60,61,62,63) and gu_id='".$uid."' and  lastupdate between '".$startdate."' and '".$enddate."' and DATE_FORMAT(lastupdate, '%Y-%m')=\"".$dateQry."\"   group by gs_id,lastupdate) a1 group by gs_id");
		//echo $this->db->last_query(); exit;
		return $query->result_array();
	}
	public function mybspicalendar($school_id,$uid,$dateQry,$startdate,$enddate)
	{
	 $query = $this->db->query('select (sum(a.game_score)/5) as game_score, lastupdate,playedDate from(SELECT avg(gr.game_score) as game_score,count(*) as cnt, lastupdate,DATE_FORMAT(`lastupdate`,"%d") as playedDate FROM game_reports gr join category_skills sk join users u WHERE gr.gu_id = u.id and u.sid =2 and gr.gu_id='.$uid.' and sk.id = gr.gs_id and gr.gs_id in (SELECT id FROM category_skills where category_id=1) and  lastupdate between "'.$startdate.'" and "'.$enddate.'" AND DATE_FORMAT(lastupdate, "%Y-%m")=\''.$dateQry.'\' group by lastupdate, gr.gs_id, gr.gu_id order by gr.gs_id) a group by lastupdate');
		//echo $this->db->last_query(); exit;
		return $query->result_array();
						
	}
	
	public function IsAsapEnable($username)
	{
		$query = $query = $this->multipledb->db->query('select count(id) as playedstatus from game_reports where gu_id=(select id from users where username="'.$username.'") and gs_id in(59,60,61,62,63)');
		//echo $this->multipledb->db->last_query(); exit;
		return $query->result_array();
	}
	public function IsCLPEnable($uid)
	{
		$query = $query = $this->db->query('select count(id) as playedstatus from game_reports where gu_id="'.$uid.'" and gs_id in(59,60,61,62,63)');
		return $query->result_array();
	}
	public function getMonthWiseSkillScore($uid,$startdate,$enddate)
	{
		$query = $query = $this->db->query("select gs_id,(CASE WHEN gs_id=59 THEN 'MEMORY'
WHEN gs_id=60 THEN 'VP'
WHEN gs_id=61 THEN 'FA'
WHEN gs_id=62 THEN 'PS'
WHEN gs_id=63 THEN 'LI' else 0
END) as skillname,playedMonth,monthName,AVG(gamescore) as gamescore from (SELECT (AVG(game_score)) as gamescore ,gs_id , lastupdate,gu_id,DATE_FORMAT(lastupdate,'%m') as playedMonth,DATE_FORMAT(lastupdate, '%b') as monthName FROM game_reports WHERE gs_id in (59,60,61,62,63)and gu_id=".$uid." and lastupdate between '".$startdate."' and '".$enddate."' group by gs_id,lastupdate) a1 group by gs_id,playedMonth");
//echo $this->db->last_query(); exit;
		return $query->result_array();
	}
	public function mySkillCalendar($school_id,$uid,$dateQry,$startdate,$enddate)
	{
	 $query = $this->db->query('SELECT gs_id,avg(gr.game_score) as game_score,count(*) as cnt, lastupdate,DATE_FORMAT(`lastupdate`,"%d") as playedDate FROM game_reports gr join category_skills sk join users u WHERE gr.gu_id = u.id and u.sid =2 and gr.gu_id='.$uid.' and sk.id = gr.gs_id and gr.gs_id in (SELECT id FROM category_skills where category_id=1) and  lastupdate between "'.$startdate.'" and "'.$enddate.'" AND DATE_FORMAT(lastupdate, "%Y-%m")=\''.$dateQry.'\' group by lastupdate, gr.gs_id, gr.gu_id order by lastupdate asc');
		//echo $this->db->last_query(); exit;
		return $query->result_array();
						
	}
}
