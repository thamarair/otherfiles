<?php if(count($userslist)!=0) { //print_r($doctorlist); ?>
<?php echo $this->ajax_pagination->create_links(); ?>
                  <div class="x_content preventcopy" onmousedown='return false;' onselectstart='return false;'>
                    <div class="row">
                      <div class="col-md-12 col-sm-12 col-xs-12 text-center"> 
                      </div>

                      <div class="clearfix"></div>
<?php 
	$ini=0; 
	foreach($userslist as $res){
	$ini++;
	?>	
                      <div class="col-md-6 col-sm-6 col-lg-4 col-xs-12 profile_details">
                        <div class="well profile_view w100p">
                          <div class="col-sm-12" style="min-height: 300px;">
						  <div class="row">
						   <div class="col-md-8 col-lg-8 col-xs-8 col-sm-8">
                            <h5 class="brief"><i><b><?php echo $res['fname'].' '.$res['lname']; ?></b></i></h5></div>
							<?php if($res['patienttype']!='') { ?>
							 <div class="col-md-4 col-lg-4 col-xs-4 col-sm-4">
                            <h5 class="brief" style="font-size:11px;"><i><b>Type : <?php  echo $res['patienttype']; ?></b></i></h5></div><?php } ?>
							</div>
							<br/>
							<div class="col-sm-12">
							
							<div class="row"><div class="col-md-12 col-lg-12 col-xs-12 col-sm-12"><i class="fa fa-circle"></i> <?php echo $res['programname']; ?></div></div>
							
							<div class="row"><div class="col-md-12 col-lg-12 col-xs-12 col-sm-12"><i class="fa fa-book"></i> <?php echo $res['gradename']; ?></div></div>
							
							
							<div class="row"><div class="col-md-12 col-lg-12 col-xs-12 col-sm-12"><i class="fa fa-user"></i> <?php echo $res['parentname']; ?></div></div>
							
							<div class="row"><div class="col-md-12 col-lg-12 col-xs-12 col-sm-12"><i class="fa fa-mobile-phone"></i> <?php echo $res['mobile']; ?></div></div>
							
							<div class="row"><div class="col-md-12 col-lg-12 col-xs-12 col-sm-12"><i class="fa fa-envelope-o"></i> <?php echo $res['email']; ?></div>
							</div>
							
							
							<div class="row"><div class="col-md-12 col-lg-12 col-xs-12 col-sm-12"><i class="fa fa-birthday-cake"></i> <?php echo $res['dob']; ?></div></div>
							
							<div class="row"><div class="col-md-12 col-lg-12 col-xs-12 col-sm-12">Doctor Name : <?php echo $res['doctorname']; ?></div></div>
							
							<div class="row"><div class="col-md-12 col-lg-12 col-xs-12 col-sm-12"><i class="fa fa-map-marker"></i> <?php echo $res['address']; ?>, <br/><?php echo $res['city']; ?>, <?php echo $res['statename']; ?></div></div>
							
							<div class="row"><div class="col-md-12 col-lg-12 col-xs-12 col-sm-12">Registered Date :  <?php  if($res['creation_date']!=''){echo date('d-m-Y',strtotime($res['creation_date']));}else{echo '-';} ?></div></div>
							
							</div>
						  
						  
						  
						   <!--<div class="col-sm-6">
                            <h4 class="brief"><i><b><?php echo $res['fname']; ?></b></i></h4></div>-->
							<?php if($res['patienttype']!='') { ?>
							<!--<div class="col-sm-6">
                            <h5 style="float:right" class="brief"><i><b> Type : <?php  echo $res['patienttype']; ?></b></i></h5></div>--><?php } ?>
                           <!--<div class="left col-xs-7 <?php if($res['status']==0) { ?> inactiveelement <?php } ?>">
                              <ul class="list-unstyled">
							  <li><i class="fa fa-user"></i> <?php echo $res['parentname']; ?></li>
							  <li><i class="fa fa-mobile-phone"></i> <?php echo $res['mobile']; ?></li>
                                <li><i class="fa fa-envelope-o"></i> <?php echo $res['email']; ?></li>
                                <li><i class="fa fa-birthday-cake"></i> <?php echo $res['dob']; ?></li>
								<li>Doctor Name : <?php echo $res['doctorname']; ?></li>
								<li><i class="fa fa-map-marker"></i> <?php echo $res['address']; ?>, <br/><?php echo $res['city']; ?>, <?php echo $res['statename']; ?></li>
								<li>Registered Date :  <?php  if($res['creation_date']!=''){echo date('d-m-Y',strtotime($res['creation_date']));}else{echo '-';} ?></li>
                              </ul>
                            </div>-->
							<?php if($res['avatarimage']==""){$res['avatarimage']="assets/images/avatar.png";} 
  if(file_exists(APPPATH."../assets/".$res['avatarimage'])=='false')
   {$res['avatarimage']="assets/images/avatar.png";}else{$res['avatarimage']=$res['avatarimage'];} ?>
                            <!--<div class="right col-xs-5 text-center">
                              <img src="<?php echo $this->config->item('frontendurl'); ?><?php echo $res['avatarimage']; ?>" style="width:100px;height:100px;" alt="profileimage" class="img-circle img-responsive">
                            </div>-->
                          </div>
                           <div class="col-xs-12 bottom text-center" style="background:#93c5c7">
                            <div class="col-xs-12 col-sm-6 emphasis">
                            </div>
                             <div class="col-xs-12 col-sm-6 emphasis">
                              <?php if($res['isnew']=='O')
							  { ?>
								  <a style="float:right" href="<?php echo base_url(); ?>index.php/sa_reports/userview/<?php echo $res['id']; ?>" class="btn btn-success btn-xs">
									<i class="fa fa-user"> </i> View Details
								  </a> 
							  <?php } else { ?>
								   <a style="float:right" href="<?php echo base_url(); ?>index.php/sa_reports/userview/<?php echo $res['id']; ?>" class="btn btn-success btn-xs">
									<i class="fa fa-user"> </i> View Details new
								  </a>
							  <?php } ?>
                            </div>	 
                          </div>
                        </div>
	</div><?php } ?>
                    </div>
					<?php echo $this->ajax_pagination->create_links(); ?>
                  </div><?php } else {?>
			<div style="text-align: center;font-size: 20px;">No Records Found</div>
			<?php } ?>
                