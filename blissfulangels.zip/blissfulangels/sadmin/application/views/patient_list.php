<style type="text/css" media="print">
    * { display: none; }
</style>
 <div class="right_col" role="main">
          <div class="">
            <div class="page-title">
              <div class="title_left">
                <h3>Child List</h3>
              </div>
            </div>

            <div class="clearfix"></div>
			
			<div class="row" >
              <div class="col-md-12">
			 
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Search Child Here.. </h2>
                    <ul class="nav navbar-right panel_toolbox">
                      <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                      </li>
                     
                     
                    </ul>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
				  <form name="frmRegister" id="frmRegister" class="" method="POST"    accept-charset="utf-8"  >
				  <div class="row">
                    <div class="col-lg-3">
	<div class="form-group">
		<label for="ddlState">Zone Name</label>
		<select class="form-control"  name="zonename" id="zonename" style="margin-bottom: 0px;">
		<option value="">Select</option>
		<?php foreach($getzone as $row){?>
			<option value="<?php echo $row['ID']; ?>" <?php if($_POST['zonename']== $row['ID']) { ?>  selected='selected' <?php } ?>><?php echo $row['zonename']; ?></option>
		<?php } ?>
		</select> 
	</div>
</div>

<div class="col-lg-3">
	<div class="form-group">
		<label for="ddlState">Head Quarter - BM</label>
		<select class="form-control"  name="brandmanager" id="brandmanager" style="margin-bottom: 0px;">
		<option value="">Select</option>
		</select> 

	</div>
</div>

<div class="col-lg-2">
	  <div class="form-group">
		<label for="txtDOB">From Date</label>
		<input type="text" readonly class="form-control" name="fromdate" value="" id="fromdate">
	  </div>
    </div>
	
	<div class="col-lg-2">
	  <div class="form-group">
		<label for="txtDOB">To Date</label>
		<input type="text" readonly class="form-control" name="todate" value="" id="todate">
	  </div>
    </div>
	
	</div>
  
  <div class="row">
 
	<!--<div class="col-lg-3">
  <div class="form-group">
    <label for="txtcode">Doctor Name</label>
    <input type="text"   class="form-control" name="txtdocname" value="" id="txtdocname">
  </div> 
  </div>
  
  <div class="col-lg-3">
  <div class="form-group">
    <label for="txtcode">Parent Name</label>
    <input type="text"   class="form-control" name="txtparentname" value="" id="txtparentname">
  </div> 
  </div>--->
  
  <div class="col-lg-3">
  <div class="form-group">
    <label for="txtcode">Child Name</label>
    <input type="text"   class="form-control" name="txtpatientname" value="" id="txtpatientname">
  </div> 
  </div>
  
  <div class="col-lg-2">
	  <div style="margin-top: 22px;">
   <input type="button" id="btnsrch" name="btnsubmit" style="float:none;" class="btn btn-success" value="Submit">
   <input type="reset"  id="btnReset" class="btn btn-waring">
</div>
    </div>
	
	
	</div></form><div id="error" style="text-align: center;color: red;font-size: 20px;"></div>
                  </div>
                </div>
               
              </div>
            </div>

            <div class="row">
			<?php $count = count($userslist); if($count==0) { ?>
			<h2 style="text-align: center; font-size: 23px;">No patient has registered yet</h2>
			<?php } else { ?>
              <div class="col-md-12">
			  <div class="loading" style="display:none;" ><img src="<?php echo base_url(); ?>assets/images/ajax-page-loader.gif" style="width:80px;" /></div>
                <div class="x_panel" id="postList">
				<?php echo $this->ajax_pagination->create_links(); ?>
                  <div class="x_content preventcopy" onmousedown='return false;' onselectstart='return false;'>
                    <div class="row">
                      <div class="col-md-12 col-sm-12 col-xs-12 text-center"> 
                      </div>

                      <div class="clearfix"></div>
					  
					  
<?php 
	$ini=0; 
	foreach($userslist as $res){
	$ini++;
	?>	
                      <div class="col-md-6 col-sm-6 col-lg-4 col-xs-12 profile_details">
                        <div class="well profile_view w100p">
                          <div class="col-sm-12" style="min-height: 300px;">
						  <div class="row">
						   <div class="col-md-8 col-lg-8 col-xs-8 col-sm-8">
                            <h5 class="brief"><i><b><?php echo $res['fname'].' '.$res['lname']; ?></b></i></h5></div>
							<?php if($res['patienttype']!='') { ?>
							 <div class="col-md-4 col-lg-4 col-xs-4 col-sm-4">
                            <h5 class="brief" style="font-size:11px;"><i><b>Type : <?php  echo $res['patienttype']; ?></b></i></h5></div><?php } ?>
							</div>
							<br/>
							<div class="col-sm-12">
							
							<div class="row"><div class="col-md-12 col-lg-12 col-xs-12 col-sm-12"><i class="fa fa-circle"></i> <?php echo $res['programname']; ?></div></div>
							
							<div class="row"><div class="col-md-12 col-lg-12 col-xs-12 col-sm-12"><i class="fa fa-book"></i> <?php echo $res['gradename']; ?></div></div>
							
							<div class="row"><div class="col-md-12 col-lg-12 col-xs-12 col-sm-12"><i class="fa fa-user"></i> <?php echo $res['parentname']; ?></div></div>
							
							<div class="row"><div class="col-md-12 col-lg-12 col-xs-12 col-sm-12"><i class="fa fa-mobile-phone"></i> <?php echo $res['mobile']; ?></div></div>
							
							<div class="row"><div class="col-md-12 col-lg-12 col-xs-12 col-sm-12"><i class="fa fa-envelope-o"></i> <?php echo $res['email']; ?></div>
							</div>
							
							
							<div class="row"><div class="col-md-12 col-lg-12 col-xs-12 col-sm-12"><i class="fa fa-birthday-cake"></i> <?php echo $res['dob']; ?></div></div>
							
							<div class="row"><div class="col-md-12 col-lg-12 col-xs-12 col-sm-12">Doctor Name : <?php echo $res['doctorname']; ?></div></div>
							
							<div class="row"><div class="col-md-12 col-lg-12 col-xs-12 col-sm-12"><i class="fa fa-map-marker"></i> <?php echo $res['address']; ?>, <br/><?php echo $res['city']; ?>, <?php echo $res['statename']; ?></div></div>
							
							<div class="row"><div class="col-md-12 col-lg-12 col-xs-12 col-sm-12">Registered Date :  <?php  if($res['creation_date']!=''){echo date('d-m-Y',strtotime($res['creation_date']));}else{echo '-';} ?></div></div>
							
							</div>
						  
						  
						  
						   <!--<div class="col-sm-6">
                            <h4 class="brief"><i><b><?php echo $res['fname']; ?></b></i></h4></div>-->
							<?php if($res['patienttype']!='') { ?>
							<!--<div class="col-sm-6">
                            <h5 style="float:right" class="brief"><i><b> Type : <?php  echo $res['patienttype']; ?></b></i></h5></div>--><?php } ?>
                           <!--<div class="left col-xs-7 <?php if($res['status']==0) { ?> inactiveelement <?php } ?>">
                              <ul class="list-unstyled">
							  <li><i class="fa fa-user"></i> <?php echo $res['parentname']; ?></li>
							  <li><i class="fa fa-mobile-phone"></i> <?php echo $res['mobile']; ?></li>
                                <li><i class="fa fa-envelope-o"></i> <?php echo $res['email']; ?></li>
                                <li><i class="fa fa-birthday-cake"></i> <?php echo $res['dob']; ?></li>
								<li>Doctor Name : <?php echo $res['doctorname']; ?></li>
								<li><i class="fa fa-map-marker"></i> <?php echo $res['address']; ?>, <br/><?php echo $res['city']; ?>, <?php echo $res['statename']; ?></li>
								<li>Registered Date :  <?php  if($res['creation_date']!=''){echo date('d-m-Y',strtotime($res['creation_date']));}else{echo '-';} ?></li>
                              </ul>
                            </div>-->
							<?php if($res['avatarimage']==""){$res['avatarimage']="assets/images/avatar.png";} 
  if(file_exists(APPPATH."../assets/".$res['avatarimage'])=='false')
   {$res['avatarimage']="assets/images/avatar.png";}else{$res['avatarimage']=$res['avatarimage'];} ?>
                            <!--<div class="right col-xs-5 text-center">
                              <img src="<?php echo $this->config->item('frontendurl'); ?><?php echo $res['avatarimage']; ?>" style="width:100px;height:100px;" alt="profileimage" class="img-circle img-responsive">
                            </div>-->
                          </div>
                          
						   <div class="col-xs-12 bottom text-center" style="background:#93c5c7">
                            <div class="col-xs-12 col-sm-6 emphasis">
                            </div>
                             <div class="col-xs-12 col-sm-6 emphasis">
                              <?php if($res['isnew']=='O')
							  { ?>
								  <a style="float:right" href="<?php echo base_url(); ?>index.php/sa_reports/userview/<?php echo $res['id']; ?>" class="btn btn-success btn-xs">
									<i class="fa fa-user"> </i> View Details
								  </a> 
							  <?php } else { ?>
								   <a style="float:right" href="<?php echo base_url(); ?>index.php/sa_reports/userview/<?php echo $res['id']; ?>" class="btn btn-success btn-xs">
									<i class="fa fa-user"> </i> View Details new
								  </a>
							  <?php } ?>
                            </div>	 
                          </div>
                        </div>
	</div><?php } ?>
                    </div>
                  </div>
				  <?php echo $this->ajax_pagination->create_links(); ?>
                </div>
			</div><?php } ?>
            </div>
			
          </div>
        </div>	
		

<link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/jquery-ui.css">
<script src="<?php echo base_url(); ?>assets/js/jquery.min.js" type="text/javascript"></script>
<script src="<?php echo base_url(); ?>assets/js/jquery-ui.js"></script>

<link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/zebra/zebra_datepicker.min.css" type="text/css">
<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/zebra/zebra_datepicker.min.js"></script>

<script>
$('#btnsrch').click(function(){
	$('#error').html('');
	var zonename = $('#zonename').val();
	var brandmanager = $('#brandmanager').val();
	var fromdate = $('#fromdate').val();
	var todate = $('#todate').val();
//	var txtdocname = $('#txtdocname').val();
//	var txtparentname = $('#txtparentname').val();
	var txtpatientname = $('#txtpatientname').val();
	
	var page_num = page_num?page_num:0;
	if(zonename!='' || brandmanager!='' || fromdate!='' || todate!='' || txtpatientname!='')
	{
	searchFilter(page_num,zonename,brandmanager,fromdate,todate,txtpatientname);
	}
	else { $('#error').html('Please select any one'); }
	
});

function searchFilter(page_num,zonename,brandmanager,fromdate,todate,txtpatientname) {
    page_num = page_num?page_num:0;
    var keywords = $('#keywords').val();
    var sortBy = $('#sortBy').val();
	
	var zonename = $('#zonename').val();
	var brandmanager = $('#brandmanager').val();
	var fromdate = $('#fromdate').val();
	var todate = $('#todate').val();
	var txtdocname = $('#txtdocname').val();
	var txtparentname = $('#txtparentname').val();
	var txtpatientname = $('#txtpatientname').val();
	
    $.ajax({
        type: 'POST',
        url: '<?php echo base_url(); ?>index.php/home/patientlist_PaginationData/'+page_num,
       // data:'page='+page_num,
	   data:{page:page_num,zonename:zonename,brandmanager:brandmanager,fromdate:fromdate,todate:todate,txtpatientname:txtpatientname},
        beforeSend: function () {
            $('.loading').show();
        },
        success: function (html) {
            $('#postList').html(html);
            $('.loading').fadeOut("slow");
        }
    });
}

$('#zonename').change(function(){
	
	var zoneid = $(this).val();
	
	$.ajax({
type:"POST",
url:"<?php echo base_url('index.php/home/getregion') ?>",
data:{zoneid:zoneid},
success:function(result)
{
//alert(result);
//$('#frmRegister')[0].reset();
$('#brandmanager').html(result);
}
});
});

$('#fromdate').Zebra_DatePicker({
       // direction: true,
		format: 'd M, Y',
        pair: $('#todate')
    });

    $('#todate').Zebra_DatePicker({
		format: 'd M, Y'
       // direction: 1
    });
	
	$('#btnReset').click(function() {
	location.href="patientlist";
});

</script>
<style>
.reporttitle { color:#1abb9c; }
thead{ background-color: #1abb9c; color: #fff;}
.pagination a{background: #ca0f0f;padding: 7px;color:#fff}
.pagination b{background: #15cc46;padding: 7px;color:#fff}
.pagination{float:right;}

.loading {
  position: fixed;
  z-index: 999;
  height: 2em;
  width: 2em;
  overflow: show;
  margin: auto;
  top: 0;
  left: 0;
  bottom: 0;
  right: 0;
}

.loading:before {
  content: '';
  display: block;
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background-color: rgba(0,0,0,0.3);
}

/* :not(:required) hides these rules from IE9 and below */
.loading:not(:required) {
  /* hide "loading..." text */
  font: 0/0 a;
  color: transparent;
  text-shadow: none;
  background-color: transparent;
  border: 0;
}



</style>
