<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	  public function __construct()
        {
                // Call the CI_Model constructor
                parent::__construct();
				$this->load->model('Dashboard_model');
				$this->load->library('session');
				$this->load->library('My_PHPMailer');
				$this->load->library('Ajax_pagination');
				$this->perPage = 12;
        }
		
	public function index()
	{			
		//$this->load->view('header');
		$this->load->view('index');
		//$this->load->view('footer');
		
	}
	
	public function logincheck()
	{	

	
			$data['query'] = $this->Dashboard_model->checklogin($this->input->post('username'),md5($this->input->post('password')));
		//	echo $data['query'][0]['school_id']; exit;
			if(isset($data['query'][0]['id'])){ 
			
			$uniqueId = $data['query'][0]['id']."".date("YmdHis")."".round(microtime(true) * 1000);
			 
			$this->session->set_userdata(array(
			
			'adminid'       => $data['query'][0]['id'],
			'fname'       => $data['query'][0]['fname'],
			'login_session_id'=>$uniqueId, 
			'level'=> $data['query'][0]['level'],
		
			));
			
			
			
if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
 $ip=$_SERVER['HTTP_CLIENT_IP'];}
 elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
 $ip=$_SERVER['HTTP_X_FORWARDED_FOR'];} else {
 $ip=$_SERVER['REMOTE_ADDR'];}		
$this->Dashboard_model->insert_login_log($data['query'][0]['id'],$uniqueId,$ip,$this->input->post('txcountry'),$this->input->post('txregion'),$this->input->post('txcity'),$this->input->post('txisp'),$_SERVER['HTTP_USER_AGENT'],1);
			
			
			redirect('index.php/home/dashboard');
			}
			else {
				$data['error'] = 'Invalid Crendentials';
				$this->load->view('index', $data);
			}
	
	
	}
	
	public function checkuserisactive()
	{
			$this->Dashboard_model->update_login_log($this->session->adminid,$this->session->login_session_id);
	}
	
	public function dashboard()
	{
		if($this->session->adminid=="" || !isset($this->session->adminid)){redirect('index.php');}
		
	$data['hospitalcount'] = $this->Dashboard_model->hospitalcount();
	$data['doctorcount'] = $this->Dashboard_model->doctorcount();
	$data['usercount'] = $this->Dashboard_model->usercount();	
	$data['totalcouponissued'] = $this->Dashboard_model->totalcouponissued();	
	$data['scannedbyregion'] = $this->Dashboard_model->scannedbyregion();	
	$data['scannedbydoctor'] = $this->Dashboard_model->scannedbydoctor();	
	
		$this->load->view('header', $data);
		$this->load->view('home', $data);
		$this->load->view('footer');
	}
	
	public function hospitallist()
	{
		if($this->session->adminid=="" || !isset($this->session->adminid)){redirect('index.php');}
		$data['hospitallist'] = $this->Dashboard_model->hospitallist();
		$this->load->view('header');
		$this->load->view('hospital_list', $data);
		$this->load->view('footer');
	}
	
	public function doctorlist()
	{
		if($this->session->adminid=="" || !isset($this->session->adminid)){redirect('index.php');}
		
	//	$totalRec = count($this->Dashboard_model->doctorlist('',''));
		
		$data['totalrecord'] = $this->Dashboard_model->totalrec_doctorlist();
		
        $totalRec = $data['totalrecord'][0]['totalrecord']; 
        
        //pagination configuration
        $config['target']      = '#postList';
        $config['base_url']    = base_url().'index.php/home/ajaxPaginationData';
        $config['total_rows']  = $totalRec;
        $config['per_page']    = $this->perPage;
        $config['link_func']   = 'searchFilter';
        $this->ajax_pagination->initialize($config);
		
		$data['getzone'] = $this->Dashboard_model->getzone();

        //get the posts data
        $data['doctorlist'] = $this->Dashboard_model->doctorlist('',$this->perPage,$zoneid);
		
		$this->load->view('header');
		$this->load->view('doctor/doctor_list', $data);
		$this->load->view('footer');
	}
	
	public function ajaxPaginationData(){
        $conditions = array();
        
        //calc offset number
        $page = $this->input->post('page');
        if(!$page){
            $offset = 0;
        }else{
            $offset = $page;
        }        
        //total rows count
        //$totalRec = count($this->Dashboard_model->doctorlist('',''));
		$zoneid=$this->input->post('zonename'); 
		$bmid=$this->input->post('brandmanager'); 
		$docname=$this->input->post('docname'); 
		
		$fdate= $this->input->post('fromdate'); 
		$tdate= $this->input->post('todate'); 

		$data['totalrecord'] = $this->Dashboard_model->totalrec_doctorlist('','',$zoneid,$bmid,$fdate,$tdate,$docname);
        $totalRec = $data['totalrecord'][0]['totalrecord']; 
        
        //pagination configuration
        $config['target']      = '#postList';
        $config['base_url']    = base_url().'index.php/home/ajaxPaginationData';
        $config['total_rows']  = $totalRec;
        $config['per_page']    = $this->perPage;
        $config['link_func']   = 'searchFilter';
        $this->ajax_pagination->initialize($config);
        
        //set start and limit
        $conditions['start'] = $offset-$this->perPage;
        $conditions['limit'] = $this->perPage;
        
        //get posts data
        $data['doctorlist'] = $this->Dashboard_model->doctorlist($offset,$this->perPage,$zoneid,$bmid,$fdate,$tdate,$docname);
        
        //load the view
        $this->load->view('doctor/doctor_list_ajax.php', $data, false);
    }
	
	public function bmlistPaginationData(){
        $conditions = array();
        
        //calc offset number
        $page = $this->input->post('page');
        if(!$page){
            $offset = 0;
        }else{
            $offset = $page;
        }        
		
		$zoneid=$this->input->post('zonename'); 
		$bmid=$this->input->post('brandmanager'); 
		$txtbmname=$this->input->post('txtbmname');
		
        //total rows count
        //$totalRec = count($this->Dashboard_model->regionlist('',''));
		$data['totalrecord'] = $this->Dashboard_model->totalrec_regionlist('','',$zoneid,$bmid,$txtbmname);
        $totalRec = $data['totalrecord'][0]['totalrecord'];
        
        //pagination configuration
        $config['target']      = '#postList';
        $config['base_url']    = base_url().'index.php/home/bmlistPaginationData';
        $config['total_rows']  = $totalRec;
        $config['per_page']    = $this->perPage;
        $config['link_func']   = 'searchFilter';
        $this->ajax_pagination->initialize($config);
        
        //set start and limit
        $conditions['start'] = $offset-$this->perPage;
        $conditions['limit'] = $this->perPage;
        
        //get posts data
        $data['regionlist'] = $this->Dashboard_model->regionlist($offset,$this->perPage,$zoneid,$bmid,$txtbmname);
        
        //load the view
        $this->load->view('region_list_ajax.php', $data, false);
    }
	
	
	public function doctorlist_csv()
	{
		if($this->session->adminid=="" || !isset($this->session->adminid)){redirect('index.php');}
		$data['doctorlist'] = $this->Dashboard_model->doctorlist();
		
		$ceationkey = date('YmdHis');
		$csvfilename = "uploads/Doctorlist_".$ceationkey.".csv";
		$file = fopen($csvfilename,"w");
		fputcsv($file,array('S.No.','Name','Head Quarter','Gender','DOB','Primary Mobile Number','Secondary Mobile Number','Primary Email ID','Secondary Email ID','Hospital Name','Address','City','State','Registered Date','Coupons Scanned','Coupons Registered By Child','Referred BM Name','Pan','Account Holder Name','Account No.','IFSC Code','Bank Name','Branch Name'));
		
	
		
		$ini=0; 
	foreach($data['doctorlist'] as $res){
	$ini++;
	
	$doctorname = $res['doctorname'].' '.$res['lastname'];
	if($res['gender']=='M') { $gender = 'Male'; } else if($res['gender']=='F') { $gender = 'Female'; }
	if($res['created_on']!=''){ $regdate = date('d-m-Y',strtotime($res['created_on'])); } else{ $regdate =  '-';}
	
	 fputcsv($file,array($ini,$doctorname,$res['headquarter'],$gender,$res['dateofbirth'],$res['mobilenumber'],$res['secondarymobilenumber'],$res['email'],$res['secondaryemail'],$res['hospitalname'],$res['address'],$res['city'],$res['statename'],$regdate,$res['scannedcount'],$res['childusedcount'],$res['bmname'],$res['pan'],$res['accholdername'],$res['accno'],$res['ifsccode'],$res['bankname'],$res['branchname']));
 }
 
 

    fclose($handle);
	
echo $data['filename'] = $csvfilename; exit;
	}
	
	public function addhospital()
	{
		if($this->session->adminid=="" || !isset($this->session->adminid)){redirect('index.php');}
		$data['getstate'] = $this->Dashboard_model->getstate();
		$this->load->view('header');
		$this->load->view('hospital_add', $data);
		$this->load->view('footer');
	}
	
	public function adddoctor()
	{
		if($this->session->adminid=="" || !isset($this->session->adminid)){redirect('index.php');}
		$data['getstate'] = $this->Dashboard_model->getstate();
		$data['gethospital'] = $this->Dashboard_model->gethospital();
		$this->load->view('header');
		$this->load->view('doctor/doctor_add', $data);
		$this->load->view('footer');
	}
	
	
	public function patientlist()
	{
		if($this->session->adminid=="" || !isset($this->session->adminid)){redirect('index.php');} 
		if($this->session->adminid!=1){ redirect('index.php/home/dashboard'); }
		
		//$totalRec = count($this->Dashboard_model->patientlist('',''));
		$data['totalrecord'] = $this->Dashboard_model->totalrec_patientlist();
        $totalRec = $data['totalrecord'][0]['totalrecord']; 
	  
        //pagination configuration
        $config['target']      = '#postList';
        $config['base_url']    = base_url().'index.php/home/patientlist';
        $config['total_rows']  = $totalRec;
        $config['per_page']    = 6;
        $config['link_func']   = 'searchFilter';
        $this->ajax_pagination->initialize($config);
		
		$data['getzone'] = $this->Dashboard_model->getzone();
        
        //get the posts data				
		$data['userslist'] = $this->Dashboard_model->patientlist('',6);
		$this->load->view('header');
		$this->load->view('patient_list', $data);
		$this->load->view('footer');
	}
	
	public function patientlist_PaginationData(){
        $conditions = array();
        
        //calc offset number
        $page = $this->input->post('page');
        if(!$page){
            $offset = 0;
        }else{
            $offset = $page;
        }        
		
		$zoneid=$this->input->post('zonename'); 
		$bmid=$this->input->post('brandmanager'); 
		$fdate= $this->input->post('fromdate'); 
		$tdate= $this->input->post('todate');
	//	$docname=$_POST['txtdocname']; 
	//	$parentname=$_POST['txtparentname']; 
		$patientname=$this->input->post('txtpatientname'); 
		
		
        //total rows count
       // $totalRec = count($this->Dashboard_model->patientlist('',''));
	   
	   $data['totalrecord'] = $this->Dashboard_model->totalrec_patientlist('','',$zoneid,$bmid,$fdate,$tdate,$patientname);
        $totalRec = $data['totalrecord'][0]['totalrecord']; 
        
        //pagination configuration
        $config['target']      = '#postList';
        $config['base_url']    = base_url().'index.php/home/patientlist_PaginationData';
        $config['total_rows']  = $totalRec;
        $config['per_page']    = 6;
        $config['link_func']   = 'searchFilter';
        $this->ajax_pagination->initialize($config);
        
        //set start and limit
        $conditions['start'] = $offset-$this->perPage;
        $conditions['limit'] = $this->perPage;
        
        //get posts data
        $data['userslist'] = $this->Dashboard_model->patientlist($offset,6,$zoneid,$bmid,$fdate,$tdate,$patientname);
        
        //load the view
        $this->load->view('patient_list_ajax.php', $data, false);
    }
	
	public function inserthospital()
	{
		if($this->session->adminid=="" || !isset($this->session->adminid)){redirect('index.php');}
		 $data['addhospital'] = $this->Dashboard_model->addhospital($this->input->post('txtHName'),$this->input->post('txtcode'),$this->input->post('txtMobile'),$this->input->post('txtSMobile'),$this->input->post('txtEmail'),$this->input->post('txtSEmail'),$this->input->post('ddlState'),$this->input->post('txtCity'),$this->input->post('txtAddress'),$this->input->post('txtcontactperson'),$this->input->post('txtstatus'));
		 
		 redirect('index.php/home/hospitallist');
		
	} 
	
	public function insertdoctor()
	{
		if($this->session->adminid=="" || !isset($this->session->adminid)){redirect('index.php');}
		 $data['addhospital'] = $this->Dashboard_model->adddoctor($this->input->post('txtFName'),$this->input->post('txtLName'),$this->input->post('rdGender'),$this->input->post('txtDOB'),$this->input->post('txtEmail'),$this->input->post('txtSEmail'),$this->input->post('txtMobile'),$this->input->post('txtSMobile'),$this->input->post('ddlState'),$this->input->post('txtCity'),$this->input->post('txthospitalname'),$this->input->post('txtAddress'),$this->input->post('txtstatus'));
		 
		 redirect('index.php/home/doctorlist');
		
	} 
	
	public function hospitaledit()
	{
		if($this->session->adminid=="" || !isset($this->session->adminid)){redirect('index.php');}
		$editid = $this->uri->segment(3);
		$data['getstate'] = $this->Dashboard_model->getstate();
		$data['edithos'] = $this->Dashboard_model->edithospital($editid);
		 
		$this->load->view('header');
		$this->load->view('hospital_edit', $data);
		$this->load->view('footer');
		
	} 
	
	public function doctoredit()
	{
		if($this->session->adminid=="" || !isset($this->session->adminid)){redirect('index.php');}
		$editid = $this->uri->segment(3);
		$data['getstate'] = $this->Dashboard_model->getstate();
		$data['gethospital'] = $this->Dashboard_model->gethospital();
		$data['editdoctor'] = $this->Dashboard_model->editdoctor($editid);
		 
		$this->load->view('header');
		$this->load->view('doctor/doctor_edit', $data);
		$this->load->view('footer');
		
	} 
	
	public function hospitalupdate()
	{
		if($this->session->adminid=="" || !isset($this->session->adminid)){redirect('index.php');}
		
		$data['updatehospital'] = $this->Dashboard_model->updatehospital($this->input->post('txtHName'),$this->input->post('txtMobile'),$this->input->post('txtSMobile'),$this->input->post('txtEmail'),$this->input->post('txtSEmail'),$this->input->post('ddlState'),$this->input->post('txtCity'),$this->input->post('txtAddress'),$this->input->post('txtcontactperson'),$this->input->post('txtstatus'),$this->input->post('txthdnid'));
		
		redirect('index.php/home/hospitallist');
		
	} 
	
	public function doctorupdate()
	{
		if($this->session->adminid=="" || !isset($this->session->adminid)){redirect('index.php');}
		
		 $data['addhospital'] = $this->Dashboard_model->updatedoctor($this->input->post('txtFName'),$this->input->post('txtLName'),$this->input->post('rdGender'),$this->input->post('txtDOB'),$this->input->post('txtEmail'),$this->input->post('txtSEmail'),$this->input->post('txtMobile'),$this->input->post('txtSMobile'),$this->input->post('ddlState'),$this->input->post('txtCity'),$this->input->post('txthospitalname'),$this->input->post('txtAddress'),$this->input->post('txtstatus'),$this->input->post('txthdnid'));
		 
		 redirect('index.php/home/doctorlist');
		
	} 
	
	public function patientperformance()
	{
		if($this->session->adminid=="" || !isset($this->session->adminid)){redirect('index.php');}
		if($this->session->adminid!=1){ redirect('index.php/home/dashboard'); }
		
		$doctorid = $this->session->doctorid;
	//	$data['asap_reports'] = $this->Dashboard_model->asap_reports($doctorid);
		$data['clp_reports'] = $this->Dashboard_model->clp_reports($doctorid);
		
		$this->load->view('header');
		$this->load->view('patient_performance', $data);
		$this->load->view('footer');
	}
	
	public function patientperformance_csv()
	{
		if($this->session->adminid=="" || !isset($this->session->adminid)){redirect('index.php');}
		if($this->session->level==2){ redirect('index.php/home/dashboard'); }
		
		$doctorid = $this->session->doctorid;
		$data['asap_reports'] = $this->Dashboard_model->asap_reports($doctorid);
		$data['clp_reports'] = $this->Dashboard_model->clp_reports($doctorid);
		
		$ceationkey = date('YmdHis');
		$csvfilename = "uploads/Patientlist_".$ceationkey.".csv";
		$file = fopen($csvfilename,"w");
		fputcsv($file,array('S.No.','Firstname','Lastname','Email ID','Mobile Number','Parent Name','Patient Type','ASAP - M','ASAP - VP','ASAP - FA','ASAP - P','ASAP - L','ASAP - BSPI','CEP - M','CEP - VP','CEP - FA','CEP - P','CEP - L','CEP - BSPI','Program Status'));
		
		foreach($data['asap_reports'] as $key1=>$val1) {
			
			$query1[$data['asap_reports'][$key1]['username']] =  $val1;
	
		}		
		foreach($data['clp_reports'] as $key2=>$val2) {
			
			$query2[$data['clp_reports'][$key2]['username']] =  $val2;

		}
		
		$ini=0; 
	foreach($query1 as $key3=>$val3){
	$ini++;
	
	if($val3['skillscorem']=="") { $asap_mscore= "-"; } else {   $asap_mscore= round($val3['skillscorem'], 2);  }
	if($val3['skillscorev']=="") { $asap_vscore= "-"; } else {   $asap_vscore= round($val3['skillscorev'], 2);  }
	if($val3['skillscoref']=="") { $asap_fscore= "-"; } else {   $asap_fscore= round($val3['skillscoref'], 2);  }
	if($val3['skillscorep']=="") { $asap_pscore= "-"; } else {   $asap_pscore= round($val3['skillscorep'], 2);  }
	if($val3['skillscorel']=="") { $asap_lscore= "-"; } else {   $asap_lscore= round($val3['skillscorel'], 2);  }
	if($val3['avgbspiset1']=="") { $asap_bspi= "-";   } else {     $asap_bspi= round($val3['avgbspiset1'], 2);  }
	
	if($query2[$key3]['skillscorem']=="") { $clp_mscore= "-"; } else {   $clp_mscore= round($query2[$key3]['skillscorem'], 2);}
	if($query2[$key3]['skillscorev']=="") { $clp_vscore= "-"; } else {   $clp_vscore= round($query2[$key3]['skillscorev'], 2);}
	if($query2[$key3]['skillscoref']=="") { $clp_fscore= "-"; } else {   $clp_fscore= round($query2[$key3]['skillscoref'], 2);}
	if($query2[$key3]['skillscorep']=="") { $clp_pscore= "-"; } else {   $clp_pscore= round($query2[$key3]['skillscorep'], 2);}
	if($query2[$key3]['skillscorel']=="") { $clp_lscore= "-"; } else {   $clp_lscore= round($query2[$key3]['skillscorel'], 2);}
	if($query2[$key3]['avgbspiset1']=="") { $clp_bspi= "-";   } else {   $clp_bspi= round($query2[$key3]['avgbspiset1'], 2); }
	
	if($val3['playcount']==0) {  $status = 'ASAP Pending'; } else if($val3['playcount']<5) { $status = 'ASAP In progress'; } else if($query2[$key3]['playcount']==0) { $status = 'CEP Pending'; } else if($query2[$key3]['playcount']<5) { $status = 'CEP In progress'; } else if($query2[$key3]['playcount']==5) { $status = 'CEP In progress'; }
	
	 fputcsv($file,array($ini,$query2[$key3]['fname'],$query2[$key3]['lname'],$query2[$key3]['username'],$query2[$key3]['mobile'],$query2[$key3]['parentname'],$query2[$key3]['patienttype'],$asap_mscore,$asap_vscore,$asap_fscore,$asap_pscore,$asap_lscore,$asap_bspi,$clp_mscore,$clp_vscore,$clp_fscore,$clp_pscore,$clp_lscore,$clp_bspi,$status));
 }
 
 

    fclose($handle);
	
echo $data['filename'] = $csvfilename; exit;
	}
	
	public function userview()
	{
		if($this->session->adminid=="" || !isset($this->session->adminid)){redirect('index.php');}
		
		$userid = $this->uri->segment(3);
		$data['getusername'] = $this->Dashboard_model->getusername($userid);
		$uname = $data['getusername'][0]['username'];
		/* New Report  */
		$pid =$data['query'][0]['gp_id'];
		$data['Playedgames'] = $this->Dashboard_model->getgamenames($userid,$data['getusername'][0]['gp_id'],$data['getusername'][0]['startdate'],$data['getusername'][0]['enddate']);
		$data['academicmonths'] = $this->Dashboard_model->getacademicmonths($data['getusername'][0]['startdate'],$data['getusername'][0]['enddate']);
		
		$data['IsAsapEnable'] = $this->Dashboard_model->IsAsapEnable($uname);
		$data['IsCLPEnable'] = $this->Dashboard_model->IsCLPEnable($userid);
		
		$data['getasapinfo'] = $this->Dashboard_model->getasapinfo($userid);
		$data['getuserid'] = $this->Dashboard_model->getuserid($uname);
		$data['patienttype'] = $this->Dashboard_model->getpatienttype();
		$startdate = $data['getasapinfo'][0]['startdate'];
		$enddate = $data['getasapinfo'][0]['enddate'];
		$data['academicmonths'] = $this->Dashboard_model->getacademicmonths($startdate,$enddate);
		
		 $asapuserid = $data['getuserid'][0]['id']; 
		
		 $data['asapbspi'] = $this->Dashboard_model->getbspicomparison($asapuserid);
		 $data['clpbspi'] = $this->Dashboard_model->clpbspi($userid);		 
			/*SKILL PERFORMANCE*/
	
$data['skillwiseaverage'] = $this->Dashboard_model->getskillwise_avg($uname);

$data['set1avg_M'] = ($data['skillwiseaverage'][0]['skillscorem']);

$data['set1avg_V'] = ($data['skillwiseaverage'][0]['skillscorev']);

$data['set1avg_F'] = ($data['skillwiseaverage'][0]['skillscoref']);

$data['set1avg_P'] = ($data['skillwiseaverage'][0]['skillscorep']);

$data['set1avg_L'] = ($data['skillwiseaverage'][0]['skillscorel']);
		/*SKILL PERFORMANCE*/
		
		$data['getcounters'] = $this->Dashboard_model->getcounters($userid);
		$data['getcrowny'] = $this->Dashboard_model->getcrowny($userid);
		$data['getattemptsession'] = $this->Dashboard_model->getattemptsession($userid);
		$data['getcompsession'] = $this->Dashboard_model->getcompsession($userid);
		
		/*SKILL PERFORMANCE CLP*/
$data['clp_skillwiseaverage'] = $this->Dashboard_model->get_clp_skillwise_avg($userid);
$data['MonthWiseSkillScore'] = $this->Dashboard_model->getMonthWiseSkillScore($userid,$startdate,$enddate);
$data['CLP_M'] = ($data['clp_skillwiseaverage'][0]['skillscorem']);

$data['CLP_V'] = ($data['clp_skillwiseaverage'][0]['skillscorev']);

$data['CLP_F'] = ($data['clp_skillwiseaverage'][0]['skillscoref']);

$data['CLP_P'] = ($data['clp_skillwiseaverage'][0]['skillscorep']);

$data['CLP_L'] = ($data['clp_skillwiseaverage'][0]['skillscorel']);
		/*SKILL PERFORMANCE CLP*/
		
		/* Efficiency Graph */

$arrofEfficiency=$this->Dashboard_model->getUserEfficiencyGraph($userid,$startdate,$enddate);
foreach($arrofEfficiency as $month)
{
	$userscore[$month['monthNumber'].$month['yearNumber'].'-S']=$month['score'];
	$userresponsetime[$month['monthNumber'].$month['yearNumber'].'-T']=$month['rtime'];
}
$data['Uscore']=$userscore;
$data['Utime']=$userresponsetime;

/* Efficiency Graph */
		
		
		$this->load->view('header');
		$this->load->view('user_view', $data);
		$this->load->view('footer');
	}
	
		public function regionlist()
	{
		if($this->session->adminid=="" || !isset($this->session->adminid)){redirect('index.php');} 
		
		//$totalRec = count($this->Dashboard_model->regionlist('',''));
		$data['totalrecord'] = $this->Dashboard_model->totalrec_regionlist();
        $totalRec = $data['totalrecord'][0]['totalrecord']; 
        
        //pagination configuration
        $config['target']      = '#postList';
        $config['base_url']    = base_url().'index.php/home/regionlist';
        $config['total_rows']  = $totalRec;
        $config['per_page']    = $this->perPage;
        $config['link_func']   = 'searchFilter';
        $this->ajax_pagination->initialize($config);
        
		$data['getzone'] = $this->Dashboard_model->getzone();
        //get the posts data		
		$data['regionlist'] = $this->Dashboard_model->regionlist('',$this->perPage);
		
		$this->load->view('header');
		$this->load->view('region_list', $data);
		$this->load->view('footer');
	}
	
	public function regionlist_csv()
	{
		if($this->session->adminid=="" || !isset($this->session->adminid)){redirect('index.php');} 
		
		$data['regionlist'] = $this->Dashboard_model->regionlist();
		
		$ceationkey = date('YmdHis');
		$csvfilename = "uploads/BMList_".$ceationkey.".csv";
		$file = fopen($csvfilename,"w");
		fputcsv($file,array('S.No.','BM Name','Zone Name','Head Quarter','Designation','Mobile NUmber','Coupons Issued','Coupons Scanned','Coupons Scanned By Doctor','Coupons Registered By Child'));
		
	
		
		$ini=0; 
	foreach($data['regionlist'] as $res){
	$ini++;
	
	if($res['ccount']==0) {  $ccount = 0; } else {  $ccount = $res['ccount']; }
	
	 fputcsv($file,array($ini,$res['personname'],$res['zname'],$res['regionname'],$res['designation'],$res['mobilenumber'],$ccount,$res['rusedcount'],$res['dusedcount'],$res['userused']));
 }
 
 

    fclose($handle);
	
echo $data['filename'] = $csvfilename; exit;
		
	}
	
		public function couponview()
	{
		if($this->session->adminid=="" || !isset($this->session->adminid)){redirect('index.php');} 
		
		$regionid = $this->uri->segment(3);
		$data['regionlist'] = $this->Dashboard_model->regiondetail($regionid);
		$data['coupondetail'] = $this->Dashboard_model->coupondetail($regionid);
		$this->load->view('header');
		$this->load->view('coupondetail', $data);
		$this->load->view('footer');
	}
	
		public function addregion()
	{
		if($this->session->adminid=="" || !isset($this->session->adminid)){redirect('index.php');} 
				
		$data['coupondetail'] = $this->Dashboard_model->coupondetail($regionid);
		$this->load->view('header');
		$this->load->view('add_region', $data);
		$this->load->view('footer');
	}
	
		public function insertregion()
	{
		if($this->session->adminid=="" || !isset($this->session->adminid)){redirect('index.php');} 
				
				//echo '<pre>'; print_r($_POST); exit;
		$data['insertregion'] = $this->Dashboard_model->insertregion($this->input->post('txtrName'),$this->input->post('txtpersname'),$this->input->post('txtMobile'),$this->input->post('txtEmail'),md5($this->input->post('txtOPassword')),$this->input->post('txtstatus'));
		
		 redirect('index.php/home/regionlist');
	}
	
	public function editregion()
	{
		if($this->session->adminid=="" || !isset($this->session->adminid)){redirect('index.php');} 
				
		$regionid = $this->uri->segment(3);	
		$data['editregion'] = $this->Dashboard_model->editregion($regionid);
		
		 $this->load->view('header');
		 $this->load->view('region_edit', $data);
		 $this->load->view('footer');
	}
	
	public function updateregion()
	{
		if($this->session->adminid=="" || !isset($this->session->adminid)){redirect('index.php');} 
				
	//	$editid = $this->post->('hdnid');
		$data['updateregion'] = $this->Dashboard_model->updateregion($this->input->post('txtrName'),$this->input->post('txtpersname'),$this->input->post('txtMobile'),$this->input->post('txtEmail'),$this->input->post('txtstatus'),$this->input->post('hdnid'));
		
		 redirect('index.php/home/regionlist');
	}
	
	public function addcoupon()
	{
		if($this->session->adminid=="" || !isset($this->session->adminid)){redirect('index.php');} 
				
	//	$editid = $this->post->('hdnid');
		//$data['addcoupons'] = $this->Dashboard_model->addcoupons();
		$data['totalcouponissued'] = $this->Dashboard_model->totalcouponissued();	
		$data['getzone'] = $this->Dashboard_model->getzone();
		$data['getcouponhistory'] = $this->Dashboard_model->getcouponhistory();
		
		

	$data['totalcouponissued'] = $this->Dashboard_model->totalcouponissued();
	$data['gettotalcoupon'] = $this->Dashboard_model->gettotalcouponcount();
		
		 $this->load->view('header');
		 $this->load->view('add_coupon_count', $data);
		 $this->load->view('footer');
	}
	
	public function addcoupon_csv()
	{
		if($this->session->adminid=="" || !isset($this->session->adminid)){redirect('index.php');} 
		
		$data['getcouponhistory'] = $this->Dashboard_model->getcouponhistory();
		
		$ceationkey = date('YmdHis');
		$csvfilename = "uploads/CouponIssuedList_".$ceationkey.".csv";
		$file = fopen($csvfilename,"w");
		fputcsv($file,array('S.No.','Zone Name','Head Quarter','Name','Issued Coupon Count','Issued Date'));
		
	
		
		$ini=0; 
	foreach($data['getcouponhistory'] as $res){
	$ini++;
	
	 fputcsv($file,array($ini,$res['zname'],$res['regionname'],$res['personname'],$res['couponcount'],date('d-m-Y',strtotime($res['givendatetime']))));
 }
 
 

    fclose($handle);
	
echo $data['filename'] = $csvfilename; exit;

	}
	
	public function getregion()
	{
		$zoneid = $_POST['zoneid'];
		$data['getregions'] = $this->Dashboard_model->getregion($zoneid);
		
		 $this->load->view('getregion', $data);
	}
	
	
	public function insertcouponcount()
	{
		if($this->session->adminid=="" || !isset($this->session->adminid)){redirect('index.php');} 
				
	       $regionname = $this->input->post('brandmanager');
		   $noofcoupons = $this->input->post('txtnoofcoupons');
		   $issuedate = date('Y-m-d',strtotime($this->input->post('issuedate'))); 
		 $adminid = $this->session->adminid;
		 
		 $data['gettotalcoupon'] = $this->Dashboard_model->gettotalcouponcount();
		 $data['totalcouponissued'] = $this->Dashboard_model->totalcouponissued();
		 
		 $remainingcoupon = $data['gettotalcoupon'][0]['value'] - $data['totalcouponissued'][0]['totalcount'];
		 
		 if($remainingcoupon < $noofcoupons)
		 {
			 //$data['error'] = '';
			 
			 $this->session->set_flashdata('error_message', 'No Sufficient Coupons Available');
			 redirect('index.php/home/addcoupon');
		 }
		 else{
		 
		$data['insertcoupon'] = $this->Dashboard_model->insertcouponcount($regionname,$adminid,$noofcoupons,$issuedate);
	//	$data['getcouponhistory'] = $this->Dashboard_model->getcouponhistory();
		// $this->load->view('couponhistory', $data);
		 redirect('index.php/home/addcoupon');
		 
		 }
	}
	
	public function logout(){
        // Unset User Data
		if($this->session->adminid=="" || !isset($this->session->adminid)){redirect('index.php');} 
		
		$this->Dashboard_model->update_logout_log($this->session->adminid,$this->session->login_session_id);
        $this->session->sess_destroy();
        redirect(base_url());
    }
	public function overallcouponview()
	{
		if($this->session->adminid=="" || !isset($this->session->adminid)){redirect('index.php');} 
		
		$data['coupondetail'] = $this->Dashboard_model->overallcoupondetail();
		$this->load->view('header');
		$this->load->view('overallcoupondetail', $data);
		$this->load->view('footer');
	}
/* ------------------------ Forget Password ---------------------- */
public function resetpwdlink()
{
	$username=$this->input->post('email');
	$Emailexist= $this->Dashboard_model->checkdoctormailidexist($username);
	
	if($Emailexist[0]['emailcount']==1)
	{	$randid=rand(1000000, 9999999);
		$qryinsertLog=$this->Dashboard_model->resetpwdlog($Emailexist[0]['id'],$randid);
		
		$baseurl="http://".$_SERVER['HTTP_HOST'].dirname($_SERVER['PHP_SELF']);
		$subject = 'Edsix BrainLab - Password Reset - Activation Link';

		
		$message = '<table align="center" width="800px" border="1" cellspacing="0" cellpadding="0" style="font-size:medium;margin-right:auto;margin-left:auto;border:1px solid rgb(197,197,197);font-family:Arial,Helvetica,sans-serif;background-image:initial;background-repeat:initial;box-shadow: 10px 10px 5px #35395e;">

		<tbody>
		<tr style="display:block;overflow:hidden;background: #35395e;"><td style="float:left;border:0px;text-align: center;padding: 10px 0px;width:33%;color: #fff;"><img alt="www.skillangels.com" src="'.base_url().'assets/images/Edsix.png" style="float: left;width:220px;"></td><td style="float:left;border:0px;text-align: center;padding: 30px 0px;width: 33%;color: #fff;"> </td><td style="float:left;border:0px;text-align: center;padding: 10px 0px;width: 33%;color: #fff;"> </td></tr>
		<tr style="padding:0px;margin:10px 42px 20px;display:block;font-size:13px;font-family:Verdana,Geneva,sans-serif;line-height:18px;text-align:justify">
		<td colspan="2" style="border:0px">
		Dear '.$Emailexist[0]['fname'].',<br/><br/>
		Please click below link to reset your password.<br/><br/>
		<a href="'.base_url().'/index.php/home/change_password?rid='.md5($randid).'&uid='.md5($Emailexist[0]['id']).'" style="color:green" target="_blank" >Click Here</a><br/><br/>
		All The Very Best!!!<br/><br/>

		Best Regards,<br/>
		<strong>Edsix BrainLab Team</strong><br/>
		</td>
		</tr>
		  
		<tr style="display:block;overflow:hidden">
		<td style="float:left;border:0px;"></td>
		</tr>
		</tbody>
		</table>';
			//echo $message;exit;
			$mail = new PHPMailer;
			$mail->isSMTP();
			$mail->SMTPDebug = 0;
			$mail->Debugoutput = 'html';
			$mail->Host = "smtp.falconide.com";
			$mail->Port = 587;
			$mail->SMTPAuth = true;
			$mail->SMTPSecure = "";
			$mail->Username = "skillsangelsfal";
			$mail->Password = "SkillAngels@123";
			$mail->setFrom('angel@skillangels.com', 'Edsix BrainLab');
			$mail->addReplyTo('angel@skillangels.com', 'Edsix BrainLab');
			$mail->addAddress($Emailexist[0]['email'], ''); //to mail id
			$mail->Subject = $subject;
			$mail->msgHTML($message);
			if (!$mail->send()) {
				//echo "Mailer Error: " . $mail->ErrorInfo;
			} else {
				//echo "Message sent!";
			}
		echo 1;exit;
	}
	else
	{
		echo 0;exit;
	}
}
public function change_password()
{
	$userid=$_REQUEST['uid']; 
	$rid=$_REQUEST['rid'];
	if($userid!='' && $rid!='')
	{ 
		$isvaliduser=$this->Dashboard_model->CheckValidActivationlink($userid,$rid); 
		if($isvaliduser[0]['userid']!='')
		{}else{redirect("index.php");exit;}
		$data['response']=='';
		if(isset($_POST))
		{
			if(isset($_POST['txtOPassword']))
			{
			if($_POST['txtOPassword']==$_POST['txtCPassword'])
			{	
				// Generate two salts (both are numerical)
				$salt1 = mt_rand(1000,9999999999);
				$salt2 = mt_rand(100,999999999);
				// Append our salts to the password
				$salted_pass = $salt1.$_POST['txtOPassword'].$salt2;
				// Generate a salted hash
				$pwdhash = md5($_POST['txtOPassword']);
				
				$arruserdetails=$this->Dashboard_model->getResetpwdDoctorDetails($isvaliduser[0]['userid']);
				//echo "<pre>";print_r($arruserdetails);exit;
				$exepwdupdate=$this->Dashboard_model->UpdateNewPwd($pwdhash,$userid,$salt1,$salt2,$_REQUEST['txtOPassword']);
				$exelogupdate=$this->Dashboard_model->UpdateNewPwd_log($userid,$rid,$_REQUEST['txtOPassword'],$this->input->ip_address());
/*----------- SMS Calling Function -----------------*/
$DOCSMSG="Dear ".$arruserdetails[0]['fname'].", you have successfully reset the password. Username is ".$arruserdetails[0]['username']." and password is ".$_REQUEST['txtOPassword'].". Please visit ".base_url()." ";
//$this->confirmation_sms($arruserdetails[0]['mobile'],$DOCSMSG);
/*----------- SMS Calling Function -----------------*/
				$baseurl="http://".$_SERVER['HTTP_HOST'].dirname($_SERVER['PHP_SELF']);
				$subject = 'Edsix BrainLab - Password Reset - Successful';
$message = '<table align="center" width="800px" border="1" cellspacing="0" cellpadding="0" style="font-size:medium;margin-right:auto;margin-left:auto;border:1px solid rgb(197,197,197);font-family:Arial,Helvetica,sans-serif;background-image:initial;background-repeat:initial;box-shadow: 10px 10px 5px #35395e;"><tbody><tr style="display:block;overflow:hidden;background: #35395e;"><td style="float:left;border:0px;text-align: center;padding: 10px 0px;width:33%;color: #fff;"><img alt="www.skillangels.com" src="'.base_url().'assets/images/Edsix.png" style="float: left;width:220px;"></td><td style="float:left;border:0px;text-align: center;padding: 30px 0px;width: 33%;color: #fff;"> </td> </tr><tr style="padding:0px;margin:10px 42px 20px;display:block;font-size:13px;font-family:Verdana,Geneva,sans-serif;line-height:18px;text-align:justify"><td colspan="2" style="border:0px">Dear '.$arruserdetails[0]['fname'].',<br/><br/>Your password has been reset successfully.<br/><br/> Now, You can login <a href="'.base_url().'" target="_blank" >'.base_url().'</a>  with the following credentials <br/><br/>Your username <strong> : '.$arruserdetails[0]['username'].'</strong><br/>Your password<strong> : '.$_REQUEST['txtOPassword'].'</strong><br/><br/><br/><br/>All The Very Best!!!<br/><br/>Best Regards,<br/><strong>Edsix BrainLab Team</strong><br/></td></tr> <tr style="display:block;overflow:hidden"><td style="float:left;border:0px;"></td></tr></tbody></table>';
			//echo $message;exit;
			//Create a new PHPMailer instance
				$mail = new PHPMailer;
				$mail->isSMTP();
				$mail->SMTPDebug = 0;
				$mail->Debugoutput = 'html';
				$mail->Host = "smtp.falconide.com";
				$mail->Port = 587;
				$mail->SMTPAuth = true;
				$mail->SMTPSecure = "";
				$mail->Username = "skillsangelsfal";
				$mail->Password = "SkillAngels@123";
				$mail->setFrom('angel@skillangels.com', 'Edsix BrainLab');
				$mail->addReplyTo('angel@skillangels.com', 'Edsix BrainLab');
				$mail->addAddress($arruserdetails[0]['email'], ''); //to mail id
				$mail->Subject = $subject;
				$mail->msgHTML($message);
				if (!$mail->send()) {
				   //echo "Mailer Error: " . $mail->ErrorInfo;
				} else {
				   //echo "Message sent!";
				}
					$data['response']='Password changed successfully';
			}
			else
			{
				$data['response']='Password does not match';
			}
			}
		}
		$this->load->view('resetpwd', $data);
	}
	else
	{
		redirect("index.php");  exit;
	}
}
public function confirmation_sms($tonum,$message)
{
	$baseurl="https://".$_SERVER['HTTP_HOST'].dirname($_SERVER['PHP_SELF']);
	$ch = curl_init("http://api-alerts.solutionsinfini.com/v3/?method=sms&api_key=Ac79406bbeca30e25c926bad8928bcc17&to=".$tonum."&sender=SBRAIN&message=".urlencode($message));

	curl_setopt($ch, CURLOPT_HEADER, 0);
	curl_setopt($ch, CURLOPT_POST, 1);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	$response=curl_exec($ch);       
	curl_close($ch);
}
/* ------------------------ Forget Password ---------------------- */
public function couponapproval()
{
	if($this->session->adminid=="" || !isset($this->session->adminid)){redirect('index.php');}
	if($this->session->level!=2) {	
		if($this->input->server('REQUEST_METHOD') == 'POST')
		{
			$Coupondetails = $this->Dashboard_model->getCoupondetails();
			$issuedate = date('Y-m-d',strtotime($this->input->post('issuedate'))); 
			$adminid = $this->session->adminid;
			$noofcoupons = $this->input->post('txtnoofcoupons');
			if($Coupondetails[0]['remainingcoupontoapprove'] < $noofcoupons)
			{
				$this->session->set_flashdata('approve_err_msg', 'Given coupon count is greater than remaining coupon count');
			}
			else
			{
				$data['insertcoupon'] = $this->Dashboard_model->approvecouponcount($adminid,$noofcoupons,$issuedate);
			}
		}
		 $data['Coupondetails'] = $this->Dashboard_model->getCoupondetails();
		 $data['arrapprovedcoupon'] = $this->Dashboard_model->getApprovedCoupondetails($this->session->adminid);
		 $data['edsixgivencoupon'] = $this->Dashboard_model->getEdsixGivencoupon();
		 $this->load->view('header');
		 $this->load->view('couponapproval', $data);
		 $this->load->view('footer');
	}
	else
	{
		redirect('index.php/home/dashboard');
	}
}
/*----------------------------------------------------*/

public function brainskill_report_ajax()
{
	 $userid = $this->input->post('userid');
	 $gameid = $this->input->post('game');
	 $pid = $this->input->post('planid');
	 $startdate = $this->input->post('startdate');
	 $enddate = $this->input->post('enddate');
	$data['gamedetails'] = $this->Dashboard_model->getgamedetails($userid,$gameid,$pid ,$startdate,$enddate); 
	echo $data['json'] = json_encode($data['gamedetails']);	exit;
}
public function ajaxcalendarSkillChart()
{
	$yearMonthQry=$this->input->post('yearMonth');
	$userid =$userid = $this->input->post('userid');
	$startdate = $this->input->post('startdate');
	$enddate = $this->input->post('enddate');
	$bspicalendarskillScore= $this->Dashboard_model->mybspicalendarSkillChart("",$userid,$yearMonthQry,$startdate,$enddate);
	$mybspiCalendarSkillScore=array("SID59"=>0,"SID60"=>0,"SID61"=>0,"SID62"=>0,"SID63"=>0);
	foreach($bspicalendarskillScore as $score)
	{
	$mybspiCalendarSkillScore["SID".$score['gs_id']]=round($score['gamescore'],2);
	}
	$data['bspicalendarskillScore']=$mybspiCalendarSkillScore;
	$data['yearMonthQry']=$yearMonthQry;
	$Yearmonth=explode("-", $yearMonthQry);
	$year=$Yearmonth[0];
	$month= $Yearmonth[1];
	echo json_encode($data['bspicalendarskillScore']);exit;
}
public function ajaxcalendar()
{
$yearMonthQry=$this->input->post('yearMonth');
$userid =$userid = $this->input->post('userid');
$startdate = $this->input->post('startdate');
$enddate = $this->input->post('enddate');

//$data['academicmonths'] = $this->Dashboard_model->getacademicmonths($startdate,$enddate);
//$data['skills'] = $this->Dashboard_model->getskills();
$bspicalendardays= $this->Dashboard_model->mybspicalendar('',$userid,$yearMonthQry,$startdate,$enddate);
$mySkillCalendar= $this->Dashboard_model->mySkillCalendar('',$userid,$yearMonthQry,$startdate,$enddate);
$mybspiCalendar=array();
foreach($bspicalendardays as $days)
{
	$mybspiCalendar[$days['playedDate']]=$days['game_score'];
}
$data['mybspiCalendar']=$mybspiCalendar;
$myskillval=array();

foreach($mySkillCalendar as $days)
{
	$myskillval[$days['playedDate']."-".$days['gs_id']]=$days['game_score'];
}
$data['myskillval']=$myskillval;

	$data['yearMonthQry']=$yearMonthQry;
	$this->load->view('mybrainprofile/ajaxcalendar', $data);
}


}
