<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Subscription extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	  public function __construct()
        {
                // Call the CI_Model constructor
                parent::__construct();
				//$this->lang->load("menu_lang","english");
				$this->load->model('Subscription_model');
				$this->load->library('session');
				$this->load->library('My_PHPMailer');
				$this->load->helper('captcha');
				//$this->lang->load("menu_lang","french");		
			
        }
public function indexnew()
{
	// $aaa=$this->doctor_confirmation_email('sundarcse2k11@gmail.com','Sundar','Sundar','CC');
	// echo "Testing";exit;
}
public function registration()
{
  $data['StateList'] = $this->Subscription_model->getStateList();
  $this->load->view('header');
  $this->load->view('registration', $data);
  $this->load->view('footer');
}
public function doctor()
{
	$data['StateList'] = $this->Subscription_model->getStateList();
	//$data['RegionList'] = $this->Subscription_model->getRegionList();
	$this->load->view('header');
	$this->load->view('doctorregistration', $data);
	$this->load->view('footer');
}
public function getReferrer()
{
	$region=$this->input->post('region');
	$RegionList=$this->Subscription_model->getReferrer($region);
	$option='<option value="">Select</option>';
	foreach($RegionList as $row){
		$option.='<option value="'.$row['id'].'" rel="'.$row['regionname'].'">'.$row['personname'].' - '.$row['regionname'].'</option>';
	}
	echo $option;exit;
}
public function couponajax()
{
	$couponcode=$this->input->post('couponcode');
	$isvalid=$this->Subscription_model->checkIsCouponValid($couponcode);
	if($isvalid[0]['isused']==1)
	{
		$isvalid="IU"; //The couponcode was used
	}
	else if( ($isvalid[0]['isvalidated']==0) && ($isvalid[0]['isvalidated']!=''))
	{
		$isvalid="NV"; //The couponcode was not validated by doctor
	}
	else
	{
		$isvalid=1; //Right Coupon to use 
	}
	echo $isvalid;exit;
}
public function qrcouponmatchajax()
{
	$couponcode=$this->input->post('couponcode');
	$qrcode=$this->input->post('qrcode');
	$ismatched=$this->Subscription_model->checkCouponQRcodematch($couponcode,$qrcode);	
	echo $ismatched[0]['ismatching'];exit;
} 
public function salt_my_pass($password)
{
// Generate two salts (both are numerical)
$salt1 = mt_rand(100,999999999);
$salt2 = mt_rand(100,999999999);

// Append our salts to the password
$salted_pass = $salt1 . $password . $salt2;

// Generate a salted hash
$pwdhash = sha1($salted_pass);

// Place into an array
$hash['Salt1'] = $salt1;
$hash['Salt2'] = $salt2;
$hash['Hash'] = $pwdhash;

// Return the hash and salts to whatever called our function
return $hash;

}
 
public function useradd()
{	//echo "<pre>";print_r($_FILE);exit;echo "<pre>";print_r($_POST);exit;
	$password = $_POST['txtOPassword'];
	$hashpass = $this->salt_my_pass($password);
	 
	$shpassword = $hashpass['Hash']; 
	$salt1 = $hashpass['Salt1']; 
	$salt2 = $hashpass['Salt2']; 
	
	$saltedpass = $salt1 . $shpassword . $salt2; 
	 
	//echo '<pre>'; print_r($_POST); 

	 $firstname = $_POST['txtFName'];
	 $lastname = $_POST['txtLName'];
	 $childname = $_POST['txtFName'].' '.$_POST['txtLName'];
	 $gender = $_POST['rdGender'];
	 $dob = $_POST['txtDOB'];
	 $parentname = $_POST['txtparentname'];
	 $mobile = $_POST['txtMobile'];
	 $email = $_POST['txtCEmail'];
	 $password = $_POST['txtOPassword'];
	 $state = $_POST['ddlState'];
	 $city = $_POST['txtCity'];	 
	 $pincode = $_POST['txtPincode'];
	 $address = $_POST['txtAddress'];
	 $CouponCode = $_POST['txtCouponCode'];
	 $txtqrCode = $_POST['txtqrCode'];	 
	//echo $mobile = $_POST['txtMobile'];exit;
	//$arrofcoupondetails=$this->Subscription_model->getCouponcodeDetails($CouponCode);
	//echo '<pre>'; print_r($arrofcoupondetails);exit;
	
//	$data['insertreg'] = $this->Subscription_model->adduser($firstname,$lastname,$gender,$dob,$parentname,$mobile,$email,$shpassword,$salt1,$salt2,$state,$city,$pincode,$address,$CouponCode,$password,$arrofcoupondetails[0]['hospitalid'],$arrofcoupondetails[0]['doctorid'],$arrofcoupondetails[0]['planid'],$arrofcoupondetails[0]['gradeid'],$arrofcoupondetails[0]['programid']);
//	$lastid = $data['insertreg'];
	//echo "<pre>";print_r($data['insertreg']);exit;
	
	//$this->Subscription_model->UpdateCouponUsedStatus($CouponCode);
	
	$data['insertreg'] = $this->Subscription_model->adduser($firstname,$lastname,$gender,$dob,$parentname,$mobile,$email,$shpassword,$salt1,$salt2,$state,$city,$pincode,$address,$CouponCode,$password);
	
	$data['getprogramid'] = $this->Subscription_model->get_programid($CouponCode);
	
	$program_url="";
	if($data['getprogramid'][0]['programid']==1)
	{
		$program_url= $this->config->item('sa_url');
	}
	else if($data['getprogramid'][0]['programid']==2)
	{
		$program_url= $this->config->item('ba_url');
	}
	else if($data['getprogramid'][0]['programid']==3)
	{
		$program_url= $this->config->item('ka_url');
	}	
	
	//	echo "<pre>";print_r($data['insertreg']);exit;
	
	$arrweek=array();
	for($i=1;$i>=53;$i++)
	{
		$nodays=$Dayslimit-1;
		$wedate = strtotime("+".$nodays." day");		
		$wstardate=date('Y-m-d');
		$wenddate=date('Y-m-d', $wedate);
		
	}

$childrenSub="Registration Success";
$DoctorSub="New Children Registered";
// Email MSG for => Children 
$childrenEMSG='<table align="center" width="800px" border="1" cellspacing="0" cellpadding="0" style="font-size:medium;margin-right:auto;margin-left:auto;border:1px solid rgb(197,197,197);font-family:Arial,Helvetica,sans-serif;background-image:initial;background-repeat:initial;box-shadow: 10px 10px 5px #35395e;"><tbody><tr style="display:block;overflow:hidden;background: #35395e;"><td style="float:left;border:0px;text-align: center;padding: 10px 0px;width:33%;color: #fff;"><img alt="www.skillangels.org" src="'.base_url().'assets/images/home/Edsix.png" style="float: left;width:220px;"></td><td style="float:left;border:0px;text-align: center;padding: 30px 0px;width: 33%;color: #fff;"> </td><td style="float:left;border:0px;text-align: center;padding: 10px 0px;width: 33%;color: #fff;"> </td></tr>
<tr style="padding:0px;margin:10px 42px 20px;display:block;font-size:13px;font-family:Verdana,Geneva,sans-serif;line-height:18px;text-align:justify"><td colspan="2" style="border:0px">Dear '.$childname.',<br/><br/>Thank you for registering with <strong>Edsix BrainLab</strong>.<br/><p><strong>Now !!</strong> you can unwrap the gift for the child to enjoy & learn thinking skills</p><br/><br/>Following are the credentials to access the service at <a href="'.$program_url.'" target="_blank" >'.$program_url.'</a><br/><br/>Your username <strong> : '.$email.'</strong><br/>Your password<strong> : '.$password.'</strong><br/><br/><br/><br/>All The Very Best!!!<br/><br/>Best Regards,<br/><strong>Edsix BrainLab Team</strong><br/></td></tr><tr style=""><td style="text-align:center;color:#ee1b5b;border:0px;background-size:100%;background-image: url('.base_url().'assets/images/emailer/footer.jpg);padding-top:20px;padding-bottom:20px;font-family: cursive;font-size: 20px;"><div style="width:100%;font-family:; float:left;text-align:center"> <br/> </div></td></tr><tr style="display:block;overflow:hidden">
<td style="float:left;border:0px;"></td></tr></tbody></table>';

// Email MSG for => Doctor 
 $doctorEMSG='<table align="center" width="800px" border="1" cellspacing="0" cellpadding="0" style="font-size:medium;margin-right:auto;margin-left:auto;border:1px solid rgb(197,197,197);font-family:Arial,Helvetica,sans-serif;background-image:initial;background-repeat:initial;box-shadow: 10px 10px 5px #35395e;"><tbody><tr style="display:block;overflow:hidden;background: #35395e;"><td style="float:left;border:0px;text-align: center;padding: 10px 0px;width:33%;color: #fff;"><img alt="www.skillangels.org" src="'.base_url().'assets/images/home/Edsix.png" style="float: left;width:220px;"></td><td style="float:left;border:0px;text-align: center;padding: 30px 0px;width: 33%;color: #fff;"> </td><td style="float:left;border:0px;text-align: center;padding: 10px 0px;width: 33%;color: #fff;"> </td></tr>
<tr style="padding:0px;margin:10px 42px 20px;display:block;font-size:13px;font-family:Verdana,Geneva,sans-serif;line-height:18px;text-align:justify"><td colspan="2" style="border:0px">Dear '.$data['getprogramid'][0]['doctorname'].',<br/><br/>New children has been registered with <strong>Edsix BrainLab</strong>.<br/><br/>Please find the details below,<br/><br/>Name of child <strong> : '.$childname.'</strong><br/>Parent / Guardian Name<strong> : '.$parentname.'</strong><br/>Mobile No<strong> : '.$mobile.'</strong><br/>Email ID<strong> : '.$email.'</strong><br/><br/><br/><br/>Best Regards,<br/><strong>Edsix BrainLab Team</strong><br/></td></tr><tr style=""><td style="text-align:center;color:#ee1b5b;border:0px;background-size:100%;background-image: url('.base_url().'assets/images/emailer/footer.jpg);padding-top:20px;padding-bottom:20px;font-family: cursive;font-size: 20px;"><div style="width:100%;font-family:; float:left;text-align:center"> <br/> </div></td></tr><tr style="display:block;overflow:hidden">
<td style="float:left;border:0px;"></td></tr></tbody></table>';

// SMS MSG for => Children 
$childrenSMSG="Dear ".$childname.", you are successfully registered with Edsix BrainLab. Username is ".$email." and password is ".$password.". Please visit ".$program_url." ";
// SMS MSG for => Doctor 
$doctorSMSG="Dear ".$data['getprogramid'][0]['doctorname'].", children ".$childname." has been registered in Edsix BrainLab";
//echo $doctorEMSG;exit;

$this->confirmation_email($email,$childrenSub,$childrenEMSG);//Mail Calling => Children
$this->confirmation_email($data['getprogramid'][0]['email'],$DoctorSub,$doctorEMSG);//Mail Calling => Doctor
//$this->confirmation_sms($mobile,$childrenSMSG);//SMS Calling => Children
//$this->confirmation_sms($data['getprogramid'][0]['mobilenumber'],$doctorSMSG);//SMS Calling => Doctor

	$arrResult=array("response"=>"success");
	echo json_encode($arrResult);exit;
}

public function doctoradd()
{	
	 $firstname =$this->input->post('txtFName'); 
	 $lastname =$this->input->post('txtLName'); 
	 $doctorname = $_POST['txtFName'].' '.$_POST['txtLName'];
	 $gender =$this->input->post('rdGender'); 
	 $dob =$this->input->post('txtDOB'); 
	 $mobile =$this->input->post('txtMobile'); 
	 $smobile =$this->input->post('txtSMobile'); 
	 $email =$this->input->post('txtEmail'); 
	 $semail =$this->input->post('txtSEmail'); 
	 $password = md5($this->input->post('txtOPassword'));
	 $orgpassword =$this->input->post('txtOPassword'); 
	 $state = $this->input->post('ddlState'); 
	 $city =$this->input->post('txtCity'); 	 
	 $hospital =$this->input->post('txthospital'); 
	 $address =$this->input->post('txtAddress'); 
	 $region =3; 
	 $refferedby =107; 
	 
	  $Pan =$this->input->post('txtpan'); 
	 $AccHolderName =$this->input->post('txtahname'); 
	 $AccNo =$this->input->post('txtaccno'); 
	 $IFSCCode =$this->input->post('txtifsccode'); 
	 $BranchName =$this->input->post('txtbranchname');
	 $BankName =$this->input->post('txtbankname');
	
	$data['insertreg'] = $this->Subscription_model->adddoctor($firstname,$lastname,$gender,$dob,$mobile,$smobile,$email,$semail,$password,$state,$city,$hospital,$address,$region,$refferedby,$orgpassword,$Pan,$AccHolderName,$AccNo,$IFSCCode,$BranchName,$BankName);
	$lastid=$data['insertreg'];
	
	$RegionalManager=$this->Subscription_model->getRegionalManager($region);


/* SMS */
  $DOCSMSG="Dear ".$doctorname.", you are successfully registered with Edsix BrainLab. Username is ".$email." and password is ".$orgpassword.". Please visit ".base_url()."doctor ";
  /* echo $DOCSMSG;
echo $mobile;exit; */
/* $REGIONSMSG="Dear ".$RegionalManager[0]['personname'].", doctor ".$firstname." has been registered in VK"; */
$ADMINSMSG="Dear admin, doctor ".$firstname." has been registered in VK"; 
/* SMS 
/* EMAIL */
$DOCSUB='Registration Success';
$REGIONSUB='New Doctor Registered';
$ADMINSUB='New Doctor Registered';

$DOCEMSG='<table align="center" width="800px" border="1" cellspacing="0" cellpadding="0" style="font-size:medium;margin-right:auto;margin-left:auto;border:1px solid rgb(197,197,197);font-family:Arial,Helvetica,sans-serif;background-image:initial;background-repeat:initial;box-shadow: 10px 10px 5px #35395e;"><tbody><tr style="display:block;overflow:hidden;background: #35395e;"><td style="float:left;border:0px;text-align: center;padding: 10px 0px;width:33%;color: #fff;"><img alt="www.skillangels.com" src="'.base_url().'assets/images/home/Edsix.png" style="float: left;width:220px;"></td><td style="float:left;border:0px;text-align: center;padding: 30px 0px;width: 33%;color: #fff;"> </td><td style="float:left;border:0px;text-align: center;padding: 10px 0px;width: 33%;color: #fff;"> </td></tr><tr style="padding:0px;margin:10px 42px 20px;display:block;font-size:13px;font-family:Verdana,Geneva,sans-serif;line-height:18px;text-align:justify"><td colspan="2" style="border:0px">Dear '.$doctorname.',<br/><br/>Thank you for registering with <strong>Edsix BrainLab</strong>.<br/><br/>Following are the credentials to access the service at <a href="'.base_url().'doctor" target="_blank" >'.base_url().'doctor</a><br/><br/>Your username <strong> :'.$email.'</strong><br/>Your password<strong> :'.$orgpassword.'</strong><br/><br/><br/><br/>All The Very Best!!!<br/><br/>Best Regards,<br/><strong>Edsix BrainLab Team</strong><br/></td></tr><tr style=""><td style="text-align:center;color:#ee1b5b;border:0px;background-size:100%;background-image: url('.base_url().'assets/images/emailer/footer.jpg);padding-top:20px;padding-bottom:20px;font-family: cursive;font-size: 20px;"><div style="width:100%;font-family:; float:left;text-align:center"> <br/>
 </div></td></tr><tr style="display:block;overflow:hidden"><td style="float:left;border:0px;"></td></tr></tbody></table>';

$REGIONEMSG='<table align="center" width="800px" border="1" cellspacing="0" cellpadding="0" style="font-size:medium;margin-right:auto;margin-left:auto;border:1px solid rgb(197,197,197);font-family:Arial,Helvetica,sans-serif;background-image:initial;background-repeat:initial;box-shadow: 10px 10px 5px #35395e;"><tbody><tr style="display:block;overflow:hidden;background: #35395e;"><td style="float:left;border:0px;text-align: center;padding: 10px 0px;width:33%;color: #fff;">	<img alt="www.skillangels.com" src="'.base_url().'assets/images/home/Edsix.png" style="float: left;width:220px;"></td><td style="float:left;border:0px;text-align: center;padding: 30px 0px;width: 33%;color: #fff;"> </td><td style="float:left;border:0px;text-align: center;padding: 10px 0px;width: 33%;color: #fff;"> </td></tr><tr style="padding:0px;margin:10px 42px 20px;display:block;font-size:13px;font-family:Verdana,Geneva,sans-serif;line-height:18px;text-align:justify"><td colspan="2" style="border:0px">Dear '.$RegionalManager[0]['personname'].',<br/><br/>	New doctor has been registered with <strong>Edsix BrainLab</strong>.<br/><br/>Please find the details below,<br/><br/>Name of doctor <strong> : '.$doctorname.'</strong><br/>Region<strong> : '.$RegionalManager[0]['regionname'].'</strong><br/>Mobile No<strong> : '.$mobile.'</strong><br/>Email ID<strong> : '.$email.'</strong><br/><br/><br/>Best Regards,<br/><strong>Edsix BrainLab Team</strong><br/></td></tr><tr style=""><td style="text-align:center;color:#ee1b5b;border:0px;background-size:100%;background-image: url('.base_url().'assets/images/emailer/footer.jpg);padding-top:20px;padding-bottom:20px;font-family: cursive;font-size: 20px;"><div style="width:100%;font-family:; float:left;text-align:center"> <br/> </div></td></tr><tr style="display:block;overflow:hidden"><td style="float:left;border:0px;"></td></tr></tbody></table>';

$ADMINEMSG='<table align="center" width="800px" border="1" cellspacing="0" cellpadding="0" style="font-size:medium;margin-right:auto;margin-left:auto;border:1px solid rgb(197,197,197);font-family:Arial,Helvetica,sans-serif;background-image:initial;background-repeat:initial;box-shadow: 10px 10px 5px #35395e;"><tbody><tr style="display:block;overflow:hidden;background: #35395e;"><td style="float:left;border:0px;text-align: center;padding: 10px 0px;width:33%;color: #fff;">	<img alt="www.skillangels.com" src="'.base_url().'assets/images/home/Edsix.png" style="float: left;width:220px;"></td><td style="float:left;border:0px;text-align: center;padding: 30px 0px;width: 33%;color: #fff;"> </td><td style="float:left;border:0px;text-align: center;padding: 10px 0px;width: 33%;color: #fff;"> </td></tr><tr style="padding:0px;margin:10px 42px 20px;display:block;font-size:13px;font-family:Verdana,Geneva,sans-serif;line-height:18px;text-align:justify"><td colspan="2" style="border:0px">Dear  Admin ,<br/><br/>	New doctor has been registered with <strong>Edsix BrainLab</strong>.<br/><br/>Please find the details below,<br/><br/>Name of doctor <strong> : '.$doctorname.'</strong><br/> Mobile No<strong> : '.$mobile.'</strong><br/>Email ID<strong> : '.$email.'</strong><br/><br/><br/>Best Regards,<br/><strong>Edsix BrainLab Team</strong><br/></td></tr><tr style=""><td style="text-align:center;color:#ee1b5b;border:0px;background-size:100%;background-image: url('.base_url().'assets/images/emailer/footer.jpg);padding-top:20px;padding-bottom:20px;font-family: cursive;font-size: 20px;"><div style="width:100%;font-family:; float:left;text-align:center"> <br/> </div></td></tr><tr style="display:block;overflow:hidden"><td style="float:left;border:0px;"></td></tr></tbody></table>';
/* EMAIL */

 // CALLING EMAIL
$this->confirmation_email($email,$DOCSUB,$DOCEMSG);
/*$this->confirmation_sms($mobile,$DOCSMSG); 
$this->confirmation_email($RegionalManager[0]['email'],$REGIONSUB,$REGIONEMSG);*/
$this->confirmation_email('thamaraiselvi@skillangels.com',$ADMINSUB,$ADMINEMSG);
	
// CALLING SMS 
/*$this->confirmation_sms($RegionalManager[0]['mobilenumber'],$REGIONSMSG);
$this->confirmation_sms('8778398026',$ADMINSMSG);*/  
	
$arrResult=array("response"=>"success");
echo json_encode($arrResult);exit;
}
/* public function confirmation_sms($tonum,$message)
{
	$baseurl="https://".$_SERVER['HTTP_HOST'].dirname($_SERVER['PHP_SELF']);
	$ch = curl_init("http://api-alerts.solutionsinfini.com/v3/?method=sms&api_key=Ac79406bbeca30e25c926bad8928bcc17&to=".$tonum."&sender=SBRAIN&message=".urlencode($message));

	curl_setopt($ch, CURLOPT_HEADER, 0);
	curl_setopt($ch, CURLOPT_POST, 1);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	$response=curl_exec($ch);       
	curl_close($ch);
}
public function doctor_confirmation_sms($tonum,$firstname,$username,$org_pwd,$type)
{
	$baseurl=base_url()."doctor";
	if($type=='TO')
	{
		$message="Dear ".$doctorname.", you are successfully registered with Edsix BrainLab. Username is ".$username." and password is ".$org_pwd.". Please visit ".$baseurl." ";
	}
	else
	{
		$message=$firstname."New User registered with Edsix BrainLab";
	}
	$ch = curl_init("http://api-alerts.solutionsinfini.com/v3/?method=sms&api_key=Ac79406bbeca30e25c926bad8928bcc17&to=".$tonum."&sender=SBRAIN&message=".urlencode($message));

	curl_setopt($ch, CURLOPT_HEADER, 0);
	curl_setopt($ch, CURLOPT_POST, 1);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	$response=curl_exec($ch);       
	curl_close($ch);
} */
public function confirmation_email($toemailid,$subject,$message)
{
//echo $message;exit;
//Create a new PHPMailer instance
	$mail = new PHPMailer;
	$mail->isSMTP();
	$mail->SMTPDebug = 0;
	$mail->Debugoutput = 'html';
	$mail->Host = "smtp.falconide.com";
	$mail->Port = 587;
	$mail->SMTPAuth = true;
	$mail->SMTPSecure = "";
	$mail->Username = "skillsangelsfal";
	$mail->Password = "SkillAngels@123";
	$mail->setFrom('angel@skillangels.com', 'EdsixBrainLab');
	$mail->addReplyTo('angel@skillangels.com', 'EdsixBrainLab');
	$mail->addAddress($toemailid, ''); //to mail id
	$mail->Subject = $subject;
	$mail->msgHTML($message);
	if (!$mail->send()) {
	   //echo "Mailer Error: " . $mail->ErrorInfo;
	} else {
	   //echo "Message sent!";
	}  
} 
/* public function doctor_confirmation_email($toemailid,$password,$username,$type)
{
if($type=='TO')
{
$subject = 'Registration Success';
$message = '
<table align="center" width="800px" border="1" cellspacing="0" cellpadding="0" style="font-size:medium;margin-right:auto;margin-left:auto;border:1px solid rgb(197,197,197);font-family:Arial,Helvetica,sans-serif;background-image:initial;background-repeat:initial;box-shadow: 10px 10px 5px #35395e;">
<tbody>
<tr style="display:block;overflow:hidden;background: #35395e;">
	<td style="float:left;border:0px;text-align: center;padding: 10px 0px;width:33%;color: #fff;">
		<img alt="www.skillangels.com" src="'.base_url().'assets/images/home/Edsix.png" style="float: left;width:220px;">
	</td>
	<td style="float:left;border:0px;text-align: center;padding: 30px 0px;width: 33%;color: #fff;">
		<a href="'.base_url().'" target="_blank" style="color: #fff;text-decoration: none;cursor: pointer;font-size: 23px;">www.skillangels.com</a>
	</td>
	<td style="float:left;border:0px;text-align: center;padding: 10px 0px;width: 33%;color: #fff;">
		<img alt="www.skillangels.com" src="'.base_url().'assets/images/home/Bris01.png" style="float: right;width:170px;">
	</td>
	</tr>
<tr style="padding:0px;margin:10px 42px 20px;display:block;font-size:13px;font-family:Verdana,Geneva,sans-serif;line-height:18px;text-align:justify">
<td colspan="2" style="border:0px">
Dear '.$username.',<br/><br/>
Thank you for registering with <strong>VK</strong>.
<br/><br/>
Following are the credentials to access the service at <a href="'.base_url().'" target="_blank" >'.base_url().'</a><br/><br/>
Your username <strong> :'.$toemailid.'</strong><br/>
Your password<strong> :'.$password.'</strong><br/><br/>
<br/><br/>
All The Very Best!!!<br/><br/>
Best Regards,<br/>
<strong>Edsix BrainLab Team</strong><br/>
</td>
</tr>
<tr style="">
<td style="text-align:center;color:#ee1b5b;border:0px;background-size:100%;background-image: url('.base_url().'assets/images/emailer/footer.jpg);padding-top:20px;padding-bottom:20px;font-family: cursive;font-size: 20px;">
<div style="width:100%;font-family:; float:left;text-align:center">
<a href="'.base_url().'" target="_blank" style="color:#ee1b5b;text-decoration: none;" >'.base_url().'</a><br/>
<a href="mailto:support@skillangels.com"  style="color:#ee1b5b;text-decoration: none;" >support@skillangels.com</a>
</div>
</td>
</tr>
<tr style="display:block;overflow:hidden">
<td style="float:left;border:0px;"></td>
</tr>
</tbody>
</table>';
}
else
{
	$subject = 'New Registration';
	$message = '
	<table align="center" width="800px" border="1" cellspacing="0" cellpadding="0" style="font-size:medium;margin-right:auto;margin-left:auto;border:1px solid rgb(197,197,197);font-family:Arial,Helvetica,sans-serif;background-image:initial;background-repeat:initial;box-shadow: 10px 10px 5px #35395e;">
	<tbody>
	<tr style="display:block;overflow:hidden;background: #35395e;">
	<td style="float:left;border:0px;text-align: center;padding: 10px 0px;width:33%;color: #fff;">
		<img alt="www.skillangels.com" src="'.base_url().'assets/images/home/Edsix.png" style="float: left;width:220px;">
	</td>
	<td style="float:left;border:0px;text-align: center;padding: 30px 0px;width: 33%;color: #fff;">
		<a href="'.base_url().'" target="_blank" style="color: #fff;text-decoration: none;cursor: pointer;font-size: 23px;">www.skillangels.com</a>
	</td>
	<td style="float:left;border:0px;text-align: center;padding: 10px 0px;width: 33%;color: #fff;">
		<img alt="www.skillangels.com" src="'.base_url().'assets/images/home/Bris01.png" style="float: right;width:170px;">
	</td>
	</tr>
	<tr style="padding:0px;margin:10px 42px 20px;display:block;font-size:13px;font-family:Verdana,Geneva,sans-serif;line-height:18px;text-align:justify">
	<td colspan="2" style="border:0px">
	Dear '.$username.',<br/><br/>
	New registering with <strong>VK</strong>.<br/><br/><br/>
	Best Regards,<br/>
	<strong>Skillangels Team</strong><br/>
	</td>
	</tr>
	<tr style="">
	<td style="text-align:center;color:#ee1b5b;border:0px;background-size:100%;background-image: url('.base_url().'assets/images/emailer/footer.jpg);padding-top:20px;padding-bottom:20px;font-family: cursive;font-size: 20px;">
	<div style="width:100%;font-family:; float:left;text-align:center">
	<a href="'.base_url().'" target="_blank" style="color:#ee1b5b;text-decoration: none;" >'.base_url().'</a><br/>
	<a href="mailto:support@skillangels.com"  style="color:#ee1b5b;text-decoration: none;" >support@skillangels.com</a>
	</div>
	</td>
	</tr>
	<tr style="display:block;overflow:hidden">
	<td style="float:left;border:0px;">
	</td>
	</tr>
	</tbody>
	</table>';
}
//echo $message;exit;
//Create a new PHPMailer instance
	$mail = new PHPMailer;
	$mail->isSMTP();
	$mail->SMTPDebug = 0;
	$mail->Debugoutput = 'html';
	$mail->Host = "smtp.falconide.com";
	$mail->Port = 587;
	$mail->SMTPAuth = true;
	$mail->SMTPSecure = "";
	$mail->Username = "skillsangelsfal";
	$mail->Password = "SkillAngels@123";
	$mail->setFrom('angel@skillangels.com', 'VK');
	$mail->addReplyTo('angel@skillangels.com', 'VK');
	$mail->addAddress($toemailid, ''); //to mail id
	$mail->Subject = $subject;
	$mail->msgHTML($message);
	if (!$mail->send()) {
	   //echo "Mailer Error: " . $mail->ErrorInfo;
	} else {
	   //echo "Message sent!";
	}  
} */
public function checkemailexist()
{
 $emailid = $_POST['emailid'];
 
 $data['checkemail'] = $this->Subscription_model->checkemailexist($emailid);
 echo $data['checkemail'][0]['emailcount'];
}
public function checkdoctoremailexist()
{
 $emailid = $_POST['emailid'];
 
 $data['checkemail'] = $this->Subscription_model->checkdoctoremailexist($emailid);
 echo $data['checkemail'][0]['emailcount'];
}
public function profileimage()
{
	if ( 0 < $_FILES['file']['error'] ) {
        echo 'Error: ' . $_FILES['file']['error'] . '<br>';
    }
    else {
        move_uploaded_file($_FILES['file']['tmp_name'], 'upload/' . $_FILES['file']['name']);
    }
	/* basename( $_POST['imagename'] );
	$filename = str_replace( "\\", '/', $_POST['imagename'] );
	$imagename = basename( $filename ); 
	$uploaddir = 'upload/';
	$sourcePath = $_POST['imagename'];  
	echo $targetPath = $uploaddir .$imagename; 
	move_uploaded_file($sourcePath, $targetPath);  */
} 
public function termsconditions()
{
$this->load->view('header');
$this->load->view('termsconditions');
$this->load->view('footer');
}
	
public function termsofservice()
{
$this->load->view('header');
$this->load->view('footerpages/termsofservice');
$this->load->view('footer');
}
	
public function privacypolicy()
{
$this->load->view('header');
$this->load->view('footerpages/privacypolicy');
$this->load->view('footer');
}
	
public function faq()
{
$this->load->view('header');
$this->load->view('footerpages/faq');
$this->load->view('footer');
}
/*----------------------- Forget Password ------------------ */
public function UserForgetPwdConfirmation()
{
	$username=$_POST['username'];
	$Emailexist= $this->Subscription_model->checkuseremailexist($username);
	
	if($Emailexist[0]['emailcount']==1)
	{	$randid=rand(1000000, 9999999);
		$qryinsertLog=$this->Subscription_model->forgetpwdlog($Emailexist[0]['id'],$randid);
		
		$baseurl="http://".$_SERVER['HTTP_HOST'].dirname($_SERVER['PHP_SELF']);
		$subject = 'VK - Password Reset - Activation Link';

		
		$message = '<table align="center" width="800px" border="1" cellspacing="0" cellpadding="0" style="font-size:medium;margin-right:auto;margin-left:auto;border:1px solid rgb(197,197,197);font-family:Arial,Helvetica,sans-serif;background-image:initial;background-repeat:initial;box-shadow: 10px 10px 5px #35395e;">

		<tbody>
		<tr style="display:block;overflow:hidden;background: #35395e;"><td style="float:left;border:0px;text-align: center;padding: 10px 0px;width:33%;color: #fff;"><img alt="www.skillangels.com" src="'.base_url().'assets/images/home/Edsix.png" style="float: left;width:220px;"></td><td style="float:left;border:0px;text-align: center;padding: 30px 0px;width: 33%;color: #fff;"> </td><td style="float:left;border:0px;text-align: center;padding: 10px 0px;width: 33%;color: #fff;"> </td></tr>
		<tr style="padding:0px;margin:10px 42px 20px;display:block;font-size:13px;font-family:Verdana,Geneva,sans-serif;line-height:18px;text-align:justify">
		<td colspan="2" style="border:0px">
		Dear '.$Emailexist[0]['fname'].',<br/><br/>
		Please click below link to reset your password.<br/><br/>
		<a href="'.base_url().'index.php/Subscription/change_password?rid='.md5($randid).'&uid='.md5($Emailexist[0]['id']).'" style="color:green" target="_blank" >Click Here</a><br/><br/>
		All The Very Best!!!<br/><br/>

		Best Regards,<br/>
		<strong>Edsix BrainLab Team</strong><br/>
		</td>
		</tr>
		<tr style="">
		<td style="text-align:center;color:#ee1b5b;border:0px;background-size:100%;background-image: url('.base_url().'assets/images/emailer/footer.jpg);padding-top:20px;padding-bottom:20px;font-family: cursive;font-size: 20px;">
		<div style="width:100%;font-family:; float:left;text-align:center">
		 
		</div>
		</td>

		</tr>
		<tr style="display:block;overflow:hidden">
		<td style="float:left;border:0px;"></td>
		</tr>
		</tbody>
		</table>';
			//echo $message;exit;
			$mail = new PHPMailer;
			$mail->isSMTP();
			$mail->SMTPDebug = 0;
			$mail->Debugoutput = 'html';
			$mail->Host = "smtp.falconide.com";
			$mail->Port = 587;
			$mail->SMTPAuth = true;
			$mail->SMTPSecure = "";
			$mail->Username = "skillsangelsfal";
			$mail->Password = "SkillAngels@123";
			$mail->setFrom('angel@skillangels.com', 'VK');
			$mail->addReplyTo('angel@skillangels.com', 'VK');
			$mail->addAddress($Emailexist[0]['email'], ''); //to mail id
			$mail->Subject = $subject;
			$mail->msgHTML($message);
			if (!$mail->send()) {
				//echo "Mailer Error: " . $mail->ErrorInfo;
			} else {
				//echo "Message sent!";
			}
		echo 1;exit;
	}
	else
	{
		echo 0;exit;
	}
}
public function change_password()
{
	$userid=$_REQUEST['uid']; 
	$rid=$_REQUEST['rid'];
	if($userid!='' && $rid!='')
	{ 
		$isvaliduser=$this->Subscription_model->CheckIsValidUser($userid,$rid); 
		if($isvaliduser[0]['userid']!='')
		{}else{redirect("index.php");exit;}
	
		if(isset($_POST))
		{
			if(isset($_POST['txtOPassword']))
			{
			if($_POST['txtOPassword']==$_POST['txtCPassword'])
			{	
				// Generate two salts (both are numerical)
				$salt1 = mt_rand(1000,9999999999);
				$salt2 = mt_rand(100,999999999);
				// Append our salts to the password
				$salted_pass = $salt1.$_POST['txtOPassword'].$salt2;
				// Generate a salted hash
				$pwdhash = sha1($salted_pass);
				
				$arruserdetails=$this->Subscription_model->getResetpwdUserDetails($isvaliduser[0]['userid']);
				//echo "<pre>";print_r($arruserdetails);exit;
				$exepwdupdate=$this->Subscription_model->ResetUserPwd($pwdhash,$userid,$salt1,$salt2,$_REQUEST['txtOPassword'],$arruserdetails[0]['username']);
				$exelogupdate=$this->Subscription_model->ResetUserPwd_log($userid,$rid,$_REQUEST['txtOPassword']);
$USERMSG="Dear ".$arruserdetails[0]['fname'].", you have successfully reset the password. Username is ".$arruserdetails[0]['username']." and password is ".$_REQUEST['txtOPassword'].". Please visit ".base_url()." ";
//$this->confirmation_sms($arruserdetails[0]['mobile'],$USERMSG);

				$baseurl="http://".$_SERVER['HTTP_HOST'].dirname($_SERVER['PHP_SELF']);
				$subject = 'VK - Password Reset - Successful';
				$message = '
				<table align="center" width="800px" border="1" cellspacing="0" cellpadding="0" style="font-size:medium;margin-right:auto;margin-left:auto;border:1px solid rgb(197,197,197);font-family:Arial,Helvetica,sans-serif;background-image:initial;background-repeat:initial;box-shadow: 10px 10px 5px #35395e;">
				<tbody>
				<tr style="display:block;overflow:hidden;background: #35395e;"><td style="float:left;border:0px;text-align: center;padding: 10px 0px;width:33%;color: #fff;"><img alt="www.skillangels.com" src="'.base_url().'assets/images/home/Edsix.png" style="float: left;width:220px;"></td><td style="float:left;border:0px;text-align: center;padding: 30px 0px;width: 33%;color: #fff;"> </td><td style="float:left;border:0px;text-align: center;padding: 10px 0px;width: 33%;color: #fff;"> </td></tr>
				<tr style="padding:0px;margin:10px 42px 20px;display:block;font-size:13px;font-family:Verdana,Geneva,sans-serif;line-height:18px;text-align:justify">
				<td colspan="2" style="border:0px">
				Dear '.$arruserdetails[0]['fname'].',<br/><br/>
				Your password has been reset successfully.<br/><br/> Now, You can login <a href="'.base_url().'" target="_blank" >'.base_url().'</a>  with the following credentials <br/><br/>
				Your username <strong> : '.$arruserdetails[0]['email'].'</strong><br/>
				Your password<strong> : '.$_REQUEST['txtOPassword'].'</strong><br/><br/>
				<br/>
				All The Very Best!!!<br/><br/>
				Best Regards,<br/>
				<strong>Edsix BrainLab Team</strong><br/>
				</td>
				</tr>
				<tr style="">
				<td style="text-align:center;color:#ee1b5b;border:0px;background-size:100%;background-image: url('.base_url().'assets/images/emailer/footer.jpg);padding-top:20px;padding-bottom:20px;font-family: cursive;font-size: 20px;">
				<div style="width:100%;font-family:; float:left;text-align:center">
				 <br/>
				 
				</div>
				</td>
				</tr>
				<tr style="display:block;overflow:hidden">
				<td style="float:left;border:0px;">
				</td>
				</tr>
				</tbody>
				</table>';
				//echo $message;exit;
			//Create a new PHPMailer instance
				$mail = new PHPMailer;
				$mail->isSMTP();
				$mail->SMTPDebug = 0;
				$mail->Debugoutput = 'html';
				$mail->Host = "smtp.falconide.com";
				$mail->Port = 587;
				$mail->SMTPAuth = true;
				$mail->SMTPSecure = "";
				$mail->Username = "skillsangelsfal";
				$mail->Password = "SkillAngels@123";
				$mail->setFrom('angel@skillangels.com', 'VK');
				$mail->addReplyTo('angel@skillangels.com', 'VK');
				$mail->addAddress($arruserdetails[0]['email'], ''); //to mail id
				$mail->Subject = $subject;
				$mail->msgHTML($message);
				if (!$mail->send()) {
					//echo "Mailer Error: " . $mail->ErrorInfo;
				} else {
					//echo "Message sent!";
				}
				$data['response']='Password Changed successfully';
			}
			else
			{
				$data['response']='Password does not match';
			}
			}
		}
		$this->load->view('header');
		$this->load->view('change_password', $data);
		$this->load->view('footer');
	}
	else
	{
		redirect("index.php");  exit;
	}
}

public function getIFSCcodeBasedBankdetails()
{
	$IFSCCode=$this->input->post('IFSCCode');
	
	$ch = curl_init("http://api.techm.co.in/api/v1/ifsc/".$IFSCCode);

	curl_setopt($ch, CURLOPT_HEADER, 0);
	curl_setopt($ch, CURLOPT_POST, 0);
	curl_setopt($ch, CURLOPT_HTTPGET, 1);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	$response=curl_exec($ch);       
	curl_close($ch);
	//echo "<pre>";print_r($response);exit;
	$resarr=json_decode($response,true );
	//echo "<pre>";print_r($resarr);exit;
	
	/* $res=array(
		"status"=>$resarr['status'],
		"BANK"=>$resarr['data']['BANK'],
		"BRANCH"=>$resarr['data']['BRANCH'],
		"IFSC"=>$resarr['data']['IFSC']
	); */
	echo $response;
}

 
}
