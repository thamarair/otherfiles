<footer>
<div class="container" id="footerpart">
<div class="row">
<div class="col-md-3 col-sm-6">

  
  <ul>
<li>EDSIX BRAINLAB<sup>TM</sup> PRIVATE LTD</li>
<li>Module #1, 3rd Floor, A Block,</li>
<li>Phase 2, IITM Research Park,</li>
<li>Kanagam Road, Taramani, Chennai - 600113</li>
  </ul>
  <?php //echo $this->lang->line("footeraddress"); ?> 
  </div>
<div class="col-md-3 col-sm-6">
<ul>
<li class="callicon"><?php echo $this->lang->line("ftphonenumber"); ?>, +91 95695 65454</li>
<li class="msgicon"><a href="mailto:angel@skillangels.com"><?php echo $this->lang->line("ftemail"); ?></a></li>
</ul>
<div class="socialmedia">
<span><?php echo $this->lang->line("ftjoin"); ?></span>
<a href="https://www.facebook.com/skillangels" target="_blank"><img src="<?php echo base_url(); ?>assets/images/fb.png" width="33" height="33"></a> <a href="https://www.linkedin.com/company/edsix-brain-lab-pvt-ltd?trk=company_logo" target="_blank"><img src="<?php echo base_url(); ?>assets/images/icon_LinkedIn.png" width="33" height="33"></a>
</div>

</div>
<div class="col-md-3 col-sm-6">
<ul>
<li><a href="<?php echo base_url(); ?>index.php"><?php echo $this->lang->line("fthome"); ?></a></li>
<li><a href="<?php echo base_url(); ?>index.php/home/termsofservice" target="_blank"><?php echo $this->lang->line("ftterms"); ?></a></li>
<li><a href="<?php echo base_url(); ?>index.php/home/privacypolicy" target="_blank"><?php echo $this->lang->line("ftprivacy"); ?></a></li>
<li><a href="<?php echo base_url(); ?>index.php/home/faq" target="_blank"><?php echo $this->lang->line("ftfaq"); ?></a></li>
</ul>
</div>
<div class="col-md-3 col-sm-6">

  <img src="<?php echo base_url(); ?>assets/images/home/Edsix-white.png" class="img-responsive"  width="170">
  <br/>
  <!--<img src="<?php echo base_url(); ?>assets/images/home/Bris01.png" class="img-responsive"  width="170">-->
   <!--<br/>
<img src="<?php echo base_url(); ?>assets/images/logo_RTBI.png"  > <img src="<?php echo base_url(); ?>assets/images/logo_CJE.png"  >--></div>
</div>
</div>

</footer>

<div class="footerBottom"><p>&copy; <?php echo date("Y"); ?> Edsix BrainLab. All rights reserved</p></div>

<script type="text/javascript">
  $(document).ready(function(e) { 
   $('.count').each(function () {
    $(this).prop('Counter',0).animate({
        Counter: $(this).text()
    }, {
        duration: 6000,
        easing: 'swing',
        step: function (now) {
            $(this).text(Math.ceil(now));
        }
    });
});
	/* $(".loginmodal-container .close").click(function(){
		//$("#primary-menu").trigger('click');
		//$(".loginLink").attr('style','background: #f92c8b !important;');
	}); */
});
</script>

<script>
/* ****************************** User Login *********************************** */	
$('#submit').click(function(){ 
var form=$("#form-login");
$(".loader").show();
/* Avoid Multiple Login */	
$.ajax({
type:"POST",
url:"<?php echo base_url('index.php/home/islogin') ?>",
data:form.serialize(),
success:function(isloginval)
{ //alert(isloginval);
	if(isloginval==0){
		if(($('#termscondition').is(':checked')) )
		{	
			//userlogin(form);
			isUser(form);
		}
		else
		{
			isUser(form);
			//termscheck(form);
		}
	}
	else
	{
			swal({
			  title: 'Are you sure?',
			  text: "You are logging into another system.would you like to continue.",
			  type: 'warning',
			  showCancelButton: true,
			  confirmButtonColor: '#3085d6',
			  cancelButtonColor: '#d33',
			  confirmButtonText: 'Yes, continue!',
			  cancelButtonText: 'No, cancel!',
			  confirmButtonClass: 'btn btn-success',
			  cancelButtonClass: 'btn btn-danger',
			  allowOutsideClick: false,
			  allowEscapeKey : false,
			  buttonsStyling: false
			}).then(function () {
					if(($('#termscondition').is(':checked')) )
					{
						//userlogin(form);
						userlogin(form);
					}
					else
					{
						termscheck(form);
					}
			  
			}, function (dismiss) {
			  if (dismiss === 'cancel') {
				swal(
				  'Cancelled',
				  'You are continuing with your previous login :)',
				  'error'
				);
				$(".loader").hide();
			  }
			});
		
	}
}
});
});	

function userlogin(form)
{	
		$.ajax({
				type:"POST",
				url:"<?php echo base_url('index.php/home/userlogin') ?>",
				data:form.serialize(),
				success:function(result)
				{ 
					if(result=='O')
					{
						window.location.href= "<?php echo base_url();?>index.php/home/dashboard#View";
					}
					else if(result=='N')
					{
						window.location.href= "<?php echo base_url();?>index.php/homenew/dashboard";
					}
					else
					{	$(".loader").hide();
						$("#errormsg").html('Invalid Credentials');
					}
				}
		}); 
	
}
function ASAPuserlogin(form)
{	
		$.ajax({
				type:"POST",
				url:"<?php echo base_url('assessments/index.php/home/userlogin') ?>",
				data:form.serialize(),
				success:function(result)
				{ 
					if(result==1)
					{
						window.location.href= "<?php echo base_url();?>assessments/index.php/mypuzzleset1/dashboard#View";
					}
					else
					{	$(".loader").hide();
						$("#errormsg").html('Invalid Credentials');
					}
				}
		}); 
	
}
function isUser(form)
{ 
		$.ajax({
				type:"POST",
				url:"<?php echo base_url('index.php/home/isUser') ?>",
				data:form.serialize(),
				dataType: "json",
				success:function(result)
				{ 
					//alert(result); console.log(result);alert(result.portal_type); return false;
					if(result.portal_type=='ASAP')
					{	
						ASAPuserlogin(form);
					}
					else
					{
						userlogin(form);
					}
				}
		}); 
	
}
function termscheck(form)
{
		$.ajax({
				type:"POST",
				url:"<?php echo base_url('index.php/home/termscheck') ?>",
				data:form.serialize(),
				success:function(result)
				{
				//alert(result);
					if(result==0  && $.trim(result)!='')
					{	$(".loader").hide();
						$("#termschkbox").show();
						$("#terrormsg").html('Please check terms and conditions');
						
					}

					else
					{
						//userlogin(form);
						isUser(form);
					}

				}
		});
}
</script>
<script>
// When the user scrolls down 20px from the top of the document, show the button
window.onscroll = function() {scrollFunction()};

function scrollFunction() {
    if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
        document.getElementById("myBtn").style.display = "block";
    } else {
        document.getElementById("myBtn").style.display = "none";
    }
}

// When the user clicks on the button, scroll to the top of the document
function topFunction() {
    $("html,body").animate({scrollTop:$("#header").offset().top},"100");return false;
}

/* $(window).load(function(){        
$('#myModal').modal('show');
});  */


</script>
<!-- BEGIN JIVOSITE CODE {literal} 
<script type='text/javascript'>
(function(){ var widget_id = 'zpFxCq3EPJ';var d=document;var w=window;function l(){
var s = document.createElement('script'); s.type = 'text/javascript'; s.async = true; s.src = '//code.jivosite.com/script/widget/'+widget_id; var ss = document.getElementsByTagName('script')[0]; ss.parentNode.insertBefore(s, ss);}if(d.readyState=='complete'){l();}else{if(w.attachEvent){w.attachEvent('onload',l);}else{w.addEventListener('load',l,false);}}})();</script>
<!-- {/literal} END JIVOSITE CODE -->

<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-113126967-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-113126967-1');
</script>


</body>
</html>