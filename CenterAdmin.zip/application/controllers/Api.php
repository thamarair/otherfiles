<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Api extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	  public function __construct()
        {
                // Call the CI_Model constructor
                parent::__construct();
				//$this->lang->load("menu_lang","english");
				$this->load->model('Api_model');
			  
				//$this->lang->load("menu_lang","french");		
			
        }
		
	public function index()
	{			
		$this->load->view('header');
		$this->load->view('index');
		$this->load->view('footer');
		
	}
	
	public function checklogin()
	{

		$username = $this->input->post('username');
		$password = $this->input->post('password');
	//	echo $username; exit;
		$data['query'] = $this->Api_model->checklogin($username,$password);
		
		if(isset($data['query'][0]->id))
			{
				echo $data['query'][0]->id.','.$data['query'][0]->doctorname;
			}
			else {
				
				echo 'FAIL';
			}
		
	}
	
public function checkqrcode()
{

	$doctorid = $this->input->post('doctorid');
	$qrcode   = $this->input->post('qrcode');
	//echo $qrcode; exit;
	//echo $doctorid; 
	$data['query'] = $this->Api_model->checkqrcode($qrcode);
	
	$data['getdoctorname'] = $this->Api_model->getdoctorname($doctorid);
	
	$doctorname = $data['getdoctorname'][0]['doctorname'];
		
	if(!isset($data['query'][0]['qrcode']) || $data['query'][0]['qrcode']!=$qrcode)
	{
		echo 'INVALID QR CODE';
	}
	else if($data['query'][0]['qrcode']==$qrcode && $data['query'][0]['region_usedstatus']=="N" )
	{
	
		echo 'QR CODE IS NOT VERIFIED BY REGIONAL MANAGER';
	}
	else if($data['query'][0]['qrcode']==$qrcode && $data['query'][0]['status']==1 )
	{
	
		echo 'QR CODE ALREADY USED';
	}
	else if($data['query'][0]['qrcode']==$qrcode && $data['query'][0]['status']==0 )
	{
		$data['activateeqrcode'] = $this->Api_model->activateqrcode($doctorid,$qrcode);
		
		$RegionalManager=$this->Api_model->getRegionalManager($qrcode);
		
		$ADMINMSG="Dear Blissfulangels admin, QR Code ".$qrcode." has been activated by the doctor ".$doctorname." ";
		
		$REGIONMSG="Dear ".$RegionalManager[0]['personname'].", QR Code ".$qrcode." has been activated by the doctor ".$doctorname." ";
		
		$this->sendsms('8807541983',$ADMINMSG);
		$this->sendsms($RegionalManager[0]['mobilenumber'],$REGIONMSG);
		echo 'QR CODE SCANNED SUCCESSFULLY';
	}
}
public function sendsms($tonum,$message)
{
	$ch = curl_init("http://api-alerts.solutionsinfini.com/v3/?method=sms&api_key=Ac79406bbeca30e25c926bad8928bcc17&to=".$tonum."&sender=SBRAIN&message=".urlencode($message));
	curl_setopt($ch, CURLOPT_HEADER, 0);
	curl_setopt($ch, CURLOPT_POST, 1);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	$response=curl_exec($ch);       
	curl_close($ch);
}
/*	public function testsms()
	{
		$message="Dear Admin, Test SMS";

	$ch = curl_init("http://api-alerts.solutionsinfini.com/v3/?method=sms&api_key=Ac79406bbeca30e25c926bad8928bcc17&to=9884584861,8807541983&sender=SBRAIN&message=".urlencode($message));

	curl_setopt($ch, CURLOPT_HEADER, 0);
	curl_setopt($ch, CURLOPT_POST, 1);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	$response=curl_exec($ch);       
	curl_close($ch);
		
	} */
	
	public function qrlist()
	{

		$doctorid = $this->input->post('doctorid');
		if($doctorid!='')
		{
		$data['query'] = $this->Api_model->getQRList($doctorid);
		$rData='';
		 foreach($data['query'] as $qlist)
		 {
			$rData.=$qlist['ldata']."," ;
		 }
		 echo rtrim($rData,',');
		}
	}
	
	
	
	
}