<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	  public function __construct()
        {
                // Call the CI_Model constructor
                parent::__construct();
				$this->load->model('Dashboard_model');
				$this->load->library('session');
				$this->load->library('My_PHPMailer');
				$this->load->library('Ajax_pagination');
				$this->perPage = 12;
        }
		
	public function index()
	{			
		//$this->load->view('header');
		$this->load->view('index');
		//$this->load->view('footer');
		
	}
	
	public function logincheck()
	{	

	
			$data['query'] = $this->Dashboard_model->checklogin($this->input->post('username'),md5($this->input->post('password')));
		//	echo $data['query'][0]['school_id']; exit;
			if(isset($data['query'][0]['id'])){ 
			
			$uniqueId = $data['query'][0]['id']."".date("YmdHis")."".round(microtime(true) * 1000);
			
			$this->session->set_userdata(array(
			
			'centername'       => $data['query'][0]['centername'],
		//	'lastname'       => $data['query'][0]['lastname'],
			'centerid'       => $data['query'][0]['id'],
		//	'hospitalid'       => $data['query'][0]['hospitalid'],
			'login_session_id'=>$uniqueId, 
			'school_id'       => 2,
			'game_grade'  => 11,
			
			));
			
			if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
			$ip=$_SERVER['HTTP_CLIENT_IP'];}
			elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
			$ip=$_SERVER['HTTP_X_FORWARDED_FOR'];} else {
			$ip=$_SERVER['REMOTE_ADDR'];}		
			$this->Dashboard_model->insert_login_log($data['query'][0]['id'],$uniqueId,$ip,$this->input->post('txcountry'),$this->input->post('txregion'),$this->input->post('txcity'),$this->input->post('txisp'),$_SERVER['HTTP_USER_AGENT'],1);
			
			redirect('index.php/home/userslist');
			}
			else {
				$data['error'] = 'Invalid Crendentials';
				$this->load->view('index', $data);
			}
	}
	
	public function checkuserisactive()
	{
		if($this->session->centerid=="" || !isset($this->session->centerid)){redirect('index.php');}
		
			$this->Dashboard_model->update_login_log($this->session->centerid,$this->session->login_session_id);
	}
	
	public function dashboard()
	{
		if($this->session->centerid=="" || !isset($this->session->centerid)){redirect('index.php');}
		
		$centerid = $this->session->centerid;
		$data['userscount'] = $this->Dashboard_model->userscount($centerid);
		//$data['couponcount'] = $this->Dashboard_model->couponcodecount($doctorid);
		//$data['doctorinfo'] = $this->Dashboard_model->doctorinfo($doctorid);
		$this->load->view('header', $data);
		$this->load->view('home', $data);
		$this->load->view('footer');
	}
	
	public function couponcounts()
	{
		if($this->session->doctorid=="" || !isset($this->session->doctorid)){redirect('index.php');}
		
		$doctorid = $this->session->doctorid;
		
		
		$data['scanstatus'] = $this->Dashboard_model->scanstatus($doctorid); 
	    $data['scanstatus'][0]['scancount'];
		
		echo $data['scanstatus'][0]['scancount']; exit;
	 	
	}
	
	public function userslist()
	{
		if($this->session->centerid=="" || !isset($this->session->centerid)){redirect('index.php');} 
		
		$data['totalrecord'] = $this->Dashboard_model->totalrec_userlist();
        $totalRec = $data['totalrecord'][0]['totalrecord'];  
        
        //pagination configuration
        $config['target']      = '#postList';
        $config['base_url']    = base_url().'index.php/home/userlist_PaginationData';
        $config['total_rows']  = $totalRec;
        $config['per_page']    = $this->perPage;
        $config['link_func']   = 'searchFilter';
        $this->ajax_pagination->initialize($config);
        
        //get the posts data
        $data['userslist'] = $this->Dashboard_model->userslist('',$this->perPage);
		
		//$data['userslist'] = $this->Dashboard_model->userslist();
		$this->load->view('header');
		$this->load->view('users_list', $data);
		$this->load->view('footer');
	}
	
	public function userlist_PaginationData()
	{
		$conditions = array();
        
        //calc offset number
        $page = $this->input->post('page');
        if(!$page){
            $offset = 0;
        }else{
            $offset = $page;
        }        
        //total rows count		
		$data['totalrecord'] = $this->Dashboard_model->totalrec_userlist();
        $totalRec = $data['totalrecord'][0]['totalrecord']; 
        
        //pagination configuration
        $config['target']      = '#postList';
        $config['base_url']    = base_url().'index.php/home/userlist_PaginationData';
        $config['total_rows']  = $totalRec;
        $config['per_page']    = $this->perPage;
        $config['link_func']   = 'searchFilter';
        $this->ajax_pagination->initialize($config);
        
        //set start and limit
        $conditions['start'] = $offset-$this->perPage;
        $conditions['limit'] = $this->perPage;
        
        //get posts data
        $data['userslist'] = $this->Dashboard_model->userslist($offset,$this->perPage);
        
        //load the view
        $this->load->view('users_list_ajax.php', $data, false);
	}
	
	public function doctoredit()
	{
		if($this->session->doctorid=="" || !isset($this->session->doctorid)){redirect('index.php');}
		//$editid = $this->uri->segment(3);
		$doctorid = $this->session->doctorid;
		$data['getstate'] = $this->Dashboard_model->getstate();
	//	$data['gethospital'] = $this->Dashboard_model->gethospital();
		$data['editdoctor'] = $this->Dashboard_model->editdoctor($doctorid);
		 
		$this->load->view('header');
		$this->load->view('doctor_edit', $data);
		$this->load->view('footer');
		
	} 
	
	
	public function doctorupdate()
	{
		if($this->session->doctorid=="" || !isset($this->session->doctorid)){redirect('index.php');}
		
		//echo '<pre>'; print_r($_FILES);
		if(isset($_FILES["file"]["type"]))
{
	//echo 'yes'; exit;
$validextensions = array("jpeg", "jpg", "png");
$temporary = explode(".", $_FILES["file"]["name"]);
$file_extension = end($temporary);
 $size = getimagesize($files);
$maxWidth = 150;
$maxHeight = 150;
if ((($_FILES["file"]["type"] == "image/png") || ($_FILES["file"]["type"] == "image/jpg") || ($_FILES["file"]["type"] == "image/jpeg")
) && in_array($file_extension, $validextensions)) {

$sourcePath = $_FILES['file']['tmp_name']; // Storing source path of the file in a variable
$targetPath = "assets/images/doctor/".$_FILES['file']['name']; // Target path where file is to be stored
//$output_dir = frontendurl()."assets/images/doctor/".$_FILES['file']['name'];
move_uploaded_file($sourcePath,$targetPath) ; 

}
}

//echo $targetPath; exit;

		
		$doctorid = $this->session->doctorid;
		
		 $data['addhospital'] = $this->Dashboard_model->updatedoctor($this->input->post('txtFName'),$this->input->post('txtLName'),$this->input->post('rdGender'),$this->input->post('txtDOB'),$this->input->post('txtEmail'),$this->input->post('txtSEmail'),$this->input->post('txtMobile'),$this->input->post('txtSMobile'),$this->input->post('ddlState'),$this->input->post('txtCity'),$this->input->post('txtAddress'),$doctorid,$targetPath,$this->input->post('txthospitalname'));
		 
		 redirect('index.php/home/dashboard');
		
	}
	
	public function couponlist()
	{
		if($this->session->doctorid=="" || !isset($this->session->doctorid)){redirect('index.php');} 
		$doctorid = $this->session->doctorid;
		$data['couponlist'] = $this->Dashboard_model->couponlist($doctorid);
		$this->load->view('header');
		$this->load->view('couponlist', $data);
		$this->load->view('footer');
	}
	
	public function userview()
	{
		if($this->session->centerid=="" || !isset($this->session->centerid)){redirect('index.php');}
		
		$userid = $this->uri->segment(3);
		$data['getusername'] = $this->Dashboard_model->getusername($userid);
		$uname = $data['getusername'][0]['username'];
		
		/* New Report  */
		$pid =$data['query'][0]['gp_id'];
		$data['Playedgames'] = $this->Dashboard_model->getgamenames($userid,$data['getusername'][0]['gp_id'],$data['getusername'][0]['startdate'],$data['getusername'][0]['enddate']);
		$data['academicmonths'] = $this->Dashboard_model->getacademicmonths($data['getusername'][0]['startdate'],$data['getusername'][0]['enddate']);
		
		$data['IsAsapEnable'] = $this->Dashboard_model->IsAsapEnable($uname);
		$data['IsCLPEnable'] = $this->Dashboard_model->IsCLPEnable($userid);
		
		
		
		$data['getasapinfo'] = $this->Dashboard_model->getasapinfo($userid);
		$data['getuserid'] = $this->Dashboard_model->getuserid($uname);
		//$data['patienttype'] = $this->Dashboard_model->getpatienttype();
		$startdate = $data['getasapinfo'][0]['startdate'];
		$enddate = $data['getasapinfo'][0]['enddate'];
		$data['academicmonths'] = $this->Dashboard_model->getacademicmonths($startdate,$enddate);
		
		 $asapuserid = $data['getuserid'][0]['id']; 
		
		 $data['asapbspi'] = $this->Dashboard_model->getbspicomparison($asapuserid);
		 $data['clpbspi'] = $this->Dashboard_model->clpbspi($userid);		 
			/*SKILL PERFORMANCE*/
	
$data['skillwiseaverage'] = $this->Dashboard_model->getskillwise_avg($uname);

$data['set1avg_M'] = ($data['skillwiseaverage'][0]['skillscorem']);

$data['set1avg_V'] = ($data['skillwiseaverage'][0]['skillscorev']);

$data['set1avg_F'] = ($data['skillwiseaverage'][0]['skillscoref']);

$data['set1avg_P'] = ($data['skillwiseaverage'][0]['skillscorep']);

$data['set1avg_L'] = ($data['skillwiseaverage'][0]['skillscorel']);
		/*SKILL PERFORMANCE*/
		
		$data['getcounters'] = $this->Dashboard_model->getcounters($userid);
		$data['getcrowny'] = $this->Dashboard_model->getcrowny($userid);
		$data['getattemptsession'] = $this->Dashboard_model->getattemptsession($userid);
		$data['getcompsession'] = $this->Dashboard_model->getcompsession($userid);
		
		/*SKILL PERFORMANCE CLP*/
$data['clp_skillwiseaverage'] = $this->Dashboard_model->get_clp_skillwise_avg($userid);
$data['MonthWiseSkillScore'] = $this->Dashboard_model->getMonthWiseSkillScore($userid,$startdate,$enddate);
$data['CLP_M'] = ($data['clp_skillwiseaverage'][0]['skillscorem']);

$data['CLP_V'] = ($data['clp_skillwiseaverage'][0]['skillscorev']);

$data['CLP_F'] = ($data['clp_skillwiseaverage'][0]['skillscoref']);

$data['CLP_P'] = ($data['clp_skillwiseaverage'][0]['skillscorep']);

$data['CLP_L'] = ($data['clp_skillwiseaverage'][0]['skillscorel']);
		/*SKILL PERFORMANCE CLP*/
		
		/* Efficiency Graph */

$arrofEfficiency=$this->Dashboard_model->getUserEfficiencyGraph($userid,$startdate,$enddate);
foreach($arrofEfficiency as $month)
{
	$userscore[$month['monthNumber'].$month['yearNumber'].'-S']=$month['score'];
	$userresponsetime[$month['monthNumber'].$month['yearNumber'].'-T']=$month['rtime'];
}
$data['Uscore']=$userscore;
$data['Utime']=$userresponsetime;

/* Efficiency Graph */
		
		
		$this->load->view('header');
		$this->load->view('user_view', $data);
		$this->load->view('footer');
	}
	
public function ajaxcalendar()
{
$yearMonthQry=$this->input->post('yearMonth');
$userid =$userid = $this->input->post('userid');
$startdate = $this->input->post('startdate');
$enddate = $this->input->post('enddate');

//$data['academicmonths'] = $this->Dashboard_model->getacademicmonths($startdate,$enddate);
//$data['skills'] = $this->Dashboard_model->getskills();
$bspicalendardays= $this->Dashboard_model->mybspicalendar('',$userid,$yearMonthQry,$startdate,$enddate);
$mySkillCalendar= $this->Dashboard_model->mySkillCalendar('',$userid,$yearMonthQry,$startdate,$enddate);
$mybspiCalendar=array();
foreach($bspicalendardays as $days)
{
	$mybspiCalendar[$days['playedDate']]=$days['game_score'];
}
$data['mybspiCalendar']=$mybspiCalendar;
$myskillval=array();
foreach($mySkillCalendar as $days)
{
	$myskillval[$days['playedDate']."-".$days['gs_id']]=$days['game_score'];
}
$data['myskillval']=$myskillval;

	$data['yearMonthQry']=$yearMonthQry;
	$this->load->view('mybrainprofile/ajaxcalendar', $data);
}

public function brainskill_report_ajax()
{
	 $userid = $this->input->post('userid');
	 $gameid = $this->input->post('game');
	 $pid = $this->input->post('planid');
	 $startdate = $this->input->post('startdate');
	 $enddate = $this->input->post('enddate');
	$data['gamedetails'] = $this->Dashboard_model->getgamedetails($userid,$gameid,$pid ,$startdate,$enddate); 
	echo $data['json'] = json_encode($data['gamedetails']);	exit;
}
	
	public function update_patienttype()
	{
		$data['updatepatienttype'] = $this->Dashboard_model->updatepatienttype($_POST['userid'],$_POST['typeid']);
		echo 1; exit;
	}
	
	public function userperformance()
	{
		$centerid = $this->session->centerid;
		$data['asap_reports'] = $this->Dashboard_model->asap_reports($centerid);
		$data['clp_reports'] = $this->Dashboard_model->clp_reports($centerid);
		
		$this->load->view('header');
		$this->load->view('patient_performance', $data);
		$this->load->view('footer');
	}
	
	public function patientperformance_downloadcsv()
	{
		
		$centerid = $this->session->centerid;
		$data['asap_reports'] = $this->Dashboard_model->asap_reports($centerid);
		$data['clp_reports'] = $this->Dashboard_model->clp_reports($centerid);
		
		$ceationkey = date('YmdHis');
		$csvfilename = "uploads/Userlist_".$ceationkey.".csv";
		$file = fopen($csvfilename,"w");
		fputcsv($file,array('S.No.','Firstname','Lastname','Username','Father Name','Grade','ASAP - M','ASAP - VP','ASAP - FA','ASAP - P','ASAP - L','ASAP - BSPI','CLP - M','CLP - VP','CLP - FA','CLP - P','CLP - L','CLP - BSPI','Program Status','Created Date'));
		
		foreach($data['asap_reports'] as $key1=>$val1) {
			
			$query1[$data['asap_reports'][$key1]['username']] =  $val1;
	
		}		
		foreach($data['clp_reports'] as $key2=>$val2) {
			
			$query2[$data['clp_reports'][$key2]['username']] =  $val2;

		}
		
		$ini=0; 
	foreach($query1 as $key3=>$val3){
	$ini++;
	
	if($val3['skillscorem']=="") { $asap_mscore= "-"; } else {   $asap_mscore= round($val3['skillscorem'], 2);  }
	if($val3['skillscorev']=="") { $asap_vscore= "-"; } else {   $asap_vscore= round($val3['skillscorev'], 2);  }
	if($val3['skillscoref']=="") { $asap_fscore= "-"; } else {   $asap_fscore= round($val3['skillscoref'], 2);  }
	if($val3['skillscorep']=="") { $asap_pscore= "-"; } else {   $asap_pscore= round($val3['skillscorep'], 2);  }
	if($val3['skillscorel']=="") { $asap_lscore= "-"; } else {   $asap_lscore= round($val3['skillscorel'], 2);  }
	if($val3['avgbspiset1']=="") { $asap_bspi= "-";   } else {     $asap_bspi= round($val3['avgbspiset1'], 2);  }
	
	if($query2[$key3]['skillscorem']=="") { $clp_mscore= "-"; } else {   $clp_mscore= round($query2[$key3]['skillscorem'], 2);}
	if($query2[$key3]['skillscorev']=="") { $clp_vscore= "-"; } else {   $clp_vscore= round($query2[$key3]['skillscorev'], 2);}
	if($query2[$key3]['skillscoref']=="") { $clp_fscore= "-"; } else {   $clp_fscore= round($query2[$key3]['skillscoref'], 2);}
	if($query2[$key3]['skillscorep']=="") { $clp_pscore= "-"; } else {   $clp_pscore= round($query2[$key3]['skillscorep'], 2);}
	if($query2[$key3]['skillscorel']=="") { $clp_lscore= "-"; } else {   $clp_lscore= round($query2[$key3]['skillscorel'], 2);}
	if($query2[$key3]['avgbspiset1']=="") { $clp_bspi= "-";   } else {   $clp_bspi= round($query2[$key3]['avgbspiset1'], 2); }
	
	if($val3['playcount']==0) {  $status = 'ASAP Pending'; } else if($val3['playcount']<5) { $status = 'ASAP In progress'; } else if($query2[$key3]['playcount']==0) { $status = 'CLP Pending'; } else if($query2[$key3]['playcount']<5) { $status = 'CLP In progress'; } else if($query2[$key3]['playcount']==5) { $status = 'CLP In progress'; }
	
	 fputcsv($file,array($ini,$query2[$key3]['fname'],$query2[$key3]['lname'],$query2[$key3]['username'],$query2[$key3]['father'],str_replace("Grade","", $query2[$key3]['grade']),$asap_mscore,$asap_vscore,$asap_fscore,$asap_pscore,$asap_lscore,$asap_bspi,$clp_mscore,$clp_vscore,$clp_fscore,$clp_pscore,$clp_lscore,$clp_bspi,$status,date('d-m-Y',strtotime($query2[$key3]['creation_date']))));
 }
 
 

    fclose($handle);
	
echo $data['filename'] = $csvfilename; exit; 
		
	}
	
	
	public function logout(){
        // Unset User Data
		if($this->session->centerid=="" || !isset($this->session->centerid)){redirect('index.php');}
		
		$this->Dashboard_model->update_logout_log($this->session->centerid,$this->session->login_session_id);
		
        $this->session->sess_destroy();
        redirect(base_url());
    }
public function couponscanned()
{
	if($this->session->doctorid=="" || !isset($this->session->doctorid)){redirect('index.php');}
     $data['query'] = $this->Dashboard_model->getScannedCoupon($this->session->doctorid);
	 $this->load->view('header', $data);
		$this->load->view('couponscanned', $data);
		$this->load->view('footer'); 
}
public function resetpwdlink()
{
	$username=$this->input->post('email');
	$Emailexist= $this->Dashboard_model->checkdoctormailidexist($username);
	
	if($Emailexist[0]['emailcount']==1)
	{	$randid=rand(1000000, 9999999);
		$qryinsertLog=$this->Dashboard_model->resetpwdlog($Emailexist[0]['id'],$randid);
		
		$baseurl="http://".$_SERVER['HTTP_HOST'].dirname($_SERVER['PHP_SELF']);
		$subject = 'Blissfulangels - Password Reset - Activation Link';

		
		$message = '<table align="center" width="800px" border="1" cellspacing="0" cellpadding="0" style="font-size:medium;margin-right:auto;margin-left:auto;border:1px solid rgb(197,197,197);font-family:Arial,Helvetica,sans-serif;background-image:initial;background-repeat:initial;box-shadow: 10px 10px 5px #35395e;">

		<tbody>
		<tr style="display:block;overflow:hidden;background: #35395e;"><td style="float:left;border:0px;text-align: center;padding: 10px 0px;width:33%;color: #fff;"><img alt="www.blissfulangels.org" src="'.base_url().'assets/images/Edsix.png" style="float: left;width:220px;"></td><td style="float:left;border:0px;text-align: center;padding: 30px 0px;width: 33%;color: #fff;"><a href="'.base_url().'" target="_blank" style="color: #fff;text-decoration: none;cursor: pointer;font-size: 23px;">www.blissfulangels.org</a></td><td style="float:left;border:0px;text-align: center;padding: 10px 0px;width: 33%;color: #fff;"><img alt="www.blissfulangels.org" src="'.base_url().'assets/images/Bris01.png" style="float: right;width:170px;"></td></tr>
		<tr style="padding:0px;margin:10px 42px 20px;display:block;font-size:13px;font-family:Verdana,Geneva,sans-serif;line-height:18px;text-align:justify">
		<td colspan="2" style="border:0px">
		Dear '.$Emailexist[0]['doctorname'].',<br/><br/>
		Please click below link to reset your password.<br/><br/>
		<a href="'.base_url().'/index.php/home/change_password?rid='.md5($randid).'&uid='.md5($Emailexist[0]['id']).'" style="color:green" target="_blank" >Click Here</a><br/><br/>
		All The Very Best!!!<br/><br/>

		Best Regards,<br/>
		<strong>Blissfulangels Team</strong><br/>
		</td>
		</tr>
		<tr style="">
		<td style="text-align:center;color:#ee1b5b;border:0px;background-size:100%;background-image: url('.base_url().'assets/images/emailer/footer.jpg);padding-top:20px;padding-bottom:20px;font-family: cursive;font-size: 20px;">
		<div style="width:100%;font-family:; float:left;text-align:center">
		<a href="'.base_url().'" target="_blank" style="color:#ee1b5b;text-decoration: none;" >'.base_url().'</a><br/>
		<a href="mailto:support@Blissfulangels.com"  style="color:#ee1b5b;text-decoration: none;" >support@Blissfulangels.com</a>
		</div>
		</td>

		</tr>
		<tr style="display:block;overflow:hidden">
		<td style="float:left;border:0px;"></td>
		</tr>
		</tbody>
		</table>';
			//echo $message;exit;
			$mail = new PHPMailer;
			$mail->isSMTP();
			$mail->SMTPDebug = 0;
			$mail->Debugoutput = 'html';
			$mail->Host = "smtp.falconide.com";
			$mail->Port = 587;
			$mail->SMTPAuth = true;
			$mail->SMTPSecure = "";
			$mail->Username = "skillsangelsfal";
			$mail->Password = "SkillAngels@123";
			$mail->setFrom('angel@skillangels.com', 'Blissfulangels');
			$mail->addReplyTo('angel@skillangels.com', 'Blissfulangels');
			$mail->addAddress($Emailexist[0]['email'], ''); //to mail id
			$mail->Subject = $subject;
			$mail->msgHTML($message);
			if (!$mail->send()) {
				//echo "Mailer Error: " . $mail->ErrorInfo;
			} else {
				//echo "Message sent!";
			}
		echo 1;exit;
	}
	else
	{
		echo 0;exit;
	}
}
public function change_password()
{
	$userid=$_REQUEST['uid']; 
	$rid=$_REQUEST['rid'];
	if($userid!='' && $rid!='')
	{ 
		$isvaliduser=$this->Dashboard_model->CheckValidActivationlink($userid,$rid); 
		if($isvaliduser[0]['userid']!='')
		{}else{redirect("index.php");exit;}
		$data['response']=='';
		if(isset($_POST))
		{
			if(isset($_POST['txtOPassword']))
			{
			if($_POST['txtOPassword']==$_POST['txtCPassword'])
			{	
				// Generate two salts (both are numerical)
				$salt1 = mt_rand(1000,9999999999);
				$salt2 = mt_rand(100,999999999);
				// Append our salts to the password
				$salted_pass = $salt1.$_POST['txtOPassword'].$salt2;
				// Generate a salted hash
				$pwdhash = md5($_POST['txtOPassword']);
				
				$arruserdetails=$this->Dashboard_model->getResetpwdDoctorDetails($isvaliduser[0]['userid']);
				//echo "<pre>";print_r($arruserdetails);exit;
				$exepwdupdate=$this->Dashboard_model->UpdateNewPwd($pwdhash,$userid,$salt1,$salt2,$_REQUEST['txtOPassword']);
				$exelogupdate=$this->Dashboard_model->UpdateNewPwd_log($userid,$rid,$_REQUEST['txtOPassword'],$this->input->ip_address());
				
$DOCSMSG="Dear ".$arruserdetails[0]['doctorname'].", you have successfully reset the password. Username is ".$arruserdetails[0]['username']." and password is ".$_REQUEST['txtOPassword'].". Please visit ".base_url()." ";
$this->confirmation_sms($arruserdetails[0]['mobilenumber'],$DOCSMSG);

				$baseurl="http://".$_SERVER['HTTP_HOST'].dirname($_SERVER['PHP_SELF']);
				$subject = 'Blissfulangels - Password Reset - Successful';
$message = '<table align="center" width="800px" border="1" cellspacing="0" cellpadding="0" style="font-size:medium;margin-right:auto;margin-left:auto;border:1px solid rgb(197,197,197);font-family:Arial,Helvetica,sans-serif;background-image:initial;background-repeat:initial;box-shadow: 10px 10px 5px #35395e;"><tbody><tr style="display:block;overflow:hidden;background: #35395e;"><td style="float:left;border:0px;text-align: center;padding: 10px 0px;width:33%;color: #fff;"><img alt="www.blissfulangels.org" src="'.base_url().'assets/images/Edsix.png" style="float: left;width:220px;"></td><td style="float:left;border:0px;text-align: center;padding: 30px 0px;width: 33%;color: #fff;"><a href="'.base_url().'" target="_blank" style="color: #fff;text-decoration: none;cursor: pointer;font-size: 23px;">www.blissfulangels.org</a></td><td style="float:left;border:0px;text-align: center;padding: 10px 0px;width: 33%;color: #fff;"><img alt="www.blissfulangels.org" src="'.base_url().'assets/images/Bris01.png" style="float: right;width:170px;"></td></tr><tr style="padding:0px;margin:10px 42px 20px;display:block;font-size:13px;font-family:Verdana,Geneva,sans-serif;line-height:18px;text-align:justify"><td colspan="2" style="border:0px">Dear '.$arruserdetails[0]['doctorname'].',<br/><br/>Your password has been reset successfully.<br/><br/> Now, You can login <a href="'.base_url().'" target="_blank" >'.base_url().'</a>  with the following credentials <br/><br/>Your username <strong> : '.$arruserdetails[0]['username'].'</strong><br/>Your password<strong> : '.$_REQUEST['txtOPassword'].'</strong><br/><br/><br/><br/>All The Very Best!!!<br/><br/>Best Regards,<br/><strong>Blissfulangels Team</strong><br/></td></tr><tr style=""><td style="text-align:center;color:#ee1b5b;border:0px;background-size:100%;background-image: url('.base_url().'assets/images/emailer/footer.jpg);padding-top:20px;padding-bottom:20px;font-family: cursive;font-size: 20px;"><div style="width:100%;font-family:; float:left;text-align:center"><a href="'.base_url().'" target="_blank" style="color:#ee1b5b;text-decoration: none;" >'.base_url().'</a><br/><a href="mailto:support@Blissfulangels.com"  style="color:#ee1b5b;text-decoration: none;" >support@Blissfulangels.com</a></div></td></tr><tr style="display:block;overflow:hidden"><td style="float:left;border:0px;"></td></tr></tbody></table>';
			//echo $message;exit;
			//Create a new PHPMailer instance
				$mail = new PHPMailer;
				$mail->isSMTP();
				$mail->SMTPDebug = 0;
				$mail->Debugoutput = 'html';
				$mail->Host = "smtp.falconide.com";
				$mail->Port = 587;
				$mail->SMTPAuth = true;
				$mail->SMTPSecure = "";
				$mail->Username = "skillsangelsfal";
				$mail->Password = "SkillAngels@123";
				$mail->setFrom('angel@skillangels.com', 'Blissfulangels');
				$mail->addReplyTo('angel@skillangels.com', 'Blissfulangels');
				$mail->addAddress($arruserdetails[0]['email'], ''); //to mail id
				$mail->Subject = $subject;
				$mail->msgHTML($message);
				if (!$mail->send()) {
				   //echo "Mailer Error: " . $mail->ErrorInfo;
				} else {
				   //echo "Message sent!";
				}
					$data['response']='Password Changed successfully';
			}
			else
			{
				$data['response']='Password does not match';
			}
			}
		}
		$this->load->view('resetpwd', $data);
	}
	else
	{
		redirect("index.php");  exit;
	}
}
public function confirmation_sms($tonum,$message)
{
	$baseurl="https://".$_SERVER['HTTP_HOST'].dirname($_SERVER['PHP_SELF']);
	$ch = curl_init("http://api-alerts.solutionsinfini.com/v3/?method=sms&api_key=Ac79406bbeca30e25c926bad8928bcc17&to=".$tonum."&sender=SBRAIN&message=".urlencode($message));

	curl_setopt($ch, CURLOPT_HEADER, 0);
	curl_setopt($ch, CURLOPT_POST, 1);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	$response=curl_exec($ch);       
	curl_close($ch);
}
}
