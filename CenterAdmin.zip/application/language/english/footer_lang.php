<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$lang['footeraddress'] = "Edsix Brain Lab Private LTD.<br/># 1 H, Module no. 8,<br/>IIT Madras Research Park First Floor,<br/>Kanagam Road ,Taramani Chennai - 113";

$lang['ftjoin'] = "Join Us";
$lang['ftphonenumber'] = "044-66469877";
$lang['ftemail'] = "angel@skillangels.com";
$lang['fthome'] = "Home";
$lang['ftterms'] = "Terms Of Service";
$lang['ftprivacy'] = "Privacy Policy";
$lang['ftfaq'] = "FAQ";
$lang['fttitle'] = "EdSix Brain Lab Pvt Ltd";
$lang['allrights'] = "2017 Skillangels. All rights reserved";

 

?>
