<?php
defined('BASEPATH') OR exit('No direct script access allowed');


$lang['mydailyplanner'] = 'My Daily Planner';
$lang['playeveryday'] = 'Play every day to get badge';
$lang['myskillpie'] = 'My Skill Pie for the Day';

$lang['todayplayed'] = 'Today';
$lang['missedday'] = 'Missed the bus';
$lang['braintrained'] = 'Brain trained';



?>
