<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$lang['welcome_message'] = 'Bienvenue à CodexWorld';
?>
