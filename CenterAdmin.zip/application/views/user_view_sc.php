<style>
@media (min-width:1025px) {.counter {width: 16%;}}
@media (min-width:1281px) {.counter {width: 16%;}}
.counter {background:#1b7590; padding: 9px; margin: 2px; color:white;  }
.counterinnertxt { font-size: 15px; font-weight: bold; color: cornsilk;}
.nice-select{color:#fff}.box1{float:right;}.month{padding-bottom:20px;}
.nice-select option {
    cursor: pointer;
	background-color: #f0cd3a;
    color: #fff;
    font-weight: 300;
    border-bottom: 1px solid;
    line-height: 40px;
    list-style: none;
    min-height: 40px;
    outline: none;
    padding-left: 18px;
    padding-right: 29px;
    text-align: left;
    -webkit-transition: all 0.2s;
    transition: all 0.2s;
    font-size: 16px !important;
}


.reportChartContainer1 {
    padding: 20px;
    overflow: hidden;
}
.cb {
    clear: both;
}
.skillName {
    float: left;
    width: 34.5%;
    display: inline-block;
    padding: 10px 0 11px 0;
    border-right: 1px solid #000;
    margin-bottom: 0;    color: #000;
	font-size:16px;
}
div.meter {
    float: left;
    width: 65%;
    height: 25px;
    border: 1px solid #b0b0b0;
    -webkit-box-shadow: inset 0 3px 5px 0 #d3d0d0;
    -moz-box-shadow: inset 0 3px 5px 0 #d3d0d0;
    box-shadow: inset 0 3px 5px 0 #d3d0d0;
    -webkit-border-radius: 3px;
    -moz-border-radius: 3px;
    -ms-border-radius: 3px;
    -o-border-radius: 3px;
    border-radius: 3px;
}
.mt10 {
    margin-top: 9px;
}
div.meter span {
    color: #fff;
    top: 0;
    line-height: 0px;
    padding-left: 7px;
    font-weight: bold;
    text-align: right;
    padding-right: 5px;
    display: block;
    height: 100%;
    animation: grower 1s linear;
    -moz-animation: grower 1s linear;
    -webkit-animation: grower 1s linear;
    -o-animation: grower 1s linear;
    position: relative;
    left: -1px;
    -webkit-border-radius: 3px;
    -moz-border-radius: 3px;
    -ms-border-radius: 3px;
    -o-border-radius: 3px;
    border-radius: 3px;
    -webkit-box-shadow: inset 0px 3px 5px 0px rgba(0, 0, 0, 0.2);
    -moz-box-shadow: inset 0px 3px 5px 0px rgba(0, 0, 0, 0.2);
    box-shadow: inset 0px 3px 5px 0px rgba(0, 0, 0, 0.2);
    background-image: -webkit-gradient(linear, 0 0, 100% 100%, color-stop(0.25, rgba(255, 255, 255, 0.2)), color-stop(0.25, transparent), color-stop(0.5, transparent), color-stop(0.5, rgba(255, 255, 255, 0.2)), color-stop(0.75, rgba(255, 255, 255, 0.2)), color-stop(0.75, transparent), to(transparent));
    background-image: -webkit-linear-gradient(45deg, rgba(255, 255, 255, 0.2) 25%, transparent 25%, transparent 50%, rgba(255, 255, 255, 0.2) 50%, rgba(255, 255, 255, 0.2) 75%, transparent 75%, transparent);
    background-image: -moz-linear-gradient(45deg, rgba(255, 255, 255, 0.2) 25%, transparent 25%, transparent 50%, rgba(255, 255, 255, 0.2) 50%, rgba(255, 255, 255, 0.2) 75%, transparent 75%, transparent);
    background-image: -ms-linear-gradient(45deg, rgba(255, 255, 255, 0.2) 25%, transparent 25%, transparent 50%, rgba(255, 255, 255, 0.2) 50%, rgba(255, 255, 255, 0.2) 75%, transparent 75%, transparent);
    background-image: -o-linear-gradient(45deg, rgba(255, 255, 255, 0.2) 25%, transparent 25%, transparent 50%, rgba(255, 255, 255, 0.2) 50%, rgba(255, 255, 255, 0.2) 75%, transparent 75%, transparent);
    -webkit-background-size: 45px 45px;
    -moz-background-size: 45px 45px;
    -o-background-size: 45px 45px;
    background-size: 45px 45px;
}
.redColor {
    background: #e81919;
}
.yellowColor {
    background: #ffa300;
    margin-bottom: 10px;
}
.greenColor {
    background: #8bcc46;
    margin-bottom: 10px;
}
.orangeColor {
    background: #f16202;
    margin-bottom: 10px;
}
.blueColor {
    background: #0ab7f6;
    margin-bottom: 10px;
}
div.meter span:before {
    content: '';
    display: block;
    width: 100%;
    height: 50%;
    position: relative;
    top: 50%;
    background: rgba(0, 0, 0, 0.03);
}
</style>
<?php 
$date = DateTime::createFromFormat("Y-m-d", $getuserinfo_sc[0]['startdate']);
$date1 = $getuserinfo_sc[0]['startdate'];
$date2 = $getuserinfo_sc[0]['enddate'];
$ts1 = strtotime($date1);
$ts2 = strtotime($date2);
$year1 = date('Y', $ts1);
$year2 = date('Y', $ts2);
$month1 = date('m', $ts1);
$month2 = date('m', $ts2);
?>
<input type="hidden" name="userid" id="userid" value="<?php echo $getuserinfo_sc[0]['id']; ?>" />
<input type="hidden" name="startdate" id="startdate" value="<?php echo $getuserinfo_sc[0]['startdate']; ?>" />
<input type="hidden" name="enddate" id="enddate" value="<?php echo $getuserinfo_sc[0]['enddate']; ?>" />
<div class="right_col" role="main">
          <div class="">
           
            
            <div class="clearfix"></div>

            <div class="row">
              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                  <div class="x_title">
				  <h2><span style="background:aqua; padding:5px; border-radius:45px; color:#000;">Product - Summer Camp</span> - User Report</h2>
                  <a href="<?php echo  base_url(); ?>index.php/home/userperformance" class="btn btn-success" id="downloadcsv" style="float: right;margin-bottom: 10px;" ><i class="fa fa-chevron-left"></i> Back</a>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
				  </div></div>
				  
				  <div class="row">
                    <div class="col-md-12 col-sm-12 col-xs-12 col-lg-3  profile_left">
                     <div class="row profile_content" style="">
                      <h3><?php echo $getuserinfo_sc[0]['fname']; ?></h3>

                      <ul class="list-unstyled user_data">
					  <li>
					  <?php if($getuserinfo_sc[0]['gender']=='M') {  ?>
					  <i class="fa fa-male"></i> Male
					<?php   } ?>
					<?php if($getuserinfo_sc[0]['gender']=='F') {  ?>
					  <i class="fa fa-female"></i> Female
					<?php   } ?>
					  </li>
			
				<li><i class="fa fa-graduation-cap"></i> Grade <?php echo str_replace("Grade","", $getuserinfo_sc[0]['grade']); ?></li>
				
				<li><i class="fa fa-calendar-o"></i> Registered Date <?php echo date('d-m-Y', strtotime($getuserinfo_sc[0]['creation_date'])); ?></li>
				
						<li class="m-top-xs">
                           Validity
                         <?php echo date('d-m-Y', strtotime($getuserinfo_sc[0]['startdate'])); ?>  -  <?php echo date('d-m-Y', strtotime($getuserinfo_sc[0]['enddate'])); ?>
                        </li>
						
						
						<li id="successmsg" style="color: green; font-weight: 700;"></li>
						
                      </ul>

                      <br />

					</div>
                    </div>
					<div class="col-md-12 col-sm-12 col-xs-12 col-lg-9 padtop">
                        <div class="" role="tabpanel" data-example-id="togglable-tabs">
                        <ul id="myTab" class="nav nav-tabs bar_tabs" role="tablist" style="margin:0; display:none;">
                          <li role="presentation" class="col-md-4 col-sm-4 col-xs-12"><a href="#tab_content1" id="asap-tab" role="tab" data-toggle="tab" aria-expanded="true">Assessment</a>
                          </li>
                          <li role="presentation" class="active col-md-4 col-sm-4 col-xs-12"><a href="#tab_content2" role="tab" id="training-tab" data-toggle="tab" aria-expanded="false">Training</a>
                          </li>
                          <li role="presentation" class="col-md-4 col-sm-4 col-xs-12"><a href="#tab_content3" role="tab" id="clp_asap_tab" data-toggle="tab" aria-expanded="false">Assessment vs Training</a>
                          </li>
                        </ul>
                        <div id="myTabContent" class="tab-content">
                          <div role="tabpanel" class="tab-pane fade" id="tab_content1" aria-labelledby="home-tab">
						  <?php if($IsAsapEnable[0]['playedstatus']>0) { ?> 
                            <div class="">
								<div class="col-md-2">
								<h2 style="font-weight:700 !important; color:#4765ff;">BSPI : <?php echo round($asapbspi[0]['avgbspiset1'], 2); ?> </h2>
								</div>
								<div class="col-md-10">
								  
								</div>
							  </div>
							<div class="col-12 col-md-12 col-sm-12 col-xs-12">
							  <div id="container3" style="background-color: #fff;"></div>
							</div>
							  <!-- end of user-activity-graph -->
						  <?php } else { ?>
						  <h2 style="text-align:center;"> Assessment not yet started </h2>
						  <?php } ?>
                          </div>
                          <div role="tabpanel" class="tab-pane fade active in" id="tab_content2" aria-labelledby="profile-tab">
						  
						  <?php if($IsCLPEnable_sc[0]['playedstatus']<=0) { ?> 
						  <h2 style="text-align:center;"> User not yet started </h2>
						  <?php }  else { ?>
 						
							  <!-- start of user-activity-graph -->
							  <div class="col-md-12" style="text-align: center;">
							  <div class="col-md-2 col-xs-12 counter">Puzzles Played<br/><span class="counterinnertxt"><?php echo $getcounters_sc[0]['UniqueGames']; ?></span></div>
							  <div class="col-md-2 col-xs-12 counter">Question Attempted<br/><span class="counterinnertxt"><?php echo $getcounters_sc[0]['PuzzlesAttempted']; ?></span></div>
							   <div class="col-md-2 col-xs-12 counter">Question Solved<br/><span class="counterinnertxt"><?php echo $getcounters_sc[0]['PuzzlesSolved']; ?></span></div>
							   <div class="col-md-2 col-xs-12 counter">Minutes Trained<br/><span class="counterinnertxt"><?php echo $getcounters_sc[0]['MinutesTrained']; ?></span></div>
							   <div class="col-md-2 col-xs-12 counter">BSPI<br/><span class="counterinnertxt"><?php echo round($getbspi_sc[0]['bspi'], 2); ?></span></div>
							   <div class="col-md-2 col-xs-12 counter">Crownies<br/><span class="counterinnertxt"><?php if($getcrowny_sc[0]['points']!='') { echo $getcrowny_sc[0]['points']; } else { echo '-'; } ?></span></div>
							  </div><br/>
							
							  <!---inner-->
							
						<!--<div class="" role="tabpanel" data-example-id="togglable-tabs">
                        <ul id="myTab1" class="nav nav-tabs bar_tabs" role="tablist">
							<li role="presentation" class="active col-md-4 col-sm-4 col-xs-12"><a style="font-size: 12px;" href="#tab_content32" id="" role="tab" data-toggle="tab" aria-expanded="true">BSPI</a>
							</li>
							
						  <li role="presentation" class="col-md-4 col-sm-4 col-xs-12"><a style="font-size: 12px;" href="#tab_content31" role="tab" id="training-tab1" data-toggle="tab" aria-expanded="false">BSPI Calendar </a>
                          </li>
                          <li role="presentation" class="col-md-4 col-sm-4 col-xs-12"><a style="font-size: 12px;" href="#tab_content21" role="tab" id="training-tab1" data-toggle="tab" aria-expanded="false">Engagement Graph</a>
                          </li>                          
                        </ul>
						</div>-->
						

							  <!--inner-->
                            <!-- end user projects -->
						 
						  
						 
                          </div> 
						  
                        </div>
                      </div>
					 
					 

					  <div class="col-md-6 col-sm-6 col-xs-12 col-lg-6 padtop">
					  <h3 style="color: #000;">Training Calendar</h3>
					 <div style="clear:both">Note : Click on marked dates to view their current day score details</div>
					  <div id="my-calendar"></div>
					  </div>
					  
					 
					  <div class="col-md-6 col-sm-6 col-xs-12 col-lg-6 padtop">
					  <h3 style="padding-bottom:17px; color: #000;">Skill Score</h3>
					<div class="panel panel-default">
                        <div class="panel-body">
					<div class="reportChartContainer1">
                            <div class="cb">
                            	<p class="skillName pt0">Memory</p>
                                	
                            	<div class="meter mt10">
                                	<span class="redColor" id="memscore"></span>
								</div>
                            </div>
                            <div class="cb">
                            	<p class="skillName">Visual Processing</p>
                            	<div class="meter mt10">
  									<span class="yellowColor" id="vpscore"></span>
								</div>
                            </div>
                            <div class="cb">
                            	<p class="skillName">Focus & Attention</p>
                            	<div class="meter mt10">
  									<span class="greenColor" id="focusscore"></span>
								</div>
                            </div>
                            <div class="cb">
                            	<p class="skillName">Problem Solving</p>
                            	<div class="meter mt10">
  									<span class="orangeColor" id="problemscore"></span>
								</div>
                            </div>
                            <div class="cb">
                            	<p class="skillName">Linguistics</p>
                            		<div class="meter mt10">
  										<span class="blueColor" id="lingscore"></span>
									</div>
                            </div>
                     </div>
				</div>
				</div>
				
					  </div>
					  
					   
					  <div class="col-md-12 col-sm-12 col-xs-6 col-lg-12 padtop">
					  <h3 style="text-align:center; color: #000;">Daywise BSPI</h3>
					  <div id="Userbspidatewise" style="background:#fff;padding-top:20px;border: 1px solid #ccc;" ></div>
					  </div>
					  
                    </div>
					
					
                     <?php } ?>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
		
<script src="<?php echo base_url(); ?>assets/js/jquery.min.js" type="text/javascript"></script>
<script src="<?php echo base_url(); ?>assets/js/highchartsnew.js" type="text/javascript"></script>
<script src="<?php echo base_url(); ?>assets/js/drilldown.js"></script>

<script src="<?php echo base_url(); ?>assets/fusioncharts/js/fusioncharts.js"></script>
<script src="<?php echo base_url(); ?>assets/fusioncharts/js/fusioncharts.theme.fint.js"></script>
<script src="<?php echo base_url(); ?>assets/fusioncharts/js/fusioncharts.widgets.js"></script>

<style>
		.tab-content > .tab-pane,
.pill-content > .pill-pane {
    display: block;     
    height: 0;          
    overflow-y: hidden; 
}

.tab-content > .active,
.pill-content > .active {
    height: auto;       
} 
.padtop {padding-top:10px;}
		</style>


<script type="text/javascript" src="<?php echo base_url();?>assets/js/jquery.nice-select.js"></script>
<link href="<?php echo base_url();?>assets/css/nice-select.css" rel="stylesheet">

<script>
$(document).ready(function(){
	cal();
	userbspidatewise();
	overallskillscore();
});
function cal()
{ 
 var userid = $("#userid").val();
	$.ajax({
	type: "POST",
	data:{userid:userid},
	url: "<?php echo base_url()."index.php/home/playeddates"; ?>",
	dataType:"json",
	success: function(result){
		/* alert(result); */
		$("#my-calendar").zabuto_calendar({
			 cell_border: true,
			 data: result,
			cell_border: true,
			today: true,
				show_days: true,
			year: <?php echo $date->format("Y"); ?>,
			month: <?php echo $date->format("m"); ?>,
			show_previous: false,
			show_next: <?php echo $diff = (($year2 - $year1) * 12) + ($month2 - $month1); ?>,
			 action: function () { //alert(this.id);
					 return myDateFunction(this.id, false);
             },
		 
		 
	});
	}
	});
}

function overallskillscore() //PIE CHART IN DASHBOARD
  { 
  
    var userid = $("#userid").val();
	var startdate = $("#startdate").val();
	var enddate = $("#enddate").val();
	
	$.ajax({
	  type: "POST",
	  url: "<?php echo base_url(); ?>index.php/home/overallskillscore",
	  dataType:"json",
	  data:{userid:userid,startdate:startdate,enddate:enddate},
	  success: function(result){
		  //alert(result);
	 // skillpiechart(result.SID59,result.SID60,result.SID61,result.SID62,result.SID63);
					$("#memscore").html(result.SID59);
					$("#memscore").css("width", result.SID59+'%');
					$("#vpscore").html(result.SID60);
					$("#vpscore").css("width", result.SID60+'%');
					$("#focusscore").html(result.SID61);
					$("#focusscore").css("width", result.SID61+'%');
					$("#problemscore").html(result.SID62);
					$("#problemscore").css("width", result.SID62+'%');
					$("#lingscore").html(result.SID63);
					$("#lingscore").css("width", result.SID63+'%');
		 
		}
	});
  }

function myDateFunction(id, fromModal) {
	
	var userid = $("#userid").val();
	
        $("#date-popover").hide();
        if (fromModal) {
            $("#" + id + "_modal").modal("hide");
        }
        var date = $("#" + id).data("date");
		var hasEvent = $("#" + id).data("hasEvent");
		if (hasEvent) 
		{
			$.ajax({
			type: "POST",
			url: "<?php echo base_url()."index.php/home/getTrainingCalendarData"; ?>",
			data: {curdate:date,userid:userid},
			dataType: "json",
			success: function(result){
			//	alert(result);
					$("#curday").html('Daily Score - '+result.Curday);
					$("#mem").html(result.MEMORY);
					$("#mem").css("width", result.MEMORY+'%');
					$("#vp").html(result.VISUAL);
					$("#vp").css("width", result.VISUAL+'%');
					$("#focus").html(result.FOCUS);
					$("#focus").css("width", result.FOCUS+'%');
					$("#problem").html(result.PROBLEM);
					$("#problem").css("width", result.PROBLEM+'%');
					$("#ling").html(result.LING);
					$("#ling").css("width", result.LING+'%');
					
					$("#CURScore").html(result.BSPI);
					
					guagechart(result.BSPI);
					var sco =parseFloat(result.BSPI).toFixed(2); 
					$('#score').html(sco);
					
					$("#CURCrownies").html(result.Crownies);
					$("#CURPuzzlesAttempted").html(result.PuzzlesAttempted);
					$("#CURPuzzlesSolved").html(result.PuzzlesSolved);
					$("#CURMinutesTrained").html(result.MinutesTrained);
					$('#todayModal').modal('show'); 
			}
			});	
		}
		
}

function guagechart(score)
			{
			
	FusionCharts.ready(function () {
    var csatGauge = new FusionCharts({
        "type": "angulargauge",
        "renderAt": "chart-container","background":"transparent",
        "width": "400",
        "height": "250",
        "dataFormat": "json",
            "dataSource": {
    "chart": {
		
        "caption": "",
        "lowerlimit": "0",
        "upperlimit": "100",
	 "bgAlpha":'0',
            
            "gaugeFillRatio": "15",
            "theme": "fint",
			
        
    },
    "colorrange": {
        "color": [
            {
                "minvalue": "0",
                "maxvalue": "20",
                "code": "c01f25"
            },
			{
                "minvalue": "20",
                "maxvalue": "40",
                "code": "f36621"
            },
			{
                "minvalue": "40",
                "maxvalue": "60",
                "code": "fdc010"
            },
            {
                "minvalue": "60",
                "maxvalue": "80",
                "code": "94c953"
            },
            {
                "minvalue": "80",
                "maxvalue": "100",
                "code": "00b04e"
            }
        ]
    },
    "dials": {
        "dial": [
            {
                "value": score,
                "rearextension": "15",
                "radius": "100",
                "bgcolor": "333333",
                "bordercolor": "333333",
                "basewidth": "8"
            }
        ]
    }
}
      });

csatGauge.render();
});	
			}

function userbspidatewise()
{ 
var userid = $("#userid").val();
var startdate = $("#startdate").val();
var enddate = $("#enddate").val();
$.ajax({
type:"POST",
data:{userid:userid,startdate:startdate,enddate:enddate},
url:"<?php echo base_url('index.php/home/datewisebspi') ?>",
//data:form.serialize(),
dataType: 'json',
success:function(result)
{
//alert(result);
if(result!='')
{ 
	var gdate=[];
	var gscore=[];
	var v1=[];
	var k1=[];
	var k2=[];
	var v2=[];
	var arrgamedate = ((result));
	
$.each(arrgamedate, function(k1, v1) {
  //gdate=gdate+","+'"'+k+'"';

  $.each(v1, function(k2, v2) {
	    
	  if(k2=="Playeddate"){gdate.push(v2);}
	  if(k2=="BSPI"){gscore.push(parseFloat(v2)).toFixed(2);}
	  //if(k2=="BSPI"){gscore.push(parseFloat(v2)).toFixed(2);}
  });
   
});
linechart(gdate,gscore); 
}
else
{
	$("#userbspidatewise").html("<div style='text-align:center;color:red;'>No data found.</div>");
}
}
});


}

function linechart(gdate,gscore)
{
	
	Highcharts.setOptions({
    colors: ['#811010', '#50B432', '#ED561B', '#DDDF00', '#24CBE5', '#64E572', '#FF9655', '#FFF263', '#6AF9C4', '#DDDF00','#64E572',  '#50B432' ]
	
});
	 
    var chart = new Highcharts.Chart({
        chart: {
			renderTo: 'Userbspidatewise',
			backgroundColor:'transparent',
			 
            type: 'column'
			//height:'55%'
			//chart.setSize(width, height, doAnimation = true);
        },
        title: {
            text: ''
        },
		tooltip: {formatter: function() {
    return 'BSPI On <b>'+ this.x +
           '</b> is <b>'+ this.y +'</b>';
  }},exporting:false,credits: {
      enabled: false
  },
        yAxis: {
			gridLineWidth: 0,
  minorGridLineWidth: 0,
          title: {
                text: 'Score'
            },
			tickInterval: 10,
			min:0,
			max: 100 
        },xAxis: {
            categories: gdate,
			gridLineWidth: 0,
       minorGridLineWidth: 0,
	   title: {
                text: 'Played Date'
            },
        },
        credits: {
            enabled: false
        },
		plotOptions: {
			  
            column: {
             //   depth: 50,
				colorByPoint: true,
				dataLabels: {
            enabled: true
        }
		
            }
        },
		
		 
		
		
      
		series: [{
			showInLegend: false,
        data: gscore        
    }]
		
    });
	
}
</script>