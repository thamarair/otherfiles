 <div class="right_col" role="main">
<div class="row">
<div class="col-md-12 col-sm-12 col-xs-12">
<div class="x_panel tile">
<div class="x_title">
<h2 class="reporttitle">Update Profile</h2>

<div class="clearfix"></div>
</div>
<div class="clearfix"></div>

	<div id="mainContDisp" class="container playGames homePlayGames" style="margin-top:20px;margin-bottom:70px;"> 

<form name="frmRegister" id="frmRegister" class="" method="post"  enctype="multipart/form-data" action="<?php echo base_url(); ?>index.php/home/doctorupdate"  accept-charset="utf-8"  >
  <div class="row">
    <div class="col-lg-12 txtclr">
	<div style="padding-top:5px;">
      <div class="">
      <h3>Please fill the details below : </h3>
	  <?php if(isset($msg)){?> <div class="msg"><?php echo $msg; ?> </div><?php } ?>
	  <span style="float:right;"><label><span style="color:red">*</span> Required fields
	  </label></span>
	 
  </div>
  </div>
  </div>
</div>
 <input type="hidden" class="form-control" name="txthdnid" value="<?php echo $editdoctor[0]['id']; ?>"  id="txthdnid">
<div class="row">
		<div class="col-lg-6">
      <div class="form-group">
    <label for="txtFName">Doctor Name <span style="color:red">*</span></label>
    <input type="text" maxlength="40" class="form-control alphaOnly" name="txtFName" value="<?php echo $editdoctor[0]['doctorname']; ?>"  id="txtFName">
  </div> 
  </div>
  <div class="col-lg-6">
  <div class="form-group">
    <label for="txtLName">Last Name</label>
    <input type="text" maxlength="40"  class="form-control alphaOnly" name="txtLName" value="<?php echo $editdoctor[0]['lastname']; ?>" id="txtLName">
  </div> 
  </div>
    </div>
<div class="row">
	<div class="col-lg-6">
  <div class="form-group">
    <label for="txtMobile">Gender <span style="color:red">*</span></label>
    <div class=""> 
       <div class="col-sm-3"><label class="radio-inline"><input type="radio" class="" <?php if($editdoctor[0]['gender']=='M') { ?> checked="checked" <?php } ?>  name="rdGender" value="M" id="rdGM">Male</label></div>
    <div class="col-sm-3"><label class="radio-inline"><input type="radio" class="" <?php if($editdoctor[0]['gender']=='F') { ?> checked="checked" <?php } ?>   name="rdGender" value="F" id="rdGF">Female</label></div>
	</div>
  </div>
    </div>
	<div class="col-lg-6">
  <div class="form-group">
    <label for="txtDOB">DOB <span style="color:red">*</span></label>
    <input type="text" readonly class="form-control" name="txtDOB" value="<?php echo $editdoctor[0]['dateofbirth']; ?>" id="txtDOB">
  </div>
    </div></div>
	<div class="row">
	<div class="col-lg-6">
  <div class="form-group">
    <label for="txtEmail">Primary Email ID<span style="color:red">*</span></label>
    <input type="text" maxlength="200" class="form-control" name="txtEmail" value="<?php echo $editdoctor[0]['email']; ?>" id="txtEmail">
	<label id='errEmail' class="error"></label>
  </div>
    </div>
	<div class="col-lg-6">
  <div class="form-group">
    <label for="txtSEmail">Secondary Email ID</label>
    <input type="text" maxlength="200" class="form-control" name="txtSEmail" value="<?php echo $editdoctor[0]['secondaryemail']; ?>" id="txtSEmail">
  </div>
    </div> </div>
	<div class="row">
		<div class="col-lg-6">
  <div class="form-group">
    <label for="txtMobile">Primary Mobile Number <span style="color:red">*</span></label>
	 <div class="input-group">
          <span class="input-group-addon" id="idmobileCode">+91</span>
    <input placeholder="" type="text" class="form-control numbersOnly" maxlength="10" name="txtMobile" value="<?php echo $editdoctor[0]['mobilenumber']; ?>" id="txtMobile">
        </div>
  </div>
    </div>
	<div class="col-lg-6">
 <div class="form-group">
    <label for="txtSMobile">Secondary Mobile Number</label>
	 <div class="input-group">
          <span class="input-group-addon" id="idmobileCode">+91</span>
    <input placeholder="" type="text" class="form-control numbersOnly" maxlength="10" name="txtSMobile" value="<?php echo $editdoctor[0]['secondarymobilenumber']; ?>" id="txtSMobile">
        </div>
  </div>
    </div></div>
	 
	
	<div class="row">
	<div class="col-lg-6">
  <div class="form-group">
    <label for="ddlState">State<span style="color:red">*</span></label>
<select class="form-control"  name="ddlState" id="ddlState">
<option value="">Select</option>
<?php foreach($getstate as $res) { ?> 
<option value="<?php echo $res['id']; ?>" <?php if($res['id']==$editdoctor[0]['state']) { ?> selected="selected" <?php } ?>><?php echo $res['state_name']; ?></option>
<?php } ?>


</select>  

</div>
    </div>
	<div class="col-lg-6">
  <div class="form-group">
    <label for="txtCity">City <span style="color:red">*</span></label>
    	<input class="form-control alphaOnly" type="text" value="<?php echo $editdoctor[0]['city']; ?>" maxlength="255" name="txtCity" id="txtCity"/>
    	
  </div>
    </div></div>	
	<div class="row">
	<div class="col-lg-6">
  <div class="form-group">
    <label for="txtCity">Hospital Name</label>
	<input type="text" class="form-control"  id="" name="txthospitalname" value="<?php echo $editdoctor[0]['hospitalname']; ?>" />
		
    	
  </div>
    </div>
	<div class="col-lg-6">
  <div class="form-group">
    <label for="txtAddress">Address <span style="color:red">*</span></label>
	<textarea class="form-control"  name="txtAddress" id="txtAddress"><?php echo $editdoctor[0]['address']; ?></textarea>
  </div>
    </div></div>
	
	<div class="row">
	
	
	<div class="col-lg-6">
  <div class="form-group">
    <label for="txtMobile">Profile Image</label>
    <div class=""> 
       <img src="<?php echo base_url(); ?><?php echo $editdoctor[0]['profileimage']; ?>" id="previewing" alt="Profile image" width=89px; height=89px; />
   <a id="pImage" href="javascript:;" title="Upload Profile Image"><img src="<?php echo base_url(); ?>assets/images/photo-icon.png" width="21" height="21" class="photoicon" alt="Upload Profile Image"></a>
   <input type="file" accept="image/*" class="form-control" value="" id="fileUpload" style="display:none;" name="file" >
	</div>
  </div>
	</div>
	</div>
	
	<div style="text-align:center;clear:both;">
   <input type="submit" id="btnRegisterSubmit" name="btnRegisterSubmit" style="float:none;" class="btn btn-success" value="Update" />
   <input type="reset"  id="frmreset" class="btn btn-waring">
</div>
		 </form>
		 </div></div>
		 </div></div>
		 </div>


<link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/jquery-ui.css">
<script src="<?php echo base_url(); ?>assets/js/jquery-2.2.0.min.js" type="text/javascript"></script>
<script src="<?php echo base_url(); ?>assets/js/jquery.min.js" type="text/javascript"></script>
<script src="<?php echo base_url(); ?>assets/js/jquery-ui.js"></script>
<script src="<?php echo base_url(); ?>assets/js/jquery.validate.js"></script> 

<script type="text/javascript">

 $("#pImage").click(function(){
	$("#fileUpload").click(); 
 });
 
 
  $('#fileUpload').change(function(){
$("#message").empty();
var file = this.files[0];
var imagefile = file.type;
var match= ["image/jpeg","image/png","image/jpg"];
//
if(!((imagefile==match[0]) || (imagefile==match[1]) || (imagefile==match[2])))
{

$("#message").html("<p id='error' style=color:red; >Please select a valid image file</p>");
return false;
}
else if(file.size>1024*1024){
	/*
	var image = new Image();
image.onload = function () {
                    var height = this.height;
                    var width = this.width;
                    if (height > 150 || width > 150) {
          $("#message").html("<p id='error' style=color:red; >Please upload image below 150*150</p>");

                        return false;
                    }
}
*/
					
$("#message").html("<p id='error' style=color:red; >Please select a file less than 1 MB</p>");
return false;
	
}
else
{
$('#previewing').attr('src','schools_admin_student_report.png');
var reader = new FileReader();
reader.onload = imageIsLoaded;
reader.readAsDataURL(this.files[0]);
}


 });
 
 function imageIsLoaded(e) {
$("#file").css("color","green");
$('#image_preview').css("display", "block");
$('#previewing').attr('src', e.target.result);
$('#previewing').attr('width', '89px');
$('#previewing').attr('height', '89px');
};

dob = $( "#txtDOB" ).datepicker({
			 dateFormat: 'dd-mm-yy' , maxDate: new Date(),
			 onSelect: function(value, ui) {
        var today = new Date(),
            dob = new Date(value),
            age = new Date(today - dob).getFullYear() - 1970;// $('#txtAge').val(age);
			},
          changeMonth: true, changeYear: true
        });

$('.numbersOnly').keyup(function () { 
    this.value = this.value.replace(/[^0-9]/g,'');
});

$('.alphaOnly').keyup(function () { 
    this.value = this.value.replace(/[^a-zA-Z ]/g,'');
});

$.validator.addMethod('filesize', function(value, element, param) {
    return this.optional(element) || (element.files[0].size <= param) 
}); 

 $('#txtPassword').bind("cut copy paste",function(e) {
     e.preventDefault();
 });
  $('#txtCPassword').bind("cut copy paste",function(e) {
     e.preventDefault();
 }); $('#txtEmail').bind("cut copy paste",function(e) {
     e.preventDefault();
 });
  $('#txtSEmail').bind("cut copy paste",function(e) {
     e.preventDefault();
 });
 
 $("#frmRegister").validate({
        rules: {
            "txtFName": {required: true,minlength: 3},
			"txtEmail": {required: true,email: true},
			"txtSEmail": {email: true},
            "txtDOB": {required: true},
            "ddlGrade": {required: true},
            "rdGender": {required: true},
            "txtMobile": {required: true,minlength: 10},
			"txtSMobile": {minlength: 10},
            "ddlState": {required: true},
            "txtCity": {required: true},
             "txtAddress": {required: true},
			// "txthospitalname": {required: true},
			// "txtstatus": {required: true},
            "ddlpreferred_channel": {required: true}
        },
        messages: {
            "txtFName": {required: "Please enter first name"},
			"txtEmail": {required: "Please enter email",email: "Please enter valid email"},
			"txtSEmail": {email: "Please enter valid email"},
           
			"txtDOB": {required: "Please select date of birth"},
			"rdGender": {required: "Please select gender"},
			"txtMobile": {required:"Please enter mobile number",minlength:"Please enter valid mobile number" },
			"txtSMobile": {minlength:"Please enter valid mobile number" },
            "ddlState": {required: "Please select state"},
            "txtCity": {required: "Please enter city"},
            "txtAddress": {required: "Please enter address"},
		//	"txthospitalname": {required: "Please select hospitalname"},
		//	"txtstatus": {required: "Please select status"},
            "ddlpreferred_channel": {required: "Please select most watched channel"}
        },
		errorPlacement: function(error, element) {
    if (element.attr("type") === "radio") {
        error.insertAfter(element.parent().parent());
    } 
	else if (element.attr("id") === "txtMobile") {
        error.insertAfter(element.parent());
    } 
	
	else if (element.attr("id") === "txtSMobile") {
        error.insertAfter(element.parent());
    } 
	else {
        error.insertAfter(element);
    }
	
},
		highlight: function(input) {
            $(input).addClass('error');
        } 
    });
	
	
 
 
</script>
<style>
.reporttitle { color:#1abb9c; }
thead{ background-color: #1abb9c; color: #fff;}
.error {color:red;}

#txtSMobile
{
	z-index: 0 !important;
}
</style>

