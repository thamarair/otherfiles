<footer>
          <div class="pull-right">
            Copyright © <?php echo date("Y"); ?> SkillAngels. All rights reserved.
          </div>
          <div class="clearfix"></div>
        </footer>
        <!-- /footer content -->
	<script src="<?php echo base_url(); ?>assets/js/jquery.min.js"></script>
	<script src="<?php echo base_url(); ?>assets/js/jquery.validate.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/bootstrap.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/fastclick.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/nprogress.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/Chart.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/gauge.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/bootstrap-progressbar.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/icheck.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/skycons.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/jquery.flot.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/jquery.flot.pie.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/jquery.flot.time.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/jquery.flot.stack.js"></script>
	<script src="<?php echo base_url(); ?>assets/js/jquery.flot.resize.js"></script>
	

    <script src="<?php echo base_url(); ?>assets/js/jquery.flot.orderBars.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/jquery.flot.spline.min.js"></script>
	<script src="<?php echo base_url(); ?>assets/js/curvedLines.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/date.js"></script>
	
	<script src="<?php echo base_url(); ?>assets/js/jquery.vmap.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/jquery.vmap.world.js"></script>
	<script src="<?php echo base_url(); ?>assets/js/jquery.vmap.sampledata.js"></script>
	
    <script src="<?php echo base_url(); ?>assets/js/moment.min.js"></script>
	<script src="<?php echo base_url(); ?>assets/js/daterangepicker.js"></script>
		 
	<script src="<?php echo base_url(); ?>assets/js/custom.js"></script>
	
	<script src="<?php echo base_url(); ?>assets/js/moment.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/fullcalendar.min.js"></script>
	<!-- FullCalendar -->
    <link href="<?php echo base_url(); ?>assets/css/fullcalendar.min.css" rel="stylesheet">
    <link href="<?php echo base_url(); ?>assets/css/fullcalendar.print.css" rel="stylesheet" media="print">
	
	<script src="<?php echo base_url(); ?>assets/js/jquery.dataTables.js" type="text/javascript"></script>
	<script src="<?php echo base_url(); ?>assets/js/dataTables.tableTools.js" type="text/javascript"></script>
	
	<link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/zebra/zebra_datepicker.min.css" type="text/css">
	<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/zebra/zebra_datepicker.min.js"></script>
	
	<script src="<?php echo base_url(); ?>assets/js/zabuto_calendar.min.js"></script>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/css/zabuto_calendar.min.css">


	<script type="text/javascript">
		$( document ).ready(function() {
			
			jQuery.validator.addMethod("noSpace", function(value, element) { 
  return value.indexOf(" ") < 0 && value != ""; 
}, "No space please and don't leave it empty");

			setInterval(LoginAjaxCall, 1000*60*1); //300000 MS == 5 minutes
			LoginAjaxCall();

			$("#calview").click(function() {
				$("#tableview").hide();
				$("#chartview").hide();
				$("#calendarview").show();
				$("#todayfilter").show();
			});
			$("#tblview").click(function() {
				$("#tableview").show();
				$("#chartview").hide();
				$("#calendarview").hide();
				$("#todayfilter").show();
			});
			$("#chview").click(function() {
				$("#tableview").hide();
				$("#chartview").show();
				$("#calendarview").hide();
				$("#todayfilter").show();
			});
		});
		
		function LoginAjaxCall(){ 		
		$.ajax({
			type:"POST",
			url:"<?php echo base_url('index.php/home/checkuserisactive') ?>",
			success:function(result)
			{	//alert(result);
			///	if(result==1)
			//	{ 
					
			//		window.location.href= "<?php echo base_url();?>index.php";
			//	}		
			}
		});
		}
		
		
		
	</script>
	
	<script>
	$("#frmpwd").validate({
		rules : {
                txtpwd : {required:true,  minlength : 6 },
                txtcpwd : {required:true, equalTo : "#txtpwd" }
            },
			
		messages: {
            "txtpwd": {required: "Please enter password"},
			"txtcpwd": {required: "Please enter confirm password", equalTo:"Please enter same password as confirm password" }
           
        },
		
		
		errorPlacement: function(error, element) {
    if (element.attr("type") === "radio") {
        error.insertAfter(element.parent().parent());
    } 
	else {
        error.insertAfter(element);
    }
	
},
		highlight: function(input) {
           // $(input).addClass('error');
        } 
    });
	
	$('#btnchange').click(function(){
		//alert('true');
		if($("#frmpwd").valid()==true)
		{
			var pwd = $("#txtpwd").val(); 
			
			$.ajax({
			type:"POST",
			data:{pwd:pwd},
			url:"<?php echo base_url('index.php/home/resetpwd') ?>",
			success:function(result)
			{		
			
			if(result==1)
			{
				$("#frmpwd")[0].reset();
				$('#successmsg').html('Your Password Updated Successfully');
			//window.location.href= "<?php echo base_url();?>index.php/home/userperformance";
			}
			
			}
		});
		}		
	});
	
$('.numbersOnly').keyup(function () { 
    this.value = this.value.replace(/[^0-9]/g,'');
});



$('.alphaOnly').keyup(function () { 
    this.value = this.value.replace(/[^a-zA-Z ]/g,'');
});

 
 $('#txtstartdate').Zebra_DatePicker({
    direction: true,
	 format: 'd-m-Y'
});

 $("#frmRegister").validate({
        rules: {
            "txtname": {required: true},
			"ddlgrade": {required: true},
			"txtgender": {required: true},
			"txtusername": {required: true,noSpace:true},
			"txtemail": {email: true},
            "txtmobile": {minlength: 10},
			"txtstartdate": {required: true}
        },
        messages: {
            "txtname": {required: "Please enter name"},
			"ddlgrade": {required: "Please select grade"},
			"txtgender": {required: "Please choose gender"},
			"txtusername": {required: "Please enter username"},
            "txtemail": {email: "Please enter valid email id"},
			"txtmobile": {minlength:"Please enter valid mobile number" },
			"txtstartdate": {required:"Please select startdate" }
        },
		errorPlacement: function(error, element) {
    if (element.attr("type") === "radio") {
        error.insertAfter(element.parent().parent());
    } 
	else if (element.attr("id") === "txtMobile") {
        error.insertAfter(element.parent());
    } 
	
	else if (element.attr("id") === "txtSMobile") {
        error.insertAfter(element.parent());
    } 
	else {
        error.insertAfter(element);
    }
	
},
		highlight: function(input) {
           // $(input).addClass('error');
        } 
    });
	
	
		
		$("#txtusername").keyup(function(e){
			
			var username = $(this).val();
			
			 if(e.keyCode == 32){
       $('#errormsg').html("No space please and don't leave it empty");
	   //$('#regsubmit').prop('disabled', true);
   }
   
			$.ajax({
			type:"POST",
			data:{username:username},
			url:"<?php echo base_url('index.php/home/usernamecheck') ?>",
			success:function(result)
			{		
			$('.loading').fadeOut("slow");
//		alert(result);
			if(result==1)
			{
				$('#errormsg').html('Username already exist');
				$('#regsubmit').prop('disabled', true);
			}
			else{
				
				$('#errormsg').html('');
				$('#regsubmit').prop('disabled', false);
			}
			
			}
		});
			
		});
		
		
	
	
	$('#regsubmit').click(function(){
		//alert('true');
		//checkalreadyexist();
		
		if($("#frmRegister").valid()==true)
		{
			
			var name = $('#txtname').val();
			var grade = $('#ddlgrade').val();
			var gender = $('#txtgender').val();
			var username = $('#txtusername').val();
			var mobile = $('#txtmobile').val();
			var emailid = $('#txtemail').val();
			var startdate = $('#txtstartdate').val();
			$('.loading').show();
			$.ajax({
			type:"POST",
			data:{name:name,grade:grade,gender:gender,username:username,mobile:mobile,emailid:emailid,startdate:startdate},
			url:"<?php echo base_url('index.php/home/addsummercampuser') ?>",
			success:function(result)
			{		
			$('.loading').fadeOut("slow");
		alert(result);
			if(result==1)
			{
				$("#frmRegister")[0].reset();
				$('#successmsg').html('User Added Successfully');
			//window.location.href= "<?php echo base_url();?>index.php/home/userperformance";
			}
			
			}
		});
			
			
			
		}
	});
	
	
	</script>
	 </div>
    </div>
	<div id="todayModal" class="modal fade" role="dialog">
  <div class="modal-dialog" id="welcomecontainer">
    <!-- Modal content-->
    <div class="modal-content" style="box-shadow: none;border: none;">
      <div class="modal-header" style="text-align:center;">
<button type="button" class="close" data-dismiss="modal" style="color: #000;opacity: 1;font-size: 30px;
">&times;</button>
			<h3 class="modal-title" id="curday" style="text-align: center;"></h3>
      </div>
      <div class="modal-body"  style="padding:0px;">
			<div class="col-md-12 col-sm-12 col-xs-12 text-center">
			
				<div class="col-md-8 col-sm-8 col-xs-12 col1 text-center">
					<div class="col-md-6 col-sm-6 col-xs-6"><h3>Memory</h3></div>
					<div class="col-md-6 col-sm-6 col-xs-6"><h4 id="mem"></h4></div>
				</div>
				
				<div class="col-md-8 col-sm-8 col-xs-12 col2 text-center">
					<div class="col-md-6 col-sm-6 col-xs-6"><h3>Visual Processing</h3></div>
					<div class="col-md-6 col-sm-6 col-xs-6"><h4 id="vp"></h4></div>
				</div>
				
				<div class="col-md-8 col-sm-8 col-xs-12 col1 text-center">
					<div class="col-md-6 col-sm-6 col-xs-6"><h3>Focus & Attention</h3></div>
					<div class="col-md-6 col-sm-6 col-xs-6"><h4 id="focus"></h4></div>
				</div>
				
				<div class="col-md-8 col-sm-8 col-xs-12 col2 text-center">
					<div class="col-md-6 col-sm-6 col-xs-6"><h3>Problem Solving</h3></div>
					<div class="col-md-6 col-sm-6 col-xs-6"><h4 id="problem"></h4></div>
				</div>
				
				<div class="col-md-8 col-sm-8 col-xs-12 col1 text-center">
					<div class="col-md-6 col-sm-6 col-xs-6"><h3>Linguistics</h3></div>
					<div class="col-md-6 col-sm-6 col-xs-6"><h4 id="ling"></h4></div>
				</div>
				
				<div class="col-md-8 col-sm-8 col-xs-12 col2 text-center">
					<div class="col-md-6 col-sm-6 col-xs-6"><h3>BSPI</h3></div>
					<div class="col-md-6 col-sm-6 col-xs-6"><h4 id="CURScore"></h4></div>
				</div>
				<div class="col-md-8 col-sm-8 col-xs-12 col1 text-center">
					<div class="col-md-6 col-sm-6 col-xs-6"><h3><img class="" src="<?php echo base_url(); ?>assets/images/sparkies/6.gif" width="40px;" >Crownies</h3></div>
					<div class="col-md-6 col-sm-6 col-xs-6"><h4 id="CURCrownies"></h4></div>
				</div>
			
				<div class="col-md-8 col-sm-8 col-xs-12 col2 text-center">
					<div class="col-md-6 col-sm-6 col-xs-6"><h3>Questions Attempted</h3></div>
					<div class="col-md-6 col-sm-6 col-xs-6"><h4 id="CURPuzzlesAttempted"></h4></div>
				</div>
				<div class="col-md-8 col-sm-8 col-xs-12 col1 text-center">
					<div class="col-md-6 col-sm-6 col-xs-6"><h3>Questions Solved</h3></div>
					<div class="col-md-6 col-sm-6 col-xs-6"><h4 id="CURPuzzlesSolved"></h4></div>
				</div>
				<div class="col-md-6 col-sm-6 col-xs-12 col2 text-center">
					<div class="col-md-6 col-sm-6 col-xs-6"><h3>Minutes Trained</h3></div>
					<div class="col-md-6 col-sm-6 col-xs-6"><h4 id="CURMinutesTrained"></h4></div>
				</div>
			</div>
			
      </div>
    </div>
  </div>
</div>
  </body>
</html>

<style>
.dateinfo .count{font-size:20px;color:#337ab7;font-weight: bold;display:block;padding-left:20px;}
.dateinfo .count_top{font-size:15px;font-weight: bold;}
.toppart h4{padding:0px; margin:0 0 0 10px;}
.footerpart .fa-arrow-circle-right{color: #f60;}
.footerpart{background: #f3f1f1;overflow: hidden;}
.tile-stats .icon i{font-size:40px;}
.tile-stats .icon{right: 30px;top: 10px;}
#todayModal .modal-title {color: #000;}
#todayModal .modal-body {background: #fafafa;overflow: hidden;}
#todayModal h3{color:#fff;margin-top: 5px;text-align: left;}
#todayModal h4{color:#fff;margin-top: 5px;}
.col1 {background: #0f4472;border-radius: 5px;margin: 0 auto;width: 100%;margin: 5px 0px;}
.col2 {background: #6f68ab;border-radius: 5px;margin: 0 auto;width: 100%;margin: 5px 0px;}
.col3 {background: #6f68ab;}
.col4 {background: #fafafa;}
.col5 {background: #fafafa;}
</style>

		