<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=yes">
<title>SkillAngels</title>
<!-- Bootstrap -->

	<link href="<?php echo base_url(); ?>assets/css/bootstrap.min.css" rel="stylesheet">
    <link href="<?php echo base_url(); ?>assets/css/font-awesome.min.css" rel="stylesheet">
    <link href="<?php echo base_url(); ?>assets/css/nprogress.css" rel="stylesheet">
    <link href="<?php echo base_url(); ?>assets/css/animate.min.css" rel="stylesheet">
    <link href="<?php echo base_url(); ?>assets/css/custom.min.css" rel="stylesheet">
<style>
.loading {
    position: fixed;
    z-index: 999;
    overflow: show;
    margin: auto;
    top: 0;
    left: 0;
    bottom: 0;
    right: 0;
    background: #5a5757 url(<?php echo base_url(); ?>assets/images/ajax-page-loader.gif) center center no-repeat;
    background-size: 5%;
    opacity: 0.6;
}
.ed6 {
    color: rgb(0, 170, 255);
    font-family: "Shadows Into Light",cursive;
    font-size: 2em;
}
.LoginContainer
{
	    BORDER: 2px solid;
    width: 50%;
    margin-left: 25%;
}
.submitlabel{padding-top:20px;padding-bottom:20px;}
.LoginContainer .fields{text-align:right;}
footer {
    margin-left: 0px !important;
	 color: #73879C;
}
input
{	 color: #73879C;
}
.landingContainer{padding-bottom:20px;}
body {
        //background:#73879C;
        background:#26b99a;
}
label.error {
    color: red;
    font-size: 15px;
    float: left;
}
</style>
</head>

<div class="login_wrapper">
        <div class="animate form login_form">
		 <div style="text-align: center;"><img src="<?php echo base_url(); ?>assets/images/brainy_logo.jpg" style="width: 50%; margin-right: 1%; margin-bottom: 0.5em;" alt="..." class="" />
		 </div>
               <section class="login_content">
            <form action="<?php echo base_url();?>index.php/home/logincheck" class="cmxform" method="POST" id="commentForm" accept-charset="utf-8">
              <h1>Center Login</h1>
			   <div class="green"></div>
					<div class="" style="padding-bottom: 20px; color:red; text-shadow:none;"><?php echo $msg_error;?></div>
              <div>
                <input type="text" name="username" value="" class="form-control required email" placeholder="Username" id="email">
              </div>
              <div>
                <input type="password" name="password" value="" class="form-control required" placeholder="Password" id="pwd">
              </div>
			 
              <!--<div style="float:left;">
                <a style="text-decoration:underline;" href="#" data-target="#pwdModal" data-toggle="modal">Forgot / Change Password</a>
              </div>-->
			  
              <div style="clear:both;">
                <input type="submit" class="btn btn-success" style="float:right;" id="submit" name="submit" value="Login">
				<span style="color:red;text-shadow: none;font-size:12px;float:left"><?php echo $error; ?></span>
              </div>


            
            </form>
          </section>
		  </div></div>
		 
<!--modal-->
<div id="pwdModal" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true">
 <div style="display:none;" id="loadingimg" class="loading">Loading...</div>
  <div class="modal-dialog">
  <div class="modal-content">
 
      <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
          <h1 class="text-center">Forgot / Change Your Password?</h1>
		  <div class="col-md-12" style="width:100%">
                <div class="panel panel-default">
                    <div class="panel-body">
                        <div class="text-center">
                          <form class="form-horizontal"  role="form" name="frmFP" id="frmFP">
                          <p>If you want to update your password you can reset it here.</p>
                            <div class="panel-body"><div id="msgFP" style="font-size: 18px;"></div>
                                <fieldset>
                                    <div class="form-group">
                                        <input class="form-control input-lg" placeholder="E-mail Address" name="txtemail" type="text" id="txtemail">
                                    </div>
                                    <input class="btn btn-lg btn-primary btn-block" value="Submit" type="button" id="btnpwd" name="btnpwd">
                                </fieldset>
                            </div>
							</form>
                        </div>
                    </div>
                </div>
            </div>
      </div>
       
       
  </div>
  </div>
</div>
				<script src="<?php echo base_url(); ?>assets/js/jquery.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/bootstrap.min.js"></script>
	<script src="<?php echo base_url(); ?>assets/js/jquery.validate.js"></script>
<script type="text/javascript">
$(document).ready(function() {
	$("#frmFP").validate({
	rules: {
	"txtemail": {required: true,email:true}
	},
	messages: {
	"txtemail": {required: "Please enter a email address"}
	},
	errorPlacement: function(error, element) {
	error.insertAfter(element);
	},
	highlight: function(input) {
	$(input).addClass('error');
	} 
	});
	$("#btnpwd").click(function(){
		if($("#frmFP").valid())
		{ 
			$(".loading").show();
			$.ajax({
				url: "<?php echo base_url(); ?>index.php/home/resetpwdlink", 
				type:'POST',
				data:{email:$("#txtemail").val()},
				success: function(result)
				{
					if(result==1)
					{
						$("#txtemail").attr('readonly', 'readonly');
						$("#msgFP").css("margin-bottom","10px").html("<div style='color:green'>Reset password link has beed send to your mail id.</div>");
					}
					else
					{	
						$("#msgFP").css("margin-bottom","10px").html("<div style='color:red'>Enter the valid registered email id</div>");
					}
					$(".loading").hide();
				}
			});
		}
	});
}); 
</script>