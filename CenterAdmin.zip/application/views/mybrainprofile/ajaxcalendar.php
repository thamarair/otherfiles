  <div class="bspicalender">

 <?php
$Yearmonth=explode("-", $yearMonthQry);
 
$month= $Yearmonth[1];
$year=$Yearmonth[0];
$day=date("d");
$endDate=date("t",mktime(0,0,0,$month,$day,$year));  ?> 


<?php
$s=date ("w", mktime (0,0,0,$month,1,$year));
//echo $s;

$ind=1;$fontColor='';
echo "<ul>";
for ($d=0;$d<$endDate+$s;$d++) {

if($d<$s){//echo "<li><span class='dLeft'><label>"; if($d<7){echo date("D",mktime (0,0,0,$month,$d-($s-1),$year)); } echo " </label></span></li>"; 
}

else {
if(isset($mybspiCalendar[str_pad($ind, 2, '0', STR_PAD_LEFT)])){

if(isset($myskillval[str_pad($ind, 2, '0', STR_PAD_LEFT)."-59"])){$ME=round($myskillval[str_pad($ind, 2, '0', STR_PAD_LEFT)."-59"],2);}else{$ME='-';}

if(isset($myskillval[str_pad($ind, 2, '0', STR_PAD_LEFT)."-60"])){$VP=round($myskillval[str_pad($ind, 2, '0', STR_PAD_LEFT)."-60"],2);}else{$VP='-';}

if(isset($myskillval[str_pad($ind, 2, '0', STR_PAD_LEFT)."-61"])){$FA=round($myskillval[str_pad($ind, 2, '0', STR_PAD_LEFT)."-61"],2);}else{$FA='-';}

if(isset($myskillval[str_pad($ind, 2, '0', STR_PAD_LEFT)."-62"])){$PS=round($myskillval[str_pad($ind, 2, '0', STR_PAD_LEFT)."-62"],2);}else{$PS='-';}

if(isset($myskillval[str_pad($ind, 2, '0', STR_PAD_LEFT)."-63"])){$LI=round($myskillval[str_pad($ind, 2, '0', STR_PAD_LEFT)."-63"],2);}else{$LI='-';}

$data="
<table><tr><td>Memory &nbsp;&nbsp;</td><td> &nbsp;&nbsp;".$ME."</td/></tr>
<tr><td>Visual Processing &nbsp;&nbsp;</td><td> &nbsp;&nbsp;".$VP."</td/></tr>
<tr><td>Focus & Attention &nbsp;&nbsp;</td><td> &nbsp;&nbsp;".$FA."</td/></tr>
<tr><td>Problem Solving &nbsp;&nbsp;</td><td> &nbsp;&nbsp;".$PS."</td/></tr>
<tr><td>Linguistics &nbsp;&nbsp;</td><td> &nbsp;&nbsp;".$LI."</td/></tr></table>";
}
else{
	$data="";
}
	echo "<li data-toggle='tooltip' data-placement='top' data-html='true' 
		title='".$data."'>
		<span class='dLeft'><label>";  {echo  $ind; } echo " </label>";   echo"</span>";
	if(isset($mybspiCalendar[str_pad($ind, 2, '0', STR_PAD_LEFT)])){
	echo '<span class="dMiddle"><img src="'.base_url().'assets/images/braintrained1.png"></span>
 <span class="dRight">'.round($mybspiCalendar[str_pad($ind, 2, '0', STR_PAD_LEFT)],2).'</span>';
	}
	echo "</li>";
$ind++;	
}



}
echo "</ul>"; 
?>
 
  <div class="brainTrainedBottom" style="clear: both;"> 
 <span><img src="<?php echo base_url();?>assets/images/braintrained1.png" > Brain Trained</span>
 </div> </div> 
 <script type="text/javascipt">
    $('[data-toggle="tooltip"]').tooltip(); 
 </script>
 <style>
 .tooltip-inner{line-height:20px;}
 <style>