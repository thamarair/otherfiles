
        <div class="right_col" role="main">
          <!-- top tiles -->
          
<!-- /top tiles -->
<div class="row">

<div class="col-md-6 col-sm-6 col-xs-6">
<div class="x_panel tile" style="min-height: 280px;">
<div class="x_title">
<h2 class="reporttitle">Change Password</h2>
<div class="clearfix"></div>
</div>
<div class="clearfix"></div>
<div class="row">
<div  id="successmsg" style="color: green;font-size: 15px;text-align: center;font-weight: 600;"></div>
<div class="animated flipInY col-lg-6 col-md-6 col-sm-6 col-xs-12">

		<div class="col-lg-12">
	  <div class="form-group">
	  <form name="frmpwd" id="frmpwd" class="" method="post" action="" accept-charset="utf-8">
		<label for="txtpwd">New Password<span style="color:red">*</span></label>
		<input type="password" maxlength="12"  class="form-control"  name="txtpwd" value="" id="txtpwd" />
		<br/>
		<label for="txtcpwd">Confirm Password<span style="color:red">*</span></label>
		<input type="password" maxlength="12"  class="form-control" name="txtcpwd" value="" id="txtcpwd" />
		
	  </div> 
  </div>
  
  <div class="col-lg-6" style="margin-top: 21px;">
	  <div class="form-group">
		<input type="button" id="btnchange" style="float:none;" class="btn btn-success btnchange" value="Change">
</form>
	  </div> 
  </div>
 
</div>
<div id="successmsg" style="color: green; text-align: center;"></div>
</div>




</div>
</div>


</div>
	</div>
	<style>
	 .error { color : red; }
	</style>
	

	
	
   