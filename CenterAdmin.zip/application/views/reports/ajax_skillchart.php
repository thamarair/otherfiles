<?php 
//error_reporting(E_ALL);
?>
<?php if(isset($bspi) && $bspi!=''){
if($type=="BASIC")
{?><div class="col-md-12 col-sm-12 col-xs-12 text-center">
	<div class="col-md-6 col-sm-6 col-xs-12 text-center">
		<div class="chartbd">
			<div class="panel panel-default minhe3" style="background: #fff;">
				<div class="panel-body">
				<h2 class="Mh2">Skill Score</h2>
					<div class="reportChartContainer1">
						<div id="SkillChart"></div>
						<?php
							/* foreach($skills as $skillid)
							{
								if(isset($SkillChart[$skillid['id']]) && $SkillChart[$skillid['id']]!='')
								{
									$Width=$SkillChart[$skillid['id']];
									$Score=round($SkillChart[$skillid['id']],2);
								}
								else
								{
									$Width="10";
									$Score=0;
								} */
								 
							?>
							<!--<div class="cb">
								<p class="PskillName pt0"><?php echo $skillid['name']; ?></p>
								<div class="meter mt10">
									<span class="" id="mem" style="width:<?php echo $Width."%"; ?>;background-color:<?php echo $skillid['colorcode']; ?>"><?php echo $Score; ?></span>
								</div>
							</div>-->
							<?php
							//}
							?>
					 </div> 
				</div>
			</div>
		</div>
	</div>
	<div class="col-md-6 col-sm-6 col-xs-12">
		<div class="chartbd">
			<div class="panel panel-default minhe3" style="background: #fff;">
				<div class="panel-body">
					<h2 class="Mh2"><?php echo $CurrentBSPIName['0']['name']; ?></h2>
						<div id="score" class="block"  style="text-align:center; font-size: 25px;font-weight: bold;"><?php echo round($bspi,2); ?></div>
					<div class="" style="background: #fff;">
						<div id="chart-container5"  style=""></div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<?php 
}
else
{
?>
<div class="col-md-12 col-sm-12 col-xs-12 text-center">
	<div class="col-md-6 col-sm-6 col-xs-12 text-center">
		<div class="chartbd"> 
			<div class="panel panel-default minhe3" style="background: #fff;">
				<div class="panel-body">
				<h2 class="Mh2">Skill Score</h2>
					<div class="reportChartContainer1">
						<div id="AdvanceSkillChart"></div>
					<?php
					/* if(isset($SkillChart["SID59"]) && $SkillChart["SID59"]!='')
					{
						$meWidth=$SkillChart["SID59"];
						$meScore=round($SkillChart["SID59"],2);
					}
					else
					{
						$meWidth="10";
						$meScore=0;
					}
					if(isset($SkillChart["SID60"]) && $SkillChart["SID60"]!='')
					{
						$vpWidth=$SkillChart["SID60"];
						$vpScore=round($SkillChart["SID60"],2);
					}
					else
					{
						$vpWidth="10";
						$vpScore=0;
					}
					if(isset($SkillChart["SID61"]) && $SkillChart["SID61"]!='')
					{
						$faWidth=$SkillChart["SID61"];
						$faScore=round($SkillChart["SID61"],2);
					}
					else
					{
						$faWidth="10";
						$faScore=0;
					}
					if(isset($SkillChart["SID62"]) && $SkillChart["SID62"]!='')
					{
						$psWidth=$SkillChart["SID62"];
						$psScore=round($SkillChart["SID62"],2);
					}
					else
					{
						$psWidth="10";
						$psScore=0;
					}
					if(isset($SkillChart["SID63"]) && $SkillChart["SID63"]!='')
					{
						$liWidth=$SkillChart["SID63"];
						$liScore=round($SkillChart["SID63"],2);
					}
					else
					{
						$liWidth="10";
						$liScore=0;
					} */
					?>
							<!--<div class="cb">
								<p class="PskillName pt0">Memory</p>
								<div class="meter mt10">
									<span class="redColor" id="mem" style="width:<?php echo $meWidth."%"; ?>"><?php echo $meScore; ?></span>
								</div>
							</div>
							<div class="cb">
								<p class="PskillName">Visual Processing</p>
								<div class="meter mt10">
									<span class="yellowColor" id="vp" style="width:<?php echo $vpWidth."%"; ?>"><?php echo $vpScore; ?></span>
								</div>
							</div>
							<div class="cb">
								<p class="PskillName">Focus & Attention</p>
								<div class="meter mt10">
									<span class="greenColor" id="focus" style="width:<?php echo $faWidth."%"; ?>"><?php echo $faScore; ?></span>
								</div>
							</div>
							<div class="cb">
								<p class="PskillName">Problem Solving</p>
								<div class="meter mt10">
									<span class="orangeColor" id="problem" style="width:<?php echo $psWidth."%"; ?>"><?php echo $psScore; ?></span>
								</div>
							</div>
							<div class="cb">
								<p class="PskillName">Linguistics</p>
									<div class="meter mt10">
										<span class="blueColor" id="ling" style="width:<?php echo $liWidth."%"; ?>"><?php echo $liScore; ?></span>
									</div>
							</div>-->
					 </div>
				</div>
			</div>
		</div>
	</div>
	<div class="col-md-6 col-sm-6 col-xs-12">
		<div class="chartbd">
			<div class="panel panel-default minhe3" style="background: #fff;">
				<div class="panel-body">
					<h2 class="Mh2"><?php echo $CurrentBSPIName['0']['name']; ?></h2>
					<div id="score1" class="block"  style="text-align:center; font-size: 25px;font-weight: bold;"><?php echo round($bspi,2); ?></div>
					<div class="" style="background: #fff;">
						<div id="chart-container4"  style=""></div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<?php 
}}else{
?><div class="col-md-12 col-sm-12 col-xs-12 text-center">	<div class="col-md-12 col-sm-12 col-xs-12 text-center">		<div class="chartbd">  			<div class="panel panel-default" style="background: #fff;">				<div class="panel-body">					<div class="reportChartContainer1">						<div style="background:#d05858;color:#fff;">No data found</div>					</div>				</div>			</div>		</div>	</div></div><?php }?>
<script src="<?php echo base_url(); ?>assets/fusioncharts/js/fusioncharts.js"></script>
<script src="<?php echo base_url(); ?>assets/fusioncharts/js/fusioncharts.theme.fint.js"></script>
<script src="<?php echo base_url(); ?>assets/fusioncharts/js/fusioncharts.widgets.js"></script>
<script>
<?php 
if(isset($bspi) && $bspi!='')
{ 
	if($type=="BASIC")
	{
?>
	Highcharts.chart('SkillChart', {
		colors: ['#058DC7', '#50B432', '#ED561B', '#DDDF00', '#24CBE5', '#64E572', 
             '#FF9655', '#FFF263', '#6AF9C4'],
		chart: {
			type: 'cylinder',
			backgroundColor: {
				linearGradient: [0, 0, 500, 500],
				stops: [
					[0, 'rgb(255, 255, 255)'],
					[1, 'rgb(240, 240, 255)']
				]
			},

			options3d: {
				enabled: true, 
				viewDistance: 25
			}
		},
		title: {
			text: ''
		},
		credits: {
            enabled: false
        },
		xAxis: 
		{
			categories:[
			<?php $i=0;
			foreach($skills as $skillid)
			{
				$i++;
				if($i>1){echo ",";}
				echo "'".$skillid['name']."'";
			}
			?>
			],
			labels: {
				skew3d: true,
				style: {
					fontSize: '16px'
				}
			}
		},
		yAxis: {
            min: 0,
            max: 100,
            tickInterval: 25
		},
		plotOptions: {
			series: {
				depth: 25,
				colorByPoint: true,
				dataLabels: {
					enabled: true,
					format: '{point.y:.f}'
				}
			}
		},
		series: [{
			data: [
			<?php $i=0;
			foreach($skills as $skillid)
			{
				$i++;
				if($i>1){echo ",";}
				if(isset($SkillChart[$skillid['id']]) && $SkillChart[$skillid['id']]!='')
				{
					$Score=round($SkillChart[$skillid['id']],2);
				}
				else
				{
					$Score=0;
				}
				echo $Score;
			}
			?>
			],
			name: 'Score',
			showInLegend: false
		}]
	}); 
	
	FusionCharts.ready(function () {
    var csatGauge = new FusionCharts({
        "type": "angulargauge",
        "renderAt": "chart-container5","background":"transparent",
        "width": "100%",
        "height": "250",
        "dataFormat": "json",
            "dataSource": 
			{
				"chart": 
				{
					"caption": "",
					"lowerlimit": "0",
					"upperlimit": "100",
					"bgAlpha":'0',
					"gaugeFillRatio": "15",
					"theme": "fint" 
				},
				"colorrange": 
				{
					"color": 
					[
						{
							"minvalue": "0",
							"maxvalue": "20",
							"code": "c01f25"
						},
						{
							"minvalue": "20",
							"maxvalue": "40",
							"code": "f36621"
						},
						{
							"minvalue": "40",
							"maxvalue": "60",
							"code": "fdc010"
						},
						{
							"minvalue": "60",
							"maxvalue": "80",
							"code": "94c953"
						},
						{
							"minvalue": "80",
							"maxvalue": "100",
							"code": "00b04e"
						}
					]
				},
				"dials": {
					"dial": [
						{
							"value": <?php echo round($bspi,2); ?>,
							"rearextension": "15",
							"radius": "100",
							"bgcolor": "333333",
							"bordercolor": "333333",
							"basewidth": "8"
						}
					]
				}
		}
      });

csatGauge.render();
});
<?php 
}
else
{
?>
Highcharts.chart('AdvanceSkillChart', {
		colors: ['#058DC7', '#50B432', '#ED561B', '#DDDF00', '#24CBE5', '#64E572', 
             '#FF9655', '#FFF263', '#6AF9C4'],
		chart: {
			type: 'cylinder',
				backgroundColor: {
				linearGradient: [0, 0, 500, 500],
				stops: [
					[0, 'rgb(255, 255, 255)'],
					[1, 'rgb(240, 240, 255)']
				]
			},
			options3d: {
				enabled: true,
				 
				viewDistance: 25
			}
		},
		title: {
			text: ''
		},
		credits: {
            enabled: false
        },
		xAxis: 
		{
			categories:[<?php $i=0;
			foreach($skills as $skillid)
			{
				$i++;
				if($i>1){echo ",";}
				echo "'".$skillid['name']."'";
			}
			?>],
			labels: {
				skew3d: true,
				style: {
					fontSize: '16px'
				}
			}
		},
		yAxis: {
            min: 0,
            max: 100,
            tickInterval: 25
		},
		plotOptions: {
			series: {
				depth: 25,
				colorByPoint: true,
				dataLabels: {
					enabled: true,
					format: '{point.y:.f}'
				}
			}
		},
		series: [{
			data: [
			<?php $j=0;
			foreach($skills as $skillid)
			{
				$j++;
				if($j>1){echo ",";}
				if(isset($SkillChart["SID".$skillid['id']]) && $SkillChart["SID".$skillid['id']]!='')
				{
					$Score=round($SkillChart["SID".$skillid['id']],2);
				}
				else
				{
					$Score=0;
				}
				echo $Score;
			}
			?>		
			],
			name: 'Score',
			showInLegend: false
		}]
	});
FusionCharts.ready(function () {
    var csatGauge = new FusionCharts({
        "type": "angulargauge",
        "renderAt": "chart-container4","background":"transparent",
        "width": "100%",
        "height": "250",
        "dataFormat": "json",
            "dataSource": 
			{
				"chart": 
				{
					"caption": "",
					"lowerlimit": "0",
					"upperlimit": "100",
					"bgAlpha":'0',
					"gaugeFillRatio": "15",
					"theme": "fint" 
				},
				"colorrange": 
				{
					"color": 
					[
						{
							"minvalue": "0",
							"maxvalue": "20",
							"code": "c01f25"
						},
						{
							"minvalue": "20",
							"maxvalue": "40",
							"code": "f36621"
						},
						{
							"minvalue": "40",
							"maxvalue": "60",
							"code": "fdc010"
						},
						{
							"minvalue": "60",
							"maxvalue": "80",
							"code": "94c953"
						},
						{
							"minvalue": "80",
							"maxvalue": "100",
							"code": "00b04e"
						}
					]
				},
				"dials": {
					"dial": [
						{
							"value": <?php echo round($bspi,2); ?>,
							"rearextension": "15",
							"radius": "100",
							"bgcolor": "333333",
							"bordercolor": "333333",
							"basewidth": "8"
						}
					]
				}
		}
      });

csatGauge.render();
});
<?php 
}
}
?>

 
</script>
<style>
.minhe3{min-height:469px;}
</style>