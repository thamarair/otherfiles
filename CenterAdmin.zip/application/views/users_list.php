 <div class="right_col" role="main">
          <div class="">
            <div class="page-title">
              <div class="title_left">
                <h3>User List</h3>
              </div>
            </div>

            <div class="clearfix"></div>

            <div class="row">
              <div class="col-md-12">
			  <div class="loading" style="display:none;" ><img src="<?php echo base_url(); ?>assets/images/ajax-page-loader.gif" style="width:80px;" /></div>
                <div class="x_panel" id="postList">
				<?php echo $this->ajax_pagination->create_links(); ?>
                  <div class="x_content">
                    <div class="row">
                      <div class="col-md-12 col-sm-12 col-xs-12 text-center"> 
                      </div>

                      <div class="clearfix"></div>
<?php 
	$ini=0; 
	foreach($userslist as $res){
	$ini++;
	?>	
                      <div class="col-md-4 col-sm-4 col-xs-12 profile_details">
                        <div class="well profile_view" style="background:#f4f7ff">
                          <div class="col-sm-12" style="min-height: 220px;">
						  <div class="col-sm-6">
                            <h4 class="brief"><i><b><?php echo $res['fname']; ?></b></i></h4></div>
							<div class="col-sm-6">
                            <h5 style="float:right" class="brief"><i><b> Grade : <?php echo str_replace("Grade","", $res['grade']); ?></b></i></h5></div>
                            <div class="left col-xs-7 <?php if($res['status']==0) { ?> inactiveelement <?php } ?>">
                              <ul class="list-unstyled">
							  <?php if($res['father']!='') { ?>
							  <li><i class="fa fa-user"></i> <?php echo $res['father']; ?></li><?php } ?>
							  <?php if($res['dob']!='') { ?>
							  <li><i class="fa fa-birthday-cake"></i> <?php echo date('d-m-Y',strtotime($res['dob'])); ?></li><?php } ?>
							<!--<li>Grade : <?php echo str_replace("Grade","", $res['grade']); ?></li>-->
								<?php if($res['creation_date']!='0000-00-00') { ?>
								<li>Created Date : <?php echo date('d-m-Y',strtotime($res['creation_date'])); ?></li><?php } ?>
                              </ul>
                            </div>
							
                          </div>
                          <div class="col-xs-12 bottom text-center" style="background:#93c5c7">
                            <div class="col-xs-12 col-sm-6 emphasis">
                            </div>
                            <div class="col-xs-12 col-sm-6 emphasis">
                              
                              <a style="float:right" href="<?php echo base_url(); ?>index.php/home/userview/<?php echo $res['id']; ?>" class="btn btn-success btn-xs">
                                <i class="fa fa-user"> </i> View Details
                              </a>
                            </div>
                          </div>
                        </div>
	</div><?php } ?>
                    </div>
					<?php echo $this->ajax_pagination->create_links(); ?>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>	
		


<script src="<?php echo base_url(); ?>assets/js/jquery.min.js" type="text/javascript"></script>

<script>
function searchFilter(page_num) {
    page_num = page_num?page_num:0;
    var keywords = $('#keywords').val();
    var sortBy = $('#sortBy').val();
    $.ajax({
        type: 'POST',
        url: '<?php echo base_url(); ?>index.php/home/userlist_PaginationData/'+page_num,
        data:'page='+page_num,
        beforeSend: function () {
            $('.loading').show();
        },
        success: function (html) {
            $('#postList').html(html);
            $('.loading').fadeOut("slow");
        }
    });
}
</script>
<style>
.reporttitle { color:#1abb9c; }
thead{ background-color: #1abb9c; color: #fff;}

.pagination a{background: #ca0f0f;padding: 7px;color:#fff}
.pagination b{background: #15cc46;padding: 7px;color:#fff}
.pagination{float:right;}


.loading {
  position: fixed;
  z-index: 999;
  height: 2em;
  width: 2em;
  overflow: show;
  margin: auto;
  top: 0;
  left: 0;
  bottom: 0;
  right: 0;
}

.loading:before {
  content: '';
  display: block;
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background-color: rgba(0,0,0,0.3);
}

/* :not(:required) hides these rules from IE9 and below */
.loading:not(:required) {
  /* hide "loading..." text */
  font: 0/0 a;
  color: transparent;
  text-shadow: none;
  background-color: transparent;
  border: 0;
}
</style>
