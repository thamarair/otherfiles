<footer style="text-align:center;">
<div class="schooltitle" style="display:inline;"><span style="font-size:17px;" class="topHead"> Powered By </span><img src="<?php echo base_url(); ?>assets/images/web_logo1.png" style="margin-bottom:5px;"  width="150" ></div>
          <!--<div class="pull-right">
            Copyright © <?php echo date("Y"); ?> SkillAngels. All rights reserved.
          </div>-->
          <div class="clearfix"></div>
        </footer>
        <!-- /footer content -->
	<script src="<?php echo base_url(); ?>assets/js/jquery.min.js"></script>
	<script src="<?php echo base_url(); ?>assets/js/jquery.validate.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/bootstrap.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/fastclick.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/nprogress.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/Chart.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/gauge.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/bootstrap-progressbar.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/icheck.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/skycons.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/jquery.flot.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/jquery.flot.pie.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/jquery.flot.time.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/jquery.flot.stack.js"></script>
	<script src="<?php echo base_url(); ?>assets/js/jquery.flot.resize.js"></script>
	

    <script src="<?php echo base_url(); ?>assets/js/jquery.flot.orderBars.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/jquery.flot.spline.min.js"></script>
	<script src="<?php echo base_url(); ?>assets/js/curvedLines.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/date.js"></script>
	
	<script src="<?php echo base_url(); ?>assets/js/jquery.vmap.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/jquery.vmap.world.js"></script>
	<script src="<?php echo base_url(); ?>assets/js/jquery.vmap.sampledata.js"></script>
	
    <script src="<?php echo base_url(); ?>assets/js/moment.min.js"></script>
	<script src="<?php echo base_url(); ?>assets/js/daterangepicker.js"></script>
		 
	<script src="<?php echo base_url(); ?>assets/js/custom.js"></script>
	
	<script src="<?php echo base_url(); ?>assets/js/moment.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/fullcalendar.min.js"></script>
	<!-- FullCalendar -->
    <link href="<?php echo base_url(); ?>assets/css/fullcalendar.min.css" rel="stylesheet">
    <link href="<?php echo base_url(); ?>assets/css/fullcalendar.print.css" rel="stylesheet" media="print">
	
	<script src="<?php echo base_url(); ?>assets/js/jquery.dataTables.js" type="text/javascript"></script>
	<script src="<?php echo base_url(); ?>assets/js/dataTables.tableTools.js" type="text/javascript"></script>
	
	<link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/zebra/zebra_datepicker.min.css" type="text/css">
	<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/zebra/zebra_datepicker.min.js"></script>
	
	<script src="<?php echo base_url(); ?>assets/js/zabuto_calendar.min.js"></script>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/css/zabuto_calendar.min.css">


	<script type="text/javascript">
		$( document ).ready(function() {
			
			jQuery.validator.addMethod("noSpace", function(value, element) { 
  return value.indexOf(" ") < 0 && value != ""; 
}, "No space please and don't leave it empty");

			setInterval(LoginAjaxCall, 1000*60*1); //300000 MS == 5 minutes
			LoginAjaxCall();

			$("#calview").click(function() {
				$("#tableview").hide();
				$("#chartview").hide();
				$("#calendarview").show();
				$("#todayfilter").show();
			});
			$("#tblview").click(function() {
				$("#tableview").show();
				$("#chartview").hide();
				$("#calendarview").hide();
				$("#todayfilter").show();
			});
			$("#chview").click(function() {
				$("#tableview").hide();
				$("#chartview").show();
				$("#calendarview").hide();
				$("#todayfilter").show();
			});
		});
		
		function LoginAjaxCall(){ 		
		$.ajax({
			type:"POST",
			url:"<?php echo base_url('index.php/home/checkuserisactive') ?>",
			success:function(result)
			{	//alert(result);
			///	if(result==1)
			//	{ 
					
			//		window.location.href= "<?php echo base_url();?>index.php";
			//	}		
			}
		});
		}
		
		
		
	</script>
	
	<script>
	$("#frmpwd").validate({
		rules : {
                txtpwd : {required:true,  minlength : 6 },
                txtcpwd : {required:true, equalTo : "#txtpwd" }
            },
			
		messages: {
            "txtpwd": {required: "Please enter password"},
			"txtcpwd": {required: "Please enter confirm password", equalTo:"Please enter same password as confirm password" }
           
        },
		
		
		errorPlacement: function(error, element) {
    if (element.attr("type") === "radio") {
        error.insertAfter(element.parent().parent());
    } 
	else {
        error.insertAfter(element);
    }
	
},
		highlight: function(input) {
           // $(input).addClass('error');
        } 
    });
	
	$('#btnchange').click(function(){
		//alert('true');
		if($("#frmpwd").valid()==true)
		{
			var pwd = $("#txtpwd").val(); 
			
			$.ajax({
			type:"POST",
			data:{pwd:pwd},
			url:"<?php echo base_url('index.php/home/resetpwd') ?>",
			success:function(result)
			{		
			
			if(result==1)
			{
				$("#frmpwd")[0].reset();
				$('#successmsg').html('Your Password Updated Successfully');
			//window.location.href= "<?php echo base_url();?>index.php/home/userperformance";
			}
			
			}
		});
		}		
	});
	
$('.numbersOnly').keyup(function () { 
    this.value = this.value.replace(/[^0-9]/g,'');
});



$('.alphaOnly').keyup(function () { 
    this.value = this.value.replace(/[^a-zA-Z ]/g,'');
});

 
 $('#txtstartdate').Zebra_DatePicker({
    direction: true,
	 format: 'd-m-Y'
});

 $("#frmRegister").validate({
        rules: {
            "txtname": {required: true},
			"ddlgrade": {required: true},
			"txtgender": {required: true},
			"txtusername": {required: true,noSpace:true},
			"txtemail": {email: true},
            "txtmobile": {minlength: 10},
			"txtstartdate": {required: true}
        },
        messages: {
            "txtname": {required: "Please enter name"},
			"ddlgrade": {required: "Please select grade"},
			"txtgender": {required: "Please choose gender"},
			"txtusername": {required: "Please enter username"},
            "txtemail": {email: "Please enter valid email id"},
			"txtmobile": {minlength:"Please enter valid mobile number" },
			"txtstartdate": {required:"Please select startdate" }
        },
		errorPlacement: function(error, element) {
    if (element.attr("type") === "radio") {
        error.insertAfter(element.parent().parent());
    } 
	else if (element.attr("id") === "txtMobile") {
        error.insertAfter(element.parent());
    } 
	
	else if (element.attr("id") === "txtSMobile") {
        error.insertAfter(element.parent());
    } 
	else {
        error.insertAfter(element);
    }
	
},
		highlight: function(input) {
           // $(input).addClass('error');
        } 
    });
	
	
		
		$("#txtusername").keyup(function(e){
			
			var username = $(this).val();
			
			 if(e.keyCode == 32){
       $('#errormsg').html("No space please and don't leave it empty");
	   //$('#regsubmit').prop('disabled', true);
   }
   
			$.ajax({
			type:"POST",
			data:{username:username},
			url:"<?php echo base_url('index.php/home/usernamecheck') ?>",
			success:function(result)
			{		
			$('.loading').fadeOut("slow");
//		alert(result);
			if(result==1)
			{
				$('#errormsg').html('Username already exist');
				$('#regsubmit').prop('disabled', true);
			}
			else{
				
				$('#errormsg').html('');
				$('#regsubmit').prop('disabled', false);
			}
			
			}
		});
			
		});
		
		
	
	
	$('#regsubmit').click(function(){
		//alert('true');
		//checkalreadyexist();
		
		if($("#frmRegister").valid()==true)
		{
			
			var name = $('#txtname').val();
			var grade = $('#ddlgrade').val();
			var gender = $('#txtgender').val();
			var username = $('#txtusername').val();
			var mobile = $('#txtmobile').val();
			var emailid = $('#txtemail').val();
			var startdate = $('#txtstartdate').val();
			$('.loading').show();
			$.ajax({
			type:"POST",
			data:{name:name,grade:grade,gender:gender,username:username,mobile:mobile,emailid:emailid,startdate:startdate},
			url:"<?php echo base_url('index.php/home/addsummercampuser') ?>",
			success:function(result)
			{		
			$('.loading').fadeOut("slow");
		//alert(result);
		if(result==0) 
			{
				//$("#frmRegister")[0].reset();
				$("#frmRegister").hide();
				$('#licenseexpiremsg').html('Your License has Expired');
			}
		else if(result==1)
			{
				$("#frmRegister")[0].reset();
				$('#successmsg').html('User Added Successfully');
			//window.location.href= "<?php echo base_url();?>index.php/home/userperformance";
			}
			
			
			}
		});
			
			
			
		}
	});
	
	
	</script>
	 </div>
    </div>
	<div id="todayModal" class="modal fade" role="dialog">
  <div class="modal-dialog modal-lg" id="welcomecontainer">
    <!-- Modal content-->
    <div class="modal-content" style="box-shadow: none;border: none;">
      <div class="modal-header" style="text-align:center;">
<button type="button" class="close" data-dismiss="modal" style="color: #000;opacity: 1;font-size: 30px;
">&times;</button>
			<h3 class="modal-title" id="curday" style="text-align: center;"></h3>
      </div>
      <div class="modal-body"  style="padding:0px;">
	  <div>
	   <div class="col-md-12 col-sm-12 col-xs-12" style="margin-top: 10px;">
	   
	   <div class="col-md-3 col-sm-3 col-xs-12 "><div class="col-md-12 col-sm-12 col-xs-12 counters" >Questions Attempted</div><div class="col-md-12 col-sm-12 col-xs-12 counters"  id="CURPuzzlesAttempted"></div></div>
	   
	    <div class="col-md-3 col-sm-3 col-xs-12 "><div class="col-md-12 col-sm-12 col-xs-12 counters" >Questions Solved</div><div class="col-md-12 col-sm-12 col-xs-12 counters"  id="CURPuzzlesSolved"></div></div>
		
		 <div class="col-md-3 col-sm-3 col-xs-12 "><div class="col-md-12 col-sm-12 col-xs-12 counters">Minutes Trained</div><div class="col-md-12 col-sm-12 col-xs-12 counters"  id="CURMinutesTrained"></div></div>
		 
		  <div class="col-md-3 col-sm-3 col-xs-12 "><div class="col-md-12 col-sm-12 col-xs-12 counters" >Crownies</div><div class="col-md-12 col-sm-12 col-xs-12 counters"  id="CURCrownies"></div></div>
	   </div></div>
	   
	   
	  <div class="col-md-12 col-sm-12 col-xs-12 text-center" style="margin-top:15px;">
			<div class="col-md-6 col-sm-6 col-xs-12 text-center">
				<h2 class="Mh2">Skill Score</h2>
					<div class="" style="background: #fff; border-color:#FFF;">
                        <div class="panel-body">
					<div class="reportChartContainer1">
                            <div class="cb">
                            	<p class="PskillName pt0">Memory</p>
                                	
                            	<div class="meter mt10">
                                	<span class="redColor" id="mem"></span>
								</div>
                            </div>
                            <div class="cb">
                            	<p class="PskillName">Visual Processing</p>
                            	<div class="meter mt10">
  									<span class="yellowColor" id="vp"></span>
								</div>
                            </div>
                            <div class="cb">
                            	<p class="PskillName">Focus & Attention</p>
                            	<div class="meter mt10">
  									<span class="greenColor" id="focus"></span>
								</div>
                            </div>
                            <div class="cb">
                            	<p class="PskillName">Problem Solving</p>
                            	<div class="meter mt10">
  									<span class="orangeColor" id="problem"></span>
								</div>
                            </div>
                            <div class="cb">
                            	<p class="PskillName">Linguistics</p>
                            		<div class="meter mt10">
  										<span class="blueColor" id="ling"></span>
									</div>
                            </div>
                     </div>
				
				</div>
				</div>
			</div>
			
			<div class="col-md-6 col-sm-6 col-xs-12 text-center">
			<h2 class="Mh2">BSPI</h2>
			<div id="score" class="block"  style="text-align:center; font-size: 25px;font-weight: bold;"></div>
			<div id="chart-container"  style=""></div>

			</div>
			
			</div>
			
      </div>
    </div>
  </div>
</div>
  </body>
</html>

<style>
.dateinfo .count{font-size:20px;color:#337ab7;font-weight: bold;display:block;padding-left:20px;}
.dateinfo .count_top{font-size:15px;font-weight: bold;}
.toppart h4{padding:0px; margin:0 0 0 10px;}
.footerpart .fa-arrow-circle-right{color: #f60;}
.footerpart{background: #f3f1f1;overflow: hidden;}
.tile-stats .icon i{font-size:40px;}
.tile-stats .icon{right: 30px;top: 10px;}
#todayModal .modal-title {color: #000;}
#todayModal .modal-body {background: #FFF; overflow: hidden;}
#todayModal h3{color:#fff;margin-top: 5px;text-align: left;}
#todayModal h4{color:#fff;margin-top: 5px;}
.col1 {background: #0f4472;border-radius: 5px;margin: 0 auto;width: 100%;margin: 5px 0px;}
.col2 {background: #6f68ab;border-radius: 5px;margin: 0 auto;width: 100%;margin: 5px 0px;}
.col3 {background: #6f68ab;}
.col4 {background: #fafafa;}
.col5 {background: #fafafa;}

.reportChartContainer1 {
   
    overflow: hidden;
}
.cb {
    clear: both;
}
.PskillName {
    float: left;
    width: 34.5%;
    display: inline-block;
    padding: 10px 0 11px 0;
    border-right: 1px solid #000;
    margin-bottom: 0;    color: #000;
	font-size:13px !important;
	line-height:25px; !important;
}
div.meter {
    float: left;
    width: 65%;
    height: 25px;
    border: 1px solid #b0b0b0;
    -webkit-box-shadow: inset 0 3px 5px 0 #d3d0d0;
    -moz-box-shadow: inset 0 3px 5px 0 #d3d0d0;
    box-shadow: inset 0 3px 5px 0 #d3d0d0;
    -webkit-border-radius: 3px;
    -moz-border-radius: 3px;
    -ms-border-radius: 3px;
    -o-border-radius: 3px;
    border-radius: 3px;
}
.mt10 {
    margin-top: 9px;
}
div.meter span {
    color: #fff;
    top: 0;
    line-height: 0px;
    padding-left: 7px;
    font-weight: bold;
    text-align: right;
    padding-right: 5px;
    display: block;
    height: 100%;
    animation: grower 1s linear;
    -moz-animation: grower 1s linear;
    -webkit-animation: grower 1s linear;
    -o-animation: grower 1s linear;
    position: relative;
    left: -1px;
    -webkit-border-radius: 3px;
    -moz-border-radius: 3px;
    -ms-border-radius: 3px;
    -o-border-radius: 3px;
    border-radius: 3px;
    -webkit-box-shadow: inset 0px 3px 5px 0px rgba(0, 0, 0, 0.2);
    -moz-box-shadow: inset 0px 3px 5px 0px rgba(0, 0, 0, 0.2);
    box-shadow: inset 0px 3px 5px 0px rgba(0, 0, 0, 0.2);
    background-image: -webkit-gradient(linear, 0 0, 100% 100%, color-stop(0.25, rgba(255, 255, 255, 0.2)), color-stop(0.25, transparent), color-stop(0.5, transparent), color-stop(0.5, rgba(255, 255, 255, 0.2)), color-stop(0.75, rgba(255, 255, 255, 0.2)), color-stop(0.75, transparent), to(transparent));
    background-image: -webkit-linear-gradient(45deg, rgba(255, 255, 255, 0.2) 25%, transparent 25%, transparent 50%, rgba(255, 255, 255, 0.2) 50%, rgba(255, 255, 255, 0.2) 75%, transparent 75%, transparent);
    background-image: -moz-linear-gradient(45deg, rgba(255, 255, 255, 0.2) 25%, transparent 25%, transparent 50%, rgba(255, 255, 255, 0.2) 50%, rgba(255, 255, 255, 0.2) 75%, transparent 75%, transparent);
    background-image: -ms-linear-gradient(45deg, rgba(255, 255, 255, 0.2) 25%, transparent 25%, transparent 50%, rgba(255, 255, 255, 0.2) 50%, rgba(255, 255, 255, 0.2) 75%, transparent 75%, transparent);
    background-image: -o-linear-gradient(45deg, rgba(255, 255, 255, 0.2) 25%, transparent 25%, transparent 50%, rgba(255, 255, 255, 0.2) 50%, rgba(255, 255, 255, 0.2) 75%, transparent 75%, transparent);
    -webkit-background-size: 45px 45px;
    -moz-background-size: 45px 45px;
    -o-background-size: 45px 45px;
    background-size: 45px 45px;
}
.redColor {
    background: #e81919;
}
.yellowColor {
    background: #ffa300;
    margin-bottom: 10px;
}
.greenColor {
    background: #8bcc46;
    margin-bottom: 10px;
}
.orangeColor {
    background: #f16202;
    margin-bottom: 10px;
}
.blueColor {
    background: #0ab7f6;
    margin-bottom: 10px;
}
div.meter span:before {
    content: '';
    display: block;
    width: 100%;
    height: 50%;
    position: relative;
    top: 50%;
    background: rgba(0, 0, 0, 0.03);
}

.counters { text-align:center; font-size:18px; background: crimson;
    margin-right: 4px; color:#fff; }
	
.Mh2 { font-size: 25px; font-weight: 400; position: relative; color: #ff6600; margin-bottom:0; }
</style>

		