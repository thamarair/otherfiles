<?php echo $this->ajax_pagination->create_links(); ?>
                  <div class="x_content">
                    <div class="row">
                      <div class="col-md-12 col-sm-12 col-xs-12 text-center"> 
                      </div>

                      <div class="clearfix"></div>
<?php 
	$ini=0; 
	foreach($userslist as $res){
	$ini++;
	?>	
                      <div class="col-md-4 col-sm-4 col-xs-12 profile_details">
                        <div class="well profile_view" style="background:#f4f7ff">
                          <div class="col-sm-12" style="min-height: 220px;">
						  <div class="col-sm-6">
                            <h4 class="brief"><i><b><?php echo $res['fname']; ?></b></i></h4></div>
							<div class="col-sm-6">
                            <h5 style="float:right" class="brief"><i><b> Grade : <?php echo str_replace("Grade","", $res['grade']); ?></b></i></h5></div>
							
                            <div class="left col-xs-7 <?php if($res['status']==0) { ?> inactiveelement <?php } ?>">
                              <ul class="list-unstyled">
							  <?php if($res['father']!='') { ?>
							  <li><i class="fa fa-user"></i> <?php echo $res['father']; ?></li><?php } ?>
							  <?php if($res['dob']!='') { ?>
							  <li><i class="fa fa-birthday-cake"></i> <?php echo date('d-m-Y',strtotime($res['dob'])); ?></li><?php } ?>
							<!--<li>Grade : <?php echo str_replace("Grade","", $res['grade']); ?></li>-->
								<?php if($res['creation_date']!='0000-00-00') { ?>
								<li>Created Date : <?php echo date('d-m-Y',strtotime($res['creation_date'])); ?></li><?php } ?>
                              </ul>
                            </div>
							
                          </div>
                          <div class="col-xs-12 bottom text-center" style="background:#93c5c7">
                            <div class="col-xs-12 col-sm-6 emphasis">
                            </div>
                            <div class="col-xs-12 col-sm-6 emphasis">
                              
                              <a style="float:right" href="<?php echo base_url(); ?>index.php/home/userview/<?php echo $res['id']; ?>" class="btn btn-success btn-xs">
                                <i class="fa fa-user"> </i> View Details
                              </a>
                            </div>
                          </div>
                        </div>
	</div><?php } ?>
                    </div>
					<?php echo $this->ajax_pagination->create_links(); ?>
                  </div>
               