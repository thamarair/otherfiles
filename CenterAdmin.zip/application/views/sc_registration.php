 <div class="right_col" role="main">
<div class="row">
<div class="col-md-12 col-sm-12 col-xs-12">
<div class="x_panel tile">
<div class="x_title">
<h2 class="reporttitle">Add Summer Camp User - <?php echo $this->session->centername; ?></h2>
<a href="<?php echo  base_url(); ?>index.php/home/userperformance" class="btn btn-success" id="downloadcsv" style="float: right;margin-bottom: 10px;" ><i class="fa fa-chevron-left"></i> Back</a>
<div class="clearfix"></div>
</div>
<div class="clearfix"></div>

	<div id="mainContDisp" class="container playGames homePlayGames" style="margin-top:20px;margin-bottom:70px;"> 
	
	<h2 id="licenseexpiremsg" style="text-align: center; color: red;font-size: 22px;"><?php if($chklicense[0]['givenlicense']<=$chklicense[0]['totalusers']) { ?>Your License has Expired
	<?php } ?></h2>
<form name="frmRegister" id="frmRegister" class="" method="post" <?php if($chklicense[0]['givenlicense']<=$chklicense[0]['totalusers']) { ?>style="display:none;" <?php } ?>   action=""  accept-charset="utf-8"  >
<div class="loading" style="display:none;" ><img src="<?php echo base_url(); ?>assets/images/ajax-page-loader.gif" style="width:80px;" /></div>
<h2 id="successmsg" style="text-align:center;color: green;font-size: 22px;"></h2>
 <div class="row">
    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 txtclr">
	

	
      <h3>Please fill the details below : </h3>
	  <?php if(isset($msg)){?> <div class="msg"><?php echo $msg; ?> </div><?php } ?>
	  <span style="float:right;"><label><span style="color:red">*</span> Required fields
	  </label></span>
	 
  
  </div>
</div>
<div class="row">
		<div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
      <div class="form-group">
    <label for="txtHName">Name <span style="color:red">*</span></label>
    <input type="text" maxlength="100" class="form-control alphaOnly" name="txtname" value=""  id="txtname">
  </div> 
  </div>
  <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
  <div class="form-group">
    <label for="txtEmail">Grade <span style="color:red">*</span></label>
    <select class="form-control"  name="ddlgrade" id="ddlgrade">
<option value="">Select</option>
<?php foreach($grades as $res) { ?> 
<option value="<?php echo $res['id']; ?>"><?php echo $res['classname']; ?></option>
<?php } ?>


</select> 
	<label id='errEmail' class="error"></label>
  </div>
    </div>
  
  
  <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
  <div class="form-group">
    <label for="txtSEmail">Gender <span style="color:red">*</span></label>
    <div class=""> 
       <div class="col-sm-3"><label class="radio-inline"><input type="radio" class=""  name="txtgender" value="M" id="rdGM">Male</label></div>
    <div class="col-sm-3"><label class="radio-inline"><input type="radio" class=""  name="txtgender" value="F" id="rdGF">Female</label></div>
	</div>
  </div>
    </div>
    </div>
	
	<div class="row">
	
	<div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
  <div class="form-group">
    <label for="txtcode">Username <span style="color:red">*</span></label>
    <input type="text" maxlength="15"  class="form-control" name="txtusername" value="" id="txtusername">
  </div> 
  <span id="errormsg" style="color: red;font-weight: bold;"></span>
  </div>
  <div class="col-lg-1 col-md-1 col-sm-1 col-xs-1" style="font-size: 20px;font-weight: 600;margin-top: 25px;">
  .<?php echo $this->session->centercode; ?>
  </div>
	
	<div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
  <div class="form-group">
    <label for="txtMobile">Mobile </label>
	 <div class="">
    <input placeholder="" type="text" class="form-control numbersOnly" maxlength="15" name="txtmobile" value="" id="txtmobile">
        </div>
  </div>
    </div> 
	
	<div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
  <div class="form-group">
    <label for="txtEmail">Email ID </label>
    <input type="text" maxlength="200" class="form-control" name="txtemail" value="" id="txtemail">
	<label id='errEmail' class="error"></label>
  </div>
    </div>
	
	</div>
	
	<div class="row">
		<div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
  <div class="form-group">
    <label for="txtEmail">Start Date <span style="color:red">*</span></label>
    <input type="text" maxlength="200" class="form-control" name="txtstartdate" value="" id="txtstartdate">
	<label id='errEmail' class="error"></label>
  </div>
    </div>	
	</div>
	
	<div class="row">
		<div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
<p style="font-size: 18px;"><span style="font-weight: 700;color: #000;">Note</span> : Account valid for <?php echo $validity[0]['value']; ?>days from start date</p>
<p style="font-size: 18px;"><span style="font-weight: 700;color: #000;">Password</span> : gensmart</p>
    </div>	
	</div>

	<div class="row>"
	
	<div style="text-align:center;clear:both;">
   <input type="button" id="regsubmit" name="regsubmit" style="float:none;" class="btn btn-success" value="Submit">
   <input type="reset"  id="frmreset" class="btn btn-waring">
</div>
</div>
	
</div>
</div>
</div>
		
		 </form></div>





<script type="text/javascript">

	
	
	
 
 
</script>
<style>
.reporttitle { color:#1abb9c; }
thead{ background-color: #1abb9c; color: #fff;}
.error {color:red;}


.loading {
  position: fixed;
  z-index: 999;
  height: 2em;
  width: 2em;
  overflow: show;
  margin: auto;
  top: 0;
  left: 0;
  bottom: 0;
  right: 0;
}

.loading:before {
  content: '';
  display: block;
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background-color: rgba(0,0,0,0.3);
}

/* :not(:required) hides these rules from IE9 and below */
.loading:not(:required) {
  /* hide "loading..." text */
  font: 0/0 a;
  color: transparent;
  text-shadow: none;
  background-color: transparent;
  border: 0;
}
</style>

