
        <div class="right_col" role="main">
          <!-- top tiles -->
          
<!-- /top tiles -->
<div class="row">

<div class="col-md-6 col-sm-6 col-xs-6">
<div class="x_panel tile" style="min-height: 280px;">
<div class="x_title">
<h2 class="reporttitle">Dashboard</h2>
<div class="clearfix"></div>
</div>
<div class="clearfix"></div>
<div class="row">
	<div class="animated flipInY col-lg-6 col-md-6 col-sm-6 col-xs-12">
		<div class="tile-stats">
		<a href="<?php echo base_url(); ?>index.php/home/couponscanned">
			<div class="toppart" style="background-color: #ffa500;color:#fff">
			<div class="icon"><i class="fa fa-users"></i></div>
				<div class="count" id="couponscanned"></div>
				<h4>Coupons Scanned</h4>
			</div>
			<div class="footerpart">
				<p class="pull-left">View Details</p><span class="pull-right"><i style="color:#26b99a" class="fa fa-arrow-circle-right"></i></span>
			</div></a>
		</div>
</div>

<div class="animated flipInY col-lg-6 col-md-6 col-sm-6 col-xs-12">

		<div class="col-lg-6">
	  <div class="form-group">
	  <form name="frmqrcode" id="" class="" method="post">
		<label for="txtqrcode">QR Value<span style="color:red">*</span></label>
		<input type="text" maxlength="8"  class="form-control alphaOnly" required="true" name="txtqrcode" value="" id="txtqrcode" />
		
	  </div> 
  </div>
  
  <div class="col-lg-6" style="margin-top: 21px;">
	  <div class="form-group">
		<input type="button" id="btnactivate" style="float:none;" class="btn btn-success btnactivate" value="Activate">
</form>
	  </div> 
  </div>
 
</div>
<div id="successmsg" style="color: green; text-align: center;"></div>
</div>


<div class="row">
	<div class="animated flipInY col-lg-6 col-md-6 col-sm-6 col-xs-12">
		<div class="tile-stats">
			<a href="<?php echo base_url(); ?>index.php/home/userslist">
			<div class="toppart" style="background-color: #ffa500;color:#fff">
			<div class="icon"><i class="fa fa-users"></i></div>
				<div class="count"><?php echo $userscount[0]['total']; ?></div>
				<h4>User</h4>
			</div>
			
			<div class="footerpart">
				<p class="pull-left">View Details</p><span class="pull-right"><i style="color:#26b99a" class="fa fa-arrow-circle-right"></i></span>
			</div></a>
		</div>
</div>

</div>

</div>
</div>

<div class="col-md-6 col-sm-6 col-xs-12">
<div class="x_panel tile" style="min-height: 280px;">
<div class="x_title">
<h2 class="reporttitle">Profile</h2>
<div class="clearfix"></div>
</div>
<div class="clearfix"></div>

<div class="col-md-6 col-sm-6 col-xs-12 profile_left">
                     
                      <h3><?php echo $doctorinfo[0]['doctorname'];  ?></h3>
                      <ul class="list-unstyled user_data">
					<li><i class="fa fa-birthday-cake"></i> <?php echo $doctorinfo[0]['dateofbirth'];  ?></li>
                        <li><i class="fa fa-map-marker user-profile-icon"></i> <?php echo $doctorinfo[0]['address'];  ?>, <?php echo $doctorinfo[0]['city'];  ?>, <?php echo $doctorinfo[0]['statename'];  ?></li>
                        <li><i class="fa fa-mobile-phone"></i> <?php echo $doctorinfo[0]['mobilenumber'];  ?> <?php if($doctorinfo[0]['secondarymobilenumber']!='') {  echo " / ". $doctorinfo[0]['secondarymobilenumber'];   } ?></li>
                        <li>
                          <i class="fa fa-envelope-o"></i> <?php echo $doctorinfo[0]['email'];  ?> <?php if($doctorinfo[0]['secondaryemail']!='') {  echo " / ". $doctorinfo[0]['secondaryemail'];   } ?>
                        </li>
						<?php if($doctorinfo[0]['hospitalname']!=''){ ?>
							<li><i class="fa fa-hospital-o"></i> <?php echo $doctorinfo[0]['hospitalname'];  ?></li>
						<?php } ?>
                      </ul>
                    </div>
					
					<div class="col-md-6 col-sm-6 col-xs-12 profile_left">
						<?php if($doctorinfo[0]['profileimage']!=''){ ?>
                       <img src="<?php echo base_url(); ?><?php echo $doctorinfo[0]['profileimage'];  ?>" class="img-responsive avatar-view" style="width:100px; height:100px;" alt="profile image"  />
						<?php } ?>
                    </div>
					<br/>
					<div class="col-xs-12 col-sm-6 emphasis" style="padding: 10px;">
                              <a href="<?php echo base_url(); ?>index.php/home/doctoredit/" target="_blank" class="btn btn-success btn-xs">
                                <i class="fa fa-edit"> </i> Edit Details
                              </a>
                            </div>
					

</div>
</div>
</div>
	</div>
	
	<script src="<?php echo base_url(); ?>assets/js/jquery.min.js"></script>
	<script>
	$(document).ready(function(){
	couponcounts();
	});
	
	$('#btnactivate').click(function(){
		
		var qrcode = $('#txtqrcode').val();
		var doctorid = '<?php echo $this->session->doctorid; ?>';
		
		$.ajax({
type:"POST",
url:"<?php echo base_url('index.php/api/checkqrcode') ?>",
data:{qrcode:qrcode,doctorid:doctorid},
success:function(result)
{
//alert(result);
$("#successmsg").html(result);
couponcounts();
}
});
		
	});
	
		function couponcounts()
	{
			$.ajax({
type:"POST",
dataType: "json",
url:"<?php echo base_url('index.php/home/couponcounts') ?>",
data:{},
success:function(result)
{
//alert(result);
$("#couponscanned").html(result);
}
});

	}
	</script>
	
   