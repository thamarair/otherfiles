 <div class="row">
 <div class="col-md-12 col-sm-12 col-xs-12">
<div class="x_panel tile">
<div class="x_title">
<h2><span style="background:aqua; padding:5px; border-radius:45px; color:#000;">Product - Summer Camp</span></h2>
<h2 style="float: right;margin-bottom: 10px;" >License in Hand : <?php echo $distributedlicence_sc[0]['totalcount'] - $userscount_sc[0]['total']; ?></h2>
<div class="clearfix"></div>
</div>
<div class="clearfix"></div>

<div class="row">
	<div class="animated flipInY col-lg-4 col-md-4 col-sm-4 col-xs-12">
	
	<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
		<div class="tile-stats">
			<!--<a href="<?php echo base_url(); ?>index.php/home/userslist">-->
			<div class="toppart" style="background-color: #ffa500;color:#fff">
			<div class="icon"><i class="fa fa-credit-card"></i></div>
				<div class="count"><?php if($distributedlicence_sc[0]['totalcount']=='') { echo 0; } else { echo $distributedlicence_sc[0]['totalcount']; } ?></div>
				<h4>Total Licenses</h4>
			</div>
			
			<div class="footerpart">
				<p class="pull-left"></p><span style="visibility:hidden;" class="pull-right"><i  class="fa fa-arrow-circle-down"></i></span>
			</div>
		</div>
		</div>
	
	
	<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
	<a href="javascript:;" id = "buttonLogin" onclick = "displayLoginBox()">
		<div class="tile-stats">
			<!--<a href="<?php echo base_url(); ?>index.php/home/userslist">-->
			<div class="toppart" style="background-color: #ffa500;color:#fff">
			<div class="icon"><i class="fa fa-credit-card"></i></div>
				<div class="count"><?php echo $userscount_sc[0]['total']; ?></div>
				<h4>Licenses Used</h4>
			</div>
			
			<div class="footerpart">
				<p class="pull-left"></p><span class="pull-right"><i class="fa fa-arrow-circle-down"></i></span>
			</div>
		</div></a>
		</div>
		
		<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12" style="display:none;" id="login_Box_Div">
<!--<div id="Gradewiseusers" style="background:#fff;padding-top:20px;border: 1px solid #ccc;" ></div>-->

<table id="assementTable1" class="table table-striped table-bordered table-hover table-condensed">
    <thead>
      <tr>
        <th>S.No.</th>
        <th>Grade</th>
		<th>Users Count</th>
       
      </tr>
    </thead>
    <tbody>
	<?php 
	$ini=0; 
	foreach($gradewiseusers_sc as $res){
	$ini++;
	?>	
      <tr>
        <td><?php echo $ini; ?></td>
		<td><?php echo $res['grade']; ?></td>
		<td><?php echo $res['usercount']; ?></td>
		</tr>
		<?php } ?>
		  </tbody>
  </table>
</div>
		
		
</div>

<div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
<div class="x_panel tile">
<div class="x_title">
<div>
<h2 class="reporttitle">User Performance</h2>
<a href="javascript:;" class="btn btn-success" id="downloadcsv" style="float: right;margin-bottom: 10px;" ><i class="fa fa-download"></i> Download</a>
</div>
<div style="clear:both">Note : Click on specific student name to view their details</div>

<div class="clearfix"></div>
<div class="clearfix"></div>
</div>
<div class="clearfix"></div>
	<table id="assementTable" class="table table-striped table-bordered table-hover table-condensed">
    <thead>
      <tr>
        <th>S.No.</th>
        <th>Student Name</th>
		<th>Username</th>
		<th>Grade</th>  		
		<th>Registered Date</th>
		<th>Startdate</th>
		<th>No. of Days Played</th>
		<th>BSPI</th>
		<th>Action</th>
       
      </tr>
    </thead>
    <tbody>
	<?php 
	$ini=0; 
	foreach($userdetails_sc as $res){
	$ini++;
	?>	
      <tr>
        <td><?php echo $ini; ?></td>
		<td class="fname"><a href="<?php echo base_url(); ?>index.php/home/userview_sc/<?php echo $res['id'];  ?>" style="text-decoration:underline;" class=""><?php echo $res['fname']; ?></a></td>
		<td><?php echo $res['username']; ?></td>
		<td><?php echo $res['grade']; ?></td>		
		<td><?php echo date('d-m-Y',strtotime($res['creation_date'])); ?></td>
		<td><?php echo date('d-m-Y',strtotime($res['startdate'])); ?></td>		
		<td><?php echo $res['totaldays']; ?></td>
		<td><?php if($res['avgbspiset1']=='') {  echo '-'; } else { echo $res['avgbspiset1'];  } ?>
		<?php if($res['totaldays']!=0) { ?>
		<a class="popscore" style="float:right" href="javascript:;" data-target="#pwdModal" data-toggle="modal" data-info="<table><tr><td>Memory &nbsp;&nbsp;</td><td>&nbsp;&nbsp;<?php if($res['skillscorem']=='') {  echo '-'; } else { echo $res['skillscorem'];  }  ?></td></tr><tr><td>Visual Processing &nbsp;&nbsp;</td><td>&nbsp;&nbsp;<?php if($res['skillscorev']=='') {  echo '-'; } else { echo $res['skillscorev'];  } ?></td></tr><tr><td>Focus and Attention &nbsp;&nbsp;</td><td>&nbsp;&nbsp;<?php if($res['skillscoref']=='') {  echo '-'; } else { echo $res['skillscoref'];  } ?></td></tr><tr><td>Problem Solving &nbsp;&nbsp;</td><td>&nbsp;&nbsp;<?php if($res['skillscorep']=='') {  echo '-'; } else { echo $res['skillscorep'];  } ?></td></tr><tr><td>Linguistics &nbsp;&nbsp;</td><td>&nbsp;&nbsp;<?php if($res['skillscorel']=='') {  echo '-'; } else { echo $res['skillscorel'];  } ?></td></tr></table>"><i class="fa fa-info"></i></a> <?php } ?>
		</td>
		<td><a href="<?php echo base_url(); ?>index.php/home/userview_sc/<?php echo $res['id'];  ?>" class="btn btn-success"><i class="fa fa-eye"></i> View</a></td>
      </tr>
	<?php } ?>
      
	  
    </tbody>
  </table>
	
</div>
</div>
</div>

<!--<div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
<div id="Usercountdatewise" style="background:#fff;padding-top:20px;border: 1px solid #ccc;" ></div>
</div>-->

</div>
</div>
 </div>
 
<div class="row">

</div>
		
		

<link href="<?php echo base_url(); ?>assets/css/jquery.dataTables.css" rel="stylesheet" type="text/css">
<link href="<?php echo base_url(); ?>assets/css/dataTables.tableTools.css" rel="stylesheet" type="text/css">
<script src="<?php echo base_url(); ?>assets/js/jquery.min.js" type="text/javascript"></script>
<script src="<?php echo base_url(); ?>assets/js/jquery.dataTables.js" type="text/javascript"></script>
<script src="<?php echo base_url(); ?>assets/js/dataTables.tableTools.js" type="text/javascript"></script>
<script>
$('#buttonLogin').on('click', function(e){

    $("#login_Box_Div").toggle();
  //  $(this).toggleClass('class1')
});

$('#assementTable').DataTable( {
	"lengthMenu": [[10,  -1], [10,  "All"]],
	"fnDrawCallback": function (oSettings) {
	
		$('.popscore').click(function(){
			$(".modaldata").html("");$(".modalheading").html("");
			$(".modalheading").html($(this).parent().siblings('td.fname').html()+" - Skill Score");
			$(".modaldata").html($(this).attr("data-info"));
		});
	}
//"scrollX": true
});

$('#downloadcsv').click(function(){
		$.ajax({
type:"POST",
url:"<?php echo base_url('index.php/home/sc_userlist_csv') ?>",
data:{},
success:function(result)
{
//alert(result);
var s = result.replace(/\uploads/g, '');
var res = s.replace(/\//g, '');
$("#downloadcsv").attr("download", res);
window.location.href= "<?php echo base_url(); ?>"+ result +"";
}
});
		
	$('.asap').click(function(){
		//alert($(this).parent().siblings('td.fname').html());
		$(".modaldata").html("");$(".modalheading").html("");
		$(".modalheading").html($(this).parent().siblings('td.fname').html()+" - ASAP Skill Score");	
		$(".modaldata").html($(this).attr("data-info"));
	});
	$('.clp').click(function(){
		$(".modaldata").html("");$(".modalheading").html("");
		$(".modalheading").html($(this).parent().siblings('td.fname').html()+" - CLP Skill Score");
		$(".modaldata").html($(this).attr("data-info"));
	});
});

</script>
<style>
.reporttitle { color:#1abb9c; }
thead{ background-color: #1abb9c; color: #fff;}
body{ padding-right: 0px !important; }
body.modal-open { padding-right: 0px !important; }
.modal-content {width: 70%;margin: 0 auto;}
.modaldata table{margin: 0 auto;}
.modaldata td{text-align:justify;}
.modalheading{color: #0d77de;font-weight: bold;}
.panel-default{border-color: #5187bd;background: #3d6a96;color: #fff;}
</style>
