<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Api_model extends CI_Model {

        
        public function __construct()
        {
                // Call the CI_Model constructor
                parent::__construct();
				 $this->load->database();
        }
		public function checklogin($username,$password)
        {
			//echo 'select id FROM doctormaster WHERE username="'.$username.'" AND password="'.md5($password).'" AND status=1'; exit;
			$query = $this->db->query('select id,doctorname FROM doctormaster WHERE username="'.$username.'" AND password="'.md5($password).'" AND status=1');
			
			//echo $this->db->last_query(); exit;
			return $query->result();
        }
		public function checkqrcode($qrcode)
        {
			$query = $this->db->query('select qrcode,status,region_usedstatus FROM couponmaster a WHERE  qrcode="'.$qrcode.'"');
			
			//echo $this->db->last_query(); exit;
			return $query->result_array();
        }
		
		public function activateqrcode($doctorid,$qrcode)
        {
			//echo 'UPDATE couponmaster SET status=1,doctorid="'.$doctorid.'",qr_scanned_date_time=NOW() where  qrcode="'.$qrcode.'"'; exit;
			$query = $this->db->query('UPDATE couponmaster SET status=1,doctorid="'.$doctorid.'",qr_scanned_date_time=NOW() where  qrcode="'.$qrcode.'"');
			
			//echo $this->db->last_query(); exit;
			//return $query->result_array();
        }
		
	public function getQRList($doctorid)
        {
 			$query = $this->db->query("SELECT concat(qrcode,'@@',date(qr_scanned_date_time),'##',usedstatus) as ldata FROM couponmaster WHERE doctorid=".$doctorid." ORDER BY qr_scanned_date_time DESC");
			return $query->result_array();
        }
		
			public function getdoctorname($doctorid)
        {
 			$query = $this->db->query("SELECT doctorname FROM doctormaster WHERE id=".$doctorid."");
			return $query->result_array();
        }
public function getRegionalManager($qrcode)
{
	$query=$this->db->query("SELECT regionname,personname,mobilenumber,email FROM couponmaster join regionmaster as r on r.id=regionid WHERE qrcode='".$qrcode."' ");
	//echo $this->db->last_query(); exit;
	return $query->result_array();
}
		
	
}